package self_test

import (
	"bytes"
	"context"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/qlogwriter"
	"github.com/quic-go/quic-go/qlogwriter/jsontext"
	"github.com/quic-go/quic-go/testutils/events"
)

func issue301Log(format string, args ...any) {
	fmt.Printf("[DEBUG-301] %s %s\n", time.Now().UTC().Format(time.RFC3339Nano), fmt.Sprintf(format, args...))
}

type issue301Recorder struct {
	mu    sync.Mutex
	id    string
	lines []string
}

func (r *issue301Recorder) RecordEvent(ev qlogwriter.Event) {
	now := time.Now().UTC()
	var b bytes.Buffer
	err := ev.Encode(jsontext.NewEncoder(&b), now)
	line := fmt.Sprintf("%s %s %s encode_error=%v", now.Format(time.RFC3339Nano), ev.Name(), b.String(), err)
	r.mu.Lock()
	r.lines = append(r.lines, line)
	r.mu.Unlock()
}

func (r *issue301Recorder) Close() error { return nil }

type issue301Diagnostics struct {
	mu        sync.Mutex
	recorders []*issue301Recorder
	stop      chan struct{}
	wg        sync.WaitGroup
}

func newIssue301Diagnostics(t *testing.T) *issue301Diagnostics {
	d := &issue301Diagnostics{stop: make(chan struct{})}
	t.Cleanup(func() {
		close(d.stop)
		d.wg.Wait()
		d.mu.Lock()
		defer d.mu.Unlock()
		for _, r := range d.recorders {
			r.mu.Lock()
			issue301Log("event-snapshot id=%s count=%d truncated=false", r.id, len(r.lines))
			for _, line := range r.lines {
				fmt.Printf("[DEBUG-301-EVENT] %s %s\n", r.id, line)
			}
			r.mu.Unlock()
		}
	})
	return d
}

func (d *issue301Diagnostics) tracer(_ context.Context, isClient bool, cid quic.ConnectionID) qlogwriter.Trace {
	r := &issue301Recorder{id: fmt.Sprintf("client=%t cid=%s", isClient, cid)}
	d.mu.Lock()
	d.recorders = append(d.recorders, r)
	d.mu.Unlock()
	issue301Log("tracer-created %s", r.id)
	return &events.Trace{Recorder: r}
}

func (d *issue301Diagnostics) observe(side string, c *quic.Conn) {
	issue301Log("conn-observed side=%s conn=%p local=%s remote=%s tls_complete=%t", side, c, c.LocalAddr(), c.RemoteAddr(), c.ConnectionState().TLS.HandshakeComplete)
	d.wg.Add(1)
	go func() {
		defer d.wg.Done()
		select {
		case <-c.HandshakeComplete():
			issue301Log("handshake-complete side=%s conn=%p", side, c)
		case <-c.Context().Done():
			issue301Log("connection-closed-before-handshake-observed side=%s conn=%p cause=%v", side, c, context.Cause(c.Context()))
			return
		case <-d.stop:
			return
		}
		select {
		case <-c.Context().Done():
			issue301Log("connection-closed side=%s conn=%p cause=%v", side, c, context.Cause(c.Context()))
		case <-d.stop:
			issue301Log("observer-stopped side=%s conn=%p cause=%v", side, c, context.Cause(c.Context()))
		}
	}()
}
