TEXT github.com/quic-go/quic-go.(*Conn).triggerSending(SB) /Volumes/worktrees/quic-go-fast/e4-linux-candidate/connection.go
  connection.go:2483	0x6c29c0		4c8d6424c8		LEAQ -0x38(SP), R12							
  connection.go:2483	0x6c29c5		4d3b6610		CMPQ R12, 0x10(R14)							
  connection.go:2483	0x6c29c9		0f8652020000		JBE 0x6c2c21								
  connection.go:2483	0x6c29cf		55			PUSHQ BP								
  connection.go:2483	0x6c29d0		4889e5			MOVQ SP, BP								
  connection.go:2483	0x6c29d3		4881ecb0000000		SUBQ $0xb0, SP								
  connection.go:2485	0x6c29da		48898424c0000000	MOVQ AX, 0xc0(SP)							
  connection.go:2485	0x6c29e2		48899c24c8000000	MOVQ BX, 0xc8(SP)							
  connection.go:2483	0x6c29ea		488d542420		LEAQ 0x20(SP), DX							
  connection.go:2483	0x6c29ef		440f113a		MOVUPS X15, 0(DX)							
  connection.go:2483	0x6c29f3		440f117a10		MOVUPS X15, 0x10(DX)							
  connection.go:2483	0x6c29f8		440f117a20		MOVUPS X15, 0x20(DX)							
  connection.go:2483	0x6c29fd		31c9			XORL CX, CX								
  connection.go:2483	0x6c29ff		90			NOPL									
  connection.go:2485	0x6c2a00		eb12			JMP 0x6c2a14								
  connection.go:2487	0x6c2a02		488b8424c0000000	MOVQ 0xc0(SP), AX							
  connection.go:2491	0x6c2a0a		488b9c24c8000000	MOVQ 0xc8(SP), BX							
  connection.go:2491	0x6c2a12		89f1			MOVL SI, CX								
  connection.go:2491	0x6c2a14		884c241e		MOVB CL, 0x1e(SP)							
  connection.go:2487	0x6c2a18		80b83b03000000		CMPB 0x33b(AX), $0x0							
  connection.go:2487	0x6c2a1f		90			NOPL									
  connection.go:2487	0x6c2a20		7515			JNE 0x6c2a37								
  connection.go:2488	0x6c2a22		e8b9fdffff		CALL github.com/quic-go/quic-go.(*Conn).applyHandshakeMTUFallback(SB)	
  connection.go:2490	0x6c2a27		488b8424c0000000	MOVQ 0xc0(SP), AX							
  connection.go:2491	0x6c2a2f		488b9c24c8000000	MOVQ 0xc8(SP), BX							
  connection.go:2490	0x6c2a37		48c7806003000000000000	MOVQ $0x0, 0x360(AX)							
  connection.go:2491	0x6c2a42		0fb6883b030000		MOVZX 0x33b(AX), CX							
  connection.go:2491	0x6c2a49		e812cb0000		CALL github.com/quic-go/quic-go.(*packetEmission).dispatch(SB)		
  connection.go:2491	0x6c2a4e		88842480000000		MOVB AL, 0x80(SP)							
  connection.go:2491	0x6c2a55		48899c2488000000	MOVQ BX, 0x88(SP)							
  connection.go:2491	0x6c2a5d		888c2490000000		MOVB CL, 0x90(SP)							
  connection.go:2491	0x6c2a64		4889bc2498000000	MOVQ DI, 0x98(SP)							
  connection.go:2491	0x6c2a6c		4889b424a0000000	MOVQ SI, 0xa0(SP)							
  connection.go:2491	0x6c2a74		4c898424a8000000	MOVQ R8, 0xa8(SP)							
  connection.go:2500	0x6c2a7c		0fb6942480000000	MOVZX 0x80(SP), DX							
  connection.go:2492	0x6c2a84		0fb674241e		MOVZX 0x1e(SP), SI							
  connection.go:2492	0x6c2a89		09d6			ORL DX, SI								
  connection.go:2494	0x6c2a8b		0fb6bc2490000000	MOVZX 0x90(SP), DI							
  connection.go:2508	0x6c2a93		4c8b842498000000	MOVQ 0x98(SP), R8							
  connection.go:2493	0x6c2a9b		4883bc24a000000000	CMPQ 0xa0(SP), $0x0							
  connection.go:2491	0x6c2aa4		4c8d4c2450		LEAQ 0x50(SP), R9							
  connection.go:2491	0x6c2aa9		4c8d942480000000	LEAQ 0x80(SP), R10							
  connection.go:2491	0x6c2ab1		450f1032		MOVUPS 0(R10), X14							
  connection.go:2491	0x6c2ab5		450f1131		MOVUPS X14, 0(R9)							
  connection.go:2491	0x6c2ab9		450f107210		MOVUPS 0x10(R10), X14							
  connection.go:2491	0x6c2abe		450f117110		MOVUPS X14, 0x10(R9)							
  connection.go:2491	0x6c2ac3		450f107220		MOVUPS 0x20(R10), X14							
  connection.go:2491	0x6c2ac8		450f117120		MOVUPS X14, 0x20(R9)							
  connection.go:2493	0x6c2acd		0f85f9000000		JNE 0x6c2bcc								
  connection.go:2494	0x6c2ad3		4883ff09		CMPQ DI, $0x9								
  connection.go:2494	0x6c2ad7		0f87ef000000		JA 0x6c2bcc								
  connection.go:2492	0x6c2add		408874241e		MOVB SI, 0x1e(SP)							
  connection.go:2494	0x6c2ae2		488d0517b60d00		LEAQ 0xdb617(IP), AX							
  connection.go:2494	0x6c2ae9		ff24f8			JMP 0(AX)(DI*8)								
  connection.go:2500	0x6c2aec		84d2			TESTL DL, DL								
  connection.go:2500	0x6c2aee		0f84d8000000		JE 0x6c2bcc								
  connection.go:2745	0x6c2af4		488b8c24c0000000	MOVQ 0xc0(SP), CX							
  connection.go:2745	0x6c2afc		488b81a0020000		MOVQ 0x2a0(CX), AX							
  connection.go:2501	0x6c2b03		90			NOPL									
  connection.go:2745	0x6c2b04		488d5c241f		LEAQ 0x1f(SP), BX							
  connection.go:2745	0x6c2b09		e8527bd5ff		CALL runtime.selectnbsend(SB)						
  connection.go:2513	0x6c2b0e		0fb674241e		MOVZX 0x1e(SP), SI							
  connection.go:2491	0x6c2b13		4c8d4c2450		LEAQ 0x50(SP), R9							
  connection.go:2500	0x6c2b18		e9af000000		JMP 0x6c2bcc								
  connection.go:2504	0x6c2b1d		488b9424c0000000	MOVQ 0xc0(SP), DX							
  connection.go:2504	0x6c2b25		c6823f03000002		MOVB $0x2, 0x33f(DX)							
  connection.go:2504	0x6c2b2c		e99b000000		JMP 0x6c2bcc								
  connection.go:2508	0x6c2b31		488b9424c0000000	MOVQ 0xc0(SP), DX							
  connection.go:2508	0x6c2b39		4c898260030000		MOVQ R8, 0x360(DX)							
  connection.go:2508	0x6c2b40		e987000000		JMP 0x6c2bcc								
  connection.go:2506	0x6c2b45		488b9424c0000000	MOVQ 0xc0(SP), DX							
  connection.go:2506	0x6c2b4d		c6823f03000001		MOVB $0x1, 0x33f(DX)							
  connection.go:2506	0x6c2b54		eb76			JMP 0x6c2bcc								
  connection.go:2496	0x6c2b56		488b8424c0000000	MOVQ 0xc0(SP), AX							
  connection.go:2496	0x6c2b5e		488b9c24c8000000	MOVQ 0xc8(SP), BX							
  connection.go:2496	0x6c2b66		e8d5000000		CALL github.com/quic-go/quic-go.(*Conn).emitPackets(SB)			
  connection.go:2496	0x6c2b6b		88842480000000		MOVB AL, 0x80(SP)							
  connection.go:2496	0x6c2b72		48899c2488000000	MOVQ BX, 0x88(SP)							
  connection.go:2496	0x6c2b7a		888c2490000000		MOVB CL, 0x90(SP)							
  connection.go:2496	0x6c2b81		4889bc2498000000	MOVQ DI, 0x98(SP)							
  connection.go:2496	0x6c2b89		4889b424a0000000	MOVQ SI, 0xa0(SP)							
  connection.go:2496	0x6c2b91		4c898424a8000000	MOVQ R8, 0xa8(SP)							
  connection.go:2496	0x6c2b99		488d4c2450		LEAQ 0x50(SP), CX							
  connection.go:2496	0x6c2b9e		488d942480000000	LEAQ 0x80(SP), DX							
  connection.go:2496	0x6c2ba6		440f1032		MOVUPS 0(DX), X14							
  connection.go:2496	0x6c2baa		440f1131		MOVUPS X14, 0(CX)							
  connection.go:2496	0x6c2bae		440f107210		MOVUPS 0x10(DX), X14							
  connection.go:2496	0x6c2bb3		440f117110		MOVUPS X14, 0x10(CX)							
  connection.go:2496	0x6c2bb8		440f107220		MOVUPS 0x20(DX), X14							
  connection.go:2496	0x6c2bbd		440f117120		MOVUPS X14, 0x20(CX)							
  connection.go:2513	0x6c2bc2		0fb674241e		MOVZX 0x1e(SP), SI							
  connection.go:2491	0x6c2bc7		4c8d4c2450		LEAQ 0x50(SP), R9							
  connection.go:2513	0x6c2bcc		0fb6542450		MOVZX 0x50(SP), DX							
  connection.go:2513	0x6c2bd1		09d6			ORL DX, SI								
  connection.go:2513	0x6c2bd3		4088742450		MOVB SI, 0x50(SP)							
  connection.go:2514	0x6c2bd8		0fb6442450		MOVZX 0x50(SP), AX							
  connection.go:2514	0x6c2bdd		488b5c2458		MOVQ 0x58(SP), BX							
  connection.go:2514	0x6c2be2		0fb64c2460		MOVZX 0x60(SP), CX							
  connection.go:2514	0x6c2be7		488b7c2468		MOVQ 0x68(SP), DI							
  connection.go:2514	0x6c2bec		488b742470		MOVQ 0x70(SP), SI							
  connection.go:2514	0x6c2bf1		4c8b442478		MOVQ 0x78(SP), R8							
  connection.go:2514	0x6c2bf6		488d542420		LEAQ 0x20(SP), DX							
  connection.go:2514	0x6c2bfb		450f1031		MOVUPS 0(R9), X14							
  connection.go:2514	0x6c2bff		440f1132		MOVUPS X14, 0(DX)							
  connection.go:2514	0x6c2c03		450f107110		MOVUPS 0x10(R9), X14							
  connection.go:2514	0x6c2c08		440f117210		MOVUPS X14, 0x10(DX)							
  connection.go:2514	0x6c2c0d		450f107120		MOVUPS 0x20(R9), X14							
  connection.go:2514	0x6c2c12		440f117220		MOVUPS X14, 0x20(DX)							
  connection.go:2514	0x6c2c17		4881c4b0000000		ADDQ $0xb0, SP								
  connection.go:2514	0x6c2c1e		5d			POPQ BP									
  connection.go:2514	0x6c2c1f		90			NOPL									
  connection.go:2514	0x6c2c20		c3			RET									
  connection.go:2483	0x6c2c21		4889442408		MOVQ AX, 0x8(SP)							
  connection.go:2483	0x6c2c26		48895c2410		MOVQ BX, 0x10(SP)							
  connection.go:2483	0x6c2c2b		e830a2dcff		CALL runtime.morestack_noctxt.abi0(SB)					
  connection.go:2483	0x6c2c30		488b442408		MOVQ 0x8(SP), AX							
  connection.go:2483	0x6c2c35		488b5c2410		MOVQ 0x10(SP), BX							
  connection.go:2483	0x6c2c3a		e981fdffff		JMP github.com/quic-go/quic-go.(*Conn).triggerSending(SB)		
