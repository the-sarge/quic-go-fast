TEXT github.com/quic-go/quic-go.(*Conn).triggerSending(SB) /Volumes/worktrees/quic-go-fast/e4-linux-base/connection.go
  connection.go:2483	0x6c29c0		4c8d6424a8		LEAQ -0x58(SP), R12							
  connection.go:2483	0x6c29c5		4d3b6610		CMPQ R12, 0x10(R14)							
  connection.go:2483	0x6c29c9		0f86eb050000		JBE 0x6c2fba								
  connection.go:2483	0x6c29cf		55			PUSHQ BP								
  connection.go:2483	0x6c29d0		4889e5			MOVQ SP, BP								
  connection.go:2483	0x6c29d3		4881ecd0000000		SUBQ $0xd0, SP								
  connection.go:2485	0x6c29da		48898424e0000000	MOVQ AX, 0xe0(SP)							
  connection.go:2485	0x6c29e2		48899c24e8000000	MOVQ BX, 0xe8(SP)							
  connection.go:2483	0x6c29ea		488d4c2430		LEAQ 0x30(SP), CX							
  connection.go:2483	0x6c29ef		440f1139		MOVUPS X15, 0(CX)							
  connection.go:2483	0x6c29f3		440f117910		MOVUPS X15, 0x10(CX)							
  connection.go:2483	0x6c29f8		440f117920		MOVUPS X15, 0x20(CX)							
  connection.go:2485	0x6c29fd		80b83b03000000		CMPB 0x33b(AX), $0x0							
  connection.go:2485	0x6c2a04		7515			JNE 0x6c2a1b								
  connection.go:2486	0x6c2a06		e8d5fdffff		CALL github.com/quic-go/quic-go.(*Conn).applyHandshakeMTUFallback(SB)	
  connection.go:2488	0x6c2a0b		488b8424e0000000	MOVQ 0xe0(SP), AX							
  connection.go:2490	0x6c2a13		488b9c24e8000000	MOVQ 0xe8(SP), BX							
  connection.go:2488	0x6c2a1b		48c7806003000000000000	MOVQ $0x0, 0x360(AX)							
  connection.go:2490	0x6c2a26		488b8840010000		MOVQ 0x140(AX), CX							
  connection.go:2490	0x6c2a2d		488b8048010000		MOVQ 0x148(AX), AX							
  connection.go:2490	0x6c2a34		488b4978		MOVQ 0x78(CX), CX							
  connection.go:2490	0x6c2a38		ffd1			CALL CX									
  connection.go:2490	0x6c2a3a		660f1f440000		NOPW 0(AX)(AX*1)							
  connection.go:2491	0x6c2a40		3c01			CMPL AL, $0x1								
  connection.go:2507	0x6c2a42		0f87f8000000		JA 0x6c2b40								
  connection.go:2494	0x6c2a48		84c0			TESTL AL, AL								
  connection.go:2494	0x6c2a4a		7545			JNE 0x6c2a91								
  connection.go:2495	0x6c2a4c		488b9424e0000000	MOVQ 0xe0(SP), DX							
  connection.go:2495	0x6c2a54		c6823f03000002		MOVB $0x2, 0x33f(DX)							
  connection.go:2496	0x6c2a5b		488d542430		LEAQ 0x30(SP), DX							
  connection.go:2496	0x6c2a60		440f113a		MOVUPS X15, 0(DX)							
  connection.go:2496	0x6c2a64		440f117a10		MOVUPS X15, 0x10(DX)							
  connection.go:2496	0x6c2a69		440f117a20		MOVUPS X15, 0x20(DX)							
  connection.go:2496	0x6c2a6e		488b5c2438		MOVQ 0x38(SP), BX							
  connection.go:2496	0x6c2a73		4c8b442458		MOVQ 0x58(SP), R8							
  connection.go:2496	0x6c2a78		c644244007		MOVB $0x7, 0x40(SP)							
  connection.go:2496	0x6c2a7d		31c0			XORL AX, AX								
  connection.go:2496	0x6c2a7f		b907000000		MOVL $0x7, CX								
  connection.go:2496	0x6c2a84		31ff			XORL DI, DI								
  connection.go:2496	0x6c2a86		31f6			XORL SI, SI								
  connection.go:2496	0x6c2a88		4881c4d0000000		ADDQ $0xd0, SP								
  connection.go:2496	0x6c2a8f		5d			POPQ BP									
  connection.go:2496	0x6c2a90		c3			RET									
  connection.go:2511	0x6c2a91		488b8424e0000000	MOVQ 0xe0(SP), AX							
  connection.go:2511	0x6c2a99		c6803f03000001		MOVB $0x1, 0x33f(AX)							
  connection.go:2512	0x6c2aa0		488b9c24e8000000	MOVQ 0xe8(SP), BX							
  connection.go:2512	0x6c2aa8		e853150000		CALL github.com/quic-go/quic-go.(*Conn).maybeSendAckOnlyPacket(SB)	
  connection.go:2512	0x6c2aad		488d8c2490000000	LEAQ 0x90(SP), CX							
  connection.go:2512	0x6c2ab5		440f1139		MOVUPS X15, 0(CX)							
  connection.go:2512	0x6c2ab9		440f117910		MOVUPS X15, 0x10(CX)							
  connection.go:2512	0x6c2abe		440f117920		MOVUPS X15, 0x20(CX)							
  packet_emission.go:54	0x6c2ac3		c68424a000000007	MOVB $0x7, 0xa0(SP)							
  packet_emission.go:54	0x6c2acb		48898424b0000000	MOVQ AX, 0xb0(SP)							
  packet_emission.go:54	0x6c2ad3		48899c24b8000000	MOVQ BX, 0xb8(SP)							
  connection.go:2512	0x6c2adb		0fb68c2490000000	MOVZX 0x90(SP), CX							
  connection.go:2512	0x6c2ae3		488b942498000000	MOVQ 0x98(SP), DX							
  connection.go:2512	0x6c2aeb		0fb6b424a0000000	MOVZX 0xa0(SP), SI							
  connection.go:2512	0x6c2af3		488bbc24a8000000	MOVQ 0xa8(SP), DI							
  connection.go:2512	0x6c2afb		4c8b8424b0000000	MOVQ 0xb0(SP), R8							
  connection.go:2512	0x6c2b03		4c8d4c2430		LEAQ 0x30(SP), R9							
  connection.go:2512	0x6c2b08		450f1139		MOVUPS X15, 0(R9)							
  connection.go:2512	0x6c2b0c		450f117910		MOVUPS X15, 0x10(R9)							
  connection.go:2512	0x6c2b11		450f117920		MOVUPS X15, 0x20(R9)							
  connection.go:2512	0x6c2b16		c644244007		MOVB $0x7, 0x40(SP)							
  connection.go:2512	0x6c2b1b		4889442450		MOVQ AX, 0x50(SP)							
  connection.go:2512	0x6c2b20		48895c2458		MOVQ BX, 0x58(SP)							
  connection.go:2512	0x6c2b25		89c8			MOVL CX, AX								
  connection.go:2512	0x6c2b27		89f1			MOVL SI, CX								
  connection.go:2512	0x6c2b29		4c89c6			MOVQ R8, SI								
  connection.go:2512	0x6c2b2c		4989d8			MOVQ BX, R8								
  connection.go:2512	0x6c2b2f		4889d3			MOVQ DX, BX								
  connection.go:2512	0x6c2b32		4881c4d0000000		ADDQ $0xd0, SP								
  connection.go:2512	0x6c2b39		5d			POPQ BP									
  connection.go:2512	0x6c2b3a		c3			RET									
  connection.go:2512	0x6c2b3b		0f1f440000		NOPL 0(AX)(AX*1)							
  connection.go:2513	0x6c2b40		3c04			CMPL AL, $0x4								
  connection.go:2513	0x6c2b42		0f8696020000		JBE 0x6c2dde								
  connection.go:2497	0x6c2b48		3c05			CMPL AL, $0x5								
  connection.go:2497	0x6c2b4a		0f84b6010000		JE 0x6c2d06								
  connection.go:2492	0x6c2b50		3c06			CMPL AL, $0x6								
  connection.go:2492	0x6c2b52		0f8409010000		JE 0x6c2c61								
  connection.go:2525	0x6c2b58		488d15217f3e00		LEAQ 0x3e7f21(IP), DX							
  connection.go:2525	0x6c2b5f		48899424c0000000	MOVQ DX, 0xc0(SP)							
  connection.go:2525	0x6c2b67		0fb6d0			MOVZX AL, DX								
  connection.go:2525	0x6c2b6a		4c8d05ef0e0e00		LEAQ runtime.staticuint64s(SB), R8					
  connection.go:2525	0x6c2b71		498d14d0		LEAQ 0(R8)(DX*8), DX							
  connection.go:2525	0x6c2b75		48899424c8000000	MOVQ DX, 0xc8(SP)							
  errors.go:26		0x6c2b7d		488d0587940b00		LEAQ 0xb9487(IP), AX							
  errors.go:26		0x6c2b84		bb19000000		MOVL $0x19, BX								
  errors.go:26		0x6c2b89		488d8c24c0000000	LEAQ 0xc0(SP), CX							
  errors.go:26		0x6c2b91		bf01000000		MOVL $0x1, DI								
  errors.go:26		0x6c2b96		89fe			MOVL DI, SI								
  errors.go:26		0x6c2b98		e8830ee3ff		CALL fmt.errorf(SB)							
  errors.go:26		0x6c2b9d		0f1f00			NOPL 0(AX)								
  errors.go:26		0x6c2ba0		4885c0			TESTQ AX, AX								
  errors.go:26		0x6c2ba3		7533			JNE 0x6c2bd8								
  errors.go:31		0x6c2ba5		90			NOPL									
  errors.go:65		0x6c2ba6		b810000000		MOVL $0x10, AX								
  errors.go:65		0x6c2bab		488d1d06093f00		LEAQ 0x3f0906(IP), BX							
  errors.go:65		0x6c2bb2		b901000000		MOVL $0x1, CX								
  errors.go:65		0x6c2bb7		e8e400d6ff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)				
  errors.go:65		0x6c2bbc		48c7400819000000	MOVQ $0x19, 0x8(AX)							
  errors.go:65		0x6c2bc4		488d1540940b00		LEAQ 0xb9440(IP), DX							
  errors.go:65		0x6c2bcb		488910			MOVQ DX, 0(AX)								
  connection.go:2525	0x6c2bce		4889c3			MOVQ AX, BX								
  connection.go:2525	0x6c2bd1		488d05f0d04200		LEAQ 0x42d0f0(IP), AX							
  connection.go:2525	0x6c2bd8		488d942490000000	LEAQ 0x90(SP), DX							
  connection.go:2525	0x6c2be0		440f113a		MOVUPS X15, 0(DX)							
  connection.go:2525	0x6c2be4		440f117a10		MOVUPS X15, 0x10(DX)							
  connection.go:2525	0x6c2be9		440f117a20		MOVUPS X15, 0x20(DX)							
  packet_emission.go:54	0x6c2bee		c68424a000000007	MOVB $0x7, 0xa0(SP)							
  packet_emission.go:54	0x6c2bf6		48898424b0000000	MOVQ AX, 0xb0(SP)							
  packet_emission.go:54	0x6c2bfe		48899c24b8000000	MOVQ BX, 0xb8(SP)							
  connection.go:2525	0x6c2c06		0fb6942490000000	MOVZX 0x90(SP), DX							
  connection.go:2525	0x6c2c0e		4c8b8c2498000000	MOVQ 0x98(SP), R9							
  connection.go:2525	0x6c2c16		0fb68c24a0000000	MOVZX 0xa0(SP), CX							
  connection.go:2525	0x6c2c1e		488bbc24a8000000	MOVQ 0xa8(SP), DI							
  connection.go:2525	0x6c2c26		488bb424b0000000	MOVQ 0xb0(SP), SI							
  connection.go:2525	0x6c2c2e		4c8d542430		LEAQ 0x30(SP), R10							
  connection.go:2525	0x6c2c33		450f113a		MOVUPS X15, 0(R10)							
  connection.go:2525	0x6c2c37		450f117a10		MOVUPS X15, 0x10(R10)							
  connection.go:2525	0x6c2c3c		450f117a20		MOVUPS X15, 0x20(R10)							
  connection.go:2525	0x6c2c41		c644244007		MOVB $0x7, 0x40(SP)							
  connection.go:2525	0x6c2c46		4889442450		MOVQ AX, 0x50(SP)							
  connection.go:2525	0x6c2c4b		48895c2458		MOVQ BX, 0x58(SP)							
  connection.go:2525	0x6c2c50		89d0			MOVL DX, AX								
  connection.go:2525	0x6c2c52		4989d8			MOVQ BX, R8								
  connection.go:2525	0x6c2c55		4c89cb			MOVQ R9, BX								
  connection.go:2525	0x6c2c58		4881c4d0000000		ADDQ $0xd0, SP								
  connection.go:2525	0x6c2c5f		5d			POPQ BP									
  connection.go:2525	0x6c2c60		c3			RET									
  connection.go:2493	0x6c2c61		488b8424e0000000	MOVQ 0xe0(SP), AX							
  connection.go:2493	0x6c2c69		488b9c24e8000000	MOVQ 0xe8(SP), BX							
  connection.go:2493	0x6c2c71		e86a030000		CALL github.com/quic-go/quic-go.(*Conn).emitPackets(SB)			
  connection.go:2493	0x6c2c76		88842490000000		MOVB AL, 0x90(SP)							
  connection.go:2493	0x6c2c7d		48899c2498000000	MOVQ BX, 0x98(SP)							
  connection.go:2493	0x6c2c85		888c24a0000000		MOVB CL, 0xa0(SP)							
  connection.go:2493	0x6c2c8c		4889bc24a8000000	MOVQ DI, 0xa8(SP)							
  connection.go:2493	0x6c2c94		4889b424b0000000	MOVQ SI, 0xb0(SP)							
  connection.go:2493	0x6c2c9c		4c898424b8000000	MOVQ R8, 0xb8(SP)							
  connection.go:2493	0x6c2ca4		0fb6842490000000	MOVZX 0x90(SP), AX							
  connection.go:2493	0x6c2cac		488b9c2498000000	MOVQ 0x98(SP), BX							
  connection.go:2493	0x6c2cb4		0fb68c24a0000000	MOVZX 0xa0(SP), CX							
  connection.go:2493	0x6c2cbc		488bbc24a8000000	MOVQ 0xa8(SP), DI							
  connection.go:2493	0x6c2cc4		488bb424b0000000	MOVQ 0xb0(SP), SI							
  connection.go:2493	0x6c2ccc		4c8b8424b8000000	MOVQ 0xb8(SP), R8							
  connection.go:2493	0x6c2cd4		488d542430		LEAQ 0x30(SP), DX							
  connection.go:2493	0x6c2cd9		4c8d8c2490000000	LEAQ 0x90(SP), R9							
  connection.go:2493	0x6c2ce1		450f1031		MOVUPS 0(R9), X14							
  connection.go:2493	0x6c2ce5		440f1132		MOVUPS X14, 0(DX)							
  connection.go:2493	0x6c2ce9		450f107110		MOVUPS 0x10(R9), X14							
  connection.go:2493	0x6c2cee		440f117210		MOVUPS X14, 0x10(DX)							
  connection.go:2493	0x6c2cf3		450f107120		MOVUPS 0x20(R9), X14							
  connection.go:2493	0x6c2cf8		440f117220		MOVUPS X14, 0x20(DX)							
  connection.go:2493	0x6c2cfd		4881c4d0000000		ADDQ $0xd0, SP								
  connection.go:2493	0x6c2d04		5d			POPQ BP									
  connection.go:2493	0x6c2d05		c3			RET									
  connection.go:2498	0x6c2d06		488b8c24e0000000	MOVQ 0xe0(SP), CX							
  connection.go:2498	0x6c2d0e		488b9140010000		MOVQ 0x140(CX), DX							
  connection.go:2498	0x6c2d15		488b8148010000		MOVQ 0x148(CX), AX							
  connection.go:2498	0x6c2d1c		488b8a90000000		MOVQ 0x90(DX), CX							
  connection.go:2498	0x6c2d23		ffd1			CALL CX									
  time.go:52		0x6c2d25		4885c0			TESTQ AX, AX								
  connection.go:2499	0x6c2d28		7507			JNE 0x6c2d31								
  connection.go:2500	0x6c2d2a		488b05ff2b4300		MOVQ github.com/quic-go/quic-go.deadlineSendImmediately(SB), AX		
  connection.go:2502	0x6c2d31		488b8c24e0000000	MOVQ 0xe0(SP), CX							
  connection.go:2502	0x6c2d39		48898160030000		MOVQ AX, 0x360(CX)							
  connection.go:2506	0x6c2d40		4889c8			MOVQ CX, AX								
  connection.go:2506	0x6c2d43		488b9c24e8000000	MOVQ 0xe8(SP), BX							
  connection.go:2506	0x6c2d4b		e8b0120000		CALL github.com/quic-go/quic-go.(*Conn).maybeSendAckOnlyPacket(SB)	
  connection.go:2506	0x6c2d50		488d8c2490000000	LEAQ 0x90(SP), CX							
  connection.go:2506	0x6c2d58		440f1139		MOVUPS X15, 0(CX)							
  connection.go:2506	0x6c2d5c		440f117910		MOVUPS X15, 0x10(CX)							
  connection.go:2506	0x6c2d61		440f117920		MOVUPS X15, 0x20(CX)							
  packet_emission.go:54	0x6c2d66		c68424a000000007	MOVB $0x7, 0xa0(SP)							
  packet_emission.go:54	0x6c2d6e		48898424b0000000	MOVQ AX, 0xb0(SP)							
  packet_emission.go:54	0x6c2d76		48899c24b8000000	MOVQ BX, 0xb8(SP)							
  connection.go:2506	0x6c2d7e		0fb68c2490000000	MOVZX 0x90(SP), CX							
  connection.go:2506	0x6c2d86		488b942498000000	MOVQ 0x98(SP), DX							
  connection.go:2506	0x6c2d8e		0fb6b424a0000000	MOVZX 0xa0(SP), SI							
  connection.go:2506	0x6c2d96		488bbc24a8000000	MOVQ 0xa8(SP), DI							
  connection.go:2506	0x6c2d9e		4c8b8424b0000000	MOVQ 0xb0(SP), R8							
  connection.go:2506	0x6c2da6		4c8d4c2430		LEAQ 0x30(SP), R9							
  connection.go:2506	0x6c2dab		450f1139		MOVUPS X15, 0(R9)							
  connection.go:2506	0x6c2daf		450f117910		MOVUPS X15, 0x10(R9)							
  connection.go:2506	0x6c2db4		450f117920		MOVUPS X15, 0x20(R9)							
  connection.go:2506	0x6c2db9		c644244007		MOVB $0x7, 0x40(SP)							
  connection.go:2506	0x6c2dbe		4889442450		MOVQ AX, 0x50(SP)							
  connection.go:2506	0x6c2dc3		48895c2458		MOVQ BX, 0x58(SP)							
  connection.go:2506	0x6c2dc8		89c8			MOVL CX, AX								
  connection.go:2506	0x6c2dca		89f1			MOVL SI, CX								
  connection.go:2506	0x6c2dcc		4c89c6			MOVQ R8, SI								
  connection.go:2506	0x6c2dcf		4989d8			MOVQ BX, R8								
  connection.go:2506	0x6c2dd2		4889d3			MOVQ DX, BX								
  connection.go:2506	0x6c2dd5		4881c4d0000000		ADDQ $0xd0, SP								
  connection.go:2506	0x6c2ddc		5d			POPQ BP									
  connection.go:2506	0x6c2ddd		c3			RET									
  connection.go:2514	0x6c2dde		89c3			MOVL AX, BX								
  connection.go:2514	0x6c2de0		488b8c24e8000000	MOVQ 0xe8(SP), CX							
  connection.go:2514	0x6c2de8		488b8424e0000000	MOVQ 0xe0(SP), AX							
  connection.go:2514	0x6c2df0		e8eb150000		CALL github.com/quic-go/quic-go.(*Conn).sendProbePacket(SB)		
  connection.go:2514	0x6c2df5		4885c0			TESTQ AX, AX								
  connection.go:2514	0x6c2df8		0f8533010000		JNE 0x6c2f31								
  connection.go:2517	0x6c2dfe		488b8c24e0000000	MOVQ 0xe0(SP), CX							
  connection.go:2517	0x6c2e06		488b9198000000		MOVQ 0x98(CX), DX							
  connection.go:2517	0x6c2e0d		488b81a0000000		MOVQ 0xa0(CX), AX							
  connection.go:2517	0x6c2e14		488b4a40		MOVQ 0x40(DX), CX							
  connection.go:2517	0x6c2e18		ffd1			CALL CX									
  connection.go:2517	0x6c2e1a		84c0			TESTL AL, AL								
  connection.go:2517	0x6c2e1c		7450			JE 0x6c2e6e								
  connection.go:2885	0x6c2e1e		488b8c24e0000000	MOVQ 0xe0(SP), CX							
  connection.go:2885	0x6c2e26		488b81a0020000		MOVQ 0x2a0(CX), AX							
  connection.go:2518	0x6c2e2d		90			NOPL									
  connection.go:2885	0x6c2e2e		488d5c242f		LEAQ 0x2f(SP), BX							
  connection.go:2885	0x6c2e33		e82878d5ff		CALL runtime.selectnbsend(SB)						
  connection.go:2519	0x6c2e38		488d4c2430		LEAQ 0x30(SP), CX							
  connection.go:2519	0x6c2e3d		440f1139		MOVUPS X15, 0(CX)							
  connection.go:2519	0x6c2e41		440f117910		MOVUPS X15, 0x10(CX)							
  connection.go:2519	0x6c2e46		440f117920		MOVUPS X15, 0x20(CX)							
  connection.go:2519	0x6c2e4b		488b5c2438		MOVQ 0x38(SP), BX							
  connection.go:2519	0x6c2e50		4c8b442458		MOVQ 0x58(SP), R8							
  connection.go:2519	0x6c2e55		c644244007		MOVB $0x7, 0x40(SP)							
  connection.go:2519	0x6c2e5a		31c0			XORL AX, AX								
  connection.go:2519	0x6c2e5c		b907000000		MOVL $0x7, CX								
  connection.go:2519	0x6c2e61		31ff			XORL DI, DI								
  connection.go:2519	0x6c2e63		31f6			XORL SI, SI								
  connection.go:2519	0x6c2e65		4881c4d0000000		ADDQ $0xd0, SP								
  connection.go:2519	0x6c2e6c		5d			POPQ BP									
  connection.go:2519	0x6c2e6d		c3			RET									
  connection.go:2521	0x6c2e6e		488b8424e0000000	MOVQ 0xe0(SP), AX							
  connection.go:2521	0x6c2e76		488b9c24e8000000	MOVQ 0xe8(SP), BX							
  connection.go:2521	0x6c2e7e		6690			NOPW									
  connection.go:2521	0x6c2e80		e83bfbffff		CALL github.com/quic-go/quic-go.(*Conn).triggerSending(SB)		
  connection.go:2521	0x6c2e85		88842490000000		MOVB AL, 0x90(SP)							
  connection.go:2521	0x6c2e8c		48899c2498000000	MOVQ BX, 0x98(SP)							
  connection.go:2521	0x6c2e94		888c24a0000000		MOVB CL, 0xa0(SP)							
  connection.go:2521	0x6c2e9b		4889bc24a8000000	MOVQ DI, 0xa8(SP)							
  connection.go:2521	0x6c2ea3		4889b424b0000000	MOVQ SI, 0xb0(SP)							
  connection.go:2521	0x6c2eab		4c898424b8000000	MOVQ R8, 0xb8(SP)							
  connection.go:2521	0x6c2eb3		488d4c2460		LEAQ 0x60(SP), CX							
  connection.go:2521	0x6c2eb8		488d942490000000	LEAQ 0x90(SP), DX							
  connection.go:2521	0x6c2ec0		440f1032		MOVUPS 0(DX), X14							
  connection.go:2521	0x6c2ec4		440f1131		MOVUPS X14, 0(CX)							
  connection.go:2521	0x6c2ec8		440f107210		MOVUPS 0x10(DX), X14							
  connection.go:2521	0x6c2ecd		440f117110		MOVUPS X14, 0x10(CX)							
  connection.go:2521	0x6c2ed2		440f107220		MOVUPS 0x20(DX), X14							
  connection.go:2521	0x6c2ed7		440f117120		MOVUPS X14, 0x20(CX)							
  connection.go:2522	0x6c2edc		c644246001		MOVB $0x1, 0x60(SP)							
  connection.go:2523	0x6c2ee1		0fb6442460		MOVZX 0x60(SP), AX							
  connection.go:2523	0x6c2ee6		488b5c2468		MOVQ 0x68(SP), BX							
  connection.go:2523	0x6c2eeb		0fb6542470		MOVZX 0x70(SP), DX							
  connection.go:2523	0x6c2ef0		488b7c2478		MOVQ 0x78(SP), DI							
  connection.go:2523	0x6c2ef5		488bb42480000000	MOVQ 0x80(SP), SI							
  connection.go:2523	0x6c2efd		4c8b842488000000	MOVQ 0x88(SP), R8							
  connection.go:2523	0x6c2f05		4c8d4c2430		LEAQ 0x30(SP), R9							
  connection.go:2523	0x6c2f0a		440f1031		MOVUPS 0(CX), X14							
  connection.go:2523	0x6c2f0e		450f1131		MOVUPS X14, 0(R9)							
  connection.go:2523	0x6c2f12		440f107110		MOVUPS 0x10(CX), X14							
  connection.go:2523	0x6c2f17		450f117110		MOVUPS X14, 0x10(R9)							
  connection.go:2523	0x6c2f1c		440f107120		MOVUPS 0x20(CX), X14							
  connection.go:2523	0x6c2f21		450f117120		MOVUPS X14, 0x20(R9)							
  connection.go:2523	0x6c2f26		89d1			MOVL DX, CX								
  connection.go:2523	0x6c2f28		4881c4d0000000		ADDQ $0xd0, SP								
  connection.go:2523	0x6c2f2f		5d			POPQ BP									
  connection.go:2523	0x6c2f30		c3			RET									
  connection.go:2515	0x6c2f31		488d942490000000	LEAQ 0x90(SP), DX							
  connection.go:2515	0x6c2f39		440f113a		MOVUPS X15, 0(DX)							
  connection.go:2515	0x6c2f3d		440f117a10		MOVUPS X15, 0x10(DX)							
  connection.go:2515	0x6c2f42		440f117a20		MOVUPS X15, 0x20(DX)							
  packet_emission.go:54	0x6c2f47		c68424a000000007	MOVB $0x7, 0xa0(SP)							
  packet_emission.go:54	0x6c2f4f		48898424b0000000	MOVQ AX, 0xb0(SP)							
  packet_emission.go:54	0x6c2f57		48899c24b8000000	MOVQ BX, 0xb8(SP)							
  connection.go:2515	0x6c2f5f		0fb6942490000000	MOVZX 0x90(SP), DX							
  connection.go:2515	0x6c2f67		4c8b8c2498000000	MOVQ 0x98(SP), R9							
  connection.go:2515	0x6c2f6f		0fb68c24a0000000	MOVZX 0xa0(SP), CX							
  connection.go:2515	0x6c2f77		488bbc24a8000000	MOVQ 0xa8(SP), DI							
  connection.go:2515	0x6c2f7f		488bb424b0000000	MOVQ 0xb0(SP), SI							
  connection.go:2515	0x6c2f87		4c8d542430		LEAQ 0x30(SP), R10							
  connection.go:2515	0x6c2f8c		450f113a		MOVUPS X15, 0(R10)							
  connection.go:2515	0x6c2f90		450f117a10		MOVUPS X15, 0x10(R10)							
  connection.go:2515	0x6c2f95		450f117a20		MOVUPS X15, 0x20(R10)							
  connection.go:2515	0x6c2f9a		c644244007		MOVB $0x7, 0x40(SP)							
  connection.go:2515	0x6c2f9f		4889442450		MOVQ AX, 0x50(SP)							
  connection.go:2515	0x6c2fa4		48895c2458		MOVQ BX, 0x58(SP)							
  connection.go:2515	0x6c2fa9		89d0			MOVL DX, AX								
  connection.go:2515	0x6c2fab		4989d8			MOVQ BX, R8								
  connection.go:2515	0x6c2fae		4c89cb			MOVQ R9, BX								
  connection.go:2515	0x6c2fb1		4881c4d0000000		ADDQ $0xd0, SP								
  connection.go:2515	0x6c2fb8		5d			POPQ BP									
  connection.go:2515	0x6c2fb9		c3			RET									
  connection.go:2483	0x6c2fba		4889442408		MOVQ AX, 0x8(SP)							
  connection.go:2483	0x6c2fbf		48895c2410		MOVQ BX, 0x10(SP)							
  connection.go:2483	0x6c2fc4		e8979edcff		CALL runtime.morestack_noctxt.abi0(SB)					
  connection.go:2483	0x6c2fc9		488b442408		MOVQ 0x8(SP), AX							
  connection.go:2483	0x6c2fce		488b5c2410		MOVQ 0x10(SP), BX							
  connection.go:2483	0x6c2fd3		e9e8f9ffff		JMP github.com/quic-go/quic-go.(*Conn).triggerSending(SB)		
