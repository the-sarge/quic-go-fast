TEXT github.com/quic-go/quic-go.(*Conn).triggerSending(SB) /Volumes/worktrees/quic-go-fast/e4-r2-linux-candidate/connection.go
  connection.go:2483	0x6c29c0		4c8d642498		LEAQ -0x68(SP), R12							
  connection.go:2483	0x6c29c5		4d3b6610		CMPQ R12, 0x10(R14)							
  connection.go:2483	0x6c29c9		0f8621030000		JBE 0x6c2cf0								
  connection.go:2483	0x6c29cf		55			PUSHQ BP								
  connection.go:2483	0x6c29d0		4889e5			MOVQ SP, BP								
  connection.go:2483	0x6c29d3		4881ece0000000		SUBQ $0xe0, SP								
  connection.go:2485	0x6c29da		48898424f0000000	MOVQ AX, 0xf0(SP)							
  connection.go:2485	0x6c29e2		48899c24f8000000	MOVQ BX, 0xf8(SP)							
  connection.go:2483	0x6c29ea		488d542420		LEAQ 0x20(SP), DX							
  connection.go:2483	0x6c29ef		440f113a		MOVUPS X15, 0(DX)							
  connection.go:2483	0x6c29f3		440f117a10		MOVUPS X15, 0x10(DX)							
  connection.go:2483	0x6c29f8		440f117a20		MOVUPS X15, 0x20(DX)							
  connection.go:2485	0x6c29fd		80b83b03000000		CMPB 0x33b(AX), $0x0							
  connection.go:2485	0x6c2a04		7515			JNE 0x6c2a1b								
  connection.go:2486	0x6c2a06		e8d5fdffff		CALL github.com/quic-go/quic-go.(*Conn).applyHandshakeMTUFallback(SB)	
  connection.go:2488	0x6c2a0b		488b8424f0000000	MOVQ 0xf0(SP), AX							
  connection.go:2489	0x6c2a13		488b9c24f8000000	MOVQ 0xf8(SP), BX							
  connection.go:2488	0x6c2a1b		48c7806003000000000000	MOVQ $0x0, 0x360(AX)							
  connection.go:2489	0x6c2a26		0fb6883b030000		MOVZX 0x33b(AX), CX							
  connection.go:2489	0x6c2a2d		e80ecc0000		CALL github.com/quic-go/quic-go.(*packetEmission).dispatch(SB)		
  connection.go:2489	0x6c2a32		888424b0000000		MOVB AL, 0xb0(SP)							
  connection.go:2489	0x6c2a39		48899c24b8000000	MOVQ BX, 0xb8(SP)							
  connection.go:2489	0x6c2a41		888c24c0000000		MOVB CL, 0xc0(SP)							
  connection.go:2489	0x6c2a48		4889bc24c8000000	MOVQ DI, 0xc8(SP)							
  connection.go:2489	0x6c2a50		4889b424d0000000	MOVQ SI, 0xd0(SP)							
  connection.go:2489	0x6c2a58		4c898424d8000000	MOVQ R8, 0xd8(SP)							
  connection.go:2493	0x6c2a60		0fb69424c0000000	MOVZX 0xc0(SP), DX							
  connection.go:2510	0x6c2a68		488bb424c8000000	MOVQ 0xc8(SP), SI							
  connection.go:2502	0x6c2a70		0fb6bc24b0000000	MOVZX 0xb0(SP), DI							
  connection.go:2502	0x6c2a78		4084ff			TESTL DI, DI								
  connection.go:2490	0x6c2a7b		4883bc24d000000000	CMPQ 0xd0(SP), $0x0							
  connection.go:2489	0x6c2a84		4c8d442450		LEAQ 0x50(SP), R8							
  connection.go:2489	0x6c2a89		4c8d8c24b0000000	LEAQ 0xb0(SP), R9							
  connection.go:2489	0x6c2a91		450f1031		MOVUPS 0(R9), X14							
  connection.go:2489	0x6c2a95		450f1130		MOVUPS X14, 0(R8)							
  connection.go:2489	0x6c2a99		450f107110		MOVUPS 0x10(R9), X14							
  connection.go:2489	0x6c2a9e		450f117010		MOVUPS X14, 0x10(R8)							
  connection.go:2489	0x6c2aa3		450f107120		MOVUPS 0x20(R9), X14							
  connection.go:2489	0x6c2aa8		450f117020		MOVUPS X14, 0x20(R8)							
  connection.go:2490	0x6c2aad		0f85e3010000		JNE 0x6c2c96								
  connection.go:2493	0x6c2ab3		4883fa09		CMPQ DX, $0x9								
  connection.go:2493	0x6c2ab7		0f878e010000		JA 0x6c2c4b								
  connection.go:2502	0x6c2abd		4084ff			TESTL DI, DI								
  connection.go:2493	0x6c2ac0		488d0539b60d00		LEAQ 0xdb639(IP), AX							
  connection.go:2493	0x6c2ac7		ff24d0			JMP 0(AX)(DX*8)								
  connection.go:2502	0x6c2aca		0f847b010000		JE 0x6c2c4b								
  connection.go:2744	0x6c2ad0		488b8c24f0000000	MOVQ 0xf0(SP), CX							
  connection.go:2744	0x6c2ad8		488b81a0020000		MOVQ 0x2a0(CX), AX							
  connection.go:2503	0x6c2adf		90			NOPL									
  connection.go:2744	0x6c2ae0		488d5c241f		LEAQ 0x1f(SP), BX							
  connection.go:2744	0x6c2ae5		e8767bd5ff		CALL runtime.selectnbsend(SB)						
  connection.go:2489	0x6c2aea		4c8d442450		LEAQ 0x50(SP), R8							
  connection.go:2502	0x6c2aef		e957010000		JMP 0x6c2c4b								
  connection.go:2506	0x6c2af4		488b9424f0000000	MOVQ 0xf0(SP), DX							
  connection.go:2506	0x6c2afc		c6823f03000002		MOVB $0x2, 0x33f(DX)							
  connection.go:2506	0x6c2b03		e943010000		JMP 0x6c2c4b								
  connection.go:2510	0x6c2b08		488b9424f0000000	MOVQ 0xf0(SP), DX							
  connection.go:2510	0x6c2b10		4889b260030000		MOVQ SI, 0x360(DX)							
  connection.go:2510	0x6c2b17		e92f010000		JMP 0x6c2c4b								
  connection.go:2508	0x6c2b1c		488b9424f0000000	MOVQ 0xf0(SP), DX							
  connection.go:2508	0x6c2b24		c6823f03000001		MOVB $0x1, 0x33f(DX)							
  connection.go:2508	0x6c2b2b		e91b010000		JMP 0x6c2c4b								
  connection.go:2496	0x6c2b30		488b8424f0000000	MOVQ 0xf0(SP), AX							
  connection.go:2496	0x6c2b38		488b9c24f8000000	MOVQ 0xf8(SP), BX							
  connection.go:2496	0x6c2b40		e8db010000		CALL github.com/quic-go/quic-go.(*Conn).emitPackets(SB)			
  connection.go:2496	0x6c2b45		88842480000000		MOVB AL, 0x80(SP)							
  connection.go:2496	0x6c2b4c		48899c2488000000	MOVQ BX, 0x88(SP)							
  connection.go:2496	0x6c2b54		888c2490000000		MOVB CL, 0x90(SP)							
  connection.go:2496	0x6c2b5b		4889bc2498000000	MOVQ DI, 0x98(SP)							
  connection.go:2496	0x6c2b63		4889b424a0000000	MOVQ SI, 0xa0(SP)							
  connection.go:2496	0x6c2b6b		4c898424a8000000	MOVQ R8, 0xa8(SP)							
  connection.go:2496	0x6c2b73		0fb6842480000000	MOVZX 0x80(SP), AX							
  connection.go:2496	0x6c2b7b		488b9c2488000000	MOVQ 0x88(SP), BX							
  connection.go:2496	0x6c2b83		0fb68c2490000000	MOVZX 0x90(SP), CX							
  connection.go:2496	0x6c2b8b		488bbc2498000000	MOVQ 0x98(SP), DI							
  connection.go:2496	0x6c2b93		488bb424a0000000	MOVQ 0xa0(SP), SI							
  connection.go:2496	0x6c2b9b		4c8b8424a8000000	MOVQ 0xa8(SP), R8							
  connection.go:2496	0x6c2ba3		488d542420		LEAQ 0x20(SP), DX							
  connection.go:2496	0x6c2ba8		4c8d8c2480000000	LEAQ 0x80(SP), R9							
  connection.go:2496	0x6c2bb0		450f1031		MOVUPS 0(R9), X14							
  connection.go:2496	0x6c2bb4		440f1132		MOVUPS X14, 0(DX)							
  connection.go:2496	0x6c2bb8		450f107110		MOVUPS 0x10(R9), X14							
  connection.go:2496	0x6c2bbd		440f117210		MOVUPS X14, 0x10(DX)							
  connection.go:2496	0x6c2bc2		450f107120		MOVUPS 0x20(R9), X14							
  connection.go:2496	0x6c2bc7		440f117220		MOVUPS X14, 0x20(DX)							
  connection.go:2496	0x6c2bcc		4881c4e0000000		ADDQ $0xe0, SP								
  connection.go:2496	0x6c2bd3		5d			POPQ BP									
  connection.go:2496	0x6c2bd4		c3			RET									
  connection.go:2499	0x6c2bd5		488b8424f0000000	MOVQ 0xf0(SP), AX							
  connection.go:2499	0x6c2bdd		488b9c24f8000000	MOVQ 0xf8(SP), BX							
  connection.go:2499	0x6c2be5		e8d6fdffff		CALL github.com/quic-go/quic-go.(*Conn).triggerSending(SB)		
  connection.go:2499	0x6c2bea		88842480000000		MOVB AL, 0x80(SP)							
  connection.go:2499	0x6c2bf1		48899c2488000000	MOVQ BX, 0x88(SP)							
  connection.go:2499	0x6c2bf9		888c2490000000		MOVB CL, 0x90(SP)							
  connection.go:2499	0x6c2c00		4889bc2498000000	MOVQ DI, 0x98(SP)							
  connection.go:2499	0x6c2c08		4889b424a0000000	MOVQ SI, 0xa0(SP)							
  connection.go:2499	0x6c2c10		4c898424a8000000	MOVQ R8, 0xa8(SP)							
  connection.go:2499	0x6c2c18		488d4c2450		LEAQ 0x50(SP), CX							
  connection.go:2499	0x6c2c1d		488d942480000000	LEAQ 0x80(SP), DX							
  connection.go:2499	0x6c2c25		440f1032		MOVUPS 0(DX), X14							
  connection.go:2499	0x6c2c29		440f1131		MOVUPS X14, 0(CX)							
  connection.go:2499	0x6c2c2d		440f107210		MOVUPS 0x10(DX), X14							
  connection.go:2499	0x6c2c32		440f117110		MOVUPS X14, 0x10(CX)							
  connection.go:2499	0x6c2c37		440f107220		MOVUPS 0x20(DX), X14							
  connection.go:2499	0x6c2c3c		440f117120		MOVUPS X14, 0x20(CX)							
  connection.go:2500	0x6c2c41		c644245001		MOVB $0x1, 0x50(SP)							
  connection.go:2489	0x6c2c46		4c8d442450		LEAQ 0x50(SP), R8							
  connection.go:2514	0x6c2c4b		0fb6442450		MOVZX 0x50(SP), AX							
  connection.go:2514	0x6c2c50		488b5c2458		MOVQ 0x58(SP), BX							
  connection.go:2514	0x6c2c55		0fb64c2460		MOVZX 0x60(SP), CX							
  connection.go:2514	0x6c2c5a		488b7c2468		MOVQ 0x68(SP), DI							
  connection.go:2514	0x6c2c5f		488b742470		MOVQ 0x70(SP), SI							
  connection.go:2514	0x6c2c64		488b542478		MOVQ 0x78(SP), DX							
  connection.go:2514	0x6c2c69		4c8d4c2420		LEAQ 0x20(SP), R9							
  connection.go:2514	0x6c2c6e		450f1030		MOVUPS 0(R8), X14							
  connection.go:2514	0x6c2c72		450f1131		MOVUPS X14, 0(R9)							
  connection.go:2514	0x6c2c76		450f107010		MOVUPS 0x10(R8), X14							
  connection.go:2514	0x6c2c7b		450f117110		MOVUPS X14, 0x10(R9)							
  connection.go:2514	0x6c2c80		450f107020		MOVUPS 0x20(R8), X14							
  connection.go:2514	0x6c2c85		450f117120		MOVUPS X14, 0x20(R9)							
  connection.go:2514	0x6c2c8a		4989d0			MOVQ DX, R8								
  connection.go:2514	0x6c2c8d		4881c4e0000000		ADDQ $0xe0, SP								
  connection.go:2514	0x6c2c94		5d			POPQ BP									
  connection.go:2514	0x6c2c95		c3			RET									
  connection.go:2491	0x6c2c96		0fb68424b0000000	MOVZX 0xb0(SP), AX							
  connection.go:2491	0x6c2c9e		488b9c24b8000000	MOVQ 0xb8(SP), BX							
  connection.go:2491	0x6c2ca6		0fb68c24c0000000	MOVZX 0xc0(SP), CX							
  connection.go:2491	0x6c2cae		488bbc24c8000000	MOVQ 0xc8(SP), DI							
  connection.go:2491	0x6c2cb6		488bb424d0000000	MOVQ 0xd0(SP), SI							
  connection.go:2491	0x6c2cbe		4c8b8424d8000000	MOVQ 0xd8(SP), R8							
  connection.go:2491	0x6c2cc6		488d542420		LEAQ 0x20(SP), DX							
  connection.go:2491	0x6c2ccb		450f1031		MOVUPS 0(R9), X14							
  connection.go:2491	0x6c2ccf		440f1132		MOVUPS X14, 0(DX)							
  connection.go:2491	0x6c2cd3		450f107110		MOVUPS 0x10(R9), X14							
  connection.go:2491	0x6c2cd8		440f117210		MOVUPS X14, 0x10(DX)							
  connection.go:2491	0x6c2cdd		450f107120		MOVUPS 0x20(R9), X14							
  connection.go:2491	0x6c2ce2		440f117220		MOVUPS X14, 0x20(DX)							
  connection.go:2491	0x6c2ce7		4881c4e0000000		ADDQ $0xe0, SP								
  connection.go:2491	0x6c2cee		5d			POPQ BP									
  connection.go:2491	0x6c2cef		c3			RET									
  connection.go:2483	0x6c2cf0		4889442408		MOVQ AX, 0x8(SP)							
  connection.go:2483	0x6c2cf5		48895c2410		MOVQ BX, 0x10(SP)							
  connection.go:2483	0x6c2cfa		e861a1dcff		CALL runtime.morestack_noctxt.abi0(SB)					
  connection.go:2483	0x6c2cff		488b442408		MOVQ 0x8(SP), AX							
  connection.go:2483	0x6c2d04		488b5c2410		MOVQ 0x10(SP), BX							
  connection.go:2483	0x6c2d09		e9b2fcffff		JMP github.com/quic-go/quic-go.(*Conn).triggerSending(SB)		
