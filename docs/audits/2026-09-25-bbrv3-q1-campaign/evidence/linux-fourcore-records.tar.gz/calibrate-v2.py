import concurrent.futures,json,pathlib,shlex,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
BASE=['gcloud','compute','ssh','--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet','--ssh-flag=-oControlMaster=auto','--ssh-flag=-oControlPath=/tmp/q1-mux-%C','--ssh-flag=-oControlPersist=30m']
def ssh(host,cmd,name,timeout=420,required=True):
 r=subprocess.run(BASE+[host,'--command='+cmd,'--ssh-flag=-oConnectTimeout=15'],capture_output=True,text=True,timeout=timeout)
 (ROOT/(name+'.txt')).write_text(r.stdout+'\nSTDERR:\n'+r.stderr)
 print(name,r.returncode,flush=True)
 if r.returncode and required:raise RuntimeError(name)
 return r.stdout,r.returncode
cases={
 'S3-reverse':('S3',210,1200000000,'send',False),
 'S2-reverse':('S2',10,150000000,'send',False),
 'S8-reverse':('S8',10,150000000,'send',True),
 'L3-reverse':('L3',300,180000000,'send',False),
 'L4-ping':('L4',10,0,'ping',False),
 'L5-rate':('L5',15,384000,'send',False),
 'S3-ping':('S3',10,0,'ping',False),
 'S3-rate':('S3',10,1200000000,'send',False),
 'S3-sustain':('S3',210,1200000000,'send',False),
 'S2-rate':('S2',10,30000000,'send',False),
 'S8-ect':('S8',10,150000000,'send',True),
 'S8-noect':('S8',10,150000000,'send',False),
 'S7-depth':('S7',10,150000000,'send',False),
 'S6-loss':('S6',10,90000000,'send',False),
 'L1-delay':('L1',18,10000000,'send',False),
 'L2-drop':('L2',18,10000000,'send',False),
 'L3-phases':('L3',300,30000000,'send',False),
}
selected=sys.argv[1:] or ['S3-ping','S3-rate']
if any(x not in cases for x in selected):raise SystemExit('unknown finite case')
ssh('bbr-gateway','sudo ethtool -K ens4 gro off lro off gso off tso off rx-gro-hw off; sudo ethtool -K ens5 gro off lro off gso off tso off rx-gro-hw off; sudo sysctl -w net.ipv4.ip_forward=0; ip -s link; chronyc tracking || timedatectl timesync-status','model-preflight-gc400-v2-'+selected[0])
try:
 for case in selected:
  name="gc400-v2-"+case
  scenario,seconds,rate,role,ect=cases[case]
  start=time.time_ns()+20_000_000_000
  c=dict(A=dict(Interface='ens4',PeerMAC='42:01:0a:3f:01:01',Focal='10.63.1.10'),B=dict(Interface='ens5',PeerMAC='42:01:0a:3f:02:01',Focal='10.63.2.10'),Scenario=scenario,StartUnixNS=start,MeasureSeconds=seconds,Phase=0,Seed=17)
  (ROOT/(name+'-config.json')).write_text(json.dumps(c,indent=2)+'\n')
  prefix='cd /tmp/q1-final && '
  router=prefix+'printf %s '+shlex.quote(json.dumps(c))+' > '+name+'.json && sudo env GOGC=400 GOMEMLIMIT=4GiB GODEBUG=gctrace=1 /usr/bin/time -v timeout --signal=TERM --kill-after=5 '+str(seconds+45)+' ./q1router-v2 -config '+name+'.json -output '+name+'-router.json; result=$?; sudo cat /tmp/q1-final/'+name+'-router.json; exit $result'
  common=' -start '+str(start)+' -seconds '+str(seconds)
  receiver='echo' if role=='ping' else 'receive'
  sendhost,receivehost="bbr-a","bbr-b"
  sendip,receiveip="10.63.1.10","10.63.2.10"
  if case.endswith("-reverse"): sendhost,receivehost=receivehost,sendhost;sendip,receiveip=receiveip,sendip
  b=prefix+'chmod 700 q1probe && ./q1probe -role '+receiver+' -local '+receiveip+':4555'+common+' -output '+name+'-receive.json; result=$?; cat /tmp/q1-final/'+name+'-receive.json; exit $result'
  a=prefix+'chmod 700 q1probe && ./q1probe -role '+role+' -local '+sendip+':4555 -peer '+receiveip+':4555 -rate '+str(rate)+common+(' -ect' if ect else '')+' -output '+name+'-send.json; result=$?; cat /tmp/q1-final/'+name+'-send.json; exit $result'
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   jobs=[(host,kind,pool.submit(ssh,host,cmd,name+'-'+kind,seconds+80,False)) for host,kind,cmd in [('bbr-gateway','router',router),(receivehost,'receive',b),(sendhost,'send',a)]]
   failed=[]
   for host,kind,job in jobs:
    text,rc=job.result()
    try:
     data=json.loads(text);(ROOT/(name+'-'+kind+'.json')).write_text(json.dumps(data,indent=2)+'\n')
    except ValueError:failed.append(kind+' missing JSON');continue
    if rc:failed.append(kind+' rc='+str(rc))
  if failed: raise RuntimeError(name+': '+', '.join(failed))
finally:
 ssh('bbr-gateway','sudo sysctl -w net.ipv4.ip_forward=1; ip -s link','model-restored-gc400-v2-'+selected[0],required=False)
