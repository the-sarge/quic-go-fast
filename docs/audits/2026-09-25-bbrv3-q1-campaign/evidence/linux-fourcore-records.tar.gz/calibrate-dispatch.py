import json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
replacement={'L3-phases':'S3-sustain','L3-reverse':'S3-reverse'}
case=sys.argv[1]
if case in replacement:
 (root/('reassigned-'+case+'.json')).write_text(json.dumps({'original_case':case,'disposition':'unmeasured on four-core profile; diagnostic slot within same immutable lease','diagnostic':'one-P V3 short check followed separately by four-P V2 sustained check; unchanged model, GOGC400 and memory limit','replacement':replacement[case]},indent=2)+'\n')
 if case=='L3-phases':
  rc=subprocess.call([sys.executable,str(root/'calibrate-onep.py'),'S3-rate'])
  (root/'onep-short-driver-outcome.json').write_text(json.dumps({'return_code':rc,'qualification':False})+'\n')
 script,args='calibrate-v2.py',[replacement[case]]
else:script,args='calibrate-fourp.py',sys.argv[1:]
raise SystemExit(subprocess.call([sys.executable,str(root/script),*args]))
