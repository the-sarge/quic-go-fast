import base64,concurrent.futures,json,pathlib,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parent
BASE=['gcloud','compute','ssh','--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet','--ssh-flag=-oControlMaster=auto','--ssh-flag=-oControlPath=/tmp/q1-mux-%C','--ssh-flag=-oControlPersist=30m']
def ssh(host,command,name,timeout=180):
 r=subprocess.run(BASE+[host,'--command='+command,'--ssh-flag=-oConnectTimeout=15'],capture_output=True,text=True,timeout=timeout)
 (ROOT/(name+'.txt')).write_text(r.stdout+'\nSTDERR:\n'+r.stderr)
 print(name,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(name)
 return r.stdout

def ps(host,script,name,timeout=180):
 return ssh(host,'powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(script.encode('utf-16le')).decode(),name,timeout)

facts=r'''$ErrorActionPreference='Stop'
if (-not (Test-Path C:\bbr\cpu.json)) { throw 'startup not complete' }
New-Item -ItemType Directory -Force C:\bbr\q1 | Out-Null
Get-Content C:\bbr\os.json,C:\bbr\cpu.json
Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json
Get-NetAdapter | Format-List Name,InterfaceDescription,Status,LinkSpeed,DriverInformation
Get-NetAdapterAdvancedProperty | Format-Table -AutoSize
Get-NetRoute -AddressFamily IPv4 | Format-Table -AutoSize
w32tm /query /status
Get-Date -Format o
'''
startup_deadline=time.monotonic()+12*60
def prepare_endpoint(host):
 for attempt in range(30):
  try:
   remaining=startup_deadline-time.monotonic()
   if remaining<1:raise TimeoutError('Windows startup deadline')
   ps(host,facts,host+'-facts-'+str(attempt),timeout=min(60,remaining));break
  except (RuntimeError,subprocess.TimeoutExpired):
   if attempt==29:raise
   time.sleep(15)
 args=['gcloud','compute','scp','--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet',str(ROOT/'stage'/'fixture.zip'),host+':C:/bbr/q1/fixture.zip']
 r=subprocess.run(args,capture_output=True,text=True,timeout=180)
 (ROOT/(host+'-fixture-stage.txt')).write_text(r.stdout+'\n'+r.stderr)
 if r.returncode:raise RuntimeError(host+' staging')
 ps(host,r"Expand-Archive -Force C:\bbr\q1\fixture.zip C:\bbr\q1",host+'-extract')
 ps(host,r"Get-FileHash -Algorithm SHA256 C:\bbr\q1\q1fixture.exe,C:\bbr\q1\q1probe.exe | Select-Object Hash | ConvertTo-Json",host+'-binary-hash')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 list(pool.map(prepare_endpoint,['bbr-a','bbr-b']))
ssh('bbr-gateway','mkdir -p /tmp/q1-windows; uname -a; lscpu; ip -j addr; ip -j route; ping -c 1 -W 2 10.63.1.1 >/dev/null; ping -c 1 -W 2 10.63.2.1 >/dev/null; ip -j neigh; chronyc tracking','gateway-facts')
subprocess.run(['gcloud','compute','scp','--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet','--scp-flag=-O','--scp-flag=-oControlMaster=no','--scp-flag=-oControlPath=none',str(ROOT/'stage'/'q1router'),'bbr-gateway:/tmp/q1-windows/q1router'],check=True,timeout=120)

ssh('bbr-gateway','chmod 700 /tmp/q1-windows/q1router && sha256sum /tmp/q1-windows/q1router','gateway-hash')
