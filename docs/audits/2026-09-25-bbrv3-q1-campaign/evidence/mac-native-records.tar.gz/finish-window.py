import json,pathlib,subprocess,time
root=pathlib.Path(__file__).resolve().parent
end=1790378040
p=root/'mac-L3-reverse-outcomes.json'
while not p.exists():
 if time.time()>end:raise SystemExit('Prior case did not finish inside network window')
 time.sleep(1)
for script,args,name,bound in [('calibrate6.py',['S3-reverse'],'calibrate6-reverse',280),('modeled-fixtures.py',[],'modeled-fixtures',1100)]:
 with (root/(name+'.txt')).open('w') as output:
  r=subprocess.run(['python3',str(root/script),*args],stdout=output,stderr=subprocess.STDOUT,timeout=bound)
 print(name,r.returncode,flush=True)
 # These are independent preparation diagnostics; preserve failures rather
 # than suppressing the remaining native fixture evidence.
