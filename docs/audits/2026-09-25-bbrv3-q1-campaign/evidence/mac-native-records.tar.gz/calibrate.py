import concurrent.futures,json,pathlib,shlex,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
remote='/tmp/q1-mac-20260925'
ns='q1-mac-20260925'
def run(host,cmd,name,bound):
 r=subprocess.run(['ssh','-o','ConnectTimeout=10',host,cmd],capture_output=True,text=True,timeout=bound)
 (root/(name+'.txt')).write_text(r.stdout+'\nSTDERR:\n'+r.stderr)
 print(name,r.returncode,flush=True)
 try:(root/(name+'.json')).write_text(json.dumps(json.loads(r.stdout),indent=2)+'\n')
 except ValueError:pass
 return r.returncode
cases={'S3-ping':('S3',10,0,'ping',False),'S3-short':('S3',10,1200000000,'send',True),'S3-forward':('S3',210,1200000000,'send',True),'S3-reverse':('S3',210,1200000000,'send',True),'L3-forward':('L3',300,30000000,'send',True),'L3-reverse':('L3',300,180000000,'send',True)}
for case in sys.argv[1:]:
 scenario,seconds,rate,role,ect=cases[case]
 name='mac-'+case
 start=time.time_ns()+10_000_000_000
 config=dict(A=dict(Interface='q1a',PeerMAC='02:63:65:01:00:01',Focal='10.64.1.10'),B=dict(Interface='q1b',PeerMAC='02:63:65:02:00:01',Focal='10.64.2.10'),Scenario=scenario,StartUnixNS=start,MeasureSeconds=seconds,Phase=0,Seed=17)
 (root/(name+'-config.json')).write_text(json.dumps(config,indent=2)+'\n')
 for host in ('m4mini-eth','mbp128'):
  run(host,'netstat -s -p udp; top -l 2 -s 1 -n 5 -o cpu -stats pid,command,cpu',name+'-'+host+'-before',10)
 router='printf %s '+shlex.quote(json.dumps(config))+' > /tmp/'+name+'-config.json && sudo ip netns exec '+ns+' sysctl -w net.ipv4.ip_forward=0 >/dev/null && sudo ip netns exec '+ns+' env GOGC=400 GOMEMLIMIT=4GiB taskset -c 0-3 /usr/bin/time -v timeout --signal=TERM --kill-after=5 '+str(seconds+40)+' /tmp/q1router-tail -config /tmp/'+name+'-config.json -output /tmp/'+name+'-router.json; rc=$?; sudo cat /tmp/'+name+'-router.json; exit $rc'
 sendhost,receivehost='m4mini-eth','mbp128';sendip,receiveip='10.64.1.10','10.64.2.10'
 if case.endswith('reverse'):sendhost,receivehost=receivehost,sendhost;sendip,receiveip=receiveip,sendip
 common=' -start '+str(start)+' -seconds '+str(seconds)
 prefix='cd '+remote+' && ./q1probe '
 recv=prefix+'-role '+('echo' if role=='ping' else 'receive')+' -local '+receiveip+':24400'+common+' -output '+name+'-receive.json; rc=$?; cat '+name+'-receive.json; exit $rc'
 send=prefix+'-role '+role+' -local '+sendip+':24400 -peer '+receiveip+':24400 -rate '+str(rate)+common+(' -ect' if ect else '')+' -output '+name+'-send.json; rc=$?; cat '+name+'-send.json; exit $rc'
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  jobs=[pool.submit(run,host,cmd,name+'-'+kind,seconds+55) for host,cmd,kind in [('minimax',router,'router'),(receivehost,recv,'receive'),(sendhost,send,'send')]]
  outcomes=[job.result() for job in jobs]
 for host in ('m4mini-eth','mbp128'):run(host,'netstat -s -p udp; top -l 2 -s 1 -n 5 -o cpu -stats pid,command,cpu',name+'-'+host+'-after',10)
 (root/(name+'-outcomes.json')).write_text(json.dumps(outcomes)+'\n')
 if any(outcomes):raise SystemExit('Mac calibration failed; retain all observations')
