import concurrent.futures,json,pathlib,shlex,subprocess,time
root=pathlib.Path(__file__).resolve().parent
remote='/tmp/q1-mac-20260925'; ns='q1-mac-20260925'
def run(host,cmd,name,bound):
 r=subprocess.run(['ssh','-o','ConnectTimeout=10',host,cmd],capture_output=True,text=True,timeout=bound)
 (root/(name+'.txt')).write_text(r.stdout+'\nSTDERR:\n'+r.stderr);print(name,r.returncode,flush=True)
 try:(root/(name+'.json')).write_text(json.dumps(json.loads(r.stdout),indent=2)+'\n')
 except ValueError:pass
 return r.returncode
cases=[('S3','reno','stream'),('S3','reno','datagram'),('S3','bbrv3','stream'),('S3','bbrv3','datagram'),('L3','reno','stream'),('completion-S3','bbrv3','stream')]
for index,(scenario,controller,workload) in enumerate(cases):
 if time.time()>1790378040:raise SystemExit('Stop before Mac network-expiry cleanup margin')
 name='mac-modeled-'+scenario+'-'+controller+'-'+workload
 completion=scenario.startswith('completion-'); model='S3' if completion else scenario
 warm,measure=(60000,300000) if model=='L3' else (0,60000) if completion else (1000,10000)
 start=time.time_ns()+10_000_000_000
 cfg=dict(id=name,controller=controller,workload=workload,start_unix_ns=start,warmup_ms=warm,measure_ms=measure,payload_bytes=16384 if workload=='stream' else 1200)
 if completion:cfg['completion_bytes']=16<<20
 routercfg=dict(A=dict(Interface='q1a',PeerMAC='02:63:65:01:00:01',Focal='10.64.1.10'),B=dict(Interface='q1b',PeerMAC='02:63:65:02:00:01',Focal='10.64.2.10'),Scenario=model,StartUnixNS=start+warm*1000000,MeasureSeconds=measure//1000,Phase=0,Seed=17)
 bound=(warm+measure)//1000+50
 # Reject before launching if this case cannot finish before the one-hour route expiry.
 if (start+(warm+measure)*1000000)/1e9+30>1790378460:raise SystemExit('Case would cross Mac network cleanup margin')
 for label,obj in [('config',cfg),('router-config',routercfg)]: (root/(name+'-'+label+'.json')).write_text(json.dumps(obj,indent=2)+'\n')
 router='printf %s '+shlex.quote(json.dumps(routercfg))+' > /tmp/'+name+'-router-config.json && sudo ip netns exec '+ns+' sysctl -w net.ipv4.ip_forward=0 >/dev/null && sudo ip netns exec '+ns+' env GOGC=400 GOMEMLIMIT=4GiB taskset -c 0-3 timeout --signal=TERM --kill-after=5 '+str(bound)+' /tmp/q1router-tail -config /tmp/'+name+'-router-config.json -output /tmp/'+name+'-router.json; rc=$?; sudo cat /tmp/'+name+'-router.json; exit $rc'
 prefix='cd '+remote+' && printf %s '+shlex.quote(json.dumps(cfg))+' > '+name+'-config.json && ./q1fixture -config '+name+'-config.json '
 port=24500+8*index
 receive=prefix+'-role receive -local 10.64.2.10:'+str(port)+' -output '+name+'-receive.json 2>'+name+'-receive.err; rc=$?; cat '+name+'-receive.json; cat '+name+'-receive.err >&2; exit $rc'
 send=prefix+'-role send -local 10.64.1.10:'+str(port)+' -peer 10.64.2.10:'+str(port)+' -output '+name+'-send.json 2>'+name+'-send.err; rc=$?; cat '+name+'-send.json; cat '+name+'-send.err >&2; exit $rc'
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
  cpu_jobs=[pool.submit(run,host,'iostat -C -w 1 -c '+str((warm+measure)//1000+31),name+'-'+host+'-cpu',bound+10) for host in ('m4mini-eth','mbp128')]
  router_job=pool.submit(run,'minimax',router,name+'-router',bound+10)
  receiver=pool.submit(run,'mbp128',receive,name+'-receive',bound+10)
  time.sleep(.5)
  sender=pool.submit(run,'m4mini-eth',send,name+'-send',bound+10)
  outcomes=[router_job.result(),receiver.result(),sender.result()]+[job.result() for job in cpu_jobs]
 (root/(name+'-outcomes.json')).write_text(json.dumps(outcomes)+'\n')
 if any(outcomes):raise SystemExit('Modeled native fixture failure; retain receipts')
