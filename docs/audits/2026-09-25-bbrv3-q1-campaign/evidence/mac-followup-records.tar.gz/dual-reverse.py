import concurrent.futures,json,pathlib,re,shlex,subprocess,time
root=pathlib.Path(__file__).resolve().parent
name='mac-dual-S3-reverse';remote='/tmp/q1-mac-20260925';seconds=210
# Call only inside a fresh approved Mac network/idle window. Every process is finite.
def run(host,cmd,label,bound):
 r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,cmd],capture_output=True,text=True,timeout=bound)
 (root/(label+'.txt')).write_text(r.stdout+'\nSTDERR:\n'+r.stderr)
 print(label,r.returncode,flush=True)
 try:(root/(label+'.json')).write_text(json.dumps(json.loads(r.stdout),indent=2)+'\n')
 except ValueError:pass
 return r.returncode
for host,interface,address in [('m4mini-eth','bridge0','10.64.1.10'),('mbp128','en8','10.64.2.10')]:
 if run(host,'ifconfig '+interface+' | grep -F '+shlex.quote('inet '+address+' '),name+'-'+host+'-address',10):raise SystemExit('Fresh temporary address required')
 run(host,'netstat -s -p udp',name+'-'+host+'-before',10)
start=time.time_ns()+15_000_000_000
config=dict(A=dict(Interface='q1a',PeerMAC='02:63:65:01:00:01',Focal='10.64.1.10'),B=dict(Interface='q1b',PeerMAC='02:63:65:02:00:01',Focal='10.64.2.10'),Scenario='S3',StartUnixNS=start,MeasureSeconds=seconds,Phase=0,Seed=17)
(root/(name+'-config.json')).write_text(json.dumps(config,indent=2)+'\n')
router='printf %s '+shlex.quote(json.dumps(config))+' > /tmp/'+name+'-config.json && sudo ip netns exec q1-mac-20260925 env GOGC=400 GOMEMLIMIT=4GiB taskset -c 0-3 timeout --signal=TERM --kill-after=5 250 /tmp/q1router-tail -config /tmp/'+name+'-config.json -output /tmp/'+name+'-router.json; rc=$?; sudo cat /tmp/'+name+'-router.json; exit $rc'
commands=[('minimax','router',router)]
for flow in (0,1):
 port=24600+flow
 for role,host,ip in [('receive','m4mini-eth','10.64.1.10'),('send','mbp128','10.64.2.10')]:
  label=role+'-'+str(flow);out=name+'-'+label+'.json'
  cmd='cd '+remote+' && ./q1probe-dual -processors 2 -role '+role+' -local '+ip+':'+str(port)+' -start '+str(start)+' -seconds 210 -ect -output '+out
  if role=='send':cmd+=' -peer 10.64.1.10:'+str(port)+' -rate 600000000'
  cmd+='; rc=$?; cat '+out+'; exit $rc';commands.append((host,label,cmd))
with concurrent.futures.ThreadPoolExecutor(max_workers=7) as pool:
 jobs={label:pool.submit(run,host,cmd,name+'-'+label,270) for host,label,cmd in commands}
 for host in ('m4mini-eth','mbp128'):jobs[host+'-cpu']=pool.submit(run,host,'iostat -C -w 1 -c 245',name+'-'+host+'-cpu',260)
 outcomes={label:job.result() for label,job in jobs.items()}
for host in ('m4mini-eth','mbp128'):run(host,'netstat -s -p udp',name+'-'+host+'-after',10)
(root/(name+'-outcomes.json')).write_text(json.dumps(outcomes,indent=2)+'\n')
if any(outcomes.values()):raise SystemExit('One or more probe/router roles failed; retain records')
gateway=json.loads((root/(name+'-router.json')).read_text());receivers=[json.loads((root/(name+'-receive-'+str(i)+'.json')).read_text()) for i in (0,1)]
obs=next(o for o in gateway['Observations'] if o['Direction']=='q1b->q1a')
summary={'delivered':obs['Stats']['Delivered'],'received':sum(r['Received'] for r in receivers),'host_counters':{}}
for host in ('m4mini-eth','mbp128'):
 vals=[int(re.search(r'(\d+) dropped due to full socket buffers',(root/(name+'-'+host+'-'+when+'.txt')).read_text())[1]) for when in ('before','after')]
 summary['host_counters'][host]=dict(before=vals[0],after=vals[1],no_growth=vals[0]==vals[1])
rates=[sum(r['IPBytesPerSecond'][i] for r in receivers) for i in range(seconds)]
summary['steady_ip_mbps_excluding_first_second']=sum(rates[1:])*8/1e6/(seconds-1)
summary['pass']=summary['delivered']==summary['received'] and all(v['no_growth'] for v in summary['host_counters'].values()) and all(not r['Error'] and not r['Invalid'] and not r['Duplicate'] for r in receivers)
(root/(name+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
if not summary['pass']:raise SystemExit('Reverse capacity calibration invalid')
