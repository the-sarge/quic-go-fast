#!/bin/bash
# Q1-only namespaces. Shared physical parent interfaces are never reconfigured.
set -euo pipefail
base=q1-mac-20260925
names=("$base" "$base-a" "$base-b")
case "${1:-}" in
 up)
  for ns in "${names[@]}"; do
   if ip netns list | grep -q "^$ns\b"; then echo "Namespace exists: $ns" >&2; exit 1; fi
  done
  for nic in q1a q1b edge-a edge-b uplink-a uplink-b; do
   if ip link show "$nic" >/dev/null 2>&1; then echo "Interface exists: $nic" >&2; exit 1; fi
  done
  made=()
  trap 'for ns in "${made[@]}"; do ip netns delete "$ns" || true; done' ERR
  for ns in "${names[@]}"; do ip netns add "$ns"; made+=("$ns"); ip -n "$ns" link set lo up; done
  for side in a b; do
   if [ "$side" = a ]; then n=1; parent=thunderbolt0; else n=2; parent=enp97s0; fi
   access="$base-$side"
   ip link add "uplink-$side" link "$parent" address "02:63:64:0$n:00:01" type macvlan mode bridge
   ip link set "uplink-$side" netns "$access"
   ip -n "$access" link set "uplink-$side" mtu 1460 up
   ip -n "$access" addr add "10.64.$n.1/24" dev "uplink-$side"
   ip link add "q1$side" address "02:63:65:0$n:00:02" type veth peer name "edge-$side" address "02:63:65:0$n:00:01"
   ip link set "q1$side" netns "$base"
   ip link set "edge-$side" netns "$access"
   ip -n "$base" link set "q1$side" mtu 1460 up
   ip -n "$access" link set "edge-$side" mtu 1460 up
   ip -n "$base" addr add "10.65.$n.2/30" dev "q1$side"
   ip -n "$access" addr add "10.65.$n.1/30" dev "edge-$side"
   ip -n "$base" route add "10.64.$n.0/24" via "10.65.$n.1"
   ip -n "$access" route add default via "10.65.$n.2"
   ip netns exec "$access" sysctl -w net.ipv4.ip_forward=1
   ip netns exec "$base" ethtool -K "q1$side" gro off lro off gso off tso off
   ip netns exec "$access" ethtool -K "edge-$side" gro off lro off gso off tso off
   ip netns exec "$base" ethtool -k "q1$side"
  done
  ip netns exec "$base" sysctl -w net.ipv4.ip_forward=0
  trap - ERR
  ;;
 down)
  for ns in "${names[@]}"; do
   if [ -n "$(ip netns pids "$ns")" ]; then echo "Stop processes in $ns first" >&2; exit 1; fi
  done
  for ns in "${names[@]}"; do ip netns delete "$ns"; done
  ;;
 *) echo 'usage: gateway-network.sh up|down' >&2; exit 2 ;;
esac
