import datetime,json,os,pathlib,signal,subprocess
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[3]
receipt=ROOT.parent/'bbr-q635-20260925/launch.json'
launch=json.loads(receipt.read_text());expiry=datetime.datetime.fromisoformat(launch['expires_at'])
assert (expiry-datetime.datetime.now(datetime.timezone.utc)).total_seconds()>900
outcomes={'original_prepare':'failed waiting for stdin EOF before measurement','same_immutable_expiry':launch['expires_at'],'paused_original_driver':6922}
def run(args,name,bound):
 with (ROOT/(name+'.txt')).open('w') as f:
  p=subprocess.Popen(args,cwd=REPO,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=bound)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc=124
 outcomes[name]=rc
 (ROOT/'staging-recovery-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
 print(name,rc,flush=True)
 if rc:raise RuntimeError(name)
try:
 run(['python3',str(ROOT/'prepare-fixed-count.py')],'prepare-recovery',180)
 run(['python3',str(ROOT/'validate-and-destroy.py')],'validation-and-cleanup',600)
finally:
 try:
  if json.loads(receipt.read_text())['status']!='destroyed':
   run(['python3','scripts/cloud/bbr-campaign/campaign.py','destroy','--config',str(ROOT/'request.json')],'recovery-fallback-destroy',300)
 finally:
  cmd=subprocess.run(['ps','-p','6922','-o','command='],capture_output=True,text=True).stdout.strip()
  if cmd.endswith('.local/cloud/bbr-campaign/q1-review-windows-retry/run-all.py'):
   os.kill(6922,signal.SIGCONT);outcomes['original_driver_resumed']=True
  (ROOT/'staging-recovery-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
