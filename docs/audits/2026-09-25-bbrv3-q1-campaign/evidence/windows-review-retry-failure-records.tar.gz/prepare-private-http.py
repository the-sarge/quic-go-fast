import base64,hashlib,json,pathlib,shlex,subprocess,tarfile,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
BASE=['gcloud','compute','ssh','--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet','--ssh-flag=-oControlMaster=auto','--ssh-flag=-oControlPath=/tmp/q1-mux-%C','--ssh-flag=-oControlPersist=30m','--ssh-flag=-oConnectTimeout=15']
def ssh(host,cmd,label,bound=60,secret=False):
 try:r=subprocess.run(BASE+[host,'--command='+cmd],capture_output=True,text=True,timeout=bound)
 except subprocess.TimeoutExpired:
  (ROOT/('http-'+label+'.txt')).write_text('command timed out; command/input omitted\n');raise RuntimeError(label+' timeout') from None
 (ROOT/('http-'+label+'.txt')).write_text(('secret staging output omitted; returncode='+str(r.returncode)) if secret else r.stdout+'\nSTDERR:\n'+r.stderr)
 print(label,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(label)
 return r.stdout
def ps(host,script,label,bound=60,secret=False):
 cmd='powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(script.encode('utf-16le')).decode()
 return ssh(host,cmd,label,bound,secret)
archive=ROOT/'stage/fixture-public.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:z.write(ROOT/'stage/q1fixture.exe','q1fixture.exe')
expected=hashlib.sha256(archive.read_bytes()).hexdigest()
bundle=ROOT/'stage/http-transfer.tar.gz'
with tarfile.open(bundle,'w:gz') as t:
 t.add(archive,arcname='fixture-public.zip');t.add(ROOT/'stage/q1router-submit',arcname='q1router')
ssh('bbr-gateway','mkdir -p /tmp/q1-windows /tmp/q1-transfer-public; uname -a; lscpu; ip -j addr; ip -j route; ping -c 1 -W 2 10.63.1.1 >/dev/null; ping -c 1 -W 2 10.63.2.1 >/dev/null; ip -j neigh; chronyc tracking','gateway-facts')
with bundle.open('rb') as source:
 p=subprocess.run(BASE+['bbr-gateway','--command=cat > /tmp/q1-windows/http-transfer.tar.gz','--ssh-flag=-T'],stdin=source,capture_output=True,timeout=90)
(ROOT/'http-gateway-transfer.txt').write_bytes(p.stdout+b'\nSTDERR:\n'+p.stderr)
if p.returncode:raise RuntimeError('gateway bundle transfer')
expected_bundle=hashlib.sha256(bundle.read_bytes()).hexdigest()
ssh('bbr-gateway',"cd /tmp/q1-windows && printf '%s  http-transfer.tar.gz\\n' "+expected_bundle+" | sha256sum -c - && tar -xzf http-transfer.tar.gz && chmod 700 q1router && printf '%s  q1router\\n' 5f541e4738398f8ec0bf7a9500d3e77fc1bc0ac0a8ae44687a4f731189c6f9dc | sha256sum -c - && cp fixture-public.zip /tmp/q1-transfer-public/",'gateway-hash')
try:
 ssh('bbr-gateway',"nohup python3 -m http.server 8080 --bind 0.0.0.0 --directory /tmp/q1-transfer-public > /tmp/q1-transfer-public/server.log 2>&1 < /dev/null & echo $! > /tmp/q1-transfer-public/server.pid",'server-start')
 for host,ip in (('bbr-a','10.63.1.2'),('bbr-b','10.63.2.2')):
  script=r"$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing -Uri 'http://"+ip+r":8080/fixture-public.zip' -OutFile C:\bbr\q1\fixture-public.zip -TimeoutSec60; Get-FileHash -Algorithm SHA256 C:\bbr\q1\fixture-public.zip | Select-Object Hash | ConvertTo-Json"
  got=json.loads(ps(host,script,host+'-archive-hash',75))['Hash'].lower()
  if got!=expected:raise RuntimeError('public archive hash mismatch')
  ps(host,r"Expand-Archive -Force C:\bbr\q1\fixture-public.zip C:\bbr\q1",host+'-extract')
  # Only public binary bytes use HTTP inside the dedicated private test VPC.
  # Small ephemeral TLS files use encrypted SSH; never log their command/output.
  for name in ('campaign.pem','campaign-key.pem'):
   content=base64.b64encode((ROOT/'stage'/name).read_bytes()).decode()
   script="[IO.File]::WriteAllBytes('C:/bbr/q1/"+name+"',[Convert]::FromBase64String('"+content+"'))"
   ps(host,script,host+'-'+name+'-stage',secret=True)
  got=json.loads(ps(host,r"Get-FileHash -Algorithm SHA256 C:\bbr\q1\q1fixture.exe | Select-Object Hash | ConvertTo-Json",host+'-binary-hash'))['Hash'].lower()
  if got!='e4178906af4079cb797e1fb4ea3910ba2c52b995cfbbe4173324d2ed56b547ab':raise RuntimeError('fixture hash mismatch')
finally:
 code="import os,pathlib,signal; p=int(pathlib.Path('/tmp/q1-transfer-public/server.pid').read_text()); cmd=pathlib.Path('/proc/'+str(p)+'/cmdline').read_bytes(); assert b'/tmp/q1-transfer-public' in cmd; os.kill(p,signal.SIGTERM)"
 ssh('bbr-gateway','python3 -c '+shlex.quote(code),'server-stop')
