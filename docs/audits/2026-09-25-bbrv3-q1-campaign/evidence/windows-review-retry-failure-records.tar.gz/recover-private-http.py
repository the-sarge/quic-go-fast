import datetime,json,os,pathlib,signal,subprocess
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[3]
receipt=ROOT.parent/'bbr-q635-20260925/launch.json'
launch=json.loads(receipt.read_text());expiry=datetime.datetime.fromisoformat(launch['expires_at'])
assert (expiry-datetime.datetime.now(datetime.timezone.utc)).total_seconds()>900
outcomes={'original_prepare':'Full stdin transfers timed out; tiny stdin read passed; no measurement ran','same_immutable_expiry':launch['expires_at'],'paused_prior_recovery_driver':10331}
def run(args,name,bound):
 with (ROOT/(name+'.txt')).open('w') as f:
  p=subprocess.Popen(args,cwd=REPO,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=bound)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc=124
 outcomes[name]=rc
 (ROOT/'http-staging-recovery-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
 print(name,rc,flush=True)
 if rc:raise RuntimeError(name)
try:
 run(['python3',str(ROOT/'prepare-private-http.py')],'prepare-http',240)
 run(['python3',str(ROOT/'validate-and-destroy.py')],'validation-and-cleanup',600)
finally:
 try:
  if json.loads(receipt.read_text())['status']!='destroyed':
   run(['python3','scripts/cloud/bbr-campaign/campaign.py','destroy','--config',str(ROOT/'request.json')],'recovery-fallback-destroy',300)
 finally:
  cmd=subprocess.run(['ps','-p','10331','-o','command='],capture_output=True,text=True).stdout.strip()
  if cmd.endswith('.local/cloud/bbr-campaign/q1-review-windows-retry/recover-staging.py'):
   os.kill(10331,signal.SIGCONT);outcomes['original_driver_resumed']=True
  (ROOT/'http-staging-recovery-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
