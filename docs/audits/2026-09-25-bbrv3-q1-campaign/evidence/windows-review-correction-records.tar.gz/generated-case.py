"""One Q1 execution check of frozen commands; never counted as a Q2 pair."""
import base64
import concurrent.futures
import json
import pathlib
import subprocess
import sys
import time

root = pathlib.Path(__file__).resolve().parent
windows = sys.argv[1] == 'windows'
index = 510 if windows else 480
name = 'review-windows-completion' if windows else 'review-linux-completion'
base = ['gcloud', 'compute', 'ssh', '--project=bbr-q635-20260925',
        '--zone=us-east1-b', '--tunnel-through-iap', '--quiet',
        '--ssh-flag=-oControlMaster=auto', '--ssh-flag=-oControlPath=/tmp/q1-mux-%C',
        '--ssh-flag=-oControlPersist=30m', '--ssh-flag=-oConnectTimeout=15']

def run(host, command, label, bound=450, encoded=False):
    result = subprocess.run(base + [host, '--command=' + command],
                            capture_output=True, text=True, timeout=bound)
    (root / (name + '-' + label + '.txt')).write_text(result.stdout + '\nSTDERR:\n' + result.stderr)
    if encoded:
        raw = base64.b64decode(result.stdout.strip())
    else:
        raw = result.stdout
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        data = None
    if data is not None:
        (root / (name + '-' + label + '.json')).write_text(json.dumps(data, indent=2) + '\n')
    return result.returncode, data

def required(host, command, label, bound=40):
    rc, _ = run(host, command, label, bound)
    if rc:
        raise RuntimeError(label)

gateway_dir = '/tmp/q1-windows' if windows else '/tmp/q1-final'
gateway_binary = 'q1router' if windows else 'q1router-submit'
required('bbr-gateway', 'mkdir /tmp/q1-campaign && ln -s ' + gateway_dir + '/' + gateway_binary +
         ' /tmp/q1-campaign/q1router && chronyc tracking && sudo ethtool -K ens4 gro off lro off gso off tso off rx-gro-hw off && '
         'sudo ethtool -K ens5 gro off lro off gso off tso off rx-gro-hw off && sudo sysctl -w net.ipv4.ip_forward=0', 'gateway-stage')
if not windows:
    for host in ('bbr-a', 'bbr-b'):
        required(host, 'mkdir /tmp/q1-campaign && ln -s /tmp/q1-final/q1fixture-linux /tmp/q1-campaign/q1fixture && '
                 'cp /tmp/q1-final/campaign.pem /tmp/q1-final/campaign-key.pem /tmp/q1-campaign/ && chronyc tracking', host + '-stage')

start = time.time_ns() + 25_000_000_000
raw = subprocess.check_output(['python3', str(root / 'command-source/case-commands.py'), str(index),
                               '--start-unix-ns', str(start)], text=True)
commands = json.loads(raw)
(root / (name + '-commands.json')).write_text(raw)
(root / (name + '-purpose.json')).write_text(json.dumps({'purpose': 'Q1 native command construction/readiness check; no Q2 comparative observation',
    'source': '1586f733; unchanged command generator, review fixture/router source '+'e4f322cbbfd4225a4b714e08ec19c958cccadcb0', 'inventory_index': index}, indent=2) + '\n')
outcomes = {}
try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
        jobs = []
        for entry in commands['commands']:
            delay = (entry['launch_not_before_unix_ns'] - time.time_ns()) / 1e9
            if delay > 0:
                time.sleep(delay)
            label = entry['label']
            jobs.append((label, pool.submit(run, entry['host'], entry['command'], label,
                                           450, windows and label != 'router')))
            if label == 'router':
                required(entry['host'], 'for attempt in $(seq 1 30); do pgrep -x q1router >/dev/null && exit 0; sleep 0.2; done; exit 1', 'router-ready')
            elif entry['readiness_command']:
                deadline = time.monotonic() + 15
                while True:
                    rc, _ = run(entry['host'], entry['readiness_command'], label + '-ready', 20)
                    if rc == 0:
                        break
                    if time.monotonic() > deadline:
                        raise RuntimeError(label + ' readiness deadline')
                    time.sleep(0.2)
        for label, job in jobs:
            try:
                rc, data = job.result()
                outcomes[label] = rc if data is not None else 'missing result JSON'
            except Exception as error:
                outcomes[label] = str(error)
    (root / (name + '-outcomes.json')).write_text(json.dumps(outcomes, indent=2) + '\n')
    print(outcomes, flush=True)
    for role in ('focal-receive', 'focal-send'):
        result = json.loads((root / (name + '-' + role + '.json')).read_text())['result']
        if not result['completion_verified'] or result['censored'] or result.get('errors') or result['receiver']['useful_bytes'] != 16 << 20:
            raise RuntimeError('Completion receipt failed: ' + role)
    if any(value != 0 for value in outcomes.values()):
        raise RuntimeError('A native command failed')
    gateway = json.loads((root / (name + '-router.json')).read_text())
    if gateway['Source'] != 'e4f322cbbfd4225a4b714e08ec19c958cccadcb0' or gateway['PacketVersion'] != 2:
        raise RuntimeError('Gateway identity mismatch')
finally:
    required('bbr-gateway', 'sudo sysctl -w net.ipv4.ip_forward=1', 'restored')
