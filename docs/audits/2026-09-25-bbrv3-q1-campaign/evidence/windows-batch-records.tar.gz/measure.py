import base64,concurrent.futures,json,pathlib,re,shlex,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
base=['gcloud','compute','ssh','--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet','--ssh-flag=-oControlMaster=auto','--ssh-flag=-oControlPath=/tmp/q1-mux-%C','--ssh-flag=-oControlPersist=30m','--ssh-flag=-oConnectTimeout=15']
def run(host,command,name,bound=480,encoded=False):
 if encoded:command='powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(command.encode('utf-16le')).decode()
 r=subprocess.run(base+[host,'--command='+command],capture_output=True,text=True,timeout=bound)
 (root/(name+'.txt')).write_text(r.stdout+'\nSTDERR:\n'+r.stderr);print(name,r.returncode,flush=True)
 try:
  raw=base64.b64decode(r.stdout.strip()) if encoded else r.stdout
  (root/(name+'.json')).write_text(json.dumps(json.loads(raw),indent=2)+'\n')
 except (ValueError,UnicodeDecodeError):pass
 return r.returncode
case=sys.argv[1]
assert case in ('probe-short','S3-forward','S3-reverse','L3','completion')
name='win-batch-'+case
fixture=case in ('L3','completion');warm=60 if case=='L3' else 0;seconds=300 if case=='L3' else 60 if case=='completion' else 10 if case=='probe-short' else 210
for host in ('bbr-a','bbr-b'):
 if run(host,'netstat -s -p udp',name+'-'+host+'-before',30):raise SystemExit('UDP counter collection failed')
if run('bbr-gateway','sudo ethtool -K ens4 gro off lro off gso off tso off rx-gro-hw off && sudo ethtool -K ens5 gro off lro off gso off tso off rx-gro-hw off && sudo sysctl -w net.ipv4.ip_forward=0',name+'-preflight',30):raise SystemExit('Gateway preflight failed')
start=time.time_ns()+25_000_000_000
cfg=dict(id=name,controller='reno' if case=='L3' else 'bbrv3',workload='stream',start_unix_ns=start,warmup_ms=warm*1000,measure_ms=seconds*1000,payload_bytes=16384)
if case=='completion':cfg['completion_bytes']=16<<20
routercfg=dict(A=dict(Interface='ens4',PeerMAC='42:01:0a:3f:01:01',Focal='10.63.1.10'),B=dict(Interface='ens5',PeerMAC='42:01:0a:3f:02:01',Focal='10.63.2.10'),Scenario='L3' if case=='L3' else 'S3',StartUnixNS=start+warm*1000000000,MeasureSeconds=seconds,Phase=0,Seed=17)
for label,data in [('config',cfg),('router-config',routercfg)]: (root/(name+'-'+label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
bound=warm+seconds+55
router='cd /tmp/q1-windows && printf %s '+shlex.quote(json.dumps(routercfg))+' > '+name+'-config.json && sudo env GOGC=400 GOMEMLIMIT=4GiB timeout --signal=TERM --kill-after=5 '+str(bound)+' ./q1router -packet-version 2 -config '+name+'-config.json -output '+name+'-router.json; rc=$?; sudo cat /tmp/q1-windows/'+name+'-router.json; exit $rc'
sendhost,receivehost,sendip,receiveip='bbr-a','bbr-b','10.63.1.10','10.63.2.10'
if case=='S3-reverse':sendhost,receivehost,sendip,receiveip=receivehost,sendhost,receiveip,sendip
commands=[('bbr-gateway','router',router,False)]
for flow in range(1):
 port=24700+20*['probe-short','S3-forward','S3-reverse','L3','completion'].index(case)+flow*2
 for role,host,ip in [('receive',receivehost,receiveip),('send',sendhost,sendip)]:
  label=role+'-'+str(flow);out=name+'-'+label+'.json';binary='q1fixture.exe' if fixture else 'q1probe.exe'
  args='-role '+role+' -local '+ip+':'+str(port)+' -output '+out
  if role=='send':args+=' -peer '+receiveip+':'+str(port)
  args+=(' -config '+name+'-config.json') if fixture else (' -processors 4 -start '+str(start)+' -seconds '+str(seconds)+(' -rate '+str(1200000000) +' -pacing-batch 256' if role=='send' else ''))
  data=base64.b64encode(json.dumps(cfg).encode()).decode()
  command=f"""$ErrorActionPreference='Stop'
$env:GOMAXPROCS='4'
Set-Location C:/bbr/q1
[IO.File]::WriteAllBytes('C:/bbr/q1/{name}-config.json',[Convert]::FromBase64String('{data}'))
$p=Start-Process -FilePath C:/bbr/q1/{binary} -WorkingDirectory C:/bbr/q1 -ArgumentList '{args}' -PassThru -NoNewWindow -RedirectStandardOutput '{name}-{label}-stdout.txt' -RedirectStandardError '{name}-{label}-stderr.txt'
if (-not $p.WaitForExit({bound*1000})) {{ $p.Kill(); throw 'native process deadline' }}
$p.Refresh(); $rc=$p.ExitCode
if (Test-Path '{out}') {{ [Convert]::ToBase64String([IO.File]::ReadAllBytes('C:/bbr/q1/{out}')) }} else {{ Get-Content -Raw '{name}-{label}-stderr.txt' | Write-Error; exit 1 }}
exit $rc
"""
  commands.append((host,label,command,True))
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
  jobs={label:pool.submit(run,host,command,name+'-'+label,bound+30,encoded) for host,label,command,encoded in commands}
  outcomes={label:job.result() for label,job in jobs.items()}
 for host in ('bbr-a','bbr-b'):run(host,'netstat -s -p udp',name+'-'+host+'-after',30)
 (root/(name+'-outcomes.json')).write_text(json.dumps(outcomes,indent=2)+'\n')
 if any(outcomes.values()):raise SystemExit('Native case failed; retain records')
 gateway=json.loads((root/(name+'-router.json')).read_text())
 if gateway['Source']!='da6655e05f88f0126e1b46b47cb6e6cb60016338' or gateway['PacketVersion']!=2 or gateway['GoVersion']!='go1.27.1':raise SystemExit('Gateway identity mismatch')
 if not fixture:
  obs=gateway['Observations'];sent_to='ens5->ens4' if case=='S3-reverse' else 'ens4->ens5'
  delivered=next(o for o in obs if o['Direction']==sent_to)['Stats']['Delivered']
  receivers=[json.loads((root/(name+'-receive-'+str(i)+'.json')).read_text()) for i in range(1)]
  summary={'delivered':delivered,'received':sum(r['Received'] for r in receivers),'udp_receive_errors':{}}
  for host in ('bbr-a','bbr-b'):
   vals=[int(re.search(r'Receive Errors\s*=\s*(\d+)',(root/(name+'-'+host+'-'+when+'.txt')).read_text())[1]) for when in ('before','after')]
   summary['udp_receive_errors'][host]={'before':vals[0],'after':vals[1],'no_growth':vals[0]==vals[1]}
  rates=[sum(r['IPBytesPerSecond'][i] for r in receivers) for i in range(seconds)]
  summary['steady_ip_mbps']=sum(rates[1:])*8/1e6/(seconds-1)
  summary['offered_ip_mbps']=json.loads((root/(name+'-send-0.json')).read_text())['Sent']*1460*8/seconds/1e6
  summary['gateway_gate_pass']=all(not any(o.get(k) for k in ('Error','NonCanonical','SocketDrops','SendErrors','MissingTimestamps')) and o['MaxIngressLagNS']<=5000000 and o['MaxEgressLagNS']<=5000000 and not o['Stats']['PropagationOverflow'] for o in obs)
  summary['capacity_rate_pass']=summary['steady_ip_mbps']>=990
  summary['pass']=summary['gateway_gate_pass'] and summary['capacity_rate_pass'] and delivered==summary['received'] and all(x['no_growth'] for x in summary['udp_receive_errors'].values()) and all(not r.get('Error') and not r['Invalid'] and not r['Duplicate'] for r in receivers)
  (root/(name+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
  if not summary['pass']:raise SystemExit('Host receive loss invalidates native rate observation')
finally:
 run('bbr-gateway','sudo sysctl -w net.ipv4.ip_forward=1',name+'-restored',30)
 if case=='S3-reverse':subprocess.run([sys.executable,str(root/'clock-observe-end.py'),'windows',str(root/'windows-end-clocks.json')],check=True,timeout=20)
