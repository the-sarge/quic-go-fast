"""One finite lower-pressure trial within the unchanged lease; resume original cleanup."""
import datetime,json,os,pathlib,signal,subprocess,time
r=pathlib.Path(__file__).resolve().parent
expiry=datetime.datetime.fromisoformat(json.loads((r/'launch-receipt.json').read_text())['expires_at']).timestamp()
def args(pid):return subprocess.run(['ps','-p',str(pid),'-o','args='],capture_output=True,text=True).stdout.strip()
rows=subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines()
coordinators=[(int(row.strip().split(None,1)[0]),row.strip().split(None,1)[1]) for row in rows if row.strip().endswith(str(r/'validate-and-destroy.py'))]
assert len(coordinators)==1,coordinators
pid,expected=coordinators[0]
watchcode="import time,os,signal,subprocess;time.sleep(1200);actual=subprocess.run(['ps','-p',str("+str(pid)+"),'-o','args='],capture_output=True,text=True).stdout.strip();os.kill("+str(pid)+",signal.SIGCONT) if actual=="+repr(expected)+" else None"
watch=subprocess.Popen(['python3','-c',watchcode],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
hold={'coordinator_pid':pid,'coordinator_command':expected,'resume_watchdog_pid':watch.pid,'watchdog_seconds':1200,'lease_expiry':datetime.datetime.fromtimestamp(expiry,datetime.timezone.utc).isoformat(),'reason':'Single lower-pressure probe trial; original timing failure preserved; immutable lease unchanged'}
(r/'controlled-hold.json').write_text(json.dumps(hold,indent=2)+'\n')
assert args(pid)==expected
os.kill(pid,signal.SIGSTOP)
deadline=min(expiry-210,time.time()+1170);outcomes={}
try:
 wait_end=time.time()+330
 while True:
  active=[row for row in subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines() if row.strip().endswith(str(r/'measure.py')+' S3-reverse')]
  if not active and (r/'windows-end-clocks.json').exists():break
  if time.time()>wait_end:raise TimeoutError('Original reverse roles not finished')
  time.sleep(1)
 for case,bound in [('probe-short',120),('S3-forward',310),('S3-reverse',310)]:
  if time.time()+bound>=deadline:outcomes[case]='unmeasured: cleanup margin';break
  with (r/('controlled-driver-'+case+'.txt')).open('w') as log:
   p=subprocess.Popen(['python3',str(r/'measure-controlled.py'),case],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:rc=p.wait(timeout=bound)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    rc=124
  outcomes[case]=rc;(r/'controlled-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n');print(case,rc,flush=True)
  if case=='probe-short' and rc:break
finally:
 (r/'controlled-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
 if args(pid)==expected:os.kill(pid,signal.SIGCONT)
 watch.terminate();watch.wait(timeout=5)
 print('Original cleanup resumed',flush=True)
