import datetime,json,os,pathlib,signal,subprocess
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[3]
controller=['python3','scripts/cloud/bbr-campaign/campaign.py']
def run(args,name,bound):
 with (ROOT/(name+'.txt')).open('w') as out:
  p=subprocess.Popen(args,cwd=REPO,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try: rc=p.wait(timeout=bound)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc=124
 print(name,rc,flush=True)
 if rc:raise RuntimeError(name)
try:
 run(controller+['apply','--config',str(ROOT/'request.json')],'apply',600)
 run(['python3',str(ROOT/'prepare.py')],'prepare',900)
 run(['python3',str(ROOT/'validate-and-destroy.py')],'validation-and-cleanup',3600)
finally:
 p=ROOT.parent/'bbr-q635-20260925/launch.json'
 if p.exists() and json.loads(p.read_text())['status']!='destroyed':
  run(controller+['destroy','--config',str(ROOT/'request.json')],'fallback-destroy',300)
