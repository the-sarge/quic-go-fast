import concurrent.futures,json,pathlib,shlex,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
REMOTE='/tmp/q1-d915'
BASE=['gcloud','compute','ssh','--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet','--ssh-flag=-oControlMaster=auto','--ssh-flag=-oControlPath=/tmp/q1-mux-%C','--ssh-flag=-oControlPersist=30m','--ssh-flag=-oConnectTimeout=15']
def ssh(host,cmd,name,timeout=430,required=True):
 try:r=subprocess.run(BASE+[host,'--command='+cmd],capture_output=True,text=True,timeout=timeout)
 except subprocess.TimeoutExpired as e:
  (ROOT/(name+'.txt')).write_bytes((e.stdout or b'')+b'\nTIMEOUT\n'+(e.stderr or b''));raise
 (ROOT/(name+'.txt')).write_text(r.stdout+'\nSTDERR:\n'+r.stderr)
 print(name,r.returncode,flush=True)
 if r.returncode and required:raise RuntimeError(name)
 return r.stdout,r.returncode
scenario=sys.argv[1]
assert scenario in ('L6','L7','L8','L4','native-cubic')
name='tcp-header-'+scenario
short=scenario=='native-cubic'
warm,measure=1000,10000
start=time.time_ns()+25_000_000_000
focal=dict(id=name+'-focal',controller='reno',workload='stream',start_unix_ns=start,warmup_ms=warm,measure_ms=measure,payload_bytes=16384)
competitor=dict(focal,id=name+'-competitor',controller={'L6':'reno','L7':'cubic','L8':'bbrv3','native-cubic':'cubic','L4':'cubic'}[scenario])

c=dict(A=dict(Interface='ens4',PeerMAC='42:01:0a:3f:01:01',Focal='10.63.1.10',Competitor='10.63.1.11'),B=dict(Interface='ens5',PeerMAC='42:01:0a:3f:02:01',Focal='10.63.2.10',Competitor='10.63.2.11'),Scenario=scenario,StartUnixNS=start+warm*1000000,MeasureSeconds=measure//1000,Phase=0,Seed=17)
prefix='cd '+REMOTE+' && '
bound=25+(warm+measure)//1000+25

def frozen(label,data):
 (ROOT/(name+'-'+label+'-config.json')).write_text(json.dumps(data,indent=2)+'\n')
 return 'printf %s '+shlex.quote(json.dumps(data))+' > '+name+'-'+label+'-config.json && '

def participant(kind,cfg,host,ip,role,peer='',port=4460):
 label=kind+'-'+role
 command=prefix+frozen(kind,cfg)+'timeout --signal=TERM --kill-after=5 '+str(bound)+' ./q1fixture-linux'+(' -tcp-cubic' if cfg['controller']=='cubic' else '')+' -role '+role+' -config '+name+'-'+kind+'-config.json -local '+ip+':'+str(port)+(' -peer '+peer+':'+str(port) if peer else '')+' -output '+name+'-'+label+'.json 2>'+name+'-'+label+'.err; result=$?; cat '+REMOTE+'/'+name+'-'+label+'.json; cat '+REMOTE+'/'+name+'-'+label+'.err >&2; exit $result'
 return host,label,command

ssh('bbr-gateway','sudo ethtool -K ens4 gro off lro off gso off tso off && sudo ethtool -K ens5 gro off lro off gso off tso off && sudo sysctl -w net.ipv4.ip_forward='+('1' if short else '0'),name+'-preflight')
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  jobs=[]
  if not short:
   router=prefix+frozen('router',c)+'sudo /usr/bin/time -v timeout --signal=TERM --kill-after=5 '+str(bound)+' ./q1router -config '+name+'-router-config.json -output '+name+'-router.json; result=$?; sudo cat '+REMOTE+'/'+name+'-router.json; exit $result'
   jobs.append(('router',pool.submit(ssh,'bbr-gateway',router,name+'-router',bound+20,False)))
   ssh('bbr-gateway','for attempt in $(seq 1 20); do pgrep -x q1router >/dev/null && exit 0; sleep 0.2; done; exit 1',name+'-router-ready',30)
  pairs=[('competitor',competitor,'bbr-competitor-a','bbr-competitor-b','10.63.1.11','10.63.2.11')]
  if not short:pairs.append(('focal',focal,'bbr-a','bbr-b','10.63.1.10','10.63.2.10'))
  if scenario=='L4':pairs=pairs[1:]
  for kind,cfg,sendhost,receivehost,sendip,receiveip in pairs:
   host,label,cmd=participant(kind,cfg,receivehost,receiveip,'receive')
   jobs.append((label,pool.submit(ssh,host,cmd,name+'-'+label,bound+20,False)))
   ready='for attempt in $(seq 1 30); do grep -q ready '+REMOTE+'/'+name+'-'+kind+'-receive.err 2>/dev/null && exit 0; sleep 0.2; done; exit 1'
   ssh(receivehost,ready,name+'-'+kind+'-ready',30)
   host,label,cmd=participant(kind,cfg,sendhost,sendip,'send',receiveip)
   jobs.append((label,pool.submit(ssh,host,cmd,name+'-'+label,bound+20,False)))
  if scenario=='L4':
   for flow,offset in [(1,100),(2,200),(3,200)]:
    cfg=dict(competitor,id=name+'-competitor-'+str(flow),start_unix_ns=start+(60+offset)*1000000000,warmup_ms=0,measure_ms=(300-offset)*1000)
    delay=(cfg['start_unix_ns']-time.time_ns())/1e9-15
    if delay>0:time.sleep(delay)
    kind='competitor-'+str(flow);port=4460+2*(flow-1)
    host,label,cmd=participant(kind,cfg,'bbr-competitor-b','10.63.2.11','receive',port=port)
    jobs.append((label,pool.submit(ssh,host,cmd,name+'-'+label,bound+20,False)))
    ssh(host,'for attempt in $(seq 1 30); do grep -q ready '+REMOTE+'/'+name+'-'+kind+'-receive.err 2>/dev/null && exit 0; sleep 0.2; done; exit 1',name+'-'+kind+'-ready',30)
    host,label,cmd=participant(kind,cfg,'bbr-competitor-a','10.63.1.11','send','10.63.2.11',port=port)
    jobs.append((label,pool.submit(ssh,host,cmd,name+'-'+label,bound+20,False)))
  outcomes={}
  for kind,job in jobs:
   raw,rc=job.result();outcomes[kind]=rc
   try:data=json.loads(raw)
   except ValueError:outcomes[kind]='missing JSON';continue
   (ROOT/(name+'-'+kind+'.json')).write_text(json.dumps(data,indent=2)+'\n')
  (ROOT/(name+'-outcomes.json')).write_text(json.dumps(outcomes,indent=2)+'\n')
  print(outcomes,flush=True)
finally:ssh('bbr-gateway','sudo sysctl -w net.ipv4.ip_forward=1; ip -s link',name+'-restored',required=False)
