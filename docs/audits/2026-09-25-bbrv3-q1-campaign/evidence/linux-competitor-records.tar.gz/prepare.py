import concurrent.futures,json,pathlib,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parent
COMMON=['--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet']
MUX=['--ssh-flag=-oControlMaster=auto','--ssh-flag=-oControlPath=/tmp/q1-mux-%C','--ssh-flag=-oControlPersist=30m']
BASE=['gcloud','compute','ssh']+COMMON+MUX
DEADLINE=time.monotonic()+300
REMOTE='/tmp/q1-d915'
def ssh(host,cmd,name,timeout=90):
 try:r=subprocess.run(BASE+[host,'--command='+cmd,'--ssh-flag=-oConnectTimeout=15'],capture_output=True,text=True,timeout=timeout)
 except subprocess.TimeoutExpired as e:
  (ROOT/(name+'.txt')).write_bytes((e.stdout or b'')+b'\nTIMEOUT\n'+(e.stderr or b''));raise
 (ROOT/(name+'.txt')).write_text(r.stdout+'\nSTDERR:\n'+r.stderr)
 print(name,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(name)
 return r.stdout
facts='uname -a; lscpu; cat /etc/os-release; ip -details link; ip route; ip neigh; date -u +%s%N; uptime; vmstat 1 3; sysctl net.ipv4.tcp_available_congestion_control net.ipv4.tcp_ecn net.ipv4.tcp_timestamps; for i in /sys/class/net/e*; do sudo ethtool -k "${i##*/}"; done'
def prepare(host):
 for attempt in range(10):
  remaining=DEADLINE-time.monotonic()
  if remaining<=0:raise TimeoutError('Linux startup deadline')
  try:ssh(host,'mkdir -p '+REMOTE+' && '+facts,host+'-facts-'+str(attempt),min(45,remaining));break
  except (RuntimeError,subprocess.TimeoutExpired):
   if attempt==9:raise
   time.sleep(5)
 archive='gateway.tar.gz' if host=='bbr-gateway' else 'endpoints.tar.gz'
 args=['gcloud','compute','scp']+COMMON+['--scp-flag=-oControlMaster=auto','--scp-flag=-oControlPath=/tmp/q1-mux-%C','--scp-flag=-oControlPersist=30m',str(ROOT/archive),host+':'+REMOTE+'/']
 r=subprocess.run(args,capture_output=True,text=True,timeout=180)
 (ROOT/(host+'-stage.txt')).write_text(r.stdout+'\n'+r.stderr)
 if r.returncode:raise RuntimeError(host+' stage')
 ssh(host,'cd '+REMOTE+' && tar -xzf '+archive+' && chmod 700 q1* && sha256sum q1*',host+'-hashes')
 if 'competitor' in host:
  ssh(host,'sudo ethtool -K ens4 gro off lro off gso off tso off && sudo ethtool -k ens4',host+'-offloads')
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
 list(pool.map(prepare,['bbr-a','bbr-b','bbr-gateway','bbr-competitor-a','bbr-competitor-b']))
ssh('bbr-a','ping -c 3 -W 2 -M do -s 1432 10.63.2.10','focal-native-path')
ssh('bbr-competitor-a','ping -c 3 -W 2 -M do -s 1432 10.63.2.11','competitor-native-path')
ssh('bbr-gateway','ip -j addr; ip -j route; ping -c 1 -W 2 10.63.1.1 >/dev/null; ping -c 1 -W 2 10.63.2.1 >/dev/null; ip -j neigh','gateway-route')
