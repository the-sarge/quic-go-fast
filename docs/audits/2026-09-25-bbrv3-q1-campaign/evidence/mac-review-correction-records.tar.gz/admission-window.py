import subprocess,pathlib,os,json,time
repo=pathlib.Path('/Users/josh/code/github.com/the-sarge/infra')
root=repo/'.local/cloud/bbr-campaign/q1-review-corrections/mac'
provider=str(repo/'scripts/garm/local-mac-provider.sh')
env=dict(os.environ,GARM_PROVIDER_CONFIG_FILE=str(repo/'.local/garm/local-mac-provider.conf'))
identity=['q1-review-mac-20260926','minimax','q1-campaign','review-mac-20260926']
held=False
try:
 deadline=time.monotonic()+1200
 while True:
  p=subprocess.run([provider,'--acquire-host-admission-exclusive-consumer',*identity],env=env,capture_output=True,text=True,timeout=60)
  (root/'admission-attempts.txt').open('a').write(str(time.time())+'\n'+p.stdout+'\n'+p.stderr+'\n')
  if p.returncode==0:
   lease=json.loads(p.stdout);assert lease['exclusive_host'] and lease['host']=='minimax' and lease['instance_id']==identity[0]
   held=True;(root/'host-lease.json').write_text(json.dumps(lease,indent=2)+'\n');print('Exclusive gateway lease acquired',flush=True);break
  if 'retryable-admission-denial:' not in p.stderr or time.monotonic()>deadline:raise RuntimeError('admission unavailable: '+p.stderr)
  print('Waiting for existing gateway consumer',flush=True);time.sleep(30)
 p=subprocess.run(['python3',str(root/'run-completion.py')],timeout=240)
 if p.returncode:raise RuntimeError('Mac completion failed')
finally:
 if held:
  p=subprocess.run(['ssh','-o','BatchMode=yes','minimax','sudo bash /tmp/q1-gateway-network.sh down && sudo ip netns list'],capture_output=True,text=True,timeout=30)
  (root/'cleanup.txt').write_text(p.stdout+'\n'+p.stderr)
  clean=p.returncode==0 and 'q1-mac-20260925' not in p.stdout
  cmd=[provider,'--release-host-admission-consumer' if clean else '--fail-host-admission-consumer',*identity]
  if not clean:cmd+=['Q1 gateway cleanup needs recovery']
  p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=60)
  (root/'admission-cleanup.txt').write_text(p.stdout+'\n'+p.stderr)
  if p.returncode or not clean:raise RuntimeError('Gateway admission cleanup failed')
  print('Owned namespaces absent; exclusive lease released',flush=True)
