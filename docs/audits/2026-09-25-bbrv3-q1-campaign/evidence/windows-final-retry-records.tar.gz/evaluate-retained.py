"""Evaluate completed raw receipts after optional Error-key parser repair; no measurements."""
import json,pathlib,re
r=pathlib.Path(__file__).resolve().parent
for case,seconds in [('probe-short',10),('S3-forward',210),('S3-reverse',210)]:
 name='win4-'+case;p=r/(name+'-outcomes.json')
 if not p.exists():continue
 outcomes=json.loads(p.read_text());g=json.loads((r/(name+'-router.json')).read_text());receivers=[json.loads((r/(name+'-receive-'+str(i)+'.json')).read_text()) for i in range(1 if case=='probe-short' else 2)]
 direction='ens5->ens4' if case=='S3-reverse' else 'ens4->ens5';o=next(x for x in g['Observations'] if x['Direction']==direction)
 d={'original_process_outcomes':outcomes,'delivered':o['Stats']['Delivered'],'received':sum(x['Received'] for x in receivers),'udp_receive_errors':{}}
 d['identity_pass']=g['Source']=='da6655e05f88f0126e1b46b47cb6e6cb60016338' and g['PacketVersion']==2 and g['GoVersion']=='go1.27.1'
 d['gateway_gate_pass']=all(not any(x.get(k) for k in ('Error','NonCanonical','SocketDrops','SendErrors','MissingTimestamps')) and x['MaxIngressLagNS']<=5e6 and x['MaxEgressLagNS']<=5e6 and not x['Stats']['PropagationOverflow'] for x in g['Observations'])
 for host in ('bbr-a','bbr-b'):
  vals=[int(re.search(r'Receive Errors\s*=\s*(\d+)',(r/(name+'-'+host+'-'+when+'.txt')).read_text())[1]) for when in ('before','after')]
  d['udp_receive_errors'][host]={'before':vals[0],'after':vals[1],'no_growth':vals[0]==vals[1]}
 d['steady_ip_mbps']=sum(sum(x['IPBytesPerSecond'][1:]) for x in receivers)*8/1e6/(seconds-1)
 d['counter_and_timing_pass']=all(v==0 for v in outcomes.values()) and d['identity_pass'] and d['gateway_gate_pass'] and d['delivered']==d['received'] and all(x['no_growth'] for x in d['udp_receive_errors'].values()) and all(not x.get('Error') and not x['Invalid'] and not x['Duplicate'] for x in receivers)
 d['capacity_qualification']=False
 d['evaluation_note']='Counter/timing success alone does not establish offered-load capacity. Separate evaluation of retained native data; original driver exits remain unchanged. Missing optional Error means no reported error.'
 (r/(name+'-evaluation.json')).write_text(json.dumps(d,indent=2)+'\n');print(case,json.dumps(d))
