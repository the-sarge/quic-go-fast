"""Finite correction inside the original lease; always resumes original cleanup."""
import datetime,json,os,pathlib,signal,subprocess,time
r=pathlib.Path(__file__).resolve().parent;holdpath=r/'bounded-validation-hold.json';hold=json.loads(holdpath.read_text());expiry=datetime.datetime.fromisoformat(hold['lease_expiry']).timestamp();deadline=min(expiry-180,holdpath.stat().st_mtime+hold['watchdog_seconds']-30);outcomes={}
try:
 # Completion was already observed finished; confirm its final restoration receipt.
 assert 'win4-completion-restored 0' in (r/'driver-completion.txt').read_text()
 for script,case,bound,label in [('generated-case-retry.py','windows',460,'generated-L3-retry'),('measure-unpaced.py','S3-forward',290,'unpaced-S3-forward'),('measure-unpaced.py','S3-reverse',290,'unpaced-S3-reverse')]:
  if time.time()+bound>=deadline:
   outcomes[label]='unmeasured: finite resumption margin';continue
  with (r/('recovery-'+label+'.txt')).open('w') as log:
   p=subprocess.Popen(['python3',str(r/script),case],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:rc=p.wait(timeout=bound)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    rc=124
  outcomes[label]=rc;(r/'recovery-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n');print(label,rc,flush=True)
finally:
 (r/'recovery-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
 os.kill(hold['coordinator_pid'],signal.SIGCONT)
 args=subprocess.run(['ps','-p',str(hold['resume_watchdog_pid']),'-o','args='],capture_output=True,text=True).stdout
 if 'time.sleep(1200);os.kill('+str(hold['coordinator_pid']) in args:os.kill(hold['resume_watchdog_pid'],signal.SIGTERM)
 print('original cleanup resumed',flush=True)
