"""Finite Windows-compatible one-shot clock observations; no clock changes."""
import base64,concurrent.futures,json,pathlib,subprocess,sys,time
platform,out=sys.argv[1:];assert platform=='windows';output=pathlib.Path(out);deadline=time.monotonic()+65
base=['gcloud','compute','ssh','--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet','--ssh-flag=-T','--ssh-flag=-oControlMaster=auto','--ssh-flag=-oControlPath=/tmp/q1-mux-%C','--ssh-flag=-oControlPersist=30m']
def observe(host):
 code="[Console]::WriteLine(([DateTime]::UtcNow.Ticks - 621355968000000000L) * 100L)"
 command=('powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(code.encode('utf-16le')).decode()) if host!='bbr-gateway' else "python3 -c 'import time;print(time.time_ns())'"
 samples=[];errors=[]
 for _ in range(10):
  remaining=deadline-time.monotonic()
  if remaining<=0:raise TimeoutError('clock observation total deadline')
  before=time.time_ns();p=subprocess.run(base+[host,'--command='+command],capture_output=True,text=True,timeout=min(10,remaining));after=time.time_ns();errors.append(p.stderr)
  if p.returncode:raise RuntimeError(host+' clock command failed: '+p.stderr)
  remote=int(p.stdout.strip());samples.append({'controller_before':before,'remote':remote,'controller_after':after,'offset_lower_ns':remote-after,'offset_upper_ns':remote-before})
 output.with_name(output.stem+'-'+host+'.stderr').write_text('\n'.join(errors))
 lo=max(x['offset_lower_ns'] for x in samples);hi=min(x['offset_upper_ns'] for x in samples)
 return host,{'samples':samples,'intersection_lower_ns':lo,'intersection_upper_ns':hi,'consistent':lo<=hi}
start=time.time_ns()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:hosts=dict(pool.map(observe,['bbr-a','bbr-b','bbr-gateway']))
r={'contract':'One-shot remote timestamp sampled between controller launch and completion; bounds include process/IAP startup and are consequently wider. No clock adjustment; no assumption the interval persists later.','controller_start_unix_ns':start,'controller_end_unix_ns':time.time_ns(),'hosts':hosts};output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({h:{k:v for k,v in d.items() if k!='samples'} for h,d in hosts.items()}))
if any(not d['consistent'] for d in hosts.values()):raise SystemExit('Inconsistent clock observations')
