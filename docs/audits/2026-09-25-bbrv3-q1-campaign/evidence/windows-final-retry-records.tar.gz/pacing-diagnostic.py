"""Two-second native unpaced UDP diagnostic; runs between campaign checks."""
import base64,concurrent.futures,json,pathlib,subprocess,time
r=pathlib.Path(__file__).resolve().parent
base=['gcloud','compute','ssh','--project=bbr-q635-20260925','--zone=us-east1-b','--tunnel-through-iap','--quiet','--ssh-flag=-oControlMaster=auto','--ssh-flag=-oControlPath=/tmp/q1-mux-%C','--ssh-flag=-oControlPersist=30m','--ssh-flag=-oConnectTimeout=10']
start=time.time_ns()+10_000_000_000
(r/'pacing-diagnostic-config.json').write_text(json.dumps({'start_unix_ns':start,'seconds':2,'rate':0,'flows':2,'processors_per_flow':2,'scope':'Unpaced native routed path; no emulator, no capacity qualification or Q2 comparison'},indent=2)+'\n')
def run(item):
 role,host,ip,flow=item;name='pacing-diagnostic-'+role+'-'+str(flow);port=24890+flow;args=f'-processors 2 -role {role} -local {ip}:{port} -start {start} -seconds 2 -output {name}.json'
 if role=='send':args+=f' -peer 10.63.2.10:{port} -rate 0'
 code=f"Set-Location C:/bbr/q1; & ./q1probe.exe {args}; $rc=$LASTEXITCODE; if (Test-Path '{name}.json') {{[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:/bbr/q1/{name}.json'))}}; exit $rc"
 command='powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(code.encode('utf-16le')).decode()
 p=subprocess.run(base+[host,'--command='+command],capture_output=True,text=True,timeout=24)
 (r/(name+'.txt')).write_text(p.stdout+'\nSTDERR:\n'+p.stderr)
 if p.returncode:raise RuntimeError(name)
 d=json.loads(base64.b64decode(p.stdout.strip()));(r/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');return name,d
items=[(role,host,ip,flow) for flow in (0,1) for role,host,ip in [('receive','bbr-b','10.63.2.10'),('send','bbr-a','10.63.1.10')]]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=dict(pool.map(run,items))
sent=sum(v['Sent'] for k,v in results.items() if '-send-' in k);received=sum(v['Received'] for k,v in results.items() if '-receive-' in k)
summary={'sent':sent,'received':received,'offered_ip_mbps':sent*1460*8/2/1e6,'qualification':False,'purpose':'Isolate offered-load limitation in paced probe; native short diagnostic only'}
(r/'pacing-diagnostic-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
