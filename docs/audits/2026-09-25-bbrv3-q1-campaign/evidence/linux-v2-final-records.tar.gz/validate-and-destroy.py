import datetime,json,os,pathlib,signal,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[3]
launch=json.loads((ROOT.parent/'bbr-q635-20260925/launch.json').read_text())
expiry=datetime.datetime.fromisoformat(launch['expires_at']).timestamp()
(ROOT/'launch-receipt.json').write_text(json.dumps(launch,indent=2)+'\n')
def run(args,name,bound):
 with (ROOT/(name+'.txt')).open('w') as output:
  p=subprocess.Popen(args,stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=REPO)
  try:rc=p.wait(timeout=bound)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc='timeout'
 print(name,rc,flush=True)
 return rc
cases=[('coexist.py','L6',440),('coexist.py','L8',440),('coexist.py','L7',440),('coexist.py','L4',440),('calibrate.py','L3-phases',385),('calibrate.py','S8-ect',90),('calibrate.py','S8-noect',90),('calibrate.py','S3-rate',90)]
outcomes={}
try:
 for script,case,bound in cases:
  if time.time()+bound+240>=expiry:
   outcomes[case]='unmeasured: immutable expiry cleanup margin';continue
  outcomes[case]=run(['python3',str(ROOT/script),case],'driver-'+case,bound)
  (ROOT/'validation-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
finally:
 (ROOT/'validation-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
 rc=run(['python3','scripts/cloud/bbr-campaign/campaign.py','destroy','--config',str(ROOT/'request.json')],'destroy',210)
 for resource in ('instances','disks'):
  result=subprocess.run(['gcloud','compute',resource,'list','--project=bbr-q635-20260925','--format=json'],capture_output=True,text=True,timeout=30)
  (ROOT/('final-'+resource+'.json')).write_text(result.stdout)
  if result.returncode or json.loads(result.stdout):raise RuntimeError('cleanup inventory not empty: '+resource)
 if rc:raise RuntimeError('explicit destroy failed')
 print('destroyed and independently verified zero VMs/disks',flush=True)
