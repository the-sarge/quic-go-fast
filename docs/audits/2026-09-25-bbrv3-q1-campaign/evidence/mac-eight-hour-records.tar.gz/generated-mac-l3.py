"""Finite Q1 check of generated commands, not a Q2 comparison."""
import concurrent.futures,json,pathlib,subprocess,time
root=pathlib.Path(__file__).resolve().parent
source=pathlib.Path('/Volumes/worktrees/quic-go-fast/q1-campaign-implementation/docs/audits/2026-09-25-bbrv3-q1-campaign')
name='generated-mac-L3';outcomes={};expiry=1790423437
# Only run after the selected V2 capacity prerequisite succeeds.
for d in ('reverse','forward'):
 assert json.loads((root/('mac-v2plain-S3-'+d+'-summary.json')).read_text())['pass']
assert time.time()+460<expiry

def run(host,cmd,label,bound=450):
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,cmd],capture_output=True,text=True,timeout=bound)
 (root/(name+'-'+label+'.txt')).write_text(p.stdout+'\nSTDERR:\n'+p.stderr)
 try:
  data=json.loads(p.stdout);(root/(name+'-'+label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
 except ValueError:data=None
 print(label,p.returncode,flush=True);return p.returncode,data

def required(host,cmd,label,bound=30):
 rc,data=run(host,cmd,label,bound);outcomes[label]=rc
 if rc:raise RuntimeError(label)
 return data

def clocks(when):
 p=subprocess.run(['python3',str(root/'followup-clock-observe.py'),'mac',str(root/(name+'-clock-'+when+'.json'))],capture_output=True,text=True,timeout=60)
 (root/(name+'-clock-'+when+'.txt')).write_text(p.stdout+'\n'+p.stderr);outcomes['clock-'+when]=p.returncode
 if p.returncode:raise RuntimeError('clock-'+when)
try:
 required('minimax','sudo bash /tmp/q1-gateway-network.sh up','gateway-up')
 for host in ('m4mini-eth','mbp128'):
  # Exclusive new directory; never replace a pre-existing directory or expose keys.
  required(host,'umask 077; mkdir /tmp/q1-campaign && ln -s /tmp/q1-mac-20260925/q1fixture /tmp/q1-campaign/q1fixture && cp /tmp/q1-mac-20260925/campaign.pem /tmp/q1-mac-20260925/campaign-key.pem /tmp/q1-campaign/ && shasum -a 256 /tmp/q1-campaign/q1fixture /tmp/q1-campaign/campaign.pem && openssl x509 -in /tmp/q1-campaign/campaign.pem -noout -dates',host+'-stage')
 required('minimax','umask 077; mkdir /tmp/q1-campaign && ln -s /tmp/q1router-ring-select /tmp/q1-campaign/q1router && sha256sum /tmp/q1-campaign/q1router','gateway-stage')
 clocks('before')
 # Prove S1 setup then the modeled command restores forwarding=0.
 raw=subprocess.check_output(['python3',str(source/'case-commands.py'),'340','--start-unix-ns',str(time.time_ns()+25000000000)],text=True)
 native=json.loads(raw);assert native['case']['scenario']=='S1'
 (root/(name+'-native-setup-command.json')).write_text(raw)
 required('minimax',native['commands'][0]['command'],'native-path')
 start=time.time_ns()+25000000000
 raw=subprocess.check_output(['python3',str(source/'case-commands.py'),'380','--start-unix-ns',str(start)],text=True)
 d=json.loads(raw);assert d['case']['scenario']=='L3' and d['case']['platform']=='darwin/arm64'
 (root/(name+'-commands.json')).write_text(raw)
 # A selected manifest must first make the native command select V2 itself.
 assert '-packet-version 2' in d['commands'][0]['command']
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
  jobs=[]
  for host in ('m4mini-eth','mbp128'):jobs.append((host+'-cpu',pool.submit(run,host,'iostat -C -w 1 -c 405',host+'-cpu',430)))
  for e in d['commands']:
   jobs.append((e['label'],pool.submit(run,e['host'],e['command'],e['label'])))
   if e['label']=='router':
    required('minimax','for i in $(seq 1 30); do pgrep -f "^./q1router " >/dev/null && test "$(sudo ip netns exec q1-mac-20260925 cat /proc/sys/net/ipv4/ip_forward)" = 0 && exit 0; sleep 0.2; done; exit 1','router-ready')
   elif e['readiness_command']:
    deadline=time.monotonic()+15
    while run(e['host'],e['readiness_command'],e['label']+'-ready',10)[0]:
     if time.monotonic()>deadline:raise RuntimeError('receiver readiness')
     time.sleep(.2)
  for label,job in jobs:
   try:
    rc,data=job.result();outcomes[label]=rc if label.endswith('-cpu') or data is not None else 'missing JSON'
   except Exception as exc:outcomes[label]=str(exc)
 clocks('after')
finally:
 required('minimax','sudo bash /tmp/q1-gateway-network.sh down','gateway-down')
 (root/(name+'-outcomes.json')).write_text(json.dumps(outcomes,indent=2)+'\n')
if any(outcomes.values()):raise SystemExit('Native command validation failed')
