import concurrent.futures,json,pathlib,re,shlex,subprocess,time
root=pathlib.Path(__file__).resolve().parent
name='mac-spaced20-S3-reverse';remote='/tmp/q1-mac-20260925';seconds=210
# Call only inside a fresh operator-created Mac network window. Record accepted background activity. Every process is finite.
def run(host,cmd,label,bound):
 r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,cmd],capture_output=True,text=True,timeout=bound)
 (root/(label+'.txt')).write_text(r.stdout+'\nSTDERR:\n'+r.stderr)
 print(label,r.returncode,flush=True)
 try:(root/(label+'.json')).write_text(json.dumps(json.loads(r.stdout),indent=2)+'\n')
 except ValueError:pass
 return r.returncode
def path_counters(when):
 for host,cmd in [
  ('m4mini-eth','netstat -I bridge0 -b -d; netstat -I en4 -b -d; netstat -s -p ip; netstat -m'),
  ('mbp128','netstat -I en8 -b -d; netstat -s -p ip; netstat -m'),
  ('minimax','ip -s -j link show thunderbolt0; ip -s -j link show enp97s0; tc -s qdisc show dev thunderbolt0; sudo ip netns exec q1-mac-20260925 ip -s -j link; sudo ip netns exec q1-mac-20260925-a ip -s -j link')]:
  if run(host,cmd,name+'-'+host+'-path-'+when,15):raise SystemExit('Path counters unavailable')
path_counters('before')
for host,interface,address in [('m4mini-eth','bridge0','10.64.1.10'),('mbp128','en8','10.64.2.10')]:
 if run(host,'ifconfig '+interface+' | grep -F '+shlex.quote('inet '+address+' '),name+'-'+host+'-address',10):raise SystemExit('Fresh temporary address required')
 run(host,'netstat -s -p udp',name+'-'+host+'-before',10)
start=time.time_ns()+15_000_000_000
config=dict(A=dict(Interface='q1a',PeerMAC='02:63:65:01:00:01',Focal='10.64.1.10'),B=dict(Interface='q1b',PeerMAC='02:63:65:02:00:01',Focal='10.64.2.10'),Scenario='S3',StartUnixNS=start,MeasureSeconds=seconds,Phase=0,Seed=17)
(root/(name+'-config.json')).write_text(json.dumps(config,indent=2)+'\n')
router='printf %s '+shlex.quote(json.dumps(config))+' > /tmp/'+name+'-config.json && sudo ip netns exec q1-mac-20260925 env GOGC=400 GOMEMLIMIT=4GiB taskset -c 0-3 timeout --signal=TERM --kill-after=5 250 /tmp/q1router-spaced -emission-rate 2000000000 -packet-version 3 -config /tmp/'+name+'-config.json -output /tmp/'+name+'-router.json; rc=$?; sudo cat /tmp/'+name+'-router.json; exit $rc'
capture="sudo ip netns exec q1-mac-20260925 taskset -c 4 timeout --signal=INT --kill-after=5 250 tcpdump -n -Q out -i q1a -s 64 -B 16384 -w /dev/null 'udp and src host 10.64.2.10 and dst host 10.64.1.10 and (dst port 24740 or dst port 24741)'; rc=$?; if [ $rc -eq 124 ]; then exit 0; else exit 1; fi"
commands=[('minimax','capture',capture),('minimax','router',router)]
for flow in (0,1):
 port=24740+flow
 for role,host,ip in [('receive','m4mini-eth','10.64.1.10'),('send','mbp128','10.64.2.10')]:
  label=role+'-'+str(flow);out=name+'-'+label+'.json'
  cmd='cd '+remote+' && ./q1probe-dual -processors 2 -role '+role+' -local '+ip+':'+str(port)+' -start '+str(start)+' -seconds 210 -ect -output '+out
  if role=='send':cmd+=' -peer 10.64.1.10:'+str(port)+' -rate 525000000'
  cmd+='; rc=$?; cat '+out+'; exit $rc';commands.append((host,label,cmd))
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 jobs={label:pool.submit(run,host,cmd,name+'-'+label,270) for host,label,cmd in commands}
 for host in ('m4mini-eth','mbp128'):jobs[host+'-cpu']=pool.submit(run,host,'iostat -C -w 1 -c 245',name+'-'+host+'-cpu',260)
 outcomes={label:job.result() for label,job in jobs.items()}
for host in ('m4mini-eth','mbp128'):run(host,'netstat -s -p udp',name+'-'+host+'-after',10)
path_counters('after')
(root/(name+'-outcomes.json')).write_text(json.dumps(outcomes,indent=2)+'\n')
# Preserve counter interpretation even when the router timing gate fails.
gateway=json.loads((root/(name+'-router.json')).read_text());receivers=[json.loads((root/(name+'-receive-'+str(i)+'.json')).read_text()) for i in (0,1)]
obs=next(o for o in gateway['Observations'] if o['Direction']=='q1b->q1a')
summary={'delivered':obs['Stats']['Delivered'],'received':sum(r['Received'] for r in receivers),'host_counters':{}}
for host in ('m4mini-eth','mbp128'):
 vals=[int(re.search(r'(\d+) dropped due to full socket buffers',(root/(name+'-'+host+'-'+when+'.txt')).read_text())[1]) for when in ('before','after')]
 summary['host_counters'][host]=dict(before=vals[0],after=vals[1],no_growth=vals[0]==vals[1])
rates=[sum(r['IPBytesPerSecond'][i] for r in receivers) for i in range(seconds)]
summary['steady_ip_mbps_excluding_first_second']=sum(rates[1:])*8/1e6/(seconds-1)
capture_text=(root/(name+'-capture.txt')).read_text()
summary['filtered_probe_packets']=int(re.search(r'(\d+) packets captured',capture_text)[1])
summary['capture_received_by_filter']=int(re.search(r'(\d+) packets received by filter',capture_text)[1])
summary['capture_kernel_drops']=int(re.search(r'(\d+) packets dropped by kernel',capture_text)[1])
summary['gateway_gate_pass']=all(not any(o.get(k) for k in ('Error','NonCanonical','SocketDrops','SendErrors','MissingTimestamps')) and o['MaxIngressLagNS']<=5000000 and o['MaxEgressLagNS']<=5000000 and not o['Stats']['PropagationOverflow'] for o in gateway['Observations'])
summary['pass']=not any(outcomes.values()) and summary['gateway_gate_pass'] and summary['steady_ip_mbps_excluding_first_second']>=990 and not summary['capture_kernel_drops'] and summary['capture_received_by_filter']==summary['filtered_probe_packets'] and summary['filtered_probe_packets']==summary['received'] and all(v['no_growth'] for v in summary['host_counters'].values()) and all(not r.get('Error') and not r['Invalid'] and not r['Duplicate'] for r in receivers)
(root/(name+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
if not summary['pass']:raise SystemExit('Reverse capacity calibration invalid')
