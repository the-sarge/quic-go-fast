import pathlib,subprocess,os,signal,json
r=pathlib.Path(__file__).resolve().parent
outcomes={}
def run(args,name,bound):
 with (r/(name+'.txt')).open('w') as out:
  p=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=bound)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc=124
 print(name,rc,flush=True);outcomes[name]=rc;return rc
try:
 run(['python3',str(r/'dual-reverse-spaced-short.py')],'dual-reverse-spaced-short-driver',420)
 run(['python3',str(r/'followup-clock-observe.py'),'mac',str(r/'clock-spaced-short-after.json')],'spaced-short-clock-after',60)
finally:
 run(['ssh','-o','ConnectTimeout=10','minimax','sudo bash /tmp/q1-gateway-network.sh down'],'spaced-short-gateway-down',30)
 (r/'spaced-short-run-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
if any(outcomes.values()):raise SystemExit(1)
