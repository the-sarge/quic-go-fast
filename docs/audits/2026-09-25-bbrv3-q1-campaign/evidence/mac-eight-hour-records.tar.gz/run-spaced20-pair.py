import pathlib,subprocess,os,signal,json
r=pathlib.Path(__file__).resolve().parent;outcomes={}
def run(args,name,bound):
 with (r/(name+'.txt')).open('w') as out:
  p=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=bound)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc=124
 print(name,rc,flush=True);outcomes[name]=rc;return rc
for direction,script in [('reverse','dual-reverse-spaced20.py'),('forward','dual-forward-spaced20.py')]:
 name='spaced20-'+direction
 try:
  if run(['ssh','-o','ConnectTimeout=10','minimax','sudo bash /tmp/q1-gateway-network.sh up'],name+'-gateway-up',20):break
  if run(['python3',str(r/'followup-clock-observe.py'),'mac',str(r/('clock-'+name+'-before.json'))],name+'-clock-before',60):break
  rc=run(['python3',str(r/script)],name+'-driver',420)
  run(['python3',str(r/'followup-clock-observe.py'),'mac',str(r/('clock-'+name+'-after.json'))],name+'-clock-after',60)
  if rc:break
 finally:
  run(['ssh','-o','ConnectTimeout=10','minimax','sudo bash /tmp/q1-gateway-network.sh down'],name+'-gateway-down',30)
  (r/'spaced20-pair-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
if any(outcomes.values()):raise SystemExit(1)
