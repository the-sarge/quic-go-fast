#!/bin/bash
# Q1-only local path setup. Run with sudo; no default route or offload changes.
# up <mini|mbp> adds one IPv4 alias and one host route; down reverses them.
set -euo pipefail
mode=${1:-status}
endpoint=${2:-}
case "$endpoint" in
  mini) nic=bridge0; addr=10.64.1.10; peer=10.64.2.10; gateway=10.64.1.1 ;;
  mbp) nic=en8; addr=10.64.2.10; peer=10.64.1.10; gateway=10.64.2.1 ;;
  *) echo 'usage: sudo bash q1-mac-network-8h.sh <up|down|status> <mini|mbp>' >&2; exit 2 ;;
esac
state=/var/run/quic-q1-network
case "$mode" in
  status) /sbin/ifconfig "$nic"; /sbin/route -n get "$peer"; exit ;;
  up|down) [ "$EUID" -eq 0 ] || { echo 'root is required for scoped alias/route changes' >&2; exit 1; } ;;
  *) exit 2 ;;
esac
if [ "$mode" = down ]; then
  [ -f "$state/owner" ] || { echo 'No owned Q1 network state'; exit 0; }
  [ "$(cat "$state/owner")" = "$endpoint" ] || { echo 'Unexpected owner' >&2; exit 1; }
  /sbin/route -n delete -host "$peer" "$gateway"
  /sbin/ifconfig "$nic" inet "$addr" -alias
  rm "$state/owner" "$state/generation"
  rmdir "$state"
  exit
fi
[ ! -e "$state" ] || { echo 'Q1 network state already exists; inspect or clean it first' >&2; exit 1; }
if /sbin/ifconfig -a | /usr/bin/grep -Eq 'inet 10\.64\.[12]\.'; then
  echo 'Campaign address range already in use; no changes made' >&2; exit 1
fi
if /usr/sbin/netstat -rn -f inet | /usr/bin/grep -Eq '^10\.64\.[12](\.|[[:space:]])'; then
  echo 'Campaign route range already in use; no changes made' >&2; exit 1
fi
/sbin/ifconfig "$nic" >/dev/null
umask 077
mkdir "$state"
alias_added=0
route_added=0
rollback() {
  [ "$route_added" = 0 ] || /sbin/route -n delete -host "$peer" "$gateway" || true
  [ "$alias_added" = 0 ] || /sbin/ifconfig "$nic" inet "$addr" -alias || true
  rm -f "$state/owner" "$state/generation"
  rmdir "$state" || true
}
trap rollback ERR
/sbin/ifconfig "$nic" inet "$addr" netmask 255.255.255.0 alias
alias_added=1
/sbin/route -n add -host "$peer" "$gateway"
route_added=1
printf '%s\n' "$endpoint" > "$state/owner"
generation=$(/usr/bin/uuidgen)
printf '%s\n' "$generation" > "$state/generation"
trap - ERR
# Freeze the cleanup commands now; no delayed execution of this writable file.
/usr/bin/nohup /bin/bash -c '
  /bin/sleep 28800
  [ -f "$1/generation" ] && [ "$(/bin/cat "$1/generation")" = "$2" ] || exit 0
  /sbin/route -n delete -host "$3" "$4"
  /sbin/ifconfig "$5" inet "$6" -alias
  /bin/rm "$1/owner" "$1/generation"
  /bin/rmdir "$1"
' q1-network-expiry "$state" "$generation" "$peer" "$gateway" "$nic" "$addr" >/var/log/quic-q1-network-expiry.log 2>&1 </dev/null &
/sbin/route -n get "$peer"
printf 'Q1 path installed with automatic cleanup in eight hours. For early cleanup run: sudo bash %q down %q\n' "$0" "$endpoint"
