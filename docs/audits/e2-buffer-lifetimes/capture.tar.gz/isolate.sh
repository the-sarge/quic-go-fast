#!/usr/bin/env bash
set -euo pipefail
for slice in machine.slice system.slice user.slice; do
 [[ -z $(systemctl show "$slice" --property=AllowedCPUs --value) ]] || exit 1
done
[[ ! -e /run/qgf-e2-cpu-reservation && ! -e /run/qgf-e1-cpu-reservation && ! -e /run/qgf-e1-four-core-cpu-reservation ]] || exit 1
touch /run/qgf-e2-cpu-reservation
restore() {
 local failed=0
 for slice in machine.slice system.slice user.slice; do
  systemctl set-property --runtime "$slice" AllowedCPUs= || failed=1
 done
 if (( failed == 0 )); then
  rm /run/qgf-e2-cpu-reservation
  systemctl stop qgf-e2-cpu-restore.timer || true
 fi
 systemctl show user.slice system.slice machine.slice -p Id -p AllowedCPUs > /home/josh/.cache/qgf-e2/restoration.txt
 return "$failed"
}
trap restore EXIT
trap 'exit 130' INT TERM HUP
systemd-run --unit=qgf-e2-cpu-restore --on-active=5m --timer-property=AccuracySec=1s /bin/bash -c 'for slice in machine.slice system.slice user.slice; do systemctl set-property --runtime "$slice" AllowedCPUs= || exit 1; done; rm -f /run/qgf-e2-cpu-reservation'
for slice in machine.slice system.slice user.slice; do
 systemctl set-property --runtime "$slice" AllowedCPUs=0-7,12-23,28-31
done
systemd-run --collect --wait --pipe --unit=qgf-e2-capture --slice=qgf-e2.slice --property=User=josh --property=AllowedCPUs=0-11 --property=RuntimeMaxSec=240 --setenv=PATH=/usr/local/bin:/usr/bin:/bin /usr/bin/taskset -c 0 /usr/bin/python3 /home/josh/.cache/qgf-e2/collect.py
