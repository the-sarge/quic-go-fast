import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/josh/.cache/qgf-e2'); out=root/'bench-01';out.mkdir()
os.sched_setaffinity(0,{0})
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(cmd,**kw): return subprocess.check_output(cmd,text=True,**kw).strip()
env=dict(os.environ,GOMAXPROCS='4',GOFLAGS='',GOEXPERIMENT='')
r=dict(controller_affinity=sorted(os.sched_getaffinity(0)),go=check(['go','version']),env={k:env[k] for k in ('GOMAXPROCS','GOFLAGS','GOEXPERIMENT')},source={},steps=[])
for v in ('base','candidate'):
 wd=Path('/Volumes/worktrees/quic-go-fast/e2-linux-'+v)
 assert not check(['git','status','--porcelain'],cwd=wd)
 r['source'][v]=dict(head=check(['git','rev-parse','HEAD'],cwd=wd),fixture_sha256=sha(wd/'send_queue_lifetime_bench_test.go'),binary_sha256=sha(root/(v+'-bench')))
assert r['source']['base']['fixture_sha256']==r['source']['candidate']['fixture_sha256']
r['cpu_layout']=check(['lscpu','-e=CPU,CORE,SOCKET,NODE'])
r['service_cgroup']=Path('/proc/self/cgroup').read_text()
monitor_log=(out/'mpstat.json').open('w')
monitor=subprocess.Popen(['taskset','-c','1','mpstat','-P','8-11,24-27','-o','JSON','1'],stdout=monitor_log)
r['monitor_affinity']=[1]
try:
 for pair in range(10):
  for v in (('base','candidate') if pair%2==0 else ('candidate','base')):
   cmd=['taskset','-c','8-11',str(root/(v+'-bench')),'-test.run=^$','-test.bench=^BenchmarkQueueLifetime$','-test.benchtime=1s','-test.benchmem']
   step=dict(pair=pair,variant=v,command=cmd,started=time.time())
   with (out/f'{pair:02}-{v}.log').open('w') as log:
    p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    # Wait only for taskset to establish the benchmark's affinity; no timing samples discarded.
    for _ in range(100):
     affinity=sorted(os.sched_getaffinity(p.pid))
     if affinity==[8,9,10,11]: break
     time.sleep(.001)
    step['observed_affinity']=affinity
    assert affinity==[8,9,10,11],affinity
    step['exit_code']=p.wait()
   step['finished']=time.time();r['steps'].append(step)
   (out/'manifest.json').write_text(json.dumps(r,indent=2)+'\n')
   print(pair,v,step['exit_code'],flush=True)
   assert step['exit_code']==0
finally:
 monitor.terminate();monitor.wait();monitor_log.close()
 (out/'manifest.json').write_text(json.dumps(r,indent=2)+'\n')
