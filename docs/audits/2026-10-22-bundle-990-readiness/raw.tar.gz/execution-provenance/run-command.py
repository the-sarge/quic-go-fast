"""Retain host coordination and one finite registered command's receipt."""
import json,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
root=Path(sys.argv[1]);label=sys.argv[2];cmd=sys.argv[3:]
assert root.name.startswith('quic-990-8095c722-') and label and '/' not in label and cmd
art=root/'.local/bundle-990-readiness';here=root/'docs/audits/2026-10-22-bundle-990-readiness'
ps=subprocess.check_output(['ps','-eo','pid,comm,args'],text=True)
workloads=[line for line in ps.splitlines()[1:] if any(s in line.split(maxsplit=2)[1].lower() for s in ['fixture','relay','garm','runner','qemu','wiremux'])]
vms=subprocess.run(['virsh','list','--name'],capture_output=True,text=True)
coord=dict(timestamp=datetime.now(timezone.utc).isoformat(),workloads=workloads,running_vms=vms.stdout,vm_exit=vms.returncode)
with (art/f'coordination-{label}.json').open('x') as f:json.dump(coord,f,indent=2)
assert not workloads and vms.returncode==0 and not vms.stdout.strip(),coord
start=datetime.now(timezone.utc).isoformat()
with (art/f'{label}-command.log').open('x') as log:
 p=subprocess.Popen(cmd,cwd=here,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 for line in p.stdout:log.write(line);log.flush();print(line,end='',flush=True)
 code=p.wait()
receipt=dict(label=label,start=start,end=datetime.now(timezone.utc).isoformat(),command=cmd,exit_code=code)
with (art/f'{label}-command.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt),flush=True);sys.exit(code)
