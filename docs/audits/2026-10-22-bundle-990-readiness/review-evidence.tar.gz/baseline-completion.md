# #887 acceptance complete

The operator's [option-C decision](https://github.com/the-sarge/quic-go-fast/issues/887#issuecomment-6354232820) is now cited in the [final committed and reviewed #990 registration](https://github.com/the-sarge/quic-go-fast/blob/05879c86bbbccd67a4eb2147d29e2f74a74fe8da/docs/audits/2026-10-22-bundle-990-readiness/README.md). [Registration acceptance, review/verification history and exact-head CI](https://github.com/the-sarge/quic-go-fast/issues/990#issuecomment-6355288141) complete the final acceptance item.

Blocking reference: default Reno at the intended release commit `8095c72244755f0c1e24f4158253bf09cfbe6e17`, before publication. Descriptive reference: frozen Reno `e4f322cbbfd4225a4b714e08ec19c958cccadcb0`, which cannot block. D3's reference identity is amended; raised flags against the new reference remain blocking. Publication is not a circular prerequisite for this reference, and the eventual tag must peel to the same candidate.

[#871's memory acceptance](https://github.com/the-sarge/quic-go-fast/issues/871#issuecomment-6354210729) precedes this decision. This closes the baseline-policy gate only; it grants no BBR advancement or exception, and #851 remains blocked by fresh #990 evidence and its operator decision.
