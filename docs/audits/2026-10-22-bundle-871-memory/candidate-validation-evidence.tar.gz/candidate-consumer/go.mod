module example.com/fast8-release-consumer

go 1.27.3

require github.com/quic-go/quic-go v0.62.0

require (
	github.com/quic-go/qpack v0.6.0 // indirect
	golang.org/x/crypto v0.58.0 // indirect
	golang.org/x/net v0.61.0 // indirect
	golang.org/x/sys v0.49.0 // indirect
	golang.org/x/text v0.43.0 // indirect
)

replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.7.0.20261022191336-8095c7224475
