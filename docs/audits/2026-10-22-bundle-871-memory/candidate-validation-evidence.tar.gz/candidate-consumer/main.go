package main
import (
 "context"
 "crypto/tls"
 "net/http"
 quic "github.com/quic-go/quic-go"
 "github.com/quic-go/quic-go/http3"
)
func main() {
 cfg := &quic.Config{EnableDatagrams: true}
 var _ func(context.Context, string, *tls.Config, *quic.Config) (*quic.Conn, error) = quic.DialAddr
 transport := &http3.Transport{QUICConfig: cfg}
 var _ http.RoundTripper = transport
 _ = transport.Close()
}
