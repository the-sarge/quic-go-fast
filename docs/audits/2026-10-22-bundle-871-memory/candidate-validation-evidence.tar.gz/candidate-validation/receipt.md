## Ordinary candidate validation complete (publication gates still open)

Candidate remains `8095c72244755f0c1e24f4158253bf09cfbe6e17`. All five required **main/push workflows at that exact SHA** succeeded, with all 17 individual jobs and their relevant steps inspected (conditional skips retained):

- [.github/workflows/lint.yml](https://github.com/the-sarge/quic-go-fast/actions/runs/39838225905) — success.
- [.github/workflows/integration.yml](https://github.com/the-sarge/quic-go-fast/actions/runs/39838225917) — success.
- [Build interop Docker image](https://github.com/the-sarge/quic-go-fast/actions/runs/39838225906) — success.
- [.github/workflows/unit.yml](https://github.com/the-sarge/quic-go-fast/actions/runs/39838225885) — success.
- [.github/workflows/cross-compile.yml](https://github.com/the-sarge/quic-go-fast/actions/runs/39838226050) — success.

Go1.26.10 and Go1.27.3 unit lanes passed on Linux, macOS and Windows. Linux full race and root-only socket tests passed; Windows reader-scoped race passed; macOS private-syscall opt-out read-slot tests passed. Integration passed Linux both Go versions (including Go1.27.3 race) and macOS/Windows Go1.27.3. Cross-compilation and the Darwin private-syscall opt-out builds passed; Android remains excluded and iOS is library-only. The interop image was built, not published.

Inspection preserves scope limits: Windows native managed handback, independent-peer ECN and external URO engagement tests skip without the required host-peer environment; historical consumer x64/Arm64 acceptance remains separate evidence. Full race is not run on macOS/Windows; Windows race is reader-scoped. Platform-specific/explicit campaign hooks and allocation-only race exclusions remain visible in the retained per-test skip list. A successful generic workflow does not prove native offload engagement or qualify BBR on macOS/Windows.

Fresh vulnerability scan at 2026-10-22T19:15:06Z: govulncheck@v1.7.0 built with Go1.27.3, host darwin/arm64, target linux/amd64, CGO off, `govulncheck -show verbose ./...`, exit0. Database https://vuln.go.dev updated 2026-10-21T00:27:29Z. It scanned 36 root packages, eight modules and Go1.27.3's standard library: zero reachable vulnerabilities and zero imported-package vulnerabilities. **GO-2026-5932** remains module-only in x/crypto v0.58.0's unmaintained OpenPGP package, which this source does not import or call. This fresh scan is separate from push lint's intentional govulncheck skip.

Separate application-owned consumer build passed for both QUIC and HTTP/3 using Go1.27.3 darwin/arm64, GOWORK=off and canonical `github.com/quic-go/quic-go` imports. Replacement resolves to `github.com/the-sarge/quic-go-fast@v0.62.1-fast.7.0.20261022191336-8095c7224475`; downloaded Origin.Hash equals the full candidate. Module sum `h1:cyDkfc8rl7Ly64TsR+RBvi7r/TffMMkDsQJCwJcHmeI=`; go.mod sum `h1:kzQzvSE26oBNHy1O/XK5lZY6fBE6ba5/o6+34xsu8v4=`. This is build verification, not a runtime or platform qualification campaign. The real-tag public module download/archive check and consumer rebuild remain required after immutable tagging.

Source minimum remains Go1.26.0, separate from shipping toolchain go1.27.3. Raw workflow/job metadata, inspected unit logs and hashes, scan output and separate application sources/commands are retained under `/tmp/quic-release-851-inspection/` for the evidence record. #871 registration PR #997 is awaiting independent review; no counted data. The separately recorded #996 package-server infrastructure failure still awaits the operator's retry decision. No tag/publication or advancement permission is claimed.
