# wiremux

wiremux is the GridSwarm connectivity context for getting two peers a direct or relayed wire without deciding who those peers are.

## Language

Datagram-bearing language below describes the implemented optional capability;
the reliable byte stream remains the required Wire plane.

The _Avoid_ entries below are scoped to the Wire domain language: "connection" and "session" are avoided as names for the Wire concept and its rendezvous roles. Technical uses of those words in their own layers remain sanctioned — the transport `Session` interface and the relay's accepted-connection rate limiting are the canonical examples.

**Wire**:
An authenticated encrypted carrier between paired peers whose required plane is a reliable byte stream, established either by transport upgrade or by retaining the reliable relay fallback. Upgrade outcome and carrier topology are distinct but constrained: a successful transport upgrade may be direct or relay-assisted, while retained reliable fallback is relay-assisted. A supporting established transport carrier may also expose the optional Datagram plane. Reliable fallback bytes use wiremux encrypted-channel framing; QUIC reliable bytes and Datagrams use the authenticated QUIC carrier on either a direct or TURN-assisted packet path. Datagrams never inherit the channel's sequencing, gap detection, or authenticated close frame.
_Avoid_: Connection, session

**Datagram**:
An optional unreliable-unordered atomic consumer message carried alongside the reliable stream on one established Wire carrier. One send produces at most one whole receive or no receive; it does not imply one UDP packet.
_Avoid_: Unreliable message, message pipe, packet

**Datagram handle**:
The concrete borrowed consumer view returned by `Wire.Datagrams()` when the established carrier supports Datagrams. It has no independent lifetime or close; the Wire owns it.
_Avoid_: Datagram connection, Datagram session

**Datagram carrier**:
The transport-side surface that carries the reliable Wire stream and Datagrams under one authenticated carrier/session, congestion authority, and aggregate owner. A future carrier may migrate internally while preserving the contract, so carrier identity does not permanently mean one route; v1 `transport/quic` remains bound to the selected remote and does not enable migration or rebinding.
_Avoid_: Direct path, UDP socket, logical multipath Wire

**Maximum Datagram payload**:
The lifetime-fixed exact number of local-outbound consumer payload bytes a Datagram handle accepts after wiremux framing. It governs send admission, not inbound delivery, a path MTU, or a delivery guarantee.
_Avoid_: MTU, native Datagram size

**Wire dialer**:
The consumer entry-point module that turns a relay endpoint, rendezvous identifier, and identity handshake into a wire.
_Avoid_: Facade, client

**Identity handshake**:
The step in which an identity layer produces a wiremux `AuthContext` over the paired relay stream.
_Avoid_: Transport handshake material

**Auth context**:
The per-wire cryptographic capability produced by an identity handshake and consumed by wiremux to key one encrypted carrier and its transport upgrade.
_Avoid_: Peer identity, transport handshake material

**Auth-context ownership**:
Responsibility for releasing an auth context's retained cryptographic material. A direct identity-handshake caller owns each context it receives; the Wire dialer owns contexts returned to it, and an established Wire carries that responsibility until aggregate teardown.
_Avoid_: Shared cleanup, borrowed auth context

**Channel-use claim**:
An irreversible reservation by a claim-capable auth context for one encrypted channel initialization. It is distinct from inspecting or deriving context material and does not itself end the auth context's lifetime.
_Avoid_: Key read, context close

**Candidate**:
A network address a peer can offer as a possible transport packet path to itself. A candidate may describe a directly discovered address or a relay-assisted address; it does not prove reachability, which is established later by probing and upgrade.
_Avoid_: Proven path, connection

**Host candidate**:
A candidate for an address directly assigned to the local peer.
_Avoid_: Local path

**Reflexive candidate**:
A candidate for the peer's externally observed address as reported by STUN.
_Avoid_: Public path, STUN path

**Relay candidate**:
A candidate representing a packet path through an allocated relay rather than a directly discovered address. It is distinct from the already-open reliable relay stream and must remain bound to the allocation and packet-resource owner that produced it.
_Avoid_: Reliable relay fallback, reflexive candidate

**Candidate gathering**:
The step where a peer collects addresses it can offer as possible transport packet paths. Direct gathering collects host and reflexive candidates; relay allocation is a separate resource-producing step. Neither step proves that an offered address is reachable.
_Avoid_: Probe, punch

**Carrier topology**:
The physical shape of an established Wire carrier: direct when an upgraded packet path travels peer to peer with two candidate kinds independently chosen from `{host, reflexive}` in any order or combination, or relay-assisted when the Wire uses either the retained reliable rendezvous-relay stream or an upgraded relay/relay TURN packet path. A mixed pair means exactly one relay candidate and one non-relay candidate and is invalid. Topology is distinct from upgrade outcome and Datagram capability, but the valid shapes are constrained: successful upgrade may be direct or relay-assisted; reliable fallback is always relay-assisted.
_Avoid_: Upgrade outcome, Datagram capability

**`Wire.Direct()` legacy outcome**:
The compatibility-preserved shorthand reporting that transport upgrade succeeded (`UpgradePathDirect`), not that the physical topology is direct. It remains true for QUIC-over-TURN and is not carrier-topology, Datagram-capability, or ownership authority; use `Wire.CarrierTopology()` for the physical shape.
_Avoid_: Direct topology test, Datagram capability test

**TURN retry**:
The compatibility-negotiated transport-upgrade attempt entered only after the frozen direct candidate probe has failed before commit. It allocates TURN/UDP packet paths, authenticates and selects a relay/relay pair, and either commits the existing end-to-end transport on that pair or, after an ordinary precommit failure and successful terminal synchronization, returns to the already-open reliable relay fallback. Outer-context termination and failed control synchronization are terminal errors rather than fallback outcomes. The existing commit, any-non-nil-stream, and no-fallback finality rules govern the selected TURN composite; the direct packet-socket root marker remains specific to the borrowed direct socket and is never used for TURN ownership.
_Avoid_: ICE session, WebRTC transport, TURN/TCP fallback

**TURN packet composite**:
The relay packet-path resource, also shortened to TURN composite, that exclusively owns one dedicated TURN/UDP socket and coordinates its readiness, interruption, and aggregate disposal until ownership transfers to an established transport stream. Its underlying TURN library may own protocol state and internal workers, but it never shares socket-close or deadline authority with that library.
_Avoid_: Pion allocation, shared TURN socket, context writer

**Probe**:
A bounded, authenticated attempt to prove that a specific pair of offered candidates can carry packets between peers. A probe happens after candidate gathering and before transport upgrade.
_Avoid_: Candidate, discovery

**Authenticated probe**:
A UDP probe request or response whose HMAC validates against exporter-derived per-upgrade probe material and the exact probed candidate pair transcript. Cleartext probe headers and candidate-pair tokens are routing hints, not proof.
_Avoid_: Magic packet, unauthenticated punch

**Probe dialect**:
The set of wire parameters that distinguishes the v1 direct probe from the TURN-retry probe — datagram magic, key-derivation label, admitted candidate kinds, and whether a datagram from the other dialect is rejected or ignored. Scheduling, retransmission, and authentication are dialect-independent.
_Avoid_: Probe profile, probe version, wire profile

**Candidate-pair token**:
A short cleartext routing hint in a UDP probe datagram, derived from the per-upgrade probe key, token version, probe direction, and encoded source/destination candidate pair. The token helps find candidate-pair state but is not proof of reachability; only the authenticated probe transcript is proof.
_Avoid_: Probe proof, candidate identity

**Selected candidate pair**:
The candidate pair chosen after probing and synchronized through upgrade control as the only packet path handed to the transport. In the implemented v1 direct profile, each of the two candidate kinds independently belongs to `{host, reflexive}`, so host/host, host/reflexive, reflexive/host, and reflexive/reflexive are all direct shapes; the separately negotiated TURN retry profile may select only relay/relay. The established transport carrier—including its reliable stream and optional Datagram views—stays bound to the selected pair for its lifetime.
_Avoid_: Migrated path, alternate accepted path

**Transport stream**:
The transport-returned `io.ReadWriteCloser` that exclusively carries disposal responsibility for its parent transport connection and selected packet-path resource after ownership transfers. Its existing Close method synchronously completes bounded transport and exact-resource cleanup; after handoff it becomes the reliable plane of the Wire. For the default QUIC transport, a normal remote parent close becomes graceful EOF only when the final receive offset is known and the caller has received every byte through it; earlier teardown preserves a non-EOF transport error.
_Avoid_: Bare stream, shared socket owner

**Direct upgrade convergence**:
The outcome where both peers complete direct transport on the same selected candidate pair. A direct-path upgrade result is valid only when both peers converge; one peer on direct transport while the other remains on relay or fails is not convergence.
_Avoid_: Partial direct success, dialer-only upgrade

**Listener transport readiness**:
The listener's declaration that it has prepared direct transport on the selected candidate pair and is ready for the dialer to commit. After signaling readiness, the listener waits for an incoming transport connection while the dialer may still be sending commit.
_Avoid_: Probe success, selected pair announcement

**Direct upgrade commit point**:
The role-specific phase boundary after which direct transport failure no longer falls back to relay: the dialer commits after `ready`, writing `commit`, and starting `Session.Dial`; the listener commits after receiving `commit` or observing authenticated transport progress. Any non-nil stream returned by `Session.Dial` or listener `TransportListener.Accept`, including stream-plus-error, is an independent no-fallback boundary even before local commit. After the applicable boundary, setup must complete or return a transport error with no active stream.
_Avoid_: Fallback window, probe phase

**Packet-socket ownership transfer**:
The point where exclusive responsibility for closing a direct-upgrade packet socket moves from the caller to wiremux. For the lower outcome-dependent contract, transfer occurs when the local direct commit boundary is crossed or `Session.Dial`/listener `TransportListener.Accept` returns any non-nil stream, including stream-plus-error, whichever applies first. Before transfer, the caller remains responsible when that direct socket is not selected, including reliable fallback and TURN-assisted upgrade; after transfer, wiremux is responsible on every terminal path, ownership never returns, and later failure cannot produce relay fallback. Root packet settlement reads only the monotonic transfer fact, never an error tree. Ownership is never shared.
_Avoid_: Shared socket ownership, automatic cleanup

**Packet-socket origin**:
Which party a direct-upgrade packet socket came from — caller-owned, transferred by the caller to the Wire dialer, or created internally by the Wire dialer. Origin is fixed when the upgrade is prepared and is combined only with the monotonic transfer fact to decide who closes the socket on each terminal path and whether a failed dial reports that the socket was transferred.
_Avoid_: Socket mode, ownership flag

**Packet-I/O permission**:
An explicit grant from a packet resource's owner allowing specified optimized packet operations during an exclusive transport-use interval. It is distinct from responsibility for closing the resource and from the platform's ability to perform those operations.
_Avoid_: Socket ownership, inferred capability

**Managed packet endpoint**:
A reusable packet resource that preserves ordinary datagram behavior across transport-use intervals while retaining responsibility for its underlying socket and receive format. It is distinct from a raw socket returned without an enduring receive-format owner.
_Avoid_: Shared transport socket, raw socket handback

**Packet-I/O lease**:
The exclusive per-attempt packet resource borrowed from a managed packet endpoint. Ending the lease releases that interval; ending the parent endpoint ends the underlying resource.
_Avoid_: Shared socket owner, endpoint disposal

**Transport phase failure**:
Direct transport setup that fails after the applicable local ownership boundary: local commit or any non-nil stream returned by `Session.Dial`/listener `TransportListener.Accept`. Both peers must end with a transport error and no active stream; asymmetric success is not a valid outcome.
_Avoid_: Partial transport success, late relay rescue

**Split-brain transport state**:
An invalid outcome where one peer believes direct transport succeeded while the other did not converge. Implementations must detect and fail split-brain before the terminal convergence acknowledgement; the protocol narrows the irreducible final `confirmed` window, where a returned direct stream can still fail fast if the peer aborts before observing that acknowledgement.
_Avoid_: Partial direct success, asymmetric upgrade

**Pre-commit transport window**:
The listener phase after signaling readiness but before local commit. Failures before both local commit and any non-nil `TransportListener.Accept` stream may still fall back to relay and are not transport phase failures. Local commit and any non-nil `Accept` stream, including stream-plus-error, are independent packet-socket ownership boundaries: crossing either prevents relay fallback, and validation failure of a materialized connection is terminal even if commit has not yet been observed.
_Avoid_: Post-commit phase, probe phase

**Transport handshake material**:
Opaque authentication material a transport session gives the negotiator to carry over the authenticated upgrade channel before direct transport setup. The selected transport defines its meaning; identity layers do not.
_Avoid_: Identity proof, transport policy

**Ephemeral transport certificate**:
A per-upgrade self-signed certificate used by a transport to prove possession of channel-delivered handshake material. In wiremux, it is not a peer identity, account identity, or WebPKI claim.
_Avoid_: Peer identity certificate, CA certificate

**Candidate policy**:
Caller-supplied, per-peer preference or exclusion rules for local candidate advertisement and remote candidate probing. Remote candidates are authenticated peer offers, not egress permission; valid unicast remote ranges are not default-blocked and are constrained with `CandidatePolicy.ExcludeRemotePrefixes` or `CandidatePolicy.DeprioritizeRemotePrefixes`. Candidate policy is not exchanged with the peer; only the coarse `policy_excluded` fallback reason may cross the wire.
_Avoid_: Identity policy, ACL, proof

**Interface selection**:
A caller's explicit choice of a local OS network interface to constrain supported wiremux operations. It is distinct from the selected candidate pair, the interface's name, and the physical network provider.
_Avoid_: Selected peer, provider identity

**Upgrade fallback reason**:
Coarse result metadata explaining why a relay-path result was selected. Fallback reasons are synchronized through upgrade control and resolved with deterministic precedence; they are not peer blame or fine-grained diagnostics.
_Avoid_: Fault attribution, remote policy

**Fallback-reason phase**:
The control exchange in which a coarse fallback reason may lawfully cross the wire: the first-phase offer exchange, the direct terminal fallback exchange, or the TURN-retry terminal fallback exchange. Phase admissibility is a fact of the one fallback-reason definition table; a reason outside its phase is treated as a protocol mismatch, not widened.
_Avoid_: Reason subset, TURN reason list, codec allowlist

**Terminal fallback exchange**:
The synchronized control exchange in which both peers settle a relay-path outcome: each sends its coarse upgrade fallback reason and awaits the peer's, resolving one reason by deterministic precedence. If the peer's commit is observed instead of a fallback reason, the exchange is past the direct upgrade commit point and must fail closed rather than settle on relay.
_Avoid_: Error report, blame exchange

**Waiting peer**:
A peer parked at the relay awaiting its counterpart under a shared rendezvous identifier. A waiting peer is tracked in the rendezvous ledger until it is paired, times out, expires, is consumed, or disconnects.
_Avoid_: Client, session

**Ephemeral SessionID consumption**:
The root `wiremux.Dial` best-effort request that marks an ephemeral relay `SessionID` unusable after successful local upgrade, after eligible identity failure, or after a post-success failure for a one-shot rendezvous authenticator. Explicit rendezvous disposition markers override the default identity-failure heuristic: `spent` consumes with the without-cancel default budget and `retryable` does not consume. Context cancellation, deadline identity failures, and relay I/O closure during unmarked identity leave the `SessionID` retryable when the error tree is purely retryable, including contextual wrappers or joins whose leaves are all relay I/O. Unmarked terminal identity/authentication errors consume after pairing when the heuristic confirms a non-I/O domain/authentication leaf; if they carry relay I/O, they must also carry that non-I/O leaf. One-shot post-success auth-context validation, channel, upgrade, and nil-stream failures also attempt consume with the without-cancel default budget. Failed consume can leave the `SessionID` reusable until normal expiry.
_Avoid_: Session deletion, identity revocation

**Rendezvous disposition**:
The error-tree declaration of whether a failed wire-establishment outcome spent
an ephemeral rendezvous identifier. Disposition values are `unknown`, `spent`,
and `retryable`. Identity layers can declare a verdict, and root `wiremux.Dial`
also synthesizes `spent` after a successful one-shot identity handshake when
auth-context validation, channel setup, upgrade, or nil-stream validation
fails. `Unknown` reserves the default identity-failure consume heuristic.
Disposition is not itself relay ledger consumption and does not identify the
failure stage; callers combine `connect.RendezvousDisposition` with Dial stage
sentinels such as `wiremux.ErrIdentity`, `wiremux.ErrChannel`, and
`wiremux.ErrUpgrade`. When a canceled or expired non-one-shot authenticator
returns `(nil, nil)`, Dial retains both the context error and
`connect.ErrNilAuthContext` while disposition remains unknown and the
rendezvous remains reusable, including a long-lived PeerID rendezvous without
an ephemeral consume coordinator.
_Avoid_: Session consumption, ledger deletion, peer deregistration

**One-shot rendezvous**:
An identity scheme capability, expressed by `connect.OneShotRendezvous`, whose
successful handshake spends the ephemeral rendezvous identifier even if a
later wire-establishment stage fails. A one-shot authenticator that returns
`(nil, nil)` has signaled success but violated the non-nil auth-context
contract, so root `wiremux.Dial` treats `connect.ErrNilAuthContext` as a spent
post-success failure. Objects, adapters, or auth contexts that can be used at
most once are instead described as `single-use`.
_Avoid_: One-use adapter, one-shot auth context

**Rendezvous pairing**:
The relay matching two waiting peers that presented the same rendezvous identifier in the same mode, then forwarding opaque bytes between their two connections. A rendezvous pairing joins two peer connections at the relay; it is not a selected candidate pair, whose two authenticated transport-path candidates independently use host or reflexive kind for direct v1 or both use relay kind for TURN retry.
_Avoid_: Candidate pair, connection pair

**Paired relay**:
A rendezvous pairing's relay stream held before authentication, across which peers may exchange bounded setup records before one authentication or abandonment. Abandoning a paired relay before authentication never spends its rendezvous; authenticating it follows the ordinary establishment and consumption rules. G-30 plans call this a relay candidate.
_Avoid_: Relay candidate (a TURN packet-path candidate), pre-auth Wire

**Native endpoint**:
The owner of one binding set, one QUIC transport per binding, the candidate-authority group spanning them and the shared setup budget, which produces native candidates by dialing numeric peers or accepting incoming connections.
_Avoid_: Native listener (it also dials), native session

**Native candidate**:
One encrypted native QUIC connection before authentication, with the dialer's single setup stream, a copied binding provenance and the local TLS channel binding. It ends by promotion, abandonment, selection of another candidate, its absolute setup deadline or its endpoint's close; it never carries application data before promotion.
_Avoid_: Relay candidate (a TURN packet-path candidate), native Wire

**Native promotion**:
Turning a selected native candidate, with its own authentication result, into a Wire on the same QUIC connection and stream: one authenticated channel, the receive phase opened, native-ready exchanged in both directions and the setup reservation transferred.
_Avoid_: Native upgrade (no upgrade negotiation happens), handoff

**Native-ready**:
The authenticated setup record, sent as exactly one channel frame after the sender opened its receive phase, that binds the connection's channel binding and native profile. A peer's native-ready may arrive before or after the local receive phase opens; application bytes may not.
_Avoid_: Ready (GridCast's Transfer-activation Ready is a different record)

**Peer refusal**:
A binding's admission decision that one peer may not be sent to or received from, because the peer's address or the route facts for it do not satisfy the binding's mode; a route that cannot be looked up does not satisfy it. The binding and its other peers are unaffected.
_Avoid_: Policy error, rejection

**Binding outage**:
A state in which a binding admits no datagrams because its interface is down, its own source address is unassigned or not yet usable to send from, or its interface cannot be inspected. Unlike binding loss it never makes the binding stale; it ends only when admission again finds the interface up and the binding's own source address assigned and usable, which may never happen.
_Avoid_: Binding interruption, source loss, unavailable binding

**Binding loss**:
The permanent end of a binding because its selected interface was removed or replaced; the binding's handle stays stale from then on.
_Avoid_: Stale binding, fatal admission failure

**Never-blocking goroutine**:
A goroutine that runs without ever waiting on a channel, lock, timer, system call or network I/O. One that waits even briefly in each period is not one.
_Avoid_: Busy goroutine (one busy most of each period may still wait), spinner (another program's load)

**Processor headroom**:
At least one of a process's Go processors (`GOMAXPROCS`) not held by a never-blocking goroutine. A native Wire's rate assumes it.
_Avoid_: Free core, spare CPU (the rule counts Go processors, not cores)

**Rendezvous ledger**:
The relay's single authority over waiting, paired, and registered rendezvous state. The ledger both tracks that state and owns pair resolution; it does not read or write peer connections itself.
_Avoid_: Pool, registry

**Pair resolution**:
The rendezvous ledger settling a waiting peer's outcome exactly once — paired, timed out, expired, consumed, or disconnected. The right to resolve a waiting peer is granted by winning its removal from the ledger's waiting state under the lock; that removal, not any channel send, is the "once". A waiting peer's own goroutine may resolve itself (timeout) by writing its own connection and sending nothing on the channel; a different goroutine resolves it across goroutines by delivering on the result channel.
_Avoid_: Notification, delivery

**Session consumption**:
The relay retiring an ephemeral session identifier once its wire outcome is settled, so the same identifier cannot pair again. The wire dialer requests consumption best-effort after direct upgrade convergence, when a relay-path wire closes, after marked-spent or unmarked heuristic terminal identity failure, or after one-shot post-success auth-context validation, channel, upgrade, or nil-stream failure. A failed consumption attempt does not fail the wire.
_Avoid_: Session close, wire teardown

**Abuse signal**:
The relay's per-SessionID judgment that a settled ephemeral rendezvous outcome looks like online guessing or a short-lived probe, which accumulates into backoff for later dials of the same SessionID. Outcomes the relay caused itself, such as shutdown or quiesce, are never abuse signals, and the judgment is distinct from the backoff mechanism that acts on accumulated signals.
_Avoid_: Abuse event, rate limit, peer blame

**Relay-assist stream**:
The forwarded byte stream between the two peers of one rendezvous pairing, counted as a single unit in both directions. It is the unit that relay-side shaping applies to; the relay pays for it and neither peer can split or disown it.
_Avoid_: Session, connection, source, proxy

**Relay-assist shaping policy**:
The relay's single owner of the per-stream ceiling, the global fair share, the monthly egress breaker, and the breaker's persisted total. It is applied all-or-nothing when the relay starts and when its values reload; every forwarding path consults it and no caller sequences its parts.
_Avoid_: Throttle config, rate limiter, egress meter

**Assist grant**:
The rendezvous ledger's claim-time decision, minted together with the pairing, of whether a rendezvous pairing keeps its relay-assist stream or has it withheld. A grant carries the cause of withholding and the byte-and-time allowance that bounds a withheld pairing; it is a value the pairing consumes, never an owner of connection I/O.
_Avoid_: Withheld flag, refusal, shedding bool

**Establishment settlement**:
The Wire dialer's single authority over the outcome of one wire-establishment attempt. Every attempt is settled exactly once — either a declared stage failure or the success handoff that passes auth-context ownership to the established Wire — and settlement derives the consequences in their required order: auth-context release, transport-upgrade cleanup, session consumption, closing the current relay carrier, and one-shot rendezvous marking. Stages declare what happened; settlement decides what follows.
_Avoid_: Cleanup helper, error handler, dial teardown

**Aggregate teardown**:
The Wire's single ordered shutdown of both planes: seal the Datagram gate, revoke the auth context, close the reliable carrier, drain the Datagram handle's in-flight work, release the auth context. It starts exactly once — from an explicit close or from the first plane fault — and the planes only report faults; the Wire orders everything else.
_Avoid_: Datagram close, carrier teardown, cleanup

**HTTP-01 listener**:
The optional plain-HTTP listener (`--acme-http-listen`, default `:80`) that answers ACME HTTP-01 challenges. It exists only for issuance; relay traffic never uses it. An empty address disables it, making 443-only an explicit posture rather than a firewall accident.
_Avoid_: ACME port, challenge server, port 80 requirement

**TLS-ALPN-01**:
The ACME challenge answered on the relay listener itself: the certificate authority opens a TLS connection with the `acme-tls/1` ALPN protocol and the relay's certificate callback presents a challenge certificate. The relay's TLS normalisation must preserve that protocol; the in-suite Pebble coverage guards it.
_Avoid_: ALPN fallback, implicit challenge

**ACME directory**:
The `https://` URL of the certificate authority's ACME directory that the relay's certificate manager registers with and orders certificates from. Set with `--acme-directory-url` (or `relay.WithACMEDirectoryURL`); absent, it is Let's Encrypt production. Pointing it at Let's Encrypt staging rehearses a cutover without spending production rate-limit budget; pointing it at another CA is the only vendor surface.
_Avoid_: CA mode, provider, Let's Encrypt flag

**External Account Binding (EAB)**:
The pre-issued key identifier plus HMAC key some ACME CAs require to tie a new ACME account to an existing customer account. The identifier is a flag (`--acme-eab-kid`); the HMAC key is read from an absolute file path (`--acme-eab-hmac-key-file`) as base64url and never passed as a flag value or logged. Both or neither must be set.
_Avoid_: API key, account token, EAB secret flag

## Example Dialogue

Dev: "The peer gathered a reflexive candidate from STUN. Can we assume the direct path works?"

Domain expert: "No. The candidate is only an offered address. The later probing step decides whether it is reachable."

Dev: "Should gathering return a relay candidate because the peers already have a relay stream?"

Domain expert: "No. Direct gathering returns host and reflexive addresses. A relay candidate comes from a separately owned packet-relay allocation, and the already-open reliable fallback is represented separately from both."

Dev: "Does gathering prove the peer can reach us directly?"

Domain expert: "No. Gathering only collects possible addresses. Probing decides whether any of them work."

Dev: "The peer offered a reflexive candidate. Is that the same as a successful probe?"

Domain expert: "No. The reflexive candidate is the address to try. The probe is the attempt that proves whether it works."

Dev: "The peers can see each other over a VPN. Should wiremux always use that host candidate?"

Domain expert: "By default it may try host candidates first, but the caller can apply a candidate policy to avoid or deprioritize VPN paths."

Dev: "Can the receiver trust a probe because it has the right cleartext token?"

Domain expert: "No. The token can route the packet to candidate-pair state, but only the authenticated probe transcript proves reachability."

Dev: "The result says `policy_excluded`. Does that tell us the peer's policy?"

Domain expert: "No. It is a coarse fallback reason selected by the protocol, not a disclosure of policy rules or interface names."

Dev: "Probing selected a candidate pair. Is that the same as the relay pairing two peers?"

Domain expert: "No. A rendezvous pairing matches two peer connections at the relay so it can forward bytes. A selected candidate pair is the authenticated packet path handed to transport: each candidate is independently host or reflexive for direct v1, or both are relay for TURN retry. Different layers, different lifetimes."

Dev: "The dialer got a direct stream but the listener timed out. Did direct upgrade succeed?"

Domain expert: "No. Direct upgrade converges pairwise or not at all. One peer alone on direct transport is not a successful upgrade."

Dev: "The listener has prepared transport but hasn't sent ready yet. Should it already be waiting for the incoming connection?"

Domain expert: "After preparing `Listen` on the selected pair, begin `Accept` and signal readiness. The listener keeps `Accept` pending while it writes `ready` and waits for `commit`."

Dev: "We're past commit and the dialer connected but the listener's accept timed out. Can one side return direct while the other errors?"

Domain expert: "No. Transport phase failure is pairwise. Both peers must end with a transport error and no active stream."

Dev: "The listener timed out waiting for commit before the dialer sent it. Is that a transport phase failure?"

Domain expert: "Only before both local commit and any non-nil `TransportListener.Accept` stream. Crossing local commit transfers packet-socket ownership and prevents relay fallback; a non-nil `Accept` result is an independent transfer boundary even with an error, so later failure is terminal when commit has not yet been observed."

Dev: "I used `WithTransferredPacketConn`, but the dial returned a relay-path wire. Can I reuse the socket?"

Domain expert: "No. `WithTransferredPacketConn` means the caller abandons the socket when applying the option. Wiremux closes it on reliable fallback or a TURN outcome and manages its lifetime on direct success."

Dev: "What if I used `WithPacketConn` instead?"

Domain expert: "That socket stays caller-owned on pre-transfer reliable fallback and TURN outcomes. Direct success transfers it. On error, `ErrPacketConnTransferred` means the exact direct socket crossed commit or a non-nil-stream boundary and was disposed; without that sentinel it remains yours. Post-transfer direct failure never returns reliable fallback."

Dev: "Accept failed before commit and we want the relay path. Can we just return the relay stream?"

Domain expert: "No. Run the terminal fallback exchange: send our fallback reason and settle the peer's. And if the peer's commit races in during that exchange, fail closed — a peer that committed is past the point where relay is a valid outcome."

Dev: "The dialer got a local stream but the listener already aborted direct upgrade. Can the dialer still return direct?"

Domain expert: "No. The dialer must tear down the transport and fail pairwise rather than returning direct success alone."

Dev: "A waiting peer timed out at the same moment a dialer tried to pair with it. Who tells the waiting peer its fate?"

Domain expert: "Exactly one of them, and only through the rendezvous ledger. Pair resolution is the ledger's job: a waiting peer is resolved once — never twice, never zero times."

Dev: "Channel setup failed after the identity handshake succeeded. Which cleanup calls does the dial path make, and in what order?"

Domain expert: "The dial path doesn't choose. It declares the stage failure to establishment settlement, which owns the consequences and their order: release the auth context, clean up the transport upgrade, apply session consumption, close the current relay carrier, and mark a one-shot rendezvous spent."
