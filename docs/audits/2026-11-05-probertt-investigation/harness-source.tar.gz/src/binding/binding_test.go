//go:build linux || darwin || windows

package binding_test

import (
	"context"
	"errors"
	"net"
	"net/netip"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/binding"
	"github.com/GridSwarm/wiremux/selection"
)

func loopback(t *testing.T) selection.Handle {
	t.Helper()
	interfaces, err := net.Interfaces()
	if err != nil {
		t.Fatal(err)
	}
	for _, iface := range interfaces {
		if iface.Flags&net.FlagLoopback != 0 && iface.Flags&net.FlagUp != 0 {
			h, err := selection.Resolve(iface.Name)
			if err != nil {
				t.Fatal(err)
			}
			return h
		}
	}
	t.Fatal("loopback interface: got none, want one")
	return selection.Handle{}
}

// Native facts classify loopback as unknown: Local refuses it, while Direct
// binds it and carries real traffic through the admission owner.
func TestListenNativeLoopback(t *testing.T) {
	h := loopback(t)
	set, err := binding.Listen(context.Background(), binding.Config{Mode: binding.Local, Selections: []selection.Handle{h}})
	var none *binding.Error
	if set != nil || !errors.As(err, &none) || !errors.Is(err, binding.ErrPolicy) {
		t.Fatalf("local loopback: got %v, %v, want policy refusal", set, err)
	}

	set, err = binding.Listen(context.Background(), binding.Config{Mode: binding.Direct, Selections: []selection.Handle{h}})
	if err != nil {
		t.Fatal(err)
	}
	defer set.Close()
	var b *binding.Binding
	for _, candidate := range set.Bindings() {
		facts := candidate.Facts()
		if facts.Classification.Class != binding.Unknown || facts.Mode != binding.Direct {
			t.Fatalf("facts: got %+v, want unknown direct binding", facts)
		}
		if facts.Local.Addr() == netip.MustParseAddr("127.0.0.1") {
			b = candidate
		}
	}
	if b == nil {
		t.Fatalf("IPv4 loopback binding: got %v failures %v, want one", set.Bindings(), set.Failures())
	}
	_ = b.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, err := b.WriteTo([]byte("self"), b.Facts().Local); err != nil {
		t.Fatal(err)
	}
	msgs := []binding.Message{{Buffer: make([]byte, 16)}}
	if n, err := b.ReadBatch(msgs); err != nil || n != 1 || string(msgs[0].Buffer[:msgs[0].N]) != "self" || msgs[0].From != b.Facts().Local {
		t.Fatalf("receive: got %d %+v, %v, want self", n, msgs[0], err)
	}
	if _, err := b.WriteTo([]byte("x"), netip.MustParseAddrPort("224.0.0.1:9")); !errors.Is(err, binding.ErrPolicy) {
		t.Fatalf("multicast peer: got %v, want policy refusal", err)
	}
	if err := set.Close(); err != nil {
		t.Fatal(err)
	}
	if _, _, err := b.ReadFrom(make([]byte, 16)); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("receive after close: got %v, want closed", err)
	}
}
