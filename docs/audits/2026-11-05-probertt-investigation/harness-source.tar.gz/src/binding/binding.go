// Package binding opens interface-scoped unicast UDP bindings for native
// establishment. A binding set binds every current unicast address of the
// selected interfaces at one caller-chosen port and reports copied successes
// and per-interface or per-address failures. A failure never widens the port,
// interface or policy, and no binding falls back to an unrestricted socket.
//
// Every send, and every received datagram including each datagram of a batch,
// is admitted by the binding: its kernel receive interface is checked per
// datagram, and its peer against native facts — the selected interface
// identity and source address, and a route lookup restricted to the binding's
// interface. A peer's native-facts verdict is reused until the operating
// system next reports a network change (link, address, route or routing-rule
// notifications on Linux, routing-socket messages on macOS, route, address
// and interface notifications on Windows), and for at most one second. After a
// change the next datagram for that peer is admitted afresh. Once a verdict is
// one second old, one datagram for the peer is admitted afresh while
// concurrent datagrams for it reuse the expired verdict. Without a working
// notification channel every datagram is admitted afresh. A change takes
// effect once its notification is read. A change whose notification is lost,
// as an overflowing macOS routing socket loses them silently, takes effect
// within one second plus that one re-admission. Idle peers are never
// re-checked, and the sockets stay bound to their interface in the kernel
// throughout. Local mode admits only LAN-classified interfaces and peers
// reached by an on-link route; Direct mode also admits gateway routes, still
// only through the binding's interface. Datagrams failing admission are
// discarded before delivery. Addresses of the selected interface itself are
// always admitted.
//
// A failed admission is a peer refusal, a binding outage or binding loss. A
// peer refusal concerns one peer: the mode does not admit it, or its route
// lookup failed. A binding outage concerns every peer while the interface is
// down or cannot be inspected, or no longer holds the binding's source
// address. Either one discards the received datagram, and the receive
// continues, or fails just that send with its error (ErrPolicy, or
// selection's ErrUnavailable, ErrPermission or ErrUnsupported) and leaves the
// binding usable. An address-not-available send error that a fresh
// observation confirms as an outage fails the same way. A failed route lookup
// or interface inspection is retried at most once every 100 ms, a lookup
// sooner after a network change, and datagrams meanwhile are refused without
// a native query; an unassigned source is rechecked on every datagram. Only
// binding loss, the selected interface removed or replaced, fails receives
// and makes the binding permanently stale (selection.ErrStale).
//
// Linux, macOS, and Windows are supported for IPv4 and IPv6; other systems
// fail with selection.ErrUnsupported. The guarantee inherits selection's
// trusted current host configuration: route checks are preliminary native
// queries, not an atomic kernel guarantee against privileged route or
// interface replacement, interception, or tunnel underlay routing.
// Classification is copied native evidence, never routing authority.
package binding

import (
	"context"

	"github.com/GridSwarm/wiremux/internal/routeselection"
)

// Mode selects the destination policy of a binding set.
type Mode = routeselection.UnicastMode

const (
	// Local admits only LAN-classified interfaces and on-link peers.
	Local = routeselection.UnicastLocal
	// Direct admits routed peers through each binding's own interface.
	Direct = routeselection.UnicastDirect
)

// Class is a native interface classification.
type Class = routeselection.InterfaceClass

const (
	// Unknown means native facts did not positively classify the interface.
	// Loopback and unrecognized adapter kinds are unknown.
	Unknown = routeselection.ClassUnknown
	// LAN is a directly attached, non-tunnel LAN interface.
	LAN = routeselection.ClassLAN
	// Tunnel is a native tunnel or point-to-point adapter. A tunnel is not by
	// itself a confirmed VPN.
	Tunnel = routeselection.ClassTunnel
	// VPN is reserved for a platform-native VPN confirmation. No supported
	// adapter currently produces it.
	VPN = routeselection.ClassVPN
)

// Classification is the class and native evidence behind it.
type Classification = routeselection.Classification

// Config describes one construction. Selections restricts the interfaces;
// when empty, every interface that is currently up is considered. Port zero
// requests an ephemeral port for each binding.
type Config = routeselection.UnicastConfig

// Set owns every socket it constructed. Close releases them and waits for
// in-flight operations to return.
type Set = routeselection.UnicastSet

// Binding is one concrete socket on one interface address.
type Binding = routeselection.UnicastBinding

// Facts is a copied description of one binding.
type Facts = routeselection.UnicastFacts

// Message is one batched receive slot. All slots passed to one ReadBatch call
// must have equal Buffer lengths.
type Message = routeselection.UnicastMessage

// Failure is a copied construction failure. Its Address is invalid when the
// whole interface failed.
type Failure = routeselection.UnicastFailure

// Error reports a construction that produced no binding.
type Error = routeselection.UnicastError

// ErrPolicy reports an interface or peer that the mode does not admit. Errors
// otherwise carry the selection package's typed Error and sentinels.
var ErrPolicy = routeselection.ErrPolicy

// Listen constructs the configured bindings. Partial success returns a set
// and its failures; zero successes returns *Error and no set.
func Listen(ctx context.Context, cfg Config) (*Set, error) {
	return routeselection.ListenUnicast(ctx, cfg)
}
