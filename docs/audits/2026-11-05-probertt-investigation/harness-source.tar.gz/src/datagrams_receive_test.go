package wiremux

import (
	"bytes"
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/connect"
)

// feedDatagramCarrier returns its prepared lower payloads in order, without
// allocating, and then waits for the call's context. It does not declare that
// its returned slices are fresh, so Receive must copy them.
type feedDatagramCarrier struct {
	lifetime context.Context
	cancel   context.CancelCauseFunc
	payloads [][]byte
	next     atomic.Int64
}

func newFeedDatagramCarrier(payloads ...[]byte) *feedDatagramCarrier {
	lifetime, cancel := context.WithCancelCause(context.Background())
	return &feedDatagramCarrier{lifetime: lifetime, cancel: cancel, payloads: payloads}
}

func (c *feedDatagramCarrier) Lifetime() context.Context { return c.lifetime }

func (c *feedDatagramCarrier) MaxDatagramPayload() int { return 1243 }

func (c *feedDatagramCarrier) SendDatagram(context.Context, []byte) error { return nil }

func (c *feedDatagramCarrier) ReceiveDatagram(ctx context.Context) ([]byte, error) {
	if i := c.next.Add(1) - 1; i < int64(len(c.payloads)) {
		return c.payloads[i], nil
	}
	<-ctx.Done()
	return nil, ctx.Err()
}

// freshFeedDatagramCarrier declares that every slice it returns is fresh, as
// the native carrier does.
type freshFeedDatagramCarrier struct{ *feedDatagramCarrier }

func (freshFeedDatagramCarrier) receivesFresh() {}

var _ freshReceiveCarrier = freshFeedDatagramCarrier{}

// applicationFrames returns n distinct framed application payloads.
func applicationFrames(n int) [][]byte {
	frames := make([][]byte, n)
	for i := range frames {
		frames[i] = []byte{datagramApplicationDiscriminator, 'p', byte(i)}
	}
	return frames
}

func newFeedTestWire(t *testing.T, carrier connect.DatagramCarrier) *Datagrams {
	t.Helper()
	wire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, nil)
	t.Cleanup(func() { _ = wire.Close() })
	handle, _ := wire.Datagrams()
	return handle
}

// sameBacking reports whether non-empty a and b start at the same element.
func sameBacking(a, b []byte) bool { return len(a) > 0 && len(b) > 0 && &a[0] == &b[0] }

// A declaring carrier's payload is delivered without a second copy: Receive
// returns the carrier's own slice past the envelope byte, and each delivery is
// a distinct slice the carrier never touches again.
func TestDatagramsReceiveStripsDeclaringCarrierPayloadWithoutCopy(t *testing.T) {
	frames := append(applicationFrames(2), []byte{datagramApplicationDiscriminator})
	handle := newFeedTestWire(t, freshFeedDatagramCarrier{newFeedDatagramCarrier(frames...)})
	ctx := context.Background()
	first, err := handle.Receive(ctx)
	if err != nil {
		t.Fatalf("Receive: %v", err)
	}
	second, err := handle.Receive(ctx)
	if err != nil {
		t.Fatalf("Receive: %v", err)
	}
	for i, got := range [][]byte{first, second} {
		if want := []byte{'p', byte(i)}; !bytes.Equal(got, want) {
			t.Fatalf("Receive %d payload = %q, want %q", i, got, want)
		}
		if !sameBacking(got, frames[i][1:]) {
			t.Fatalf("Receive %d copied the declaring carrier's payload, want its own slice past the envelope", i)
		}
	}
	first[0] = 'X'
	if !bytes.Equal(second, []byte{'p', 1}) {
		t.Fatalf("second payload changed with the first: %q", second)
	}
	empty, err := handle.Receive(ctx)
	if err != nil {
		t.Fatalf("Receive empty payload: %v", err)
	}
	if empty == nil || len(empty) != 0 {
		t.Fatalf("Receive empty payload = %#v, want non-nil empty slice", empty)
	}
}

// A carrier that does not declare fresh slices keeps today's copy, so its
// later use of a returned slice never reaches the caller's payload.
func TestDatagramsReceiveCopiesNonDeclaringCarrierPayload(t *testing.T) {
	frames := applicationFrames(1)
	handle := newFeedTestWire(t, newFeedDatagramCarrier(frames...))
	got, err := handle.Receive(context.Background())
	if err != nil {
		t.Fatalf("Receive: %v", err)
	}
	if sameBacking(got, frames[0][1:]) {
		t.Fatal("Receive aliased a non-declaring carrier's slice, want a copy")
	}
	frames[0][1] = 'X'
	if !bytes.Equal(got, []byte{'p', 0}) {
		t.Fatalf("Receive payload changed with the carrier slice: %q", got)
	}
}

// A managed transport/quic Wire's carrier does not declare fresh slices, so
// its Receive keeps the copy.
func TestManagedDatagramsKeepReceiveCopy(t *testing.T) {
	left, right := managedTestPair(t)
	for _, wire := range []*ManagedWire{left, right} {
		if managedRequireDatagrams(t, wire).freshReceive {
			t.Fatal("managed transport/quic Wire strips without copying, want the copy")
		}
	}
}

// Contexts whose dynamic values cannot be compared never reach the identity
// check: Receive serves them, one merged context per call, without
// panicking. The second type is comparable, but its value holds a map.
func TestDatagramsReceiveNonComparableContextDoesNotPanic(t *testing.T) {
	type structContext struct {
		context.Context
		labels map[string]string
	}
	type wrappedContext struct {
		context.Context
		label any
	}
	contexts := []func() context.Context{
		func() context.Context { return structContext{context.Background(), map[string]string{}} },
		func() context.Context { return wrappedContext{context.Background(), map[string]string{}} },
	}
	for _, newContext := range contexts {
		handle := newFeedTestWire(t, newFeedDatagramCarrier(applicationFrames(3)...))
		for i := range 3 {
			got, err := handle.Receive(newContext())
			if err != nil {
				t.Fatalf("Receive %d: %v", i, err)
			}
			if !bytes.Equal(got, []byte{'p', byte(i)}) {
				t.Fatalf("Receive %d payload = %q", i, got)
			}
		}
	}
}

// registrationContext is a caller context whose Done is its own channel, so
// context.WithCancel registers on it through AfterFunc and its live
// registrations can be counted.
type registrationContext struct {
	done chan struct{}
	once sync.Once

	mu    sync.Mutex
	funcs map[int]func()
	next  int
}

func newRegistrationContext() *registrationContext {
	return &registrationContext{done: make(chan struct{}), funcs: map[int]func(){}}
}

func (c *registrationContext) Deadline() (time.Time, bool) { return time.Time{}, false }

func (c *registrationContext) Done() <-chan struct{} { return c.done }

func (c *registrationContext) Err() error {
	select {
	case <-c.done:
		return context.Canceled
	default:
		return nil
	}
}

func (c *registrationContext) Value(any) any { return nil }

func (c *registrationContext) AfterFunc(f func()) func() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	id := c.next
	c.next++
	c.funcs[id] = f
	return func() bool {
		c.mu.Lock()
		defer c.mu.Unlock()
		_, live := c.funcs[id]
		delete(c.funcs, id)
		return live
	}
}

// end cancels the context and runs its registrations, which it then drops.
func (c *registrationContext) end() {
	c.once.Do(func() {
		close(c.done)
		c.mu.Lock()
		funcs := c.funcs
		c.funcs = map[int]func(){}
		c.mu.Unlock()
		for _, f := range funcs {
			f()
		}
	})
}

func (c *registrationContext) live() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return len(c.funcs)
}

func requireLiveRegistrations(t *testing.T, ctx *registrationContext, want int) {
	t.Helper()
	deadline := time.Now().Add(time.Second)
	for ctx.live() != want {
		if time.Now().After(deadline) {
			t.Fatalf("live registrations on the caller's context = %d, want %d", ctx.live(), want)
		}
		time.Sleep(time.Millisecond)
	}
}

func requireReceive(t *testing.T, handle *Datagrams, ctx context.Context) {
	t.Helper()
	if _, err := handle.Receive(ctx); err != nil {
		t.Fatalf("Receive: %v", err)
	}
}

// Receive keeps one registration on a context the caller passes again, and
// the next call with a different context releases it.
func TestDatagramsReceiveDifferentContextReleasesKeptRegistration(t *testing.T) {
	handle := newFeedTestWire(t, newFeedDatagramCarrier(applicationFrames(3)...))
	kept, next := newRegistrationContext(), newRegistrationContext()
	requireReceive(t, handle, kept)
	requireReceive(t, handle, kept)
	requireLiveRegistrations(t, kept, 1)
	requireReceive(t, handle, next)
	requireLiveRegistrations(t, kept, 0)
	requireLiveRegistrations(t, next, 1)

	// A next call whose context is already canceled is a call with a
	// different context too: it releases the kept registration on an idle
	// handle before reporting its cancellation.
	canceled, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := handle.Receive(canceled); !errors.Is(err, context.Canceled) {
		t.Fatalf("Receive with a canceled context: %v, want context.Canceled", err)
	}
	if got := next.live(); got != 0 {
		t.Fatalf("live registrations on the previous context after a canceled call = %d, want 0", got)
	}
}

// The kept context's end releases its registration, and the next call builds
// a merged context anew.
func TestDatagramsReceiveKeptContextEndReleasesRegistration(t *testing.T) {
	handle := newFeedTestWire(t, newFeedDatagramCarrier(applicationFrames(2)...))
	kept := newRegistrationContext()
	requireReceive(t, handle, kept)
	requireLiveRegistrations(t, kept, 1)
	kept.end()
	requireLiveRegistrations(t, kept, 0)
	if _, err := handle.Receive(kept); !errors.Is(err, context.Canceled) {
		t.Fatalf("Receive with the ended context: %v, want context.Canceled", err)
	}
	next := newRegistrationContext()
	requireReceive(t, handle, next)
	requireLiveRegistrations(t, next, 1)
}

// Gate closure releases the kept registration while the caller's context
// lives, and a later Receive on that context still reports the closed error.
func TestDatagramsReceiveGateClosureReleasesKeptRegistration(t *testing.T) {
	carrier := newFeedDatagramCarrier(applicationFrames(1)...)
	wire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, nil)
	handle, _ := wire.Datagrams()
	kept := newRegistrationContext()
	requireReceive(t, handle, kept)
	requireLiveRegistrations(t, kept, 1)
	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	requireLiveRegistrations(t, kept, 0)
	if _, err := handle.Receive(kept); !errors.Is(err, ErrWireClosed) {
		t.Fatalf("Receive after Close: %v, want ErrWireClosed", err)
	}
}
