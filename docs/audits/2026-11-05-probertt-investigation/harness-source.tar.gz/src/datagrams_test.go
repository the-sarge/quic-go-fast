package wiremux

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"runtime"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/channel"
	"github.com/GridSwarm/wiremux/connect"
	"github.com/GridSwarm/wiremux/internal/nettest"
	"github.com/GridSwarm/wiremux/internal/testerrors"
)

func TestWireDatagramsDiscoveryAndFixedCeiling(t *testing.T) {
	absent := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}}, nil)
	if got, ok := absent.Datagrams(); ok || got != nil {
		t.Fatalf("Datagrams() = (%v, %v), want (nil, false)", got, ok)
	}

	carrier := newDatagramTestCarrier(1243)
	wire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, nil)
	handle, ok := wire.Datagrams()
	if !ok || handle == nil {
		t.Fatalf("Datagrams() = (%v, %v), want non-nil handle", handle, ok)
	}
	if got := handle.MaxPayload(); got != 1242 {
		t.Fatalf("MaxPayload() = %d, want 1242", got)
	}
	carrier.maxPayload = 2048
	if got := handle.MaxPayload(); got != 1242 {
		t.Fatalf("MaxPayload() after carrier mutation = %d, want fixed 1242", got)
	}
	if again, ok := wire.Datagrams(); !ok || again != handle {
		t.Fatal("Datagrams() did not return the same borrowed handle")
	}
	otherCarrier := newDatagramTestCarrier(9)
	otherWire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: otherCarrier}, nil)
	otherHandle, _ := otherWire.Datagrams()
	if got := otherHandle.MaxPayload(); got != 8 {
		t.Fatalf("directional peer MaxPayload() = %d, want 8 independent of first Wire", got)
	}
	if err := otherWire.Close(); err != nil {
		t.Fatalf("other Close: %v", err)
	}
	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
}

func TestDatagramsReceiveDoesNotApplyOutboundCeiling(t *testing.T) {
	carrier := newDatagramTestCarrier(3)
	wire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, nil)
	handle, _ := wire.Datagrams()
	if handle.MaxPayload() != 2 {
		t.Fatalf("MaxPayload() = %d, want 2", handle.MaxPayload())
	}
	carrier.received <- []byte{0x00, 'l', 'a', 'r', 'g', 'e'}
	payload, err := handle.Receive(context.Background())
	if err != nil {
		t.Fatalf("Receive larger inbound payload: %v", err)
	}
	if string(payload) != "large" {
		t.Fatalf("Receive larger inbound payload = %q", payload)
	}
	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
}

func TestDatagramsSendFramesCopiesAndKeepsLocalErrorsNonTerminal(t *testing.T) {
	carrier := newDatagramTestCarrier(5)
	wire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, nil)
	handle, _ := wire.Datagrams()

	payload := []byte("data")
	if err := handle.Send(nil, payload); err != nil { //nolint:staticcheck // nil-context behavior is part of the public contract.
		t.Fatalf("Send maximum payload: %v", err)
	}
	payload[0] = 'X'
	if got := receiveSentDatagram(t, carrier.sent); !bytes.Equal(got, []byte{0x00, 'd', 'a', 't', 'a'}) {
		t.Fatalf("lower datagram = %v, want framed copied payload", got)
	}

	if err := handle.Send(context.Background(), nil); err != nil {
		t.Fatalf("Send empty payload: %v", err)
	}
	if got := receiveSentDatagram(t, carrier.sent); !bytes.Equal(got, []byte{0x00}) {
		t.Fatalf("empty lower datagram = %v, want [0]", got)
	}

	if err := handle.Send(context.Background(), []byte("large")); !errors.Is(err, ErrDatagramTooLarge) || errors.Is(err, connect.ErrDatagramTooLarge) {
		t.Fatalf("oversize Send error = %v, want only root ErrDatagramTooLarge", err)
	}
	canceled, cancel := context.WithCancel(context.Background())
	cancel()
	if err := handle.Send(canceled, []byte("ok")); !errors.Is(err, context.Canceled) {
		t.Fatalf("canceled Send error = %v, want context.Canceled", err)
	}

	if err := handle.Send(context.Background(), []byte("ok")); err != nil {
		t.Fatalf("Send after local errors: %v", err)
	}
	if got := receiveSentDatagram(t, carrier.sent); !bytes.Equal(got, []byte{0x00, 'o', 'k'}) {
		t.Fatalf("lower datagram after local errors = %v", got)
	}
	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
}

func TestDatagramsReceiveDropsReservedFramesAndReturnsCallerOwnedPayload(t *testing.T) {
	carrier := newDatagramTestCarrier(1243)
	wire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, nil)
	handle, _ := wire.Datagrams()

	carrier.received <- []byte{}
	carrier.received <- []byte{0x7f, 'x'}
	native := []byte{0x00, 'o', 'k'}
	carrier.received <- native

	got, err := handle.Receive(nil) //nolint:staticcheck // nil-context behavior is part of the public contract.
	if err != nil {
		t.Fatalf("Receive: %v", err)
	}
	if !bytes.Equal(got, []byte("ok")) {
		t.Fatalf("Receive payload = %q, want ok", got)
	}
	native[1] = 'X'
	if string(got) != "ok" {
		t.Fatalf("Receive payload changed with carrier slice: %q", got)
	}

	carrier.received <- []byte{0x00}
	empty, err := handle.Receive(context.Background())
	if err != nil {
		t.Fatalf("Receive empty payload: %v", err)
	}
	if empty == nil || len(empty) != 0 {
		t.Fatalf("Receive empty payload = %#v, want non-nil empty slice", empty)
	}
	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
}

func TestDatagramsRejectInvalidLowerReceiveResults(t *testing.T) {
	lowerErr := errors.New("lower receive failed with payload")
	tests := []struct {
		name    string
		payload []byte
		err     error
		cause   error
	}{
		{name: "nil payload and nil error", cause: errDatagramCarrierInvalidReceiveResult},
		{name: "payload and error", payload: []byte{0x00, 'x'}, err: lowerErr, cause: lowerErr},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			base := newDatagramTestCarrier(1240)
			carrier := &fixedReceiveResultDatagramCarrier{
				datagramTestCarrier: base,
				payload:             test.payload,
				err:                 test.err,
			}
			stream := &datagramTestStream{closeCalled: make(chan struct{})}
			wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
			handle, _ := wire.Datagrams()
			payload, err := handle.Receive(context.Background())
			if payload != nil {
				t.Fatalf("Receive payload = %q, want no delivery", payload)
			}
			if !errors.Is(err, ErrWireClosed) || !errors.Is(err, test.cause) {
				t.Fatalf("Receive error = %v, want ErrWireClosed preserving %v", err, test.cause)
			}
			select {
			case <-stream.closeCalled:
			case <-time.After(time.Second):
				t.Fatal("invalid lower receive result did not start aggregate teardown")
			}
		})
	}
}

func TestDatagramsContinuousInvalidInputCannotStarveCancellationOrClose(t *testing.T) {
	invalidPayloads := []struct {
		name    string
		payload []byte
	}{
		{name: "empty native", payload: []byte{}},
		{name: "reserved discriminator", payload: []byte{0xff}},
	}
	for _, invalid := range invalidPayloads {
		for _, termination := range []string{"call context", "Wire close"} {
			t.Run(invalid.name+"/"+termination, func(t *testing.T) {
				carrier := newInvalidFloodDatagramTestCarrier(invalid.payload)
				defer carrier.cancel(errors.New("test complete"))
				wire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, nil)
				handle, _ := wire.Datagrams()
				ctx, cancel := context.WithCancel(context.Background())
				defer cancel()
				done := make(chan error, 1)
				go func() {
					_, err := handle.Receive(ctx)
					done <- err
				}()
				select {
				case <-carrier.started:
				case <-time.After(time.Second):
					t.Fatal("Receive did not begin consuming invalid lower messages")
				}
				if termination == "call context" {
					cancel()
				} else if err := wire.Close(); err != nil {
					t.Fatalf("Wire.Close during invalid input flood: %v", err)
				}
				select {
				case err := <-done:
					if termination == "call context" && !errors.Is(err, context.Canceled) {
						t.Fatalf("Receive after call cancellation = %v, want context.Canceled", err)
					}
					if termination == "Wire close" && !errors.Is(err, ErrWireClosed) {
						t.Fatalf("Receive after Wire.Close = %v, want ErrWireClosed", err)
					}
				case <-time.After(time.Second):
					t.Fatal("continuous invalid input starved Receive termination")
				}
				if termination == "call context" {
					if err := wire.Close(); err != nil {
						t.Fatalf("cleanup Wire.Close: %v", err)
					}
				}
			})
		}
	}
}

func TestWireCloseReleasesPendingDatagramReceiveAndWinsErrorPrecedence(t *testing.T) {
	carrier := newDatagramTestCarrier(5)
	stream := &datagramTestStream{closeCalled: make(chan struct{})}
	wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
	handle, _ := wire.Datagrams()

	receiveDone := make(chan error, 1)
	go func() {
		_, err := handle.Receive(context.Background())
		receiveDone <- err
	}()
	select {
	case <-carrier.receiveStarted:
	case <-time.After(time.Second):
		t.Fatal("carrier receive did not start")
	}

	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	select {
	case err := <-receiveDone:
		if !errors.Is(err, ErrWireClosed) {
			t.Fatalf("pending Receive error = %v, want ErrWireClosed", err)
		}
	case <-time.After(time.Second):
		t.Fatal("pending Receive did not return after Close")
	}
	if !stream.closed.Load() {
		t.Fatal("Wire.Close did not close reliable stream")
	}

	canceled, cancel := context.WithCancel(context.Background())
	cancel()
	if err := handle.Send(canceled, []byte("oversize")); !errors.Is(err, ErrWireClosed) {
		t.Fatalf("closed oversize canceled Send error = %v, want ErrWireClosed", err)
	}
	if _, err := handle.Receive(canceled); !errors.Is(err, ErrWireClosed) {
		t.Fatalf("closed canceled Receive error = %v, want ErrWireClosed", err)
	}
	select {
	case payload := <-carrier.sent:
		t.Fatalf("closed public Send reached carrier with payload %v", payload)
	default:
	}
}

func TestDatagramsBlockedAdmissionIsCancellableAndCloseDiscardsQueuedSend(t *testing.T) {
	carrier := newBlockingDatagramTestCarrier(1243)
	stream := &datagramTestStream{}
	wire := &Wire{stream: stream}
	wire.startDatagrams(carrier, 1)
	handle, _ := wire.Datagrams()

	if err := handle.Send(context.Background(), []byte("in flight")); err != nil {
		t.Fatalf("first Send: %v", err)
	}
	select {
	case <-carrier.sendStarted:
	case <-time.After(time.Second):
		t.Fatal("carrier send did not start")
	}
	if err := handle.Send(context.Background(), []byte("queued")); err != nil {
		t.Fatalf("second Send: %v", err)
	}

	ctx, cancel := context.WithCancel(context.Background())
	observed := &doneObservedContext{Context: ctx, observed: make(chan struct{})}
	blockedDone := make(chan error, 1)
	go func() {
		blockedDone <- handle.Send(observed, []byte("blocked"))
	}()
	select {
	case <-observed.observed:
	case <-time.After(time.Second):
		t.Fatal("blocked Send did not begin waiting for admission")
	}
	cancel()
	select {
	case err := <-blockedDone:
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("blocked Send error = %v, want context.Canceled", err)
		}
	case <-time.After(time.Second):
		t.Fatal("blocked Send did not return after cancellation")
	}

	closeObserved := &doneObservedContext{Context: context.Background(), observed: make(chan struct{})}
	closeBlockedDone := make(chan error, 1)
	go func() {
		closeBlockedDone <- handle.Send(closeObserved, []byte("blocked until close"))
	}()
	select {
	case <-closeObserved.observed:
	case <-time.After(time.Second):
		t.Fatal("close-blocked Send did not begin waiting for admission")
	}

	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	select {
	case err := <-closeBlockedDone:
		if !errors.Is(err, ErrWireClosed) {
			t.Fatalf("Send pending during local Close error = %v, want ErrWireClosed", err)
		}
	case <-time.After(time.Second):
		t.Fatal("Send pending during local Close did not unblock")
	}
	if got := carrier.sendCalls.Load(); got != 1 {
		t.Fatalf("carrier send calls = %d, want only in-flight call; queued payload was not discarded", got)
	}
}

func TestDatagramPostAdmissionLowerSendErrorSemantics(t *testing.T) {
	t.Run("unclassified live error is silent loss", func(t *testing.T) {
		lowerErr := errors.New("unclassified lower send error")
		carrier := newSequencedSendErrorDatagramCarrier(lowerErr)
		stream := &datagramTestStream{closeCalled: make(chan struct{})}
		wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
		handle, _ := wire.Datagrams()
		t.Cleanup(func() { _ = wire.Close() })

		if err := handle.Send(context.Background(), []byte("silently lost")); err != nil {
			t.Fatalf("first public Send: %v", err)
		}
		requireDatagramLowerSendCall(t, carrier.calls, 1)
		select {
		case <-stream.closeCalled:
			t.Fatal("unclassified lower send error closed the Wire")
		default:
		}
		if carrier.Lifetime().Err() != nil {
			t.Fatalf("unclassified lower send error ended Lifetime: %v", context.Cause(carrier.Lifetime()))
		}
		if err := handle.Send(context.Background(), []byte("later")); err != nil {
			t.Fatalf("later public Send: %v", err)
		}
		requireDatagramLowerSendCall(t, carrier.calls, 2)
		if n, err := wire.Write([]byte("reliable")); err != nil || n != len("reliable") {
			t.Fatalf("reliable Write after silent loss = (%d, %v)", n, err)
		}
	})

	t.Run("at ceiling rejection is terminal breach", func(t *testing.T) {
		lowerErr := fmt.Errorf("native rejected frozen ceiling: %w", connect.ErrDatagramTooLarge)
		carrier := newSequencedSendErrorDatagramCarrier(lowerErr)
		stream := &datagramTestStream{closeCalled: make(chan struct{})}
		wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
		handle, _ := wire.Datagrams()
		if err := handle.Send(context.Background(), make([]byte, handle.MaxPayload())); err != nil {
			t.Fatalf("public Send at ceiling: %v", err)
		}
		requireDatagramLowerSendCall(t, carrier.calls, 1)
		select {
		case <-stream.closeCalled:
		case <-time.After(time.Second):
			t.Fatal("at-ceiling lower rejection did not close the Wire")
		}
		if err := handle.Send(context.Background(), nil); !errors.Is(err, ErrWireClosed) || !errors.Is(err, connect.ErrDatagramTooLarge) || errors.Is(err, ErrDatagramTooLarge) {
			t.Fatalf("Send after ceiling breach = %v, want closed size cause", err)
		}
	})
}

func requireDatagramLowerSendCall(t *testing.T, calls <-chan int, want int) {
	t.Helper()
	select {
	case got := <-calls:
		if got != want {
			t.Fatalf("lower send call = %d, want %d", got, want)
		}
	case <-time.After(time.Second):
		t.Fatalf("lower send call %d did not occur", want)
	}
}

func TestDatagramsConcurrentReceivesDeliverEachMessageOnce(t *testing.T) {
	carrier := newDatagramTestCarrier(1243)
	wire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, nil)
	handle, _ := wire.Datagrams()

	type outcome struct {
		payload string
		err     error
	}
	done := make(chan outcome, 2)
	for range 2 {
		go func() {
			payload, err := handle.Receive(context.Background())
			done <- outcome{payload: string(payload), err: err}
		}()
	}
	carrier.received <- []byte{0x00, 'a'}
	carrier.received <- []byte{0x00, 'b'}

	seen := make(map[string]int)
	for range 2 {
		select {
		case result := <-done:
			if result.err != nil {
				t.Fatalf("Receive: %v", result.err)
			}
			seen[result.payload]++
		case <-time.After(time.Second):
			t.Fatal("concurrent Receive timed out")
		}
	}
	if seen["a"] != 1 || seen["b"] != 1 {
		t.Fatalf("concurrent Receive deliveries = %v, want each payload once", seen)
	}
	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
}

func TestDatagramPeerFailureReleasesSaturatedSendAndWaitingReceive(t *testing.T) {
	cause := errors.New("abrupt peer teardown")
	carrier := newPeerFailingDatagramTestCarrier(1243, cause)
	stream := &datagramTestStream{closeCalled: make(chan struct{})}
	wire := &Wire{stream: stream}
	wire.startDatagrams(carrier, 1)
	handle, _ := wire.Datagrams()

	if err := handle.Send(context.Background(), []byte("in flight")); err != nil {
		t.Fatalf("first Send: %v", err)
	}
	select {
	case <-carrier.sendStarted:
	case <-time.After(time.Second):
		t.Fatal("carrier send did not start")
	}
	if err := handle.Send(context.Background(), []byte("queued")); err != nil {
		t.Fatalf("second Send: %v", err)
	}

	sendCtx := &doneObservedContext{Context: context.Background(), observed: make(chan struct{})}
	blockedSend := make(chan error, 1)
	go func() { blockedSend <- handle.Send(sendCtx, []byte("blocked")) }()
	select {
	case <-sendCtx.observed:
	case <-time.After(time.Second):
		t.Fatal("third Send did not wait on saturated admission")
	}
	receiveDone := make(chan error, 1)
	go func() {
		_, err := handle.Receive(context.Background())
		receiveDone <- err
	}()
	select {
	case <-carrier.receiveStarted:
	case <-time.After(time.Second):
		t.Fatal("carrier receive did not start")
	}

	carrier.failPeer()
	for name, done := range map[string]<-chan error{"Send": blockedSend, "Receive": receiveDone} {
		select {
		case err := <-done:
			if !errors.Is(err, ErrWireClosed) || !errors.Is(err, cause) {
				t.Fatalf("%s after peer failure = %v, want ErrWireClosed preserving cause", name, err)
			}
		case <-time.After(time.Second):
			t.Fatalf("%s did not return after peer failure", name)
		}
	}
	select {
	case <-stream.closeCalled:
	case <-time.After(time.Second):
		t.Fatal("peer Datagram failure did not close reliable stream")
	}
	if got := carrier.sendCalls.Load(); got != 1 {
		t.Fatalf("carrier send calls = %d, want queued send discarded", got)
	}
}

func TestDatagramAutomaticTeardownReleasesAuthAndReportsOnce(t *testing.T) {
	cause := errors.New("automatic Datagram teardown sentinel")
	releaseErr := errors.New("automatic auth release sentinel")
	carrier := newPeerFailingDatagramTestCarrier(1243, cause)
	stream := &datagramTestStream{closeCalled: make(chan struct{})}
	source := &lifecycleAuthContext{base: nettest.NewAuthContext(), releaseErr: releaseErr}
	observed := make(chan error, 2)
	owner := newAuthContextOwner(source, func(err error) { observed <- err })
	wire := newTestWire(
		connect.UpgradeResult{Stream: stream, Datagrams: carrier},
		owner,
	)

	carrier.failPeer()
	select {
	case <-stream.closeCalled:
	case <-time.After(time.Second):
		t.Fatal("automatic teardown did not close the reliable stream")
	}
	err := wire.Close()
	if !errors.Is(err, ErrWireClosed) || !errors.Is(err, releaseErr) {
		t.Fatalf("Close after automatic teardown = %v, want ErrWireClosed with release error", err)
	}
	if got := source.releaseCount(); got != 1 {
		t.Fatalf("automatic teardown release count = %d, want 1", got)
	}
	select {
	case err := <-observed:
		if !errors.Is(err, releaseErr) {
			t.Fatalf("observed automatic release error = %v, want %v", err, releaseErr)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for automatic release observation")
	}
	select {
	case err := <-observed:
		t.Fatalf("duplicate automatic release observation = %v", err)
	case <-time.After(20 * time.Millisecond):
	}
}

func TestAutomaticTeardownReleaseHandlerCanCloseWire(t *testing.T) {
	releaseErr := errors.New("reentrant automatic release sentinel")
	carrier := newDatagramTestCarrier(1240)
	stream := &datagramTestStream{closeCalled: make(chan struct{})}
	source := &lifecycleAuthContext{base: nettest.NewAuthContext(), releaseErr: releaseErr}
	handlerDone := make(chan error, 1)
	var wire *Wire
	owner := newAuthContextOwner(source, func(error) { handlerDone <- wire.Close() })
	wire = newTestWire(
		connect.UpgradeResult{Stream: stream, Datagrams: carrier},
		owner,
	)

	carrier.cancel(errors.New("automatic carrier sentinel"))
	select {
	case err := <-handlerDone:
		if !errors.Is(err, ErrWireClosed) || !errors.Is(err, releaseErr) {
			t.Fatalf("reentrant handler Close error = %v, want ErrWireClosed with release error", err)
		}
	case <-time.After(time.Second):
		t.Fatal("reentrant automatic release handler deadlocked")
	}
	if got := source.releaseCount(); got != 1 {
		t.Fatalf("producer release calls = %d, want 1", got)
	}
}

func TestDatagramAutomaticTeardownTimeoutObserverSequence(t *testing.T) {
	tests := []struct {
		name    string
		lateErr error
	}{
		{name: "deferred success"},
		{name: "deferred error", lateErr: errors.New("automatic late release sentinel")},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			cause := errors.New("automatic timeout carrier sentinel")
			carrier := newPeerFailingDatagramTestCarrier(1243, cause)
			stream := &datagramTestStream{closeCalled: make(chan struct{})}
			unblock := make(chan struct{})
			source := &lifecycleAuthContext{
				base:         nettest.NewAuthContext(),
				releaseBlock: unblock,
				releaseErr:   test.lateErr,
			}
			observed := make(chan error, 3)
			owner := newAuthContextOwner(source, func(err error) { observed <- err })
			wire := newTestWire(
				connect.UpgradeResult{Stream: stream, Datagrams: carrier},
				owner,
			)
			wire.authContextReleaseTimeout = 20 * time.Millisecond

			carrier.failPeer()
			select {
			case <-stream.closeCalled:
			case <-time.After(time.Second):
				t.Fatal("automatic timeout teardown did not close reliable stream")
			}
			err := wire.Close()
			if !errors.Is(err, ErrWireClosed) || !errors.Is(err, connect.ErrAuthContextReleaseTimeout) {
				t.Fatalf("Close error = %v, want ErrWireClosed with %v", err, connect.ErrAuthContextReleaseTimeout)
			}
			// Let deferred completion race observer delivery. The publication
			// barrier must still keep the timeout event first.
			close(unblock)
			select {
			case got := <-observed:
				if !errors.Is(got, connect.ErrAuthContextReleaseTimeout) {
					t.Fatalf("first observed error = %v, want timeout", got)
				}
			case <-time.After(time.Second):
				t.Fatal("timed out waiting for automatic timeout observation")
			}

			if test.lateErr != nil {
				select {
				case got := <-observed:
					if !errors.Is(got, test.lateErr) {
						t.Fatalf("second observed error = %v, want %v", got, test.lateErr)
					}
				case <-time.After(time.Second):
					t.Fatal("timed out waiting for deferred release error")
				}
			}
			select {
			case got := <-observed:
				t.Fatalf("unexpected extra observer event = %v", got)
			case <-time.After(30 * time.Millisecond):
			}
			if got := source.releaseCount(); got != 1 {
				t.Fatalf("automatic timeout producer calls = %d, want 1", got)
			}
		})
	}
}

func TestDatagramAutomaticReleaseTimeoutPublishesWhileCarrierCloseIsBlocked(t *testing.T) {
	cause := errors.New("blocked carrier automatic teardown sentinel")
	carrier := newDatagramTestCarrier(1240)
	stream := &singleCloseDatagramTestStream{
		entered: make(chan struct{}),
		release: make(chan struct{}),
	}
	unblockRelease := make(chan struct{})
	source := &lifecycleAuthContext{
		base:         nettest.NewAuthContext(),
		releaseBlock: unblockRelease,
	}
	observed := make(chan error, 2)
	owner := newAuthContextOwner(source, func(err error) { observed <- err })
	wire := newTestWire(
		connect.UpgradeResult{Stream: stream, Datagrams: carrier},
		owner,
	)
	wire.authContextReleaseTimeout = 20 * time.Millisecond

	carrier.cancel(cause)
	select {
	case <-stream.entered:
	case <-time.After(time.Second):
		t.Fatal("automatic teardown did not enter carrier Close")
	}
	closeDone := make(chan error, 1)
	go func() { closeDone <- wire.Close() }()
	select {
	case got := <-observed:
		if !errors.Is(got, connect.ErrAuthContextReleaseTimeout) {
			t.Fatalf("observed error = %v, want %v", got, connect.ErrAuthContextReleaseTimeout)
		}
	case <-time.After(time.Second):
		t.Fatal("auth release timeout was hidden by blocked carrier Close")
	}
	select {
	case err := <-closeDone:
		t.Fatalf("Wire.Close returned while carrier Close remained blocked: %v", err)
	default:
	}
	close(unblockRelease)
	close(stream.release)
	err := <-closeDone
	if !errors.Is(err, ErrWireClosed) || !errors.Is(err, connect.ErrAuthContextReleaseTimeout) {
		t.Fatalf("Close error = %v, want ErrWireClosed with release timeout", err)
	}
	select {
	case got := <-observed:
		t.Fatalf("deferred release success produced extra observer event: %v", got)
	case <-time.After(30 * time.Millisecond):
	}
	if got := source.releaseCount(); got != 1 {
		t.Fatalf("producer release calls = %d, want 1", got)
	}
}

func TestDatagramCarrierFailureClosesWholeWireAndPreservesCause(t *testing.T) {
	cause := errors.New("carrier failed")
	carrier := newDatagramTestCarrier(1243)
	carrier.receiveErr = cause
	stream := &datagramTestStream{closeCalled: make(chan struct{})}
	wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
	handle, _ := wire.Datagrams()

	_, err := handle.Receive(context.Background())
	if !errors.Is(err, ErrWireClosed) || !errors.Is(err, cause) {
		t.Fatalf("Receive error = %v, want ErrWireClosed preserving cause", err)
	}
	select {
	case <-stream.closeCalled:
	case <-time.After(time.Second):
		t.Fatal("carrier failure did not close reliable stream")
	}
	if err := handle.Send(context.Background(), nil); !errors.Is(err, ErrWireClosed) || !errors.Is(err, cause) {
		t.Fatalf("Send after carrier failure = %v, want ErrWireClosed preserving cause", err)
	}
}

func TestDatagramCarrierIdleLifetimeFailureClosesStableHandle(t *testing.T) {
	cause := errors.New("idle carrier terminated")
	carrier := newDatagramTestCarrier(1240)
	stream := &datagramTestStream{closeCalled: make(chan struct{})}
	wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
	handle, ok := wire.Datagrams()
	if !ok || handle.MaxPayload() != 1239 {
		t.Fatalf("Datagrams() before teardown = (%T, %v), max=%d", handle, ok, handle.MaxPayload())
	}

	carrier.cancel(cause)
	select {
	case <-stream.closeCalled:
	case <-time.After(time.Second):
		t.Fatal("idle carrier lifetime did not start aggregate teardown")
	}
	after, ok := wire.Datagrams()
	if !ok || after != handle {
		t.Fatalf("Datagrams() after teardown = (%T, %v), want stable handle", after, ok)
	}
	if after.MaxPayload() != 1239 {
		t.Fatalf("MaxPayload() after teardown = %d, want frozen 1239", after.MaxPayload())
	}
	if err := after.Send(context.Background(), nil); !errors.Is(err, ErrWireClosed) || !errors.Is(err, cause) {
		t.Fatalf("Send after idle carrier teardown = %v, want ErrWireClosed preserving cause", err)
	}
}

func TestDatagramSendAfterIdleLifetimeTerminationNeverAdmits(t *testing.T) {
	cause := errors.New("idle carrier terminated")
	carrier := newDatagramTestCarrier(1240)
	stream := &datagramTestStream{closeCalled: make(chan struct{})}
	wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
	handle, ok := wire.Datagrams()
	if !ok {
		t.Fatal("Datagrams() reported the configured carrier absent")
	}

	// Stop the Wire's carrier-lifetime watch so Send itself must enforce the
	// stable carrier lifetime before admitting work.
	wire.stopWatchingCarrier()
	<-wire.carrierWatchDone
	carrier.cancel(cause)

	err := handle.Send(context.Background(), []byte("must not be admitted"))
	if !errors.Is(err, ErrWireClosed) || !errors.Is(err, cause) {
		t.Errorf("Send after idle carrier teardown = %v, want ErrWireClosed preserving cause", err)
	}
	select {
	case payload := <-carrier.sent:
		t.Fatalf("lower carrier received payload %q after lifetime termination", payload)
	case <-time.After(50 * time.Millisecond):
	}
}

func TestDatagramReceiveLocalCloseWinsDelivery(t *testing.T) {
	carrier := newGatedReceiveDatagramCarrier([]byte{datagramApplicationDiscriminator, 'x'})
	wire := newTestWire(connect.UpgradeResult{
		Stream:    &datagramTestStream{closeCalled: make(chan struct{})},
		Datagrams: carrier,
	}, nil)
	handle, _ := wire.Datagrams()
	deliveryReached := make(chan struct{})
	releaseDelivery := make(chan struct{})
	handle.testBeforeReceiveDelivery = func() {
		close(deliveryReached)
		<-releaseDelivery
	}
	type receiveResult struct {
		payload []byte
		err     error
	}
	receiveDone := make(chan receiveResult, 1)
	go func() {
		payload, err := handle.Receive(context.Background())
		receiveDone <- receiveResult{payload: payload, err: err}
	}()
	<-carrier.started
	close(carrier.release)
	<-deliveryReached
	if err := wire.Close(); err != nil {
		t.Fatalf("Wire.Close: %v", err)
	}
	close(releaseDelivery)
	result := <-receiveDone
	if result.payload != nil || !errors.Is(result.err, ErrWireClosed) {
		t.Fatalf("Receive after local close = (%q, %v), want nil ErrWireClosed", result.payload, result.err)
	}
}

func TestDatagramReceiveCommittedPayloadWinsCallCancellation(t *testing.T) {
	carrier := newGatedReceiveDatagramCarrier([]byte{datagramApplicationDiscriminator, 'x'})
	wire := newTestWire(connect.UpgradeResult{
		Stream:    &datagramTestStream{closeCalled: make(chan struct{})},
		Datagrams: carrier,
	}, nil)
	t.Cleanup(func() { _ = wire.Close() })
	handle, _ := wire.Datagrams()
	deliveryReached := make(chan struct{})
	releaseDelivery := make(chan struct{})
	handle.testBeforeReceiveDelivery = func() {
		close(deliveryReached)
		<-releaseDelivery
	}
	ctx, cancel := context.WithCancel(context.Background())
	type receiveResult struct {
		payload []byte
		err     error
	}
	receiveDone := make(chan receiveResult, 1)
	go func() {
		payload, err := handle.Receive(ctx)
		receiveDone <- receiveResult{payload: payload, err: err}
	}()
	<-carrier.started
	close(carrier.release)
	<-deliveryReached
	cancel()
	close(releaseDelivery)
	result := <-receiveDone
	if string(result.payload) != "x" || result.err != nil {
		t.Fatalf("Receive after committed payload cancellation = (%q, %v), want x, nil", result.payload, result.err)
	}
}

func TestDatagramPreCanceledCarrierConstructionClosesWithoutFieldRace(t *testing.T) {
	cause := errors.New("carrier ended before Wire construction")
	carrier := newDatagramTestCarrier(1240)
	carrier.cancel(cause)
	stream := &datagramTestStream{closeCalled: make(chan struct{})}
	wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)

	select {
	case <-stream.closeCalled:
	case <-time.After(time.Second):
		t.Fatal("pre-canceled carrier did not close the constructed Wire")
	}
	handle, ok := wire.Datagrams()
	if !ok || handle == nil {
		t.Fatal("pre-canceled carrier lost the stable Datagram handle")
	}
	if err := handle.Send(context.Background(), nil); !errors.Is(err, ErrWireClosed) || !errors.Is(err, cause) {
		t.Fatalf("Send after pre-canceled construction = %v, want closed cause", err)
	}
}

func TestDatagramRetainedCausesSanitizeMalformedErrorTrees(t *testing.T) {
	tests := []struct {
		name               string
		closeWireAtCleanup bool
		setup              func(*Wire, *datagramTestCarrier)
	}{
		{
			name:               "reliable read",
			closeWireAtCleanup: true,
			setup: func(wire *Wire, _ *datagramTestCarrier) {
				wire.stream = &reliableFailureDatagramTestStream{cause: errors.Join(io.EOF, testerrors.TypedNilOpError())}
				_, _ = wire.Read(make([]byte, 1))
			},
		},
		{
			name: "stream close",
			setup: func(wire *Wire, _ *datagramTestCarrier) {
				wire.stream = &singleCloseDatagramTestStream{
					closeErr: testerrors.TypedNilOpError(),
					entered:  make(chan struct{}),
					release:  closedDatagramTestChannel(),
				}
				_ = wire.Close()
			},
		},
		{
			name: "carrier lifetime",
			setup: func(_ *Wire, carrier *datagramTestCarrier) {
				carrier.cancel(testerrors.TypedNilOpError())
			},
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			carrier := newDatagramTestCarrier(1240)
			wire := newTestWire(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, nil)
			if test.closeWireAtCleanup {
				t.Cleanup(func() { _ = wire.Close() })
			}
			handle, _ := wire.Datagrams()
			test.setup(wire, carrier)
			select {
			case <-handle.done:
			case <-time.After(time.Second):
				t.Fatal("Datagram gate did not close")
			}
			err := handle.Send(context.Background(), nil)
			if err == nil || !errors.Is(err, ErrWireClosed) {
				t.Fatalf("Send error = %v, want ErrWireClosed", err)
			}
			var opErr *net.OpError
			if errors.As(err, &opErr) {
				t.Fatalf("Send error exposed malformed net.OpError: %v", err)
			}
		})
	}
}

func closedDatagramTestChannel() chan struct{} {
	done := make(chan struct{})
	close(done)
	return done
}

func TestDatagramCarrierFailureAndWireCloseShareOneCloseResult(t *testing.T) {
	cause := errors.New("carrier terminated")
	closeErr := errors.New("first stream close failed")
	carrier := newDatagramTestCarrier(1240)
	stream := &singleCloseDatagramTestStream{closeErr: closeErr, entered: make(chan struct{}), release: make(chan struct{})}
	wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)

	carrier.cancel(cause)
	select {
	case <-stream.entered:
	case <-time.After(time.Second):
		t.Fatal("carrier failure did not start stream close")
	}
	closeDone := make(chan error, 1)
	go func() { closeDone <- wire.Close() }()
	select {
	case err := <-closeDone:
		t.Fatalf("Wire.Close returned before the first close completed: %v", err)
	default:
	}
	close(stream.release)
	select {
	case err := <-closeDone:
		if !errors.Is(err, ErrWireClosed) || !errors.Is(err, closeErr) {
			t.Fatalf("Wire.Close error = %v, want retained first close error", err)
		}
	case <-time.After(time.Second):
		t.Fatal("Wire.Close did not join automatic teardown")
	}
	if got := stream.closeCalls.Load(); got != 1 {
		t.Fatalf("stream Close calls = %d, want exactly one", got)
	}
}

func TestDatagramLocalCloseCausePreservesStreamError(t *testing.T) {
	closeErr := errors.New("stream close failed")
	for range 100 {
		carrier := newDatagramTestCarrier(1240)
		stream := &cancelingCloseDatagramTestStream{cancelCarrier: carrier.cancel, closeErr: closeErr}
		wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
		handle, _ := wire.Datagrams()

		if err := wire.Close(); !errors.Is(err, ErrWireClosed) || !errors.Is(err, closeErr) {
			t.Fatalf("Wire.Close error = %v, want ErrWireClosed preserving stream close error", err)
		}
		err := handle.Send(context.Background(), nil)
		if !errors.Is(err, ErrWireClosed) || !errors.Is(err, closeErr) {
			t.Fatalf("Datagram Send after local close = %v, want ErrWireClosed preserving stream close error", err)
		}
		if errors.Is(err, context.Canceled) {
			t.Fatalf("Datagram Send after local close = %v, must not retain context.Canceled", err)
		}
	}
}

func TestWireCloseRacingCarrierTerminationNeverReportsCarrierCause(t *testing.T) {
	closeErr := errors.New("stream close failed during local close")
	carrierCause := errors.New("carrier terminated during local close")
	for range 200 {
		carrier := newDatagramTestCarrier(1240)
		stream := &singleCloseDatagramTestStream{closeErr: closeErr, entered: make(chan struct{}), release: closedDatagramTestChannel()}
		wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
		handle, _ := wire.Datagrams()

		closeDone := make(chan error, 1)
		go func() { closeDone <- wire.Close() }()
		// Local close has won once closeCalled is stored: the Wire stores it
		// before any gate closure, so a carrier termination issued from here
		// on races only the remainder of the Wire's teardown order.
		for !wire.closeCalled.Load() {
			runtime.Gosched()
		}
		carrier.cancel(carrierCause)

		select {
		case err := <-closeDone:
			if !errors.Is(err, ErrWireClosed) || !errors.Is(err, closeErr) {
				t.Fatalf("Wire.Close error = %v, want ErrWireClosed preserving stream close error", err)
			}
		case <-time.After(time.Second):
			t.Fatal("Wire.Close did not return while racing carrier termination")
		}
		err := handle.Send(context.Background(), nil)
		if !errors.Is(err, ErrWireClosed) || !errors.Is(err, closeErr) {
			t.Fatalf("Datagram Send after local close = %v, want ErrWireClosed preserving stream close error", err)
		}
		if errors.Is(err, carrierCause) {
			t.Fatalf("Datagram Send after local close = %v, must not report the carrier cause when local close won", err)
		}
		if _, err := handle.Receive(context.Background()); errors.Is(err, carrierCause) {
			t.Fatalf("Datagram Receive after local close = %v, must not report the carrier cause when local close won", err)
		}
	}
}

func TestDatagramFaultAfterCloseStartedProducesNoSecondTeardown(t *testing.T) {
	closeErr := errors.New("stream close failed")
	faultCause := errors.New("Datagram fault after local close started")
	releaseErr := errors.New("auth release sentinel")
	carrier := newDatagramTestCarrier(1240)
	stream := &singleCloseDatagramTestStream{closeErr: closeErr, entered: make(chan struct{}), release: make(chan struct{})}
	source := &lifecycleAuthContext{base: nettest.NewAuthContext(), releaseErr: releaseErr}
	observed := make(chan error, 2)
	owner := newAuthContextOwner(source, func(err error) { observed <- err })
	wire := newTestWire(
		connect.UpgradeResult{Stream: stream, Datagrams: carrier},
		owner,
	)
	handle, _ := wire.Datagrams()

	closeDone := make(chan error, 1)
	go func() { closeDone <- wire.Close() }()
	select {
	case <-stream.entered:
	case <-time.After(time.Second):
		t.Fatal("Wire.Close did not start closing the reliable stream")
	}

	// The handle reports a fault while the Wire is still inside its own
	// teardown order; the report must fold into that one teardown.
	handle.fault(faultCause)
	close(stream.release)

	select {
	case err := <-closeDone:
		if !errors.Is(err, ErrWireClosed) || !errors.Is(err, closeErr) || !errors.Is(err, releaseErr) {
			t.Fatalf("Wire.Close error = %v, want ErrWireClosed joining stream close and release errors", err)
		}
	case <-time.After(time.Second):
		t.Fatal("Wire.Close did not return after the Datagram fault")
	}
	if got := stream.closeCalls.Load(); got != 1 {
		t.Fatalf("stream Close calls = %d, want exactly one", got)
	}
	if got := source.releaseCount(); got != 1 {
		t.Fatalf("auth release calls = %d, want exactly one", got)
	}
	select {
	case err := <-observed:
		t.Fatalf("explicit close published an automatic release observation: %v", err)
	case <-time.After(20 * time.Millisecond):
	}
	err := handle.Send(context.Background(), nil)
	if !errors.Is(err, ErrWireClosed) || !errors.Is(err, closeErr) {
		t.Fatalf("Datagram Send after local close = %v, want ErrWireClosed preserving stream close error", err)
	}
	if errors.Is(err, faultCause) {
		t.Fatalf("Datagram Send after local close = %v, must not report a fault that lost to local close", err)
	}
}

func TestReliableReadTerminalClosesDatagramGateWithoutClosingWriteDirection(t *testing.T) {
	tests := []struct {
		name  string
		cause error
	}{
		{name: "authenticated read EOF", cause: io.EOF},
		{name: "channel authentication", cause: channel.ErrAuthentication},
		{name: "channel truncation", cause: channel.ErrTruncated},
		{name: "transport read closure", cause: net.ErrClosed},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			cause := test.cause
			stream := &reliableFailureDatagramTestStream{cause: cause}
			carrier := newDatagramTestCarrier(1240)
			defer carrier.cancel(errors.New("test complete"))
			wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
			t.Cleanup(func() { _ = wire.Close() })
			handle, ok := wire.Datagrams()
			if !ok || handle == nil {
				t.Fatal("Datagrams() before reliable failure is absent")
			}

			n, err := wire.Read(make([]byte, 1))
			if n != 1 || !errors.Is(err, cause) {
				t.Fatalf("Read = (%d, %v), want one reported byte and terminal cause", n, err)
			}
			if stream.closeCalls.Load() != 0 {
				t.Fatalf("reliable read failure stream Close calls = %d, want 0", stream.closeCalls.Load())
			}
			if n, err := wire.Write([]byte("still writable")); err != nil || n != len("still writable") {
				t.Fatalf("Write after terminal Read = (%d, %v), want independent write direction", n, err)
			}
			if carrier.Lifetime().Err() != nil {
				t.Fatalf("reliable read failure ended carrier lifetime: %v", context.Cause(carrier.Lifetime()))
			}
			if after, present := wire.Datagrams(); !present || after != handle {
				t.Fatalf("Datagrams() after reliable failure = (%T, %v), want stable handle", after, present)
			}
			if err := handle.Send(context.Background(), nil); !errors.Is(err, ErrWireClosed) || !errors.Is(err, cause) {
				t.Fatalf("Send after reliable failure = %v, want ErrWireClosed preserving cause", err)
			}
			if _, err := handle.Receive(context.Background()); !errors.Is(err, ErrWireClosed) || !errors.Is(err, cause) {
				t.Fatalf("Receive after reliable failure = %v, want ErrWireClosed preserving cause", err)
			}
			workersDone := make(chan struct{})
			go func() {
				handle.drain()
				close(workersDone)
			}()
			select {
			case <-workersDone:
			case <-time.After(time.Second):
				t.Fatal("Datagram worker survived terminal reliable read")
			}
		})
	}
}

func TestDatagramGateClosureDoesNotReclassifyReliableFollowUpReads(t *testing.T) {
	tests := []struct {
		name       string
		first      error
		followUp   error
		wantClosed bool
		wantEOF    bool
		wantExact  bool
	}{
		{name: "net closed", first: io.EOF, followUp: net.ErrClosed, wantClosed: true},
		{name: "repeated EOF", first: io.EOF, followUp: io.EOF, wantEOF: true},
		{name: "unclassified after terminal", first: io.EOF, followUp: errors.New("late read failure"), wantExact: true},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			carrier := newDatagramTestCarrier(1240)
			stream := &sequencedReadDatagramTestStream{errors: []error{test.first, test.followUp}}
			wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
			t.Cleanup(func() { _ = wire.Close() })
			if _, err := wire.Read(make([]byte, 1)); !errors.Is(err, test.first) {
				t.Fatalf("first Read error = %v, want %v", err, test.first)
			}
			_, err := wire.Read(make([]byte, 1))
			if test.wantClosed && !errors.Is(err, ErrWireClosed) {
				t.Fatalf("follow-up Read error = %v, want ErrWireClosed", err)
			}
			if test.wantEOF && !errors.Is(err, io.EOF) {
				t.Fatalf("follow-up Read error = %v, want EOF precedence", err)
			}
			if test.wantExact && (!errors.Is(err, test.followUp) || errors.Is(err, ErrWireClosed)) {
				t.Fatalf("follow-up Read error = %v, want unclassified error without ErrWireClosed", err)
			}
			if got := stream.closeCalls.Load(); got != 0 {
				t.Fatalf("stream Close calls = %d, want zero before public close", got)
			}
			if n, err := wire.Write([]byte("still writable")); err != nil || n != len("still writable") {
				t.Fatalf("Write after follow-up Read = (%d, %v)", n, err)
			}
		})
	}
}

func TestDatagramReliableReadGateClosureStillObservesLaterCarrierTermination(t *testing.T) {
	carrierCause := errors.New("carrier terminated after read EOF")
	carrier := newDatagramTestCarrier(1240)
	stream := &reliableFailureDatagramTestStream{cause: io.EOF, closed: make(chan struct{})}
	wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)

	if _, err := wire.Read(make([]byte, 1)); !errors.Is(err, io.EOF) {
		t.Fatalf("Read error = %v, want EOF", err)
	}
	if n, err := wire.Write([]byte("still writable")); err != nil || n != len("still writable") {
		t.Fatalf("Write after EOF = (%d, %v)", n, err)
	}
	if got := stream.closeCalls.Load(); got != 0 {
		t.Fatalf("stream Close calls after read gate closure = %d, want 0", got)
	}

	carrier.cancel(carrierCause)
	select {
	case <-stream.closed:
	case <-time.After(time.Second):
		t.Fatal("later carrier termination did not start aggregate stream teardown")
	}
	if got := stream.closeCalls.Load(); got != 1 {
		t.Fatalf("stream Close calls after carrier termination = %d, want 1", got)
	}
	if err := wire.Close(); err != nil {
		t.Fatalf("Wire.Close after automatic teardown: %v", err)
	}
	if got := stream.closeCalls.Load(); got != 1 {
		t.Fatalf("stream Close calls after public close = %d, want retained single close", got)
	}
}

func TestReliablePerCallErrorLeavesDatagramsAndOppositeDirectionUsable(t *testing.T) {
	tests := []struct {
		name      string
		operation string
		cause     error
	}{
		{name: "read-side empty frame", operation: "Read", cause: channel.ErrStreamEmptyDataFrame},
		{name: "unclassified write", operation: "Write", cause: errors.New("unclassified per-call write error")},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			stream := &perCallFailureDatagramTestStream{operation: test.operation, cause: test.cause}
			carrier := newDatagramTestCarrier(1240)
			defer carrier.cancel(errors.New("test complete"))
			wire := newTestWire(connect.UpgradeResult{Stream: stream, Datagrams: carrier}, nil)
			handle, _ := wire.Datagrams()
			t.Cleanup(func() { _ = wire.Close() })

			var err error
			if test.operation == "Read" {
				_, err = wire.Read(make([]byte, 1))
			} else {
				_, err = wire.Write([]byte{'x'})
			}
			if !errors.Is(err, test.cause) {
				t.Fatalf("%s error = %v, want %v", test.operation, err, test.cause)
			}
			if stream.closeCalls.Load() != 0 {
				t.Fatalf("per-call error closed reliable stream %d times", stream.closeCalls.Load())
			}
			if test.operation == "Read" {
				if n, err := wire.Write([]byte("still writable")); err != nil || n != len("still writable") {
					t.Fatalf("Write after read-side error = (%d, %v)", n, err)
				}
			} else {
				buf := make([]byte, 1)
				if n, err := wire.Read(buf); err != nil || n != 1 || buf[0] != 'r' {
					t.Fatalf("Read after write per-call error = (%d, %v, %q)", n, err, buf)
				}
			}
			if err := handle.Send(context.Background(), []byte("still usable")); err != nil {
				t.Fatalf("Datagram Send after per-call error: %v", err)
			}
			if got := receiveSentDatagram(t, carrier.sent); !bytes.Equal(got, append([]byte{0x00}, []byte("still usable")...)) {
				t.Fatalf("Datagram after per-call error = %q", got)
			}
		})
	}
}

func receiveSentDatagram(t *testing.T, sent <-chan []byte) []byte {
	t.Helper()
	select {
	case payload := <-sent:
		return payload
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for lower datagram")
		return nil
	}
}

type datagramTestCarrier struct {
	maxPayload int
	lifetime   context.Context
	cancel     context.CancelCauseFunc
	sent       chan []byte
	received   chan []byte
	receiveErr error

	receiveStarted chan struct{}
	receiveOnce    sync.Once
}

type fixedReceiveResultDatagramCarrier struct {
	*datagramTestCarrier
	payload []byte
	err     error
}

type gatedReceiveDatagramCarrier struct {
	*datagramTestCarrier
	payload []byte
	started chan struct{}
	release chan struct{}
	once    sync.Once
}

func newGatedReceiveDatagramCarrier(payload []byte) *gatedReceiveDatagramCarrier {
	return &gatedReceiveDatagramCarrier{
		datagramTestCarrier: newDatagramTestCarrier(1240),
		payload:             append([]byte(nil), payload...),
		started:             make(chan struct{}),
		release:             make(chan struct{}),
	}
}

func (c *gatedReceiveDatagramCarrier) ReceiveDatagram(context.Context) ([]byte, error) {
	c.once.Do(func() { close(c.started) })
	<-c.release
	return append([]byte(nil), c.payload...), nil
}

func (c *fixedReceiveResultDatagramCarrier) ReceiveDatagram(context.Context) ([]byte, error) {
	return c.payload, c.err
}

type sequencedSendErrorDatagramCarrier struct {
	*datagramTestCarrier
	firstErr error
	calls    chan int
	count    atomic.Int32
}

func newSequencedSendErrorDatagramCarrier(firstErr error) *sequencedSendErrorDatagramCarrier {
	return &sequencedSendErrorDatagramCarrier{
		datagramTestCarrier: newDatagramTestCarrier(1240),
		firstErr:            firstErr,
		calls:               make(chan int, 2),
	}
}

func (c *sequencedSendErrorDatagramCarrier) SendDatagram(context.Context, []byte) error {
	call := int(c.count.Add(1))
	c.calls <- call
	if call == 1 {
		return c.firstErr
	}
	return nil
}

type invalidFloodDatagramTestCarrier struct {
	lifetime context.Context
	cancel   context.CancelCauseFunc
	payload  []byte
	started  chan struct{}
	once     sync.Once
}

func newInvalidFloodDatagramTestCarrier(payload []byte) *invalidFloodDatagramTestCarrier {
	lifetime, cancel := context.WithCancelCause(context.Background())
	return &invalidFloodDatagramTestCarrier{
		lifetime: lifetime,
		cancel:   cancel,
		payload:  append(make([]byte, 0, len(payload)), payload...),
		started:  make(chan struct{}),
	}
}

func (c *invalidFloodDatagramTestCarrier) Lifetime() context.Context { return c.lifetime }

func (*invalidFloodDatagramTestCarrier) MaxDatagramPayload() int { return 1240 }

func (*invalidFloodDatagramTestCarrier) SendDatagram(context.Context, []byte) error { return nil }

func (c *invalidFloodDatagramTestCarrier) ReceiveDatagram(context.Context) ([]byte, error) {
	c.once.Do(func() { close(c.started) })
	return c.payload, nil
}

type blockingDatagramTestCarrier struct {
	maxPayload  int
	lifetime    context.Context
	cancel      context.CancelCauseFunc
	sendStarted chan struct{}
	sendOnce    sync.Once
	sendCalls   atomic.Int32
}

type peerFailingDatagramTestCarrier struct {
	maxPayload     int
	lifetime       context.Context
	cancel         context.CancelCauseFunc
	cause          error
	peerFailed     chan struct{}
	sendStarted    chan struct{}
	receiveStarted chan struct{}
	sendOnce       sync.Once
	receiveOnce    sync.Once
	sendCalls      atomic.Int32
}

func newPeerFailingDatagramTestCarrier(maxPayload int, cause error) *peerFailingDatagramTestCarrier {
	lifetime, cancel := context.WithCancelCause(context.Background())
	return &peerFailingDatagramTestCarrier{
		maxPayload:     maxPayload,
		lifetime:       lifetime,
		cancel:         cancel,
		cause:          cause,
		peerFailed:     make(chan struct{}),
		sendStarted:    make(chan struct{}),
		receiveStarted: make(chan struct{}),
	}
}

func (c *peerFailingDatagramTestCarrier) Lifetime() context.Context { return c.lifetime }

func (c *peerFailingDatagramTestCarrier) failPeer() {
	c.cancel(c.cause)
	close(c.peerFailed)
}

func (c *peerFailingDatagramTestCarrier) MaxDatagramPayload() int { return c.maxPayload }

func (c *peerFailingDatagramTestCarrier) SendDatagram(context.Context, []byte) error {
	c.sendCalls.Add(1)
	c.sendOnce.Do(func() { close(c.sendStarted) })
	<-c.peerFailed
	return c.cause
}

func (c *peerFailingDatagramTestCarrier) ReceiveDatagram(context.Context) ([]byte, error) {
	c.receiveOnce.Do(func() { close(c.receiveStarted) })
	<-c.peerFailed
	return nil, c.cause
}

func newBlockingDatagramTestCarrier(maxPayload int) *blockingDatagramTestCarrier {
	lifetime, cancel := context.WithCancelCause(context.Background())
	return &blockingDatagramTestCarrier{maxPayload: maxPayload, lifetime: lifetime, cancel: cancel, sendStarted: make(chan struct{})}
}

func (c *blockingDatagramTestCarrier) Lifetime() context.Context { return c.lifetime }

func (c *blockingDatagramTestCarrier) MaxDatagramPayload() int { return c.maxPayload }

func (c *blockingDatagramTestCarrier) SendDatagram(ctx context.Context, _ []byte) error {
	c.sendCalls.Add(1)
	c.sendOnce.Do(func() { close(c.sendStarted) })
	<-ctx.Done()
	return ctx.Err()
}

func (c *blockingDatagramTestCarrier) ReceiveDatagram(ctx context.Context) ([]byte, error) {
	<-ctx.Done()
	return nil, ctx.Err()
}

type doneObservedContext struct {
	context.Context
	observed chan struct{}
	once     sync.Once
}

func (c *doneObservedContext) Done() <-chan struct{} {
	c.once.Do(func() { close(c.observed) })
	return c.Context.Done()
}

func newDatagramTestCarrier(maxPayload int) *datagramTestCarrier {
	lifetime, cancel := context.WithCancelCause(context.Background())
	return &datagramTestCarrier{
		maxPayload:     maxPayload,
		lifetime:       lifetime,
		cancel:         cancel,
		sent:           make(chan []byte, 16),
		received:       make(chan []byte, 16),
		receiveStarted: make(chan struct{}),
	}
}

func (c *datagramTestCarrier) Lifetime() context.Context { return c.lifetime }

func (c *datagramTestCarrier) MaxDatagramPayload() int { return c.maxPayload }

func (c *datagramTestCarrier) SendDatagram(ctx context.Context, payload []byte) error {
	owned := append([]byte(nil), payload...)
	select {
	case c.sent <- owned:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func (c *datagramTestCarrier) ReceiveDatagram(ctx context.Context) ([]byte, error) {
	c.receiveOnce.Do(func() { close(c.receiveStarted) })
	if c.receiveErr != nil {
		return nil, c.receiveErr
	}
	select {
	case payload := <-c.received:
		return payload, nil
	case <-ctx.Done():
		return nil, ctx.Err()
	}
}

type datagramTestStream struct {
	closed      atomic.Bool
	closeCalled chan struct{}
	closeOnce   sync.Once
	buf         bytes.Buffer
	mu          sync.Mutex
}

type reliableFailureDatagramTestStream struct {
	cause      error
	closeCalls atomic.Int32
	closed     chan struct{}
	closeOnce  sync.Once
}

type perCallFailureDatagramTestStream struct {
	operation  string
	cause      error
	closeCalls atomic.Int32
	failed     atomic.Bool
}

type singleCloseDatagramTestStream struct {
	closeErr   error
	entered    chan struct{}
	release    chan struct{}
	closeCalls atomic.Int32
}

type cancelingCloseDatagramTestStream struct {
	cancelCarrier context.CancelCauseFunc
	closeErr      error
}

func (*cancelingCloseDatagramTestStream) Read([]byte) (int, error)    { return 0, io.EOF }
func (*cancelingCloseDatagramTestStream) Write(p []byte) (int, error) { return len(p), nil }

func (s *cancelingCloseDatagramTestStream) Close() error {
	s.cancelCarrier(context.Canceled)
	runtime.Gosched()
	return s.closeErr
}

func (*singleCloseDatagramTestStream) Read([]byte) (int, error)    { return 0, io.EOF }
func (*singleCloseDatagramTestStream) Write(p []byte) (int, error) { return len(p), nil }

func (s *singleCloseDatagramTestStream) Close() error {
	if s.closeCalls.Add(1) != 1 {
		panic("stream closed more than once")
	}
	close(s.entered)
	<-s.release
	return s.closeErr
}

type sequencedReadDatagramTestStream struct {
	errors     []error
	reads      atomic.Int32
	closeCalls atomic.Int32
}

func (s *sequencedReadDatagramTestStream) Read([]byte) (int, error) {
	index := int(s.reads.Add(1)) - 1
	if index >= len(s.errors) {
		index = len(s.errors) - 1
	}
	return 0, s.errors[index]
}

func (*sequencedReadDatagramTestStream) Write(p []byte) (int, error) { return len(p), nil }

func (s *sequencedReadDatagramTestStream) Close() error {
	s.closeCalls.Add(1)
	return nil
}

func (s *perCallFailureDatagramTestStream) Read(p []byte) (int, error) {
	if s.operation == "Read" && s.failed.CompareAndSwap(false, true) {
		return 0, s.cause
	}
	p[0] = 'r'
	return 1, nil
}

func (s *perCallFailureDatagramTestStream) Write(p []byte) (int, error) {
	if s.operation == "Write" && s.failed.CompareAndSwap(false, true) {
		return 0, s.cause
	}
	return len(p), nil
}

func (s *perCallFailureDatagramTestStream) Close() error {
	s.closeCalls.Add(1)
	return nil
}

func (s *reliableFailureDatagramTestStream) Read(p []byte) (int, error) {
	p[0] = 'x'
	return 1, s.cause
}

func (*reliableFailureDatagramTestStream) Write(p []byte) (int, error) {
	return len(p), nil
}

func (s *reliableFailureDatagramTestStream) Close() error {
	s.closeCalls.Add(1)
	s.closeOnce.Do(func() {
		if s.closed != nil {
			close(s.closed)
		}
	})
	return nil
}

func (s *datagramTestStream) Read(p []byte) (int, error) {
	if s.closed.Load() {
		return 0, io.ErrClosedPipe
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.buf.Read(p)
}

func (s *datagramTestStream) Write(p []byte) (int, error) {
	if s.closed.Load() {
		return 0, io.ErrClosedPipe
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.buf.Write(p)
}

func (s *datagramTestStream) Close() error {
	s.closeOnce.Do(func() {
		s.closed.Store(true)
		if s.closeCalled != nil {
			close(s.closeCalled)
		}
	})
	return nil
}
