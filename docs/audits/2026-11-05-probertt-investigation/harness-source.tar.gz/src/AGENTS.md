# AGENTS.md

Agent-facing instructions for `GridSwarm/wiremux`.

## What This Repo Is

wiremux is the pairwise peer-to-peer connectivity primitive for the
GridSwarm product family: relay rendezvous + STUN + UDP hole-punching +
transport upgrade negotiation, with pluggable transport (default QUIC)
and a pluggable auth-context interface that admits PAKE (codemux),
Noise IK (keymux), and BYO-auth consumers without modification.

It is **identity-agnostic** — wiremux gets two parties a wire between
them; identity layers above wiremux decide who they are.

This repo is a green v1 connectivity kernel. The Go module, package implementation, CI validation gate, relay rendezvous, STUN, candidate gathering, authenticated probing, transport upgrade negotiation, QUIC transport, encrypted channel, root `wiremux.Dial` entry point, and deployable `wiremux-server` are present. The current release is the private, immutable [v0.3.0](https://github.com/GridSwarm/wiremux/releases/tag/v0.3.0), published 2026-10-27 (America/New_York); [`docs/RELEASE.md`](docs/RELEASE.md) records the release record, non-claims, and downstream sequencing, and [`docs/COMPATIBILITY.md`](docs/COMPATIBILITY.md) is the normative compatibility contract for the released v0.1.x, v0.2.x and v0.3.x lines. Downstream stable-version migrations are owned by the consumer repositories; live public-CA ACME validation remains follow-up work. Scope is defined in:

- [`docs/adr/adr-0001-vision-and-scope.md`](docs/adr/adr-0001-vision-and-scope.md) — vision and decision points.
- [`docs/prd/prd-0001-connectivity-kernel.md`](docs/prd/prd-0001-connectivity-kernel.md) — v1 API surface and acceptance criteria.

For the family taxonomy this repo lives in, see
[`GridSwarm/org-docs` ADR-0001](https://github.com/GridSwarm/org-docs/blob/main/docs/decisions/adr-0001-four-product-family.md).

## Documentation Layout

- [README.md](README.md) — project front door.
- [CONTEXT.md](CONTEXT.md) — domain language and terminology.
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — current architecture
  snapshot.
- [docs/CONVENTIONS.md](docs/CONVENTIONS.md) — codified code conventions: error messages, panic text, test grammar, shell dialect, test seams, receiver names.
- [docs/REVIEW-LOOP.md](docs/REVIEW-LOOP.md) — PR-body handling,
  closing-directive verification, and the required review loop.
- [docs/CI.md](docs/CI.md) — validation lanes, change routing, required-check
  behavior, and scheduled coverage.
- [docs/agents/](docs/agents/) — agent setup for issue tracking, triage
  labels, and domain docs.
- [docs/adr/](docs/adr/) — wiremux-scoped ADRs.
- [docs/prd/](docs/prd/) — wiremux-scoped PRDs.
- [docs/DEV-JOURNAL.md](docs/DEV-JOURNAL.md) — session journal.
- [memory/MEMORY.md](memory/MEMORY.md) — project memory index.

## Agent Skills

### Issue Tracker

Work is tracked in GitHub Issues; external PRs are not a triage request
surface. See
[`docs/agents/issue-tracker.md`](docs/agents/issue-tracker.md).

### Triage Labels

Use the standard five-role triage vocabulary. See
[`docs/agents/triage-labels.md`](docs/agents/triage-labels.md).

### Domain Docs

This is a single-context repository. See
[`docs/agents/domain.md`](docs/agents/domain.md).

## Validation Gate

The validation gate is:

```bash
task verify
```

This runs deterministic CI-script fixtures, diff-range secret scanning, repository-local Markdown-link and memory-frontmatter checks, working-tree plus base-range whitespace checks, the required Go toolchain audit, `gofmt` validation, `go mod download`, `go mod verify`, `go test ./...`, the root cleanup-budget race test, focused root/connect auth-lifecycle race tests, the relay and wiremuxtest race gate, focused root, QUIC-adapter, and production-establishment Datagram race gates, `golangci-lint run --timeout 5m`, and `govulncheck -test ./...`. Secret scanning reuses a matching cached TruffleHog first. Managed Linux selects the image-installed release, whose vendor checksum is verified during image construction; local and hosted first downloads retain archive checksum verification. The `govulncheck` step requires network access to the Go vulnerability database or a usable cached vulnerability database.

The required race set includes a bounded managed-dialer lane matching `TestDialerEngine.*` and `TestNegotiatorUpgradeDialerEngineHappyPath`, plus a bounded TURN-retry lane covering the owned-composite disposal ordering, the concurrent terminal seal, the bilateral retry upgrade, and the held-success listener (including its control-timeout retry-entry hold under an asymmetric probe timeout); the separate 3,000-count multicore D19 stress profile remains exact-head slice certification evidence rather than part of every `task verify`.

### Pinned Validation Tools

[`tools/go.mod`](tools/go.mod) is the single source of truth for the `golangci-lint`, `govulncheck`, `actionlint`, and `task` versions. [`tools/trufflehog.env`](tools/trufflehog.env) is the single source of truth for the TruffleHog release and platform checksums. The tools module is separate from the wiremux module, so its dependency graph stays out of the module that the rest of the GridSwarm family builds against. Dependabot watches it, and `scripts/test-ci-workflow.py` rejects any workflow that reintroduces a hardcoded `go install <pkg>@<version>` pin.

Select every pinned tool into the checkout-local bin with, after the base-toolchain audit in §Go Toolchain Supply-Chain Gate:

```bash
GOBIN="$PWD/.cache/tools/bin" GOTOOLCHAIN=local ./scripts/install-tools.sh
```

Managed Linux uses `infra-ensure-tool` to select each exact image-installed version and fails when a helper or version is missing; other environments build through the tools module. Official image binaries can have different embedded dependency graphs from local tools-module builds; local MVS selections and replacements remain unchanged. Retained Go and Task setup actions reuse image-seeded runner tool-cache entries, with cache certification owned by infra.

Installing tools is itself a `go` subcommand that can bootstrap a toolchain, so it must never run before that audit. `task tools` enforces the ordering by depending on `audit-go`.

`task verify` does this automatically and invokes the tools from `.cache/tools/bin`, never from `PATH`. A different `golangci-lint` or `govulncheck` installed globally is therefore ignored rather than rejected; nothing asks you to downgrade a shared binary. Install the `task` runner itself from <https://taskfile.dev>, or use the pinned build produced by the command above.

If `task` is unavailable, run the equivalent commands directly:

```bash
export GOTOOLCHAIN=local
BASE_REF="${BASE_REF:-origin/main}"
TOOLBIN="$PWD/.cache/tools/bin"
# Check the lint-cache policy while Task is still absent.
./scripts/check-lint-cache-contract.sh
# Audit the base toolchain before any go subcommand, then build the pinned tools
# and put them first on PATH. The rendered-command fixture runs only after the
# pinned Task binary becomes available.
GOTOOLCHAIN=local go version
go version
go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS
GOBIN="$TOOLBIN" ./scripts/install-tools.sh
export PATH="$TOOLBIN:$PATH"
./scripts/test-install-tools.sh
./scripts/test-ci-workflow.py
./scripts/test-audit-go-floor.sh
./scripts/test-go-toolchain-pin.py
./scripts/test-taskfile-lint-cache.sh
./scripts/test-classify-ci-changes.sh
./scripts/test-secret-scan.sh
./scripts/test-docs-check.sh
./scripts/test-release-wrapper-common.sh
./scripts/test-compatibility-manifests.sh
./scripts/test-nat-smoke-linux.sh
./scripts/test-nat-evidence.sh
./scripts/test-release-package.sh
./scripts/test-release-smoke.sh
./scripts/install-trufflehog.sh
./scripts/scan-secrets.sh
./scripts/check-docs.sh "$BASE_REF...HEAD"
./scripts/check-gofmt.sh
go mod download
go mod verify
./scripts/test-qualification.py
go test ./...
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^TestDialPairCloseAllowsProductionConsumeBudget$' -count=1 .
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestAuthContext|TestTransportAuth|TestBlockedTransport|TestWireAuth|TestWireClose|TestExplicitWireClose)' -count=1 .
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestDialReleaseHandlerDoesNotBlockReturn|TestAutomaticTeardownReleaseHandlerCanCloseWire|TestAuthContextExporterPanicReleasesGate)$' -count=1 .
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^TestDial(AuthContextReleaseTimeoutObserverSequence|ConsumesOneShotRealCanceledAuthSuccess)$' -count=1 .
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestNewReleasingAuthContext|TestTransportAuth|TestLegacyTransportAuth)' -count=1 ./connect
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestNewChannelClaims|TestNewChannelDoesNotRestore|TestChannelConstructorsClaim|TestCapabilityDroppingWrapper)' -count=1 ./channel
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestAttemptResources.*|TestSessionCloseUnblocksAndAttemptOwnerJoinsOperation|TestSessionOperationReceiverCensus)$' -count=1 ./connect
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^TestListenerEngineDefinitiveAcceptFailureClosesCommittedPacketConn$' -count=1 ./connect
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestDialerEngine.*|TestNegotiatorUpgradeDialerEngineHappyPath)$' -count=1 ./connect
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestOwnedCompositeTerminalDisposalPrecedesOperationJoin|TestTurnRetryConcurrentCompositeTerminalRequestsShareOneSeal|TestTurnRetryBilateralDirectFailureUpgradesOverComposites|TestTurnRetryHeldSuccessListenerDiscardsDirectAndAllocatesAfterStart|TestTurnRetryHeldSuccessListenerWaitsThroughProbeTimeoutForStart)$' -count=1 ./connect
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^TestSessionOperationReceiverCensus/acceptBeforeCommitSession$' -count=1 .
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^TestSessionCloseUnblocksConfiguredDialAndListen$' -count=1 ./internal/nettest
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^TestSessionFinalityWrapperCensus$' -count=1 ./internal/integration
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^TestSessionCloseUnblocksDialAndListen$' -count=1 ./transport/quic
go test -race ./relay/... ./internal/relayobserve/... ./wiremuxtest
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run 'Datagram' -count=1 .
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^Test.*Datagram' -count=1 ./transport/quic
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^Test(QUICProductionWireDatagramContract|ProductionWireDatagramAbsenceContract|ProductionWireMalformedDatagramContract|ProductionWirePostCommitMalformedDatagramContract)$' -count=1 ./internal/integration
GOLANGCI_LINT_CACHE="$PWD/.cache/golangci-lint" "$TOOLBIN/golangci-lint" run --timeout 5m
"$TOOLBIN/govulncheck" -test ./...
```

The documentation script verifies before every PR that Markdown links resolve
and memory files with YAML frontmatter include `name`, `description`, and
`type`. Also verify:

- When changing workflow or container files that invoke Go indirectly,
  audit their Go toolchain behavior against §Go Toolchain Supply-Chain
  Gate.

### RAS Review Tooling

`ras` is an optional local multi-agent review tool for reviewing,
adjudicating, and synthesizing GitHub PR feedback before merge.
Project-local configuration may live in `.ras/config.yaml`, which
overrides global `ras` config; the entire `.ras/` directory
(configuration, runtime state, review worktrees) is local-only and
git-ignored. Use `ras --help` for the installed CLI's command
reference.

### Go Toolchain Supply-Chain Gate

This is active project policy now that Go code and validation gates are
present; changes to Go build/test/lint behavior must enforce these checks
in CI.

Before introducing or modifying Go code, verify the installed/base Go
toolchain, not only `GOTOOLCHAIN`, the `toolchain` directive, or the
`go` directive:

```bash
GOTOOLCHAIN=local go version
go version
go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS
```

For this module, if `GOTOOLCHAIN=local go version` reports below `go1.27.3`, stop and upgrade the installed Go before running any other `go` subcommand. An older Go does not satisfy this repository’s approved toolchain floor. The audit commands above do not switch toolchains, but `go build`, `go mod`, `go test`, and `go run` can.

`GOTOOLCHAIN=local go version` is the authoritative base-toolchain
check; plain `go version` reports the selected toolchain and may switch
based on `GOTOOLCHAIN=auto`, `go.mod`, or `go.work`.

The `toolchain` directive bootstraps the requested Go through
`GOPROXY`/`GOSUMDB`, so an unpatched installed `go` cannot be trusted to
securely fetch the patched toolchain.

The installed/base `go` must include the checksum-bypass fix from GO-2026-4984 / CVE-2026-42501 and every Go security fix released since; `go1.27.3` is this repository’s approved floor and carries all of them. Authoritative references: <https://pkg.go.dev/vuln/GO-2026-4984>, <https://groups.google.com/g/golang-announce/c/94pEornpRlI>, and the [Go release history](https://go.dev/doc/devel/release#go1.27.3).

Every Go module in the portfolio — root and `tools/` alike — carries the same two-line convention: the `go` directive is the language compatibility floor and the `toolchain` directive pins the base toolchain.

```go
go 1.27

toolchain go1.27.3
```

Keep the two lines in lockstep across `go.mod` and `tools/go.mod`, and move them together when the portfolio floor moves. Do not change `go 1.27` to a patch-level `go 1.27.z`; the patch level belongs in the `toolchain` directive.

If `go.sum` exists and dependencies may have been fetched through an
untrusted `GOPROXY` or `GOSUMDB`, revalidate dependency trust state only
after upgrading the base Go toolchain and following the official Go
advisory. Before regenerating dependency state, preserve suspect
`go.mod`, `go.sum`, and module-cache evidence for incident review. If
private modules are involved, do not use a public reset path without
repo-owner or security review.

GitHub Actions that build or test Go must install the exact patched base toolchain pinned by the root `go.mod` through `actions/setup-go`. Use the canonical named setup step:

```yaml
env:
  GOTOOLCHAIN: local

steps:
  - name: Set up Go
    env:
      GOTOOLCHAIN: auto
    uses: actions/setup-go@<full-commit-sha> # v6 or newer
    with:
      go-version-file: go.mod
```

The workflow-level `GOTOOLCHAIN: local` policy remains in force for every later step. The setup step alone overrides it with `GOTOOLCHAIN: auto`, allowing `actions/setup-go@v6` or newer to resolve the root `go.mod` file's patched `toolchain go1.27.3` directive; after the step finishes, subsequent commands inherit `GOTOOLCHAIN: local` again and cannot switch away from the installed toolchain automatically. Do not also set `go-version`: that input takes precedence over `go-version-file`. Add a post-setup audit step:

```yaml
- name: Report Go environment
  run: |
    GOTOOLCHAIN=local go version
    go version
    go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS
```

Also check workflows that invoke Go indirectly, including CodeQL
autobuild, Docker builds, Makefiles, Taskfiles, release jobs,
`govulncheck`, `gosec`, `staticcheck`, and custom scripts. For every
Docker or base image that builds Go code, verify
`GOTOOLCHAIN=local go version`, `go version`, and
`go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS`
inside the image before relying on it.

## Family Position

wiremux is the **dependency floor** for the GridSwarm family. codemux,
keymux, and (future) meshmux all depend on wiremux. tapmux and
swarmcast (in the SwarmCast org) consume wiremux directly for connectivity
and indirectly through codemux/keymux for identity.

When making changes to wiremux's public API, surface the change in the PR
description and update the downstream repos (codemux, keymux, and other
consumers) in their own follow-up PRs.
