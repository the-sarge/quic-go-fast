package wiremux

import (
	"context"
	"errors"
	"io"
	"sync"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/connect"
	"github.com/GridSwarm/wiremux/internal/nettest"
)

func TestAuthContextOwnerExposesRevocableViews(t *testing.T) {
	source := &lifecycleAuthContext{base: nettest.NewAuthContext()}
	owner := newAuthContextOwner(source, nil)
	view := owner.authContext()
	transportView := owner.transportAuth()

	if view == source {
		t.Fatal("auth view retained producer-native identity")
	}
	if _, ok := view.(connect.AuthContextReleaser); ok {
		t.Fatal("auth view exposed release authority")
	}
	claimer, ok := view.(connect.ChannelUseClaimer)
	if !ok {
		t.Fatal("auth view dropped ChannelUseClaimer")
	}
	if err := claimer.ClaimChannelUse(); err != nil {
		t.Fatalf("live ClaimChannelUse() error = %v", err)
	}
	exporter := view.Exporter()
	if _, err := exporter.Derive("live", nil, 16); err != nil {
		t.Fatalf("live Derive() error = %v", err)
	}
	if binding, err := transportView.SessionBinding(); err != nil || len(binding) == 0 {
		t.Fatalf("live transport binding = (%x, %v), want non-empty and nil", binding, err)
	}

	if err := owner.finishRelease(time.Second, authReleaseReturnImmediate); err != nil {
		t.Fatalf("release error = %v", err)
	}
	if got := view.SendKey(); got != nil {
		t.Fatalf("released SendKey = %x, want nil", got)
	}
	if got := view.ReceiveKey(); got != nil {
		t.Fatalf("released ReceiveKey = %x, want nil", got)
	}
	if got := view.SessionBinding(); got != nil {
		t.Fatalf("released SessionBinding = %x, want nil", got)
	}
	if _, err := exporter.Derive("released", nil, 16); !errors.Is(err, connect.ErrAuthContextReleased) {
		t.Fatalf("retained exporter error = %v, want %v", err, connect.ErrAuthContextReleased)
	}
	if _, err := transportView.SessionBinding(); !errors.Is(err, connect.ErrAuthContextReleased) {
		t.Fatalf("released transport binding error = %v, want %v", err, connect.ErrAuthContextReleased)
	}
	if _, err := transportView.Exporter().Derive("released", nil, 16); !errors.Is(err, connect.ErrAuthContextReleased) {
		t.Fatalf("released transport exporter error = %v, want %v", err, connect.ErrAuthContextReleased)
	}
	if err := claimer.ClaimChannelUse(); !errors.Is(err, connect.ErrAuthContextReleased) {
		t.Fatalf("released claim error = %v, want %v", err, connect.ErrAuthContextReleased)
	}
	if got := source.releaseCount(); got != 1 {
		t.Fatalf("producer release count = %d, want 1", got)
	}
}

func TestAuthContextConcurrentStartAndFinishShareResultAndPublication(t *testing.T) {
	releaseErr := errors.New("wiremux: shared release sentinel")
	unblock := make(chan struct{})
	defer close(unblock)
	source := &lifecycleAuthContext{base: nettest.NewAuthContext(), releaseBlock: unblock, releaseErr: releaseErr}
	observed := make(chan error, 32)
	owner := newAuthContextOwner(source, func(err error) { observed <- err })
	start := make(chan struct{})
	results := make(chan error, 16)
	var starters sync.WaitGroup
	for range 16 {
		starters.Go(func() {
			<-start
			owner.startRelease(20 * time.Millisecond)
		})
		go func() {
			<-start
			results <- owner.finishRelease(20*time.Millisecond, authReleaseObserveImmediate)
		}()
	}
	close(start)
	starters.Wait()
	for range 16 {
		if got := <-results; !errors.Is(got, connect.ErrAuthContextReleaseTimeout) {
			t.Fatalf("shared result: got %v, want release timeout", got)
		}
	}
	select {
	case got := <-observed:
		if !errors.Is(got, connect.ErrAuthContextReleaseTimeout) {
			t.Fatalf("immediate event: got %v, want release timeout", got)
		}
	case <-time.After(time.Second):
		t.Fatal("wiremux: missing immediate release event")
	}
	if got := owner.finishRelease(time.Second, authReleaseReturnImmediate); !errors.Is(got, connect.ErrAuthContextReleaseTimeout) {
		t.Fatalf("repeated finish: got %v, want stable release timeout", got)
	}
	if got := source.releaseCount(); got != 1 {
		t.Fatalf("producer calls: got %d, want 1", got)
	}
	select {
	case got := <-observed:
		t.Fatalf("duplicate publication: got %v, want no event", got)
	case <-time.After(20 * time.Millisecond):
	}
}

func TestAuthContextReleaseDefersUntilActiveExporterExits(t *testing.T) {
	started := make(chan struct{})
	unblock := make(chan struct{})
	source := &lifecycleAuthContext{
		base: nettest.NewAuthContext(nettest.WithExporter(nettest.ExporterFunc(func(string, []byte, int) ([]byte, error) {
			close(started)
			<-unblock
			return []byte("derived"), nil
		}))),
	}
	owner := newAuthContextOwner(source, nil)
	exporter := owner.authContext().Exporter()
	deriveDone := make(chan error, 1)
	go func() {
		_, err := exporter.Derive("blocked", nil, 7)
		deriveDone <- err
	}()
	<-started

	if err := owner.finishRelease(20*time.Millisecond, authReleaseReturnImmediate); !errors.Is(err, connect.ErrAuthContextReleaseTimeout) {
		t.Fatalf("release error = %v, want %v", err, connect.ErrAuthContextReleaseTimeout)
	}
	if got := source.releaseCount(); got != 0 {
		t.Fatalf("release count while exporter active = %d, want 0", got)
	}
	if _, err := owner.transportAuth().SessionBinding(); !errors.Is(err, connect.ErrAuthContextReleased) {
		t.Fatalf("post-timeout transport access error = %v, want %v", err, connect.ErrAuthContextReleased)
	}

	close(unblock)
	if err := <-deriveDone; err != nil {
		t.Fatalf("in-flight Derive error = %v", err)
	}
	awaitLifecycleCondition(t, func() bool { return source.releaseCount() == 1 })
	if err := owner.finishRelease(time.Second, authReleaseReturnImmediate); !errors.Is(err, connect.ErrAuthContextReleaseTimeout) {
		t.Fatalf("stable second release error = %v, want original timeout", err)
	}
}

func TestAuthContextReleaseTimesOutBlockedProducerOnce(t *testing.T) {
	unblock := make(chan struct{})
	lateErr := errors.New("late release sentinel")
	source := &lifecycleAuthContext{base: nettest.NewAuthContext(), releaseBlock: unblock, releaseErr: lateErr}
	observed := make(chan error, 1)
	owner := newAuthContextOwner(source, func(err error) { observed <- err })

	if err := owner.finishRelease(20*time.Millisecond, authReleaseReturnImmediate); !errors.Is(err, connect.ErrAuthContextReleaseTimeout) {
		t.Fatalf("release error = %v, want %v", err, connect.ErrAuthContextReleaseTimeout)
	}
	if got := source.releaseCount(); got != 1 {
		t.Fatalf("blocked producer invocation count = %d, want 1", got)
	}
	close(unblock)
	select {
	case err := <-observed:
		if !errors.Is(err, lateErr) {
			t.Fatalf("late observed error = %v, want %v", err, lateErr)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for late release error")
	}
	if got := source.releaseCount(); got != 1 {
		t.Fatalf("final producer invocation count = %d, want 1", got)
	}
}

func TestAuthContextReleaseBudgetStartsAtLogicalRevocation(t *testing.T) {
	source := &lifecycleAuthContext{base: nettest.NewAuthContext()}
	owner := newAuthContextOwner(source, nil)
	owner.revoke(20 * time.Millisecond)
	time.Sleep(30 * time.Millisecond)

	started := time.Now()
	if err := owner.finishRelease(time.Second, authReleaseReturnImmediate); !errors.Is(err, connect.ErrAuthContextReleaseTimeout) {
		t.Fatalf("release error = %v, want expired %v", err, connect.ErrAuthContextReleaseTimeout)
	}
	if elapsed := time.Since(started); elapsed > 50*time.Millisecond {
		t.Fatalf("release used a fresh timeout after revocation: elapsed %s", elapsed)
	}
	awaitLifecycleCondition(t, func() bool { return source.releaseCount() == 1 })
}

func TestTransportAuthExporterIsNonNilForMalformedLiveSource(t *testing.T) {
	source := &lifecycleAuthContext{base: nettest.NewAuthContext(nettest.WithExporter(nil))}
	owner := newAuthContextOwner(source, nil)
	exporter := owner.transportAuth().Exporter()
	if exporter == nil {
		t.Fatal("TransportAuth.Exporter = nil")
	}
	if _, err := exporter.Derive("malformed", nil, 16); !errors.Is(err, connect.ErrNilKeyExporter) {
		t.Fatalf("TransportAuth exporter error = %v, want %v", err, connect.ErrNilKeyExporter)
	}
}

func TestAuthContextExporterPanicReleasesGate(t *testing.T) {
	tests := []struct {
		name     string
		exporter func(*authContextOwner) connect.KeyExporter
	}{
		{name: "auth view", exporter: func(owner *authContextOwner) connect.KeyExporter {
			return owner.authContext().Exporter()
		}},
		{name: "transport view", exporter: func(owner *authContextOwner) connect.KeyExporter {
			return owner.transportAuth().Exporter()
		}},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			source := &lifecycleAuthContext{base: panickingExporterAuth{AuthContext: nettest.NewAuthContext()}}
			owner := newAuthContextOwner(source, nil)
			panicked := func() (panicked bool) {
				defer func() {
					panicked = recover() != nil
				}()
				_ = test.exporter(owner)
				return false
			}()
			if !panicked {
				t.Fatal("Exporter did not propagate producer panic")
			}
			if err := owner.finishRelease(100*time.Millisecond, authReleaseReturnImmediate); err != nil {
				t.Fatalf("release after Exporter panic = %v, want nil", err)
			}
			if got := source.releaseCount(); got != 1 {
				t.Fatalf("producer release count = %d, want 1", got)
			}
		})
	}
}

func TestBlockedTransportCallsCannotStartAuthUseAfterRevocation(t *testing.T) {
	t.Run("NewSession", func(t *testing.T) {
		source := &lifecycleAuthContext{base: nettest.NewAuthContext()}
		owner := newAuthContextOwner(source, nil)
		started := make(chan struct{})
		unblock := make(chan struct{})
		accessErr := make(chan error, 1)
		transport := &nettest.Transport{
			NewSessionFunc: func(_ context.Context, auth connect.TransportAuth) (connect.Session, error) {
				close(started)
				<-unblock
				_, err := auth.SessionBinding()
				accessErr <- err
				return &nettest.Session{}, nil
			},
		}
		newSessionDone := make(chan error, 1)
		go func() {
			_, err := transport.NewSession(context.Background(), owner.transportAuth())
			newSessionDone <- err
		}()
		<-started
		if err := owner.finishRelease(time.Second, authReleaseReturnImmediate); err != nil {
			t.Fatalf("release: %v", err)
		}
		close(unblock)
		if err := <-newSessionDone; err != nil {
			t.Fatalf("NewSession error = %v", err)
		}
		if err := <-accessErr; !errors.Is(err, connect.ErrAuthContextReleased) {
			t.Fatalf("late NewSession auth access = %v, want %v", err, connect.ErrAuthContextReleased)
		}
	})

	t.Run("Session.Close", func(t *testing.T) {
		source := &lifecycleAuthContext{base: nettest.NewAuthContext()}
		owner := newAuthContextOwner(source, nil)
		exporter := owner.transportAuth().Exporter()
		started := make(chan struct{})
		unblock := make(chan struct{})
		accessErr := make(chan error, 1)
		session := &nettest.Session{CloseFunc: func() error {
			close(started)
			<-unblock
			_, err := exporter.Derive("late-session-close", nil, 16)
			accessErr <- err
			return nil
		}}
		closeDone := make(chan error, 1)
		go func() { closeDone <- session.Close() }()
		<-started
		if err := owner.finishRelease(time.Second, authReleaseReturnImmediate); err != nil {
			t.Fatalf("release: %v", err)
		}
		close(unblock)
		if err := <-closeDone; err != nil {
			t.Fatalf("Session.Close error = %v", err)
		}
		if err := <-accessErr; !errors.Is(err, connect.ErrAuthContextReleased) {
			t.Fatalf("late Session.Close exporter access = %v, want %v", err, connect.ErrAuthContextReleased)
		}
	})
}

func TestAuthContextOwnerIgnoresIncidentalClose(t *testing.T) {
	source := &closingOnlyAuthContext{AuthContext: nettest.NewAuthContext()}
	owner := newAuthContextOwner(source, nil)
	if err := owner.finishRelease(time.Second, authReleaseReturnImmediate); err != nil {
		t.Fatalf("release error = %v", err)
	}
	if source.closed {
		t.Fatal("incidental Close was invoked")
	}
}

func TestWireCloseJoinsCarrierAndAuthReleaseErrors(t *testing.T) {
	carrierErr := errors.New("carrier close sentinel")
	releaseErr := errors.New("auth release sentinel")
	owner := newAuthContextOwner(&lifecycleAuthContext{base: nettest.NewAuthContext(), releaseErr: releaseErr}, nil)
	wire := newTestWire(connect.UpgradeResult{Stream: &closeErrorStream{err: carrierErr}}, owner)

	err := wire.Close()
	if !errors.Is(err, ErrWireClosed) || !errors.Is(err, carrierErr) || !errors.Is(err, releaseErr) {
		t.Fatalf("Close error = %v, want ErrWireClosed with carrier and release errors", err)
	}
	if second := wire.Close(); !errors.Is(second, carrierErr) || !errors.Is(second, releaseErr) {
		t.Fatalf("second Close error = %v, want stable carrier and release errors", second)
	}
}

func TestWireCloseRevokesAndReleasesBeforeBlockedCarrierReturns(t *testing.T) {
	entered := make(chan struct{})
	unblock := make(chan struct{})
	source := &lifecycleAuthContext{base: nettest.NewAuthContext()}
	owner := newAuthContextOwner(source, nil)
	wire := newTestWire(connect.UpgradeResult{Stream: &blockingCloseStream{entered: entered, unblock: unblock}}, owner)
	exporter := wire.Auth().Exporter()
	closeDone := make(chan error, 1)
	go func() { closeDone <- wire.Close() }()

	select {
	case <-entered:
	case <-time.After(time.Second):
		t.Fatal("carrier Close did not start")
	}
	if got := wire.Auth().SendKey(); got != nil {
		t.Fatalf("auth remained live during blocked carrier Close: %x", got)
	}
	if _, err := exporter.Derive("blocked-carrier", nil, 16); !errors.Is(err, connect.ErrAuthContextReleased) {
		t.Fatalf("retained exporter error = %v, want %v", err, connect.ErrAuthContextReleased)
	}
	awaitLifecycleCondition(t, func() bool { return source.releaseCount() == 1 })
	close(unblock)
	if err := <-closeDone; err != nil {
		t.Fatalf("Wire.Close error = %v", err)
	}
}

func TestExplicitWireCloseSuppressesImmediateTimeoutObservationAndReportsLateError(t *testing.T) {
	unblock := make(chan struct{})
	lateErr := errors.New("explicit late release sentinel")
	source := &lifecycleAuthContext{base: nettest.NewAuthContext(), releaseBlock: unblock, releaseErr: lateErr}
	observed := make(chan error, 2)
	owner := newAuthContextOwner(source, func(err error) { observed <- err })
	wire := newTestWire(
		connect.UpgradeResult{Stream: &closeErrorStream{}},
		owner,
	)
	wire.authContextReleaseTimeout = 20 * time.Millisecond

	err := wire.Close()
	if !errors.Is(err, ErrWireClosed) || !errors.Is(err, connect.ErrAuthContextReleaseTimeout) {
		t.Fatalf("Wire.Close error = %v, want ErrWireClosed with %v", err, connect.ErrAuthContextReleaseTimeout)
	}
	select {
	case got := <-observed:
		t.Fatalf("explicit Close reported immediate timeout to observer: %v", got)
	default:
	}
	close(unblock)
	select {
	case got := <-observed:
		if !errors.Is(got, lateErr) {
			t.Fatalf("late observed error = %v, want %v", got, lateErr)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for explicit Close late release error")
	}
	second := wire.Close()
	if !errors.Is(second, connect.ErrAuthContextReleaseTimeout) || errors.Is(second, lateErr) {
		t.Fatalf("stable second Close error = %v, want timeout without late mutation", second)
	}
}

func TestAuthContextClaimAndReleaseAreLinearizable(t *testing.T) {
	for range 100 {
		source := &lifecycleAuthContext{base: nettest.NewAuthContext()}
		owner := newAuthContextOwner(source, nil)
		claimer := owner.authContext().(connect.ChannelUseClaimer)
		start := make(chan struct{})
		claimDone := make(chan error, 1)
		releaseDone := make(chan error, 1)
		go func() {
			<-start
			claimDone <- claimer.ClaimChannelUse()
		}()
		go func() {
			<-start
			releaseDone <- owner.finishRelease(time.Second, authReleaseReturnImmediate)
		}()
		close(start)
		claimErr := <-claimDone
		if claimErr != nil && !errors.Is(claimErr, connect.ErrAuthContextReleased) {
			t.Fatalf("claim/release race error = %v", claimErr)
		}
		if err := <-releaseDone; err != nil {
			t.Fatalf("claim/release race release error = %v", err)
		}
		if got := source.releaseCount(); got != 1 {
			t.Fatalf("claim/release race release count = %d, want 1", got)
		}
	}
}

func TestWireAuthConcurrentAccessDuringClose(t *testing.T) {
	source := &lifecycleAuthContext{base: nettest.NewAuthContext()}
	owner := newAuthContextOwner(source, nil)
	wire := newTestWire(connect.UpgradeResult{Stream: &closeErrorStream{}}, owner)
	view := wire.Auth()
	retainedExporter := view.Exporter()
	start := make(chan struct{})
	var workers sync.WaitGroup
	for range 16 {
		workers.Go(func() {
			<-start
			for range 100 {
				_ = view.SendKey()
				_ = view.ReceiveKey()
				_ = view.SessionBinding()
				if exporter := view.Exporter(); exporter != nil {
					_, err := exporter.Derive("concurrent-close", nil, 16)
					if err != nil && !errors.Is(err, connect.ErrAuthContextReleased) {
						t.Errorf("view exporter error = %v", err)
						return
					}
				}
				_, err := retainedExporter.Derive("retained-concurrent-close", nil, 16)
				if err != nil && !errors.Is(err, connect.ErrAuthContextReleased) {
					t.Errorf("retained exporter error = %v", err)
					return
				}
			}
		})
	}
	close(start)
	if err := wire.Close(); err != nil {
		t.Fatalf("Wire.Close error = %v", err)
	}
	workers.Wait()
	if got := source.releaseCount(); got != 1 {
		t.Fatalf("concurrent close release count = %d, want 1", got)
	}
}

type lifecycleAuthContext struct {
	base         connect.AuthContext
	releaseBlock <-chan struct{}
	releaseErr   error

	mu       sync.Mutex
	claims   int
	releases int
}

func (a *lifecycleAuthContext) SendKey() []byte        { return a.base.SendKey() }
func (a *lifecycleAuthContext) ReceiveKey() []byte     { return a.base.ReceiveKey() }
func (a *lifecycleAuthContext) SessionBinding() []byte { return a.base.SessionBinding() }
func (a *lifecycleAuthContext) Exporter() connect.KeyExporter {
	return a.base.Exporter()
}

func (a *lifecycleAuthContext) ClaimChannelUse() error {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.claims > 0 {
		return connect.ErrChannelUseClaimed
	}
	a.claims++
	return nil
}

func (a *lifecycleAuthContext) ReleaseAuthContext() error {
	a.mu.Lock()
	a.releases++
	a.mu.Unlock()
	if a.releaseBlock != nil {
		<-a.releaseBlock
	}
	return a.releaseErr
}

func (a *lifecycleAuthContext) releaseCount() int {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.releases
}

type closingOnlyAuthContext struct {
	connect.AuthContext
	closed bool
}

type panickingExporterAuth struct {
	connect.AuthContext
}

func (panickingExporterAuth) Exporter() connect.KeyExporter {
	panic("exporter panic sentinel")
}

func (a *closingOnlyAuthContext) Close() error {
	a.closed = true
	return nil
}

type closeErrorStream struct {
	err error
}

func (*closeErrorStream) Read([]byte) (int, error)    { return 0, io.EOF }
func (*closeErrorStream) Write(p []byte) (int, error) { return len(p), nil }
func (s *closeErrorStream) Close() error              { return s.err }

type blockingCloseStream struct {
	entered chan struct{}
	unblock chan struct{}
}

func (*blockingCloseStream) Read([]byte) (int, error)    { return 0, io.EOF }
func (*blockingCloseStream) Write(p []byte) (int, error) { return len(p), nil }
func (s *blockingCloseStream) Close() error {
	close(s.entered)
	<-s.unblock
	return nil
}

func awaitLifecycleCondition(t *testing.T, condition func() bool) {
	t.Helper()
	deadline := time.Now().Add(time.Second)
	for !condition() {
		if time.Now().After(deadline) {
			t.Fatal("timed out waiting for lifecycle condition")
		}
		time.Sleep(time.Millisecond)
	}
}
