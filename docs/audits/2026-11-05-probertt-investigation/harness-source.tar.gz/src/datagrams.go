package wiremux

import (
	"context"
	"errors"
	"fmt"
	"reflect"
	"sync"
	"sync/atomic"

	"github.com/GridSwarm/wiremux/connect"
	"github.com/GridSwarm/wiremux/internal/datagramadmission"
)

const (
	datagramApplicationDiscriminator = byte(0x00)
	datagramSendQueueCapacity        = 8
)

var (
	errDatagramCarrierLifetimeEndedWithoutCause = errors.New("wiremux: Datagram carrier lifetime ended without a cause")
	errDatagramCarrierInvalidReceiveResult      = errors.New("wiremux: Datagram carrier returned an invalid receive result")
)

// Datagrams is a borrowed view of an established Wire's optional
// unreliable-unordered atomic-message plane. It has no independent Close;
// Wire.Close owns both reliable and Datagram teardown.
type Datagrams struct {
	carrier    connect.DatagramCarrier
	maxPayload int
	// fault reports a Datagram-plane fault to the Wire, which alone decides
	// whether it starts Aggregate teardown. The handle never reads Wire state.
	fault func(error)

	gateMu sync.Mutex
	closed atomic.Bool
	done   chan struct{}
	ctx    context.Context
	cancel context.CancelFunc

	causeMu sync.RWMutex
	cause   error

	// Exactly one of sendAdmission and owned is set, by the constructor. With
	// sendAdmission, Send admits into the root queue and the pump hands each
	// payload to the carrier. With owned, the native construction path's
	// carrier, Send admits straight into the carrier's own queue, the Wire's
	// only send queue, and no pump runs.
	sendAdmission *datagramadmission.Queue
	owned         ownedDatagramCarrier
	workers       sync.WaitGroup

	// receiveToken makes Receive single-flight; its holder alone touches
	// keptReceive.
	receiveToken chan struct{}
	keptReceive  keptReceiveContext
	// freshReceive records, once per carrier, that the carrier declares
	// freshReceiveCarrier, so Receive strips the envelope without copying.
	freshReceive bool

	testBeforeReceiveDelivery func()
}

// ownedDatagramCarrier is a carrier whose own bounded, cancellable admission
// queue can be a Wire's only Datagram send queue. Only the native construction
// path builds a handle over one through newOwnedDatagrams; a carrier passed to
// newDatagramsUnstarted keeps the root queue and pump whatever its methods.
type ownedDatagramCarrier interface {
	connect.DatagramCarrier
	// sendOwned admits framed, which the caller must not touch afterwards,
	// without copying it. It reports a *datagramadmission.SealedError after
	// sealAdmission, the call's context error, or another failure.
	sendOwned(ctx context.Context, framed []byte) error
	// sealAdmission seals the carrier's admission queue; the first seal wins.
	sealAdmission()
}

// freshReceiveCarrier is a carrier that declares every slice its
// ReceiveDatagram returns to be a fresh allocation that it and everything
// beneath it never touch again, so Receive may hand the caller that slice past
// the envelope byte instead of a copy. The method is unexported, so only a
// wiremux type can declare it; every other carrier, including any
// connect.DatagramCarrier a third party supplies, keeps Receive's copy.
type freshReceiveCarrier interface {
	connect.DatagramCarrier
	receivesFresh()
}

// keptReceiveContext is the merged receive context Receive keeps while the
// caller passes the same comparable context: parent canceled also by gate
// closure. Its registrations are released by the next call with a different
// context, by parent's end, or by gate closure, the last two through the
// cancellation they trigger.
type keptReceiveContext struct {
	parent context.Context
	// parentType is parent's dynamic type, and everyValueComparable records
	// that every value of it compares with == without panicking, so a later
	// context of that type needs no value check.
	parentType           reflect.Type
	everyValueComparable bool
	merged               context.Context
	stop                 func() bool
	cancel               context.CancelFunc
}

func newDatagramsUnstarted(carrier connect.DatagramCarrier, fault func(error), queueCapacity int) *Datagrams {
	d := newDatagramsHandle(carrier, fault)
	d.sendAdmission = datagramadmission.New(carrier.Lifetime(), queueCapacity)
	d.workers.Add(1)
	return d
}

// newOwnedDatagrams returns a handle whose Send admits straight into
// carrier's own queue. It builds no root queue and needs no start: no pump
// runs, so drain has nothing to join.
func newOwnedDatagrams(carrier ownedDatagramCarrier, fault func(error)) *Datagrams {
	d := newDatagramsHandle(carrier, fault)
	d.owned = carrier
	return d
}

func newDatagramsHandle(carrier connect.DatagramCarrier, fault func(error)) *Datagrams {
	ctx, cancel := context.WithCancel(context.Background()) // #nosec G118 -- cancel is owned by end.
	d := &Datagrams{
		carrier:      carrier,
		maxPayload:   carrier.MaxDatagramPayload() - 1,
		fault:        fault,
		done:         make(chan struct{}),
		ctx:          ctx,
		cancel:       cancel,
		receiveToken: make(chan struct{}, 1),
	}
	d.receiveToken <- struct{}{}
	_, d.freshReceive = carrier.(freshReceiveCarrier)
	return d
}

func (d *Datagrams) start() {
	go d.pumpSends()
}

// MaxPayload returns the lifetime-fixed exact maximum consumer payload size.
func (d *Datagrams) MaxPayload() int {
	if d == nil {
		return 0
	}
	return d.maxPayload
}

// Send copies and admits one payload for possible transmission. Success means
// admission, not transmission or delivery. A nil context is treated as
// context.Background().
func (d *Datagrams) Send(ctx context.Context, payload []byte) error {
	if d == nil {
		return ErrWireClosed
	}
	if d.closed.Load() {
		return d.closedError()
	}
	if cause, ended := d.endedCarrierLifetime(); ended {
		d.fault(cause)
		return d.closedError()
	}
	if len(payload) > d.maxPayload {
		return fmt.Errorf("%w: payload size %d exceeds maximum %d", ErrDatagramTooLarge, len(payload), d.maxPayload)
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		if d.closed.Load() {
			return d.closedError()
		}
		return err
	}

	framed := make([]byte, len(payload)+1)
	framed[0] = datagramApplicationDiscriminator
	copy(framed[1:], payload)
	if d.owned != nil {
		return d.sendOwned(ctx, framed)
	}
	err := d.sendAdmission.Admit(ctx, framed)
	if err == nil {
		return nil
	}
	var sealed *datagramadmission.SealedError
	if errors.As(err, &sealed) {
		return d.closedError()
	}
	if errors.Is(err, datagramadmission.ErrOwnerEnded) {
		cause, _ := d.endedCarrierLifetime()
		d.fault(cause)
		return d.closedError()
	}
	if d.closed.Load() {
		return d.closedError()
	}
	return err
}

// sendOwned admits framed into the carrier's own queue and maps the outcome
// as the pump maps a lower send: a seal or a closed gate is the closed error,
// the call's own context ending is that context's error, and any other
// failure faults the Wire, with the carrier lifetime's cause once it ended.
func (d *Datagrams) sendOwned(ctx context.Context, framed []byte) error {
	err := d.owned.sendOwned(ctx, framed)
	if err == nil {
		return nil
	}
	var sealed *datagramadmission.SealedError
	if errors.As(err, &sealed) || d.closed.Load() {
		return d.closedError()
	}
	if ctxErr := ctx.Err(); ctxErr != nil && errors.Is(err, ctxErr) {
		return ctxErr
	}
	cause, ended := d.endedCarrierLifetime()
	if !ended {
		cause = err
	}
	d.fault(cause)
	return d.closedError()
}

func (d *Datagrams) endedCarrierLifetime() (error, bool) {
	lifetime := d.carrier.Lifetime()
	if lifetime.Err() == nil {
		select {
		case <-lifetime.Done():
		default:
			return nil, false
		}
	}
	cause := context.Cause(lifetime)
	if cause == nil {
		cause = errDatagramCarrierLifetimeEndedWithoutCause
	}
	return cause, true
}

// Receive waits for one application Datagram. Empty native frames and
// reserved discriminators are silently dropped. A nil context is treated as
// context.Background().
func (d *Datagrams) Receive(ctx context.Context) ([]byte, error) {
	if d == nil {
		return nil, ErrWireClosed
	}
	if d.closed.Load() {
		return nil, d.closedError()
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		if d.closed.Load() {
			return nil, d.closedError()
		}
		d.releaseKeptReceiveIfIdle()
		return nil, err
	}

	select {
	case <-d.done:
		return nil, d.closedError()
	case <-ctx.Done():
		if d.closed.Load() {
			return nil, d.closedError()
		}
		d.releaseKeptReceiveIfIdle()
		return nil, ctx.Err()
	case <-d.receiveToken:
	}
	defer func() { d.receiveToken <- struct{}{} }()

	if d.closed.Load() {
		return nil, d.closedError()
	}
	if err := ctx.Err(); err != nil {
		d.releaseKeptReceive()
		return nil, err
	}
	callCtx, stop, cancel := d.receiveContext(ctx)
	if stop != nil {
		defer func() {
			stop()
			cancel()
		}()
	}

	for {
		payload, err := d.carrier.ReceiveDatagram(callCtx)
		if d.closed.Load() {
			return nil, d.closedError()
		}
		if (payload == nil) == (err == nil) {
			cause := err
			if cause == nil {
				cause = errDatagramCarrierInvalidReceiveResult
			}
			d.fault(cause)
			return nil, d.closedError()
		}
		if err != nil {
			if d.closed.Load() {
				return nil, d.closedError()
			}
			if ctxErr := ctx.Err(); ctxErr != nil {
				return nil, ctxErr
			}
			d.fault(err)
			return nil, d.closedError()
		}
		if len(payload) == 0 || payload[0] != datagramApplicationDiscriminator {
			if d.closed.Load() {
				return nil, d.closedError()
			}
			if ctxErr := ctx.Err(); ctxErr != nil {
				if d.closed.Load() {
					return nil, d.closedError()
				}
				return nil, ctxErr
			}
			continue
		}
		var owned []byte
		if d.freshReceive {
			owned = payload[1:]
		} else {
			owned = make([]byte, len(payload)-1)
			copy(owned, payload[1:])
		}
		if d.testBeforeReceiveDelivery != nil {
			d.testBeforeReceiveDelivery()
		}
		d.gateMu.Lock()
		if d.closed.Load() {
			d.gateMu.Unlock()
			return nil, d.closedError()
		}
		d.gateMu.Unlock()
		return owned, nil
	}
}

// receiveContext returns the merged context for one Receive call: ctx,
// canceled also by gate closure. It reuses the kept merged context while the
// caller passes the same comparable context and keeps a new one for any other
// comparable context, releasing the previous one first; a call that ends
// canceled before reaching it releases the kept one too. A context whose
// dynamic value is not comparable never reaches the identity check, where ==
// would panic; it gets a merged context for this call alone, whose stop and
// cancel the caller runs when the call ends. Only the receiveToken holder
// calls it.
func (d *Datagrams) receiveContext(ctx context.Context) (callCtx context.Context, stop func() bool, cancel context.CancelFunc) {
	kept := &d.keptReceive
	if kept.merged != nil && reflect.TypeOf(ctx) == kept.parentType &&
		(kept.everyValueComparable || reflect.ValueOf(ctx).Comparable()) &&
		ctx == kept.parent && kept.merged.Err() == nil {
		return kept.merged, nil, nil
	}
	d.releaseKeptReceive()
	merged, cancel := context.WithCancel(ctx)
	stop = context.AfterFunc(d.ctx, cancel)
	t := reflect.TypeOf(ctx)
	if !t.Comparable() {
		return merged, stop, cancel
	}
	everyValue := comparesWithoutInterfaces(t)
	if !everyValue && !reflect.ValueOf(ctx).Comparable() {
		return merged, stop, cancel
	}
	*kept = keptReceiveContext{parent: ctx, parentType: t, everyValueComparable: everyValue, merged: merged, stop: stop, cancel: cancel}
	return merged, nil, nil
}

// releaseKeptReceive releases the kept merged context, if any. Only the
// receiveToken holder calls it.
func (d *Datagrams) releaseKeptReceive() {
	kept := &d.keptReceive
	if kept.merged == nil {
		return
	}
	kept.stop()
	kept.cancel()
	*kept = keptReceiveContext{}
}

// releaseKeptReceiveIfIdle is releaseKeptReceive for a call that ends
// canceled without holding receiveToken. It counts as the next call with a
// different context, so it releases the kept registration when no Receive is
// in flight; it never waits for the token, so a canceled call returns at
// once, and it leaves an in-flight Receive's merged context alone. A kept
// context that is the canceled one has already ended, so releasing it
// unconditionally is right for both.
func (d *Datagrams) releaseKeptReceiveIfIdle() {
	select {
	case <-d.receiveToken:
		d.releaseKeptReceive()
		d.receiveToken <- struct{}{}
	default:
	}
}

// comparesWithoutInterfaces reports whether comparable type t holds no
// interface, so that == on two of its values never panics. An interface
// inside t can hold an uncomparable dynamic value.
func comparesWithoutInterfaces(t reflect.Type) bool {
	switch t.Kind() {
	case reflect.Interface:
		return false
	case reflect.Array:
		return comparesWithoutInterfaces(t.Elem())
	case reflect.Struct:
		for i := range t.NumField() {
			if !comparesWithoutInterfaces(t.Field(i).Type) {
				return false
			}
		}
		return true
	default:
		return true
	}
}

func (d *Datagrams) pumpSends() {
	defer d.workers.Done()
	for {
		select {
		case <-d.done:
			return
		default:
		}

		payload, ok := d.sendAdmission.Dequeue()
		if !ok {
			return
		}
		if d.closed.Load() {
			return
		}
		if cause, ended := d.endedCarrierLifetime(); ended {
			d.fault(cause)
			return
		}
		if err := d.carrier.SendDatagram(d.ctx, payload); err != nil {
			if d.closed.Load() {
				return
			}
			if errors.Is(err, connect.ErrDatagramTooLarge) {
				d.fault(err)
				return
			}
			if d.carrier.Lifetime().Err() != nil {
				return
			}
			continue
		}
	}
}

// end seals the Datagram gate: it records the first non-nil cause, seals send
// admission (the root queue, or the owned carrier's queue), cancels in-flight
// carrier calls, and closes done. The seal is the commit point: no Send
// succeeds after it. It is idempotent, and only the Wire decides when it runs
// and with which cause.
func (d *Datagrams) end(cause error) {
	if cause != nil {
		d.setCause(cause)
	}
	if d.owned != nil {
		d.owned.sealAdmission()
	} else {
		d.sendAdmission.Close(cause)
	}
	d.gateMu.Lock()
	if d.closed.CompareAndSwap(false, true) {
		d.cancel()
		close(d.done)
	}
	d.gateMu.Unlock()
}

func (d *Datagrams) setCause(cause error) {
	if cause == nil {
		return
	}
	cause = sanitizeWireError(cause)
	d.causeMu.Lock()
	if d.cause == nil {
		d.cause = cause
	}
	d.causeMu.Unlock()
}

func (d *Datagrams) closedError() error {
	d.causeMu.RLock()
	cause := d.cause
	d.causeMu.RUnlock()
	if cause == nil {
		return ErrWireClosed
	}
	return fmt.Errorf("%w: %w", ErrWireClosed, cause)
}

// drain joins the handle's workers after end has released them.
func (d *Datagrams) drain() {
	d.workers.Wait()
}
