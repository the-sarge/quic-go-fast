# CLAUDE.md

This file exists as a pointer for Claude-family agents. The authoritative
agent-facing content is in [`AGENTS.md`](AGENTS.md) (which is
agent-family-agnostic).

**Read [`AGENTS.md`](AGENTS.md) first.** Everything relevant is there or
linked from there.
