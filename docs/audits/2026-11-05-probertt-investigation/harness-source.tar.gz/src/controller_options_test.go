//go:build linux || darwin || windows

package wiremux

import (
	"context"
	"net"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/transport/quic"
)

func TestConfiguredQUICTransportOptions(t *testing.T) {
	tr, err := quic.NewConfiguredTransport(quic.Transport{}, quic.EndpointConfig{ACKPolicy: quic.ACKConservative})
	if err != nil {
		t.Fatal(err)
	}
	m := managedConfig{}
	WithManagedQUICTransport(tr)(&m)
	cfg, err := newDialConfig(m.options)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.upgradePlan.transport != tr {
		t.Fatal("managed transport: got different instance, want configured transport")
	}
	if _, err := newDialConfig([]Option{WithTransport((*quic.ConfiguredTransport)(nil))}); err == nil {
		t.Fatal("nil configured transport: got accepted, want rejection")
	}
	// Exact configured identity retains selected and owned-packet capabilities.
	if _, err := newDialConfig([]Option{WithSelection(selectedLoopbackForTest(t)), WithTransport(tr)}); err != nil {
		t.Fatal(err)
	}
	mc := migrationConfig{}
	WithMigrationQUICTransport(tr)(&mc)
	if !mc.quicTransportSet || mc.quicTransport != tr {
		t.Fatal("migration transport: got missing configuration, want configured transport")
	}
	s, err := tr.NewSession(context.Background(), nil)
	if err != nil {
		t.Fatal(err)
	}
	_ = s.Close()
}

func TestConfiguredQUICManagedAndMigration(t *testing.T) {
	controller := quic.CongestionReno
	if quic.BBRv3Supported() {
		controller = quic.CongestionBBRv3
	}
	tr, err := quic.NewConfiguredTransport(quic.Transport{}, quic.EndpointConfig{CongestionController: controller, ACKPolicy: quic.ACKConservative})
	if err != nil {
		t.Fatal(err)
	}
	left, right := managedTestPair(t, WithManagedQUICTransport(tr))
	migrationTransfer(t, left, right, "configured managed")
	old, oldPeer := managedTestPair(t, WithManagedRelayOnly())
	raw, peerRaw := net.Pipe()
	a, b := migrationTestAuth(t)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	type result struct {
		s   *MigrationSession
		err error
	}
	done := make(chan result, 1)
	go func() {
		s, err := PrepareMigration(ctx, old, raw, a, "wiremux://127.0.0.1:1", WithMigrationQUICTransport(tr))
		done <- result{s, err}
	}()
	other, err := PrepareMigration(ctx, oldPeer, peerRaw, b, "wiremux://127.0.0.1:1", WithMigrationQUICTransport(tr))
	first := <-done
	if err != nil || first.err != nil {
		t.Fatalf("configured migration: got %v / %v, want ready", first.err, err)
	}
	l, r := first.s.Commit(), other.Commit()
	if l.Outcome() != MigrationCommitted || r.Outcome() != MigrationCommitted {
		t.Fatalf("configured migration: got %v / %v, want committed", l, r)
	}
	t.Cleanup(func() { _ = l.Wire().Close(); _ = r.Wire().Close() })
	migrationTransfer(t, l.Wire(), r.Wire(), "configured migration")
}
