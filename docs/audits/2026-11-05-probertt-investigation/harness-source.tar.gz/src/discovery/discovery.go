// Package discovery provides interface-scoped multicast DNS datagram I/O for
// local discovery. An endpoint owns one socket per retained interface and
// address family, bound to the wildcard address at Port so it can share the
// port with a system responder, and joined to 224.0.0.251 or the
// interface-scoped ff02::fb on that interface only. The package carries bytes;
// DNS records, query flags, source-port reply rules and protocol timers belong
// to the caller.
//
// Only LAN-classified, multicast-capable interfaces participate, as in the
// binding package's Local mode. Every received datagram is admitted before
// delivery: the kernel packet-info record must be present, intact and name
// the binding's interface; the destination must be the family's group or one
// of that interface's current addresses; and the source must be an on-link
// peer reached through that interface, or the interface itself. Datagrams
// larger than MaxDatagram bytes are discarded, and an admitted datagram that
// finds the QueueLength-entry queue full is dropped and counted.
//
// A binding sends multicast only to its group, through its interface, from
// its explicit source, with TTL or hop limit 255. The only unicast send is a
// Reply capability minted from a received datagram; each Reply.Send re-admits
// the target as an on-link peer on the same interface. There is no generic
// send operation.
//
// Linux, macOS and Windows are supported for IPv4 and IPv6; other systems
// fail construction with selection.ErrUnsupported. The guarantee inherits
// selection's trusted current host configuration, and a received hop limit is
// never treated as authentication.
package discovery

import (
	"context"

	"github.com/GridSwarm/wiremux/internal/routeselection"
)

const (
	// Port is the multicast DNS port every binding receives on.
	Port = routeselection.DiscoveryPort
	// MaxDatagram bounds one received payload; larger datagrams are discarded.
	MaxDatagram = routeselection.MaxDiscoveryDatagram
	// QueueLength bounds admitted datagrams awaiting Receive.
	QueueLength = routeselection.DiscoveryQueueLength
)

// Config describes one endpoint. Selections restricts the interfaces; when
// empty, every interface that is currently up is considered.
type Config = routeselection.DiscoveryConfig

// Endpoint owns every binding, membership and receive worker it constructed.
// Close leaves the memberships, closes the sockets and joins in-flight
// operations.
type Endpoint = routeselection.DiscoveryEndpoint

// Binding is one interface-scoped socket for one address family.
type Binding = routeselection.DiscoveryBinding

// Facts is a copied description of one binding.
type Facts = routeselection.DiscoveryFacts

// Datagram is one admitted datagram and its reply capability.
type Datagram = routeselection.DiscoveryDatagram

// Reply is the capability to send unicast to one received source through the
// binding that admitted it. The zero value is invalid.
type Reply = routeselection.DiscoveryReply

// Failure is a copied construction failure. Group is invalid when the whole
// interface failed; Source is invalid when no source address was attempted.
type Failure = routeselection.DiscoveryFailure

// Error reports a construction that produced no binding.
type Error = routeselection.DiscoveryError

// Listen constructs the endpoint. Partial success returns an endpoint and its
// failures; zero successes returns *Error and no endpoint.
func Listen(ctx context.Context, cfg Config) (*Endpoint, error) {
	return routeselection.ListenDiscovery(ctx, cfg)
}
