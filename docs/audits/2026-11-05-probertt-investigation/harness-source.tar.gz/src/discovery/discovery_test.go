//go:build linux || darwin || windows

package discovery_test

import (
	"context"
	"errors"
	"net"
	"testing"

	"github.com/GridSwarm/wiremux/binding"
	"github.com/GridSwarm/wiremux/discovery"
	"github.com/GridSwarm/wiremux/selection"
)

// Native facts classify loopback as unknown, so the public constructor
// refuses it before opening any socket.
func TestListenRefusesNonLANInterface(t *testing.T) {
	interfaces, err := net.Interfaces()
	if err != nil {
		t.Fatal(err)
	}
	for _, iface := range interfaces {
		if iface.Flags&net.FlagLoopback == 0 || iface.Flags&net.FlagUp == 0 {
			continue
		}
		h, err := selection.Resolve(iface.Name)
		if err != nil {
			t.Fatal(err)
		}
		e, err := discovery.Listen(context.Background(), discovery.Config{Selections: []selection.Handle{h}})
		var none *discovery.Error
		if e != nil || !errors.As(err, &none) || len(none.Failures) != 1 || !errors.Is(err, binding.ErrPolicy) {
			t.Fatalf("loopback: got %v, %v, want one policy refusal", e, err)
		}
		return
	}
	t.Fatal("loopback interface: got none, want one")
}
