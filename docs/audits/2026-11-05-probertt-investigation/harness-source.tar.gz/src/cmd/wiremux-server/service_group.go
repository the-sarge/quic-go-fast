package main

import (
	"context"
	"errors"
	"fmt"
	"net"
	"sync"
	"time"

	"github.com/GridSwarm/wiremux/relay"
)

// serviceGroup is private to wiremux-server and is not safe for concurrent use.
// Call add sequentially before the single wait call; run and shutdown must be
// non-nil.
type serviceGroup struct {
	services         []serviceGroupService
	testBeforeReturn func()
}

type serviceGroupService struct {
	name     string
	run      func() error
	shutdown func(context.Context)
}

func (g *serviceGroup) add(name string, run func() error, shutdown func(context.Context)) {
	if run == nil {
		panic(fmt.Sprintf("serviceGroup.add(%q): run must be non-nil", name))
	}
	if shutdown == nil {
		panic(fmt.Sprintf("serviceGroup.add(%q): shutdown must be non-nil", name))
	}
	g.services = append(g.services, serviceGroupService{
		name:     name,
		run:      run,
		shutdown: shutdown,
	})
}

func (g *serviceGroup) wait(ctx context.Context, shutdownTimeout time.Duration) error {
	if g.testBeforeReturn != nil {
		defer g.testBeforeReturn()
	}
	errCh := make(chan serviceGroupResult, len(g.services))
	for _, service := range g.services {
		go func(service serviceGroupService) {
			errCh <- serviceGroupResult{name: service.name, err: service.run()}
		}(service)
	}

	var firstErr error
	remaining := len(g.services)
	shutdownStarted := false
	var shutdownCtx context.Context
	var shutdownCancel context.CancelFunc
	var shutdownDone <-chan struct{}
	shutdownsDone := true
	var shutdownsDoneCh <-chan struct{}
	ctxDone := ctx.Done()
	defer func() {
		if shutdownCancel != nil {
			shutdownCancel()
		}
	}()

	startShutdown := func() {
		if shutdownStarted {
			return
		}
		shutdownStarted = true
		ctxDone = nil
		//nolint:fatcontext // startShutdown is one-shot (guarded by shutdownStarted) and assigns wait's own shutdown context; nothing is nested per call.
		shutdownCtx, shutdownCancel = context.WithTimeout(context.Background(), shutdownTimeout) // #nosec G118 -- canceled by serviceGroup.wait deferred cleanup.
		shutdownDone = shutdownCtx.Done()
		shutdownsDone = false
		done := make(chan struct{})
		shutdownsDoneCh = done
		go func() {
			var wg sync.WaitGroup
			wg.Add(len(g.services))
			for _, service := range g.services {
				go func(service serviceGroupService) {
					defer wg.Done()
					service.shutdown(shutdownCtx)
				}(service)
			}
			wg.Wait()
			close(done)
		}()
	}

	recordResult := func(result serviceGroupResult) {
		remaining--
		err := result.err
		if (shutdownStarted || ctx.Err() != nil) && isExpectedServiceStopError(err) {
			err = nil
		}
		if err == nil {
			return
		}

		wrapped := fmt.Errorf("%s: %w", result.name, err)
		if firstErr == nil {
			firstErr = wrapped
			startShutdown()
			return
		}
		firstErr = errors.Join(firstErr, wrapped)
	}

	drainReadyResults := func() {
		for remaining > 0 {
			select {
			case result := <-errCh:
				recordResult(result)
			default:
				return
			}
		}
	}

	for remaining > 0 || !shutdownsDone {
		select {
		case <-ctxDone:
			startShutdown()
		case result := <-errCh:
			recordResult(result)
		case <-shutdownDone:
			drainReadyResults()
			if remaining > 0 || !shutdownsDone {
				return errors.Join(firstErr, fmt.Errorf("shutdown timed out: %w", context.DeadlineExceeded))
			}
		case <-shutdownsDoneCh:
			drainReadyResults()
			if errors.Is(shutdownCtx.Err(), context.DeadlineExceeded) {
				return errors.Join(firstErr, fmt.Errorf("shutdown timed out: %w", context.DeadlineExceeded))
			}
			shutdownsDone = true
			shutdownsDoneCh = nil
		}
	}
	return firstErr
}

type serviceGroupResult struct {
	name string
	err  error
}

func isExpectedServiceStopError(err error) bool {
	if !errors.Is(err, net.ErrClosed) {
		return false
	}
	return !errors.Is(err, relay.ErrShutdownTimeout) &&
		!errors.Is(err, relay.ErrShutdownAccounting)
}
