//go:build unix

package main

import (
	"context"
	"fmt"
	"io"
	"os"
	"os/signal"
	"sync"
	"syscall"
)

// reloadShapingOnHangup owns SIGHUP for the lifetime of serve: with a reload
// function it applies the relay shaping file on every SIGHUP, and without one
// (no shaping file, or no relay at all) it swallows the signal, because the
// default disposition would terminate the process. Outcomes are reported on
// stderr; a rejected file keeps the running values, so an incident-time edit
// can never take the relay down. The returned stop is idempotent.
func reloadShapingOnHangup(ctx context.Context, reload func() error, stderr io.Writer) func() {
	hangups := make(chan os.Signal, 1)
	signal.Notify(hangups, syscall.SIGHUP)
	done := make(chan struct{})
	stopped := make(chan struct{})
	go func() {
		defer close(stopped)
		for {
			select {
			case <-hangups:
				if reload == nil {
					continue // SIGHUP without a shaping file is a no-op
				}
				if err := reload(); err != nil {
					fmt.Fprintf(stderr, "relay shaping reload failed; keeping running values: %v\n", err)
					continue
				}
				fmt.Fprintln(stderr, "relay shaping reloaded")
			case <-ctx.Done():
				return
			case <-done:
				return
			}
		}
	}()
	var stopOnce sync.Once
	return func() {
		stopOnce.Do(func() {
			signal.Stop(hangups)
			close(done)
			<-stopped
		})
	}
}
