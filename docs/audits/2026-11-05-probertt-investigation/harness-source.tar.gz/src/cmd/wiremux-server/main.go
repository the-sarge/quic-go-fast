package main

import (
	"context"
	"fmt"
	"io"
	"os"
	"runtime/debug"
)

var usageText = `usage:
  wiremux-server serve [flags]
  wiremux-server --version

wiremux-server runs the wiremux relay and STUN responder. Relay TLS is
configured with --tls-cert/--tls-key for private relays or --acme for public
relays.

flags:
` + serveFlagsUsage

// versionOutputFormat is the machine-relevant --version output contract; the
// release CLI manifest freezes it for v0.1.x.
const versionOutputFormat = "wiremux-server version=%s revision=%s\n"

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

func run(args []string, stdout, stderr io.Writer) int {
	if len(args) == 0 {
		if stderr != nil {
			fmt.Fprint(stderr, usageText)
		}
		return 2
	}

	switch args[0] {
	case "serve":
		return runServe(context.Background(), args[1:], stderr)
	case "--version":
		if len(args) != 1 {
			if stderr != nil {
				fmt.Fprintln(stderr, "--version does not accept arguments")
			}
			return 2
		}
		version, revision := buildIdentity()
		if stdout != nil {
			fmt.Fprintf(stdout, versionOutputFormat, version, revision)
		}
		return 0
	case "-h", "--help", "help":
		if stderr != nil {
			fmt.Fprint(stderr, usageText)
		}
		return 0
	default:
		if stderr != nil {
			fmt.Fprintf(stderr, "unknown command %q\n\n%s", args[0], usageText)
		}
		return 2
	}
}

func buildIdentity() (string, string) {
	version := "devel"
	revision := "unknown"
	info, ok := debug.ReadBuildInfo()
	if !ok {
		return version, revision
	}
	if info.Main.Version != "" && info.Main.Version != "(devel)" {
		version = info.Main.Version
	}
	modified := false
	for _, setting := range info.Settings {
		switch setting.Key {
		case "vcs.revision":
			if setting.Value != "" {
				revision = setting.Value
			}
		case "vcs.modified":
			modified = setting.Value == "true"
		}
	}
	if modified {
		revision += "+modified"
	}
	return version, revision
}
