package main

import (
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"testing"
)

// TestHTTPServersConstructedWithExplicitHandler is the package census for
// http.Server handler explicitness. This binary imports net/http/pprof, which
// registers the profiling handlers on the process-wide http.DefaultServeMux,
// and net/http serves DefaultServeMux whenever a Server's Handler is nil. Any
// server in this package constructed without an explicit non-nil Handler
// would therefore silently expose pprof on its listener. The census
// default-denies: only a composite literal with an explicit non-nil Handler
// field and the *http.Server pointer type outside a type declaration are
// audited-safe uses of the type; every other form — including a package-local
// named type or alias over http.Server, which would let composite literals
// construct servers without naming the type — fails until this census is
// consciously extended.
//
// The census is syntactic (go/parser only, no go/types), and that is a
// deliberate ceiling: it classifies the Handler value by its spelling, not
// by its type or its runtime value. A nil interface produced by a call
// expression — a conversion such as http.Handler(nil), or a call that
// returns nil — is a documented non-goal (#1410). The default-denial
// alternative #1410 weighed would flag any one-argument call whose
// argument is the nil literal, catching the conversion forms at the cost
// of also flagging legitimate wrappers such as wrapHandler(nil); a
// callee-name heuristic limited to the net/http conversions would be a
// guarantee in name only. Reviewers own the pinned residual: a Handler
// spelled as a call expression, conversions included, must visibly return
// a non-nil handler.
func TestHTTPServersConstructedWithExplicitHandler(t *testing.T) {
	_, thisFile, _, ok := runtime.Caller(0)
	if !ok {
		t.Fatal("runtime.Caller failed")
	}
	dir := filepath.Dir(thisFile)
	if !filepath.IsAbs(thisFile) {
		// Under -trimpath builds runtime.Caller reports an import-path-relative
		// filename that exists nowhere on disk, and Glob returns no matches
		// without an error. The test binary runs in the package source
		// directory, so fall back to the working directory rather than passing
		// vacuously.
		wd, err := os.Getwd()
		if err != nil {
			t.Fatalf("Getwd: %v", err)
		}
		dir = wd
	}
	matches, err := filepath.Glob(filepath.Join(dir, "*.go"))
	if err != nil {
		t.Fatalf("glob package sources: %v", err)
	}
	fset := token.NewFileSet()
	parsed := 0
	var violations []string
	for _, path := range matches {
		if strings.HasSuffix(path, "_test.go") {
			continue
		}
		file, err := parser.ParseFile(fset, path, nil, 0)
		if err != nil {
			t.Fatalf("ParseFile %s: %v", path, err)
		}
		parsed++
		violations = append(violations, httpServerHandlerViolations(fset, file)...)
	}
	if parsed == 0 {
		t.Fatalf("no non-test package sources found in %s; the census must not pass vacuously", dir)
	}
	if len(violations) > 0 {
		t.Fatalf("http.Server uses that can serve http.DefaultServeMux (where net/http/pprof registers its handlers):\n%s", strings.Join(violations, "\n"))
	}
}

// httpServerHandlerViolations reports every syntactically recognized use of
// the net/http Server type in file that could yield a server whose nil
// Handler falls back to http.DefaultServeMux, plus any import form that
// would blind this audit. Its nil check is literal-only: a nil interface
// produced by a call expression such as http.Handler(nil) lies outside the
// census's documented parser-only ceiling (see the census doc comment and
// #1410).
func httpServerHandlerViolations(fset *token.FileSet, file *ast.File) []string {
	var violations []string
	report := func(pos token.Pos, message string) {
		p := fset.Position(pos)
		violations = append(violations, fmt.Sprintf("%s:%d: %s", p.Filename, p.Line, message))
	}

	httpNames := map[string]bool{}
	for _, imp := range file.Imports {
		path, err := strconv.Unquote(imp.Path.Value)
		if err != nil || path != "net/http" {
			continue
		}
		switch {
		case imp.Name == nil:
			httpNames["http"] = true
		case imp.Name.Name == ".":
			report(imp.Pos(), "dot import of net/http hides http.Server references from the handler census; use a named import")
		case imp.Name.Name == "_":
		default:
			httpNames[imp.Name.Name] = true
		}
	}
	if len(httpNames) == 0 {
		return violations
	}

	unparen := func(expr ast.Expr) ast.Expr {
		for {
			paren, ok := expr.(*ast.ParenExpr)
			if !ok {
				return expr
			}
			expr = paren.X
		}
	}

	serverType := func(expr ast.Expr) *ast.SelectorExpr {
		sel, ok := expr.(*ast.SelectorExpr)
		if !ok {
			return nil
		}
		pkg, ok := sel.X.(*ast.Ident)
		if !ok || !httpNames[pkg.Name] || sel.Sel.Name != "Server" {
			return nil
		}
		return sel
	}

	checkComposite := func(lit *ast.CompositeLit) {
		for _, elt := range lit.Elts {
			kv, ok := elt.(*ast.KeyValueExpr)
			if !ok {
				report(elt.Pos(), "http.Server composite literal must use Handler: key-value form so the census can audit the Handler field")
				return
			}
			key, ok := kv.Key.(*ast.Ident)
			if !ok || key.Name != "Handler" {
				continue
			}
			if value, ok := unparen(kv.Value).(*ast.Ident); ok && value.Name == "nil" {
				report(kv.Value.Pos(), "http.Server Handler is the nil literal; a nil Handler serves http.DefaultServeMux")
			}
			return
		}
		report(lit.Pos(), "http.Server composite literal without an explicit Handler field; the zero Handler serves http.DefaultServeMux")
	}

	// Within an array, slice, or map literal, Go lets a child composite
	// literal elide its type (including an elided &T for a *T element or key
	// type), so `[]*http.Server{{Addr: ":0"}}` constructs a server without
	// ever naming the type at the construction site. Carry the enclosing
	// element, key, and value types through elided children and audit any
	// child whose inherited type is *http.Server. Children that spell their
	// own type are audited by the main walk; non-literal elements such as a
	// nil pointer construct no server.
	var auditElidedElements func(lit *ast.CompositeLit, litType ast.Expr)
	auditElidedElements = func(lit *ast.CompositeLit, litType ast.Expr) {
		var keyType, valueType ast.Expr
		switch typ := unparen(litType).(type) {
		case *ast.ArrayType:
			valueType = typ.Elt
		case *ast.MapType:
			keyType = typ.Key
			valueType = typ.Value
		default:
			return
		}
		auditChild := func(expr ast.Expr, childType ast.Expr) {
			child, ok := expr.(*ast.CompositeLit)
			if !ok || child.Type != nil {
				return
			}
			resolved := unparen(childType)
			if star, ok := resolved.(*ast.StarExpr); ok {
				if serverType(star.X) != nil {
					checkComposite(child)
					return
				}
				// An elided child of a pointer-to-collection element type is
				// the address of a composite literal of the pointed-to
				// collection type, so peel the single pointer level and keep
				// propagating. A second pointer level cannot elide: Go only
				// elides &T for an element type *T where T itself is a
				// composite-literal type.
				resolved = unparen(star.X)
			}
			auditElidedElements(child, resolved)
		}
		for _, elt := range lit.Elts {
			if kv, ok := elt.(*ast.KeyValueExpr); ok {
				if keyType != nil {
					auditChild(kv.Key, keyType)
				}
				auditChild(kv.Value, valueType)
				continue
			}
			auditChild(elt, valueType)
		}
	}

	// ast.Inspect visits parents before children, so an audited-safe parent
	// form marks its http.Server type reference allowed before the bare
	// selector case can see it. Type declarations are denied first for the
	// same reason: a package-local named type or alias over http.Server would
	// let a composite literal construct a server without naming the type at
	// the construction site, hiding it from every case below. Cross-package
	// named types over http.Server would be invisible to any syntactic
	// census and are an explicit non-goal; no dependency exports one.
	allowed := map[*ast.SelectorExpr]bool{}
	ast.Inspect(file, func(n ast.Node) bool {
		switch node := n.(type) {
		case *ast.TypeSpec:
			ast.Inspect(node.Type, func(inner ast.Node) bool {
				expr, ok := inner.(ast.Expr)
				if !ok {
					return true
				}
				if sel := serverType(expr); sel != nil && !allowed[sel] {
					allowed[sel] = true
					report(sel.Pos(), "http.Server referenced in a type declaration; a named type or alias over http.Server lets composite literals construct servers without naming the type, hiding them from this census — construct http.Server directly or consciously extend the census")
				}
				return true
			})
		case *ast.StarExpr:
			// *http.Server declares a pointer; no server value is created.
			if sel := serverType(node.X); sel != nil {
				allowed[sel] = true
			}
		case *ast.CompositeLit:
			if sel := serverType(node.Type); sel != nil {
				allowed[sel] = true
				checkComposite(node)
			} else if node.Type != nil {
				auditElidedElements(node, node.Type)
			}
		case *ast.SelectorExpr:
			if sel := serverType(node); sel != nil && !allowed[sel] {
				report(node.Pos(), "http.Server used outside an audited construction form (composite literal with explicit Handler, or *http.Server pointer type); a zero-value Server serves http.DefaultServeMux")
			}
		}
		return true
	})
	return violations
}

// TestHTTPServerHandlerCensusDetectsViolations pins the census's detection
// power with one synthetic source per violation class, per audited-safe
// form, and per deliberately undetected ceiling case, so weakening the
// checker fails here rather than silently narrowing the package invariant,
// and tightening it past the documented ceiling is a conscious edit here
// rather than an accident.
func TestHTTPServerHandlerCensusDetectsViolations(t *testing.T) {
	cases := []struct {
		name string
		src  string
		want string // substring of the single expected violation; empty means no violation
	}{
		{
			name: "explicit handler composite is allowed",
			src:  `package p; import "net/http"; var _ = &http.Server{Handler: http.NotFoundHandler()}`,
			want: "",
		},
		{
			name: "pointer declaration is allowed",
			src:  `package p; import "net/http"; var _ *http.Server`,
			want: "",
		},
		{
			name: "pointer return type is allowed",
			src:  `package p; import "net/http"; func f() *http.Server { return &http.Server{Handler: http.NotFoundHandler()} }`,
			want: "",
		},
		{
			name: "no net/http import is ignored",
			src:  `package p; type grpc struct{ Server int }; var _ = grpc{}`,
			want: "",
		},
		{
			name: "elided slice element with explicit handler is allowed",
			src:  `package p; import "net/http"; var _ = []*http.Server{{Handler: http.NotFoundHandler()}}`,
			want: "",
		},
		{
			name: "nil pointer slice element is allowed",
			src:  `package p; import "net/http"; var _ = []*http.Server{nil}`,
			want: "",
		},
		{
			name: "empty pointer slice is allowed",
			src:  `package p; import "net/http"; var _ = []*http.Server{}`,
			want: "",
		},
		{
			// The census is syntactic and does not evaluate call expressions;
			// a nil interface produced by a call expression (a conversion, or
			// a call that returns nil) is a documented non-goal (#1410). These four cases
			// pin that ceiling so a future tightening is a conscious
			// extension rather than an accident, and so the ordinary
			// wrapper form stays allowed.
			name: "conversion-wrapped nil Handler is outside the syntactic ceiling",
			src:  `package p; import "net/http"; var _ = &http.Server{Handler: http.Handler(nil)}`,
			want: "",
		},
		{
			name: "parenthesized conversion-wrapped nil Handler is outside the syntactic ceiling",
			src:  `package p; import "net/http"; var _ = &http.Server{Handler: (http.Handler(nil))}`,
			want: "",
		},
		{
			name: "elided slice element with conversion-wrapped nil Handler is outside the syntactic ceiling",
			src:  `package p; import "net/http"; var _ = []*http.Server{{Handler: http.Handler(nil)}}`,
			want: "",
		},
		{
			name: "wrapper call with nil argument is allowed",
			src:  `package p; import "net/http"; func wrapHandler(h http.Handler) http.Handler { return http.NotFoundHandler() }; var _ = &http.Server{Handler: wrapHandler(nil)}`,
			want: "",
		},
		{
			name: "missing Handler field",
			src:  `package p; import "net/http"; var _ = &http.Server{Addr: ":0"}`,
			want: "without an explicit Handler field",
		},
		{
			name: "nil literal Handler",
			src:  `package p; import "net/http"; var _ = &http.Server{Handler: nil}`,
			want: "Handler is the nil literal",
		},
		{
			name: "parenthesized nil Handler",
			src:  `package p; import "net/http"; var _ = &http.Server{Handler: (nil)}`,
			want: "Handler is the nil literal",
		},
		{
			name: "doubly parenthesized nil Handler",
			src:  `package p; import "net/http"; var _ = &http.Server{Handler: ((nil))}`,
			want: "Handler is the nil literal",
		},
		{
			name: "elided slice element without Handler",
			src:  `package p; import "net/http"; var _ = []*http.Server{{Addr: ":0"}}`,
			want: "without an explicit Handler field",
		},
		{
			name: "elided slice element with nil Handler",
			src:  `package p; import "net/http"; var _ = []*http.Server{{Handler: nil}}`,
			want: "Handler is the nil literal",
		},
		{
			name: "elided array element without Handler",
			src:  `package p; import "net/http"; var _ = [1]*http.Server{{Addr: ":0"}}`,
			want: "without an explicit Handler field",
		},
		{
			name: "elided map value without Handler",
			src:  `package p; import "net/http"; var _ = map[string]*http.Server{"a": {Addr: ":0"}}`,
			want: "without an explicit Handler field",
		},
		{
			name: "elided map key without Handler",
			src:  `package p; import "net/http"; var _ = map[*http.Server]bool{{Addr: ":0"}: true}`,
			want: "without an explicit Handler field",
		},
		{
			name: "nested elided slice element without Handler",
			src:  `package p; import "net/http"; var _ = [][]*http.Server{{{Addr: ":0"}}}`,
			want: "without an explicit Handler field",
		},
		{
			name: "elided pointer-to-slice element without Handler",
			src:  `package p; import "net/http"; var _ = []*[]*http.Server{{{Addr: ":0"}}}`,
			want: "without an explicit Handler field",
		},
		{
			name: "elided pointer-to-array element without Handler",
			src:  `package p; import "net/http"; var _ = []*[1]*http.Server{{{Addr: ":0"}}}`,
			want: "without an explicit Handler field",
		},
		{
			name: "elided pointer-to-map element without Handler",
			src:  `package p; import "net/http"; var _ = []*map[string]*http.Server{{"a": {Addr: ":0"}}}`,
			want: "without an explicit Handler field",
		},
		{
			name: "elided map-value pointer-to-slice with nil Handler",
			src:  `package p; import "net/http"; var _ = map[string]*[]*http.Server{"a": {{Handler: nil}}}`,
			want: "Handler is the nil literal",
		},
		{
			name: "elided pointer-to-slice element with explicit handler is allowed",
			src:  `package p; import "net/http"; var _ = []*[]*http.Server{{{Handler: http.NotFoundHandler()}}}`,
			want: "",
		},
		{
			name: "positional composite literal",
			src:  `package p; import "net/http"; var _ = &http.Server{":0", nil, nil, nil, 0, 0, 0, 0, 0, nil, nil, nil, nil, nil, nil, nil, nil, nil}`,
			want: "must use Handler: key-value form",
		},
		{
			name: "zero value via new",
			src:  `package p; import "net/http"; var _ = new(http.Server)`,
			want: "outside an audited construction form",
		},
		{
			name: "zero value via var declaration",
			src:  `package p; import "net/http"; var _ http.Server`,
			want: "outside an audited construction form",
		},
		{
			name: "value-typed field of an anonymous struct",
			src:  `package p; import "net/http"; var _ = struct{ srv http.Server }{}`,
			want: "outside an audited construction form",
		},
		{
			name: "aliased import without Handler",
			src:  `package p; import web "net/http"; var _ = &web.Server{}`,
			want: "without an explicit Handler field",
		},
		{
			name: "dot import",
			src:  `package p; import . "net/http"; var _ = &Server{}`,
			want: "dot import of net/http",
		},
		{
			name: "named collection type over http.Server",
			src:  `package p; import "net/http"; type servers []*http.Server`,
			want: "referenced in a type declaration",
		},
		{
			name: "pointer alias over http.Server",
			src:  `package p; import "net/http"; type srv = *http.Server`,
			want: "referenced in a type declaration",
		},
		{
			// A struct field cannot launder construction (struct literal
			// fields cannot elide their type), but the census still denies
			// every type declaration over http.Server so the safe rule stays
			// simple; extending the census is the conscious escape hatch.
			name: "struct field inside a type declaration",
			src:  `package p; import "net/http"; type deps struct{ srv *http.Server }`,
			want: "referenced in a type declaration",
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			fset := token.NewFileSet()
			file, err := parser.ParseFile(fset, "case.go", tc.src, 0)
			if err != nil {
				t.Fatalf("ParseFile: %v", err)
			}
			violations := httpServerHandlerViolations(fset, file)
			if tc.want == "" {
				if len(violations) != 0 {
					t.Fatalf("violations = %q, want none", violations)
				}
				return
			}
			if len(violations) != 1 {
				t.Fatalf("violations = %q, want exactly one containing %q", violations, tc.want)
			}
			if !strings.Contains(violations[0], tc.want) {
				t.Fatalf("violation = %q, want substring %q", violations[0], tc.want)
			}
		})
	}
}
