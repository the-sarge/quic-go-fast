package main

import (
	"bytes"
	"strings"
	"testing"

	"github.com/GridSwarm/wiremux/internal/ratelimit"
)

func TestWriteSTUNRateLimitDropReportIncludesGlobalAndSourceCounts(t *testing.T) {
	var out bytes.Buffer
	writeSTUNRateLimitDropReport(&out, ratelimit.DropSnapshot{
		Global: 2,
		Source: 3,
	})

	report := out.String()
	for _, want := range []string{
		"stun rate-limit drops",
		"global=2",
		"source=3",
		"total=5",
	} {
		if !strings.Contains(report, want) {
			t.Fatalf("report %q does not contain %q", report, want)
		}
	}
}
