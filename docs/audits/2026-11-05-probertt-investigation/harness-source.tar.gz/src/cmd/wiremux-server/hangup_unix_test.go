//go:build unix

package main

import (
	"context"
	"errors"
	"os"
	"strings"
	"sync/atomic"
	"syscall"
	"testing"
	"time"
)

func TestReloadShapingOnHangupAppliesAndReportsOutcomes(t *testing.T) {
	var calls atomic.Int32
	failNext := atomic.Bool{}
	var stderr lockedBuffer
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	stop := reloadShapingOnHangup(ctx, func() error {
		calls.Add(1)
		if failNext.Load() {
			return errors.New("relay: shaping file is invalid")
		}
		return nil
	}, &stderr)
	defer stop()

	sendHangup := func(wantCalls int32) {
		t.Helper()
		if err := syscall.Kill(os.Getpid(), syscall.SIGHUP); err != nil {
			t.Fatalf("send SIGHUP: %v", err)
		}
		deadline := time.Now().Add(5 * time.Second)
		for calls.Load() < wantCalls {
			if time.Now().After(deadline) {
				t.Fatalf("reload calls: got %d, want %d", calls.Load(), wantCalls)
			}
			time.Sleep(5 * time.Millisecond)
		}
	}

	sendHangup(1)
	failNext.Store(true)
	sendHangup(2)
	time.Sleep(20 * time.Millisecond) // let the second outcome be written
	out := stderr.String()
	if !strings.Contains(out, "relay shaping reloaded\n") {
		t.Fatalf("stderr after a successful reload: got %q, want the success line", out)
	}
	if !strings.Contains(out, "relay shaping reload failed; keeping running values: relay: shaping file is invalid") {
		t.Fatalf("stderr after a failed reload: got %q, want the failure line", out)
	}

	// stop must return promptly (the loop goroutine exits). A SIGHUP after
	// stop would take the default disposition and terminate the process, so
	// the test does not send one.
	stopped := make(chan struct{})
	go func() { stop(); close(stopped) }()
	select {
	case <-stopped:
	case <-time.After(5 * time.Second):
		t.Fatal("stop did not return")
	}
}

func TestHangupWithoutShapingFileIsANoOp(t *testing.T) {
	var stderr lockedBuffer
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	stop := reloadShapingOnHangup(ctx, nil, &stderr)
	defer stop()

	// With the handler installed, SIGHUP must neither terminate the process
	// nor log anything.
	if err := syscall.Kill(os.Getpid(), syscall.SIGHUP); err != nil {
		t.Fatalf("send SIGHUP: %v", err)
	}
	time.Sleep(50 * time.Millisecond)
	if out := stderr.String(); out != "" {
		t.Fatalf("stderr after SIGHUP without a shaping file: got %q, want empty", out)
	}
}
