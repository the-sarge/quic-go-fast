package main

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime/pprof"
	"strings"
	"testing"
	"time"
)

func TestParseServeFlagsAcceptsDebugPprofListen(t *testing.T) {
	cfg, err := parseServeFlags([]string{
		"--no-relay",
		"--debug-pprof-listen", "127.0.0.1:6060",
	})
	if err != nil {
		t.Fatalf("parseServeFlags: %v", err)
	}
	if cfg.debugPprofListen != "127.0.0.1:6060" {
		t.Fatalf("debugPprofListen = %q, want %q", cfg.debugPprofListen, "127.0.0.1:6060")
	}
}

func TestValidateServeConfigAcceptsLoopbackDebugPprofListen(t *testing.T) {
	for _, listen := range []string{
		"127.0.0.1:6060",
		"127.0.0.1:0",
		"127.5.4.3:9",
		"[::1]:6060",
	} {
		cfg, err := parseServeFlags([]string{
			"--no-relay",
			"--debug-pprof-listen", listen,
		})
		if err != nil {
			t.Fatalf("parseServeFlags(%q): %v", listen, err)
		}
		if err := validateServeConfig(cfg); err != nil {
			t.Errorf("validateServeConfig(%q): got %v, want nil", listen, err)
		}
	}
}

func TestRunServeRejectsNonLoopbackDebugPprofListen(t *testing.T) {
	const wantErr = "--debug-pprof-listen must be a loopback IP host:port"
	for _, listen := range []string{
		"6060",
		":6060",
		"127.0.0.1",
		"127.0.0.1:",
		"[::1]:",
		"0.0.0.0:6060",
		"[::]:6060",
		"192.0.2.10:6060",
		"localhost:6060",
	} {
		var stderr lockedBuffer
		code := runServe(context.Background(), []string{
			"--no-relay",
			"--stun-listen", "127.0.0.1:0",
			"--debug-pprof-listen", listen,
		}, &stderr)
		if code != 2 {
			t.Errorf("runServe(--debug-pprof-listen %q) exit code = %d, want 2", listen, code)
			continue
		}
		stderr.mu.Lock()
		message := stderr.buf.String()
		stderr.mu.Unlock()
		if !strings.Contains(message, wantErr) {
			t.Errorf("runServe(--debug-pprof-listen %q) stderr = %q, want %q", listen, message, wantErr)
		}
	}
}

func TestRunServeServesDebugPprofOnLoopback(t *testing.T) {
	stunListen := freeUDPListenAddr(t)
	debugListen := freeTCPListenAddr(t)

	var stderr lockedBuffer
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--no-relay",
			"--stun-listen", stunListen,
			"--debug-pprof-listen", debugListen,
		}, &stderr)
	}()

	waitForTCPListener(t, debugListen)

	resp, err := http.Get("http://" + debugListen + "/debug/pprof/cmdline")
	if err != nil {
		t.Fatalf("http.Get pprof cmdline: %v", err)
	}
	_, _ = io.Copy(io.Discard, resp.Body)
	_ = resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("pprof cmdline status = %d, want %d", resp.StatusCode, http.StatusOK)
	}

	// The CPU-profile endpoint streams for the caller-selected duration; a
	// completed 1-second capture proves the debug server does not impose a
	// write timeout that would truncate longer captures.
	resp, err = http.Get("http://" + debugListen + "/debug/pprof/profile?seconds=1")
	if err != nil {
		t.Fatalf("http.Get pprof profile: %v", err)
	}
	profile, err := io.ReadAll(resp.Body)
	_ = resp.Body.Close()
	if err != nil {
		t.Fatalf("read pprof profile body: %v", err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("pprof profile status = %d, want %d", resp.StatusCode, http.StatusOK)
	}
	if len(profile) == 0 {
		t.Fatal("pprof profile body is empty")
	}

	resp, err = http.Get("http://" + debugListen + "/debug/pprof/goroutineleak")
	if err != nil {
		t.Fatalf("http.Get pprof goroutineleak: %v", err)
	}
	leakProfile, err := io.ReadAll(resp.Body)
	_ = resp.Body.Close()
	if err != nil {
		t.Fatalf("read pprof goroutineleak body: %v", err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("pprof goroutineleak status = %d, want %d", resp.StatusCode, http.StatusOK)
	}
	if len(leakProfile) == 0 {
		t.Fatal("pprof goroutineleak body is empty")
	}
	requirePprofProfileParseable(t, leakProfile)

	stderr.mu.Lock()
	message := stderr.buf.String()
	stderr.mu.Unlock()
	want := "debug pprof on http://" + debugListen + "/debug/pprof/"
	if !strings.Contains(message, want) {
		t.Fatalf("stderr = %q, want %q", message, want)
	}

	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0", code)
	}
	assertTCPDialFails(t, debugListen)
}

func requirePprofProfileParseable(t *testing.T, data []byte) {
	t.Helper()
	// Go may compile pprof on demand. Keep that build outside the profile
	// parsing deadline so a cold tool cache does not look like a parser hang.
	buildCtx, buildCancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer buildCancel()
	prepare := exec.CommandContext(buildCtx, "go", "tool", "-n", "pprof")
	prepare.Env = append(os.Environ(), "GOTOOLCHAIN=local")
	var buildStderr bytes.Buffer
	prepare.Stderr = &buildStderr
	toolPath, err := prepare.Output()
	if err != nil {
		t.Fatalf("prepare pprof tool: %v (context: %v)\n%s", err, buildCtx.Err(), &buildStderr)
	}
	profilePath := filepath.Join(t.TempDir(), "goroutineleak.prof")
	if err := os.WriteFile(profilePath, data, 0o600); err != nil {
		t.Fatalf("write pprof profile: %v", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, strings.TrimSpace(string(toolPath)), "-raw", profilePath) //nolint:gosec // The trusted local Go toolchain resolves its own pprof executable.
	cmd.Env = append(os.Environ(), "GOTOOLCHAIN=local")
	if output, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("parse pprof profile: %v (context: %v)\n%s", err, ctx.Err(), output)
	}
}

func TestRunServeShutdownForceClosesInFlightPprofCapture(t *testing.T) {
	stunListen := freeUDPListenAddr(t)
	debugListen := freeTCPListenAddr(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--no-relay",
			"--stun-listen", stunListen,
			"--debug-pprof-listen", debugListen,
			"--shutdown-timeout", "1s",
		}, io.Discard)
	}()

	waitForTCPListener(t, debugListen)

	// A CPU-profile capture far longer than the shutdown timeout; the Get
	// blocks until the capture ends or the connection is closed. A nil
	// result means the capture completed cleanly with status 200.
	captureResult := make(chan error, 4)
	startCapture := func() {
		go func() {
			resp, err := http.Get("http://" + debugListen + "/debug/pprof/profile?seconds=60")
			if err != nil {
				captureResult <- err
				return
			}
			_, copyErr := io.Copy(io.Discard, resp.Body)
			_ = resp.Body.Close()
			if resp.StatusCode != http.StatusOK {
				captureResult <- fmt.Errorf("capture status %d", resp.StatusCode)
				return
			}
			captureResult <- copyErr
		}()
	}
	startCapture()

	// The CPU profiler is process-global, so a local StartCPUProfile failing
	// is the signal that the handler's capture is in flight. The probe can
	// win the narrow race against the handler's own StartCPUProfile and 500
	// the capture, so a capture that ends during this loop is restarted and
	// ownership is only confirmed while no capture result is pending.
	deadline := time.Now().Add(10 * time.Second)
	for {
		if time.Now().After(deadline) {
			t.Fatal("no pprof capture took ownership of the CPU profiler")
		}
		select {
		case <-captureResult:
			startCapture()
			time.Sleep(10 * time.Millisecond)
			continue
		default:
		}
		if err := pprof.StartCPUProfile(io.Discard); err != nil {
			break
		}
		pprof.StopCPUProfile()
		time.Sleep(10 * time.Millisecond)
	}

	cancel()
	select {
	case code := <-errCh:
		if code != 0 {
			t.Fatalf("runServe exit code = %d, want 0", code)
		}
	case <-time.After(10 * time.Second):
		t.Fatal("runServe did not exit after cancellation during an in-flight capture")
	}
	select {
	case err := <-captureResult:
		if err == nil {
			t.Fatal("in-flight capture completed cleanly; want truncation by the forced close")
		}
	case <-time.After(10 * time.Second):
		t.Fatal("in-flight capture did not end after shutdown")
	}
	assertTCPDialFails(t, debugListen)
}
