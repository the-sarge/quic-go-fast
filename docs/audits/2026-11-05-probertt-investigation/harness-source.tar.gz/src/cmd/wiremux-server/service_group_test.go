package main

import (
	"context"
	"errors"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/relay"
)

func TestServiceGroupTreatsClosedServiceAsCleanAfterShutdown(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	var group serviceGroup
	group.add("stun", func() error {
		return net.ErrClosed
	}, func(context.Context) {})

	if err := group.wait(ctx, time.Second); err != nil {
		t.Fatalf("serviceGroup wait error = %v, want nil", err)
	}
}

func TestServiceGroupAddPanicsForNilCallbacks(t *testing.T) {
	tests := []struct {
		name     string
		run      func() error
		shutdown func(context.Context)
		want     string
	}{
		{
			name:     "nil run",
			shutdown: func(context.Context) {},
			want:     `serviceGroup.add("nil run"): run must be non-nil`,
		},
		{
			name: "nil shutdown",
			run: func() error {
				return nil
			},
			want: `serviceGroup.add("nil shutdown"): shutdown must be non-nil`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var group serviceGroup
			defer func() {
				got := recover()
				if got == nil {
					t.Fatal("serviceGroup.add did not panic")
				}
				if got != tt.want {
					t.Fatalf("panic = %v, want %q", got, tt.want)
				}
			}()

			group.add(tt.name, tt.run, tt.shutdown)
		})
	}
}

func TestServiceGroupWaitsForShutdownFunc(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	shutdownStarted := make(chan struct{})
	shutdownFinished := make(chan struct{})
	releaseShutdown := make(chan struct{})
	releaseRun := make(chan struct{})
	var group serviceGroup
	group.add("stun", func() error {
		<-releaseRun
		return net.ErrClosed
	}, func(context.Context) {
		close(shutdownStarted)
		<-releaseShutdown
		close(releaseRun)
		close(shutdownFinished)
	})
	group.testBeforeReturn = func() {
		select {
		case <-shutdownFinished:
		default:
			t.Error("serviceGroup returned before shutdown function completed")
		}
	}

	done := make(chan error, 1)
	go func() {
		done <- group.wait(ctx, time.Second)
	}()

	select {
	case <-shutdownStarted:
	case <-time.After(time.Second):
		t.Fatal("shutdown function was not called")
	}

	close(releaseShutdown)
	if err := <-done; err != nil {
		t.Fatalf("serviceGroup wait error = %v, want nil", err)
	}
}

func TestServiceGroupWaitsForACMEHTTPGracefulShutdown(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("Listen tcp: %v", err)
	}
	defer listener.Close()

	handlerStarted := make(chan struct{})
	handlerFinished := make(chan struct{})
	releaseHandler := make(chan struct{})
	var releaseOnce sync.Once
	defer releaseOnce.Do(func() { close(releaseHandler) })

	httpServer := newACMEServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer close(handlerFinished)
		close(handlerStarted)
		<-releaseHandler
		_, _ = w.Write([]byte("ok"))
	}))
	shutdownStarted := make(chan struct{})
	var group serviceGroup
	group.testBeforeReturn = func() {
		select {
		case <-handlerFinished:
		default:
			t.Error("serviceGroup returned before ACME HTTP handler drained")
		}
	}
	group.add("acme http", func() error {
		err := httpServer.Serve(listener)
		if errors.Is(err, http.ErrServerClosed) {
			return nil
		}
		return err
	}, func(ctx context.Context) {
		close(shutdownStarted)
		if err := httpServer.Shutdown(ctx); err != nil {
			_ = httpServer.Close()
		}
	})

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() {
		done <- group.wait(ctx, time.Second)
	}()

	clientDone := make(chan error, 1)
	go func() {
		resp, err := http.Get("http://" + listener.Addr().String()) // #nosec G107 -- in-process test server on loopback.
		if err == nil {
			_, _ = io.Copy(io.Discard, resp.Body)
			err = resp.Body.Close()
		}
		clientDone <- err
	}()

	select {
	case <-handlerStarted:
	case <-time.After(time.Second):
		t.Fatal("ACME HTTP test handler was not reached")
	}

	cancel()
	select {
	case <-shutdownStarted:
	case <-time.After(time.Second):
		t.Fatal("ACME HTTP shutdown did not start")
	}

	releaseOnce.Do(func() { close(releaseHandler) })
	if err := <-done; err != nil {
		t.Fatalf("serviceGroup wait error = %v, want nil", err)
	}
	if err := <-clientDone; err != nil {
		t.Fatalf("ACME HTTP client error: %v", err)
	}
}

func TestServiceGroupReportsACMEHTTPShutdownDeadline(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("Listen tcp: %v", err)
	}
	defer listener.Close()

	handlerStarted := make(chan struct{})
	httpServer := newACMEServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		close(handlerStarted)
		<-r.Context().Done()
	}))
	var group serviceGroup
	group.add("acme http", func() error {
		err := httpServer.Serve(listener)
		if errors.Is(err, http.ErrServerClosed) {
			return nil
		}
		return err
	}, func(ctx context.Context) {
		if err := httpServer.Shutdown(ctx); err != nil {
			_ = httpServer.Close()
		}
	})

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() {
		done <- group.wait(ctx, 10*time.Millisecond)
	}()

	clientDone := make(chan struct{})
	go func() {
		defer close(clientDone)
		resp, err := http.Get("http://" + listener.Addr().String()) // #nosec G107 -- in-process test server on loopback.
		if err == nil {
			_, _ = io.Copy(io.Discard, resp.Body)
			_ = resp.Body.Close()
		}
	}()

	select {
	case <-handlerStarted:
	case <-time.After(time.Second):
		t.Fatal("ACME HTTP test handler was not reached")
	}

	cancel()
	err = <-done
	if err == nil {
		t.Fatal("serviceGroup wait error = nil, want shutdown timeout")
	}
	if !strings.Contains(err.Error(), "shutdown timed out") {
		t.Fatalf("serviceGroup wait error = %v, want shutdown timeout", err)
	}

	select {
	case <-clientDone:
	case <-time.After(time.Second):
		t.Fatal("ACME HTTP client did not finish after forced close")
	}
}

func TestServiceGroupReportsShutdownTimeout(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	releaseRun := make(chan struct{})
	defer close(releaseRun)
	var group serviceGroup
	group.add("stun", func() error {
		<-releaseRun
		return nil
	}, func(context.Context) {})

	err := group.wait(ctx, 10*time.Millisecond)
	if err == nil {
		t.Fatal("serviceGroup wait error = nil, want shutdown timeout")
	}
	if !strings.Contains(err.Error(), "shutdown timed out") {
		t.Fatalf("serviceGroup wait error = %v, want shutdown timeout", err)
	}
}

func TestServiceGroupReportsTimeoutAfterServiceError(t *testing.T) {
	releaseRun := make(chan struct{})
	defer close(releaseRun)
	var group serviceGroup
	group.add("relay", func() error {
		return errors.New("relay failed")
	}, func(context.Context) {})
	group.add("stun", func() error {
		<-releaseRun
		return nil
	}, func(context.Context) {})

	err := group.wait(context.Background(), 10*time.Millisecond)
	if err == nil {
		t.Fatal("serviceGroup wait error = nil, want relay failure and shutdown timeout")
	}
	message := err.Error()
	for _, want := range []string{"relay: relay failed", "shutdown timed out"} {
		if !strings.Contains(message, want) {
			t.Fatalf("serviceGroup wait error = %v, want %q", err, want)
		}
	}
}

func TestServiceGroupPreservesRelayShutdownErrorJoinedWithClose(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	releaseRun := make(chan struct{})
	var group serviceGroup
	group.add("relay", func() error {
		<-releaseRun
		return errors.Join(net.ErrClosed, relay.ErrShutdownTimeout)
	}, func(context.Context) {
		close(releaseRun)
	})

	err := group.wait(ctx, time.Second)
	if err == nil {
		t.Fatal("serviceGroup wait error = nil, want relay shutdown timeout")
	}
	if !strings.Contains(err.Error(), relay.ErrShutdownTimeout.Error()) {
		t.Fatalf("serviceGroup wait error = %v, want relay shutdown timeout", err)
	}
}

func TestServiceGroupReportsReadyRelayErrorAtSupervisorTimeout(t *testing.T) {
	releaseRelay := make(chan struct{})
	relayResultReady := make(chan struct{})
	var group serviceGroup
	group.add("stun", func() error {
		return errors.New("stun failed")
	}, func(context.Context) {})
	group.add("relay", func() error {
		<-releaseRelay
		close(relayResultReady)
		return errors.Join(net.ErrClosed, relay.ErrShutdownAccounting)
	}, func(ctx context.Context) {
		close(releaseRelay)
		<-relayResultReady
		<-ctx.Done()
	})

	err := group.wait(context.Background(), 10*time.Millisecond)
	if err == nil {
		t.Fatal("serviceGroup wait error = nil, want service and shutdown errors")
	}
	message := err.Error()
	for _, want := range []string{"stun: stun failed", relay.ErrShutdownAccounting.Error(), "shutdown timed out"} {
		if !strings.Contains(message, want) {
			t.Fatalf("serviceGroup wait error = %v, want %q", err, want)
		}
	}
}

func TestServiceGroupShutsDownPeerAfterServiceError(t *testing.T) {
	releasePeer := make(chan struct{})
	shutdownCalled := make(chan struct{}, 1)
	var group serviceGroup
	group.add("relay", func() error {
		return errors.New("relay failed")
	}, func(context.Context) {})
	group.add("stun", func() error {
		<-releasePeer
		return net.ErrClosed
	}, func(context.Context) {
		shutdownCalled <- struct{}{}
		close(releasePeer)
	})

	err := group.wait(context.Background(), time.Second)
	if err == nil {
		t.Fatal("serviceGroup wait error = nil, want relay failure")
	}
	if !strings.Contains(err.Error(), "relay: relay failed") {
		t.Fatalf("serviceGroup wait error = %v, want relay failure", err)
	}
	select {
	case <-shutdownCalled:
	default:
		t.Fatal("shutdown function was not called")
	}
	select {
	case <-shutdownCalled:
		t.Fatal("shutdown function was called more than once")
	default:
	}
}
