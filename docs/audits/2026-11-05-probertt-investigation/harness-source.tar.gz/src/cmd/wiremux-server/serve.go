package main

import (
	"context"
	"crypto/tls"
	"encoding/base64"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"github.com/GridSwarm/wiremux/internal/ratelimit"
	"github.com/GridSwarm/wiremux/relay"
	"github.com/GridSwarm/wiremux/stun"
)

var errHelpRequested = errors.New("help requested")

// relayTLSFingerprintOutputFormat is the machine-relevant explicit-certificate
// startup line; its argument is a canonical sha256:<64 hex> pin. The release
// CLI manifest freezes it for v0.1.x.
const relayTLSFingerprintOutputFormat = "relay TLS fingerprint: %s\n"

const (
	defaultSTUNRateLimitWindow         = time.Second
	defaultSTUNMaxGlobalPerWindow      = 4096
	defaultSTUNMaxSourcePerWindow      = 128
	defaultSTUNRateLimitIPv6PrefixBits = 64
	maxRelayShutdownSupervisorHeadroom = 100 * time.Millisecond
)

var serveUsageText = "usage: wiremux-server serve [flags]\n\n" + serveFlagsUsage

type serveConfig struct {
	relayListen                string
	stunListen                 string
	stunRateWindow             time.Duration
	stunMaxGlobalPerWindow     int
	stunMaxSourcePerWindow     int
	stunRateIPv6PrefixBits     int
	stunRateDropReportInterval time.Duration
	tlsCert                    string
	tlsKey                     string
	acme                       bool
	acmeDomains                []string
	acmeCacheDir               string
	acmeHTTPListen             string
	acmeDirectoryURL           string
	acmeEABKID                 string
	acmeEABHMACKeyFile         string
	shutdownTimeout            time.Duration
	relayEphemeralAbuseBackoff bool
	relayEphemeralAbuseConfig  relay.EphemeralAbuseBackoffConfig
	relayAssistStreamRate      int64
	relayAssistGlobalRate      int64
	relayAssistEgressBudget    int64
	relayAssistEgressState     string
	relayShapingFile           string
	debugPprofListen           string
	noSTUN                     bool
	noRelay                    bool
	ephemeralOnly              bool
	longLivedOnly              bool
	longLivedProof             string
	// flagGroups is the set of flag groups the invocation touched, derived
	// by serveFlagGroups from the visited flags and the serveFlagSpecs row
	// declarations; validateServeConfig reads it for the group-based rules.
	flagGroups map[serveFlagGroup]bool
}

// newServeFlagSet registers every serve flag against a fresh serveConfig.
// The compatibility-manifest cross-check test enumerates this flag set, so
// flag registrations stay in one place.
func newServeFlagSet() (*flag.FlagSet, *serveConfig, *stringListFlag) {
	fs := flag.NewFlagSet("serve", flag.ContinueOnError)
	fs.SetOutput(io.Discard)

	cfg := &serveConfig{}
	cfg.relayEphemeralAbuseConfig = relay.DefaultEphemeralAbuseBackoffConfig()
	acmeDomains := &stringListFlag{}
	for _, spec := range serveFlagSpecs {
		spec.add(fs, cfg, acmeDomains, spec.name, spec.usage)
	}
	return fs, cfg, acmeDomains
}

func parseServeFlags(args []string) (serveConfig, error) {
	fs, cfg, acmeDomains := newServeFlagSet()

	if err := fs.Parse(args); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return serveConfig{}, errHelpRequested
		}
		return serveConfig{}, err
	}
	if fs.NArg() != 0 {
		return serveConfig{}, fmt.Errorf("unexpected arguments: %s", strings.Join(fs.Args(), " "))
	}
	cfg.flagGroups = serveFlagGroups(fs)
	cfg.acmeDomains = []string(*acmeDomains)
	return *cfg, nil
}

// serveFlagGroups reports which flag groups an invocation touched. It is the
// only derivation of group membership: each visited flag contributes the
// group its serveFlagSpecs row declares, so validation never infers
// membership from how a flag name is spelled.
func serveFlagGroups(fs *flag.FlagSet) map[serveFlagGroup]bool {
	groups := make(map[serveFlagGroup]bool)
	fs.Visit(func(f *flag.Flag) {
		if group := serveFlagGroupOf(f.Name); group != groupNone {
			groups[group] = true
		}
	})
	return groups
}

// serveFlagGroupOf returns the group the named flag's serveFlagSpecs row
// declares. Every registered flag is registered from those rows, so a visited
// flag always has one; an unknown name is groupNone rather than a guess.
func serveFlagGroupOf(name string) serveFlagGroup {
	for _, spec := range serveFlagSpecs {
		if spec.name == name {
			return spec.group
		}
	}
	return groupNone
}

func validateServeConfig(cfg serveConfig) error {
	switch {
	case cfg.noRelay && cfg.noSTUN:
		return errors.New("at least one of relay or STUN must be enabled")
	case cfg.noRelay && (cfg.ephemeralOnly || cfg.longLivedOnly):
		return errors.New("relay mode flags cannot be used with --no-relay")
	case cfg.noRelay && (cfg.relayEphemeralAbuseBackoff || cfg.flagGroups[groupRelayAbuseTuning]):
		return errors.New("relay ephemeral abuse flags cannot be used with --no-relay")
	case cfg.noRelay && cfg.flagGroups[groupRelayAssistShaping]:
		return errors.New("relay-assist shaping flags cannot be used with --no-relay")
	case cfg.ephemeralOnly && cfg.longLivedOnly:
		return errors.New("--ephemeral-only and --longlived-only are mutually exclusive")
	case cfg.longLivedOnly && (cfg.relayEphemeralAbuseBackoff || cfg.flagGroups[groupRelayAbuseTuning]):
		return errors.New("relay ephemeral abuse flags cannot be used with --longlived-only")
	case cfg.acme && cfg.noRelay:
		return errors.New("--acme requires the relay")
	case cfg.acme && (cfg.tlsCert != "" || cfg.tlsKey != ""):
		return errors.New("--acme cannot be combined with --tls-cert or --tls-key")
	case cfg.acme && len(cfg.acmeDomains) == 0:
		return errors.New("--acme requires at least one --acme-domain")
	case cfg.acme && cfg.acmeCacheDir == "":
		return errors.New("--acme requires --acme-cache-dir")
	case cfg.acme && !filepath.IsAbs(cfg.acmeCacheDir):
		return errors.New("--acme-cache-dir must be an absolute path")
	case !cfg.acme && cfg.acmeDirectoryURL != "":
		return errors.New("--acme-directory-url requires --acme")
	case !cfg.acme && cfg.acmeEABKID != "":
		return errors.New("--acme-eab-kid requires --acme")
	case !cfg.acme && cfg.acmeEABHMACKeyFile != "":
		return errors.New("--acme-eab-hmac-key-file requires --acme")
	case cfg.acmeDirectoryURL != "" && !isAbsoluteHTTPSURL(cfg.acmeDirectoryURL):
		return errors.New("--acme-directory-url must be an absolute https:// URL")
	case (cfg.acmeEABKID == "") != (cfg.acmeEABHMACKeyFile == ""):
		return errors.New("--acme-eab-kid and --acme-eab-hmac-key-file must be set together")
	case cfg.acmeEABHMACKeyFile != "" && !filepath.IsAbs(cfg.acmeEABHMACKeyFile):
		return errors.New("--acme-eab-hmac-key-file must be an absolute path")
	case !cfg.noRelay && !cfg.acme && cfg.tlsCert == "" && cfg.tlsKey == "":
		return errors.New("TLS is required: set --tls-cert and --tls-key or enable --acme")
	case !cfg.noRelay && !cfg.acme && (cfg.tlsCert == "" || cfg.tlsKey == ""):
		return errors.New("both --tls-cert and --tls-key are required")
	}

	switch cfg.longLivedProof {
	case "ed25519-keyhash", "none":
	default:
		return fmt.Errorf("unsupported --longlived-proof value %q", cfg.longLivedProof)
	}
	switch {
	case cfg.stunRateWindow <= 0:
		return errors.New("--stun-rate-window must be positive")
	case cfg.stunMaxGlobalPerWindow <= 0:
		return errors.New("--stun-max-global-per-window must be positive")
	case cfg.stunMaxSourcePerWindow <= 0:
		return errors.New("--stun-max-source-per-window must be positive")
	case cfg.stunRateIPv6PrefixBits <= 0 || cfg.stunRateIPv6PrefixBits > 128:
		return errors.New("--stun-rate-ipv6-prefix-bits must be between 1 and 128")
	case cfg.stunRateDropReportInterval < 0:
		return errors.New("--stun-rate-drop-report-interval must be non-negative")
	case cfg.shutdownTimeout <= 0:
		return errors.New("--shutdown-timeout must be positive")
	case cfg.relayAssistStreamRate < 0:
		return errors.New("--relay-assist-stream-rate must be non-negative")
	case cfg.relayAssistGlobalRate < 0:
		return errors.New("--relay-assist-global-rate must be non-negative")
	case cfg.relayAssistEgressBudget < 0:
		return errors.New("--relay-assist-egress-budget must be non-negative")
	case cfg.relayAssistEgressBudget > 0 && cfg.relayAssistEgressState == "":
		return errors.New("--relay-assist-egress-budget requires --relay-assist-egress-state")
	case cfg.relayAssistEgressState != "" && !filepath.IsAbs(cfg.relayAssistEgressState):
		return errors.New("--relay-assist-egress-state must be an absolute path")
	case cfg.relayShapingFile != "" && !filepath.IsAbs(cfg.relayShapingFile):
		return errors.New("--relay-shaping-file must be an absolute path")
	case cfg.debugPprofListen != "" && !isLoopbackHostPort(cfg.debugPprofListen):
		return errors.New("--debug-pprof-listen must be a loopback IP host:port")
	}
	if cfg.relayEphemeralAbuseBackoff {
		if err := validateServeEphemeralAbuseBackoffConfig(cfg.relayEphemeralAbuseConfig); err != nil {
			return err
		}
	}
	if cfg.flagGroups[groupRelayAbuseTuning] && !cfg.relayEphemeralAbuseBackoff {
		return errors.New("--relay-ephemeral-abuse-* tuning flags require --relay-ephemeral-abuse-backoff")
	}
	return nil
}

// shapingReloadForServe selects what SIGHUP does: reload the relay's shaping
// file when one is configured, otherwise nothing (the handler still swallows
// the signal).
func shapingReloadForServe(cfg serveConfig, relayServer *relay.Relay) func() error {
	if relayServer == nil || cfg.relayShapingFile == "" {
		return nil
	}
	return relayServer.ReloadShaping
}

func relayOptionsForServe(cfg serveConfig, tlsConfig *tls.Config) []relay.Option {
	opts := []relay.Option{
		relay.WithTLSConfig(tlsConfig),
		relay.WithShutdownTimeout(relayShutdownTimeoutForServe(cfg.shutdownTimeout)),
	}
	if cfg.ephemeralOnly {
		opts = append(opts, relay.WithLongLivedDisabled())
	}
	if cfg.longLivedOnly {
		opts = append(opts, relay.WithEphemeralDisabled())
	}
	if cfg.longLivedProof == "none" {
		opts = append(opts, relay.WithLongLivedProofNone())
	}
	if cfg.acme {
		opts = append(opts, relay.WithTLSHandshakeTimeout(90*time.Second))
	}
	if cfg.relayEphemeralAbuseBackoff {
		opts = append(opts, relay.WithEphemeralAbuseBackoff(cfg.relayEphemeralAbuseConfig))
	}
	if cfg.relayAssistStreamRate > 0 {
		opts = append(opts, relay.WithRelayAssistStreamRateLimit(cfg.relayAssistStreamRate))
	}
	if cfg.relayAssistGlobalRate > 0 {
		opts = append(opts, relay.WithRelayAssistGlobalRateLimit(cfg.relayAssistGlobalRate))
	}
	if cfg.relayAssistEgressState != "" {
		opts = append(opts, relay.WithRelayAssistEgressStatePath(cfg.relayAssistEgressState))
	}
	if cfg.relayAssistEgressBudget > 0 {
		opts = append(opts, relay.WithRelayAssistEgressBudget(cfg.relayAssistEgressBudget))
	}
	if cfg.relayShapingFile != "" {
		opts = append(opts, relay.WithShapingFile(cfg.relayShapingFile))
	}
	return opts
}

func relayShutdownTimeoutForServe(shutdownTimeout time.Duration) time.Duration {
	headroom := shutdownTimeout / 10
	if headroom <= 0 {
		return shutdownTimeout
	}
	if headroom > maxRelayShutdownSupervisorHeadroom {
		headroom = maxRelayShutdownSupervisorHeadroom
	}
	relayTimeout := shutdownTimeout - headroom
	if relayTimeout <= 0 {
		return shutdownTimeout
	}
	return relayTimeout
}

func runServe(ctx context.Context, args []string, stderr io.Writer) int {
	cfg, err := parseServeFlags(args)
	if err != nil {
		if errors.Is(err, errHelpRequested) {
			if stderr != nil {
				fmt.Fprint(stderr, serveUsageText)
			}
			return 0
		}
		writeServeError(stderr, err)
		return 2
	}
	if err := validateServeConfig(cfg); err != nil {
		writeServeError(stderr, err)
		return 2
	}

	ctx, stop := signal.NotifyContext(ctx, os.Interrupt, syscall.SIGTERM)
	defer stop()

	return serve(ctx, cfg, stderr)
}

func serve(ctx context.Context, cfg serveConfig, stderr io.Writer) int {
	var group serviceGroup
	var acmeHTTPListener net.Listener
	var acmeHTTPServer *http.Server
	var debugPprofListener net.Listener
	var debugPprofServer *http.Server
	var relayListener net.Listener
	var relayServer *relay.Relay
	var packetConn net.PacketConn
	var stunServer *stun.Server
	var stunDrops *ratelimit.DropCounter
	var listenConfig net.ListenConfig

	if !cfg.noRelay {
		var tlsConfig *tls.Config
		if cfg.acme {
			acmeOpts, err := acmeOptionsForServe(cfg)
			if err != nil {
				writeServeError(stderr, err)
				return 1
			}
			acmeTLS, err := relay.ACMEServerTLSConfig(cfg.acmeDomains, cfg.acmeCacheDir, acmeOpts...)
			if err != nil {
				writeServeError(stderr, err)
				return 1
			}
			tlsConfig = acmeTLS.TLSConfig
			if acmeHTTP01Enabled(cfg) {
				fmt.Fprintf(stderr, "relay TLS: ACME for domains %s%s (HTTP-01 on %s; TLS-ALPN-01 may also be attempted on %s)\n",
					strings.Join(cfg.acmeDomains, ", "), acmeDirectorySuffix(cfg), cfg.acmeHTTPListen, cfg.relayListen)

				httpListener, err := listenConfig.Listen(ctx, "tcp", cfg.acmeHTTPListen)
				if err != nil {
					writeServeError(stderr, fmt.Errorf("listen acme http %s: %w", cfg.acmeHTTPListen, err))
					return 1
				}
				defer httpListener.Close()
				acmeHTTPListener = httpListener
				acmeHTTPServer = newACMEServer(acmeTLS.HTTPHandler)
			} else {
				fmt.Fprintf(stderr, "relay TLS: ACME for domains %s%s (HTTP-01 disabled; TLS-ALPN-01 only on %s)\n",
					strings.Join(cfg.acmeDomains, ", "), acmeDirectorySuffix(cfg), cfg.relayListen)
			}
		} else {
			loaded, err := relay.LoadServerTLSConfig(cfg.tlsCert, cfg.tlsKey)
			if err != nil {
				writeServeError(stderr, err)
				return 1
			}
			tlsConfig = loaded
			fingerprint, err := relay.ServerTLSFingerprint(tlsConfig)
			if err != nil {
				writeServeError(stderr, err)
				return 1
			}
			fmt.Fprintf(stderr, relayTLSFingerprintOutputFormat, fingerprint.String())
		}

		listener, err := listenConfig.Listen(ctx, "tcp", cfg.relayListen)
		if err != nil {
			writeServeError(stderr, fmt.Errorf("listen relay %s: %w", cfg.relayListen, err))
			return 1
		}
		defer listener.Close()

		relayListener = listener
		relayServer = relay.New(relayOptionsForServe(cfg, tlsConfig)...)
	}

	if !cfg.noSTUN {
		conn, err := listenConfig.ListenPacket(ctx, "udp", cfg.stunListen)
		if err != nil {
			writeServeError(stderr, fmt.Errorf("listen stun %s: %w", cfg.stunListen, err))
			return 1
		}
		defer conn.Close()

		if cfg.stunRateDropReportInterval > 0 {
			stunDrops = ratelimit.NewDropCounter()
		}

		packetConn = ratelimit.NewPacketConn(conn, ratelimit.PacketConfig{
			Window:         cfg.stunRateWindow,
			MaxGlobal:      cfg.stunMaxGlobalPerWindow,
			MaxSource:      cfg.stunMaxSourcePerWindow,
			IPv6PrefixBits: cfg.stunRateIPv6PrefixBits,
			Drops:          stunDrops,
		})
		stunServer = stun.NewServer()
	}

	if cfg.debugPprofListen != "" {
		listener, err := listenConfig.Listen(ctx, "tcp", cfg.debugPprofListen)
		if err != nil {
			writeServeError(stderr, fmt.Errorf("listen debug pprof %s: %w", cfg.debugPprofListen, err))
			return 1
		}
		defer listener.Close()
		debugPprofListener = listener
		debugPprofServer = newDebugPprofServer()
		fmt.Fprintf(stderr, "debug pprof on http://%s/debug/pprof/\n", listener.Addr())
	}

	if stunDrops != nil {
		reportCtx, stopReports := context.WithCancel(ctx)
		reportDone := make(chan struct{})
		go func() {
			defer close(reportDone)
			reportSTUNRateLimitDrops(reportCtx, stunDrops, cfg.stunRateDropReportInterval, stderr)
		}()
		defer func() {
			stopReports()
			<-reportDone
		}()
	}

	if acmeHTTPServer != nil {
		group.add("acme http", func() error {
			err := acmeHTTPServer.Serve(acmeHTTPListener)
			if errors.Is(err, http.ErrServerClosed) {
				return nil
			}
			return err
		}, func(ctx context.Context) {
			if err := acmeHTTPServer.Shutdown(ctx); err != nil {
				_ = acmeHTTPServer.Close()
			}
		})
	}

	if debugPprofServer != nil {
		group.add("debug pprof", func() error {
			err := debugPprofServer.Serve(debugPprofListener)
			if errors.Is(err, http.ErrServerClosed) {
				return nil
			}
			return err
		}, func(context.Context) {
			// Close, not Shutdown: profile and trace captures hold their
			// request for the caller-selected duration, so a graceful drain
			// would exhaust the shutdown budget and turn a clean signal
			// shutdown into exit 1. Truncating an in-flight capture is the
			// documented shutdown behavior for this diagnostic surface.
			_ = debugPprofServer.Close()
		})
	}

	// SIGHUP is owned for the whole serve lifetime: a reload when a shaping
	// file is configured, otherwise a no-op rather than the terminating
	// default disposition.
	stopHangup := reloadShapingOnHangup(ctx, shapingReloadForServe(cfg, relayServer), stderr)
	defer stopHangup()
	if relayServer != nil {
		group.add("relay", func() error {
			return relayServer.ServeContext(ctx, relayListener)
		}, func(context.Context) {
			_ = relayListener.Close()
		})
	}

	if stunServer != nil {
		group.add("stun", func() error {
			return stunServer.Serve(packetConn)
		}, func(context.Context) {
			_ = packetConn.Close()
		})
	}

	if err := waitForServeServices(&group, ctx, cfg.shutdownTimeout); err != nil {
		writeServeError(stderr, err)
		return 1
	}
	return 0
}

// waitForServeServices is a test seam for serve's private serviceGroup wait
// reached through runServe. Do not mutate it outside tests; tests that replace
// it must run sequentially and restore the original value.
var waitForServeServices = (*serviceGroup).wait

func writeServeError(stderr io.Writer, err error) {
	if stderr != nil && err != nil {
		fmt.Fprintln(stderr, "wiremux-server:", err)
	}
}

// isAbsoluteHTTPSURL reports whether raw parses (per net/url) as an absolute
// URL with the https scheme and a non-empty host.
func isAbsoluteHTTPSURL(raw string) bool {
	parsed, err := url.Parse(raw)
	if err != nil {
		return false
	}
	return parsed.Scheme == "https" && parsed.Host != ""
}

// acmeOptionsForServe translates the ACME extension flags into relay options.
// It reads the EAB key file at startup; the returned error names the path and
// the failure class but never the file content.
func acmeOptionsForServe(cfg serveConfig) ([]relay.ACMEOption, error) {
	var opts []relay.ACMEOption
	if !acmeHTTP01Enabled(cfg) {
		opts = append(opts, relay.WithACMEHTTP01Disabled())
	}
	if cfg.acmeDirectoryURL != "" {
		opts = append(opts, relay.WithACMEDirectoryURL(cfg.acmeDirectoryURL))
	}
	if cfg.acmeEABKID != "" {
		key, err := loadACMEEABKey(cfg.acmeEABHMACKeyFile)
		if err != nil {
			return nil, err
		}
		opts = append(opts, relay.WithACMEExternalAccountBinding(cfg.acmeEABKID, key))
	}
	return opts, nil
}

// loadACMEEABKey reads a base64url-encoded (padded or unpadded,
// whitespace-trimmed) HMAC key from path and returns the decoded bytes.
func loadACMEEABKey(path string) ([]byte, error) {
	content, err := os.ReadFile(path) // #nosec G304 -- operator-supplied absolute credential path validated by validateServeConfig.
	if err != nil {
		return nil, fmt.Errorf("read --acme-eab-hmac-key-file: %w", err)
	}
	encoded := strings.TrimRight(strings.TrimSpace(string(content)), "=")
	key, err := base64.RawURLEncoding.DecodeString(encoded)
	if err != nil {
		return nil, fmt.Errorf("decode --acme-eab-hmac-key-file %s as base64url: %w", path, err)
	}
	if len(key) == 0 {
		return nil, fmt.Errorf("decode --acme-eab-hmac-key-file %s: empty key", path)
	}
	return key, nil
}

// acmeHTTP01Enabled reports whether serve binds the HTTP-01 challenge
// listener. An empty --acme-http-listen disables it, leaving TLS-ALPN-01 on
// the relay listener as the only challenge path.
func acmeHTTP01Enabled(cfg serveConfig) bool {
	return cfg.acmeHTTPListen != ""
}

// acmeDirectorySuffix names an explicitly configured ACME directory in the
// startup line; the default directory keeps the frozen default line.
func acmeDirectorySuffix(cfg serveConfig) string {
	if cfg.acmeDirectoryURL == "" {
		return ""
	}
	return " via " + cfg.acmeDirectoryURL
}

func newACMEServer(handler http.Handler) *http.Server {
	return &http.Server{
		Handler:           handler,
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      10 * time.Second,
		IdleTimeout:       30 * time.Second,
		MaxHeaderBytes:    1 << 20,
	}
}
