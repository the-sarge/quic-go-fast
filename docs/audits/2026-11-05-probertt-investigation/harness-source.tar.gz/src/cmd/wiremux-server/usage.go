package main

import (
	"errors"
	"flag"
	"strings"

	"github.com/GridSwarm/wiremux/relay"
)

// The serve flag surface is declared exactly once, in serveFlagSpecs below.
// Flag registration, the serve usage text, the root usage text, and relay-only
// group membership are all derived from that table, so the flag list, per-flag
// help, both usage blocks, and the group rules cannot drift apart. The
// compatibility-manifest cross-check test enumerates the registered flag set,
// so names, defaults, and repeatability stay frozen by the v0.1.x CLI
// manifest.
type serveFlagSpec struct {
	// name is the flag name without leading dashes.
	name string
	// arg is the usage placeholder (for example "addr" or "dur"); empty for
	// boolean flags that take no value.
	arg string
	// usage is the operator-facing description, used both as the flag help
	// string and as the usage-text description column.
	usage string
	// group is the flag family the row belongs to; validation derives which
	// groups an invocation touched from these declarations via
	// serveFlagGroups, never from how the flag name is spelled.
	group serveFlagGroup
	// add registers the flag against the flag set and config.
	add func(fs *flag.FlagSet, cfg *serveConfig, acmeDomains *stringListFlag, name, usage string)
}

// serveFlagGroup names the flag family a serve flag belongs to. Group
// membership is declared on each serveFlagSpecs row and is the only fact the
// relay-only validation rules read; it is implementation vocabulary, not part
// of the frozen CLI contract.
type serveFlagGroup uint8

const (
	groupNone serveFlagGroup = iota
	groupRelayMode
	groupRelayAbuse
	groupRelayAbuseTuning
	groupRelayAssistShaping
	groupACME
	groupSTUN
)

// Operator-facing spellings of the ephemeral-abuse flags, shared by the flag
// table and the validation-failure messages.
const (
	flagRelayEphemeralAbuseWindow             = "--relay-ephemeral-abuse-window"
	flagRelayEphemeralAbuseThreshold          = "--relay-ephemeral-abuse-threshold"
	flagRelayEphemeralAbuseInitialBackoff     = "--relay-ephemeral-abuse-initial-backoff"
	flagRelayEphemeralAbuseMaxBackoff         = "--relay-ephemeral-abuse-max-backoff"
	flagRelayEphemeralAbuseMinPairDuration    = "--relay-ephemeral-abuse-min-pair-duration"
	flagRelayEphemeralAbuseMaxTrackedSessions = "--relay-ephemeral-abuse-max-tracked-sessions"
)

var serveFlagSpecs = []serveFlagSpec{
	{
		"relay-listen", "addr", "TCP listen address for the TLS relay", groupNone,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.relayListen, name, ":443", usage)
		},
	},
	{
		"stun-listen", "addr", "UDP listen address for the STUN responder", groupSTUN,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.stunListen, name, ":3478", usage)
		},
	},
	{
		"stun-rate-window", "dur", "STUN fixed rate-limit window", groupSTUN,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.DurationVar(&cfg.stunRateWindow, name, defaultSTUNRateLimitWindow, usage)
		},
	},
	{
		"stun-max-global-per-window", "n", "STUN global packet budget per rate window", groupSTUN,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.IntVar(&cfg.stunMaxGlobalPerWindow, name, defaultSTUNMaxGlobalPerWindow, usage)
		},
	},
	{
		"stun-max-source-per-window", "n", "STUN source bucket packet budget per rate window", groupSTUN,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.IntVar(&cfg.stunMaxSourcePerWindow, name, defaultSTUNMaxSourcePerWindow, usage)
		},
	},
	{
		"stun-rate-ipv6-prefix-bits", "n", "IPv6 prefix bits for STUN source buckets", groupSTUN,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.IntVar(&cfg.stunRateIPv6PrefixBits, name, defaultSTUNRateLimitIPv6PrefixBits, usage)
		},
	},
	{
		"stun-rate-drop-report-interval", "dur", "periodically report aggregate STUN rate-limit drop counts; 0 disables", groupSTUN,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.DurationVar(&cfg.stunRateDropReportInterval, name, 0, usage)
		},
	},
	{
		"tls-cert", "path", "path to the relay TLS certificate PEM file", groupNone,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.tlsCert, name, "", usage)
		},
	},
	{
		"tls-key", "path", "path to the relay TLS private key PEM file", groupNone,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.tlsKey, name, "", usage)
		},
	},
	{
		"acme", "", "provision relay TLS certificates with ACME (TLS-ALPN-01 and HTTP-01)", groupACME,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.BoolVar(&cfg.acme, name, false, usage)
		},
	},
	{
		"acme-domain", "name", "ACME domain name (repeatable)", groupACME,
		func(fs *flag.FlagSet, _ *serveConfig, acmeDomains *stringListFlag, name, usage string) {
			fs.Var(acmeDomains, name, usage)
		},
	},
	{
		"acme-cache-dir", "path", "absolute ACME certificate cache directory", groupACME,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.acmeCacheDir, name, "", usage)
		},
	},
	{
		"acme-http-listen", "addr", "HTTP-01 listener address for ACME (empty disables HTTP-01)", groupACME,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.acmeHTTPListen, name, ":80", usage)
		},
	},
	{
		"acme-directory-url", "url", "ACME directory URL (default: Let's Encrypt production)", groupACME,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.acmeDirectoryURL, name, "", usage)
		},
	},
	{
		"acme-eab-kid", "id", "ACME external account binding key identifier", groupACME,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.acmeEABKID, name, "", usage)
		},
	},
	{
		"acme-eab-hmac-key-file", "path", "absolute path to the base64url ACME EAB HMAC key file", groupACME,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.acmeEABHMACKeyFile, name, "", usage)
		},
	},
	{
		"shutdown-timeout", "dur", "bounded shutdown wait for relay/server work", groupNone,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.DurationVar(&cfg.shutdownTimeout, name, relay.DefaultShutdownTimeout, usage)
		},
	},
	{
		"debug-pprof-listen", "addr", "serve Go pprof debug endpoints on a loopback IP host:port; empty disables", groupNone,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.debugPprofListen, name, "", usage)
		},
	},
	{
		"relay-ephemeral-abuse-backoff", "", "enable per-SessionID backoff for suspicious ephemeral relay attempts", groupRelayAbuse,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.BoolVar(&cfg.relayEphemeralAbuseBackoff, name, false, usage)
		},
	},
	{
		strings.TrimPrefix(flagRelayEphemeralAbuseWindow, "--"), "dur", "rolling window for per-SessionID abuse events", groupRelayAbuseTuning,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.DurationVar(&cfg.relayEphemeralAbuseConfig.EventWindow, name, cfg.relayEphemeralAbuseConfig.EventWindow, usage)
		},
	},
	{
		strings.TrimPrefix(flagRelayEphemeralAbuseThreshold, "--"), "n", "events per SessionID before backoff applies", groupRelayAbuseTuning,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.IntVar(&cfg.relayEphemeralAbuseConfig.EventThreshold, name, cfg.relayEphemeralAbuseConfig.EventThreshold, usage)
		},
	},
	{
		strings.TrimPrefix(flagRelayEphemeralAbuseInitialBackoff, "--"), "dur", "first per-SessionID abuse backoff delay", groupRelayAbuseTuning,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.DurationVar(&cfg.relayEphemeralAbuseConfig.InitialBackoff, name, cfg.relayEphemeralAbuseConfig.InitialBackoff, usage)
		},
	},
	{
		strings.TrimPrefix(flagRelayEphemeralAbuseMaxBackoff, "--"), "dur", "maximum per-SessionID abuse backoff delay", groupRelayAbuseTuning,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.DurationVar(&cfg.relayEphemeralAbuseConfig.MaxBackoff, name, cfg.relayEphemeralAbuseConfig.MaxBackoff, usage)
		},
	},
	{
		strings.TrimPrefix(flagRelayEphemeralAbuseMinPairDuration, "--"), "dur", "paired relay streams shorter than this count as abuse events", groupRelayAbuseTuning,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.DurationVar(&cfg.relayEphemeralAbuseConfig.MinPairedSessionDuration, name, cfg.relayEphemeralAbuseConfig.MinPairedSessionDuration, usage)
		},
	},
	{
		strings.TrimPrefix(flagRelayEphemeralAbuseMaxTrackedSessions, "--"), "n", "maximum tracked SessionID abuse keys", groupRelayAbuseTuning,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.IntVar(&cfg.relayEphemeralAbuseConfig.MaxTrackedSessionIDs, name, cfg.relayEphemeralAbuseConfig.MaxTrackedSessionIDs, usage)
		},
	},
	{
		"relay-assist-stream-rate", "bytes/s", "per-stream relay-assist byte-rate ceiling (0 = unlimited)", groupRelayAssistShaping,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.Int64Var(&cfg.relayAssistStreamRate, name, 0, usage)
		},
	},
	{
		"relay-assist-global-rate", "bytes/s", "relay-wide relay-assist byte-rate ceiling (0 = unlimited)", groupRelayAssistShaping,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.Int64Var(&cfg.relayAssistGlobalRate, name, 0, usage)
		},
	},
	{
		"relay-assist-egress-budget", "bytes", "monthly relay-assist egress budget that trips the breaker (0 = none)", groupRelayAssistShaping,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.Int64Var(&cfg.relayAssistEgressBudget, name, 0, usage)
		},
	},
	{
		"relay-assist-egress-state", "path", "absolute path of the monthly egress state file (enables counting)", groupRelayAssistShaping,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.relayAssistEgressState, name, "", usage)
		},
	},
	{
		"relay-shaping-file", "path", "absolute path of the relay-assist shaping file re-read on SIGHUP", groupRelayAssistShaping,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.relayShapingFile, name, "", usage)
		},
	},
	{
		"no-stun", "", "disable the STUN responder", groupNone,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.BoolVar(&cfg.noSTUN, name, false, usage)
		},
	},
	{
		"no-relay", "", "disable the TLS relay", groupNone,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.BoolVar(&cfg.noRelay, name, false, usage)
		},
	},
	{
		"ephemeral-only", "", "accept only ephemeral rendezvous on the relay", groupRelayMode,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.BoolVar(&cfg.ephemeralOnly, name, false, usage)
		},
	},
	{
		"longlived-only", "", "accept only long-lived rendezvous on the relay", groupRelayMode,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.BoolVar(&cfg.longLivedOnly, name, false, usage)
		},
	},
	{
		"longlived-proof", "scheme", "long-lived registration proof scheme (ed25519-keyhash or none)", groupNone,
		func(fs *flag.FlagSet, cfg *serveConfig, _ *stringListFlag, name, usage string) {
			fs.StringVar(&cfg.longLivedProof, name, "ed25519-keyhash", usage)
		},
	},
}

// serveUsageDescColumn is the zero-based column where the description text
// starts; a flag head that reaches it pushes its description onto the next
// line at the same indent.
const serveUsageDescColumn = 29

// serveFlagsUsage is the rendered flag block shared by the root and serve
// usage texts. It is derived from serveFlagSpecs and the registered defaults,
// never hand-maintained.
var serveFlagsUsage = renderServeFlagsUsage()

func renderServeFlagsUsage() string {
	fs, _, _ := newServeFlagSet()
	var b strings.Builder
	for _, spec := range serveFlagSpecs {
		head := "  --" + spec.name
		if spec.arg != "" {
			head += " <" + spec.arg + ">"
		}
		desc := spec.usage
		if suffix := serveFlagDefaultSuffix(fs, spec); suffix != "" {
			desc += " " + suffix
		}
		b.WriteString(head)
		if len(head)+1 > serveUsageDescColumn {
			b.WriteByte('\n')
			b.WriteString(strings.Repeat(" ", serveUsageDescColumn))
		} else {
			b.WriteString(strings.Repeat(" ", serveUsageDescColumn-len(head)))
		}
		b.WriteString(desc)
		b.WriteByte('\n')
	}
	return b.String()
}

// serveFlagDefaultSuffix renders "(default X)" from the registered default so
// the displayed default can never drift from the effective one. Boolean flags
// and flags with empty defaults show no suffix.
func serveFlagDefaultSuffix(fs *flag.FlagSet, spec serveFlagSpec) string {
	if spec.arg == "" {
		return ""
	}
	registered := fs.Lookup(spec.name)
	if registered == nil || registered.DefValue == "" {
		return ""
	}
	return "(default " + registered.DefValue + ")"
}

// validateServeEphemeralAbuseBackoffConfig reports relay validation failures
// with the operator-facing flag spelling. The validation rules live solely in
// relay.ValidateEphemeralAbuseBackoffConfig; this table only renames its
// field verdicts to flags.
func validateServeEphemeralAbuseBackoffConfig(config relay.EphemeralAbuseBackoffConfig) error {
	err := relay.ValidateEphemeralAbuseBackoffConfig(config)
	if err == nil {
		return nil
	}
	var configErr *relay.EphemeralAbuseBackoffConfigError
	if !errors.As(err, &configErr) {
		return err
	}
	message, ok := serveEphemeralAbuseFlagMessages[configErr.Field]
	if !ok {
		return err
	}
	return serveEphemeralAbuseFlagError{message: message}
}

var serveEphemeralAbuseFlagMessages = map[string]string{
	"EventWindow":              flagRelayEphemeralAbuseWindow + " must be positive",
	"EventThreshold":           flagRelayEphemeralAbuseThreshold + " must be positive",
	"InitialBackoff":           flagRelayEphemeralAbuseInitialBackoff + " must be positive",
	"MaxBackoff":               flagRelayEphemeralAbuseMaxBackoff + " must be greater than or equal to " + flagRelayEphemeralAbuseInitialBackoff,
	"MinPairedSessionDuration": flagRelayEphemeralAbuseMinPairDuration + " must be positive",
	"MaxTrackedSessionIDs":     flagRelayEphemeralAbuseMaxTrackedSessions + " must be positive",
}

type serveEphemeralAbuseFlagError struct {
	message string
}

func (e serveEphemeralAbuseFlagError) Error() string {
	return e.message
}

func (e serveEphemeralAbuseFlagError) Unwrap() error {
	return relay.ErrInvalidEphemeralAbuseBackoff
}
