package main

import (
	"context"
	"fmt"
	"io"
	"time"

	"github.com/GridSwarm/wiremux/internal/ratelimit"
)

// stunRateLimitDropReportFormat is the machine-relevant STUN aggregate drop
// report line; the release CLI manifest freezes it for v0.1.x.
const stunRateLimitDropReportFormat = "stun rate-limit drops: global=%d source=%d total=%d\n"

func reportSTUNRateLimitDrops(ctx context.Context, drops *ratelimit.DropCounter, interval time.Duration, w io.Writer) {
	if interval <= 0 || w == nil {
		return
	}

	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			writeSTUNRateLimitDropReport(w, drops.Snapshot())
			return
		case <-ticker.C:
			writeSTUNRateLimitDropReport(w, drops.Snapshot())
		}
	}
}

func writeSTUNRateLimitDropReport(w io.Writer, snapshot ratelimit.DropSnapshot) {
	if w == nil {
		return
	}
	fmt.Fprintf(w, stunRateLimitDropReportFormat, snapshot.Global, snapshot.Source, snapshot.Total())
}
