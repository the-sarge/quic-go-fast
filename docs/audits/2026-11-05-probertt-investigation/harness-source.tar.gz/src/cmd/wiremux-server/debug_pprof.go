package main

import (
	"net"
	"net/http"
	"net/http/pprof"
	"time"
)

// isLoopbackHostPort reports whether addr is a host:port whose host is a
// loopback IP literal and whose port is present. Hostnames are rejected even
// when they would resolve to loopback: the debug listener must not depend on
// resolver state to stay unreachable from other hosts. An empty port
// ("127.0.0.1:") is rejected rather than treated as an implicit ephemeral
// port, so the listen address an operator forwards to is always the one they
// wrote; explicit ":0" remains accepted.
func isLoopbackHostPort(addr string) bool {
	host, port, err := net.SplitHostPort(addr)
	if err != nil || port == "" {
		return false
	}
	ip := net.ParseIP(host)
	return ip != nil && ip.IsLoopback()
}

// newDebugPprofServer serves the Go runtime profiling endpoints on a
// dedicated mux rather than http.DefaultServeMux, so no other handler in the
// process can leak onto the debug listener. WriteTimeout is deliberately
// unset: on the pinned Go 1.27 toolchain the pprof handlers extend a
// configured write deadline by the requested ?seconds=N capture duration
// themselves (net/http/pprof's configureWriteDeadline), so the contract keeps
// captures bounded only by the caller-selected duration rather than layering
// a server-side write budget on top.
func newDebugPprofServer() *http.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("/debug/pprof/", pprof.Index)
	mux.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
	mux.HandleFunc("/debug/pprof/profile", pprof.Profile)
	mux.HandleFunc("/debug/pprof/symbol", pprof.Symbol)
	mux.HandleFunc("/debug/pprof/trace", pprof.Trace)
	return &http.Server{
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
	}
}
