package main

import (
	"errors"
	"flag"
	"strings"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/relay"
)

// TestServeUsageCoversRegisteredFlagsExactly proves the rendered usage block
// and the registered flag set are the same list: every registered flag
// appears exactly once as a usage head, and every usage head is a registered
// flag. Both derive from serveFlagSpecs, so this guards the derivation, and
// with it the impossibility of usage/registration drift.
func TestServeUsageCoversRegisteredFlagsExactly(t *testing.T) {
	fs, _, _ := newServeFlagSet()

	registered := make(map[string]bool)
	fs.VisitAll(func(f *flag.Flag) { registered[f.Name] = true })

	seen := make(map[string]int)
	for _, spec := range serveFlagSpecs {
		seen[spec.name]++
	}
	for name, count := range seen {
		if count != 1 {
			t.Errorf("flag %q declared %d times in serveFlagSpecs, want 1", name, count)
		}
		if !registered[name] {
			t.Errorf("spec flag %q is not registered", name)
		}
	}
	for name := range registered {
		if seen[name] == 0 {
			t.Errorf("registered flag %q missing from serveFlagSpecs", name)
		}
	}

	for _, spec := range serveFlagSpecs {
		head := "  --" + spec.name
		if spec.arg != "" {
			head += " <" + spec.arg + ">"
		}
		// A head line ends the flag name with a space run or a newline, so a
		// name that prefixes another name is not double-counted.
		got := strings.Count(serveFlagsUsage, head+" ") + strings.Count(serveFlagsUsage, head+"\n")
		if got != 1 {
			t.Errorf("usage head %q appears %d times in rendered usage, want 1", head, got)
		}
	}
}

// TestUsageTextsEmbedRenderedFlagBlock proves both stored usage texts are
// built from the one rendered block rather than hand-maintained copies.
func TestUsageTextsEmbedRenderedFlagBlock(t *testing.T) {
	if !strings.HasSuffix(usageText, serveFlagsUsage) {
		t.Error("root usageText does not end with the rendered serve flag block")
	}
	if !strings.HasSuffix(serveUsageText, serveFlagsUsage) {
		t.Error("serveUsageText does not end with the rendered serve flag block")
	}
}

// TestValidateServeEphemeralAbuseBackoffConfigReportsFlagMessage carries the
// operator-facing flag-message contract that moved here from the relay
// package: validation verdicts come from relay's single validator, and this
// command renames each field verdict to its flag spelling.
func TestValidateServeEphemeralAbuseBackoffConfigReportsFlagMessage(t *testing.T) {
	valid := relay.DefaultEphemeralAbuseBackoffConfig()
	for _, tc := range []struct {
		name    string
		mutate  func(*relay.EphemeralAbuseBackoffConfig)
		wantErr string
	}{
		{
			name:    "event-window",
			mutate:  func(c *relay.EphemeralAbuseBackoffConfig) { c.EventWindow = 0 },
			wantErr: "--relay-ephemeral-abuse-window must be positive",
		},
		{
			name:    "event-threshold",
			mutate:  func(c *relay.EphemeralAbuseBackoffConfig) { c.EventThreshold = 0 },
			wantErr: "--relay-ephemeral-abuse-threshold must be positive",
		},
		{
			name:    "initial-backoff",
			mutate:  func(c *relay.EphemeralAbuseBackoffConfig) { c.InitialBackoff = 0 },
			wantErr: "--relay-ephemeral-abuse-initial-backoff must be positive",
		},
		{
			name:    "max-backoff",
			mutate:  func(c *relay.EphemeralAbuseBackoffConfig) { c.MaxBackoff = c.InitialBackoff - time.Nanosecond },
			wantErr: "--relay-ephemeral-abuse-max-backoff must be greater than or equal to --relay-ephemeral-abuse-initial-backoff",
		},
		{
			name:    "min-paired-session-duration",
			mutate:  func(c *relay.EphemeralAbuseBackoffConfig) { c.MinPairedSessionDuration = 0 },
			wantErr: "--relay-ephemeral-abuse-min-pair-duration must be positive",
		},
		{
			name:    "max-tracked-session-ids",
			mutate:  func(c *relay.EphemeralAbuseBackoffConfig) { c.MaxTrackedSessionIDs = 0 },
			wantErr: "--relay-ephemeral-abuse-max-tracked-sessions must be positive",
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			config := valid
			tc.mutate(&config)

			err := validateServeEphemeralAbuseBackoffConfig(config)
			if !errors.Is(err, relay.ErrInvalidEphemeralAbuseBackoff) {
				t.Fatalf("validateServeEphemeralAbuseBackoffConfig error = %v, want %v", err, relay.ErrInvalidEphemeralAbuseBackoff)
			}
			if got := err.Error(); got != tc.wantErr {
				t.Fatalf("validateServeEphemeralAbuseBackoffConfig error = %q, want %q", got, tc.wantErr)
			}
		})
	}
}

// TestServeEphemeralAbuseFlagMessagesCoverEveryValidatedField proves the
// flag-message table stays in lockstep with relay's validator fields: every
// field verdict the validator can produce has a flag spelling here.
func TestServeEphemeralAbuseFlagMessagesCoverEveryValidatedField(t *testing.T) {
	valid := relay.DefaultEphemeralAbuseBackoffConfig()
	for _, mutate := range []func(*relay.EphemeralAbuseBackoffConfig){
		func(c *relay.EphemeralAbuseBackoffConfig) { c.EventWindow = 0 },
		func(c *relay.EphemeralAbuseBackoffConfig) { c.EventThreshold = 0 },
		func(c *relay.EphemeralAbuseBackoffConfig) { c.InitialBackoff = 0 },
		func(c *relay.EphemeralAbuseBackoffConfig) { c.MaxBackoff = c.InitialBackoff - time.Nanosecond },
		func(c *relay.EphemeralAbuseBackoffConfig) { c.MinPairedSessionDuration = 0 },
		func(c *relay.EphemeralAbuseBackoffConfig) { c.MaxTrackedSessionIDs = 0 },
	} {
		config := valid
		mutate(&config)
		err := relay.ValidateEphemeralAbuseBackoffConfig(config)
		var configErr *relay.EphemeralAbuseBackoffConfigError
		if !errors.As(err, &configErr) {
			t.Fatalf("relay.ValidateEphemeralAbuseBackoffConfig error = %v, want *EphemeralAbuseBackoffConfigError", err)
		}
		if _, ok := serveEphemeralAbuseFlagMessages[configErr.Field]; !ok {
			t.Errorf("no flag message for validated field %q", configErr.Field)
		}
	}
}
