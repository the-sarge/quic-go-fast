package main

import (
	"bytes"
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/ratelimit"
	"github.com/GridSwarm/wiremux/internal/relayobserve"
	"github.com/GridSwarm/wiremux/internal/tlstest"
	"github.com/GridSwarm/wiremux/relay"
	"github.com/GridSwarm/wiremux/relayurl"
	"github.com/GridSwarm/wiremux/stun"
)

func TestRunRejectsUnknownSubcommand(t *testing.T) {
	code := run([]string{"unknown"}, io.Discard, &bytes.Buffer{})
	if code != 2 {
		t.Fatalf("run unknown subcommand code = %d, want 2", code)
	}
}

func TestRunServeHelp(t *testing.T) {
	var stderr bytes.Buffer
	if code := run([]string{"serve", "--help"}, io.Discard, &stderr); code != 0 {
		t.Fatalf("run serve --help code = %d, want 0", code)
	}
	for _, want := range []string{"--relay-listen", "--shutdown-timeout", "--relay-ephemeral-abuse-backoff", "default 5s"} {
		if !strings.Contains(stderr.String(), want) {
			t.Fatalf("serve --help stderr = %q, want %q", stderr.String(), want)
		}
	}
}

func TestUsageIncludesEphemeralAbuseFlags(t *testing.T) {
	flags := []string{
		"--relay-ephemeral-abuse-backoff",
		"--relay-ephemeral-abuse-window",
		"--relay-ephemeral-abuse-threshold",
		"--relay-ephemeral-abuse-initial-backoff",
		"--relay-ephemeral-abuse-max-backoff",
		"--relay-ephemeral-abuse-min-pair-duration",
		"--relay-ephemeral-abuse-max-tracked-sessions",
	}
	for _, helpArgs := range [][]string{{"--help"}, {"serve", "--help"}} {
		var stderr bytes.Buffer
		if code := run(helpArgs, io.Discard, &stderr); code != 0 {
			t.Fatalf("run %v code = %d, want 0", helpArgs, code)
		}
		for _, flag := range flags {
			if !strings.Contains(stderr.String(), flag) {
				t.Fatalf("run %v help missing %s:\n%s", helpArgs, flag, stderr.String())
			}
		}
	}
}

func TestRunServeRequiresTLSConfiguration(t *testing.T) {
	var stderr bytes.Buffer
	code := run([]string{"serve"}, io.Discard, &stderr)
	if code != 2 {
		t.Fatalf("run serve without TLS code = %d, want 2", code)
	}
	message := stderr.String()
	for _, want := range []string{"TLS", "--tls-cert", "--tls-key", "--acme"} {
		if !strings.Contains(message, want) {
			t.Fatalf("stderr %q does not contain %q", message, want)
		}
	}
}

func TestRunServeRejectsACMEWithoutDomain(t *testing.T) {
	if code := run([]string{"serve", "--acme", "--acme-cache-dir", t.TempDir()}, io.Discard, io.Discard); code != 2 {
		t.Fatalf("run code = %d, want 2", code)
	}
}

func TestRunServeRejectsRelativeACMECacheDir(t *testing.T) {
	if code := run([]string{
		"serve",
		"--acme",
		"--acme-domain", "relay.example.com",
		"--acme-cache-dir", "wiremux-acme",
	}, io.Discard, io.Discard); code != 2 {
		t.Fatalf("run code = %d, want 2", code)
	}
}

func TestRunServeStartsACMEHTTPAndRelay(t *testing.T) {
	relayListen := freeTCPListenAddr(t)
	httpListen := freeTCPListenAddr(t)
	cacheDir := t.TempDir()

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--relay-listen", relayListen,
			"--no-stun",
			"--acme",
			"--acme-domain", "relay.example.com",
			"--acme-cache-dir", cacheDir,
			"--acme-http-listen", httpListen,
		}, io.Discard)
	}()

	waitForTCPListener(t, relayListen)
	waitForTCPListener(t, httpListen)

	client := &http.Client{
		CheckRedirect: func(*http.Request, []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
	resp, err := client.Get("http://" + httpListen)
	if err != nil {
		t.Fatalf("http.Get acme listener: %v", err)
	}
	_ = resp.Body.Close()
	if resp.StatusCode == 0 {
		t.Fatalf("acme http listener returned no status")
	}

	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0", code)
	}
	assertTCPDialFails(t, relayListen)
	assertTCPDialFails(t, httpListen)
}

func TestRunServeRejectsACMEAndExplicitCertTogether(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	if code := run([]string{
		"serve",
		"--acme",
		"--acme-domain", "relay.example.com",
		"--tls-cert", certPath,
		"--tls-key", keyPath,
	}, io.Discard, io.Discard); code != 2 {
		t.Fatalf("run code = %d, want 2", code)
	}
}

func TestRunServeStartupFailureClosesPreparedACMEHTTPListener(t *testing.T) {
	relayBlocker, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("Listen relay blocker: %v", err)
	}
	defer relayBlocker.Close()
	httpListen := freeTCPListenAddr(t)

	code := runServe(context.Background(), []string{
		"--relay-listen", relayBlocker.Addr().String(),
		"--no-stun",
		"--acme",
		"--acme-domain", "relay.example.com",
		"--acme-cache-dir", t.TempDir(),
		"--acme-http-listen", httpListen,
	}, io.Discard)
	if code != 1 {
		t.Fatalf("runServe exit code = %d, want 1", code)
	}
	assertTCPDialFails(t, httpListen)
}

func TestRelayOptionsForServeACMEUsesSeparateTLSHandshakeTimeout(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("Listen tcp: %v", err)
	}

	opts := relayOptionsForServe(serveConfig{
		acme:            true,
		shutdownTimeout: relay.DefaultShutdownTimeout,
	}, delayedServeTLSConfig(t, 75*time.Millisecond))
	opts = append(opts, relay.WithRequestTimeout(25*time.Millisecond))
	relayServer := relay.New(opts...)
	ctx, cancel := context.WithCancel(context.Background())
	errCh := make(chan error, 1)
	go func() {
		errCh <- relayServer.ServeContext(ctx, listener)
	}()
	t.Cleanup(func() {
		cancel()
		select {
		case err := <-errCh:
			if err != nil {
				t.Fatalf("relay ServeContext error = %v, want nil", err)
			}
		case <-time.After(time.Second):
			t.Fatal("relay ServeContext did not return after context cancellation")
		}
	})

	conn, err := tls.DialWithDialer(&net.Dialer{Timeout: time.Second}, "tcp", listener.Addr().String(), insecureServeTestTLSConfig())
	if err != nil {
		t.Fatalf("TLS Dial with delayed ACME certificate: %v", err)
	}
	defer conn.Close()

	assertServeConnectionClosedBefore(t, conn, 150*time.Millisecond)
}

func TestRunServeRejectsACMEWithNoRelay(t *testing.T) {
	if code := run([]string{
		"serve",
		"--no-relay",
		"--acme",
		"--acme-domain", "relay.example.com",
	}, io.Discard, io.Discard); code != 2 {
		t.Fatalf("run code = %d, want 2", code)
	}
}

func TestRunServeRejectsIncompleteTLSPaths(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)

	tests := []struct {
		name string
		args []string
	}{
		{name: "cert only", args: []string{"serve", "--tls-cert", certPath}},
		{name: "key only", args: []string{"serve", "--tls-key", keyPath}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var stderr bytes.Buffer
			if code := run(append(tt.args, "--relay-listen", "127.0.0.1:0"), io.Discard, &stderr); code != 2 {
				t.Fatalf("run code = %d, want 2; stderr=%q", code, stderr.String())
			}
		})
	}
}

func TestRunServeRejectsInvalidEphemeralAbuseBackoff(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	for _, tc := range []struct {
		name string
		flag string
		val  string
	}{
		{name: "window", flag: "--relay-ephemeral-abuse-window", val: "0s"},
		{name: "threshold", flag: "--relay-ephemeral-abuse-threshold", val: "0"},
		{name: "initial", flag: "--relay-ephemeral-abuse-initial-backoff", val: "0s"},
		{name: "max", flag: "--relay-ephemeral-abuse-max-backoff", val: "1ns"},
		{name: "min-pair", flag: "--relay-ephemeral-abuse-min-pair-duration", val: "0s"},
		{name: "max-tracked", flag: "--relay-ephemeral-abuse-max-tracked-sessions", val: "0"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var stderr bytes.Buffer
			code := run([]string{
				"serve",
				"--no-stun",
				"--tls-cert", certPath,
				"--tls-key", keyPath,
				"--relay-ephemeral-abuse-backoff",
				"--relay-ephemeral-abuse-initial-backoff", "2ns",
				tc.flag, tc.val,
			}, io.Discard, &stderr)
			if code != 2 {
				t.Fatalf("run code = %d, want 2; stderr=%q", code, stderr.String())
			}
			if !strings.Contains(stderr.String(), tc.flag) {
				t.Fatalf("stderr %q does not mention %s", stderr.String(), tc.flag)
			}
		})
	}
}

func TestRunServeRejectsEphemeralAbuseTuningWithoutBackoff(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	const wantStderr = "wiremux-server: --relay-ephemeral-abuse-* tuning flags require --relay-ephemeral-abuse-backoff\n"
	for _, tc := range []struct {
		name string
		flag string
		val  string
	}{
		{name: "valid-threshold", flag: "--relay-ephemeral-abuse-threshold", val: "2"},
		{name: "invalid-window", flag: "--relay-ephemeral-abuse-window", val: "0s"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var stderr bytes.Buffer
			code := run([]string{
				"serve",
				"--no-stun",
				"--tls-cert", certPath,
				"--tls-key", keyPath,
				tc.flag, tc.val,
			}, io.Discard, &stderr)
			if code != 2 {
				t.Fatalf("run code = %d, want 2; stderr=%q", code, stderr.String())
			}
			if got := stderr.String(); got != wantStderr {
				t.Fatalf("stderr = %q, want %q", got, wantStderr)
			}
		})
	}
}

func TestRunServeRejectsEphemeralAbuseFlagsWithoutEphemeralRelay(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	for _, tc := range []struct {
		name       string
		args       []string
		wantStderr string
	}{
		{
			name:       "enable-no-relay",
			args:       []string{"serve", "--no-relay", "--relay-ephemeral-abuse-backoff"},
			wantStderr: "--no-relay",
		},
		{
			name:       "tuning-no-relay",
			args:       []string{"serve", "--no-relay", "--relay-ephemeral-abuse-threshold", "2"},
			wantStderr: "--no-relay",
		},
		{
			name: "enable-longlived-only",
			args: []string{
				"serve",
				"--no-stun",
				"--tls-cert", certPath,
				"--tls-key", keyPath,
				"--longlived-only",
				"--relay-ephemeral-abuse-backoff",
			},
			wantStderr: "--longlived-only",
		},
		{
			name: "tuning-longlived-only",
			args: []string{
				"serve",
				"--no-stun",
				"--tls-cert", certPath,
				"--tls-key", keyPath,
				"--longlived-only",
				"--relay-ephemeral-abuse-threshold", "2",
			},
			wantStderr: "--longlived-only",
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var stderr bytes.Buffer
			if code := run(tc.args, io.Discard, &stderr); code != 2 {
				t.Fatalf("run code = %d, want 2; stderr=%q", code, stderr.String())
			}
			if !strings.Contains(stderr.String(), tc.wantStderr) {
				t.Fatalf("stderr %q does not mention %s", stderr.String(), tc.wantStderr)
			}
		})
	}
}

func TestRunServeEphemeralAbuseBackoffDelaysAfterShortPairedSession(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	cfg, err := parseServeFlags([]string{
		"--no-stun",
		"--tls-cert", certPath,
		"--tls-key", keyPath,
		"--relay-ephemeral-abuse-backoff",
		"--relay-ephemeral-abuse-threshold", "1",
		"--relay-ephemeral-abuse-initial-backoff", "75ms",
		"--relay-ephemeral-abuse-max-backoff", "75ms",
		"--relay-ephemeral-abuse-min-pair-duration", "1s",
	})
	if err != nil {
		t.Fatalf("parseServeFlags: %v", err)
	}
	if err := validateServeConfig(cfg); err != nil {
		t.Fatalf("validateServeConfig: %v", err)
	}
	tlsConfig, err := relay.LoadServerTLSConfig(certPath, keyPath)
	if err != nil {
		t.Fatalf("LoadServerTLSConfig: %v", err)
	}
	backoffs := relayobserve.NewBackoffs()
	server := relayobserve.NewObservedRelay(nil, backoffs, relayOptionsForServe(cfg, tlsConfig)).(*relay.Relay)
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("Listen: %v", err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	errCh := make(chan error, 1)
	go func() { errCh <- server.ServeContext(ctx, listener) }()
	t.Cleanup(func() {
		cancel()
		_ = listener.Close()
		if err := <-errCh; err != nil {
			t.Errorf("ServeContext: %v", err)
		}
	})

	endpoint, err := relayurl.Parse("wiremux://" + listener.Addr().String())
	if err != nil {
		t.Fatalf("Parse endpoint: %v", err)
	}
	sessionID := relay.SessionID{1, 3, 5}

	leftCh := make(chan dialOutcome, 1)
	rightCh := make(chan dialOutcome, 1)
	go dialServeRelay(leftCh, endpoint, sessionID)
	go dialServeRelay(rightCh, endpoint, sessionID)
	left := mustServeRelayDial(t, leftCh)
	right := mustServeRelayDial(t, rightCh)
	_ = left.Close()
	_ = right.Close()
	eventCtx, stopEventWait := context.WithTimeout(context.Background(), time.Second)
	defer stopEventWait()
	if !backoffs.WaitForEventCount(eventCtx, sessionID[:], 1) {
		t.Fatal("configured relay did not record the short-pair abuse event")
	}

	delayedLeftCh := make(chan dialOutcome, 1)
	start := time.Now()
	go dialServeRelay(delayedLeftCh, endpoint, sessionID)
	observationCtx, stopObservation := context.WithTimeout(context.Background(), time.Second)
	defer stopObservation()
	if !backoffs.WaitForCount(observationCtx, sessionID[:], 1) {
		t.Fatal("configured relay did not enter ephemeral abuse backoff")
	}
	if got := backoffs.LastDelay(sessionID[:]); got != 75*time.Millisecond {
		t.Fatalf("observed backoff = %s, want 75ms", got)
	}

	delayedRightCh := make(chan dialOutcome, 1)
	go dialServeRelay(delayedRightCh, endpoint, sessionID)
	delayedLeft := mustServeRelayDial(t, delayedLeftCh)
	delayedRight := mustServeRelayDial(t, delayedRightCh)
	_ = delayedLeft.Close()
	_ = delayedRight.Close()
	if elapsed := time.Since(start); elapsed < 75*time.Millisecond {
		t.Fatalf("Dial completed before configured backoff elapsed: %s", elapsed)
	}
}

func TestRunServeLoadsExplicitCertKeyAndPrintsFingerprint(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	tlsConfig, err := relay.LoadServerTLSConfig(certPath, keyPath)
	if err != nil {
		t.Fatalf("LoadServerTLSConfig: %v", err)
	}
	wantFingerprint, err := relay.ServerTLSFingerprint(tlsConfig)
	if err != nil {
		t.Fatalf("ServerTLSFingerprint: %v", err)
	}

	relayListen := freeTCPListenAddr(t)
	var stderr lockedBuffer
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--relay-listen", relayListen,
			"--no-stun",
			"--tls-cert", certPath,
			"--tls-key", keyPath,
		}, &stderr)
	}()

	waitForTCPListener(t, relayListen)
	stderr.mu.Lock()
	message := stderr.buf.String()
	stderr.mu.Unlock()
	if !strings.Contains(message, wantFingerprint.String()) {
		t.Fatalf("stderr %q does not contain fingerprint %q", message, wantFingerprint.String())
	}

	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0", code)
	}
}

func TestRunServeStartsRelayAndSTUN(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	relayListen := freeTCPListenAddr(t)
	stunListen := freeUDPListenAddr(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--relay-listen", relayListen,
			"--stun-listen", stunListen,
			"--tls-cert", certPath,
			"--tls-key", keyPath,
		}, io.Discard)
	}()

	waitForTCPListener(t, relayListen)
	probeRelayTLS(t, relayListen)
	probeSTUNBindingWithRetry(t, stunListen)

	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0", code)
	}
	assertTCPDialFails(t, relayListen)
	assertSTUNBindingFails(t, stunListen)
}

func TestRunServeMapsServiceGroupWaitErrorToExitCode(t *testing.T) {
	originalWait := waitForServeServices
	t.Cleanup(func() {
		waitForServeServices = originalWait
	})

	waitCalled := false
	waitForServeServices = func(group *serviceGroup, ctx context.Context, shutdownTimeout time.Duration) error {
		waitCalled = true
		if ctx == nil {
			t.Fatal("wait context is nil")
		}
		if shutdownTimeout != 25*time.Millisecond {
			t.Fatalf("shutdownTimeout = %s, want 25ms", shutdownTimeout)
		}
		if len(group.services) != 1 {
			t.Fatalf("registered services = %d, want 1", len(group.services))
		}
		if group.services[0].name != "stun" {
			t.Fatalf("registered service = %q, want stun", group.services[0].name)
		}
		return fmt.Errorf("shutdown timed out: %w", context.DeadlineExceeded)
	}

	var stderr bytes.Buffer
	code := runServe(context.Background(), []string{
		"--no-relay",
		"--stun-listen", "127.0.0.1:0",
		"--shutdown-timeout", "25ms",
	}, &stderr)
	if !waitCalled {
		t.Fatal("runServe did not reach serviceGroup wait")
	}
	if code != 1 {
		t.Fatalf("runServe exit code = %d, want 1; stderr=%q", code, stderr.String())
	}

	message := stderr.String()
	for _, want := range []string{"wiremux-server:", "shutdown timed out", context.DeadlineExceeded.Error()} {
		if !strings.Contains(message, want) {
			t.Fatalf("stderr = %q, want %q", message, want)
		}
	}
}

func TestRunServeStartupFailureClosesPreparedRelayListener(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	relayListen := freeTCPListenAddr(t)
	stunBlocker, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("ListenPacket stun blocker: %v", err)
	}
	defer stunBlocker.Close()

	code := runServe(context.Background(), []string{
		"--relay-listen", relayListen,
		"--stun-listen", stunBlocker.LocalAddr().String(),
		"--tls-cert", certPath,
		"--tls-key", keyPath,
	}, io.Discard)
	if code != 1 {
		t.Fatalf("runServe exit code = %d, want 1", code)
	}
	assertTCPDialFails(t, relayListen)
}

func TestRunServeNoRelay(t *testing.T) {
	stunListen := freeUDPListenAddr(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--no-relay",
			"--stun-listen", stunListen,
		}, io.Discard)
	}()

	probeSTUNBindingWithRetry(t, stunListen)

	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0", code)
	}
	assertSTUNBindingFails(t, stunListen)
}

func TestRunServeRejectsInvalidSTUNRateLimit(t *testing.T) {
	tests := []struct {
		name string
		args []string
	}{
		{name: "window", args: []string{"serve", "--no-relay", "--stun-rate-window", "0s"}},
		{name: "window with disabled STUN", args: []string{"serve", "--no-stun", "--tls-cert", "missing.crt", "--tls-key", "missing.key", "--stun-rate-window", "0s"}},
		{name: "global", args: []string{"serve", "--no-relay", "--stun-max-global-per-window", "0"}},
		{name: "source", args: []string{"serve", "--no-relay", "--stun-max-source-per-window", "0"}},
		{name: "ipv6 prefix zero", args: []string{"serve", "--no-relay", "--stun-rate-ipv6-prefix-bits", "0"}},
		{name: "ipv6 prefix too large", args: []string{"serve", "--no-relay", "--stun-rate-ipv6-prefix-bits", "129"}},
		{name: "drop report interval negative", args: []string{"serve", "--no-relay", "--stun-rate-drop-report-interval", "-1s"}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if code := run(tt.args, io.Discard, io.Discard); code != 2 {
				t.Fatalf("run code = %d, want 2", code)
			}
		})
	}
}

func TestRunServeRejectsInvalidShutdownTimeout(t *testing.T) {
	if code := run([]string{"serve", "--no-relay", "--shutdown-timeout", "0s"}, io.Discard, io.Discard); code != 2 {
		t.Fatalf("run code = %d, want 2", code)
	}
}

func TestParseServeFlagsAcceptsSTUNRateDropReportInterval(t *testing.T) {
	cfg, err := parseServeFlags([]string{"--stun-rate-drop-report-interval", "250ms"})
	if err != nil {
		t.Fatalf("parseServeFlags: %v", err)
	}
	if cfg.stunRateDropReportInterval != 250*time.Millisecond {
		t.Fatalf("stunRateDropReportInterval = %s, want 250ms", cfg.stunRateDropReportInterval)
	}

	defaultCfg, err := parseServeFlags(nil)
	if err != nil {
		t.Fatalf("parseServeFlags default: %v", err)
	}
	if defaultCfg.stunRateDropReportInterval != 0 {
		t.Fatalf("default stunRateDropReportInterval = %s, want disabled", defaultCfg.stunRateDropReportInterval)
	}
}

func TestParseServeFlagsAcceptsShutdownTimeout(t *testing.T) {
	cfg, err := parseServeFlags([]string{"--shutdown-timeout", "250ms"})
	if err != nil {
		t.Fatalf("parseServeFlags: %v", err)
	}
	if cfg.shutdownTimeout != 250*time.Millisecond {
		t.Fatalf("shutdownTimeout = %s, want 250ms", cfg.shutdownTimeout)
	}

	defaultCfg, err := parseServeFlags(nil)
	if err != nil {
		t.Fatalf("parseServeFlags default: %v", err)
	}
	if defaultCfg.shutdownTimeout != relay.DefaultShutdownTimeout {
		t.Fatalf("default shutdownTimeout = %s, want %s", defaultCfg.shutdownTimeout, relay.DefaultShutdownTimeout)
	}
}

func TestRelayShutdownTimeoutForServeKeepsSupervisorHeadroom(t *testing.T) {
	tests := []struct {
		name            string
		shutdownTimeout time.Duration
		want            time.Duration
	}{
		{name: "default", shutdownTimeout: 5 * time.Second, want: 4900 * time.Millisecond},
		{name: "short", shutdownTimeout: 50 * time.Millisecond, want: 45 * time.Millisecond},
		{name: "minimum", shutdownTimeout: time.Nanosecond, want: time.Nanosecond},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := relayShutdownTimeoutForServe(tt.shutdownTimeout); got != tt.want {
				t.Fatalf("relayShutdownTimeoutForServe(%s) = %s, want %s", tt.shutdownTimeout, got, tt.want)
			}
		})
	}
}

func TestRunServeAllowsSTUNBindingWithinRateLimit(t *testing.T) {
	stunListen := freeUDPListenAddr(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--no-relay",
			"--stun-listen", stunListen,
			"--stun-rate-window", "1h",
			"--stun-max-global-per-window", "10",
			"--stun-max-source-per-window", "10",
		}, io.Discard)
	}()

	probeSTUNBindingWithRetry(t, stunListen)

	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0", code)
	}
}

func TestSTUNRateLimitedPacketConnDropsOverBudgetSource(t *testing.T) {
	stunListen := startRateLimitedSTUNServer(t, ratelimit.PacketConfig{
		Window:         time.Hour,
		MaxGlobal:      10,
		MaxSource:      2,
		IPv6PrefixBits: 64,
	})

	for range 2 {
		if err := probeSTUNBindingErrWithin(stunListen, time.Second); err != nil {
			t.Fatalf("within-budget STUN Binding request failed: %v", err)
		}
	}
	if err := probeSTUNBindingErrWithin(stunListen, 75*time.Millisecond); err == nil {
		t.Fatal("over-budget source STUN Binding request succeeded, want dropped request")
	}
}

func TestSTUNRateLimitedPacketConnDropsOverBudgetGlobal(t *testing.T) {
	stunListen := startRateLimitedSTUNServer(t, ratelimit.PacketConfig{
		Window:         time.Hour,
		MaxGlobal:      2,
		MaxSource:      10,
		IPv6PrefixBits: 64,
	})

	for range 2 {
		if err := probeSTUNBindingErrWithin(stunListen, time.Second); err != nil {
			t.Fatalf("within-budget STUN Binding request failed: %v", err)
		}
	}
	if err := probeSTUNBindingErrWithin(stunListen, 75*time.Millisecond); err == nil {
		t.Fatal("over-budget global STUN Binding request succeeded, want dropped request")
	}
}

func TestRunServeReportsSTUNRateLimitDrops(t *testing.T) {
	tests := []struct {
		name       string
		maxGlobal  string
		maxSource  string
		wantGlobal string
		wantSource string
	}{
		{
			name:       "source",
			maxGlobal:  "100",
			maxSource:  "1",
			wantGlobal: "0",
			wantSource: "1",
		},
		{
			name:       "global",
			maxGlobal:  "1",
			maxSource:  "100",
			wantGlobal: "1",
			wantSource: "0",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			stunListen := freeUDPListenAddr(t)

			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()

			var stderr lockedBuffer
			errCh := make(chan int, 1)
			go func() {
				errCh <- runServe(ctx, []string{
					"--no-relay",
					"--stun-listen", stunListen,
					"--stun-rate-window", "1h",
					"--stun-max-global-per-window", tt.maxGlobal,
					"--stun-max-source-per-window", tt.maxSource,
					"--stun-rate-drop-report-interval", "10ms",
				}, &stderr)
			}()

			probeSTUNBindingWithRetry(t, stunListen)
			if err := probeSTUNBindingErrWithin(stunListen, 75*time.Millisecond); err == nil {
				t.Fatal("over-budget STUN Binding request succeeded, want dropped request")
			}

			waitForSTUNDropReport(t, &stderr, tt.wantGlobal, tt.wantSource, "1")

			cancel()
			if code := <-errCh; code != 0 {
				t.Fatalf("runServe exit code = %d, want 0", code)
			}
		})
	}
}

func TestRunServeReportsFinalSTUNRateLimitDropsOnShutdown(t *testing.T) {
	stunListen := freeUDPListenAddr(t)

	ctx, cancel := context.WithCancel(context.Background())

	var stderr lockedBuffer
	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--no-relay",
			"--stun-listen", stunListen,
			"--stun-rate-window", "1h",
			"--stun-max-global-per-window", "100",
			"--stun-max-source-per-window", "1",
			"--stun-rate-drop-report-interval", "1h",
		}, &stderr)
	}()

	probeSTUNBindingWithRetry(t, stunListen)
	if err := probeSTUNBindingErrWithin(stunListen, 75*time.Millisecond); err == nil {
		t.Fatal("over-budget source STUN Binding request succeeded, want dropped request")
	}

	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0", code)
	}
	assertSTUNDropReport(t, stderr.String(), "0", "1", "1")
}

func TestRunServeNoSTUN(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	relayListen := freeTCPListenAddr(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--relay-listen", relayListen,
			"--no-stun",
			"--tls-cert", certPath,
			"--tls-key", keyPath,
		}, io.Discard)
	}()

	waitForTCPListener(t, relayListen)
	probeRelayTLS(t, relayListen)

	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0", code)
	}
}

func TestRunServeEphemeralOnlyRejectsLongLivedDial(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	relayListen := freeTCPListenAddr(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--relay-listen", relayListen,
			"--no-stun",
			"--ephemeral-only",
			"--tls-cert", certPath,
			"--tls-key", keyPath,
		}, io.Discard)
	}()

	waitForTCPListener(t, relayListen)

	endpoint, err := relayurl.Parse("wiremux://" + relayListen)
	if err != nil {
		t.Fatalf("Parse endpoint: %v", err)
	}
	dialCtx, dialCancel := context.WithTimeout(context.Background(), time.Second)
	defer dialCancel()
	conn, err := relay.Dial(dialCtx, endpoint, relay.ModeLongLived, relay.PeerID("peer"), relay.WithDialTLSConfig(insecureServeTestTLSConfig()))
	if conn != nil {
		_ = conn.Close()
	}
	if !errors.Is(err, relay.ErrLongLivedUnavailable) {
		t.Fatalf("long-lived Dial error = %v, want %v", err, relay.ErrLongLivedUnavailable)
	}

	cancel()
	<-errCh
}

func TestRunServeLongLivedOnlyRejectsEphemeralDial(t *testing.T) {
	certPath, keyPath := writeServeTestCertKeyFiles(t)
	relayListen := freeTCPListenAddr(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--relay-listen", relayListen,
			"--no-stun",
			"--longlived-only",
			"--longlived-proof", "none",
			"--tls-cert", certPath,
			"--tls-key", keyPath,
		}, io.Discard)
	}()

	waitForTCPListener(t, relayListen)

	endpoint, err := relayurl.Parse("wiremux://" + relayListen)
	if err != nil {
		t.Fatalf("Parse endpoint: %v", err)
	}
	dialCtx, dialCancel := context.WithTimeout(context.Background(), time.Second)
	defer dialCancel()
	conn, err := relay.Dial(dialCtx, endpoint, relay.ModeEphemeral, relay.SessionID{1}, relay.WithDialTLSConfig(insecureServeTestTLSConfig()))
	if conn != nil {
		_ = conn.Close()
	}
	if !errors.Is(err, relay.ErrEphemeralUnavailable) {
		t.Fatalf("ephemeral Dial error = %v, want %v", err, relay.ErrEphemeralUnavailable)
	}

	cancel()
	<-errCh
}

func TestRunServeRejectsNoRelayWithModeOnlyFlags(t *testing.T) {
	if code := run([]string{
		"serve",
		"--no-relay",
		"--ephemeral-only",
	}, io.Discard, io.Discard); code != 2 {
		t.Fatalf("run code = %d, want 2", code)
	}
}

func writeServeTestCertKeyFiles(t *testing.T) (certPath, keyPath string) {
	t.Helper()

	dir := t.TempDir()
	certPath = filepath.Join(dir, "server.crt")
	keyPath = filepath.Join(dir, "server.key")

	certPEM, keyPEM := generateServeTestCertKeyPEM(t)
	if err := os.WriteFile(certPath, certPEM, 0o600); err != nil {
		t.Fatalf("WriteFile cert: %v", err)
	}
	if err := os.WriteFile(keyPath, keyPEM, 0o600); err != nil {
		t.Fatalf("WriteFile key: %v", err)
	}
	return certPath, keyPath
}

func generateServeTestCertKeyPEM(t *testing.T) (certPEM, keyPEM []byte) {
	t.Helper()
	identity := tlstest.NewServerIdentity(t)
	return identity.CertificatePEM, identity.PrivateKeyPEM
}

func delayedServeTLSConfig(t *testing.T, delay time.Duration) *tls.Config {
	t.Helper()

	certPEM, keyPEM := generateServeTestCertKeyPEM(t)
	cert, err := tls.X509KeyPair(certPEM, keyPEM)
	if err != nil {
		t.Fatalf("X509KeyPair: %v", err)
	}
	return &tls.Config{
		MinVersion: tls.VersionTLS13,
		GetCertificate: func(*tls.ClientHelloInfo) (*tls.Certificate, error) {
			time.Sleep(delay)
			return &cert, nil
		},
	}
}

func freeTCPListenAddr(t *testing.T) string {
	t.Helper()
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("Listen tcp: %v", err)
	}
	addr := listener.Addr().String()
	_ = listener.Close()
	return addr
}

func freeUDPListenAddr(t *testing.T) string {
	t.Helper()
	conn, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("ListenPacket udp: %v", err)
	}
	addr := conn.LocalAddr().String()
	_ = conn.Close()
	return addr
}

func waitForTCPListener(t *testing.T, addr string) {
	t.Helper()
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		conn, err := net.DialTimeout("tcp", addr, 50*time.Millisecond)
		if err == nil {
			_ = conn.Close()
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("tcp listener %s did not become ready", addr)
}

func assertTCPDialFails(t *testing.T, addr string) {
	t.Helper()

	conn, err := net.DialTimeout("tcp", addr, 75*time.Millisecond)
	if err == nil {
		_ = conn.Close()
		t.Fatalf("tcp listener %s still accepted a connection after shutdown", addr)
	}
}

type lockedBuffer struct {
	mu  sync.Mutex
	buf bytes.Buffer
}

func (l *lockedBuffer) Write(p []byte) (int, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.buf.Write(p)
}

func (l *lockedBuffer) String() string {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.buf.String()
}

func waitForSTUNDropReport(t *testing.T, stderr *lockedBuffer, global, source, total string) {
	t.Helper()

	deadline := time.Now().Add(time.Second)
	for {
		report := stderr.String()
		if hasSTUNDropReport(report, global, source, total) {
			return
		}
		if time.Now().After(deadline) {
			t.Fatalf("stderr %q did not report expected STUN drops", report)
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func assertSTUNDropReport(t *testing.T, report, global, source, total string) {
	t.Helper()

	if !hasSTUNDropReport(report, global, source, total) {
		t.Fatalf("stderr %q did not report expected STUN drops", report)
	}
}

func hasSTUNDropReport(report, global, source, total string) bool {
	return strings.Contains(report, "stun rate-limit drops") &&
		strings.Contains(report, "global="+global) &&
		strings.Contains(report, "source="+source) &&
		strings.Contains(report, "total="+total)
}

func probeRelayTLS(t *testing.T, addr string) {
	t.Helper()
	conn, err := tls.Dial("tcp", addr, insecureServeTestTLSConfig())
	if err != nil {
		t.Fatalf("tls.Dial relay: %v", err)
	}
	_ = conn.Close()
}

func probeSTUNBindingWithRetry(t *testing.T, addr string) {
	t.Helper()
	deadline := time.Now().Add(2 * time.Second)
	var lastErr error
	for time.Now().Before(deadline) {
		if err := probeSTUNBindingErr(addr); err == nil {
			return
		} else {
			lastErr = err
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("STUN binding to %s failed: %v", addr, lastErr)
}

func assertSTUNBindingFails(t *testing.T, addr string) {
	t.Helper()

	if err := probeSTUNBindingErrWithin(addr, 75*time.Millisecond); err == nil {
		t.Fatalf("STUN binding to %s succeeded after shutdown", addr)
	}
}

func probeSTUNBindingErr(addr string) error {
	return probeSTUNBindingErrWithin(addr, time.Second)
}

func probeSTUNBindingErrWithin(addr string, timeout time.Duration) error {
	clientConn, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		return err
	}
	defer clientConn.Close()

	serverAddr, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		return err
	}

	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	client := stun.NewClient()
	reflexive, err := client.Reflexive(ctx, clientConn, serverAddr)
	if err != nil {
		return err
	}
	if reflexive == nil {
		return errors.New("reflexive address is nil")
	}
	return nil
}

func startRateLimitedSTUNServer(t *testing.T, cfg ratelimit.PacketConfig) string {
	t.Helper()

	conn, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("ListenPacket udp: %v", err)
	}

	errCh := make(chan error, 1)
	go func() {
		errCh <- stun.NewServer().Serve(ratelimit.NewPacketConn(conn, cfg))
	}()

	t.Cleanup(func() {
		if err := conn.Close(); err != nil {
			t.Fatalf("Close STUN packet conn: %v", err)
		}
		select {
		case err := <-errCh:
			if err != nil {
				t.Fatalf("STUN server returned error: %v", err)
			}
		case <-time.After(time.Second):
			t.Fatal("STUN server did not return after packet conn close")
		}
	})

	return conn.LocalAddr().String()
}

type dialOutcome struct {
	conn io.ReadWriteCloser
	err  error
}

func dialServeRelay(ch chan<- dialOutcome, endpoint *relayurl.Endpoint, sessionID relay.SessionID) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	conn, err := relay.Dial(ctx, endpoint, relay.ModeEphemeral, sessionID, relay.WithDialTLSConfig(insecureServeTestTLSConfig()))
	ch <- dialOutcome{conn: conn, err: err}
}

func mustServeRelayDial(t *testing.T, ch <-chan dialOutcome) io.ReadWriteCloser {
	t.Helper()

	select {
	case result := <-ch:
		if result.err != nil {
			t.Fatalf("relay Dial: %v", result.err)
		}
		if result.conn == nil {
			t.Fatal("relay Dial returned nil conn")
		}
		return result.conn
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for relay Dial")
		return nil
	}
}

func insecureServeTestTLSConfig() *tls.Config {
	return &tls.Config{
		InsecureSkipVerify: true, // #nosec G402 -- tests dial in-process self-signed relay TLS.
		MinVersion:         tls.VersionTLS13,
	}
}

func assertServeConnectionClosedBefore(t *testing.T, conn net.Conn, timeout time.Duration) {
	t.Helper()

	_ = conn.SetReadDeadline(time.Now().Add(timeout))
	var buf [1]byte
	_, err := conn.Read(buf[:])
	if err == nil {
		t.Fatal("relay read succeeded, want close")
	}
	var timeoutErr net.Error
	if errors.As(err, &timeoutErr) && timeoutErr.Timeout() {
		t.Fatalf("relay connection remained open for %s: %v", timeout, err)
	}
}

func acmeServeArgs(t *testing.T, extra ...string) []string {
	t.Helper()
	return append([]string{
		"serve",
		"--acme",
		"--acme-domain", "relay.example.com",
		"--acme-cache-dir", t.TempDir(),
	}, extra...)
}

func TestRunServeRejectsACMEExtensionFlagsWithoutACME(t *testing.T) {
	for name, args := range map[string][]string{
		"directory url": {"--acme-directory-url", "https://acme.example.com/directory"},
		"eab kid":       {"--acme-eab-kid", "kid-1"},
		"eab key file":  {"--acme-eab-hmac-key-file", "/etc/wiremux/eab.key"},
	} {
		t.Run(name, func(t *testing.T) {
			full := append([]string{"serve", "--tls-cert", "cert.pem", "--tls-key", "key.pem"}, args...)
			if code := run(full, io.Discard, io.Discard); code != 2 {
				t.Fatalf("run code = %d, want 2", code)
			}
		})
	}
}

func TestRunServeRejectsNonHTTPSACMEDirectoryURL(t *testing.T) {
	if code := run(acmeServeArgs(t, "--acme-directory-url", "http://acme.example.com/directory"), io.Discard, io.Discard); code != 2 {
		t.Fatalf("run code = %d, want 2", code)
	}
}

func TestRunServeRejectsPartialEAB(t *testing.T) {
	if code := run(acmeServeArgs(t, "--acme-eab-kid", "kid-1"), io.Discard, io.Discard); code != 2 {
		t.Fatalf("run code = %d, want 2", code)
	}
}

func TestRunServeRejectsRelativeEABKeyFile(t *testing.T) {
	if code := run(acmeServeArgs(t, "--acme-eab-kid", "kid-1", "--acme-eab-hmac-key-file", "eab.key"), io.Discard, io.Discard); code != 2 {
		t.Fatalf("run code = %d, want 2", code)
	}
}

func TestLoadACMEEABKeyDecodesBase64URL(t *testing.T) {
	want := []byte("sixteen-byte-key")
	for name, encoded := range map[string]string{
		"unpadded":       "c2l4dGVlbi1ieXRlLWtleQ",
		"padded":         "c2l4dGVlbi1ieXRlLWtleQ==",
		"trailing space": "c2l4dGVlbi1ieXRlLWtleQ\n",
	} {
		t.Run(name, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "eab.key")
			if err := os.WriteFile(path, []byte(encoded), 0o600); err != nil {
				t.Fatal(err)
			}
			got, err := loadACMEEABKey(path)
			if err != nil {
				t.Fatalf("loadACMEEABKey: %v", err)
			}
			if !bytes.Equal(got, want) {
				t.Fatalf("loadACMEEABKey = %q, want %q", got, want)
			}
		})
	}
}

func TestLoadACMEEABKeyFailuresNeverEchoContent(t *testing.T) {
	const secret = "not!valid!base64url"
	undecodable := filepath.Join(t.TempDir(), "eab.key")
	if err := os.WriteFile(undecodable, []byte(secret), 0o600); err != nil {
		t.Fatal(err)
	}
	for name, path := range map[string]string{
		"missing":     filepath.Join(t.TempDir(), "absent.key"),
		"undecodable": undecodable,
		"empty":       writeTempFile(t, "empty.key", ""),
	} {
		t.Run(name, func(t *testing.T) {
			_, err := loadACMEEABKey(path)
			if err == nil {
				t.Fatal("loadACMEEABKey error = nil, want non-nil")
			}
			if strings.Contains(err.Error(), secret) {
				t.Fatalf("loadACMEEABKey error %q echoes file content", err)
			}
		})
	}
}

func writeTempFile(t *testing.T, name, content string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), name)
	if err := os.WriteFile(path, []byte(content), 0o600); err != nil {
		t.Fatal(err)
	}
	return path
}

func TestRunServeMissingEABKeyFileFailsStartup(t *testing.T) {
	var stderr bytes.Buffer
	code := run(acmeServeArgs(t,
		"--relay-listen", freeTCPListenAddr(t),
		"--no-stun",
		"--acme-eab-kid", "kid-1",
		"--acme-eab-hmac-key-file", filepath.Join(t.TempDir(), "absent.key"),
	), io.Discard, &stderr)
	if code != 1 {
		t.Fatalf("run code = %d, want 1; stderr %q", code, stderr.String())
	}
	if !strings.HasPrefix(stderr.String(), "wiremux-server: ") {
		t.Fatalf("stderr %q lacks the serve error prefix", stderr.String())
	}
}

func TestRunServeACMEDirectoryURLAppearsInStartupLine(t *testing.T) {
	const relayListen = "127.0.0.1:0"
	const httpListen = "localhost:0"
	keyFile := writeTempFile(t, "eab.key", "c2l4dGVlbi1ieXRlLWtleQ")
	const directory = "https://acme-staging-v02.api.letsencrypt.org/directory"

	// The startup-line contract needs successful listener setup, not a
	// connect-and-retry readiness probe against a released port reservation.
	originalWait := waitForServeServices
	t.Cleanup(func() { waitForServeServices = originalWait })
	waitCalled := false
	waitForServeServices = func(group *serviceGroup, _ context.Context, _ time.Duration) error {
		waitCalled = true
		if len(group.services) != 2 {
			t.Fatalf("registered services: got %d, want 2", len(group.services))
		}
		return nil
	}

	var stderr bytes.Buffer
	code := runServe(t.Context(), []string{
		"--relay-listen", relayListen,
		"--no-stun",
		"--acme",
		"--acme-domain", "relay.example.com",
		"--acme-cache-dir", t.TempDir(),
		"--acme-http-listen", httpListen,
		"--acme-directory-url", directory,
		"--acme-eab-kid", "kid-1",
		"--acme-eab-hmac-key-file", keyFile,
	}, &stderr)
	if code != 0 || !waitCalled {
		t.Fatalf("runServe startup: got code %d, waitCalled %t; want 0, true; stderr %q", code, waitCalled, stderr.String())
	}
	want := "relay TLS: ACME for domains relay.example.com via " + directory + " (HTTP-01 on " + httpListen + "; TLS-ALPN-01 may also be attempted on " + relayListen + ")\n"
	if !strings.Contains(stderr.String(), want) {
		t.Fatalf("stderr %q lacks startup line %q", stderr.String(), want)
	}
	if strings.Contains(stderr.String(), "sixteen-byte-key") || strings.Contains(stderr.String(), "c2l4dGVlbi") {
		t.Fatalf("stderr %q leaks EAB key material", stderr.String())
	}
}

func TestRunServeDefaultACMEStartupLineUnchanged(t *testing.T) {
	relayListen := freeTCPListenAddr(t)
	httpListen := freeTCPListenAddr(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var stderr lockedBuffer
	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--relay-listen", relayListen,
			"--no-stun",
			"--acme",
			"--acme-domain", "relay.example.com",
			"--acme-cache-dir", t.TempDir(),
			"--acme-http-listen", httpListen,
		}, &stderr)
	}()
	waitForTCPListener(t, relayListen)
	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0", code)
	}
	want := "relay TLS: ACME for domains relay.example.com (HTTP-01 on " + httpListen + "; TLS-ALPN-01 may also be attempted on " + relayListen + ")\n"
	if !strings.Contains(stderr.String(), want) {
		t.Fatalf("stderr %q lacks default startup line %q", stderr.String(), want)
	}
}

func TestRunServeEmptyACMEHTTPListenDisablesHTTP01(t *testing.T) {
	relayListen := freeTCPListenAddr(t)

	// Capture the registered service names through the wait seam: a
	// successful run never prints service names to stderr, so the
	// serviceGroup itself is the only evidence of what was registered.
	// The capture is read only after errCh delivers, which orders it.
	originalWait := waitForServeServices
	t.Cleanup(func() {
		waitForServeServices = originalWait
	})
	var registered []string
	waitForServeServices = func(group *serviceGroup, ctx context.Context, shutdownTimeout time.Duration) error {
		for _, service := range group.services {
			registered = append(registered, service.name)
		}
		return originalWait(group, ctx, shutdownTimeout)
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var stderr lockedBuffer
	errCh := make(chan int, 1)
	go func() {
		errCh <- runServe(ctx, []string{
			"--relay-listen", relayListen,
			"--no-stun",
			"--acme",
			"--acme-domain", "relay.example.com",
			"--acme-cache-dir", t.TempDir(),
			"--acme-http-listen", "",
		}, &stderr)
	}()
	waitForTCPListener(t, relayListen)
	cancel()
	if code := <-errCh; code != 0 {
		t.Fatalf("runServe exit code = %d, want 0; stderr %q", code, stderr.String())
	}
	want := "relay TLS: ACME for domains relay.example.com (HTTP-01 disabled; TLS-ALPN-01 only on " + relayListen + ")\n"
	if !strings.Contains(stderr.String(), want) {
		t.Fatalf("stderr %q lacks startup line %q", stderr.String(), want)
	}
	if !slices.Contains(registered, "relay") {
		t.Fatalf("registered services = %q, want relay present", registered)
	}
	if slices.Contains(registered, "acme http") {
		t.Fatalf("registered services = %q, want no acme http service", registered)
	}
	assertTCPDialFails(t, relayListen)
}

func TestServeEmptyACMEHTTPListenRegistersNoHTTPService(t *testing.T) {
	relayListen := freeTCPListenAddr(t)
	cfg, err := parseServeFlags([]string{
		"--relay-listen", relayListen,
		"--no-stun",
		"--acme",
		"--acme-domain", "relay.example.com",
		"--acme-cache-dir", t.TempDir(),
		"--acme-http-listen", "",
	})
	if err != nil {
		t.Fatalf("parseServeFlags: %v", err)
	}
	if err := validateServeConfig(cfg); err != nil {
		t.Fatalf("validateServeConfig: %v", err)
	}
	if acmeHTTP01Enabled(cfg) {
		t.Fatal("acmeHTTP01Enabled = true for an empty --acme-http-listen, want false")
	}
	if !acmeOptionsDisableHTTP01(t, cfg) {
		t.Fatal("acmeOptionsForServe omitted WithACMEHTTP01Disabled for an empty --acme-http-listen")
	}
	cfg.acmeHTTPListen = ":80"
	if !acmeHTTP01Enabled(cfg) {
		t.Fatal("acmeHTTP01Enabled = false for the default --acme-http-listen, want true")
	}
	if acmeOptionsDisableHTTP01(t, cfg) {
		t.Fatal("acmeOptionsForServe disabled HTTP-01 for the default --acme-http-listen")
	}
}

// acmeOptionsDisableHTTP01 reports whether the serve-derived ACME options
// leave the HTTP-01 handler unbuilt.
func acmeOptionsDisableHTTP01(t *testing.T, cfg serveConfig) bool {
	t.Helper()
	opts, err := acmeOptionsForServe(cfg)
	if err != nil {
		t.Fatalf("acmeOptionsForServe: %v", err)
	}
	acmeTLS, err := relay.ACMEServerTLSConfig(cfg.acmeDomains, cfg.acmeCacheDir, opts...)
	if err != nil {
		t.Fatalf("ACMEServerTLSConfig: %v", err)
	}
	return acmeTLS.HTTPHandler == nil
}

// TestShapingFileReachesTheRelayAndSelectsTheReload pins the production glue
// between --relay-shaping-file and the relay: the option must propagate (a
// malformed file then fails ReloadShaping with the relay's sentinel) and the
// SIGHUP callback must be selected only when a file is configured.
func TestShapingFileReachesTheRelayAndSelectsTheReload(t *testing.T) {
	path := filepath.Join(t.TempDir(), "shaping.json")
	if err := os.WriteFile(path, []byte(`{"version":9}`), 0o600); err != nil {
		t.Fatal(err)
	}
	withFile, err := parseServeFlags([]string{"--tls-cert", "cert.pem", "--tls-key", "key.pem", "--relay-shaping-file", path})
	if err != nil {
		t.Fatalf("parseServeFlags: %v", err)
	}
	relayServer := relay.New(relayOptionsForServe(withFile, &tls.Config{MinVersion: tls.VersionTLS13})...)
	if err := relayServer.ReloadShaping(); !errors.Is(err, relay.ErrInvalidShapingFile) {
		t.Fatalf("ReloadShaping through serve options: got %v, want %v (the path did not reach the relay)", err, relay.ErrInvalidShapingFile)
	}
	if shapingReloadForServe(withFile, relayServer) == nil {
		t.Fatal("reload callback: got nil with a shaping file configured, want ReloadShaping")
	}

	withoutFile, err := parseServeFlags([]string{"--tls-cert", "cert.pem", "--tls-key", "key.pem"})
	if err != nil {
		t.Fatalf("parseServeFlags: %v", err)
	}
	plain := relay.New(relayOptionsForServe(withoutFile, &tls.Config{MinVersion: tls.VersionTLS13})...)
	if err := plain.ReloadShaping(); err != nil {
		t.Fatalf("ReloadShaping without a file: got %v, want nil", err)
	}
	if shapingReloadForServe(withoutFile, plain) != nil {
		t.Fatal("reload callback: got non-nil without a shaping file, want nil")
	}
	if shapingReloadForServe(withFile, nil) != nil {
		t.Fatal("reload callback: got non-nil without a relay, want nil")
	}
}
