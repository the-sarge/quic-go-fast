package main

import (
	"testing"
)

// relayOnlyGroupDiagnostics maps each relay-only flag group to the exact
// validateServeConfig diagnostic that --no-relay produces for it. Every row
// in serveFlagSpecs that declares one of these groups must be rejected
// under --no-relay with that diagnostic.
var relayOnlyGroupDiagnostics = map[serveFlagGroup]string{
	groupRelayAbuse:         "relay ephemeral abuse flags cannot be used with --no-relay",
	groupRelayAbuseTuning:   "relay ephemeral abuse flags cannot be used with --no-relay",
	groupRelayAssistShaping: "relay-assist shaping flags cannot be used with --no-relay",
}

// requireNoRelayRejectsGroup walks every serveFlagSpecs row declaring group
// and proves that parsing --no-relay together with that flag is rejected
// with wantErr. The rows themselves are the table: every flag declared in a
// relay-only group is probed, so a declared flag that the derivation or
// validation fails to reject is caught here. The row declaration is the
// authority for membership; this test does not adjudicate which group a row
// belongs in. This sweep and the name-keyed relayEnabledStandaloneOutcomes
// oracle below are complementary: a row moved into groupRelayAbuse escapes
// the --no-relay rejection (that rule keys on the backoff boolean, not the
// group bit) and turns this sweep red, and a move that empties a group trips
// the zero-row guard, while a move between groupRelayAbuseTuning and
// groupRelayAssistShaping stays green here (the two abuse-family groups
// share one diagnostic, and the swapped diagnostic still matches the moved
// declaration) and is owned by the oracle.
func requireNoRelayRejectsGroup(t *testing.T, group serveFlagGroup, wantErr string) {
	t.Helper()
	fs, _, _ := newServeFlagSet()
	rows := 0
	for _, spec := range serveFlagSpecs {
		if spec.group != group {
			continue
		}
		rows++
		args := []string{"--no-relay", "--" + spec.name}
		if spec.arg != "" {
			// Any registered default parses; the group rejection keys on
			// the flag being set, not on its value.
			args = append(args, fs.Lookup(spec.name).DefValue)
		}
		cfg, err := parseServeFlags(args)
		if err != nil {
			t.Fatalf("parseServeFlags(%v): got %v, want nil", args, err)
		}
		err = validateServeConfig(cfg)
		if err == nil {
			t.Errorf("validateServeConfig(%v): got nil, want %q", args, wantErr)
			continue
		}
		if got := err.Error(); got != wantErr {
			t.Errorf("validateServeConfig(%v): got %q, want %q", args, got, wantErr)
		}
	}
	if rows == 0 {
		t.Fatalf("serveFlagSpecs declares no row in group %d; the table would be vacuous", group)
	}
}

// TestNoRelayRejectsEveryRelayOnlyGroupedFlag iterates the serveFlagSpecs
// rows rather than a hand list: every flag declared in a relay-only group is
// rejected under --no-relay with its group's diagnostic.
func TestNoRelayRejectsEveryRelayOnlyGroupedFlag(t *testing.T) {
	for group, wantErr := range relayOnlyGroupDiagnostics {
		requireNoRelayRejectsGroup(t, group, wantErr)
	}
}

// relayAbuseTuningRequiresBackoff is the relay-enabled diagnostic produced
// when a tuning-group flag is set without --relay-ephemeral-abuse-backoff.
const relayAbuseTuningRequiresBackoff = "--relay-ephemeral-abuse-* tuning flags require --relay-ephemeral-abuse-backoff"

// relayEnabledProbe is one relay-enabled invocation of a single relay-only
// flag plus the TLS flags the relay requires. An empty value means the bare
// form for boolean flags and the registered default for valued flags; any
// other value is passed as --name=value.
type relayEnabledProbe struct {
	value   string
	wantErr string
}

// relayEnabledStandaloneOutcomes is the row-independent oracle for relay-only
// group membership: it is keyed by flag name, not by the group a
// serveFlagSpecs row declares, and pins the exact validateServeConfig outcome
// (empty wantErr: validates cleanly) of each probe. A row moved between
// groupRelayAbuseTuning and groupRelayAssistShaping keeps
// requireNoRelayRejectsGroup green, but it changes relay-enabled behavior: a
// shaping row moved into the tuning group starts rejecting with the tuning
// diagnostic, and a tuning row moved into the shaping group stops requiring
// --relay-ephemeral-abuse-backoff. Pinning the outcome per flag name turns
// either move red (#1382). The backoff row needs the explicit-false probe:
// the bare form sets the backoff boolean, which suppresses the tuning-group
// rule, so only --relay-ephemeral-abuse-backoff=false — still visited, and
// so still grouped — rejects after a move into the tuning group. Its move
// into the shaping group is behaviorally silent relay-enabled and relies on
// requireNoRelayRejectsGroup's zero-row guard.
var relayEnabledStandaloneOutcomes = map[string][]relayEnabledProbe{
	"relay-ephemeral-abuse-backoff":              {{wantErr: ""}, {value: "false", wantErr: ""}},
	"relay-ephemeral-abuse-window":               {{wantErr: relayAbuseTuningRequiresBackoff}},
	"relay-ephemeral-abuse-threshold":            {{wantErr: relayAbuseTuningRequiresBackoff}},
	"relay-ephemeral-abuse-initial-backoff":      {{wantErr: relayAbuseTuningRequiresBackoff}},
	"relay-ephemeral-abuse-max-backoff":          {{wantErr: relayAbuseTuningRequiresBackoff}},
	"relay-ephemeral-abuse-min-pair-duration":    {{wantErr: relayAbuseTuningRequiresBackoff}},
	"relay-ephemeral-abuse-max-tracked-sessions": {{wantErr: relayAbuseTuningRequiresBackoff}},
	"relay-assist-stream-rate":                   {{wantErr: ""}},
	"relay-assist-global-rate":                   {{wantErr: ""}},
	"relay-assist-egress-budget":                 {{wantErr: ""}},
	"relay-assist-egress-state":                  {{wantErr: ""}},
	"relay-shaping-file":                         {{wantErr: ""}},
}

// TestRelayEnabledStandaloneOutcomePerRelayOnlyFlag checks every relay-only
// grouped flag against the name-keyed oracle above. Both tables are swept for
// completeness in each direction — every oracle row must name a registered
// flag declared in a relay-only group, and every serveFlagSpecs row declared
// in a relay-only group must have an oracle row — so the oracle and the row
// declarations cannot drift apart silently.
func TestRelayEnabledStandaloneOutcomePerRelayOnlyFlag(t *testing.T) {
	specByName := make(map[string]serveFlagSpec, len(serveFlagSpecs))
	for _, spec := range serveFlagSpecs {
		specByName[spec.name] = spec
	}
	fs, _, _ := newServeFlagSet()
	for name, probes := range relayEnabledStandaloneOutcomes {
		spec, ok := specByName[name]
		if !ok {
			t.Errorf("relayEnabledStandaloneOutcomes names %q, which serveFlagSpecs does not declare", name)
			continue
		}
		if _, relayOnly := relayOnlyGroupDiagnostics[spec.group]; !relayOnly {
			t.Errorf("flag %q: declared group %d is not a relay-only group; remove the oracle row or restore the declaration", name, spec.group)
			continue
		}
		for _, probe := range probes {
			args := []string{"--tls-cert", "cert.pem", "--tls-key", "key.pem"}
			switch {
			case probe.value != "":
				args = append(args, "--"+name+"="+probe.value)
			case spec.arg != "":
				args = append(args, "--"+name, fs.Lookup(name).DefValue)
			default:
				args = append(args, "--"+name)
			}
			cfg, err := parseServeFlags(args)
			if err != nil {
				t.Fatalf("parseServeFlags(%v): got %v, want nil", args, err)
			}
			err = validateServeConfig(cfg)
			switch {
			case probe.wantErr == "" && err != nil:
				t.Errorf("validateServeConfig(%v): got %q, want nil", args, err.Error())
			case probe.wantErr != "" && err == nil:
				t.Errorf("validateServeConfig(%v): got nil, want %q", args, probe.wantErr)
			case probe.wantErr != "" && err.Error() != probe.wantErr:
				t.Errorf("validateServeConfig(%v): got %q, want %q", args, err.Error(), probe.wantErr)
			}
		}
	}
	for _, spec := range serveFlagSpecs {
		if _, relayOnly := relayOnlyGroupDiagnostics[spec.group]; !relayOnly {
			continue
		}
		if _, ok := relayEnabledStandaloneOutcomes[spec.name]; !ok {
			t.Errorf("serveFlagSpecs declares %q in a relay-only group but relayEnabledStandaloneOutcomes has no row for it", spec.name)
		}
	}
}
