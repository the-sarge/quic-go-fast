//go:build !unix

package main

import (
	"context"
	"io"
)

// reloadShapingOnHangup has no signal to listen for on this platform; the
// shaping file is still applied at startup.
func reloadShapingOnHangup(context.Context, func() error, io.Writer) func() {
	return func() {}
}
