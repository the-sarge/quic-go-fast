package main

import (
	"flag"
	"reflect"
	"strings"
	"testing"

	"github.com/GridSwarm/wiremux/internal/compatmanifest"
)

// These tests prove the wiremux-server CLI surface matches the declarative
// contract that the release CLI manifest freezes for v0.1.x: flag names,
// defaults, repeatability, and the machine-relevant output formats.

func TestServeFlagSetMatchesCompatibilityManifest(t *testing.T) {
	fs, _, _ := newServeFlagSet()

	got := make(map[string]compatmanifest.CLIFlag)
	fs.VisitAll(func(f *flag.Flag) {
		_, repeatable := f.Value.(*stringListFlag)
		got[f.Name] = compatmanifest.CLIFlag{Name: f.Name, Default: f.DefValue, Repeatable: repeatable}
	})

	want := make(map[string]compatmanifest.CLIFlag)
	for _, f := range compatmanifest.CLIServeFlags() {
		if _, dup := want[f.Name]; dup {
			t.Fatalf("compatmanifest declares serve flag %q twice", f.Name)
		}
		want[f.Name] = f
	}

	if !reflect.DeepEqual(got, want) {
		for name, f := range got {
			if want[name] != f {
				t.Errorf("serve flag %q: production %+v, manifest %+v", name, f, want[name])
			}
		}
		for name := range want {
			if _, ok := got[name]; !ok {
				t.Errorf("manifest declares serve flag %q that production does not register", name)
			}
		}
		t.Fatal("serve flag set drifted from the compatibility manifest")
	}
}

func TestVersionOutputFormatMatchesCompatibilityManifest(t *testing.T) {
	if got := compatmanifest.CLIVersionOutputFormat(); got != versionOutputFormat {
		t.Fatalf("compatmanifest version output format = %q, want %q", got, versionOutputFormat)
	}
}

func TestMachineOutputFormatsMatchCompatibilityManifest(t *testing.T) {
	if got := compatmanifest.CLIRelayTLSFingerprintOutputFormat(); got != relayTLSFingerprintOutputFormat {
		t.Fatalf("compatmanifest fingerprint output format = %q, want %q", got, relayTLSFingerprintOutputFormat)
	}
	if got := compatmanifest.CLISTUNRateLimitDropReportFormat(); got != stunRateLimitDropReportFormat {
		t.Fatalf("compatmanifest STUN drop-report format = %q, want %q", got, stunRateLimitDropReportFormat)
	}
}

// TestServeValidationRulesMatchCompatibilityManifest proves every validation
// rule the CLI manifest freezes still corresponds to enforced production
// behavior: each rule has one canonical offending (or, for replacement
// semantics, accepted) invocation, and the rule list and verifier set must
// stay in one-to-one correspondence.
func TestServeValidationRulesMatchCompatibilityManifest(t *testing.T) {
	tls := []string{"--tls-cert", "cert.pem", "--tls-key", "key.pem"}
	withTLS := func(args ...string) []string {
		return append(append([]string(nil), tls...), args...)
	}
	acmeArgs := func(args ...string) []string {
		return append([]string{"--acme", "--acme-domain", "relay.example.com", "--acme-cache-dir", "/var/lib/wiremux/acme"}, args...)
	}

	requireParseError := func(args ...string) func(*testing.T) {
		return func(t *testing.T) {
			if _, err := parseServeFlags(args); err == nil {
				t.Fatal("parseServeFlags accepted arguments the manifest rule rejects")
			}
		}
	}
	type branchProbe struct {
		args    []string
		wantErr string
	}
	// requireValidateBranches pins the exact production diagnostic of every
	// branch grouped under one manifest rule, so removing or rerouting any
	// branch surfaces a different (or no) message and fails the subtest. The
	// prose itself stays non-contractual; this in-package test simply
	// updates alongside intentional rewording.
	requireValidateBranches := func(probes ...branchProbe) func(*testing.T) {
		return func(t *testing.T) {
			for _, probe := range probes {
				cfg, err := parseServeFlags(probe.args)
				if err != nil {
					t.Fatalf("parseServeFlags(%v): %v", probe.args, err)
				}
				err = validateServeConfig(cfg)
				if err == nil {
					t.Fatalf("validateServeConfig(%v) accepted a configuration the manifest rule rejects", probe.args)
				}
				if err.Error() != probe.wantErr {
					t.Fatalf("validateServeConfig(%v) error = %q, want the branch's own diagnostic %q", probe.args, err, probe.wantErr)
				}
			}
		}
	}
	requireValidateError := func(args []string, wantErr string) func(*testing.T) {
		return requireValidateBranches(branchProbe{args: args, wantErr: wantErr})
	}

	verifiers := map[string]func(*testing.T){
		"at least one of relay or STUN must be enabled":                            requireValidateError([]string{"--no-relay", "--no-stun"}, "at least one of relay or STUN must be enabled"),
		"relay mode flags --ephemeral-only and --longlived-only require the relay": requireValidateError([]string{"--no-relay", "--ephemeral-only"}, "relay mode flags cannot be used with --no-relay"),
		"relay ephemeral abuse flags require the relay":                            requireValidateError([]string{"--no-relay", "--relay-ephemeral-abuse-backoff"}, "relay ephemeral abuse flags cannot be used with --no-relay"),
		"--ephemeral-only and --longlived-only are mutually exclusive":             requireValidateError([]string{"--ephemeral-only", "--longlived-only"}, "--ephemeral-only and --longlived-only are mutually exclusive"),
		"relay ephemeral abuse flags cannot be used with --longlived-only":         requireValidateError([]string{"--longlived-only", "--relay-ephemeral-abuse-backoff"}, "relay ephemeral abuse flags cannot be used with --longlived-only"),
		"relay-assist shaping flags require the relay": func(t *testing.T) {
			// Every row declared groupRelayAssistShaping is the probe set, so a
			// newly grouped flag is covered without a hand-written probe.
			requireNoRelayRejectsGroup(t, groupRelayAssistShaping, relayOnlyGroupDiagnostics[groupRelayAssistShaping])
		},
		"--relay-assist-stream-rate and --relay-assist-global-rate must be non-negative": requireValidateBranches(
			branchProbe{args: withTLS("--relay-assist-stream-rate", "-1"), wantErr: "--relay-assist-stream-rate must be non-negative"},
			branchProbe{args: withTLS("--relay-assist-global-rate", "-1"), wantErr: "--relay-assist-global-rate must be non-negative"},
		),
		"--relay-assist-egress-budget must be non-negative and requires --relay-assist-egress-state": requireValidateBranches(
			branchProbe{args: withTLS("--relay-assist-egress-budget", "-1", "--relay-assist-egress-state", "/var/lib/wiremux/egress.json"), wantErr: "--relay-assist-egress-budget must be non-negative"},
			branchProbe{args: withTLS("--relay-assist-egress-budget", "1"), wantErr: "--relay-assist-egress-budget requires --relay-assist-egress-state"},
		),
		"--relay-assist-egress-state must be an absolute path":   requireValidateError(withTLS("--relay-assist-egress-state", "egress.json"), "--relay-assist-egress-state must be an absolute path"),
		"--relay-shaping-file must be an absolute path":          requireValidateError(withTLS("--relay-shaping-file", "shaping.json"), "--relay-shaping-file must be an absolute path"),
		"--acme requires the relay":                              requireValidateError([]string{"--acme", "--no-relay"}, "--acme requires the relay"),
		"--acme cannot be combined with --tls-cert or --tls-key": requireValidateError([]string{"--acme", "--tls-cert", "cert.pem"}, "--acme cannot be combined with --tls-cert or --tls-key"),
		"--acme requires at least one --acme-domain":             requireValidateError([]string{"--acme"}, "--acme requires at least one --acme-domain"),
		"--acme requires --acme-cache-dir":                       requireValidateError([]string{"--acme", "--acme-domain", "relay.example.com"}, "--acme requires --acme-cache-dir"),
		"--acme-cache-dir must be an absolute path":              requireValidateError([]string{"--acme", "--acme-domain", "relay.example.com", "--acme-cache-dir", "relative/cache"}, "--acme-cache-dir must be an absolute path"),
		"--acme-directory-url, --acme-eab-kid, and --acme-eab-hmac-key-file require --acme": requireValidateBranches(
			branchProbe{args: withTLS("--acme-directory-url", "https://acme.example.com/directory"), wantErr: "--acme-directory-url requires --acme"},
			branchProbe{args: withTLS("--acme-eab-kid", "kid-1"), wantErr: "--acme-eab-kid requires --acme"},
			branchProbe{args: withTLS("--acme-eab-hmac-key-file", "/etc/wiremux/eab.key"), wantErr: "--acme-eab-hmac-key-file requires --acme"},
		),
		"--acme-directory-url must be an absolute https:// URL": requireValidateBranches(
			branchProbe{args: acmeArgs("--acme-directory-url", "http://acme.example.com/directory"), wantErr: "--acme-directory-url must be an absolute https:// URL"},
			branchProbe{args: acmeArgs("--acme-directory-url", "/directory"), wantErr: "--acme-directory-url must be an absolute https:// URL"},
			branchProbe{args: acmeArgs("--acme-directory-url", "https:///directory"), wantErr: "--acme-directory-url must be an absolute https:// URL"},
			branchProbe{args: acmeArgs("--acme-directory-url", "::not a url"), wantErr: "--acme-directory-url must be an absolute https:// URL"},
		),
		"--acme-eab-kid and --acme-eab-hmac-key-file must be set together": requireValidateBranches(
			branchProbe{args: acmeArgs("--acme-eab-kid", "kid-1"), wantErr: "--acme-eab-kid and --acme-eab-hmac-key-file must be set together"},
			branchProbe{args: acmeArgs("--acme-eab-hmac-key-file", "/etc/wiremux/eab.key"), wantErr: "--acme-eab-kid and --acme-eab-hmac-key-file must be set together"},
		),
		"--acme-eab-hmac-key-file must be an absolute path": requireValidateError(acmeArgs("--acme-eab-kid", "kid-1", "--acme-eab-hmac-key-file", "eab.key"), "--acme-eab-hmac-key-file must be an absolute path"),
		"an enabled relay requires TLS: both --tls-cert and --tls-key, or --acme": requireValidateBranches(
			branchProbe{args: nil, wantErr: "TLS is required: set --tls-cert and --tls-key or enable --acme"},
			branchProbe{args: []string{"--tls-cert", "cert.pem"}, wantErr: "both --tls-cert and --tls-key are required"},
			branchProbe{args: []string{"--tls-key", "key.pem"}, wantErr: "both --tls-cert and --tls-key are required"},
		),
		"--longlived-proof accepts only ed25519-keyhash or none": requireValidateError(withTLS("--longlived-proof", "bogus"), `unsupported --longlived-proof value "bogus"`),
		"--stun-rate-window, --stun-max-global-per-window, and --stun-max-source-per-window must be positive": requireValidateBranches(
			branchProbe{args: withTLS("--stun-rate-window", "0s"), wantErr: "--stun-rate-window must be positive"},
			branchProbe{args: withTLS("--stun-max-global-per-window", "0"), wantErr: "--stun-max-global-per-window must be positive"},
			branchProbe{args: withTLS("--stun-max-source-per-window", "0"), wantErr: "--stun-max-source-per-window must be positive"},
		),
		"--stun-rate-ipv6-prefix-bits must be between 1 and 128":                         requireValidateError(withTLS("--stun-rate-ipv6-prefix-bits", "129"), "--stun-rate-ipv6-prefix-bits must be between 1 and 128"),
		"--stun-rate-drop-report-interval must be non-negative":                          requireValidateError(withTLS("--stun-rate-drop-report-interval", "-1s"), "--stun-rate-drop-report-interval must be non-negative"),
		"--shutdown-timeout must be positive":                                            requireValidateError(withTLS("--shutdown-timeout", "0s"), "--shutdown-timeout must be positive"),
		"--debug-pprof-listen must be a loopback IP host:port":                           requireValidateError(withTLS("--debug-pprof-listen", "0.0.0.0:6060"), "--debug-pprof-listen must be a loopback IP host:port"),
		"--relay-ephemeral-abuse-* tuning flags require --relay-ephemeral-abuse-backoff": requireValidateError(withTLS("--relay-ephemeral-abuse-threshold", "5"), "--relay-ephemeral-abuse-* tuning flags require --relay-ephemeral-abuse-backoff"),
		"relay ephemeral abuse values must be positive and the maximum backoff must not be below the initial backoff": requireValidateBranches(
			branchProbe{args: withTLS("--relay-ephemeral-abuse-backoff", "--relay-ephemeral-abuse-window", "0s"), wantErr: "--relay-ephemeral-abuse-window must be positive"},
			branchProbe{args: withTLS("--relay-ephemeral-abuse-backoff", "--relay-ephemeral-abuse-threshold", "0"), wantErr: "--relay-ephemeral-abuse-threshold must be positive"},
			branchProbe{args: withTLS("--relay-ephemeral-abuse-backoff", "--relay-ephemeral-abuse-initial-backoff", "0s"), wantErr: "--relay-ephemeral-abuse-initial-backoff must be positive"},
			branchProbe{args: withTLS("--relay-ephemeral-abuse-backoff", "--relay-ephemeral-abuse-initial-backoff", "10s", "--relay-ephemeral-abuse-max-backoff", "1s"), wantErr: "--relay-ephemeral-abuse-max-backoff must be greater than or equal to --relay-ephemeral-abuse-initial-backoff"},
			branchProbe{args: withTLS("--relay-ephemeral-abuse-backoff", "--relay-ephemeral-abuse-min-pair-duration", "0s"), wantErr: "--relay-ephemeral-abuse-min-pair-duration must be positive"},
			branchProbe{args: withTLS("--relay-ephemeral-abuse-backoff", "--relay-ephemeral-abuse-max-tracked-sessions", "0"), wantErr: "--relay-ephemeral-abuse-max-tracked-sessions must be positive"},
		),
		"abuse tuning flags are single-valued; a later occurrence replaces an earlier one": func(t *testing.T) {
			cfg, err := parseServeFlags(withTLS("--relay-ephemeral-abuse-backoff", "--relay-ephemeral-abuse-threshold", "5", "--relay-ephemeral-abuse-threshold", "7"))
			if err != nil {
				t.Fatalf("parseServeFlags: %v", err)
			}
			if cfg.relayEphemeralAbuseConfig.EventThreshold != 7 {
				t.Fatalf("EventThreshold = %d, want the later occurrence 7", cfg.relayEphemeralAbuseConfig.EventThreshold)
			}
		},
		"serve accepts no positional arguments": requireParseError("positional"),
	}

	rules := compatmanifest.CLIValidationRules()
	seen := make(map[string]bool, len(rules))
	for _, rule := range rules {
		if seen[rule] {
			t.Fatalf("manifest declares validation rule %q twice", rule)
		}
		seen[rule] = true
		verify, ok := verifiers[rule]
		if !ok {
			t.Errorf("manifest validation rule %q has no production verifier", rule)
			continue
		}
		t.Run(rule, verify)
	}
	for rule := range verifiers {
		if !seen[rule] {
			t.Errorf("verifier %q does not correspond to any manifest validation rule", rule)
		}
	}
}

// TestCommandTreeAndExitClassesMatchCompatibilityManifest exercises the live
// dispatch for every command, help form, and exit class the CLI manifest
// freezes, including the help-precedence rule that help forms ignore
// trailing arguments.
func TestCommandTreeAndExitClassesMatchCompatibilityManifest(t *testing.T) {
	cases := []struct {
		name string
		args []string
		want int
	}{
		{name: "no command", args: nil, want: 2},
		{name: "unknown command", args: []string{"bogus"}, want: 2},
		{name: "help -h", args: []string{"-h"}, want: 0},
		{name: "help --help", args: []string{"--help"}, want: 0},
		{name: "help word", args: []string{"help"}, want: 0},
		{name: "help ignores trailing arguments", args: []string{"--help", "unexpected"}, want: 0},
		{name: "version", args: []string{"--version"}, want: 0},
		{name: "version rejects arguments", args: []string{"--version", "unexpected"}, want: 2},
		{name: "serve help -h", args: []string{"serve", "-h"}, want: 0},
		{name: "serve help --help", args: []string{"serve", "--help"}, want: 0},
		{name: "serve help ignores trailing arguments", args: []string{"serve", "--help", "unexpected"}, want: 0},
		{name: "serve unknown flag", args: []string{"serve", "--bogus-flag"}, want: 2},
		{name: "serve validation failure", args: []string{"serve"}, want: 2},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			var stdout, stderr strings.Builder
			if got := run(tc.args, &stdout, &stderr); got != tc.want {
				t.Fatalf("run(%v) = %d, want %d (stderr: %s)", tc.args, got, tc.want, stderr.String())
			}
		})
	}
}

func TestParseServeFlagsAppendsRepeatedACMEDomains(t *testing.T) {
	cfg, err := parseServeFlags([]string{
		"--acme", "--acme-cache-dir", "/var/cache/acme",
		"--acme-domain", "relay.example.com",
		"--acme-domain", "relay2.example.com",
	})
	if err != nil {
		t.Fatalf("parseServeFlags: %v", err)
	}
	want := []string{"relay.example.com", "relay2.example.com"}
	if !reflect.DeepEqual(cfg.acmeDomains, want) {
		t.Fatalf("acmeDomains = %v, want %v", cfg.acmeDomains, want)
	}
}
