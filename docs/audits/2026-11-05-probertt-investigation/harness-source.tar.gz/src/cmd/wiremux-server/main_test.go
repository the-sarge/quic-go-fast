package main

import (
	"archive/zip"
	"bytes"
	"context"
	"debug/buildinfo"
	"errors"
	"io"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime/debug"
	"strings"
	"testing"
	"time"
)

func TestVersionDevelopmentBuild(t *testing.T) {
	binary := buildServer(t, "-buildvcs=false")

	result := runServerCommand(t, binary, "--version")
	if result.err != nil {
		t.Fatalf("run wiremux-server --version: %v; stderr = %q", result.err, result.stderr)
	}
	if got, want := result.stdout, "wiremux-server version=devel revision=unknown\n"; got != want {
		t.Fatalf("wiremux-server --version stdout = %q, want %q", got, want)
	}
	if result.stderr != "" {
		t.Fatalf("wiremux-server --version stderr = %q, want empty", result.stderr)
	}
}

func TestVersionDevelopmentBuildReportsRevision(t *testing.T) {
	binary, version, revision := buildVCSStampedServer(t, false)

	result := runServerCommand(t, binary, "--version")
	if result.err != nil {
		t.Fatalf("run wiremux-server --version: %v; stderr = %q", result.err, result.stderr)
	}
	want := "wiremux-server version=" + version + " revision=" + revision + "\n"
	if got := result.stdout; got != want {
		t.Fatalf("wiremux-server --version stdout = %q, want %q", got, want)
	}
	if result.stderr != "" {
		t.Fatalf("wiremux-server --version stderr = %q, want empty", result.stderr)
	}
}

func TestVersionModifiedDevelopmentBuildReportsRevision(t *testing.T) {
	binary, version, revision := buildVCSStampedServer(t, true)

	result := runServerCommand(t, binary, "--version")
	if result.err != nil {
		t.Fatalf("run modified wiremux-server --version: %v; stderr = %q", result.err, result.stderr)
	}
	want := "wiremux-server version=" + version + " revision=" + revision + "+modified\n"
	if got := result.stdout; got != want {
		t.Fatalf("modified wiremux-server --version stdout = %q, want %q", got, want)
	}
	if result.stderr != "" {
		t.Fatalf("modified wiremux-server --version stderr = %q, want empty", result.stderr)
	}
}

func TestVersionModuleBuildReportsExactTag(t *testing.T) {
	const version = "v0.1.0"
	binary := buildVersionedServer(t, version)

	result := runServerCommand(t, binary, "--version")
	if result.err != nil {
		t.Fatalf("run versioned wiremux-server --version: %v; stderr = %q", result.err, result.stderr)
	}
	want := "wiremux-server version=" + version + " revision=unknown\n"
	if got := result.stdout; got != want {
		t.Fatalf("versioned wiremux-server --version stdout = %q, want %q", got, want)
	}
	if result.stderr != "" {
		t.Fatalf("versioned wiremux-server --version stderr = %q, want empty", result.stderr)
	}
}

func TestVersionRejectsArguments(t *testing.T) {
	binary := buildServer(t, "-buildvcs=false")

	result := runServerCommand(t, binary, "--version", "unexpected")
	var exitError *exec.ExitError
	if !errors.As(result.err, &exitError) || exitError.ExitCode() != 2 {
		t.Fatalf("wiremux-server --version unexpected exit error = %v, want exit 2", result.err)
	}
	if result.stdout != "" {
		t.Fatalf("wiremux-server --version unexpected stdout = %q, want empty", result.stdout)
	}
	if result.stderr == "" {
		t.Fatal("wiremux-server --version unexpected stderr is empty, want diagnostic")
	}
}

type serverCommandResult struct {
	stdout string
	stderr string
	err    error
}

func runServerCommand(t *testing.T, binary string, args ...string) serverCommandResult {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, binary, args...)
	var stdout bytes.Buffer
	var stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	if ctx.Err() != nil {
		t.Fatalf("run wiremux-server: %v", ctx.Err())
	}
	return serverCommandResult{stdout: stdout.String(), stderr: stderr.String(), err: err}
}

func buildServer(t *testing.T, buildArgs ...string) string {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	binary := filepath.Join(t.TempDir(), "wiremux-server")
	args := append([]string{"build"}, buildArgs...)
	args = append(args, "-o", binary, ".")
	cmd := exec.CommandContext(ctx, "go", args...)
	cmd.Env = append(os.Environ(), "GOTOOLCHAIN=local")
	if output, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build wiremux-server: %v\n%s", err, output)
	}
	return binary
}

func buildVCSStampedServer(t *testing.T, modified bool) (binary, version, revision string) {
	t.Helper()
	mainSource, err := os.ReadFile("main.go")
	if err != nil {
		t.Fatalf("read wiremux-server main source: %v", err)
	}
	moduleRoot := t.TempDir()
	commandDir := filepath.Join(moduleRoot, "cmd", "wiremux-server")
	if err := os.MkdirAll(commandDir, 0o755); err != nil {
		t.Fatalf("create VCS fixture command directory: %v", err)
	}
	files := map[string][]byte{
		"go.mod":                              []byte("module example.com/wiremux-version-fixture\n\ngo 1.26\n"),
		"fixture-state.txt":                   []byte("clean\n"),
		"cmd/wiremux-server/main.go":          mainSource,
		"cmd/wiremux-server/serve_fixture.go": []byte("package main\n\nimport (\n\t\"context\"\n\t\"io\"\n)\n\nvar serveFlagsUsage string\n\nfunc runServe(context.Context, []string, io.Writer) int { return 0 }\n"),
	}
	for name, data := range files {
		if err := os.WriteFile(filepath.Join(moduleRoot, filepath.FromSlash(name)), data, 0o600); err != nil {
			t.Fatalf("write VCS fixture %s: %v", name, err)
		}
	}
	runFixtureGit(t, moduleRoot, "init", "--quiet")
	runFixtureGit(t, moduleRoot, "add", ".")
	runFixtureGit(t, moduleRoot, "commit", "--quiet", "-m", "fixture")
	revision = strings.TrimSpace(runFixtureGit(t, moduleRoot, "rev-parse", "HEAD"))
	if modified {
		if err := os.WriteFile(filepath.Join(moduleRoot, "fixture-state.txt"), []byte("modified\n"), 0o600); err != nil {
			t.Fatalf("modify VCS fixture: %v", err)
		}
	}

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	binary = filepath.Join(t.TempDir(), "wiremux-server")
	cmd := exec.CommandContext(ctx, "go", "build", "-buildvcs=true", "-o", binary, "./cmd/wiremux-server")
	cmd.Dir = moduleRoot
	cmd.Env = append(os.Environ(), "GOTOOLCHAIN=local")
	if output, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build VCS-stamped wiremux-server: %v\n%s", err, output)
	}
	binaryInfo, err := buildinfo.ReadFile(binary)
	if err != nil {
		t.Fatalf("read VCS-stamped wiremux-server build info: %v", err)
	}
	if got := buildSetting(binaryInfo, "vcs.revision"); got != revision {
		t.Fatalf("VCS-stamped revision setting = %q, want %q", got, revision)
	}
	wantModified := "false"
	if modified {
		wantModified = "true"
	}
	if got := buildSetting(binaryInfo, "vcs.modified"); got != wantModified {
		t.Fatalf("VCS-stamped modified setting = %q, want %q", got, wantModified)
	}
	version = binaryInfo.Main.Version
	if version == "" || version == "(devel)" {
		version = "devel"
	}
	return binary, version, revision
}

func runFixtureGit(t *testing.T, dir string, args ...string) string {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, "git", args...)
	cmd.Dir = dir
	cmd.Env = append(os.Environ(),
		"GIT_CONFIG_GLOBAL="+os.DevNull,
		"GIT_CONFIG_NOSYSTEM=1",
		"GIT_AUTHOR_NAME=wiremux test",
		"GIT_AUTHOR_EMAIL=wiremux-test@example.com",
		"GIT_AUTHOR_DATE=2026-01-01T00:00:00Z",
		"GIT_COMMITTER_NAME=wiremux test",
		"GIT_COMMITTER_EMAIL=wiremux-test@example.com",
		"GIT_COMMITTER_DATE=2026-01-01T00:00:00Z",
	)
	output, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("git %s: %v\n%s", strings.Join(args, " "), err, output)
	}
	return string(output)
}

func buildSetting(info *debug.BuildInfo, key string) string {
	for _, setting := range info.Settings {
		if setting.Key == key {
			return setting.Value
		}
	}
	return ""
}

func buildVersionedServer(t *testing.T, version string) string {
	t.Helper()
	const modulePath = "github.com/GridSwarm/wiremux"
	mainSource, err := os.ReadFile("main.go")
	if err != nil {
		t.Fatalf("read wiremux-server main source: %v", err)
	}
	moduleFile := []byte("module " + modulePath + "\n\ngo 1.26\n")
	stubSource := []byte("package main\n\nimport (\n\t\"context\"\n\t\"io\"\n)\n\nvar serveFlagsUsage string\n\nfunc runServe(context.Context, []string, io.Writer) int { return 0 }\n")

	proxyRoot := t.TempDir()
	versionDir := filepath.Join(proxyRoot, "github.com", "!grid!swarm", "wiremux", "@v")
	if err := os.MkdirAll(versionDir, 0o755); err != nil {
		t.Fatalf("create module proxy: %v", err)
	}
	if err := os.WriteFile(filepath.Join(versionDir, version+".mod"), moduleFile, 0o600); err != nil {
		t.Fatalf("write module proxy mod file: %v", err)
	}
	if err := os.WriteFile(filepath.Join(versionDir, "list"), []byte(version+"\n"), 0o600); err != nil {
		t.Fatalf("write module proxy version list: %v", err)
	}
	info := []byte("{\"Version\":\"" + version + "\",\"Time\":\"2026-01-01T00:00:00Z\"}\n")
	if err := os.WriteFile(filepath.Join(versionDir, version+".info"), info, 0o600); err != nil {
		t.Fatalf("write module proxy info file: %v", err)
	}

	zipFile, err := os.Create(filepath.Join(versionDir, version+".zip"))
	if err != nil {
		t.Fatalf("create module proxy zip: %v", err)
	}
	archive := zip.NewWriter(zipFile)
	prefix := modulePath + "@" + version + "/"
	files := []struct {
		name string
		data []byte
	}{
		{name: "go.mod", data: moduleFile},
		{name: "cmd/wiremux-server/main.go", data: mainSource},
		{name: "cmd/wiremux-server/serve_stub.go", data: stubSource},
	}
	for _, file := range files {
		writer, createErr := archive.Create(prefix + file.name)
		if createErr != nil {
			t.Fatalf("create %s in module proxy zip: %v", file.name, createErr)
		}
		if _, writeErr := writer.Write(file.data); writeErr != nil {
			t.Fatalf("write %s in module proxy zip: %v", file.name, writeErr)
		}
	}
	if err := archive.Close(); err != nil {
		t.Fatalf("close module proxy zip: %v", err)
	}
	if err := zipFile.Close(); err != nil {
		t.Fatalf("close module proxy zip file: %v", err)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	binDir := t.TempDir()
	commandDir := t.TempDir()
	proxyURL := (&url.URL{Scheme: "file", Path: proxyRoot}).String()
	// #nosec G204 -- the module path and version are test constants resolved only through the isolated local proxy.
	cmd := exec.CommandContext(ctx, "go", "install", modulePath+"/cmd/wiremux-server@"+version)
	cmd.Dir = commandDir
	cmd.Env = append(os.Environ(),
		"GOBIN="+binDir,
		"GOENV=off",
		"GOMODCACHE="+t.TempDir(),
		"GONOPROXY=",
		"GONOSUMDB="+modulePath,
		"GOFLAGS=-modcacherw",
		"GOPRIVATE=",
		"GOPROXY="+proxyURL,
		"GOTOOLCHAIN=local",
		"GOWORK=off",
	)
	if output, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build versioned wiremux-server: %v\n%s", err, output)
	}
	return filepath.Join(binDir, "wiremux-server")
}

func TestRunPrintsUsageWithoutArguments(t *testing.T) {
	var stderr bytes.Buffer
	code := run(nil, io.Discard, &stderr)
	if code != 2 {
		t.Fatalf("run without args code = %d, want 2", code)
	}
	if stderr.Len() == 0 {
		t.Fatal("expected usage text on stderr")
	}
	if !strings.Contains(stderr.String(), "--acme") {
		t.Fatalf("usage text %q does not mention --acme", stderr.String())
	}
	if !strings.Contains(stderr.String(), "wiremux-server --version") {
		t.Fatalf("usage text %q does not mention --version", stderr.String())
	}
}
