package main

import (
	"context"
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/measurement"
)

func TestRemoteHeadlineSupportsDatagramAndStreamResults(t *testing.T) {
	r := measurement.Result{RunID: "run", Status: "complete", Summary: measurement.Summary{WindowGoodputBPS: 1_000_000}, Remote: &measurement.RemoteReceipt{WindowQualified: false}}
	var out strings.Builder
	writeRemoteResult(&out, r, "result-dir")
	if !strings.Contains(out.String(), "1.000 Mbps") || !strings.Contains(out.String(), "qualified=false") {
		t.Fatalf("Datagram headline lost throughput or qualification: %s", out.String())
	}
	r.Stream = &measurement.StreamSummary{WindowGoodputBPS: 2_000_000}
	out.Reset()
	writeRemoteResult(&out, r, "result-dir")
	if !strings.Contains(out.String(), "2.000 Mbps") {
		t.Fatalf("stream headline changed interpretation: %s", out.String())
	}
}

func TestRemoteWorkerDeadlineProcess(t *testing.T) {
	if os.Getenv("WIREMUX_REMOTE_DEADLINE_TEST") != "1" {
		return
	}
	if err := runRemoteWorker(context.Background(), 30*time.Millisecond); err != nil {
		os.Exit(7)
	}
	os.Exit(0)
}

func TestRemoteWorkerDeadlineTerminatesBlockedBootstrap(t *testing.T) {
	binary, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(t.Context(), 3*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, binary, "-test.run=^TestRemoteWorkerDeadlineProcess$")
	cmd.Env = append(os.Environ(), "WIREMUX_REMOTE_DEADLINE_TEST=1")
	in, err := cmd.StdinPipe()
	if err != nil {
		t.Fatal(err)
	}
	defer in.Close()
	if err = cmd.Run(); err == nil || cmd.ProcessState.ExitCode() != 7 || ctx.Err() != nil {
		t.Fatalf("remote watchdog: got %v, state=%v, context=%v; want process exit 7 before external deadline", err, cmd.ProcessState, ctx.Err())
	}
}

func TestLocalDatagramCLIProducesVerifiedFiniteArtifacts(t *testing.T) {
	root := t.TempDir()
	binary := filepath.Join(root, "wiremux-measure.exe")
	buildCtx, buildCancel := context.WithTimeout(t.Context(), 90*time.Second)
	defer buildCancel()
	build := exec.CommandContext(buildCtx, "go", "build", "-o", binary, ".")
	build.Env = append(os.Environ(), "GOTOOLCHAIN=local")
	if out, err := build.CombinedOutput(); err != nil {
		t.Fatalf("build CLI: %v: %s", err, out)
	}
	t.Run("remote capture stream", func(t *testing.T) {
		source := filepath.Join(root, "capture.pprof")
		data := "raw\x00profile\xffbytes"
		if err := os.WriteFile(source, []byte(data), 0o600); err != nil {
			t.Fatal(err)
		}
		ctx, cancel := context.WithTimeout(t.Context(), 5*time.Second)
		defer cancel()
		cmd := exec.CommandContext(ctx, binary, "-remote-capture", source)
		if out, err := cmd.Output(); err != nil || string(out) != data {
			t.Fatalf("capture stream: got %q, %v, want exact raw bytes", out, err)
		}
		// #nosec G204 -- both the built executable and missing path belong to this isolated test fixture.
		cmd = exec.CommandContext(ctx, binary, "-remote-capture", filepath.Join(root, "missing"))
		if out, err := cmd.Output(); err == nil || len(out) != 0 {
			t.Fatalf("missing capture: got %q, %v, want failure without capture bytes", out, err)
		}
	})
	c := measurement.DefaultDatagramConfig()
	c.Layer, c.Profile = "native", "none"
	c.RateBPS = 1_000_000
	c.WarmupMS, c.MeasurementMS, c.DrainMS = 10, 100, 100
	config, err := json.Marshal(c)
	if err != nil {
		t.Fatal(err)
	}
	configPath := filepath.Join(root, "config.json")
	if err := os.WriteFile(configPath, config, 0o600); err != nil {
		t.Fatal(err)
	}
	output := filepath.Join(root, "result")
	ctx, cancel := context.WithTimeout(t.Context(), 20*time.Second)
	defer cancel()
	command := exec.CommandContext(ctx, binary, "-config", configPath, "-output", output)
	if out, err := command.CombinedOutput(); err != nil {
		t.Fatalf("local CLI: %v: %s", err, out)
	}
	data, err := os.ReadFile(filepath.Join(output, "result.json"))
	if err != nil {
		t.Fatal(err)
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(data, &fields); err != nil {
		t.Fatal(err)
	}
	qualification, exists := fields["local_window_alignment_qualified"]
	if !exists || (string(qualification) != "true" && string(qualification) != "false") {
		t.Fatal("local CLI omitted its Boolean alignment qualification field")
	}
	var result measurement.Result
	if err := json.Unmarshal(data, &result); err != nil {
		t.Fatal(err)
	}
	if result.Version != 6 || result.Status != "complete" || result.Stream != nil || result.Remote != nil || result.Summary.Scheduled != 11 || len(result.Peers) != 2 {
		t.Fatalf("local Datagram result: %+v", result)
	}
	for _, peer := range result.Peers {
		if peer.Datagram == nil || len(peer.Captures) != 1 {
			t.Fatalf("missing peer evidence: %+v", peer)
		}
		if _, err := measurement.ReadPackedLedger(output, result.RunID, peer.Role, 11, peer.Captures[0]); err != nil {
			t.Fatal(err)
		}
	}
}
