package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestDirectLauncherHelper(t *testing.T) {
	if os.Getenv("WIREMUX_DIRECT_LAUNCHER_HELPER") != "1" {
		return
	}
	if os.Getenv("WIREMUX_DIRECT_CONTROLLER_HELPER") == "1" {
		input, err := directLauncherInput()
		if err != nil {
			t.Fatal(err)
		}
		runDirectLauncherFixture(t, "early-exit", input, "", nil)
		return
	}
	os.Exit(directLauncherHelper())
}

func directLauncherHelper() int {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	mode := os.Getenv("WIREMUX_DIRECT_LAUNCHER_MODE")
	if mode == "before-connect-exit" {
		return 2
	}
	if mode == "before-connect-cancel" {
		fmt.Fprintln(os.Stderr, "waiting")
		<-ctx.Done()
		return 2
	}
	var bootstrap io.Reader = os.Stdin
	if mode == "wrong-token" {
		data, err := io.ReadAll(os.Stdin)
		if err != nil {
			return 2
		}
		var config directWorkerConfig
		if json.Unmarshal(data, &config) != nil {
			return 2
		}
		config.Token = strings.Repeat("0", 64)
		data, err = json.Marshal(config)
		if err != nil {
			return 2
		}
		bootstrap = bytes.NewReader(data)
	}
	conn, err := openDirectWorker(ctx, bootstrap)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer conn.Close()
	if mode == "early-exit" {
		return 0
	}
	if _, err = conn.Write([]byte("ready:")); err != nil {
		return 3
	}
	data, err := io.ReadAll(conn)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 2
	}
	if _, err = conn.Write(append([]byte("partial-result:"), data...)); err != nil {
		return 3
	}
	return 0
}

func TestDirectLauncherHalfCloseRetainsWorkerResponse(t *testing.T) {
	input, writer, err := os.Pipe()
	if err != nil {
		t.Fatal(err)
	}
	defer writer.Close()
	if _, err = writer.WriteString("bootstrap"); err != nil {
		t.Fatal(err)
	}
	runDirectLauncherFixture(t, "half-close", input, "ready:partial-result:bootstrap", func() { _ = writer.Close() })
}

func TestDirectLauncherEarlyExitUnblocksOpenInput(t *testing.T) {
	input, writer, err := os.Pipe()
	if err != nil {
		t.Fatal(err)
	}
	defer input.Close()
	defer writer.Close()
	runDirectLauncherFixture(t, "early-exit", input, "", nil)
}

func runDirectLauncherFixture(t *testing.T, mode string, input io.ReadCloser, want string, onOutput func()) {
	t.Helper()
	config := filepath.Join(t.TempDir(), "ssh-config")
	if err := os.WriteFile(config, nil, 0o600); err != nil {
		t.Fatal(err)
	}
	ready := directSession{RunID: "owned-test", SessionRunID: "owned-test", Status: "session-access-ready", Deadline: float64(time.Now().Unix() + 120), SSHConfig: config}
	binary, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	newCommand := func(ctx context.Context, _ string, _ ...string) *exec.Cmd {
		// #nosec G204 -- the test invokes its own executable with a fixed helper selector.
		cmd := exec.CommandContext(ctx, binary, "-test.run=^TestDirectLauncherHelper$")
		cmd.Env = append(os.Environ(), "WIREMUX_DIRECT_LAUNCHER_HELPER=1", "WIREMUX_DIRECT_CONTROLLER_HELPER=0", "WIREMUX_DIRECT_LAUNCHER_MODE="+mode)
		return cmd
	}
	ctx, cancel := context.WithTimeout(t.Context(), 4*time.Second)
	defer cancel()
	var output, stderr bytes.Buffer
	err = launchDirectControl(ctx, ready, "127.0.0.1", directFixtureArguments(), input, directFixtureWriter{&output, onOutput}, &stderr, newCommand)
	if mode == "input-error" {
		if !errors.Is(err, errDirectFixtureInput) {
			t.Fatalf("input failure: got %v, want %v", err, errDirectFixtureInput)
		}
	} else if err != nil {
		t.Fatalf("launcher: %v; stderr: %s", err, stderr.String())
	}
	// Input cancellation races with the pump closing the TLS write half. The
	// worker may send its response before connection cleanup wins; retaining
	// the input error above is the obligation, not suppressing that response.
	if mode == "input-error" && output.String() == want+"partial-result:" {
		return
	}
	if output.String() != want {
		t.Fatalf("got %q, want %q", output.String(), want)
	}
}

func directFixtureArguments() []string {
	return []string{"-T", "-oBatchMode=yes", "-oStrictHostKeyChecking=yes", "-oConnectTimeout=10", "-oServerAliveInterval=2", "-oServerAliveCountMax=2", "wiremux-session", "C:/worker.exe", "-remote-worker", "-worker-timeout-ms", "5000"}
}

type directFixtureWriter struct {
	io.Writer
	notify func()
}

func (w directFixtureWriter) Write(p []byte) (int, error) {
	n, e := w.Writer.Write(p)
	if w.notify != nil {
		w.notify()
	}
	return n, e
}

func TestDirectLauncherInheritedInputEarlyExit(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("direct launcher requires a Unix controller")
	}
	binary, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(t.Context(), 3*time.Second)
	defer cancel()
	// #nosec G204 -- invoke this test executable with the fixed helper selector.
	cmd := exec.CommandContext(ctx, binary, "-test.run=^TestDirectLauncherHelper$")
	cmd.Env = append(os.Environ(), "WIREMUX_DIRECT_LAUNCHER_HELPER=1", "WIREMUX_DIRECT_CONTROLLER_HELPER=1")
	input, err := cmd.StdinPipe()
	if err != nil {
		t.Fatal(err)
	}
	defer input.Close()
	var output bytes.Buffer
	cmd.Stdout = &output
	cmd.Stderr = &output
	if err = cmd.Run(); err != nil {
		t.Fatalf("launcher failed with parent input held open: %v: %s", err, output.String())
	}
	if ctx.Err() != nil {
		t.Fatal("launcher did not exit before parent deadline")
	}
}

func TestDirectLauncherRejectsInvalidArguments(t *testing.T) {
	cases := [][]string{
		{"-J", "wiremux-session", "other-host", "worker", "-remote-worker"},
		append(directFixtureArguments(), "extra"),
	}
	for _, index := range []int{6, 7, 9, 10} {
		args := directFixtureArguments()
		args[index] = "bad value"
		cases = append(cases, args)
	}
	for _, args := range cases {
		if _, _, err := directWorkerArguments(args); err == nil {
			t.Fatalf("accepted invalid arguments: %v", args)
		}
	}
}

func TestDirectLauncherBootstrapFailureJoinsChild(t *testing.T) {
	for _, mode := range []string{"before-connect-exit", "before-connect-cancel", "wrong-token"} {
		t.Run(mode, func(t *testing.T) {
			input, writer, err := os.Pipe()
			if err != nil {
				t.Fatal(err)
			}
			defer writer.Close()
			config := filepath.Join(t.TempDir(), "ssh")
			if err = os.WriteFile(config, nil, 0o600); err != nil {
				t.Fatal(err)
			}
			ready := directSession{RunID: "owned", SessionRunID: "owned", Status: "session-access-ready", Deadline: float64(time.Now().Unix() + 120), SSHConfig: config}
			binary, err := os.Executable()
			if err != nil {
				t.Fatal(err)
			}
			var child *exec.Cmd
			factory := func(ctx context.Context, _ string, _ ...string) *exec.Cmd {
				// #nosec G204 -- invoke this test executable with the fixed helper selector.
				child = exec.CommandContext(ctx, binary, "-test.run=^TestDirectLauncherHelper$")
				child.Env = append(os.Environ(), "WIREMUX_DIRECT_LAUNCHER_HELPER=1", "WIREMUX_DIRECT_CONTROLLER_HELPER=0", "WIREMUX_DIRECT_LAUNCHER_MODE="+mode)
				return child
			}
			var stderr, output bytes.Buffer
			start := time.Now()
			err = launchDirectControl(t.Context(), ready, "127.0.0.1", directFixtureArguments(), input, &output, directFixtureWriter{&stderr, func() {
				if mode == "before-connect-cancel" {
					_ = writer.Close()
				}
			}}, factory)
			if err == nil || time.Since(start) > 2*time.Second {
				t.Fatalf("failure not prompt: %s: %v", time.Since(start), err)
			}
			if child == nil || child.ProcessState == nil {
				t.Fatal("child was not joined")
			}
			if mode == "before-connect-exit" {
				var exit *exec.ExitError
				if !errors.As(err, &exit) || exit.ExitCode() != 2 {
					t.Fatalf("lost child exit status: %v", err)
				}
			}
			if mode == "wrong-token" && !strings.Contains(err.Error(), "token mismatch") {
				t.Fatalf("wrong token not rejected: %v", err)
			}
			if output.Len() != 0 {
				t.Fatal("unauthenticated output forwarded")
			}
		})
	}
}

func TestDirectLauncherRejectsExpiredOrShortSession(t *testing.T) {
	config := filepath.Join(t.TempDir(), "ssh")
	if err := os.WriteFile(config, nil, 0o600); err != nil {
		t.Fatal(err)
	}
	for _, seconds := range []int64{-1, 30, 35} {
		ready := directSession{RunID: "owned", SessionRunID: "owned", Status: "session-access-ready", Deadline: float64(time.Now().Unix() + seconds), SSHConfig: config}
		args := directFixtureArguments()
		args[10] = "25000"
		factory := func(context.Context, string, ...string) *exec.Cmd {
			t.Fatal("invalid session started a child")
			return nil
		}
		if err := launchDirectControl(t.Context(), ready, "127.0.0.1", args, io.NopCloser(strings.NewReader("")), io.Discard, io.Discard, factory); err == nil {
			t.Fatal("invalid session accepted")
		}
	}
}

var errDirectFixtureInput = errors.New("injected controller input failure")

type directFailingInput struct {
	ready chan struct{}
	once  sync.Once
}

func (r *directFailingInput) Read([]byte) (int, error) {
	<-r.ready
	return 0, errDirectFixtureInput
}

func (r *directFailingInput) Close() error {
	r.once.Do(func() { close(r.ready) })
	return nil
}

func TestDirectLauncherRetainsInputReadFailure(t *testing.T) {
	input := &directFailingInput{ready: make(chan struct{})}
	runDirectLauncherFixture(t, "input-error", input, "ready:", func() { _ = input.Close() })
}

type directFailingWriter struct {
	writeErr, closeErr error
	closing            *atomic.Bool
}

func (w directFailingWriter) Write(p []byte) (int, error) {
	if w.closing != nil {
		w.closing.Store(true)
	}
	if w.writeErr != nil {
		return 0, w.writeErr
	}
	return len(p), nil
}

func (w directFailingWriter) CloseWrite() error {
	if w.closing != nil {
		w.closing.Store(true)
	}
	return w.closeErr
}

func TestDirectInputRetainsFailureConcurrentWithCleanup(t *testing.T) {
	failure := net.ErrClosed
	for _, halfClose := range []bool{false, true} {
		chunks := make(chan []byte, 1)
		var closing atomic.Bool
		writer := directFailingWriter{closing: &closing}
		if halfClose {
			writer.closeErr = failure
		} else {
			chunks <- []byte("data")
			writer.writeErr = failure
		}
		close(chunks)
		if err := copyDirectInput(chunks, writer, &closing); !errors.Is(err, failure) {
			t.Fatalf("half-close=%t: failure lost: %v", halfClose, err)
		}
	}
}
