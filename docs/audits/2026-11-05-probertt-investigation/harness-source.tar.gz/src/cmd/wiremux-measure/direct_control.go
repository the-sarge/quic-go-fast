package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/netip"
	"time"
)

// directWorkerConfig arrives only through the authenticated launcher stdin.
// The random token authenticates the worker to the pinned controller listener.
type directWorkerConfig struct {
	Address string
	Pin     string
	Token   string
}

func openDirectWorker(ctx context.Context, input io.Reader) (*tls.Conn, error) {
	var c directWorkerConfig
	data, err := io.ReadAll(io.LimitReader(input, 4097))
	if err != nil || len(data) > 4096 {
		return nil, fmt.Errorf("wiremux-measure: invalid direct control bootstrap size")
	}
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&c); err != nil {
		return nil, fmt.Errorf("wiremux-measure: invalid direct control bootstrap")
	}
	if decoder.Decode(new(any)) != io.EOF {
		return nil, fmt.Errorf("wiremux-measure: trailing direct control bootstrap data")
	}
	address, err := netip.ParseAddrPort(c.Address)
	pin, pinErr := hex.DecodeString(c.Pin)
	token, tokenErr := hex.DecodeString(c.Token)
	if err != nil || !address.Addr().IsValid() || address.Addr().IsUnspecified() || address.Addr().IsMulticast() || address.Port() == 0 || pinErr != nil || len(pin) != 32 || tokenErr != nil || len(token) != 32 {
		return nil, fmt.Errorf("wiremux-measure: invalid direct control coordinates or authentication")
	}
	dialCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	dialer := tls.Dialer{Config: &tls.Config{
		MinVersion: tls.VersionTLS13,
		// The private, ephemeral certificate is authenticated by its full SHA-256
		// pin delivered through SSH, rather than a public CA or host name.
		InsecureSkipVerify: true, // #nosec G402 -- VerifyConnection requires the authenticated exact certificate pin.
		VerifyConnection: func(state tls.ConnectionState) error {
			if len(state.PeerCertificates) != 1 {
				return fmt.Errorf("wiremux-measure: direct control certificate count")
			}
			sum := sha256.Sum256(state.PeerCertificates[0].Raw)
			if subtle.ConstantTimeCompare(sum[:], pin) != 1 {
				return fmt.Errorf("wiremux-measure: direct control certificate pin mismatch")
			}
			return nil
		},
	}}
	raw, err := dialer.DialContext(dialCtx, "tcp", address.String())
	if err != nil {
		return nil, fmt.Errorf("wiremux-measure: connect direct control: %w", err)
	}
	conn, ok := raw.(*tls.Conn)
	if !ok {
		_ = raw.Close()
		return nil, fmt.Errorf("wiremux-measure: direct control did not establish TLS")
	}
	if deadline, ok := ctx.Deadline(); ok {
		if err = conn.SetDeadline(deadline); err != nil {
			_ = conn.Close()
			return nil, err
		}
	}
	if err = json.NewEncoder(conn).Encode(struct {
		Token string `json:"token"`
	}{c.Token}); err != nil {
		_ = conn.Close()
		return nil, fmt.Errorf("wiremux-measure: authenticate direct control: %w", err)
	}
	return conn, nil
}
