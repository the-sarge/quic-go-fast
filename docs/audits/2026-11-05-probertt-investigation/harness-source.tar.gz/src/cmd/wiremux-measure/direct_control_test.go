package main

import (
	"context"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/hex"
	"encoding/json"
	"math/big"
	"net"
	"strings"
	"testing"
	"time"
)

func TestDirectWorkerRejectsInvalidBootstrapBeforeDial(t *testing.T) {
	validPrefix := `{"Address":"127.0.0.1:1","Pin":"` + strings.Repeat("a", 64) + `","Token":"` + strings.Repeat("b", 64) + `"}`
	for _, input := range []string{validPrefix + `{}`, validPrefix + "junk", validPrefix + strings.Repeat(" ", 4097), `{}`, `{"Address":"example.com:443","Pin":"` + strings.Repeat("a", 64) + `","Token":"` + strings.Repeat("b", 64) + `"}`, strings.Repeat(" ", 4097)} {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		conn, err := openDirectWorker(ctx, strings.NewReader(input))
		cancel()
		if conn != nil {
			_ = conn.Close()
			t.Fatal("invalid bootstrap opened a connection")
		}
		if err == nil {
			t.Fatal("invalid bootstrap was accepted")
		}
	}
}

func TestDirectWorkerPinsCertificateAndAuthenticates(t *testing.T) {
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	template := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "diagnostic"}, NotBefore: time.Now().Add(-time.Minute), NotAfter: time.Now().Add(time.Hour), KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
	der, err := x509.CreateCertificate(rand.Reader, template, template, &key.PublicKey, key)
	if err != nil {
		t.Fatal(err)
	}
	certificate := tls.Certificate{Certificate: [][]byte{der}, PrivateKey: key}
	sum := sha256.Sum256(der)
	for _, valid := range []bool{true, false} {
		listener, err := net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			t.Fatal(err)
		}
		got := make(chan string, 1)
		go func() {
			raw, e := listener.Accept()
			if e != nil {
				got <- ""
				return
			}
			defer raw.Close()
			_ = raw.SetDeadline(time.Now().Add(2 * time.Second))
			conn := tls.Server(raw, &tls.Config{MinVersion: tls.VersionTLS13, Certificates: []tls.Certificate{certificate}})
			var auth struct {
				Token string `json:"token"`
			}
			if json.NewDecoder(conn).Decode(&auth) != nil {
				got <- ""
				return
			}
			got <- auth.Token
		}()
		pin := hex.EncodeToString(sum[:])
		if !valid {
			pin = strings.Repeat("0", 64)
		}
		token := strings.Repeat("b", 64)
		input, err := json.Marshal(directWorkerConfig{Address: listener.Addr().String(), Pin: pin, Token: token})
		if err != nil {
			t.Fatal(err)
		}
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		conn, err := openDirectWorker(ctx, strings.NewReader(string(input)))
		if conn != nil {
			_ = conn.Close()
		}
		cancel()
		_ = listener.Close()
		received := <-got
		if valid && (err != nil || received != token) {
			t.Fatalf("authenticated connection failed: %v", err)
		}
		if !valid && (err == nil || received != "") {
			t.Fatal("wrong certificate pin disclosed authentication")
		}
	}
}
