//go:build unix

package main

import (
	"fmt"
	"os"
	"syscall"
)

func directLauncherInput() (*os.File, error) {
	// A child inherits blocking stdin. Reopen an owned duplicate after setting
	// nonblocking mode so Go registers it with the poller and Close wakes Read.
	fd, err := syscall.Dup(int(os.Stdin.Fd()))
	if err != nil {
		return nil, err
	}
	if err = syscall.SetNonblock(fd, true); err != nil {
		_ = syscall.Close(fd)
		return nil, err
	}
	input := os.NewFile(uintptr(fd), "direct-controller-input")
	if input == nil {
		_ = syscall.Close(fd)
		return nil, fmt.Errorf("wiremux-measure: invalid controller input")
	}
	return input, nil
}
