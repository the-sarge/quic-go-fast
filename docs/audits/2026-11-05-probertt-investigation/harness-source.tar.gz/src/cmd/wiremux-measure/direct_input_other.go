//go:build !unix

package main

import (
	"fmt"
	"os"
)

func directLauncherInput() (*os.File, error) {
	return nil, fmt.Errorf("wiremux-measure: direct control launcher requires a Unix controller")
}
