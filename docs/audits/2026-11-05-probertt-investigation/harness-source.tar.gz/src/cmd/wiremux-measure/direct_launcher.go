package main

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/netip"
	"os"
	"os/exec"
	"slices"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

type directSession struct {
	RunID        string  `json:"run_id"`
	SessionRunID string  `json:"session_run_id"`
	Status       string  `json:"status"`
	Deadline     float64 `json:"session_deadline_unix"`
	SSHConfig    string  `json:"ssh_config"`
}

type directCommandFactory func(context.Context, string, ...string) *exec.Cmd

func runDirectLauncher(ctx context.Context, readyPath, bind string, args []string) error {
	f, err := os.Open(readyPath)
	if err != nil {
		return err
	}
	defer f.Close()
	var ready directSession
	if err = json.NewDecoder(io.LimitReader(f, 65536)).Decode(&ready); err != nil {
		return fmt.Errorf("wiremux-measure: invalid session coordinates")
	}
	input, err := directLauncherInput()
	if err != nil {
		return err
	}
	defer input.Close()
	return launchDirectControl(ctx, ready, bind, args, input, os.Stdout, os.Stderr, exec.CommandContext)
}

func launchDirectControl(parent context.Context, ready directSession, bind string, args []string, input io.ReadCloser, output, errorOutput io.Writer, newCommand directCommandFactory) (result error) {
	ip, err := netip.ParseAddr(bind)
	if err != nil || !ip.Is4() || ip.IsUnspecified() || ip.IsMulticast() || ready.Status != "session-access-ready" || ready.RunID == "" || ready.RunID != ready.SessionRunID || ready.Deadline <= float64(time.Now().Unix()+30) {
		return fmt.Errorf("wiremux-measure: fresh session and explicit controller IPv4 required")
	}
	if _, err = os.Stat(ready.SSHConfig); err != nil {
		return fmt.Errorf("wiremux-measure: live SSH configuration missing")
	}
	workerTimeout, worker, err := directWorkerArguments(args)
	if err != nil {
		return err
	}
	budget := 182 * time.Second
	if worker {
		// Allow SSH startup and retain the worker's own process deadline first.
		budget = workerTimeout + 17*time.Second
		if time.Until(time.Unix(0, int64(ready.Deadline*1e9))) <= budget {
			return fmt.Errorf("wiremux-measure: session cannot contain worker deadline and startup allowance")
		}
	}
	ctx, cancel := context.WithTimeout(parent, min(budget, time.Until(time.Unix(0, int64(ready.Deadline*1e9)))))
	defer cancel()
	if !worker {
		cmd := newCommand(ctx, "/usr/bin/ssh", append([]string{"-F", ready.SSHConfig}, args...)...)
		cmd.Stdin = input
		cmd.Stdout = output
		cmd.Stderr = errorOutput
		cmd.WaitDelay = 2 * time.Second
		return cmd.Run()
	}
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return err
	}
	serial, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	if err != nil {
		return err
	}
	template := &x509.Certificate{SerialNumber: serial, NotBefore: time.Now().Add(-time.Minute), NotAfter: time.Now().Add(time.Hour), KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
	der, err := x509.CreateCertificate(rand.Reader, template, template, &key.PublicKey, key)
	if err != nil {
		return err
	}
	token := make([]byte, 32)
	if _, err = rand.Read(token); err != nil {
		return err
	}
	pin := sha256.Sum256(der)
	listener, err := net.ListenTCP("tcp4", &net.TCPAddr{IP: net.IP(ip.AsSlice())})
	if err != nil {
		return err
	}
	defer listener.Close()
	stopAccept := context.AfterFunc(ctx, func() { _ = listener.Close() })
	defer stopAccept()
	if err = listener.SetDeadline(time.Now().Add(15 * time.Second)); err != nil {
		return err
	}
	commandArgs := append([]string{"-F", ready.SSHConfig}, args...)
	commandArgs = append(commandArgs, "-worker-direct-control")
	cmd := newCommand(ctx, "/usr/bin/ssh", commandArgs...)
	cmd.Stdout = io.Discard
	cmd.Stderr = errorOutput
	cmd.WaitDelay = 2 * time.Second
	bootstrap, err := cmd.StdinPipe()
	if err != nil {
		return err
	}
	defer bootstrap.Close()
	if err = cmd.Start(); err != nil {
		return err
	}
	var authenticated, connected atomic.Bool
	childDone := make(chan struct{})
	var childErr error
	go func() {
		childErr = cmd.Wait()
		close(childDone)
		_ = listener.Close()
		if !connected.Load() {
			cancel()
		}
	}()
	defer func() {
		select {
		case <-childDone:
		default:
			_ = cmd.Process.Kill()
			<-childDone
		}
		result = errors.Join(result, childErr)
	}()
	// Read controller input before accept so cancellation also owns bootstrap.
	// The supported controller sends one bounded bootstrap and waits for replies.
	// A bounded queue retains that bootstrap without blocking EOF observation.
	inputCtx, stopInput := context.WithCancel(ctx)
	defer stopInput()
	chunks := make(chan []byte, 16)
	readDone := make(chan struct{})
	var readErr error
	var shuttingDown atomic.Bool
	go func() {
		defer close(readDone)
		defer close(chunks)
		for {
			buf := make([]byte, 4096)
			n, e := input.Read(buf)
			if n > 0 {
				select {
				case chunks <- buf[:n]:
				case <-inputCtx.Done():
					return
				default:
					if !authenticated.Load() {
						readErr = fmt.Errorf("wiremux-measure: controller bootstrap exceeds direct input buffer")
						cancel()
						return
					}
					select {
					case chunks <- buf[:n]:
					case <-inputCtx.Done():
						return
					}
				}
			}
			if e != nil {
				if e != io.EOF && (!shuttingDown.Load() || !errors.Is(e, os.ErrClosed)) {
					readErr = e
				}
				if !authenticated.Load() || readErr != nil {
					cancel()
				}
				return
			}
		}
	}()
	defer func() {
		shuttingDown.Store(true)
		stopInput()
		_ = input.Close()
		<-readDone
		result = errors.Join(result, readErr)
	}()
	// #nosec G117 -- authentication material travels only over verified SSH stdin.
	if err = json.NewEncoder(bootstrap).Encode(directWorkerConfig{Address: listener.Addr().String(), Pin: hex.EncodeToString(pin[:]), Token: hex.EncodeToString(token)}); err != nil {
		return err
	}
	_ = bootstrap.Close()
	raw, err := listener.AcceptTCP()
	if err != nil {
		return fmt.Errorf("wiremux-measure: accept direct worker: %w", err)
	}
	connected.Store(true)
	defer raw.Close()
	_ = listener.Close()
	if err = raw.SetNoDelay(true); err != nil {
		return err
	}
	conn := tls.Server(raw, &tls.Config{MinVersion: tls.VersionTLS13, Certificates: []tls.Certificate{{Certificate: [][]byte{der}, PrivateKey: key}}})
	defer conn.Close()
	stopConn := context.AfterFunc(ctx, func() { _ = conn.Close() })
	defer stopConn()
	if err = conn.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
		return err
	}
	if err = conn.HandshakeContext(ctx); err != nil {
		return fmt.Errorf("wiremux-measure: direct worker TLS handshake: %w", err)
	}
	// Read exactly the authentication frame, leaving all protocol bytes in TLS.
	auth := make([]byte, 0, 128)
	one := make([]byte, 1)
	for len(auth) < 1024 {
		if _, err = io.ReadFull(conn, one); err != nil {
			return fmt.Errorf("wiremux-measure: direct worker authentication: %w", err)
		}
		auth = append(auth, one[0])
		if one[0] == '\n' {
			break
		}
	}
	var response struct {
		Token string `json:"token"`
	}
	if json.Unmarshal(auth, &response) != nil || subtle.ConstantTimeCompare([]byte(response.Token), []byte(hex.EncodeToString(token))) != 1 {
		return fmt.Errorf("wiremux-measure: direct worker token mismatch")
	}
	deadline, _ := ctx.Deadline()
	if err = conn.SetDeadline(deadline); err != nil {
		return err
	}
	authenticated.Store(true)
	inputDone := make(chan error, 1)
	go func() { inputDone <- copyDirectInput(chunks, conn, &shuttingDown) }()
	_, outputErr := io.Copy(output, conn)
	shuttingDown.Store(true)
	_ = input.Close()
	stopInput()
	_ = conn.Close()
	// Never reclassify an operation that already failed as cleanup. The pump
	// skips a new half-close after teardown begins, but retains in-flight errors.
	inputErr := <-inputDone
	if outputErr != nil || inputErr != nil {
		cancel()
	}
	<-childDone
	return errors.Join(outputErr, inputErr)
}

// Accept only the canonical argv emitted by measurement.startRemoteWorker.
// This is a closed command format, not a parser for arbitrary SSH invocations.
func directWorkerArguments(args []string) (time.Duration, bool, error) {
	if !slices.Contains(args, "-remote-worker") {
		return 0, false, nil
	}
	prefix := []string{"-T", "-oBatchMode=yes", "-oStrictHostKeyChecking=yes", "-oConnectTimeout=10", "-oServerAliveInterval=2", "-oServerAliveCountMax=2", "wiremux-session"}
	bad := func() (time.Duration, bool, error) {
		return 0, true, fmt.Errorf("wiremux-measure: direct control requires canonical admitted worker arguments")
	}
	if len(args) != len(prefix)+4 || !slices.Equal(args[:len(prefix)], prefix) || args[8] != "-remote-worker" || args[9] != "-worker-timeout-ms" {
		return bad()
	}
	binary := args[7]
	if binary == "" || strings.HasPrefix(binary, "-") {
		return bad()
	}
	for _, r := range binary {
		if r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' || r >= '0' && r <= '9' || strings.ContainsRune("/:._-", r) {
			continue
		}
		return bad()
	}
	ms, err := strconv.ParseInt(args[10], 10, 64)
	if err != nil || ms < 1 || ms > 182000 || strconv.FormatInt(ms, 10) != args[10] {
		return bad()
	}
	return time.Duration(ms) * time.Millisecond, true, nil
}

type directInputWriter interface {
	io.Writer
	CloseWrite() error
}

func copyDirectInput(chunks <-chan []byte, conn directInputWriter, shuttingDown *atomic.Bool) error {
	for chunk := range chunks {
		if _, err := conn.Write(chunk); err != nil {
			return err
		}
	}
	if shuttingDown.Load() {
		return nil
	}
	return conn.CloseWrite()
}
