// wiremux-measure is an opt-in Datagram and reliable-stream diagnostic. It is not included in
// release packaging and performs no network work unless explicitly invoked.
package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"time"

	"github.com/GridSwarm/wiremux/internal/measurement"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run() error {
	launcher := flag.Bool("direct-control-launcher", false, "internal SSH launcher with pinned TLS control")
	readyPath := flag.String("direct-control-session", "", "internal fresh session coordinates")
	controlBind := flag.String("direct-control-bind", "", "internal explicit controller IPv4 address")
	configPath := flag.String("config", "", "versioned JSON run configuration (default: local Wire diagnostic)")
	output := flag.String("output", "", "new output directory; parent must exist")
	defaults := flag.Bool("print-config", false, "print the default versioned configuration and exit")
	streamDefaults := flag.Bool("print-stream-config", false, "print the version 2 TCP stream configuration and exit")
	comparisonDefaults := flag.Bool("print-comparison-config", false, "print the version 3 full-Wire stream comparison configuration and exit")
	datagramDefaults := flag.Bool("print-datagram-config", false, "print the version 4 compact Datagram configuration and exit")
	worker := flag.Bool("worker", false, "internal worker protocol on stdin/stdout")
	remoteConfig := flag.String("remote-config", "", "versioned remote configuration with pinned endpoints")
	directControl := flag.Bool("worker-direct-control", false, "internal pinned TLS control bootstrap on stdin")
	remoteWorker := flag.Bool("remote-worker", false, "internal remote worker with process deadline")
	remoteCapture := flag.String("remote-capture", "", "internal capture stream on stdout")
	workerTimeout := flag.Int64("worker-timeout-ms", 0, "internal remote worker process deadline in milliseconds")
	flag.Parse()
	if flag.NArg() != 0 && !*launcher {
		return fmt.Errorf("wiremux-measure: unexpected arguments")
	}
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt)
	defer cancel()
	if *launcher {
		return runDirectLauncher(ctx, *readyPath, *controlBind, flag.Args())
	}
	if *remoteCapture != "" {
		if *worker || *remoteWorker || *directControl {
			return fmt.Errorf("wiremux-measure: invalid remote capture mode")
		}
		return runRemoteCapture(ctx, *remoteCapture)
	}
	if *directControl && !*remoteWorker {
		return fmt.Errorf("wiremux-measure: direct control requires remote worker mode")
	}
	if *remoteWorker {
		if *workerTimeout < 1 || *workerTimeout > 182000 || *worker {
			return fmt.Errorf("wiremux-measure: invalid remote worker deadline or mode")
		}
		if *directControl {
			return runDirectRemoteWorker(ctx, time.Duration(*workerTimeout)*time.Millisecond)
		}
		return runRemoteWorker(ctx, time.Duration(*workerTimeout)*time.Millisecond)
	}
	if *worker {
		return measurement.Worker(ctx, os.Stdin, os.Stdout)
	}
	c := measurement.DefaultConfig()
	if *streamDefaults {
		c = measurement.DefaultStreamConfig()
	}
	if *comparisonDefaults {
		c = measurement.DefaultComparisonConfig()
	}
	if *datagramDefaults {
		c = measurement.DefaultDatagramConfig()
	}
	if *defaults || *streamDefaults || *comparisonDefaults || *datagramDefaults {
		e := json.NewEncoder(os.Stdout)
		e.SetIndent("", "  ")
		return e.Encode(c)
	}
	if *output == "" {
		return fmt.Errorf("wiremux-measure: -output is required")
	}
	if *remoteConfig != "" {
		if *configPath != "" {
			return fmt.Errorf("wiremux-measure: select either local or remote config")
		}
		f, err := os.Open(*remoteConfig)
		if err != nil {
			return err
		}
		rc, err := measurement.DecodeRemoteConfig(f)
		_ = f.Close()
		if err != nil {
			return err
		}
		binary, err := os.Executable()
		if err != nil {
			return err
		}
		r, err := measurement.RunRemote(ctx, binary, []string{"-worker"}, rc, *output)
		if err != nil {
			return err
		}
		writeRemoteResult(os.Stdout, r, *output)
		return nil
	}
	if *configPath != "" {
		f, err := os.Open(*configPath)
		if err != nil {
			return err
		}
		c, err = measurement.DecodeConfig(f)
		_ = f.Close()
		if err != nil {
			return err
		}
	}
	binary, err := os.Executable()
	if err != nil {
		return err
	}
	r, err := measurement.RunLocal(ctx, binary, []string{"-worker"}, c, *output)
	if err != nil {
		return err
	}
	if r.Stream != nil {
		fmt.Printf("%s: %s; %.3f Mbps receiver-window goodput, %d/%d desired bytes validated; results: %s/result.json\n", r.RunID, r.Status, r.Stream.WindowGoodputBPS/1e6, r.Stream.ReceivedBytes, r.Stream.DesiredBytes, *output)
		return nil
	}
	fmt.Printf("%s: %s; %.3f Mbps window goodput, %d/%d admitted delivered; results: %s/result.json\n", r.RunID, r.Status, r.Summary.WindowGoodputBPS/1e6, r.Summary.Admitted-r.Summary.MissingAdmitted, r.Summary.Admitted, *output)
	return nil
}

func writeRemoteResult(out io.Writer, r measurement.Result, output string) {
	goodput := r.Summary.WindowGoodputBPS
	if r.Stream != nil {
		goodput = r.Stream.WindowGoodputBPS
	}
	_, _ = fmt.Fprintf(out, "%s: %s; %.3f Mbps observed receiver-window goodput; remote alignment qualified=%t; results: %s/result.json\n", r.RunID, r.Status, goodput/1e6, r.Remote.WindowQualified, output)
}

// This process-only entry point has a hard deadline independent of SSH EOF or
// cooperative library shutdown. main exits on timeout, releasing this worker's
// OS resources even if an I/O operation cannot join. No other host process is
// signaled. Normal completion joins Worker before returning.
func runRemoteWorker(parent context.Context, timeout time.Duration) error {
	ctx, cancel := context.WithTimeout(parent, timeout)
	defer cancel()
	done := make(chan error, 1)
	go func() { done <- measurement.Worker(ctx, os.Stdin, os.Stdout) }()
	select {
	case err := <-done:
		return err
	case <-ctx.Done():
		return fmt.Errorf("wiremux-measure: remote worker process deadline or cancellation: %w", ctx.Err())
	}
}

// Like runRemoteWorker, this private CLI mode exits the process on deadline,
// including if opening or reading the selected file stalls.
func runRemoteCapture(parent context.Context, path string) error {
	ctx, cancel := context.WithTimeout(parent, 10*time.Second)
	defer cancel()
	done := make(chan error, 1)
	go func() {
		f, err := os.Open(path)
		if err != nil {
			done <- err
			return
		}
		_, err = io.Copy(os.Stdout, io.LimitReader(f, (256<<20)+1))
		done <- errors.Join(err, f.Close())
	}()
	select {
	case err := <-done:
		return err
	case <-ctx.Done():
		return fmt.Errorf("wiremux-measure: remote capture deadline or cancellation: %w", ctx.Err())
	}
}

// The existing process deadline also bounds bootstrap, authentication and I/O.
func runDirectRemoteWorker(parent context.Context, timeout time.Duration) error {
	ctx, cancel := context.WithTimeout(parent, timeout)
	defer cancel()
	done := make(chan error, 1)
	go func() {
		conn, err := openDirectWorker(ctx, os.Stdin)
		if err != nil {
			done <- err
			return
		}
		defer conn.Close()
		stop := context.AfterFunc(ctx, func() { _ = conn.Close() })
		defer stop()
		done <- measurement.Worker(ctx, conn, conn)
	}()
	select {
	case err := <-done:
		return err
	case <-ctx.Done():
		return fmt.Errorf("wiremux-measure: direct remote worker process deadline or cancellation: %w", ctx.Err())
	}
}
