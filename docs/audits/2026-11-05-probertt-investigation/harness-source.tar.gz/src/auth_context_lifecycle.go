package wiremux

import (
	"errors"
	"sync"
	"time"

	"github.com/GridSwarm/wiremux/connect"
)

const defaultAuthContextReleaseTimeout = time.Second

// authReleaseRoute controls reporting only; callers retain release timing.
type authReleaseRoute uint8

const (
	authReleaseObserveImmediate authReleaseRoute = iota
	authReleaseReturnImmediate
)

type authContextOwner struct {
	source connect.AuthContext
	gate   authContextGate
	view   connect.AuthContext

	observer    *orderedAuthContextReleaseObserver
	releaseDone chan struct{}
	publishOnce sync.Once
	releaseOnce sync.Once
	releaseErr  error
	revokeOnce  sync.Once
	deadline    time.Time
}

func newAuthContextOwner(source connect.AuthContext, handler func(error)) *authContextOwner {
	owner := &authContextOwner{
		source:      source,
		observer:    newOrderedAuthContextReleaseObserver(handler),
		releaseDone: make(chan struct{}),
	}
	owner.gate.init()
	base := &authContextView{owner: owner}
	if _, ok := source.(connect.ChannelUseClaimer); ok {
		owner.view = &claimableAuthContextView{authContextView: base}
	} else {
		owner.view = base
	}
	return owner
}

func (o *authContextOwner) authContext() connect.AuthContext {
	return o.view
}

func (o *authContextOwner) transportAuth() connect.TransportAuth {
	return &transportAuthContextView{owner: o}
}

func (o *authContextOwner) revoke(timeout time.Duration) {
	o.revokeOnce.Do(func() {
		_, revokedAt := o.gate.revoke()
		o.deadline = revokedAt.Add(timeout)
	})
}

// startRelease revokes synchronously and starts the one bounded release without
// publishing. The deadline remains anchored to the first logical revocation.
func (o *authContextOwner) startRelease(timeout time.Duration) {
	o.revoke(timeout)
	o.releaseOnce.Do(func() {
		go func() {
			o.releaseErr = o.releaseOnceWithin()
			close(o.releaseDone)
		}()
	})
}

// finishRelease joins the stable immediate result and publishes once at the
// caller's chosen point. The first publication fixes the reporting route;
// callback completion is never joined here.
func (o *authContextOwner) finishRelease(timeout time.Duration, route authReleaseRoute) error {
	o.startRelease(timeout)
	<-o.releaseDone
	o.publishOnce.Do(func() {
		o.observer.publishImmediate(o.releaseErr, route == authReleaseObserveImmediate)
	})
	return o.releaseErr
}

func (o *authContextOwner) releaseOnceWithin() error {
	idle, _ := o.gate.revoke()
	releaser, ok := o.source.(connect.AuthContextReleaser)
	if !ok {
		return nil
	}

	if !waitForAuthContextIdle(idle, time.Until(o.deadline)) {
		go func() {
			<-idle
			if err := releaser.ReleaseAuthContext(); err != nil {
				o.observer.reportLate(err)
			}
		}()
		return connect.ErrAuthContextReleaseTimeout
	}

	done := make(chan error, 1)
	go func() {
		done <- releaser.ReleaseAuthContext()
	}()
	remaining := time.Until(o.deadline)
	if remaining <= 0 {
		observeLateAuthContextRelease(done, o.observer.reportLate)
		return connect.ErrAuthContextReleaseTimeout
	}
	timer := time.NewTimer(remaining)
	defer timer.Stop()
	select {
	case err := <-done:
		return err
	case <-timer.C:
		observeLateAuthContextRelease(done, o.observer.reportLate)
		return connect.ErrAuthContextReleaseTimeout
	}
}

func waitForAuthContextIdle(idle <-chan struct{}, timeout time.Duration) bool {
	if timeout <= 0 {
		select {
		case <-idle:
			return true
		default:
			return false
		}
	}
	timer := time.NewTimer(timeout)
	defer timer.Stop()
	select {
	case <-idle:
		return true
	case <-timer.C:
		return false
	}
}

func observeLateAuthContextRelease(done <-chan error, handler func(error)) {
	go func() {
		reportAuthContextReleaseError(handler, <-done)
	}()
}

func reportAuthContextReleaseError(handler func(error), err error) {
	if handler == nil || err == nil {
		return
	}
	defer func() {
		_ = recover()
	}()
	handler(err)
}

type orderedAuthContextReleaseObserver struct {
	handler   func(error)
	published chan struct{}
	once      sync.Once
	mu        sync.Mutex
	tail      <-chan struct{}
}

func newOrderedAuthContextReleaseObserver(handler func(error)) *orderedAuthContextReleaseObserver {
	tail := make(chan struct{})
	close(tail)
	return &orderedAuthContextReleaseObserver{
		handler:   handler,
		published: make(chan struct{}),
		tail:      tail,
	}
}

func (o *orderedAuthContextReleaseObserver) reportLate(err error) {
	<-o.published
	o.enqueue(err)
}

func (o *orderedAuthContextReleaseObserver) publishImmediate(err error, report bool) {
	if report {
		o.enqueue(err)
	}
	o.once.Do(func() {
		close(o.published)
	})
}

func (o *orderedAuthContextReleaseObserver) enqueue(err error) {
	if o.handler == nil || err == nil {
		return
	}
	o.mu.Lock()
	previous := o.tail
	done := make(chan struct{})
	o.tail = done
	o.mu.Unlock()
	go func() {
		<-previous
		reportAuthContextReleaseError(o.handler, err)
		close(done)
	}()
}

type authContextGate struct {
	mu        sync.Mutex
	revoked   bool
	revokedAt time.Time
	active    int
	idle      chan struct{}
}

func (g *authContextGate) init() {
	g.idle = make(chan struct{})
	close(g.idle)
}

func (g *authContextGate) acquire() bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.revoked {
		return false
	}
	if g.active == 0 {
		g.idle = make(chan struct{})
	}
	g.active++
	return true
}

func (g *authContextGate) release() {
	g.mu.Lock()
	defer g.mu.Unlock()
	g.active--
	if g.active == 0 {
		close(g.idle)
	}
}

func (g *authContextGate) revoke() (<-chan struct{}, time.Time) {
	g.mu.Lock()
	if !g.revoked {
		g.revoked = true
		g.revokedAt = time.Now()
	}
	idle := g.idle
	revokedAt := g.revokedAt
	g.mu.Unlock()
	return idle, revokedAt
}

type authContextView struct {
	owner *authContextOwner
}

func (v *authContextView) SendKey() []byte {
	if !v.owner.gate.acquire() {
		return nil
	}
	defer v.owner.gate.release()
	return v.owner.source.SendKey()
}

func (v *authContextView) ReceiveKey() []byte {
	if !v.owner.gate.acquire() {
		return nil
	}
	defer v.owner.gate.release()
	return v.owner.source.ReceiveKey()
}

func (v *authContextView) SessionBinding() []byte {
	if !v.owner.gate.acquire() {
		return nil
	}
	defer v.owner.gate.release()
	return v.owner.source.SessionBinding()
}

func (v *authContextView) Exporter() connect.KeyExporter {
	if !v.owner.gate.acquire() {
		return releasedAuthContextExporter{}
	}
	defer v.owner.gate.release()
	exporter := v.owner.source.Exporter()
	if exporter == nil {
		return nil
	}
	return &authContextExporterView{owner: v.owner, source: exporter}
}

type claimableAuthContextView struct {
	*authContextView
}

func (v *claimableAuthContextView) ClaimChannelUse() error {
	if !v.owner.gate.acquire() {
		return connect.ErrAuthContextReleased
	}
	defer v.owner.gate.release()
	//nolint:forcetypeassert // newAuthContextOwner only builds this view when source implements ChannelUseClaimer.
	return v.owner.source.(connect.ChannelUseClaimer).ClaimChannelUse()
}

type transportAuthContextView struct {
	owner *authContextOwner
}

func (v *transportAuthContextView) SessionBinding() ([]byte, error) {
	if !v.owner.gate.acquire() {
		return nil, connect.ErrAuthContextReleased
	}
	defer v.owner.gate.release()
	return v.owner.source.SessionBinding(), nil
}

func (v *transportAuthContextView) Exporter() connect.KeyExporter {
	if !v.owner.gate.acquire() {
		return releasedAuthContextExporter{}
	}
	defer v.owner.gate.release()
	exporter := v.owner.source.Exporter()
	if exporter == nil {
		return authContextErrorExporter{err: connect.ErrNilKeyExporter}
	}
	return &authContextExporterView{owner: v.owner, source: exporter}
}

type authContextExporterView struct {
	owner  *authContextOwner
	source connect.KeyExporter
}

func (e *authContextExporterView) Derive(label string, context []byte, length int) ([]byte, error) {
	if !e.owner.gate.acquire() {
		return nil, connect.ErrAuthContextReleased
	}
	defer e.owner.gate.release()
	return e.source.Derive(label, context, length)
}

type releasedAuthContextExporter struct{}

func (releasedAuthContextExporter) Derive(string, []byte, int) ([]byte, error) {
	return nil, connect.ErrAuthContextReleased
}

type authContextErrorExporter struct {
	err error
}

func (e authContextErrorExporter) Derive(string, []byte, int) ([]byte, error) {
	return nil, e.err
}

func joinAuthContextReleaseError(carrierErr, releaseErr error) error {
	return errors.Join(carrierErr, releaseErr)
}
