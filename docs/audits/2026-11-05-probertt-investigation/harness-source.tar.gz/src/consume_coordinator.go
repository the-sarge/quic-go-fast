package wiremux

import (
	"context"
	"io"
	"sync"
	"time"

	"github.com/GridSwarm/wiremux/connect"
	"github.com/GridSwarm/wiremux/relay"
	"github.com/GridSwarm/wiremux/relayurl"
)

type consumeSessionFunc func(context.Context, *relayurl.Endpoint, relay.SessionID, ...relay.DialOption) error

type consumeCoordinator struct {
	ctx       context.Context
	endpoint  *relayurl.Endpoint
	sessionID relay.SessionID
	relayOpts []relay.DialOption
	consume   consumeSessionFunc
	handler   func(relay.SessionID, error)

	consumeOnce sync.Once
	consumeDone chan struct{}
}

type identityFailureConsumePolicy uint8

const (
	identityFailureConsumeNone identityFailureConsumePolicy = iota
	identityFailureConsumeWithinDialDeadline
	identityFailureConsumeWithoutCancel
)

func newConsumeCoordinator(
	ctx context.Context,
	endpoint *relayurl.Endpoint,
	id relay.RendezvousID,
	relayOpts []relay.DialOption,
	handler func(relay.SessionID, error),
	consume consumeSessionFunc,
) *consumeCoordinator {
	sessionID, ok := id.(relay.SessionID)
	if !ok || consume == nil {
		return nil
	}
	return &consumeCoordinator{
		ctx:         ctx,
		endpoint:    endpoint,
		sessionID:   sessionID,
		relayOpts:   append([]relay.DialOption(nil), relayOpts...),
		consume:     consume,
		handler:     handler,
		consumeDone: make(chan struct{}),
	}
}

func (c *consumeCoordinator) onIdentityFailure(cause error) {
	if c == nil {
		return
	}
	policy := c.identityFailureConsumePolicy(cause)
	if policy == identityFailureConsumeNone {
		return
	}
	var err error
	ran := false
	c.consumeOnce.Do(func() {
		ran = true
		defer close(c.consumeDone)
		switch policy {
		case identityFailureConsumeWithoutCancel:
			err = c.consumeBestEffort()
		default:
			err = c.consumeWithinDialDeadline()
		}
	})
	if ran {
		go c.reportConsumeError(err)
	}
}

func (c *consumeCoordinator) onPostIdentitySuccessFailure(successSpendsRendezvous bool) {
	if c == nil || !successSpendsRendezvous {
		return
	}
	var err error
	ran := false
	c.consumeOnce.Do(func() {
		ran = true
		defer close(c.consumeDone)
		err = c.consumeBestEffort()
	})
	if ran {
		go c.reportConsumeError(err)
	}
}

func (c *consumeCoordinator) decorateRelay(stream io.ReadWriteCloser) io.ReadWriteCloser {
	if c == nil {
		return stream
	}
	return &consumeOnDirectUpgradeSuccessStream{
		ReadWriteCloser: stream,
		coordinator:     c,
	}
}

func (c *consumeCoordinator) gateRelayWin(stream io.ReadWriteCloser) io.ReadWriteCloser {
	if c == nil {
		return stream
	}
	consumeDone := c.startConsumeForRelayWin()
	return &consumeBeforeCloseStream{
		ReadWriteCloser: stream,
		consumeDone:     consumeDone,
	}
}

func (c *consumeCoordinator) identityFailureConsumePolicy(cause error) identityFailureConsumePolicy {
	if c == nil || isNilError(cause) {
		return identityFailureConsumeNone
	}
	switch connect.RendezvousDisposition(cause) {
	case connect.DispositionSpent:
		return identityFailureConsumeWithoutCancel
	case connect.DispositionRetryable:
		return identityFailureConsumeNone
	case connect.DispositionUnknown:
		// No rendezvous marker; the error-tree summary below decides.
	}
	if c.ctx.Err() != nil {
		return identityFailureConsumeNone
	}
	summary := identityFailureErrorTreeSummaryWithinDepth(cause, 0)
	if summary.meaningful &&
		!summary.hasContextCanceled &&
		!summary.hasContextDeadline &&
		summary.relayIOClosure == relayIOClosureAbsent {
		return identityFailureConsumeWithinDialDeadline
	}
	return identityFailureConsumeNone
}

func (c *consumeCoordinator) consumeBestEffort() error {
	consumeCtx, cancel := context.WithTimeout(context.WithoutCancel(c.ctx), defaultConsumeSessionTimeout)
	defer cancel()
	return c.consume(consumeCtx, c.endpoint, c.sessionID, c.relayOpts...)
}

func (c *consumeCoordinator) consumeWithinDialDeadline() error {
	timeout := defaultConsumeSessionTimeout
	if deadline, ok := c.ctx.Deadline(); ok {
		remaining := time.Until(deadline)
		if remaining <= 0 {
			return context.DeadlineExceeded
		}
		if remaining < timeout {
			timeout = remaining
		}
	}
	consumeCtx, cancel := context.WithTimeout(c.ctx, timeout)
	defer cancel()
	return c.consume(consumeCtx, c.endpoint, c.sessionID, c.relayOpts...)
}

func (c *consumeCoordinator) startConsumeForRelayWin() <-chan struct{} {
	return c.startConsumeBestEffort()
}

func (c *consumeCoordinator) startConsumeBestEffort() <-chan struct{} {
	c.consumeOnce.Do(func() {
		go func() {
			defer close(c.consumeDone)
			err := c.consumeBestEffort()
			go c.reportConsumeError(err)
		}()
	})
	return c.consumeDone
}

func (c *consumeCoordinator) startConsumeForDirectWin(relayStream io.ReadWriteCloser) {
	c.consumeOnce.Do(func() {
		go func() {
			// Relay consumption targets live ephemeral session state. Keep the
			// obsolete relay stream open until this bounded best-effort consume
			// attempt returns, without blocking Dial success.
			var err error
			func() {
				defer close(c.consumeDone)
				defer func() {
					_ = relayStream.Close()
				}()
				err = c.consumeBestEffort()
			}()
			c.reportConsumeError(err)
		}()
	})
}

func (c *consumeCoordinator) reportConsumeError(err error) {
	reportConsumeSessionError(c.handler, c.sessionID, err)
}

func reportConsumeSessionError(handler func(relay.SessionID, error), sessionID relay.SessionID, err error) {
	if handler == nil || isNilError(err) {
		return
	}
	defer func() {
		// The handler is non-fatal telemetry. Keep callback panics from escaping
		// library-owned cleanup goroutines.
		_ = recover()
	}()
	handler(sessionID, err)
}

type consumeOnDirectUpgradeSuccessStream struct {
	io.ReadWriteCloser
	coordinator *consumeCoordinator
}

func (s *consumeOnDirectUpgradeSuccessStream) CloseAfterDirectUpgradeSuccess() error {
	s.coordinator.startConsumeForDirectWin(s.ReadWriteCloser)
	return nil
}

type consumeBeforeCloseStream struct {
	io.ReadWriteCloser
	consumeDone           <-chan struct{}
	testBeforeConsumeWait func()
}

func (s *consumeBeforeCloseStream) Close() error {
	if s.testBeforeConsumeWait != nil {
		s.testBeforeConsumeWait()
	}
	<-s.consumeDone
	return s.ReadWriteCloser.Close()
}
