# Datagram scenario review dispositions

Package D implements the finite scenarios in the [approved preparation contract](../work-items/qualification-preparation.md). Initial RAS review `20260913T104419-160f8d314fd53113c1fa87bd` examined `b41e4396745e51c18b6b2195aeb05869ad6cc109`; synthesis SHA-256 is `c443a4884191b4a933d32c71250272ff3dd74a1b8f527708c9972ee71957c639`. These are independent implementation dispositions. Measurement code and its regressions are maintained verification aids; no production transport changes are included.

| Finding | Disposition | Evidence and bounded owner correction |
| --- | --- | --- |
| C001 | fix-now | The public retained-ledger reader hardcoded the unnumbered kind. Admit only the existing finite unnumbered/0..3 kinds through the same association, size and digest verifier. Both native and Wire four-connection subprocess cases reproduce failure before the fix and reload all eight retained artifacts afterward. |
| C003/C010 | fix-now | A percentile upper bound above the limit cannot prove failure. The per-flow admission verdict uses the actual p99 bucket lower bound to prove failure, its upper bound to prove pass, and otherwise reports inconclusive. Observe/finalize distributions cover both 2 ms and 5 ms limits, proven failure and pass. |
| C009 | fix-now | Local shared calibration does not establish actual child start lateness. The controller's per-flow verdict owner requires both local child starts within 0..1 ms. One late child invalidates only its local flow; remote shared witnessed qualification remains conservative for the group. |
| C004/C007 | reject as additional work | No behavioral counterexample beyond the accepted verdict issues. The existing subprocess regression now asserts all indexed verdicts and conservative remote qualification as evidence for those fixes. |
| C002/C008/C011 | defer, no ticket | Stale limitation prose is adjacent polish; structured connection/control receipts preserve the supported workload. It does not block the approved measurement outcome. |
| C005/C012 | defer, no ticket | Diagnostics name an older configuration version, but unsupported manifests are rejected. No accepted behavior is violated. |
| C006/C013 | reject | The proposed sub-32768-bit/s aggregate domain and alternate invalid manifests are outside the named campaign rates. No failure in an authorized row or search is established. |

These initial findings concern three distinct precise invariants and owners; no prior claimed closure of these owners exists in Package D. Their finite cases fit the accepted focused evidence, with no stronger platform or mutation cross-product. The focused `TestDatagram`, `TestRemoteDatagram` and `TestPackedLedger` race set passed after correction. Exact-candidate full validation, accepted-fix verification and the single permitted replacement review remain the completion gates. Native qualification captures remain unexecuted.
