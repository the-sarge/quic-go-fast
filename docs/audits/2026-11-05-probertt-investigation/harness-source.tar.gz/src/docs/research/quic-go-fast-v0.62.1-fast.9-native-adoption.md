# fast.9 maintenance adoption for native certification

Status: accepted maintenance selection for remaining native certification. The [fork prerelease](https://github.com/the-sarge/quic-go-fast/releases/tag/v0.62.1-fast.9) was published at `2026-10-25T21:52:03Z`, non-draft and prerelease, with no assets. This record makes no throughput-certification claim.

This maintenance adoption selects `github.com/the-sarge/quic-go-fast v0.62.1-fast.9` for the program's optional native fork lane and never-merged measurement rig. The ordinary graph remains upstream quic-go `v0.62.0` without a replacement; root module files, release selection and advertised-fork documentation are unchanged. It is not a wiremux release or a throughput claim. The [fast.8 adoption record](quic-go-fast-v0.62.1-fast.8-native-adoption.md) remains the source for the eleven bundle slices, defaults, accepted consumer costs and packet-I/O reconciliation.

## Identity and release boundary

| Identity | Value |
| --- | --- |
| Fork tag | `v0.62.1-fast.9` |
| Source commit | `0f717339f767df5d2e4091b2515266d61f66e2ac` |
| Annotated tag object | `2265931bf6dfa1dba4901ec65171ecf4c8623f3a` |
| Base release / upstream base | `v0.62.1-fast.8` / upstream quic-go `v0.62.0` |
| Public-proxy module sum | `h1:bxCYXEbnY35W5bstYGEkvOc0rVSu284KtjKmI2qbw4c=` |
| Public-proxy go.mod sum | `h1:kzQzvSE26oBNHy1O/XK5lZY6fBE6ba5/o6+34xsu8v4=` |
| Public-proxy ZIP SHA-256 | `d19fc83d6b52c27d8375a4cb5de0c7e718beb9333d3d00a2d5542eeb39b6b56e` |
| Release preparation and owner exception | [quic-go-fast #1049](https://github.com/the-sarge/quic-go-fast/issues/1049) |

The owner selected fast.8 plus [QUIC #1047](https://github.com/the-sarge/quic-go-fast/pull/1047) only and approved a one-time maintenance-branch release exception on 2026-10-25. Current-main loss-recovery changes are excluded. The tag is immutable by policy; no GitHub-enforced immutability claim is made.

Both archives were obtained with `GOPROXY=https://proxy.golang.org`, `GOSUMDB=sum.golang.org` and empty private-module bypass variables. Fast.8 has 915 module-archive files; fast.9 has 916. The complete archive comparison changes only `connection.go` and `mtu_discoverer.go`, adds only `connection_idle_pmtu_test.go`, and removes nothing. The four checked candidate files, including unchanged `go.mod`, match the approved source; proxy origin identifies the selected commit. A separate application-owned replacement builds QUIC and HTTP/3 before tagging and with the downloaded tag; its `go mod verify` passes.

## Reason and source reconciliation

Fast.8 can stall packet-size discovery on an idle connection because its connection timer omits the next eligible path-MTU probe. The explicit certification minimum waits for 1,397-byte readiness before authentication and produces no application traffic during that wait. #1047 includes the next probe time in the existing connection timer, respecting pacing and the existing hard-blocked and congestion-limited early returns. The upstream virtual-time regression fails on fast.8 and passes all eight cases with the fix.

The [Windows diagnosis](https://github.com/GridSwarm/wiremux/issues/1935#issuecomment-6403536921) reproduced the original 60-second setup failure using the retained original binaries. On the same replacement guest, with the same product/rig/observer, flags, port and affinity, fast.8 plus only #1047 completed setup and exchanged 1,397-byte Datagrams; both promoted ceilings were 1,397, failed sends were zero, and the Windows observer reported positive coalesced reads with zero coalescing fallbacks. These short pairs are debugging examples, not certification or floor evidence. [Wiremux #2037](https://github.com/GridSwarm/wiremux/pull/2037) is separately merged, Darwin-only and already present in the Windows product source.

The reconciliation domain is the complete fast.8-to-fast.9 module-archive delta. `connection.go` changes timer scheduling only; `mtu_discoverer.go` factors existing probe eligibility into `NextProbeTime` and reuses it from `ShouldSendProbe`. Neither file introduces descriptor access, socket submission, a replacement packet connection, admission permission, or a new runtime owner. Probes still use the existing emission and checked-write paths. Therefore the fast.8 selected-peer and socket-owner census remains valid; this maintenance delta changes no packet-I/O authority. All eleven fork slices, native coalescing grants, delegated admission, acknowledgment threshold, gluing, send/read batch bounds and QoS opt-ins retain their prior owners and defaults. No new stand-in flag or kill switch is introduced.

## Validation and limits

Release evidence is retained at `/Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/release-fast9/`. Audited base Go is 1.27.3. Fresh `govulncheck@v1.7.0` source scans for Darwin/arm64, Linux/amd64 and Windows/amd64 report no reachable or imported-package vulnerability. Uncalled module advisory [GO-2026-5932](https://pkg.go.dev/vuln/GO-2026-5932) concerns the unmaintained `golang.org/x/crypto/openpgp` package in required module `golang.org/x/crypto v0.58.0`; these builds do not import that package. No dependency mutation is included.

The first candidate Windows integration run failed QUIC-v2 `TestServerTransportClose` at its fixed one-second client idle-wait assertion. The exact focused test passes 20 repetitions on Darwin and 20 on the retained Windows guest with the CI timescale of three. Production's idle timeout can be extended to three PTOs; the first failed job lacks the RTT/PTO evidence to prove its cause. One bounded failed-job rerun passed; the original failure remains preserved. No test or production source was changed to obtain that result. Exact-source tag-triggered workflows all passed before publication: [unit](https://github.com/the-sarge/quic-go-fast/actions/runs/40236856552), [integration](https://github.com/the-sarge/quic-go-fast/actions/runs/40236856539), [lint](https://github.com/the-sarge/quic-go-fast/actions/runs/40236856541), [cross-compilation](https://github.com/the-sarge/quic-go-fast/actions/runs/40236856544) and [interop-image build](https://github.com/the-sarge/quic-go-fast/actions/runs/40236856605). All 17 jobs succeeded at the selected source. The original branch failure is disclosed in the published release evidence. Additional cross-compiled platforms are build-only evidence; interop builds publish no image.

The optional lane selects the published tag through a copied module file and the rig's own `rig.mod`; ordinary downstream builds remain upstream. The rig pin is published on its existing never-merged branch after this adoption merges. No fork-lane throughput campaign or additional performance certification is claimed. Windows and macOS certification records must name the actual product, fork and published rig revisions they measure; historical fast.8 results are retained rather than relabelled.
