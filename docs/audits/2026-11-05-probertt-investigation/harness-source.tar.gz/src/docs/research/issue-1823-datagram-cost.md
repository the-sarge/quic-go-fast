# Issue #1823: how much per-Datagram cost the native Datagram path can shed

Research for [#1823](https://github.com/GridSwarm/wiremux/issues/1823) on the wayfinder map [#1794](https://github.com/GridSwarm/wiremux/issues/1794). It answers how much of the native Datagram path's per-Datagram CPU cost wiremux can remove while keeping the bounded, cancellable, per-datagram admission that [ADR-0009](../adr/adr-0009-optional-datagram-capability.md) and [#1784](https://github.com/GridSwarm/wiremux/issues/1784) guarantee. Nothing here implements a change. Every reduction was sized with a throwaway probe that was never committed, and the probe diffs live only in the evidence directory.

Sources are wiremux at `origin/main` [2599a002](https://github.com/GridSwarm/wiremux/tree/2599a00292c70c9871794ce62a1266741d71d42a), the quic-go-fast fork at the version the rig selects (`v0.62.1-fast.7`, commit [55ea687d](https://github.com/the-sarge/quic-go-fast/tree/55ea687d68c9c6f33785a1875374ec6a0d7570e8)), the rig `cmd/nativerig` from `codex/native-gap-rig` [9695aeca](https://github.com/GridSwarm/wiremux/tree/9695aecacdef1e551862bf4fcbf279772819bb89/cmd/nativerig), and measurements taken for this note. Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Measurement caveat.** This note was produced in the daytime, so it uses no `tb` run, no minimax run and no Docker run (the Docker cell is retired). Every rig number comes from one host, mbp128 (Apple M4 Max, 16 cores, macOS 27), with both `nativerig` peers bound to `bridge0`'s own IPv4 address. Both peers share cores, and the kernel routes the traffic through `lo0`. Absolute rates and CPU totals are therefore not `tb` numbers (the kernel's `sendmsg` includes the loopback delivery). The evidence is the **relative** A/B deltas between builds run alternately on the same cell. The [off-hours confirmation](#off-hours-confirmation) section specifies the `tb` and minimax runs that would confirm them.

## Answer

wiremux can remove about **1.2 CPU-s per delivered GiB on the sender and 1.1 on the receiver** on its own, with no contract change (**measured**, same-host A/B, pooled medians of 4–7 runs per build). That is about a quarter of the gap to the native stream on the same cell (sender 4.40, receiver 4.18 CPU-s/GiB, **measured**). With two small fork APIs (a `SendDatagram` that takes ownership of the buffer, and a release callback once the frame is packed), the sender saving rises to about **1.8 CPU-s/GiB**, about 40% of the sender gap. Removing wiremux's last send hop as well (a non-blocking fork send) reaches about 2.0, but it changes the admission bound and came with unexplained Datagram loss in 3 of 8 runs. Allocations fall from 10.8 to 4.7 per sent Datagram and from 15.5 to 10.0 per received Datagram, and allocated bytes from 5,330 to 187 per sent Datagram (**measured**).

Throughput does not move on this cell (every build is within ±2% of base): the sender is bound by the fork's send goroutine doing one `sendmsg` per packet, not by the per-Datagram chain. The savings are CPU, which matters wherever the Datagram path is CPU-bound or shares cores with the application, and they are likely to matter more on Linux once Datagram GSO ([quic-go-fast#743](https://github.com/the-sarge/quic-go-fast/issues/743)) removes the per-packet `sendmsg` and leaves the per-Datagram chain as the sender's critical path. That is unmeasured here.

Most of the per-Datagram cost [#1814's note](https://github.com/GridSwarm/wiremux/blob/ed76d00647568523f6b9fad1804346a09f1db024/docs/research/issue-1814-datagram-gso.md#cpu-profiles) attributed to hand-offs, GC and scheduling is real, but not all of it is removable by wiremux: one bounded queue and one copy are what the admission contract itself requires, and the fork's own per-frame work (frame allocation, queue, run-loop wake-up) remains unless the fork changes.

## Ranked reductions

Savings are base median minus probe median over common-mode runs pooled from campaigns C1 and C2 (**measured**; run-to-run spread of base is about ±0.2 CPU-s/GiB, so differences below about 0.3 are noise). "Over X" means measured against the previous step rather than against base.

| # | Reduction | Sender CPU-s/GiB saved | Receiver CPU-s/GiB saved | Throughput effect | Contract impact | Owner | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | **One send queue and one copy for native Wires.** Root `Send` copies once and admits that copy straight into the native carrier's bounded, cancellable queue; the root pump goroutine and its queue go away (probe `s3b`) | **1.11** | 0.16 (noise) | none (−0.5%) | preserves as-is, provided `Datagrams.end` seals the carrier's queue under the same commit fence (the probe skipped that) | wiremux | `s3b`, n=6; same saving as the `s3` shape (1.11) |
| 2 | **Receive without the second copy and without a per-call context.** Strip the envelope from the caller-owned slice the carrier already returns, and reuse the merged (caller context + gate) context across calls (probes `r1` + `r2`) | 0.06 (noise) | **1.00** | none | preserves as-is | wiremux | `r12`, n=5; `r1` alone 0.73, `r2` alone 0.51 |
| 3 | **Fork takes ownership of the admitted copy** (`SendDatagramOwned`), so the fork's frame copy disappears | **0.30** over #1's shape (1.41 against base) | — | none (−1.2%) | preserves as-is | fork API, wiremux adopts | `s4` vs `s3`, n=7 |
| 4 | **Recycle the admitted buffer** once the fork has serialized it into a packet (free list in the handle, release callback from the fork) | **0.27** over #3 (1.68 against base) | — | none (−1.8%) | preserves as-is | fork API, wiremux adopts | `s5` vs `s4`, n=7; sender GCs per 8 s run fall from a median of 1,755 to 64 |
| 5 | **No wiremux send hop at all.** `Send` hands its copy to a non-blocking fork `TrySendDatagramOwned` under the gate mutex and waits on a fork readiness signal when the fork queue is full | **0.26** over #4 (2.00 against base, C3 only) | — | none (−1.5%), but Datagram loss of 0.22–0.51% in 3 of 8 runs, unexplained | **changes observable behavior**: the admission bound becomes the fork's 32-entry queue instead of a wiremux-owned queue of 8; ADR-0009 and `docs/COMPATIBILITY.md` wording change | fork API, wiremux adopts | `s6` vs `s5`, [C3](#zero-hop-send-c3), n=3 |
| — | Packaged wiremux-only (#1 + #2, probe `wmbest`) | **1.20** | **1.06** | none (+0.2%) | preserves as-is | wiremux | `wmbest`, n=4 |
| — | Packaged with the fork (#1–#4 + #2, probe `all`) | **1.80** | **1.05** | none (−1.1%) | preserves as-is | both | `all`, n=7 |
| 6 | Single root copy alone (part of #1) | 0.38 | — | none | preserves as-is | wiremux | `s1`, n=6 |
| 7 | Collapse the *carrier's* queue instead: the root pump calls the fork's blocking `SendDatagram` directly (probe `s2`) | 0.79 (1.11 with #6, `s3`) | — | none | **changes observable behavior** unless the fork offers a context-aware send: the Datagram gate's drain can then wait on the fork's uncancellable queue (below) | wiremux, plus a fork API to be safe | `s2`, `s3`, n=6–7 |
| 8 | Fix two escaping `errors.As` targets in the native carrier ([`promote.go` L473](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L473), [L501](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L501)) | not measured alone; 2 of the 10.8 sender allocations per Datagram | — | none | preserves as-is | wiremux | allocation profile; explains `s3b`'s 8.75 against `s3`'s 6.75 allocations |

Reading the table:

- Rows #1 and #2 are independent (one is the send path, the other the receive path) and add up: `wmbest` saves 1.20 and 1.06 (**measured**) against 1.11 + 0.06 and 0.16 + 1.00 summed from the parts (**derived**).
- Rows #3 and #4 were measured on the `s3` shape (row 7's collapse plus row 6's single copy), not on row 1's `s3b` shape, because they were built first. `s3` and `s3b` have the same hop and copy count and the same measured saving (1.11 each), so #3 and #4 should stack on #1 the same way (**derived**).
- Converted per Datagram, 1 CPU-s/GiB is 1.11 µs per 1,191-byte Datagram (**derived**: 2³⁰ / 1,191 = 901,557 Datagrams per GiB). So #1 saves about 1.2 µs of sender CPU per Datagram, #1–#4 about 1.9 µs, and #2 about 1.1 µs of receiver CPU (**derived**: 1.11, 1.68 and 1.00 × 1.11).

## The per-Datagram path today

### Send: four copies and four goroutine boundaries

The ticket counted three payload copies. There are four before the packer, because the root handle copies twice: once to prepend the envelope and once more inside its admission queue.

| Step | Goroutine | Hand-off | Copies and allocations | Code |
| --- | --- | --- | --- | --- |
| 1. `Datagrams.Send`: size and context checks, prepend the `0x00` envelope | caller | — | copy 1 (1,192 bytes into a 1,280-byte size class) | [`datagrams.go` L83-L109](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/datagrams.go#L83-L109) |
| 2. Root `Queue.Admit`: four-way `select` for a slot, the fence mutex, `entries <- append([]byte(nil), payload...)` | caller | channel of 8 to the pump | copy 2 | [`queue.go` L51-L92](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/datagramadmission/queue.go#L51-L92) |
| 3. `pumpSends`: `Dequeue` (mutex, three-way `select`, mutex, slot release), lifetime check, `carrier.SendDatagram(d.ctx, …)` | wiremux pump | **boundary 1** | — | [`datagrams.go` L240-L273](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/datagrams.go#L240-L273) |
| 4. `nativeDatagramCarrier` → `DatagramCarrier.SendDatagram`: checks, then the carrier's own `Admit` | pump | channel of 8 to the carrier sender | copy 3, plus one escaping `errors.As` target | [`native_promotion.go` L420-L426](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/native_promotion.go#L420-L426), [`promote.go` L457-L481](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L457-L481) |
| 5. `DatagramCarrier.send`: `Dequeue`, then the fork's blocking `SendDatagram` | wiremux carrier sender | **boundary 2** | one escaping `errors.As` target | [`promote.go` L490-L506](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L490-L506) |
| 6. Fork `Conn.SendDatagram`: allocate a frame, copy the payload, `datagramQueue.Add` (mutex, ring of 32, blocks while full), `hasData` → `scheduleSending` | carrier sender | **boundary 3**: wakes the connection's run loop | frame allocation, copy 4 | [`connection.go` L2900-L2918](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/connection.go#L2900-L2918), [`datagram_queue.go` L44-L69](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/datagram_queue.go#L44-L69), [`connection.go` L2787-L2792](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/connection.go#L2787-L2792) |
| 7. Packer: `Peek`/`Pop` one DATAGRAM frame per packet (the `Pop` signals the blocked `Add`), serialize into the packet buffer, seal | fork run loop | — | copy into the packet (inherent), a frames-slice allocation per packet | [`packet_packer.go` L648-L663](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/packet_packer.go#L648-L663), [L957-L993](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/packet_packer.go#L957-L993) |
| 8. Send queue → wiremux's admitted batch writer → `sendmsg` | fork send goroutine | **boundary 4** | per-packet address and control-message allocations | [`unicast.go` WriteUnicastBatch](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L762-L809) |

Between `Send` and the packer, up to 8 + 1 + 8 + 1 + 32 = 50 Datagrams can be in flight (root queue, pump's hand, carrier queue, sender's hand, fork queue; **derived** from the capacities). Boundaries 1 and 2 are wiremux's; 3 and 4 are the fork's and are shared with the stream. Each wiremux queue costs, per Datagram, four channel operations, three mutex acquisitions and two multi-way `select`s, and whenever a queue runs full, as it does while the sender outpaces `sendmsg`, a slot release can wake a parked goroutine.

### Receive: two copies, two fork boundaries, one context per call

| Step | Goroutine | Hand-off | Copies and allocations | Code |
| --- | --- | --- | --- | --- |
| 1. `Transport.listen` → `packetConn.ReadBatch` → binding `receive` (`ReadMsgUDP`) and `admitReceived` → fork packet policy → `Conn.handlePacket` | fork listen goroutine | to the run loop via `receivedPackets` and `notifyReceivedPacket` | per packet, not per Datagram: a `*net.UDPAddr` from `ReadMsgUDP`, a private address copy, and the fork policy re-marshaling the control message | [`transport.go` L648](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/transport.go#L648), [`unicast.go` L921-L982](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L921-L982), [`packet_policy.go` L57-L73](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/packet_policy.go#L57-L73), [`connection.go` L2003-L2035](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/connection.go#L2003-L2035) |
| 2. Run loop: open, `parseDatagramFrame` (the frame aliases the packet), `handleDatagramFrame` → `HandleDatagramFrame`: copy into the 128-entry receive queue, signal `rcvd` | fork run loop | wakes the receiving goroutine | frame allocation, copy 1, receive-queue growth | [`connection.go` L2248-L2264](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/connection.go#L2248-L2264), [`datagram_frame.go` L24-L46](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/internal/wire/datagram_frame.go#L24-L46), [`datagram_queue.go` L92-L110](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/datagram_queue.go#L92-L110) |
| 3. `Datagrams.Receive`: receive token, `context.WithCancel(ctx)` and `context.AfterFunc(d.ctx, cancel)`, carrier → fork `Receive` (mutex, pop), envelope check, copy 2, gate mutex | caller | — | about 4.5 context allocations and copy 2 | [`datagrams.go` L148-L238](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/datagrams.go#L148-L238), [`promote.go` L515-L532](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L515-L532), [`datagram_queue.go` L120-L140](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/datagram_queue.go#L120-L140) |

wiremux adds no goroutine on receive: `Receive` runs on the caller's goroutine. Its cost is the per-call context plumbing and the second copy. The fork's copy in step 2 is necessary, because the packet buffer is recycled, and the lower carrier contract already promises a caller-owned slice ([`connect/contracts.go` L166-L171](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/connect/contracts.go#L166-L171)), so the root's copy in step 3 is redundant.

### Allocation census

Whole-process counters over each 8 s rig run, divided by Datagrams sent or received (**measured**, pooled medians), and the allocation profiles of one run each (`mprof/`, **measured**):

| Build | Sender allocations per Datagram | Sender bytes per Datagram | Receiver allocations per Datagram | Receiver bytes per Datagram |
| --- | ---: | ---: | ---: | ---: |
| base | 10.78 | 5,330 | 15.45 | 3,180 |
| `wmbest` (#1 + #2) | 8.77 | 2,759 | 10.01 | 1,612 |
| `all` (#1–#4 + #2) | 4.74 | 187 | 10.04 | 1,628 |

Base sender allocations by site (allocation profile): root and carrier `Admit` 2.0, fork `SendDatagram` 2.0 (frame and data), `Send` 1.0, the two escaping `errors.As` targets 1.0 each, the fork packer's frames slice 1.0, and about 2 per-packet allocations in the binding and fork packet policy for the acknowledgments the sender receives and the packets it writes. Base receiver: `context.AfterFunc` 2.0, `context.WithCancel` 1.0, lazy `Done` channels 0.4, root copy 1.0, fork `HandleDatagramFrame` 1.7 (copy and queue growth), fork frame parse 1.0, and about 5 per packet in the binding and fork packet policy. What is left after `all` is the fork frame allocation and frames slice on the sender, and the fork copy, frame parse and per-packet allocations on the receiver.

## Where the CPU goes

### Method: Go's profiler cannot attribute this on macOS

[PROTOCOL.md](https://github.com/GridSwarm/wiremux/blob/9695aecacdef1e551862bf4fcbf279772819bb89/cmd/nativerig/PROTOCOL.md) says to profile with `-cpuprofile`. On macOS that misleads. Go's CPU profiler uses `setitimer` there, and the signal lands disproportionately on threads returning from system calls. In the base `dgram` sender's `-cpuprofile` (`prof/base-dgram`, **measured**), the three wiremux send hops (`Datagrams.Send`, `pumpSends`, `DatagramCarrier.send`) get 0.17 s of samples, against 1.00 s for the same functions in a kernel-sampled Instruments recording of an equivalent 8 s run (`xprof/base-dgram`), while `runtime.kevent` gets 3.26 s against 1.27 s. So per-hop attribution here uses `xctrace`'s Time Profiler (1 ms on-CPU samples with user stacks, one system-wide recording per run so both peers are captured; `scripts/xprof.sh`, `scripts/xtsum.py`). Time inside a system call appears as the `libsystem_kernel` leaf, because the unwinder stops at the Go system stack. On Linux, Go's profiler uses per-thread timers and is fine, which is why #1814's Docker profiles are usable.

### Sender and receiver, by bucket

One 8 s run per build, CPU-s per delivered GiB (**measured**, `xprof/xtcompare.txt`). Cumulative buckets overlap; leaf buckets do not.

| Bucket | Sender base `dgram` | Sender `allwm` | Sender `all` | Sender `stream` | Receiver base `dgram` | Receiver `allwm` | Receiver `stream` |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| **total (xctrace samples)** | **18.81** | **17.73** | **17.33** | **13.67** | **20.75** | **19.41** | **15.60** |
| `Datagrams.Send` (incl. root `Admit`) | 0.33 | 0.24 | 0.20 | — | — | — | — |
| `pumpSends` (incl. carrier `SendDatagram`) | 0.35 | 0.41¹ | 0.21¹ | — | — | — | — |
| carrier sender `DatagramCarrier.send` (incl. fork `SendDatagram`) | 0.37 | 0 | 0 | — | — | — | — |
| fork `Conn.SendDatagram` | 0.19 | 0.24 | 0 (owned variant) | — | — | — | — |
| `datagramadmission` `Admit` + `Dequeue` | 0.69 | 0.14 | 0.11 | — | — | — | — |
| `Datagrams.Receive` | — | — | — | — | 0.99 | 0.35 | — |
| of which `context.WithCancel` + `AfterFunc` | — | — | — | — | 0.21 | 0 | — |
| fork `HandleDatagramFrame` + `ReceiveDatagram` | — | — | — | — | 0.56 | 0.54 | — |
| fork run loop (`Conn.run`: packing, sealing, frame handling) | 1.49 | 1.37 | 1.42 | 1.29 | 2.00 | 1.90 | 1.53 |
| `mallocgc` | 0.31 | 0.23 | 0.04 | 0.07 | 0.47 | 0.25 | 0.05 |
| GC workers and assists | 0.53 | 0.29 | 0.02 | 0.01 | 0.43 | 0.22 | 0.04 |
| `selectgo` | 0.85 | 0.62 | 0.62 | 0.29 | 0.72 | 0.77 | 0.40 |
| scheduler (`runtime.schedule`) | 1.09 | 1.05 | 1.03 | 0.73 | 1.58 | 1.65 | 1.34 |
| leaf: thread park and wake (`__psynch_cv*`) | 1.84 | 1.70 | 1.55 | 1.26 | 1.90 | 1.82 | 1.45 |
| leaf: `sendmsg` | 7.69 | 7.80 | 8.06 | 6.51 | 4.45 | 4.41 | 3.65 |
| leaf: `recvmsg` | 1.74 | 1.81 | 1.80 | 1.50 | 4.40 | 4.22 | 3.59 |
| leaf: `kevent` (netpoll) | 1.34 | 1.35 | 1.37 | 1.04 | 2.22 | 2.14 | 1.66 |

¹ In `allwm` and `all` the pump calls the fork directly (the `s3` shape), so `pumpSends` absorbs the carrier sender's work.

What the table says:

- **System calls dominate this cell** (about 10.8 of 18.8 sender CPU-s/GiB, **measured** leaf sum), and they are per packet. The stream pays 15–25% less per GiB in every system-call leaf, consistent with its larger packets (the native stream fills packets up to its discovered size, at most the fork's 1,452 bytes, while a Datagram packet is 1,218 bytes, **source**: [#1814](https://github.com/GridSwarm/wiremux/blob/ed76d00647568523f6b9fad1804346a09f1db024/docs/research/issue-1814-datagram-gso.md#why-datagram-packets-are-never-full-size)), so it needs fewer of them. That part of the gap belongs to [#1819](https://github.com/GridSwarm/wiremux/issues/1819#issuecomment-6064664332) (Datagram ceiling 1,191 → 1,397 bytes at MTU 1500, about 15% fewer packets per GiB, **derived**: 1 − 1,191 / 1,397 = 14.7%), not to this ticket.
- **wiremux's two send hops** cost about 1.05 CPU-s/GiB directly (`Send` + `pumpSends` + carrier sender, including the fork's 0.19 inside the last), and they drive part of the GC (0.53), `mallocgc` (0.31), `selectgo` (0.85 against the stream's 0.29) and park/wake (1.84 against 1.26).
- **The receive side's wiremux cost** is `Datagrams.Receive`'s 0.99, of which the context plumbing is 0.21 directly plus its allocations and GC. Probe #2 takes `Receive` to 0.35 and halves receiver `mallocgc` and GC.
- **What `all` leaves** on the sender: one pump hop (0.21 plus the scheduling it causes), the fork's run-loop wake per Datagram, and `selectgo` still twice the stream's. That last part is the one queue the contract needs, and only the zero-hop design (#5) removes it.

### In-process hop benchmarks

To isolate the user-space chain from system calls, `BenchmarkDatagramSendChain` pushes Datagrams from `Datagrams.Send` through every wiremux hop into a fake connection that imitates the fork (copy into a frame, a bounded queue of 32, a "run loop" goroutine that copies into a packet buffer), and `BenchmarkDatagramReceive` calls `Datagrams.Receive` with a payload always ready (`bench/`, medians of 5, **measured**; CPU from `getrusage`, converted with 901,557 Datagrams per GiB, **derived**):

| Variant | Send chain CPU ns/Datagram | → CPU-s/GiB | allocs | Receive CPU ns/Datagram | → CPU-s/GiB | allocs |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| base | 3,305 | 2.98 | 6 | 809 | 0.73 | 6 |
| `s1` single root copy | 3,097 | 2.79 | 5 | | | |
| `s2` collapse carrier queue | 1,954 | 1.76 | 3 | | | |
| `s3` = `s1` + `s2` | 1,668 | 1.50 | 2 | | | |
| `s3b` one queue, contract shape | 1,677 | 1.51 | 4 | | | |
| `s4` + fork owns the copy | 1,313 | 1.18 | 1 | | | |
| `s5` + buffer recycling | 1,159 | 1.04 | 0 | | | |
| `r1` no second copy | | | | 522 | 0.47 | 5 |
| `r2` reuse the merged context | | | | 676 | 0.61 | 2 |
| `r1` + `r2` | | | | 360 | 0.32 | 1 |

The bench's base chain (2.98 CPU-s/GiB) includes the fake fork's copy and run-loop wake; removing one wiremux hop (`s2`) cuts it by 41%. The bench savings (1.48 for `s3`, 1.94 for `s5`, 0.41 for `r1` + `r2`, **derived** from the table) are the same size as the rig's (1.11, 1.68 and 1.00, **measured**). The send side saves more in the bench, where the hop is all there is; the receive side saves more in the rig, where the context and copy allocations feed a GC that the whole receiving process pays for.

## Probes and A/B

Each probe is a diff against 2599a002 (with the rig) in `probes/`; its built binary and exact applied diff are in `bin/<name>/`. Probes `s4`, `s5`, `s6` and `all` also need the fork scratch copy (`fork-probe/quic-go-fast`, patched by `probes/fork-owned-release*.diff`) through `probes/probe.mod`. `base-pf` is base built against that fork copy, and it measures the same as base (sender +0.03, receiver +0.02 CPU-s/GiB), so the fork patch alone is neutral.

| Probe | What it changes |
| --- | --- |
| `s1` | `Datagrams.Send` admits its framed copy without the queue copying it again (`Queue.AdmitOwned`) |
| `s2` | `DatagramCarrier.SendDatagram` calls the fork's `SendDatagram` directly; no carrier queue or sender goroutine |
| `s3` | `s1` + `s2` |
| `s3b` | For native carriers, `Send` admits its single copy straight into the carrier's queue (`SendDatagramOwned` → `AdmitOwned`), and the root pump is not started; the carrier keeps its sender goroutine |
| `s4` | `s3` + the carrier hands the owned buffer to a fork `SendDatagramOwned` (no fork copy) |
| `s5` | `s4` + the handle draws framed buffers from a 64-entry free list and the fork returns each one after `appendPacketPayload` serialized it |
| `s6` | `s5` + `Send` calls a non-blocking fork `TrySendDatagramOwned` under `gateMu` and waits on the fork's readiness channel when the queue is full; no wiremux queue or goroutine |
| `r1` | `Receive` returns `payload[1:]` of the carrier's caller-owned slice instead of copying it |
| `r2` | `Receive` keeps the merged context (`WithCancel` of the caller's context plus `AfterFunc` on the gate) while the caller passes the same context, instead of building one per call |
| `allwm`, `wmbest`, `all`, `s6all` | `s3` + `r1` + `r2`; `s3b` + `r1` + `r2`; `s5` + `r1` + `r2`; `s6` + `r1` + `r2` |

**Campaigns.** C1 (REPS=3) and C2 (REPS=4) each ran every build once per repetition, after one warm-up rotation that is excluded, with the order rotating every repetition so drift lands on every build alike (PROTOCOL.md's rotation rule on one host). Each run is an 8 s offer (`scripts/campaign.sh`, `scripts/pair.sh`). Before every run the driver read `load1` and waited 30 s whenever it exceeded 8; that happened 3 times in C1 and 5 times in C2, and the highest `load1` recorded at a run's start was 7.99. No run was flagged by PROTOCOL.md's rules (rate outside 0.8–1.2× its build's median, load above 8, failure). Loss was zero in all but five C1 and C2 runs: one base run lost 0.45% (C1 `r3-base`, 3,801 Datagrams) and four others lost at most 0.011%. Socket-buffer drops were zero in every run, so those losses happened above the receiver's socket, in the fork's queues, as in #1814. C1 and C2 medians agree within 0.1 CPU-s/GiB for every build (`pooled.txt`).

**A bimodal host mode.** Six of 95 non-warm-up `dgram` runs, spread over five different builds and both campaigns, delivered 1,100–1,112 Mbit/s instead of the usual 1,000–1,050, with 1.3–1.6 CPU-s/GiB less on *both* peers. The mode is a property of the run (probably thread placement on this host's performance and efficiency cores), not of the build: it hit base-equivalent receive-only builds too. With 3–4 runs per build it could swing a median, so the headline uses common-mode runs (≤ 1,060 Mbit/s); all-runs medians are in `pooled.txt` and change no ranking.

Pooled common-mode medians (**measured**):

| Build | n | Mbit/s | Sender CPU-s/GiB | Sender user | Receiver CPU-s/GiB | Receiver user | Loss |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base | 7 | 1,028 | 19.77 | 6.05 | 22.40 | 7.63 | 0 |
| `s1` | 6 | 1,023 | 19.39 | 5.69 | 22.37 | 7.59 | 0 |
| `s2` | 7 | 1,025 | 18.98 | 5.42 | 22.35 | 7.62 | 0 |
| `s3` | 6 | 1,022 | 18.66 | 5.15 | 22.22 | 7.60 | 0 |
| `s3b` | 6 | 1,023 | 18.66 | 5.11 | 22.24 | 7.57 | 0 |
| `s4` | 7 | 1,016 | 18.37 | 4.73 | 22.28 | 7.52 | 0 |
| `s5` | 7 | 1,009 | 18.09 | 4.42 | 22.37 | 7.58 | 0 |
| `r1` | 7 | 1,033 | 19.63 | 5.98 | 21.67 | 7.06 | 0 |
| `r2` | 7 | 1,029 | 19.66 | 6.05 | 21.90 | 7.07 | 0 |
| `r12` | 5 | 1,025 | 19.71 | 6.00 | 21.40 | 6.57 | 0 |
| `allwm` | 6 | 1,016 | 18.71 | 5.10 | 21.38 | 6.58 | 0 |
| `wmbest` | 4 | 1,030 | 18.58 | 5.10 | 21.34 | 6.60 | 0 |
| `all` | 7 | 1,017 | 17.97 | 4.40 | 21.35 | 6.58 | 0 |
| `stream` (base binary) | 7 | 1,158 | 15.38 | 3.69 | 18.22 | 5.52 | — |

### Zero-hop send (C3)

C3 measured the last wiremux hop: builds base, `s5`, `s6`, `all` and `s6all`, REPS=3 plus a warm-up rotation, same rules (two load waits, every run common-mode). Medians (**measured**, n=3 each):

| Build | Mbit/s | Sender CPU-s/GiB | Receiver CPU-s/GiB | Sender allocations per Datagram | Runs with loss (of 4, warm-up included) |
| --- | ---: | ---: | ---: | ---: | --- |
| base | 1,023 | 19.81 | 22.56 | 10.79 | 0 |
| `s5` | 1,012 | 18.06 | 22.35 | 4.73 | 0 |
| `s6` | 1,007 | 17.80 | 22.37 | 6.23 | 2 (0.43% in the warm-up, 0.22%) |
| `all` | 1,014 | 18.15 | 21.57 | 4.74 | 0 |
| `s6all` | 1,013 | 17.81 | 21.58 | 6.25 | 1 (0.51%) |

Taking the last queue and goroutine out saves another 0.26 sender CPU-s/GiB over `s5` (**measured**, same campaign). The probe understates it slightly: its non-blocking path still declares an escaping `errors.As` target and retries after a coalesced wake-up, which is why its allocations rise from 4.73 to 6.23 per Datagram. The loss is the open issue. Three of the eight zero-hop runs lost 0.22–0.51% of Datagrams, against one loss above 0.02% (the 0.45% base run above) in the roughly 130 other `dgram` runs across C1–C3, always with zero socket-buffer drops. Loss is not unique to the zero-hop shape, though: a 3 s smoke run of `s3b`, outside any campaign, lost 1.25%. With wiremux's 18 slots of buffering gone, `Send` feeds the fork's queue directly, and something above the receiver's socket or in the sender's packer discards Datagrams more often. These runs cannot say which; the fork's unprocessed-packet queue, its 128-entry DATAGRAM receive queue and the packer's discard branch each need a counter (the same gap as #1814's open question 4). Until that is explained, #5 is a candidate for the owner, not a recommendation.

## Contract analysis

The guarantees each candidate is judged against, as written today:

- **Public send** ([ADR-0009](../adr/adr-0009-optional-datagram-capability.md), "Senders block only until admission to a small bounded wiremux-owned queue and may cancel that wait with their context. wiremux copies the payload on admission."): bounded, cancellable, copied on admission, success means admission only.
- **Commit fence**: once the gate closes, no later `Send` may report success ([ADR-0009 transport seam](../adr/adr-0009-optional-datagram-capability.md#transport-seam-and-extraction-boundary); `datagramadmission`'s shared fence mutex, [`doc.go`](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/datagramadmission/doc.go#L1-L18)).
- **Public receive**: "each delivered message reaches exactly one caller as a fresh caller-owned slice", with no receive queue beyond the transport's.
- **Lower carrier**: `SendDatagram` and `ReceiveDatagram` unblock when their context ends or the carrier lifetime ends; `ReceiveDatagram` returns a caller-owned slice ([`connect/contracts.go` L146-L172](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/connect/contracts.go#L146-L172)).
- **Native Wire** ([`docs/COMPATIBILITY.md` L121](../COMPATIBILITY.md)): "sends admitted through a bounded cancellable queue to one sender that Close joins", ceiling fixed at promotion.
- **Per-datagram ingress admission** ([`docs/COMPATIBILITY.md` L103-L105](../COMPATIBILITY.md), #1784): every received datagram is admitted by the binding (cached verdict, kernel ingress per datagram). No candidate here touches the binding, the packet policy or `sendmsg`, so ingress admission is unchanged by all of them.

Per candidate:

- **#1 one queue (`s3b` shape): preserves as-is.** For a native Wire, the root handle stops running its own queue and pump and admits its single copy into the native carrier's queue, which is equally bounded (8), cancellable on the caller's context, and joined by `Promotion.Close` ([`promote.go` L508-L513](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L508-L513)). Two obligations for the real change: `Datagrams.end` must seal the carrier's queue (the commit fence moves with the queue; `Queue.Close` is already first-wins, and `Promotion.Close`'s later seal stays harmless), and owner-end must still fault the Wire, which it does because that queue's owner is the connection context, the same lifetime the root queue uses today. ADR-0009 justifies two queues because "root callers and direct `connect` callers must independently receive cancellable admission semantics". The native carrier has no direct `connect` callers (it is internal and reached only through `Promote`), so one queue serves its only audience. `transport/quic` keeps both queues, since its carrier is reachable through `connect.Upgrade`. No change to `COMPATIBILITY.md`; the L121 sentence stays true.
- **#2 receive without a second copy, with a reused context: preserves as-is.** The slice `Receive` returns is still fresh and caller-owned: it is the carrier's caller-owned slice (the fork copies every received frame into a new buffer), minus the envelope byte. No contract covers where the slice starts inside its allocation. The reused context gives the same cancellation: the caller's context and gate closure still cancel an in-flight wait. It holds one child registration on the caller's context between calls, released by the next call with a different context, by that context's end, or by gate closure. Both changes apply to every carrier, including `transport/quic`, whose own `ReceiveDatagram` builds a second per-call context ([`transport.go` L801-L810](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/transport/quic/transport.go#L801-L810)).
- **#3 fork owns the copy: preserves as-is.** wiremux still copies on admission; the fork just stops copying a second time. The ownership hand-off is internal: the admitted buffer is never touched by wiremux again.
- **#4 buffer recycling: preserves as-is**, with one internal discipline: a buffer returns to the free list only through the fork's release, after serialization. A frame the fork discards unsent (oversize at packing, connection close) is simply never released and is garbage-collected, so the free list must tolerate losses. The probe released right after `appendPacketPayload`; the fork's frame logging reads only the length, so nothing reads the data after release.
- **#5 zero-hop send: changes observable behavior.** It stays bounded, cancellable, copy-on-admission, and fenced (the gate mutex is held around each non-blocking enqueue, and `end` takes it). But the bound is now the fork's 32-entry DATAGRAM queue, not a wiremux-owned queue of 8 in front of up to 42 more slots, so `Send` blocks after 32 queued Datagrams instead of about 50 (**derived** from the capacities). ADR-0009's "small bounded wiremux-owned queue" and its QUIC-adapter paragraph ("one lifecycle-owned send worker … sole caller of quic-go's non-contextual `SendDatagram`") would need amending for native Wires, and `COMPATIBILITY.md` L121 ("a bounded cancellable queue to one sender that Close joins") would change to describe the connection's queue. Consumers would see less buffering and earlier back-pressure; no released consumer depends on the depth.
- **#7 pump calls the fork directly (`s2` shape): changes observable behavior** unless the fork offers a context-aware send. The fork's `SendDatagram` blocks on a full queue with no context ([`datagram_queue.go` L44-L69](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/datagram_queue.go#L44-L69)). When a terminal reliable read closes only the Datagram gate, `closeDatagramsFromReliableRead` drains the handle and joins the pump ([`wiremux.go` L738-L741](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/wiremux.go#L738-L741)) while the connection may still be alive. Today the pump waits in the carrier's cancellable `Admit` and returns at once. With `s2` it could sit in the fork's `Add` until the queue drains or the connection closes, up to the 30 s idle timeout if the peer stops acknowledging (**source**: `DefaultMaxIdleTimeout`, [`docs/COMPATIBILITY.md` L121](../COMPATIBILITY.md)), and the reliable `Read` that triggered the closure would wait with it. That breaks the lower carrier's "unblocks when its context ends" rule. #1 gets the same saving without this hazard, which is why #1 ranks first.
- **#8 `errors.As` escapes: preserves as-is** (check `err != nil` before declaring the target).
- **Rejected: a borrowed-buffer receive.** A fork receive that lends the packet buffer instead of copying would save the fork's copy only if wiremux's public `Receive` stopped returning a fresh caller-owned slice. That breaks ADR-0009's receive guarantee for one copy; wiremux would have to copy again to keep the contract, which saves nothing.

## Fork changes and API sketches

None of these is implemented in the fork; the throwaway versions are in `probes/fork-owned-release*.diff`. They belong in the-sarge/quic-go-fast's tracker.

1. **Ownership-taking send (for #3 and #4).**
   ```go
   // SendDatagramOwned queues p without copying it. The connection owns p
   // from the call on. If release is non-nil, it is called with p exactly
   // once, on the connection's run loop, after p's bytes have been
   // serialized into a packet; a frame discarded unsent is never released.
   // release must not block.
   func (c *Conn) SendDatagramOwned(p []byte, release func([]byte)) error
   ```
   The release point must follow serialization, not the packer's `Pop`: `composeNextPacket` pops the frame before `appendPacketPayload` writes it ([`packet_packer.go` L648-L663](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/packet_packer.go#L648-L663), [L974-L980](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/packet_packer.go#L974-L980)). Equal-size GSO batching ([quic-go-fast#743](https://github.com/the-sarge/quic-go-fast/issues/743)) packs several frames per send; release per frame still works.
2. **Non-blocking send with a readiness signal (for #5), or a context-aware send (to make #7 safe).**
   ```go
   // TrySendDatagramOwned queues p if the DATAGRAM send queue has room and
   // reports whether it did; it never blocks.
   func (c *Conn) TrySendDatagramOwned(p []byte, release func([]byte)) (queued bool, err error)
   // DatagramSendSpace returns a channel that is closed once the send queue
   // next gains room. Each call may return a new channel.
   func (c *Conn) DatagramSendSpace() <-chan struct{}

   // Alternative: SendDatagramContext is SendDatagramOwned whose wait for
   // room also ends when ctx ends.
   func (c *Conn) SendDatagramContext(ctx context.Context, p []byte, release func([]byte)) error
   ```
   The probe reused the queue's existing capacity-1 `sent` channel as the readiness signal, which is enough for one sender; several concurrent senders need a broadcast, hence a closed-channel shape.
3. **Smaller fork-internal items, no API.** The packer allocates a frames slice per DATAGRAM packet; `parseDatagramFrame` allocates a frame struct per received frame; `HandleDatagramFrame`'s `rcvQueue = rcvQueue[1:]` regrows its slice. Each is about one allocation per Datagram (allocation profile).

## Off-hours confirmation

Not run. Both use the same three builds, prepared once by hand (each is a detached worktree at 2599a002 plus the rig; nothing is committed):

```sh
W=/Volumes/worktrees/wiremux; E=$W/native-gap-evidence/1823-dgram-cost
R=/Users/josh/code/github.com/GridSwarm/wiremux; S=2599a00292c70c9871794ce62a1266741d71d42a
for x in A B C; do
  git -C "$R" worktree add --detach "$W/1823-off-$x" "$S"
  git -C "$W/1823-off-$x" checkout origin/codex/native-gap-rig -- cmd/nativerig
  git -C "$W/1823-off-$x" apply "$E/rig-memstats.diff"   # optional: allocation counters
done
git -C "$W/1823-off-B" apply "$E/bin/wmbest/applied.diff"  # B: #1 + #2, wiremux only
git -C "$W/1823-off-C" apply "$E/bin/all/applied.diff"     # C: #1-#4 + #2, with the fork probe
cp "$E/probes/probe.mod" "$W/1823-off-C/cmd/nativerig/probe.mod"
cp "$W/1823-off-C/cmd/nativerig/rig.sum" "$W/1823-off-C/cmd/nativerig/probe.sum"
cp "$W/native-gap-evidence/1814-dgram-gso/rig_mod.sh" "$W/1823-off-C/cmd/nativerig/rig_mod.sh"  # rig.sh with a MODFILE override
```

The applied diffs touch only tracked wiremux files, so they combine with the rig and `rig-memstats.diff`. Build C's fork copy now also carries the unused `TrySendDatagramOwned` from the `s6` probe; `all` does not call it.

**`tb` (mbp128 `bridge0` → m4mini over Thunderbolt, 22:00–07:00 ET, not across Wednesday 05:17 ET).** A/B/C alternated twice, each a full campaign with the standard slate, so every campaign carries its own baseline (PROTOCOL.md):

```sh
ARMS=(dgram=dgram stream=stream udp=udp 'udp4=udp -sockets 4' binding=binding)
for round in 1 2; do
  (cd "$W/1823-off-A" && REPS=3 cmd/nativerig/rig.sh tb "$E/tb-A$round" "${ARMS[@]}")
  (cd "$W/1823-off-B" && REPS=3 cmd/nativerig/rig.sh tb "$E/tb-B$round" "${ARMS[@]}")
  (cd "$W/1823-off-C" && MODFILE=cmd/nativerig/probe.mod REPS=3 cmd/nativerig/rig_mod.sh tb "$E/tb-C$round" "${ARMS[@]}")
done
```

This confirms the ranking if the pooled `dgram` sender and receiver CPU-s/GiB of B and C fall below A by roughly this note's deltas (B: about 1.2 and 1.1; C: about 1.8 and 1.05), with `stream`, `udp` and `binding` unchanged between builds and `dgram` throughput within a few percent (the `tb` sender is `sendmsg`-bound at about 133k packets/s, **source**: [#1797](issue-1797-native-packet-size.md#the-packets-per-second-premise)). For attribution, add one profiled run per build outside the campaigns, recording each host with `xctrace record --template 'Time Profiler' --all-processes --time-limit 20s` around a by-hand `nativerig` pair and summarizing with `scripts/xtsum.py` (not `-cpuprofile`, see [Method](#method-gos-profiler-cannot-attribute-this-on-macos)).

**minimax netns (off-hours, after the owner's one-time namespace setup in [the shape-cell decision](https://github.com/GridSwarm/wiremux/issues/1794#issuecomment-6064330111)).** `rig.sh` has no `netns` cell yet, so these run by hand; Linux `-cpuprofile` is accurate, so profiles come from the rig directly. Build linux/amd64 binaries:

```sh
for x in A B; do (cd "$W/1823-off-$x" && GOOS=linux GOARCH=amd64 GOFLAGS=-mod=mod go build -trimpath -modfile=cmd/nativerig/rig.mod -o "$E/linux/$x/nativerig" ./cmd/nativerig); done
(cd "$W/1823-off-C" && GOOS=linux GOARCH=amd64 GOFLAGS=-mod=mod go build -trimpath -modfile=cmd/nativerig/probe.mod -o "$E/linux/C/nativerig" ./cmd/nativerig)
ssh minimax 'mkdir -p /tmp/nr1823' && scp -r "$E/linux/A" "$E/linux/B" "$E/linux/C" minimax:/tmp/nr1823/
```

Then on minimax, with sender and receiver pinned to different CCDs (confirm the core map with `lscpu -e` first; `0-7` and `8-15` below assume CCD0 and CCD1), GRO left off and recorded, alternating A, B, C twice for `dgram` and `stream`:

```sh
cd /tmp/nr1823
for round in 1 2; do for x in A B C; do for arm in dgram stream; do
  d=runs/$x-$arm-$round; mkdir -p "$d"
  cat /proc/loadavg > "$d/load"; lscpu -e > "$d/lscpu"
  sudo ip netns exec nr-send ethtool -k nr-s > "$d/send.ethtool"; sudo ip netns exec nr-recv ethtool -k nr-r > "$d/recv.ethtool"
  sudo ip netns exec nr-recv grep Udp: /proc/net/snmp > "$d/recv.udp.before"
  sudo ip netns exec nr-recv sudo -u josh taskset -c 8-15 timeout 60 ./$x/nativerig recv -arm $arm -iface nr-r -port 47823 -cpuprofile "$d/recv.pprof" > "$d/recv.json" 2> "$d/recv.err" &
  sleep 2
  sudo ip netns exec nr-send sudo -u josh taskset -c 0-7 timeout 40 ./$x/nativerig send -arm $arm -iface nr-s -target 10.77.0.2:47823 -seconds 10 -cpuprofile "$d/send.pprof" > "$d/send.json" 2> "$d/send.err"
  wait
  sudo ip netns exec nr-recv grep Udp: /proc/net/snmp > "$d/recv.udp.after"
done; done; done
pgrep -fl nativerig || true
```

Copy `/tmp/nr1823/runs` back into the evidence directory afterwards.

This confirms the Linux shape if base `dgram` reproduces #1814's roughly 4× sender CPU-s/GiB against `stream`, B and C cut `dgram` CPU by at least this note's deltas (Linux has no `setitimer` bias and no loopback delivery inside `sendmsg`, so the per-Datagram share should be larger), and #1814's `profsum.py` buckets (`pumpSends`, `DatagramCarrier.send`, GC, scheduler) shrink accordingly. First check that a `binding` run admits the veth peer (Local mode needs a LAN-classified interface; #1814's Docker `eth0` was). An optional fourth build D, the fork scratch copy with both #1814's `probe.diff` (equal-size GSO) and this note's fork patch, would show whether the per-Datagram savings turn into throughput once Datagram GSO removes the per-packet `sendmsg`.

## Corrections to the ticket's premises

- **Four send copies, not three.** The root handle copies twice (envelope prepend in `Send`, then `Queue.Admit`'s own copy), before the carrier's copy and the fork's.
- **"About 3.3 CPU-s/GiB per Datagram" is not all wiremux's to remove.** #1814 derived it from Docker profiles as hand-off + GC + scheduling above the stream's. On this cell the comparable xctrace sum is about 3.1 (**derived**: hops 1.05 + GC 0.52 + extra `selectgo` 0.56 + extra park/wake 0.58 + extra scheduling 0.36), and the A/B shows wiremux alone removes about 1.1 of it on the sender, 1.8 with the fork changes. The rest is the one queue and copy the contract needs, the fork's per-frame work, and per-packet costs.
- **The receive path has no wiremux goroutine hop.** The receiver's wiremux cost is the per-call context (WithCancel + AfterFunc, about 4.5 allocations) and the redundant copy, not a hand-off.
- **macOS profiling.** The rig's profiling rule (`-cpuprofile`) attributes per-hop cost wrongly on macOS (see [Method](#method-gos-profiler-cannot-attribute-this-on-macos)); `tb` attribution needs `xctrace`.

## Open questions and suggested tickets

1. **(wiremux, new) Per-packet receive allocations in the binding.** About 2.3 allocations per received packet come from the binding's receive path: `ReadMsgUDP` returns a fresh `*net.UDPAddr` and `admitReceived` makes a private copy ([`unicast.go` L935, L952-L982](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L935-L982)). They are per packet, so they cost the stream as much as Datagrams, and they are outside this ticket's per-Datagram scope. Sharp question: can the binding read with `ReadMsgUDPAddrPort` and hand the fork an address without allocating, keeping per-datagram ingress admission?
2. **(fork, new) Per-packet receive policy re-marshals the control message.** The fork's `packetPolicyConn.allowsReceive` rebuilds the received control message for every packet (`packetInfo.OOB` → `ipv4.ControlMessage.Marshal`, about 2.2 allocations per packet, [`packet_policy.go` L57-L73](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/packet_policy.go#L57-L73)).
3. **(fork, new) The DATAGRAM send APIs above** (ownership, release, non-blocking or context-aware send), packaged with #743 since both touch the packer.
4. **(owner decision) Zero-hop send.** Whether native Wires may make the fork's 32-entry queue the admission bound (#5), which amends ADR-0009 for native Wires.
5. **(rig) PROTOCOL.md's profiling rule** should name `xctrace` for macOS cells; this note's `scripts/xprof.sh` and `scripts/xtsum.py` are a starting point.

## Evidence

Everything is outside the repository under `/Volumes/worktrees/wiremux/native-gap-evidence/1823-dgram-cost/`:

- `README.txt` describes the directory.
- `C1/`, `C2/`, `C3/` (with `C1.log`, `C2.log`, `C3.log`): the rotating campaigns, each with `meta.txt`, `summary.txt`, `waits.log` and one directory per run (`send.json`, `recv.json` with allocation counters, UDP counters before and after, `load`). `pooled.txt` is `scripts/pool.py C1 C2`.
- `bin/<build>/`: every binary measured, with its exact `applied.diff` and `recipe`.
- `probes/`: the throwaway probe diffs, the fork patches and `probe.mod`; `fork-probe/quic-go-fast/` is the patched scratch copy of the fork (a local git repository; its first commit is the pristine module).
- `xprof/`: the `xctrace` recordings, their exports, `xtsum.txt` and `xtcompare.txt`; `prof/`: the biased Go `-cpuprofile` runs kept for the method comparison; `mprof/`: allocation profiles and `mprof-top.txt`.
- `bench/`: the in-process benchmarks, per-variant output and `summary.txt`.
- `scripts/`: `pair.sh`, `campaign.sh`, `an.py`, `pool.py`, `xprof.sh`, `xtsum.py`.
- `rig-memstats.diff`: the evidence-only rig extension (allocation counters, `-memprofile`).
- `smoke/`: smoke runs, not evidence.
