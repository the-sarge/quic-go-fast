# Issue #1797: how much throughput larger packets buy the native path

Planning research for [#1797](https://github.com/GridSwarm/wiremux/issues/1797) on the wayfinder map [#1794](https://github.com/GridSwarm/wiremux/issues/1794). It answers how much throughput larger UDP packets could buy wiremux's native QUIC path, and what stands in the way on each kind of link. Nothing here implements a change or alters any host setting: no interface MTU, sysctl or host configuration was touched, and jumbo-frame effects are estimated from sources, arithmetic and loopback, never measured on a jumbo link.

Sources are wiremux at `origin/main` b494e711, the quic-go-fast fork at the exact version the native path uses (`v0.62.1-fast.7`, tag object 48a2b32e; the native path requires the fork, see [`capability.go`](../../internal/nativequic/capability.go#L1-L9)), upstream quic-go, the RFCs, vendor documentation, and measurements on the `tb` cell taken for this note. Every derived number is marked **derived** with its arithmetic.

## Summary

Larger packets are the one lever that cuts per-packet work in every layer at once (QUIC packing, sealing and acknowledgment, wiremux admission, system calls, kernel, driver). The Thunderbolt measurements below confirm the premise: inside an MTU of 1500, delivered packets per second stay roughly flat from 256 to 1,472-byte payloads, and the native Datagram arm delivers the same 133k packets/s at 600 bytes as at 1,191 bytes, so its throughput is set by packet count, not bytes. On loopback, raw UDP holds about 190–210k packets/s from 1,472 up to 8,972 bytes.

The gain is real only where an operator runs jumbo frames end to end, which in practice means a Thunderbolt bridge, a data-center LAN, or traffic that stays inside one cloud VPC. It is zero on Wi-Fi, the internet, tunnels and TURN relays. Two small gains are available on ordinary MTU-1500 links too.

| Link | Largest usable UDP payload (IPv4 / IPv6) | Packet-rate regime | Native throughput today → estimate | What blocks it |
| --- | --- | --- | --- | --- |
| Thunderbolt bridge, macOS, as configured today (MTU 1500) | 1,472 / 1,452 | about 133k packets/s, per-packet bound (measured) | stream 1.39–1.46 Gbit/s → about 1.5 (**+3%**); Datagrams 1.21–1.27 → about 1.42–1.49 (**+14–17%**) | the discovery stall at about 1,400 bytes (stream); the fixed 1,192-byte Datagram cap, and when the ceiling is read (Datagrams) |
| Thunderbolt bridge, macOS, MTU 9000 (an operator setting; the valid range is 1280–65518) | 8,972 / 8,952 | about 58–106k packets/s (**derived**) | stream and Datagrams **about 4.1–7.6 Gbit/s** (**derived**, 2.8–6× today); TCP reference 14.6 | fork packet-size cap; DPLPMTUD reach; Datagram ceiling; operator MTU on both Macs |
| 10/25 GbE data-center LAN, Linux, MTU 9000 | 8,972 / 8,952 | unmeasured (no owned Linux hardware, #1799) | Datagrams: per-packet bound in the Docker shape (215k packets/s, no offload) so they should scale like macOS, up to the link; stream: already offloaded (GSO, 7.8 Gbit/s in Docker), so the gain is smaller and unestimated | the same three, plus #1799 to measure |
| Cloud VPC, same region | AWS 8,973 (MTU 9001); GCP at most 8,868 (MTU 8896); Azure 8,972 with MANA (MTU 9000), 3,872 with Mellanox (MTU 3900) | as Linux | capped by per-flow limits: AWS 5 Gbit/s per flow outside a cluster placement group, 10 inside, 25 with ENA Express | the same three; leaving the VPC drops to 1500 |
| Typical Wi-Fi or home LAN, MTU 1500 | 1,472 / 1,452 | per-packet | the MTU-1500 gains only (+3% stream, +14–17% Datagrams) | as row 1 |
| Internet path | 1,472 / 1,452 typical; floor 1,252 / 1,232 at the IPv6 1280 minimum | per-packet | none beyond the MTU-1500 gains | the path |
| Tunnels and VPNs (WireGuard 1420 default, Tailscale 1280) | at most 1,392 / 1,372 (WireGuard); 1,252 / 1,232 (Tailscale) | per-packet | none; possibly below today's stream size | the path |
| TURN relay (`wiremux-quic/3`) | fixed 1,200-byte packet class, Datagram 1,160 lower / 1,159 public | n/a | none, by design | ADR-0012's fixed, discovery-off profile; the native path never uses TURN |

The changes, in the order they would have to land (detail under [Changes each step needs](#changes-each-step-needs)):

1. **wiremux + fork, diagnosis only:** find why native path MTU discovery stops at about 1,400 bytes on `bridge0` when the path carries 1,472-byte DF datagrams. Worth +3% to the stream at MTU 1500, and a prerequisite, because the same discoverer would have to climb to 9,000.
2. **Fork change, no wiremux contract:** make the 1,452-byte packet ceiling configurable (receive buffers, pools, the advertised `max_udp_payload_size`, the discovery ceiling and the BBR invariants), keeping 1,452 as the default.
3. **Fork change:** black-hole detection, meaning DPLPMTUD that can shrink after a path change (RFC 8899 §4.3). Today it never shrinks, and with jumbo sizes a path change would stall the connection until the idle timeout.
4. **wiremux, internal only:** set the native profile's discovery ceiling from the bound interface's MTU. The stream gain arrives here with no contract change.
5. **wiremux, contract-sensitive:** lift the fixed 1,192-byte Datagram cap and read the native Datagram ceiling *after* discovery completes, instead of at promotion. The ceiling stays lifetime-fixed per Wire, so ADR-0009 holds, but the exported `MaxNativeDatagramPayload` constant (1,191) changes meaning or value. There are no real users yet, so this is a discipline choice that needs a `docs/COMPATIBILITY.md` entry, not an obligation.
6. **Operator, not code:** MTU 9000 on both Thunderbolt bridges (or the LAN, or the VPC).

Admission (#1784) and the relay need no change.

## Today's packet sizes on the Thunderbolt pair

> **Correction (2026-10-08, [#1818](https://github.com/GridSwarm/wiremux/issues/1818)):** discovery does not stall. Both peers reach 1,438 within 16–91 ms and no probe is lost. The 1,397–1,400 figures below are mean sizes, pulled down by one 4-byte-header packet and one tail packet per 64 KiB Wire record. See [`issue-1818-mtu-discovery-stall.md`](issue-1818-mtu-discovery-stall.md). The ~3% cost stands, but its cause is packetisation.

The native profile configures a 1,232-byte initial packet size and leaves path MTU discovery on: [`endpoint.go`](../../internal/nativequic/endpoint.go#L26-L27) and the server and client configs at [L638-L660](../../internal/nativequic/endpoint.go#L638-L660), which set no `DisablePathMTUDiscovery`. The fork starts its MTU discoverer only when the connection reports DF ([`connection.go` L1044-L1046](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L1044-L1046)). The native `packetConn` exposes `SyscallConn` for option control ([`packetconn.go` L120-L124](../../internal/nativequic/packetconn.go#L120-L124)), so the fork's `setDF` sets `IP_DONTFRAG` on the IPv4 binding ([`sys_conn.go` L88-L100](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn.go#L88-L100), [`sys_conn_df_darwin.go` L21-L43](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_df_darwin.go#L21-L43)), and discovery runs.

Exact on-wire sizes come from two counters the rig already records: macOS `netstat -s -p udp` reports datagrams *and bytes* "checksummed in software" over IPv4, and `netstat -I bridge0 -b` (added in this note's sweep) reports interface bytes. In the 2026-10-08 baseline (`native-gap-evidence/2026-10-08-tb-standard`) and this note's sweep:

| Arm | UDP length (counter) | UDP payload | Interface frame | Application bytes per packet |
| --- | --- | --- | --- | --- |
| `dgram` (1,191-byte Wire maximum) | 1,226.1 | 1,218 | 1,260.0 | 1,191 |
| `dgram -size 600` | 635.1 | 627 | 669.1 | 600 |
| `stream` | 1,403.6–1,404.3 (mean) | about 1,396 mean; 1,397 then 1,400 | 1,437 rising to 1,441 over a run | 1,364–1,365 |
| `udp`, `binding` (default `-size 1452`) | 1,460.0 | 1,452 | 1,494 (**derived**: 1,460 + 20 IPv4 + 14 Ethernet) | 1,452 |
| receiver ACKs during `stream`/`dgram` | 45.6–45.8 | about 38 | | about 0.31 per data packet |

The Datagram packet is exactly the QUIC arithmetic (**derived**): 1 type byte + 4-byte destination connection ID (the fork's `DefaultConnectionIDLength`, [`params.go` L130-L132](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/protocol/params.go#L130-L132)) + 2-byte packet number + 3 bytes of DATAGRAM type and length + 1,192 lower payload + 16-byte AEAD tag = 1,218. The 1,192 is lifetime-fixed ([`promote.go` L19-L25](../../internal/nativequic/promote.go#L19-L25)), less the one-byte wiremux envelope gives the 1,191 public maximum ([`native_promotion.go` L21-L25](../../native_promotion.go#L21-L25)).

**The stream does not reach the size discovery should find.** quic-go's discoverer is a binary search from the initial size to a ceiling of `MaxPacketBufferSize` = 1,452 (or the peer's smaller `max_udp_payload_size`), one probe every 5 smoothed RTTs, stopping when the bracket is within 21 bytes ([`mtu_discoverer.go` L13-L23, L125-L160](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/mtu_discoverer.go#L13-L160); ceiling wiring at [`connection.go` L2577-L2586](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2577-L2586)). A faithful re-implementation of that search, run against a path that carries everything up to 1,472 bytes, probes 1,342, 1,397, 1,424 and 1,438, and settles at **1,438** (**derived**). The measured stream packets instead sit at about 1,397 early in a run and 1,400 later. The same simulation reproduces that trajectory exactly when every probe of 1,403 bytes or more is lost: 1,342 ack, 1,397 ack, 1,424 lost, 1,410 lost, 1,403 lost, 1,400 ack, 1,412 lost, then stop: seven probes, four lost, with the final bracket of 1,400–1,412 inside the 21-byte stop rule.

The path is not the cause. A DF ladder (`tb-df-ladder/`, 50 datagrams at each even size from 1,380 to 1,472, `IP_DONTFRAG` on and off) delivered every datagram at every size in both modes. Each native run also shows 8–21 packets counted out of the sender's interface and never counted into the receiver's, against zero in the delivered-data accounting, which fits lost probes. The loss therefore happens inside the native stack (probe emission, the binding, or the receive side), not on the wire. The root cause is left to a follow-up (see [Open questions](#open-questions-for-later-tickets)). The cost today is small, about 3% of stream goodput (**derived**: (1,438 − 35) / (1,400 − 35) = 1.028, where 35 bytes is 23 of QUIC header and tag plus about 12 of STREAM frame header). But it matters for jumbo frames, because the same search has to climb to 9,000.

Even an ideal search stops short of the ceiling: `maxMTUDiff` of 20 means 1,438, never 1,452, at MTU 1500.

## The packets-per-second premise

The ticket assumes macOS delivers a roughly fixed number of packets per second, so bytes per packet multiply throughput. Three measurements test that directly. They are not headline campaigns: mbp128's load1 was 9–49 during them (GARM VMs, `fseventsd`, `mediaanalysisd`), above the protocol's `MAXLOAD` of 8. Their rates were nonetheless at or above the 07:30Z baseline, and every run is kept under `native-gap-evidence/1797-size-sweep/`.

**Raw UDP over Thunderbolt, MTU 1500** (`tb-udp-size/`, 3 × 10 s per size, receiver medians):

| Arm | Payload | Delivered packets/s | Mbit/s |
| --- | --- | --- | --- |
| 1 socket | 256 | 116k (114k–164k) | 238 |
| 1 socket | 512 | 129k | 528 |
| 1 socket | 1,024 | 128k (103k–128k) | 1,045 |
| 1 socket | 1,472 | 146k (132k–158k) | 1,723 |
| 4 sockets | 512 | 168k | 690 |
| 4 sockets | 1,472 | 160k | 1,881 |

The single socket's receive ceiling is flat within noise from 256 to 1,472 bytes, and the four-socket arm shows a receiver-interface ingest ceiling of about 160–170k packets/s that does not move between 512 and 1,472 bytes. Its loss is on the "wire" counter: the sender offers about 275–285k packets/s and the receiving `bridge0` takes in about 160–170k.

**Native over Thunderbolt** (`tb-native-size/`, 2 × 10 s): `dgram` 1,268–1,274 Mbit/s at 133.1k–133.7k packets/s; `dgram -size 600` 640 Mbit/s at 133.3k packets/s; `stream` 1,458 Mbit/s at 133.5k–133.6k packets/s. The full-size `dgram` and `stream` runs lost nothing. The two 600-byte runs lost 2,025 and 633 Datagrams (0.152% and 0.047%; 1,335,552 sent against 1,333,527 received, and 1,334,144 against 1,333,511), alongside receive socket-buffer drops. These small losses do not change the packet-rate conclusion. Halving the Datagram size halved the throughput and left the packet rate unchanged to within 0.1%. The native path is per-packet bound at about 133k packets/s, which is above the ticket's "~100k/s".

**Raw UDP on loopback `lo0`** (`lo0-udp-size/`; loopback, MTU 16384, *not link evidence*): 1,472 bytes ran at 208.6k–208.9k packets/s (2.46 Gbit/s), 4,072 bytes at 196.4k–208.4k (6.4–6.8 Gbit/s), and 8,972 bytes at 186.7k–199.8k (13.4–14.3 Gbit/s), with zero loss. The receiver used 5.0–5.4 CPU-s per 8 s run at every size. The kernel's UDP path is per-packet bound well past 9,000 bytes.

### Where per-byte cost takes over

Per-byte work does grow with size. On `bridge0` both peers compute UDP checksums in software, despite the interface advertising `RXCSUM,TXCSUM,TSO4,TSO6` (those offloads serve TCP). In `r2-dgram`, 1,255,916 IPv4 datagrams were "checksummed in software" on output and 1,255,913 on input, matching the datagrams sent. QUIC 1-RTT protection here is AES-128-GCM, which Go's TLS 1.3 prefers when AES-GCM assembly is available (`hasAESGCMHardwareSupport` includes arm64, Go 1.27.1 `crypto/tls/cipher_suites.go` L368). A Go 1.27.1 microbenchmark on mbp128 sealed at 7.1 GB/s for 1,200 bytes and 8.7 GB/s for 9,000 bytes, 1.03 µs per 9,000-byte packet (ChaCha20-Poly1305 1.1–1.2 GB/s; in-cache `copy` about 100 GB/s).

Two bounds on the per-byte coefficient *b*:

- **Floor (**derived**, components):** AES-GCM 0.115 ns/B, plus software checksum and the uncached copies (not measured separately; about 0.1 ns/B assumed) gives **b ≈ 0.25 ns/B**.
- **Ceiling (**derived**, measured, noisy):** total CPU per packet from the native campaign. Sender: 16.07 CPU-s/GiB at 1,191 B is 17.8 µs per packet, and 30.51 at 600 B is 17.05 µs. Receiver: 22.2 and 21.6 µs. The slope (17.8 − 17.05) µs / (1,218 − 627) B gives about 1.3 ns/B on the sender and 1.0 ns/B on the receiver. This is total CPU across all threads, inflated by host load, and it includes per-datagram allocation (each delivered Datagram is a fresh caller-owned slice, ADR-0009), so it is an upper bound.

Per-packet cost is about 17–22 µs of total CPU across all threads, or 7.5 µs on the serialized bottleneck (**derived**: 1 / 133.4k packets/s). The estimate below uses only the serialized frame. In that frame, per-byte cost equals the fixed per-packet cost *t₀* at about 4.4–28.6 KB (**derived**: *t₀* / *b* = 5.68 µs / 1.3 ns/B and 7.15 µs / 0.25 ns/B, from the model below). At an 8,956-byte packet, per-byte work is 2.2–11.6 µs. That is below the fixed cost at the optimistic end, but above it at the pessimistic end (11.6 against 5.68 µs), which is why the estimate's range is wide. In the aggregate-CPU frame, the 1.3 ns/B slope against 17 µs gives about 13 KB; the two frames are not mixed.

### Estimated throughput at MTU 9000 (Thunderbolt, IPv4)

Model (**derived**): the bottleneck time per packet is *t* = *t₀* + *b*·*S*. Today *t* = 7.50 µs at *S* ≈ 1,397, so *t₀* = 7.15 µs (b = 0.25) or 5.68 µs (b = 1.3). At *S* = 8,956, the size an ideal search reaches under an 8,972 ceiling, *t* is 9.39 or 17.3 µs, giving 106.5k or 57.7k packets/s.

- Stream: 8,956 − 35 = 8,921 application bytes per packet, so **4.1–7.6 Gbit/s** against 1.39–1.46 today.
- Datagrams: 8,956 − 37 − 3 = 8,916 lower, 8,915 public payload under wiremux's current derivation (the fork's uncapped probe itself would report 8,956 − 37 = 8,919; see [obstacle 3](#3-the-lifetime-fixed-datagram-ceiling)), so **4.1–7.6 Gbit/s** against 1.21–1.27 today.
- Packets per GiB fall 6.5× for the stream (786.6k to 120.4k) and 7.5× for Datagrams (901.6k to 120.4k). ACK packets fall by the same factor.

The ticket's "≈7 Gbit/s" is the optimistic end of this range. Nothing measured caps it lower: the receiving interface ingested 160–170k packets/s at 1,472 bytes (its behavior at 9,000 bytes is unmeasured), loopback carried 13.4–14.3 Gbit/s at 8,972 bytes, and TCP reaches 14.6 Gbit/s on this link. Header efficiency is not the source of the gain (97.7% today, 99.6% at 8,956); the packet count is.

## Obstacles, in order

### 1. The fork's packet-size cap

`MaxPacketBufferSize = 1452` ([`protocol.go` L107-L111](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/protocol/protocol.go#L107-L111)) is not just the discovery ceiling. The same constant sizes or guards:

- the receive read buffers, which truncate anything larger ([`sys_conn.go` L141-L143](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn.go#L141-L143), `sys_conn_oob.go` L224, `sys_conn_windows.go` L172-L175)
- the advertised `max_udp_payload_size` ([`connection.go` L353, L483](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L353))
- the discovery ceiling on every path reset (L968-L975, L1345-L1355, L2577-L2586)
- the clipping of `InitialPacketSize` ([`config.go` L86-L91](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/config.go#L86-L91))
- the packet buffer pool (`buffer_pool.go` L71, L114), the STREAM frame pool (`internal/wire/pool.go` L14) and STREAM frame splitting (`send_stream.go` L351, L477-L491, L713-L717)
- the coalesced receive slab (`coalesced_slab.go` L122)
- BBR, which panics on a larger size ([`internal/congestion/bbr_sender.go` L86-L88](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/congestion/bbr_sender.go#L86-L88), [`bbr_send_policy.go` L31](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/bbr_send_policy.go#L31))

The GSO and batch buffer is `MaxLargePacketBufferSize = 20 KiB` (`protocol.go` L113-L114, used at `packet_emission_bbr.go` L145): 14 segments at 1,452 bytes, but only 2 at 8,952.

Upstream quic-go has the same constant at v0.62.0 and on its default branch. [quic-go#3162](https://github.com/quic-go/quic-go/issues/3162) ("Allow customization of MaxPacketBufferSize", open since 2021) has the maintainer willing to review a PR while noting it must be wired into `max_udp_payload_size`. [#4553](https://github.com/quic-go/quic-go/issues/4553) is open. [#5863](https://github.com/quic-go/quic-go/issues/5863) was closed unread in 2026-09. [#3385](https://github.com/quic-go/quic-go/issues/3385) was closed after `InitialPacketSize` landed, which only lowers or pins the size within 1,452. The fork has no issue for a larger cap (searched "jumbo", "MaxPacketBufferSize", "packet size"). Raising the cap is therefore a fork change.

One memory note for the design: pooled packet buffers grow by the cap ratio (6.2× at 9,000), so separate small and large pools, or sizing receive buffers to the advertised value, is preferable to a bigger constant.

### 2. DPLPMTUD reach

RFC 9000 §14.3 maps QUIC onto DPLPMTUD (RFC 8899) and §14.4 makes probes ack-eliciting, with probe loss not treated as congestion. The fork honors that ([`ackhandler/packet.go` L24](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/packet.go#L24)). RFC 8899 §5.1.2 bounds `MAX_PLPMTU` by the local interface MTU and recommends `MAX_PROBES` = 3, which the fork's `maxLostMTUProbes` matches. The search simulated against the fork's exact logic (**derived**):

| Ceiling | Path | Result |
| --- | --- | --- |
| 1,452 (today) | 1,472 | 1,438 after 4 probes |
| 8,972 | 8,972 (MTU 9000 IPv4) | 8,956 after 9 probes, none lost |
| 8,952 | 8,952 (MTU 9000 IPv6) | 8,936 after 9 probes |
| 8,972 | 1,472 (a 1500 hop) | 1,472 after 23 probes, 14 lost |
| 65,527 | 8,972 | 8,972 after 23 probes, 15 lost |

At 5 smoothed RTTs per probe, nine probes on a sub-millisecond LAN take tens of milliseconds. A ceiling set far above the real path, such as 65,527, costs about 20 probes and many losses, so the ceiling should come from the bound interface's MTU, which a native binding knows. The peer's `max_udp_payload_size` (RFC 9000 §18.2, "a property of the endpoint and not the path") must also be raised, because it caps the sender.

The fork has no shrink path. `OnLost` only narrows the search, and once a size is acknowledged `min` never falls; the only reset is path migration (`connection.go` L968-L975, L1345-L1355). RFC 8899 §4.3 requires black-hole detection. Upstream [#3955](https://github.com/quic-go/quic-go/issues/3955) ("PMTU reduction causes packet loss") is open. At 1,452 bytes this rarely matters. At 9,000 bytes, any later hop at 1500 would stall a connection until its 30 s idle timeout.

The handshake must keep starting at 1,232. The fork's handshake MTU fallback only reacts to *local* send-size errors ([`connection.go` L2589-L2601](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2589-L2601)), not to path loss. A jumbo initial size would fail on any non-jumbo path, which is why [`transport/quic/transport.go` L58-L67](../../transport/quic/transport.go#L58-L67) fixes the initial class at the IPv6-safe floor.

The ~1,400 stall described above has to be understood before any of this is trusted.

### 3. The lifetime-fixed Datagram ceiling

[`CONTEXT.md`](../../CONTEXT.md#L28-L30) defines the maximum Datagram payload as "lifetime-fixed" and explicitly not a path MTU. [ADR-0009](../adr/adr-0009-optional-datagram-capability.md#L76-L79) adds that an adapter with a changing native limit "publishes a conservative value it can uphold or terminates the whole Wire" (L235-L241). Native measures its ceiling once, at promotion, by probing `SendDatagram` with an oversized payload ([`promote.go` L536-L559](../../internal/nativequic/promote.go#L536-L559), called from L318 and `native_promotion.go` L358). That value is the smaller of the peer's `max_datagram_frame_size` (the fork advertises 16,383, `connection.go` L368 and `internal/wire/datagram_frame.go` L10-L14) and `maxPayloadSizeEstimate`, which starts at `estimateMaxPayloadSize(1232)` = 1,195 and grows only when probes are acknowledged ([`connection.go` L2237-L2243, L2900-L2914, L3026-L3028](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2900-L2914)). The result is then capped by the constant 1,192.

The binding limit today is that constant. `DatagramCapacity` starts at `MaxDatagramPayload` = 1,192 and only ever lowers it ([`promote.go` L549-L552](../../internal/nativequic/promote.go#L549-L552)), so the ceiling is 1,192 lower / 1,191 public whatever the path carries and whenever promotion runs. When the ceiling is read is a second, separate factor. Authentication and promotion are caller-controlled ([`native_promotion.go` L158, L254-L275](../../native_promotion.go#L254-L275)), so discovery may or may not have progressed by then, and a ceiling taken from the fork's estimate would depend on when it is read. Lifting the cap and choosing when to read the estimate are two separate changes. RFC 9221 §5 notes that DATAGRAM frames "cannot be fragmented", so a Datagram can never exceed one packet.

The constraint is real, but contract-compatible routes exist. The handle is lifetime-fixed per Wire, not globally. With the cap lifted, a promotion that waited for discovery to complete (bounded at about 9 probes on a jumbo LAN) could install a larger value and still never mutate it. The ADR-0009 observation boundary (L243-L249) already classifies a later in-network drop of an accepted Datagram as ordinary loss, not a contract breach. The exported constant `MaxNativeDatagramPayload` and `NativeConfig.MinDatagramPayload`'s validation against it ([`native.go` L67-L73, L133-L135](../../native.go#L67-L73)) would have to become a per-Wire value or a larger maximum, with a `docs/COMPATIBILITY.md` entry. Consumers that size their messages from `MaxPayload` (GridCast's symbol size, for example) would have to follow. That is a cross-repo gate, not wiremux work.

At MTU 1500, lifting the cap and reading the ceiling after discovery gives 1,438 − 37 − 3 = 1,398 lower / 1,397 public (**derived**), +17.3% bytes per Datagram packet, *if* discovery reaches 1,438. With today's stall at 1,400 it gives 1,360 / 1,359, +14.1% (**derived**: 1,359 / 1,191 − 1). Both figures keep wiremux's three-byte DATAGRAM frame allowance ([`transport.go` L66-L75](../../transport/quic/transport.go#L66-L75)). The fork's own probe subtracts only 37 (`estimateMaxPayloadSize`, [`connection.go` L3026-L3028](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L3026-L3028), compared against the Data length at L2908-L2913). Uncapped, it would report 1,401 at 1,438 and 1,363 at 1,400, so reaching the values above needs an explicit three-byte deduction or an equivalent cap.

### 4. Admission (#1784)

No obstacle. The binding admits each datagram independently, every send in a batch and every received datagram ([`unicast.go` L722-L810, L871-L919](../../internal/routeselection/unicast.go#L722-L810); [`packetconn.go` L19-L31, L91-L96](../../internal/nativequic/packetconn.go#L19-L31); `docs/COMPATIBILITY.md` L103). Admission does no size-dependent work and imposes no size limit. Larger packets cut admission work per byte by the same 6.5–7.5× as everything else. The per-datagram contract is unchanged.

Native receive coalescing is off: `ConfigureExternalPacketIOV1(conn, false, …)` ([`endpoint.go` L222](../../internal/nativequic/endpoint.go#L222)). On Linux, jumbo frames would buy the receive-side system-call reduction that GRO would otherwise provide.

### 5. Relay

The native path never uses a relay. A native Wire "has no upgrade, fallback or probe history" (`native_promotion.go` L77-L97), and the paired relay that precedes it is a TCP byte stream where packet size does not apply.

The QUIC-over-TURN profile `wiremux-quic/3` is deliberately fixed: a 1,200-byte packet class with discovery disabled and a 1,160 / 1,159 Datagram ceiling ([`transport.go` L74-L75, L222-L236](../../transport/quic/transport.go#L222-L236); [ADR-0012](../adr/adr-0012-turn-udp-relay-candidates.md#L21)). That is 1,200 − 37 − 3 = 1,160 (**derived**), matching the derivation comment at [`transport.go` L66-L75](../../transport/quic/transport.go#L66-L75). TURN adds a 4-byte ChannelData header (RFC 8656 §12.4) to an internet-path outer packet, so no TURN deployment benefits from jumbo frames.

## Per-link notes

- **Thunderbolt bridge (macOS).** `networksetup -listValidMTURange` reports 1280–65518 for `bridge0` and its member interfaces on both Macs (read-only query); the ticket's "supports 9000" understates the range. macOS also caps a UDP datagram at the socket send buffer, returning `EMSGSIZE` when it exceeds `so_snd.sb_hiwat` (XNU `uipc_socket.c` `sosend`). The default send buffer is `net.inet.udp.maxdgram` = 9,216 (XNU `udp_usrreq.c` `udp_sendspace`; observed value on both hosts), and quic-go requests 7 MiB, so 9,000-byte packets fit. Beyond 9,000, the loopback flatness suggests the kernel would keep scaling, but per-byte cost (crossover about 4.4–28.6 KB in the serialized model) and the 14.6 Gbit/s link cap take over. An MTU above 9,000 is not worth planning for.
- **Data-center LAN.** IEEE 802.3 defines no jumbo frame. 9,000 is a common operator configuration, not a standard, and every hop must agree. Linux already gives the native stream GSO (Docker shape: stream 7.8 Gbit/s, Datagrams 2.05 Gbit/s at 215k packets/s, raw UDP 4.3 Gbit/s at 372k packets/s). Datagrams should benefit most, but real numbers wait for #1799. An alternative Linux Datagram lever is GSO for equal-size packets ([quic-go-fast#743](https://github.com/the-sarge/quic-go-fast/issues/743)), which cuts system calls but not QUIC per-packet work.
- **AWS.** All current instance types support MTU 9001, but traffic over an internet gateway, VPN, or between Regions without a transit gateway is limited to 1500, and inter-Region VPC peering to 8500 ([EC2 network MTU](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/network_mtu.html)). Single-flow bandwidth is 5 Gbit/s outside a cluster placement group, 10 inside, and up to 25 with ENA Express ([EC2 instance network bandwidth](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-instance-network-bandwidth.html)). A native connection is one 5-tuple flow, so the jumbo gain is capped at 5 Gbit/s unless the hosts share a placement group.
- **GCP.** The VPC default is 1460, configurable from 1300 to 8896 ([VPC MTU](https://docs.cloud.google.com/vpc/docs/mtu)). Internet traffic should stay at or below 1500.
- **Azure.** The default is 1500. Larger MTUs work only within a virtual network and directly peered same-region networks: up to 9000 with the Microsoft Azure Network Adapter, 3900 with Mellanox. Gateways, global peering and the internet are not supported ([Azure VM MTU](https://learn.microsoft.com/en-us/azure/virtual-network/how-to-virtual-machine-mtu)).
- **Never jumbo.** Wi-Fi networks bridge to Ethernet at an IP MTU of 1500 in practice (not verified against the IEEE 802.11 text here). The internet path is about 1500, and IPv6 guarantees only 1280 (RFC 8200 §5). Tunnels are smaller: [`transport.go` L58-L66](../../transport/quic/transport.go#L58-L66) lists the exact-1280 class (Tailscale, Cloudflare WARP, NetBird, 6to4, mobile IPv6) and WireGuard's 1420 default. TURN is fixed, as above. A binding in `Local` mode admits only LAN-classified interfaces, while `Direct` mode also admits gateway routes (`docs/COMPATIBILITY.md` L103), so a native connection can cross such paths. Discovery must therefore stay on, and the initial size must stay at 1,232.

## Changes each step needs

| Step | Where | Contract impact | Unlocks |
| --- | --- | --- | --- |
| 1. Root-cause the ~1,400 discovery stall (qlog `MTUUpdated`, probe send and receive accounting) | wiremux native stack and/or fork | none | +3% stream at MTU 1500; trustworthy discovery for every later step |
| 2. Configurable packet ceiling: split the receive capacity (read buffers, pools, advertised `max_udp_payload_size`) from the discovery `MAX_PLPMTU`; lift the BBR and `send_stream` guards; size GSO buffers by segment count, not 20 KiB | fork (quic-go#3162 is the upstream home) | none for wiremux; a new fork config surface | everything above 1,452 |
| 3. Black-hole detection: shrink after repeated full-size loss (RFC 8899 §4.3) | fork (upstream #3955) | none | safe jumbo on paths that can change |
| 4. Native profile sets the ceiling from the binding's interface MTU on both peers; initial stays 1,232 | wiremux `internal/nativequic` | none (internal) | stream 4.1–7.6 Gbit/s on Thunderbolt at MTU 9000 (**derived**) |
| 5. Datagram ceiling measured after discovery completes; `MaxNativeDatagramPayload` becomes a maximum or per-Wire value | wiremux `internal/nativequic`, root `native*.go`, `docs/COMPATIBILITY.md`; ADR-0009 note | lifetime-fixed per Wire is preserved; the exported constant's value or meaning changes (a discipline choice with no real users) | Datagrams +14–17% at MTU 1500 (17% needs discovery to reach 1,438); 4.1–7.6 Gbit/s at MTU 9000 (**derived**); consumers must opt into larger messages |
| 6. MTU 9000 on both Thunderbolt bridges, the LAN, or the VPC | operator | none | the jumbo rows |

Steps 2–5 are worth doing only for deployments that will actually run jumbo frames. Step 1 and the MTU-1500 half of step 5 pay off everywhere.

## Corrections to the ticket's premises

- "~100k/s" understates the measured rate. Native runs at 126k (baseline) to 133k (this sweep) packets/s, and raw UDP delivers 115–165k. The per-packet premise itself holds.
- "~1,200-byte packets": native Datagram packets are 1,218 bytes of UDP payload. Stream packets are about 1,397–1,400, which is neither the 1,452 cap nor the 1,438 discovery should reach.
- "Thunderbolt bridges support 9000" understates it: the valid range is 1280–65518.
- "quic-go's maximum packet size is capped near 1,452": correct, and the discovery tolerance makes the best reachable size 1,438.
- "Path MTU discovery is not disabled": correct, and it does run (DF is set via the binding's control connection), but it stalls near 1,400 for reasons inside the stack.
- The Datagram contract and the `/3` relay derivation (1,200 − 37 − 3 = 1,160) are as stated.

## Open questions for later tickets

1. **Why native DPLPMTUD stops at about 1,400 on `bridge0`.** The path delivers DF datagrams up to 1,472 bytes. The fork's search, simulated, reproduces the observed sizes if every probe of 1,403 bytes or more is lost, and each run loses 8–21 packets between the two interface counters. Instrument with qlog `MTUUpdated` and per-size probe accounting on both peers.
2. **A real MTU 9000 measurement on the `tb` cell.** It needs Josh's go-ahead to change and restore `bridge0`'s MTU on both Macs, plus a fork build with a raised ceiling. It would test the 4.1–7.6 Gbit/s range and the receiving interface's packet ceiling at 9,000 bytes.
3. **Per-byte cost.** The measured 1.0–1.3 ns/B slope is 4–5× the component floor. Profile `dgram` at 600 versus 1,191 bytes to see whether per-Datagram allocation and copies, rather than crypto or checksum, are the per-byte cost; that would be cheaper to fix than to tolerate.
4. **Linux (#1799).** How jumbo frames combine with GSO on the native stream, and whether Datagram GSO (quic-go-fast#743) is the better Linux lever.
5. **The Datagram ceiling design.** Wait for discovery at promotion versus a negotiated jumbo class, the bound on promotion latency, and what a black-hole event does to an already-published ceiling. This probably needs an ADR-0009 amendment and a decision before step 5.

## Evidence

All under `/Volumes/worktrees/wiremux/native-gap-evidence/` (outside the repository), produced 2026-10-08 between 04:07 and 04:35 ET with the 2026-10-08-tb-standard binaries (rig 9532593 on b494e711, quic-go-fast v0.62.1-fast.7):

- `2026-10-08-tb-standard/`: the map's baseline campaign, reused for wire sizes.
- `1797-size-sweep/tb-udp-size/`, `tb-native-size/`, `lo0-udp-size/`, `tb-df-ladder/`: this note's runs, each with per-run counters and a `summary.txt`. `sweep.sh` is the driver (`rig.sh run_tb` plus `netstat -I IF -b` counters and a 1 s receiver timeline), and `an.py` is the analysis.
- The AES-GCM, ChaCha20-Poly1305 and copy figures come from a throwaway Go 1.27.1 benchmark on mbp128 (AES-128-GCM seal 7.1 GB/s at 1,200 B, 8.7 GB/s at 9,000 B), not kept in the repository.
