# Unreliable datagram relay architectures relevant to issue 624

Research note for [Datagram track: unreliable-unordered message primitive on the transport contract](https://github.com/GridSwarm/wiremux/issues/624).

## Summary

There are strong, deployed precedents for preserving unreliable message semantics through a relay. They do not all make the same congestion-control or confidentiality tradeoffs:

| Architecture | Loss and ordering | Congestion control | What the relay can read |
| --- | --- | --- | --- |
| TURN over UDP | TURN forwards application data over UDP and does not add delivery recovery. Ordering and loss are therefore preserved as network properties. | TURN itself adds no congestion controller. The application protocol must provide end-to-end control if needed; the server separately enforces allocation and bandwidth quotas by dropping excess traffic. | Base TURN extracts the application payload, so TURN transport security alone does not hide it from the server. An end-to-end application protocol can make that payload ciphertext. |
| WebRTC data channel over TURN/UDP | Unordered PR-SCTP with zero retransmissions gives a UDP-like message service over the ICE-selected path. A TURN/UDP path preserves it; TURN/TCP adds underlying retransmission and head-of-line blocking. | SCTP congestion control is end-to-end and per association; all channels in the association share its congestion window. TURN may also rate-limit traffic operationally. | DTLS protects the complete SCTP packet between the WebRTC endpoints, so a TURN relay sees ciphertext. |
| MASQUE CONNECT-UDP over HTTP/3 | QUIC DATAGRAM carries unreliable messages between client and proxy; the proxy emits ordinary UDP to the target. The reliable Capsule fallback does **not** preserve strict unreliability. | The outer HTTP/3 QUIC connection has client-to-proxy congestion control. If the tunneled protocol is QUIC, it has a second, end-to-end controller, so the result is nested congestion control rather than one shared controller. | CONNECT-UDP hands the proxy the unmodified UDP payload. It is opaque only when the tunneled protocol encrypts it end to end. |
| Steam Datagram Relay / GameNetworkingSockets | The same API supports direct or relayed unreliable messages with no retransmission and no ordering guarantee. | The endpoint connection has shared rate estimation and metering for reliable and unreliable traffic. Valve also rate-limits relay traffic. The public material does not expose enough of the proprietary relay internals to determine whether additional per-backbone-leg control exists. | Valve documents endpoint certificates as end-to-end and the open transport as AES-GCM encrypted per packet. It is therefore reasonable to infer that SDR forwards endpoint ciphertext, but the closed SDR data plane prevents source-level confirmation. |

The most important conclusion for wiremux is that **“direct-only” is not the durable capability boundary**. A future WebRTC transport could satisfy the requested contract on either a direct ICE/UDP path or a TURN/UDP path, while failing it on TURN/TCP. Steam demonstrates that a purpose-built relay can also preserve the same message contract. The capability should therefore describe the semantics of the *established transport path*, not whether that path happens to contain a relay.

That does not require issue 624 to add datagrams to wiremux's current relay. The current relay is a reliable byte-forwarding path, and none of these examples turns such a path into a genuinely unreliable carrier by adding framing. Supporting relay-carried datagrams would require adopting a separate relay data-plane design such as TURN/UDP, CONNECT-UDP, or a purpose-built encrypted packet network.

## 1. TURN: the standardized UDP packet relay

[RFC 8656](https://www.rfc-editor.org/rfc/rfc8656.html) defines a TURN allocation as a relay transport address owned by a client. The client sends a TURN message containing application data and a peer address; the server extracts that data and sends it to the peer in a UDP datagram. In the reverse direction, it wraps the received UDP payload in a TURN Data indication or ChannelData message ([§3](https://www.rfc-editor.org/rfc/rfc8656.html#section-3), [§3.4](https://www.rfc-editor.org/rfc/rfc8656.html#section-3.4), [§3.5](https://www.rfc-editor.org/rfc/rfc8656.html#section-3.5)).

TURN's server-to-peer leg is UDP. The client-to-server leg can be UDP, DTLS-over-UDP, TCP, or TLS-over-TCP ([RFC 8656 §3.1](https://www.rfc-editor.org/rfc/rfc8656.html#section-3.1)). Consequences:

- With UDP or DTLS-over-UDP on the client leg, TURN does not restore a lost application datagram or impose message order. It is a genuine unreliable packet relay.
- With TCP or TLS-over-TCP on the client leg, losses on that leg are recovered and later packets are held behind missing bytes. This is useful through UDP-blocking firewalls but no longer has strict "no underlying retransmission" semantics.
- TURN itself supplies no application-data congestion controller. RFC 8656 explicitly notes that UDP lacks congestion control and recommends per-user allocation and bandwidth limits, with the server dropping traffic above quota ([§5](https://www.rfc-editor.org/rfc/rfc8656.html#section-5)). For UDP-to-UDP relay the server may preserve ECN or act as an ECN-aware queue, but this is not a replacement for an endpoint congestion controller ([§14](https://www.rfc-editor.org/rfc/rfc8656.html#section-14)).

TURN is not opaque by itself: the server extracts and re-encapsulates the application data. RFC 8656 says application-data confidentiality should be provided by the application protocol because TURN over TLS or DTLS does not protect the server-to-peer leg ([§21.1.6](https://www.rfc-editor.org/rfc/rfc8656.html#section-21.1.6)). TURN permissions, allocation quotas, bandwidth limits, packet-size/fragmentation behavior, and authentication are all part of operating the service; they are evidence that an unreliable relay is more than a new frame type.

## 2. WebRTC: an end-to-end unreliable message transport over TURN

WebRTC is the closest standardized example to wiremux's desired abstraction because the application selects message semantics while ICE selects a direct or relayed path underneath it.

[RFC 8831](https://www.rfc-editor.org/rfc/rfc8831.html) defines data channels as SCTP over DTLS over ICE/UDP. It requires partial reliability and states that a retransmission limit of zero combined with unordered delivery provides a UDP-like service in which each user message is sent once and delivered in receive order ([§6.1](https://www.rfc-editor.org/rfc/rfc8831.html#section-6.1)). The WebRTC API exposes the same choice through `ordered`, `maxRetransmits`, and `maxPacketLifeTime` ([W3C WebRTC §6.2](https://www.w3.org/TR/webrtc/#rtcdatachannel)).

SCTP is the end-to-end congestion authority. RFC 8831 says it provides congestion control per association and that all SCTP streams in that association share one congestion window ([§5](https://www.rfc-editor.org/rfc/rfc8831.html#section-5)). DTLS protects the complete SCTP packet between the endpoints, providing confidentiality, integrity, and source authentication on both direct and TURN-selected paths.

WebRTC endpoints must support TURN for endpoint-dependent NATs and must also support TURN over TCP and TLS for UDP-blocking firewalls ([RFC 8835 §3.4](https://www.rfc-editor.org/rfc/rfc8835.html#section-3.4)). This produces an important capability distinction:

- direct ICE/UDP and TURN/UDP can preserve no-retransmission delivery;
- TURN/TCP and TURN/TLS retain the data-channel's *SCTP* zero-retransmission setting but the lower TCP leg can still retransmit and head-of-line block packets.

Thus, “WebRTC supports unreliable channels” is not by itself enough to promise issue 624's strict property. The transport adapter must know the selected path's lower transport, or define the contract more weakly as “the message layer does not retransmit.”

## 3. MASQUE CONNECT-UDP: unreliable HTTP/3 proxying

[RFC 9298](https://www.rfc-editor.org/rfc/rfc9298.html) defines CONNECT-UDP. A client opens an HTTP request naming a UDP target; over HTTP/3, UDP payloads are carried to the proxy in HTTP Datagrams backed by QUIC DATAGRAM frames, and the proxy sends them through an ordinary UDP socket ([§3](https://www.rfc-editor.org/rfc/rfc9298.html#section-3), [§5](https://www.rfc-editor.org/rfc/rfc9298.html#section-5)). The proxy receives the unmodified UDP payload, so confidentiality from the proxy depends on an inner end-to-end protocol such as QUIC or DTLS.

[RFC 9297](https://www.rfc-editor.org/rfc/rfc9297.html) is explicit that HTTP/3 can use QUIC DATAGRAM for unreliable delivery, while the Capsule Protocol carries HTTP Datagrams reliably when QUIC DATAGRAM is unavailable or undesirable ([§2.1](https://www.rfc-editor.org/rfc/rfc9297.html#section-2.1), [§2.2](https://www.rfc-editor.org/rfc/rfc9297.html#section-2.2), [§3.5](https://www.rfc-editor.org/rfc/rfc9297.html#section-3.5)). A strict wiremux capability could therefore not silently treat Capsule fallback as equivalent.

CONNECT-UDP also illustrates why “shares the connection's congestion control” needs a precise referent. RFC 9298 says a congestion-controlled inner protocol such as QUIC experiences at least two nested controllers: its end-to-end controller and the underlying client-to-proxy HTTP connection's controller ([§6](https://www.rfc-editor.org/rfc/rfc9298.html#section-6)). The proxy-to-target UDP leg has no transport-level controller of its own. The RFC advises proxies not to batch queued packets, to drop oversized datagrams that cannot fit a QUIC DATAGRAM, and to restrict authenticated clients and targets because a proxy can otherwise become an abuse or amplification source ([§6](https://www.rfc-editor.org/rfc/rfc9298.html#section-6), [§7](https://www.rfc-editor.org/rfc/rfc9298.html#section-7)).

This is not merely a paper design. Apple documents OS-level network relays built on MASQUE for TCP and UDP traffic ([Apple Platform Deployment](https://support.apple.com/guide/deployment/use-network-relays-dep91a6e427d/web)), and its Private Relay design uses HTTP/3 CONNECT-UDP and QUIC unreliable datagrams ([iCloud Private Relay Overview](https://www.apple.com/privacy/docs/iCloud_Private_Relay_Overview_Dec2021.PDF)). Cloudflare documents its production Privacy Proxy as a MASQUE CONNECT/CONNECT-UDP service and as an iCloud Private Relay egress provider ([Cloudflare Privacy Proxy](https://developers.cloudflare.com/privacy-proxy/)). These deployments add authentication, rate limiting, target policy, and—in Private Relay—multiple administrative hops to the base protocol.

## 4. Steam Datagram Relay: a purpose-built opaque game packet network

Valve's Steam Datagram Relay (SDR) is the strongest deployed analogy for a single application-facing connection that can use direct or relayed delivery without changing message semantics.

The official Steamworks documentation describes SDR as a relay network for both peer-to-peer and dedicated-server traffic. It hides endpoint IP addresses and authenticates, encrypts, and rate-limits traffic ([Steam Datagram Relay](https://partner.steamgames.com/doc/features/multiplayer/steamdatagramrelay)). `ISteamNetworkingMessages` and `ISteamNetworkingSockets` both support unreliable and reliable messages over direct or SDR routes. Valve documents that unreliable messages may be lost, duplicated, or received out of order, and that only reliable messages have ordering guarantees ([ISteamNetworkingMessages](https://partner.steamgames.com/doc/api/ISteamNetworkingMessages), [ISteamNetworkingSockets](https://partner.steamgames.com/doc/api/ISteamNetworkingSockets)).

The public `GameNetworkingSockets` source is consistent with the service API:

- [`k_nSteamNetworkingSend_Unreliable`](https://github.com/ValveSoftware/GameNetworkingSockets/blob/master/include/steam/steamnetworkingtypes.h) sends without retransmission; if any segment of a fragmented unreliable message is lost, the whole message is dropped.
- The [SNP wire-format description](https://github.com/ValveSoftware/GameNetworkingSockets/blob/master/src/steamnetworkingsockets/clientlib/SNP_WIRE_FORMAT.md) defines unreliable-message segments and a shared packet ACK/NACK record used both for retransmitting reliable segments and for TCP-friendly bandwidth estimation.
- The [project README](https://github.com/ValveSoftware/GameNetworkingSockets) documents AES-GCM-256 per-packet encryption and a common reliability layer for reliable and unreliable message traffic.

Endpoint status exposes one estimated send rate plus pending reliable and unreliable byte counts, and the sender meters both through that connection ([`SteamNetworkingQuickConnectionStatus`](https://github.com/ValveSoftware/GameNetworkingSockets/blob/master/include/steam/steamnetworkingtypes.h)). Valve's service documentation separately says SDR traffic is rate-limited. This supports an endpoint-controlled shared congestion model plus relay enforcement; the proprietary SDR forwarding implementation is not public, so it would be overclaiming to say there is definitely no additional per-relay-leg control.

Valve says certificates are an end-to-end concept used for Diffie-Hellman key agreement, including on direct and P2P connections, while the open transport encrypts packets with AES-GCM. The natural inference is that the relay routes ciphertext rather than application plaintext. The public documentation does not expose the closed relay packet-processing source, so that inference should not be treated as a formally specified non-observability guarantee.

SDR demonstrates feasibility, but it also shows the size of the undertaking: a relay topology and route-selection system, authorization tickets, endpoint PKI, encrypted routing information, rate limiting, DoS controls, relay health measurement, and dedicated operational infrastructure. It is evidence for a future wiremux-relayed datagram track, not evidence that it belongs inside the transport-contract design of issue 624.

## Design implications for wiremux

1. Define the capability by observable semantics, not mechanism: message boundaries, maximum payload, retransmission/order guarantees, queue/drop behavior, shared congestion authority, and end-to-end confidentiality.
2. Make capability reporting path-sensitive. A transport name such as WebRTC or HTTP/3 is insufficient because UDP and TCP fallback paths can have different loss semantics.
3. Distinguish “the message layer never retransmits” from “no layer underneath retransmits.” Issue 624 currently asks for the stronger property; WebRTC/TURN and HTTP Capsule fallbacks make that distinction concrete.
4. Do not bake “direct” into the public contract. QUIC direct is the first implementation, but TURN/UDP and SDR show that a relay can satisfy the same contract.
5. Keep a wiremux relay implementation out of this design effort unless the effort is intentionally expanded to choose a packet relay data plane, end-to-end packet envelope, queue/drop and quota rules, abuse controls, MTU behavior, version negotiation, and deployment model.
