# UDP ceilings per platform, and what other QUIC stacks reach

Research for [What are the real UDP ceilings per platform, and what do other QUIC stacks reach? (#1796)](https://github.com/GridSwarm/wiremux/issues/1796), under the [native↔TCP gap map (#1794)](https://github.com/GridSwarm/wiremux/issues/1794). Researched 2026-10-08. No load tests or cross-host measurements were run for this note. The only local inputs were source reading, `sysctl`, `ifconfig -v`, `netstat -s` on mbp128, and the [#1795 rig baseline](https://github.com/GridSwarm/wiremux/issues/1795#issuecomment-6055235817).

Confidence labels:

- **high:** a reproducible primary measurement with stated hardware, or a direct reading of source.
- **medium:** a primary source, but the hardware or conditions are vague, or the kernel is older.
- **low:** inferred.

**Version caveat.** The rig runs macOS 27.0.1, which is Darwin 27.0.0 with kernel `xnu-13432.1.9`. The newest published xnu source is [`xnu-12377.121.6`](https://github.com/apple-oss-distributions/xnu/tree/xnu-12377.121.6) (macOS 26.x, Darwin 25). Every xnu source claim below was verified against `xnu-12377.121.6` only. For each one, I checked that the running Darwin 27 kernel exposes the same sysctls and behavior where that is observable. The fork had the same gap when it qualified `sendmsg_x` on Darwin 27 ([darwin27 results](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-22-darwin27/results.md)).

## Answer

### macOS 27, BSD sockets, one flow, MTU 1500 (Apple silicon, Thunderbolt bridge)

**Realistic ceiling: about 1.2–2.0 Gbit/s, or 130–170k packets/s delivered per 4-tuple.** Confidence: medium. That is one rig plus source analysis, and the number is set by per-packet cost, not by bytes.

**Today's rig against that ceiling:**

- Native Datagrams carry 126k pkt/s at zero loss. That is already about 94% of the raw single-socket UDP delivered rate (134k pkt/s, which comes with 27% loss).
- In bytes, native Datagrams reach only 77% of raw UDP (1205 vs 1557 Mbit/s). The arms carry 1191-byte payloads against raw UDP's 1452. At MTU 1500, the gap to raw UDP is mostly packet size, not QUIC overhead.
- QUIC does cost about 3× the CPU per byte (17/19.5 against 5.6/9.0 CPU-s/GiB for send/receive).
- The 14.6 Gbit/s TCP reference is out of reach for any UDP path that pays the full stack once per 1500-byte datagram.

**Levers, ranked by expected payoff:**

1. **Larger datagrams.**
   - At MTU 1500, going from 1191 to 1452 bytes per IPv4 packet is +22% at the same packet rate.
   - On a jumbo-capable LAN (the Thunderbolt members allow MTU 65518), it is the only lever that can multiply throughput. At about 130k pkt/s × 8.9 KB, the theoretical ceiling is about 9 Gbit/s before per-byte costs bite.
   - This is a path-MTU and profile decision, not a socket trick.
2. **A connected socket per peer.** On the rig, a connected sender is about 4× faster than a wildcard-bound one. A connected socket also gets:
   - an exact-match receive lookup
   - interface-queue backpressure (`ENOBUFS`) instead of silent drops
   - the only `sendmsg_x` path that builds a packet list in the kernel
3. **Lower userspace CPU per packet.** This frees cores, but it raises the MTU-1500 ceiling only marginally.
4. **Network.framework's user-space stack.** It is unmeasured, and it is unavailable on `bridge0`.
5. **More 4-tuples (several sockets).** On the rig, 4 sockets gave +23% pkt/s at 43% loss.
6. **Small items:** `UDP_NOCKSUM` (IPv4 only) and receive buffers up to 8 MiB. Bigger buffers remove drops, not the ceiling.

**Hard limits that cannot be recovered:**

- xnu has no UDP segmentation or receive offload of any kind. TSO, software GSO and Skywalk receive aggregation are all TCP-only.
- `sendmsg_x`/`recvmsg_x` only amortize the syscall. Each datagram still goes through `udp_send` → `ip_output` and the per-packet input path one at a time.
- `SO_REUSEPORT` does not spread unicast receive.
- The fast syscalls are private ABI.

### Linux, one flow, MTU 1500, commodity 10–100G NIC

**Realistic ceiling: about 5–10 Gbit/s per connection for a userspace QUIC stack that uses both GSO and GRO.** Confidence: medium.

- The best published kernel-socket figures are msquic at 8.3 Gbit/s on an E810 100G NIC with Linux 6.1 (about 4.8 without offload), and quinn at 8.2 Gbit/s on 10G.
- The best published figure overall is LSQUIC on DPDK kernel bypass, at 10.8 Gbit/s.
- Upstream quic-go is published at only about 1.0–1.3 Gbit/s on 10G. That was with GSO and without GRO.
- In the Docker shape cell, the fork's stream arm already reaches 7.8 Gbit/s.
- The raw per-socket receive ceiling without GRO is about 1.5–2.0 Mpps when the application and softirq run on different cores. That is about 17–19 Gbit/s at 1200–1350-byte packets. A single QUIC connection therefore hits crypto and userspace per-packet cost before the kernel socket limit.

**Levers, ranked by expected payoff:**

1. **GSO on every bulk send, including Datagrams.** The fork's GSO batch only continues while each packet equals the maximum size. Datagram traffic stalled at 2.0 Gbit/s in Docker with no visible segmentation, while stream traffic reached 7.8 Gbit/s.
2. **GRO.** It is already shipped in the fork: about 3.8× fewer receive syscalls per delivered datagram (paired engaged/disabled ratio 0.263, a 73.7% reduction against `recvmmsg` alone, which already handles about 7 datagrams per call while GRO reaches about 28) and +26% throughput on loopback. The native path does not use it yet: it turns receive coalescing off (`internal/nativequic/endpoint.go` L222).
3. **Hardware USO.** mlx5 reports about 1.5× the throughput at half the cycles.
4. **Socket buffers and placement.** Raise buffers (`rmem_max` is 212992 before Linux 6.18), and keep the application off the RSS softirq core.
5. **`sendmmsg` of several GSO buffers.** Modest gain.

**Hard limits:**

- One 4-tuple maps to one RX queue, one softirq CPU and one socket. `SO_REUSEPORT` hashes the 4-tuple, so it cannot spread one flow.
- Aggregation is capped at 64 KB per GSO or GRO unit: 64 GRO segments, and 64 GSO segments (128 from 6.9).
- AEAD encryption and decryption, and ACK processing, stay in userspace. TCP+kTLS can push the equivalent work into the kernel and NIC.

## macOS

### Local facts (mbp128, Darwin 27.0.0, `xnu-13432.1.9`)

| Fact | Value | How observed |
| --- | --- | --- |
| Socket buffer cap | `kern.ipc.maxsockbuf` 8388608 (8 MiB) | `sysctl`; compiled default `SB_MAX` = 8192×1024 ([socketvar.h L193](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/sys/socketvar.h#L193)) |
| UDP default receive buffer | `net.inet.udp.recvspace` 786896 | `sysctl`; set at [udp_usrreq.c L297](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L297) |
| UDP send buffer | `net.inet.udp.maxdgram` 9216, which is `udp_sendspace`: "really max datagram size" | [udp_usrreq.c L2327](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L2327). A datagram larger than the send high-water mark fails with `EMSGSIZE`, so jumbo datagrams need a larger `SO_SNDBUF` |
| Batch syscall limits | `kern.ipc.maxsendmsgx` / `maxrecvmsgx` 256, `sendmsg_x_mode` 0 | `sysctl`; [uipc_syscalls.c L189](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_syscalls.c#L189) |
| `bridge0` offloads | `options=RXCSUM,TXCSUM,TSO4,TSO6`; no Skywalk netif or flowswitch | `ifconfig -v bridge0` |
| Thunderbolt members `en1`–`en3` | `TSO4,TSO6,CHANNEL_IO`; **no checksum offload, no LRO**; Skywalk NetIf agent only, **no FlowSwitch**; `max mtu: 65518` | `ifconfig -v en1` |
| Ethernet and Wi-Fi interfaces | Skywalk NetIf **and** FlowSwitch agents | `ifconfig -v en0`, `en14` |
| Software UDP checksum, sender side too | 181.9M of 185.3M UDP datagrams output were "checksummed in software" | `netstat -s -p udp` on mbp128. The rig found the same on m4mini's receive side |
| Interface queue | `net.link.generic.system.sndq_maxlen` 128 (`IFQ_MAXLEN`) | `sysctl`; [if.h L163](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/if.h#L163) |

### Mechanisms

| Mechanism | What the source or docs say | Confidence | Meaning for wiremux |
| --- | --- | --- | --- |
| UDP GSO, GRO or USO | None. The only interface offload flags are checksum, `IFNET_TSO_IPV4/6` and `IFNET_LRO`, which is documented as "TCP Large Receive Offload" ([kpi_interface.h L204–L270](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/kpi_interface.h#L204)). Skywalk's software GSO asserts TCP ([nx_netif_gso.c L296](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/netif/nx_netif_gso.c#L296)). Flowswitch receive aggregation (`rx_agg_tcp`, 16 KB) and the 16 KB software-TSO MTU are TCP-only ([skywalk.c L122/L144](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/core/skywalk.c#L122), [flow_agg.c L1233](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/flowswitch/flow/flow_agg.c#L1233)). The only UDP socket options are `UDP_NOCKSUM` and `UDP_KEEPALIVE_OFFLOAD` (`udp.h`). The quinn-udp author who added the Apple fast path agrees: "AFAIK Apple doesn't have GSO/GRO via the socket interface" ([quinn#1993](https://github.com/quinn-rs/quinn/pull/1993#issuecomment-2370151154)) | high (source) | No per-byte amortization exists for UDP on macOS. Every 1500-byte datagram pays the full stack, in both directions |
| `sendmsg_x` | On a **connected** datagram socket, `sendit_x` builds an mbuf packet list and calls `sosend_list` ([uipc_syscalls.c L1907](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_syscalls.c#L1907)). Otherwise it **loops `sendit()` once per message** ([L1933](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_syscalls.c#L1933)). UDP has no `pru_send_list` ([udp_usrreqs L222](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L222)), so even the connected path falls back to one `pru_send` per packet ([uipc_socket.c L2747](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket.c#L2747)). The fork calls it on an **unconnected** socket with a per-message destination ([sys_conn_sendmsg_x_darwin.go L53](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_sendmsg_x_darwin.go#L53)), so it takes the per-message `sendit` loop | high (source) | This explains the 2026-10-07 probe: the CPU saving came from fewer Go scheduler wakeups, not from kernel work. The fork's D1 measured about 8× fewer send syscalls and +17% loopback throughput ([D1 results](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-12-d1-sendmsgx-results.md)). Burst submission with no kernel pacing plausibly explains the receiver socket-buffer drops (low) |
| `recvmsg_x` | Moves a list of datagrams out of the socket buffer in one call via `soreceive_m_list` ([uipc_syscalls.c](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_syscalls.c#L2666); contract in [socket_private.h L774–L803](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/sys/socket_private.h#L774)) | high (source) | The fork retired it. On a sender-bound loopback it filled only 1.8 of 8 slots and lost 33% throughput ([D2 results](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-12-d2-recvmsgx-results.md)). quinn-udp measured the opposite on its own loopback bench: 172 MiB/s plain, 658 with `sendmsg_x`, 789 with both, 856 with batch 64 ([quinn#1993](https://github.com/quinn-rs/quinn/pull/1993#issuecomment-2368080124); hardware not stated, medium). It only pays off when the receive queue is deep, i.e. when the receiver is the bottleneck, which is the rig's case and not the D2 case |
| Unconnected vs connected send | A wildcard local address runs `in_pcbladdr` (source selection and route) on every send ([udp_usrreq.c L1904](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L1904)). Flow advisory, which suspends the socket with `ENOBUFS` when the interface queue is full, is "enable[d] only when connected" ([L1688](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L1688)) | high (source); rig ratios 1×/2.5×/4× high | An unconnected sender overruns the 128-packet interface queue silently. That is plausibly part of the rig's "wire" loss (low). A connected per-Wire socket gets backpressure and the cheapest send path, but it changes wiremux's socket model and admission seam |
| `SO_REUSEPORT` with several sockets | Unicast lookup `in_pcblookup_hash_locked` returns the **first** exact or wildcard match. There is no hashing or load balancing ([in_pcb.c L2565](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/in_pcb.c#L2565)). Only multicast and broadcast deliver a copy to every reuse socket ([udp_usrreq.c L607](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L607)) | high (source) | Darwin cannot spread one flow's receive across sockets. Spreading needs distinct 4-tuples (ports), which for QUIC means several paths. On the rig, `udp4` (4 tuples) gained only +23% pkt/s, with 43% "wire" loss |
| Input threading | Each legacy interface gets one DLIL input thread. Netif-backed interfaces run input synchronously in the driver context ([dlil_input.c L83](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/dlil_input.c#L83)). `bridge0` is a legacy interface | medium (source; not profiled) | The receive path below the socket is serialized per interface. TCP crosses the same `bridge0` at about 1.26M frames/s equivalent (14.6 Gbit/s ÷ 1448 B), assuming its frames are MTU-sized on the wire. That suggests UDP's ~165k cap is the per-datagram UDP and socket cost plus the sender, not the link. Unverified, see open questions |
| Socket buffers | `SO_RCVBUF` up to `maxsockbuf` (8 MiB) without root | high | Raising the receive buffer from about 0.77 MB to 8 MiB absorbs bursts (it addresses the rig's rcvbuf loss). It does not raise the packet-rate ceiling |
| `UDP_NOCKSUM` | Skips the pseudo-header and payload checksum on IPv4 output ([udp_usrreq.c L1169](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L1169), L2016). IPv6 mandates the checksum | high (source); payoff low | Both Thunderbolt peers checksum in software. QUIC's AEAD already protects the payload. The saving is small at 1–2 Gbit/s, and IPv4 only |
| Network.framework user-space networking | Apple: user-space networking gives "30 percent less overhead" on the receive side for UDP, and `connection.batch` sends many datagrams with "ideally … just one context switch" ([WWDC18 session 715](https://developer.apple.com/videos/play/wwdc2018/715/)). Back then it was iOS and tvOS only. Apple DTS: "User-space networking landed in macOS 12" and Network framework "uses user-space networking by default". The built-in firewall disabled it as of 14.4.1 ([forum 751581](https://developer.apple.com/forums/thread/751581)); DTS believes that changed in macOS 15 ([forum 773493](https://developer.apple.com/forums/thread/773493)). Apple recommends Network framework for unicast UDP flows ([TN3151](https://developer.apple.com/documentation/technotes/tn3151-choosing-the-right-networking-api)). A developer measured 1M UDP sends at 6 s with Network framework against 17 s with BSD sockets, MacBook Air to iPhone over Wi-Fi; receive was a wash at 53 vs 51 s ([forum 748197](https://developer.apple.com/forums/thread/748197); low) | medium (vendor; no Mac Ethernet numbers) | This is the only Apple-sanctioned route around per-datagram BSD socket syscalls. It is a per-peer connection API, reachable from Go only through cgo. It needs an interface with a Skywalk **FlowSwitch**, which `bridge0` lacks on the rig, so the `tb` cell cannot test it as configured. No public GSO or GRO API exists in it either. Apple publishes no QUIC throughput for `NWProtocolQUIC` |
| Skywalk channels directly | The registration entitlements are `com.apple.private.skywalk.*` (xnu source); the user-space API is private | high (source) | Not usable by a third-party binary except through Network.framework |
| Private ABI risk | `sendmsg_x`/`recvmsg_x` are "a private system call, the API is subject to change" ([socket_private.h L800](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/sys/socket_private.h#L800)). quinn-udp keeps them behind an opt-in runtime switch, and records an Apple `sendmsg`/`sendmsg_x` `EWOULDBLOCK` bug near the `SO_SNDBUF` limit ([quinn#2463](https://github.com/quinn-rs/quinn/pull/2463), [quinn#2727](https://github.com/quinn-rs/quinn/pull/2727)) | high | The fork's allowlist-per-Darwin-major model is the right shape. Every macOS major is a requalification |

### Rig numbers decoded (2026-10-08, `tb` cell)

| Arm | Mbit/s | pkt/s | Bytes/pkt | Send cores | Receive cores | Note |
| --- | --- | --- | --- | --- | --- | --- |
| `udp` (1 socket, interface-bound) | 1557 | 134k | 1452 | ≈1.0 | ≈1.6 | 27% loss: wire 308k, rcvbuf 184k |
| `udp4` (4 sockets) | 1919 | 165k | 1452 | ≈4.0 | ≈0.8 | 43% loss, almost all "wire"; sender CPU per *delivered* GiB is inflated by loss |
| `binding` | 1111 | 96k | 1452 | ≈1.0 | ≈1.3 | 47% loss, mostly rcvbuf |
| `dgram` (native Datagrams) | 1205 | 126k | 1191 | ≈2.4 | ≈2.7 | 0 loss |
| `stream` | 1392 | — | — | ≈2.0 | ≈2.6 | — |

Cores = CPU-s/GiB × GiB/s. This counts process CPU only; work done in kernel input threads is not included. Derived figures are high-confidence arithmetic on the [#1795 baseline](https://github.com/GridSwarm/wiremux/issues/1795#issuecomment-6055235817).

The native arms are not ceiling-limited by sockets: `dgram` sits near the raw single-socket delivered rate while burning 2.4–2.7 cores. Raising throughput at MTU 1500 therefore needs more bytes per packet, or a per-packet path cheaper than BSD UDP. Neither of those is a QUIC-side optimization.

## Linux

| Mechanism | Primary fact | Kernel | Confidence | Meaning for wiremux |
| --- | --- | --- | --- | --- |
| UDP GSO (`UDP_SEGMENT`) | Merged in [4.18](https://github.com/torvalds/linux/commit/bec1f6f69736). Commit benchmark on one core: 876 MB/s at 624,666 calls/s → 2139 MB/s at 36,282 calls/s for the same cycles. TCP with TSO: 3197 MB/s. LPC 2018 paper on 10G ConnectX-3, Mcycles/s at line rate: UDP 2801 → UDP GSO 1727, TCP TSO 618 ([de Bruijn & Dumazet, LPC 2018](https://lpc.events/event/2/contributions/106/attachments/104/129/willemdebruijn-lpc2018-udpgso-paper-DRAFT-1.pdf)). Batching with `sendmmsg` "is not sufficient" | 4.18+ | high (paper), medium (commit: no hardware) | About 2× bytes per cycle on send. The fork ships it, but only for full-size packet runs (see Datagram row) |
| GSO limits | `UDP_MAX_SEGMENTS` 64; 128 from [v6.9](https://github.com/torvalds/linux/commit/1382e3b6a350). One super-packet ≤ 64 KB. `gso_size` + headers ≤ MTU. Needs TX checksum offload ([udp.h](https://github.com/torvalds/linux/blob/master/include/linux/udp.h)) | 4.18 / 6.9 | high (source) | At 1452-byte segments the 64 KB cap binds (about 45 segments), not the segment count |
| Hardware USO | `NETIF_F_GSO_UDP_L4` / ethtool `tx-udp-segmentation`. Drivers include mlx5, ice, i40e, ixgbe, bnxt, gve, virtio_net/tun (6.2+) ([segmentation-offloads.rst](https://docs.kernel.org/networking/segmentation-offloads.html)). In the LPC paper, the mlx5 authors report "1.5x higher throughput at half the CPU cycles" over software GSO | 4.19+ (mlx5) | medium | NIC-dependent. Owned Linux hardware should be chosen with USO (mlx5 or ice) |
| UDP GRO (`UDP_GRO`) | Merged in [5.0](https://github.com/torvalds/linux/commit/e20cf8d3f1f7). Commit benchmark: 1079 MB/s at 769k calls/s → 1466 MB/s at 24.9k calls/s. Coalesces only for sockets with `UDP_GRO`, same ports, equal length and non-zero checksum, capped at 64 segments and 64 KB. BIG TCP's `gro_max_size` does not apply to UDP ([udp_offload.c](https://github.com/torvalds/linux/blob/master/net/ipv4/udp_offload.c)) | 5.0+ | high (source), medium (numbers) | Shipped in the fork: 0.263× receive syscalls per datagram and +26% throughput, measured on a Ryzen AI MAX+ 395 loopback with Linux 7.0 ([G2 results](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-11-g2-gro-results.md)) |
| `recvmmsg` / `sendmmsg` | `recvmmsg` (2.6.33): +16–55% pps on 1 GbE ([tester report](https://lists.openwall.net/netdev/2009/09/17/62)). `sendmmsg` (3.0): +20% at 64 B ([commit](https://github.com/torvalds/linux/commit/228e548e6020)) | old | medium | These save syscall entry, not per-packet stack work. msquic combines `sendmmsg` with GSO; upstream quic-go uses one `sendmsg` per GSO buffer |
| `SO_REUSEPORT` | Since [3.9](https://github.com/torvalds/linux/commit/ba418fa357a7). The socket is chosen by hashing (saddr, sport, daddr, dport), unless a reuseport BPF program (4.5) picks one ([inet_hashtables.c](https://github.com/torvalds/linux/blob/master/net/ipv4/inet_hashtables.c)) | 3.9+ | high (source) | A single QUIC 4-tuple always lands on one socket. RSS likewise pins one flow to one RX queue and softirq CPU |
| Per-socket receive pps | Brouer `udp_sink` on 100G mlx5, Linux 5.3: about 1.58–1.83 Mpps with the app on a different core from softirq (2.0 Mpps connected); 0.52–0.80 Mpps on the same core ([lkml](https://lkml.iu.edu/hypermail/linux/kernel/1911.3/04009.html)). Cloudflare, 2015, Solarflare 10G: ~370k pps single thread, 1.4 Mpps best with multiqueue and reuseport ([blog](https://blog.cloudflare.com/how-to-receive-a-million-packets/)) | 5.3 / ~3.x | high / medium | Without GRO, one socket can take about 17–19 Gbit/s of 1200–1350-byte packets, if the application is off the softirq core. Docker's raw `udp` arm (372k pkt/s) is far below this, so it reflects the VM, not Linux |
| Socket buffer limits | `rmem_max`/`wmem_max` 212992 until [6.18](https://github.com/torvalds/linux/commit/a6d4f25888b8) raised the maxima to 4 MB (defaults unchanged). quic-go recommends about 7.5 MB ([wiki](https://github.com/quic-go/quic-go/wiki/UDP-Buffer-Sizes)) | 6.18 | high | Deployment guidance: without a sysctl change, a pre-6.18 host caps wiremux's receive buffer at 208 KiB |
| `MSG_ZEROCOPY` for UDP | [5.0](https://github.com/torvalds/linux/commit/b5947e5d1e71). LPC paper: no gain at 1500 B without GSO; with GSO and cold buffers, 13% fewer cycles | 5.0 | medium | Not worth it for QUIC: the AEAD output is fresh memory, and completion notification adds complexity |
| Virtual devices | `GSO_UDP_L4` passes through software devices from [5.11](https://github.com/torvalds/linux/commit/2e4ef10f5850). veth GRO without XDP from 5.13, default off. tun/virtio USO from 6.2 | 5.11–6.2 | high | The Docker shape cell can show GSO, but veth GRO may be off. Docker numbers are shape only, as #1795 says |
| Datagram GSO eligibility (fork) | The GSO loop keeps appending only `if !done && size == maxSize && …` ([packet_emission.go L277](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/packet_emission.go#L277)). The packer puts at most one DATAGRAM frame in a packet ([packet_packer.go L648](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/packet_packer.go#L648)) | — | high (source) | Any Datagram packet shorter than the current maximum flushes a one-packet "batch". That matches Docker `dgram` (2.0 Gbit/s, no visible segmentation) against `stream` (7.8 Gbit/s with GSO; native receive coalescing is off, `internal/nativequic/endpoint.go` L222). Linux GSO only needs equal segment sizes, not the maximum size, so batching equal-size runs would extend GSO to Datagrams |

## Other QUIC stacks

All rows are one connection, on Linux unless the row says otherwise.

| Stack | Figure | Hardware, NIC, MTU, kernel | Offloads | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| msquic (Linux) | 6.6–7.3 Gbit/s up, 7.7–8.0 down (best 8.6/8.7); io_uring 6.3–7.0. Lab: about 8.0 | Azure 4-vCPU MANA VM (25 Gbit/s cap), kernel 6.17-azure. Lab: Dell R650, Xeon Silver 4316, ConnectX-6 Dx, kernel 6.8. 12 s, 1 stream | GSO + GRO + `sendmmsg`/`recvmmsg` | [microsoft/netperf dashboard](https://microsoft.github.io/netperf/dist) (data on the repo's `deploy` branch; run 2026-06-16) | high |
| msquic (Windows) | Azure WS2022: 10.0–11.1 up, 11.5–12.0 down. WS2025 up to 12.6/12.3. XDP on Azure is *slower* (6.3–7.9) | Same Azure VMs | USO/URO (msquic default) | same | high |
| TCP on the same rigs | Azure WS2022 TCP 14.7–20.5. Lab Ubuntu TCP 22.7–25.6, against QUIC at about 8 | same | TSO/LRO | same | high |
| msquic (100G) | No offload ~4.8 → GSO+GRO **8.3** Gbit/s; GRO adds +12% on top of GSO. Without offload, crypto is 32% of server samples and packet I/O is 24% (server) and 34% (client). GSO cuts server packet I/O by 21%; GRO cuts client packet I/O by 58%. msquic is "the only implementation amongst the four that supports GRO" | Xeon Gold 6421N (32 cores), Intel E810 100G, Debian 12, Linux 6.1 | GSO/GRO | [Späth et al., NOMS 2026](https://www.net.in.tum.de/fileadmin/bibtex/publications/papers/spaethj-noms2026.pdf) | high |
| LSQUIC / quiche / picoquic (100G) | LSQUIC with DPDK **10.8** Gbit/s (3× its kernel-socket figure; it has no GSO or GRO). quiche as low as 2.2. picoquic with GSO +33% | same | DPDK vs GSO | same | high |
| quinn (Rust) | **8.22** Gbit/s, the best of 6. msquic 5.81; the rest < 4.06. Turning off crypto: msquic +22%, quinn +7.3%. The busiest core sits at 100% | Xeon W-2145 (8C), Intel X550 10G, MTU 1500, kernel 5.15.0-56 | GSO | [König et al., LCN 2023](https://publikationen.bibliothek.kit.edu/1000161904/152028985) | high |
| ngtcp2 / quiche / lsquic / picoquic / **quic-go** (HTTP/3, 8 GiB) | Self-pairs: ngtcp2 4.17, quiche 2.97, lsquic 2.47, picoquic 1.52, **quic-go 1.29**. quic-go is 1.22–1.45 in every pairing. quic-go gains up to 27% on HTTP/0.9 | Same KIT 10G rig, kernel 5.15 | GSO (quic-go: GSO only; GRO is upstream issue #3838) | [König et al., IFIP Networking 2025 / IETF 123 MAPRG](https://publikationen.bibliothek.kit.edu/1000190603/174943268) | high |
| lsquic / quiche / quic-go (2023) | lsquic ≈3.0 (≈5 on Xeon Gold 6312U), quiche ≈2.5, quic-go ≈1.0 (read from a heatmap), TCP 8.0. GSO/GRO gave no gain *in the stacks as tested* | EPYC 7543, Broadcom BCM57416 10G, kernel 5.10 | as shipped | [Jaeger et al., IFIP Networking 2023](https://arxiv.org/abs/2309.16395) | high (quic-go value medium) |
| Chrome, cURL, quic_client | Chrome HTTP/3 averages 478 Mbit/s on 1 GbE, 45.2% below HTTP/2. Raw UDP 958 vs TCP 944 Mbit/s, so the link is not the limit. The root cause is receiver-side packet processing; "no stack used UDP GRO" | Xeon E5-2640 server, i7-6700 client, Ubuntu 18.04, 1 GbE | none effective | [Zhang et al., WWW 2024](https://arxiv.org/abs/2310.09423) | high |
| Google QUIC (Chromium/QUICHE server) | QUIC server CPU was 3.5× TLS/TCP at first, cut to about 2× | Production YouTube | `PACKET_RX_RING`, optimized crypto | [Langley et al., SIGCOMM 2017](https://research.google/pubs/the-quic-transport-protocol-design-and-internet-scale-deployment/) | high (ratio; no Gbit/s) |
| quicly (Fastly) | 196 → 466 Mbit/s, equal to TLS-over-TCP (466); plain TCP 708 | Core m3-6Y30 deliberately capped at 400 MHz, 1 core, AX88179 USB 1 GbE, kernel 5.3 | GSO, reduced ACK frequency | [Fastly, 2020](https://www.fastly.com/blog/measuring-quic-vs-tcp-computational-efficiency) | high (CPU-starved by design) |
| quicly / picoquic-dpdk | quicly with GSO plus client GRO ≈7.2 Gbit/s (2× without GRO); server I/O share of CPU 60.7% → 21.3%. picoquic-dpdk 10.4 | E5-2640v4 + ConnectX-4 25G; EPYC 7302P + ConnectX-5 25G; kernel 5.4 | GSO/GRO, DPDK | [Mukherjee et al., ANRW 2025](https://dl.acm.org/doi/10.1145/3744200.3744780) | high |
| quiche + NGINX (Cloudflare) | `sendmsg` ≈80–90 MB/s → `sendmmsg` ≈100 → GSO ≈160 MB/s; syscalls 904,539 → 18,824 with GSO | Laptop, localhost, Linux 5.3 | `sendmmsg`, GSO | [Cloudflare, 2020](https://blog.cloudflare.com/accelerating-udp-packet%2Dtransmission-for-quic/) | medium (chart readings) |
| picoquic | "1.5 to 2 Gbps", single thread | not stated | `sendmsg` + GSO | [Huitema, 2023](https://www.privateoctopus.com/2023/12/12/quic-performance.html) | medium |
| neqo (Firefox, quinn-udp) | < 1 → about 4 Gbit/s; latest ≈5.7 down / 5.5 up | loopback, hardware not stated | GSO/GRO, `recvmmsg` | [Inden, 2026 slides](https://mxinden-bot.github.io/slides/02-udp-io/), [blog](https://max-inden.de/post/fast-udp-io-in-firefox/) | medium |
| msquic secnetperf over wireguard-go (Tailscale) | 2.94 → **12.46** Gbit/s through the tunnel (kernel WireGuard 5.42) | 2× i5-12400, ConnectX-5 25G (MCX512A), Ubuntu 22.04 with kernel 6.2 HWE | TUN UDP GSO/GRO | [Tailscale, 2023-11](https://tailscale.com/blog/quic-udp-throughput) | high, but **`-encrypt:0`**, i.e. QUIC crypto off |
| wireguard-go, TCP inside (Tailscale) | 8.36 → **13.0** Gbit/s (kernel WireGuard 11.8); AWS c6i.8xlarge 5.34 → 7.32 | same i5 rig, kernel 5.15 | UDP GSO/GRO + TUN TSO/GRO | [Tailscale, 2023-04](https://tailscale.com/blog/more-throughput) | high |
| quinn-udp, **macOS** | 172 MiB/s → 658 MiB/s with `sendmsg_x`, 789 MiB/s with `sendmsg_x` + `recvmsg_x`, 856 MiB/s at batch 64. neqo's full QUIC loopback benchmark gained only about +11% (the figure is in Inden's 2025-03-09 comment, pointing to neqo#2302) | Mac localhost, model not stated | private batch syscalls; no GSO exists | [quinn#1993](https://github.com/quinn-rs/quinn/pull/1993#issuecomment-2368080124) | medium |
| quic-go-fast D1, **macOS** | Loopback 153–167 → 174–197 MB/s with `sendmsg_x` (+17%) | M4 Max, macOS 26.6.2, Darwin 25.6 | `sendmsg_x` | [D1 results](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-12-d1-sendmsgx-results.md) | high (loopback) |
| wiremux native, **macOS** | Datagrams 1205 Mbit/s (126k pkt/s, 0 loss); stream 1392 | mbp128 → m4mini, Thunderbolt `bridge0`, MTU 1500, Darwin 27 | none: the binding writes each datagram with `WriteMsgUDPAddrPort` (`internal/routeselection/unicast.go`); the fork's `sendmsg_x` never applies to the native adapter (`internal/nativequic/packetconn.go` L19-L31) | [#1795 baseline](https://github.com/GridSwarm/wiremux/issues/1795#issuecomment-6055235817) | high |

What is missing:

- **No first-party throughput figure exists for quic-go, ngtcp2, s2n-quic or lsquic.** quic-go's [optimizations page](https://quic-go.net/docs/quic/optimizations/) documents GSO but gives no numbers. The independent quic-go figures are ≈1.0 and ≈1.3 Gbit/s on 10G, both from before the fork's GRO.
- **No QUIC result over a real NIC on macOS was found from any stack.** wiremux's rig is the only real-link macOS data point here.
- **Per-core packet rates are rarely stated.** The clearest one is the LPC paper's: about 812k `sendmsg` calls/s of 1500-byte UDP saturating one core of about 2.8 GHz at 2,801 Mcycles/s.
- Yang et al. ([EPIQ 2020](https://doi.org/10.1145/3405796.3405827)) find kernel↔userspace I/O, crypto and reordering dominate QUIC CPU. Their throughput figures (mvfst 325, picoquic 489 Mbit/s on 10G) are reported only second-hand via KIT, so confidence is low.

## Where TCP's advantage comes from

| Source of TCP advantage | Linux: recoverable for userspace QUIC? | macOS: recoverable? |
| --- | --- | --- |
| Segmentation offload on send (TSO: one 64 KB descriptor per ~45 segments; TSO cost 618 vs UDP 2801 Mcycles/s at 10G) | **Mostly.** UDP GSO gets about 1.6× less CPU than plain UDP (1727 Mcycles/s); hardware USO closes most of the rest | **No.** No UDP GSO or USO. TCP gets hardware TSO on the Thunderbolt members plus Skywalk software TSO (16 KB) |
| Receive coalescing (LRO/GRO) | **Mostly.** UDP GRO, capped at 64 KB. TCP can go larger with BIG TCP | **No.** Skywalk flowswitch receive aggregation is TCP-only, and `bridge0` has no flowswitch anyway |
| Syscalls per byte (TCP `write`/`read` move up to MBs per call) | **Mostly.** GSO and GRO give 64 KB per syscall; `sendmmsg`/`recvmmsg` for the remainder | **Partly.** `sendmsg_x`/`recvmsg_x` (private) cut syscalls, not the per-packet stack traversal |
| Kernel-side ACK processing, pacing and retransmission | **No.** QUIC ACKs are encrypted userspace packets. ACK frequency ([fork #645](https://github.com/the-sarge/quic-go-fast/issues/645)) reduces their count | **No.** Same |
| Crypto placement (TCP+kTLS can offload TLS to the NIC; TCP baselines often run without TLS) | **No** for kernel or NIC. QUIC header protection and AEAD run in userspace: 32% of server samples for MsQuic without offload (NOMS 2026). QUIC crypto offload exists only in research ([Yang et al., EPIQ 2020](https://dl.acm.org/doi/10.1145/3405796.3405827)) | **No.** Same; userspace AEAD |
| Per-packet socket and buffer cost (one `sk_buff`/mbuf and one queue operation per wire packet versus per segment train) | **Mostly**, via GSO/GRO | **No.** Every datagram is one mbuf, one pcb lookup and one socket-buffer append |
| Flow-level backpressure (TCP stalls the writer instead of dropping) | **Partly.** UDP gets `EAGAIN` on the socket buffer, but qdisc drops are silent unless configured | **Partly.** Only connected UDP sockets get flow advisory |

## Open questions

These need measurement on the rig or on owned Linux hardware. They are candidate wayfinder tickets.

1. **Where does macOS UDP lose packets above ~130k pkt/s: the sender's 128-slot interface queue, the Thunderbolt link or driver, or the receiver's `bridge0` input thread?** Read the sender's `netstat -I bridge0 -qq` / `ifnet` drops, the per-member `en1`–`en3` counters and the receiver's per-thread kernel CPU during the `udp` and `udp4` arms.
2. **What frame rate does TCP's 14.6 Gbit/s actually put through `bridge0` and its members?** Compare interface packet counters during a TCP run. About 1.26M frames/s would prove the link and input path carry 8× UDP's packet rate, putting UDP's limit in the socket layer. About 20k frames/s would mean Thunderbolt carries TSO-sized frames and the comparison is not like for like.
3. **Does a connected socket raise the receiver's ceiling, or only the sender's?** Rig flag `-connected` on the `udp` arm, both peers. Does flow advisory on the connected sender turn "wire" loss into backpressure?
4. **How does throughput scale with packet size on the `tb` cell?** Measure 1191 vs 1452 B at MTU 1500. Then set `bridge0` MTU to 9000 (members allow 65518) with `-size 8952` and `-buf` above 9216. Is the ceiling packets/s (throughput ×6) or bytes/s?
5. **Does `sendmsg_x` on a connected socket (`sosend_list`, one lock) beat the fork's unconnected per-message loop, and does `recvmsg_x` pay off once the receiver, not the sender, is the bottleneck?** The rig is receiver-bound, which is the opposite of D2's loopback.
6. **Does Network.framework's user-space path beat BSD sockets for one UDP flow on a flowswitch-backed interface?** Test on a direct Thunderbolt or Ethernet interface, not `bridge0`. Measure a minimal cgo `nw_connection` sender/receiver with `nw_connection_batch` against the `udp` arm. Can a per-peer `nw_connection` preserve wiremux's per-datagram admission?
7. **Why does Linux native Datagram traffic not segment?** Is the Datagram packet size below `maxSize` on every packet? Would equal-size GSO runs bring `dgram` near `stream`'s 7.8 Gbit/s in the Docker shape cell?
8. **What is the Linux single-connection ceiling for the fork on owned hardware with GSO, GRO and hardware USO** (mlx5 or ice, kernel ≥ 6.9, application pinned off the RSS core)? Against the same box's TCP and raw `udp` arms. No published quic-go figure substitutes for this.

## Sources

Local evidence:

- [#1795 rig baseline (resolution comment)](https://github.com/GridSwarm/wiremux/issues/1795#issuecomment-6055235817)
- [#1794 map](https://github.com/GridSwarm/wiremux/issues/1794)
- Local `sysctl`, `ifconfig -v` and `netstat -s -p udp` readings on mbp128, Darwin 27.0.0 `xnu-13432.1.9`, 2026-10-08

Apple xnu (`xnu-12377.121.6`, newest published tag):

- [bsd/netinet/udp_usrreq.c](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c)
- [bsd/netinet/in_pcb.c](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/in_pcb.c)
- [bsd/kern/uipc_syscalls.c](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_syscalls.c)
- [bsd/kern/uipc_socket.c](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket.c)
- [bsd/sys/socket_private.h](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/sys/socket_private.h)
- [bsd/sys/socketvar.h](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/sys/socketvar.h)
- [bsd/net/kpi_interface.h](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/kpi_interface.h)
- [bsd/net/dlil_input.c](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/dlil_input.c)
- [bsd/skywalk/core/skywalk.c](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/core/skywalk.c)
- [bsd/skywalk/nexus/netif/nx_netif_gso.c](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/netif/nx_netif_gso.c)
- [bsd/skywalk/nexus/flowswitch/flow/flow_agg.c](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/flowswitch/flow/flow_agg.c)

Apple documentation and DTS:

- [WWDC18 session 715, Introducing Network.framework](https://developer.apple.com/videos/play/wwdc2018/715/)
- [TN3151: Choosing the right networking API](https://developer.apple.com/documentation/technotes/tn3151-choosing-the-right-networking-api)
- [Developer Forums 751581](https://developer.apple.com/forums/thread/751581)
- [Developer Forums 773493](https://developer.apple.com/forums/thread/773493)
- [Developer Forums 748197](https://developer.apple.com/forums/thread/748197) (developer measurement, low)

quic-go-fast fork (`v0.62.1-fast.7`, `main` at `d3648918`):

- [Datapath offload program #235](https://github.com/the-sarge/quic-go-fast/issues/235)
- [D1 sendmsg_x results](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-12-d1-sendmsgx-results.md)
- [D2 recvmsg_x results](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-12-d2-recvmsgx-results.md)
- [G2 GRO results](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-11-g2-gro-results.md)
- [Darwin 27 qualification](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-22-darwin27/results.md)
- [Stack datapath comparison](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-11-quic-stack-datapath-comparison.md)
- [sys_conn_sendmsg_x_darwin.go](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_sendmsg_x_darwin.go)
- [packet_emission.go](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/packet_emission.go)
- [packet_packer.go](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/packet_packer.go)

quinn:

- [quinn#1993, Apple fast path and benchmarks](https://github.com/quinn-rs/quinn/pull/1993)
- [quinn#2463, opt-in](https://github.com/quinn-rs/quinn/pull/2463)
- [quinn#2727, SO_SNDBUF EWOULDBLOCK bug](https://github.com/quinn-rs/quinn/pull/2727)

Linux:

- [UDP GSO commit bec1f6f69736](https://github.com/torvalds/linux/commit/bec1f6f69736)
- [UDP GRO commit e20cf8d3f1f7](https://github.com/torvalds/linux/commit/e20cf8d3f1f7)
- [UDP_MAX_SEGMENTS 128, 1382e3b6a350](https://github.com/torvalds/linux/commit/1382e3b6a350)
- [rmem_max/wmem_max 4 MB, a6d4f25888b8](https://github.com/torvalds/linux/commit/a6d4f25888b8)
- [SO_REUSEPORT, ba418fa357a7](https://github.com/torvalds/linux/commit/ba418fa357a7)
- [sendmmsg, 228e548e6020](https://github.com/torvalds/linux/commit/228e548e6020)
- [UDP MSG_ZEROCOPY, b5947e5d1e71](https://github.com/torvalds/linux/commit/b5947e5d1e71)
- [GSO_UDP_L4 on software devices, 2e4ef10f5850](https://github.com/torvalds/linux/commit/2e4ef10f5850)
- [segmentation-offloads.rst](https://docs.kernel.org/networking/segmentation-offloads.html)
- [include/linux/udp.h](https://github.com/torvalds/linux/blob/master/include/linux/udp.h)
- [net/ipv4/udp_offload.c](https://github.com/torvalds/linux/blob/master/net/ipv4/udp_offload.c)
- [net/ipv4/inet_hashtables.c](https://github.com/torvalds/linux/blob/master/net/ipv4/inet_hashtables.c)
- [de Bruijn & Dumazet, Optimizing UDP for content delivery: GSO, pacing and zerocopy (LPC 2018 paper)](https://lpc.events/event/2/contributions/106/attachments/104/129/willemdebruijn-lpc2018-udpgso-paper-DRAFT-1.pdf)
- [Brouer udp_sink measurements (lkml 2019)](https://lkml.iu.edu/hypermail/linux/kernel/1911.3/04009.html)
- [recvmmsg tester report (netdev 2009)](https://lists.openwall.net/netdev/2009/09/17/62)
- [Cloudflare: How to receive a million packets per second](https://blog.cloudflare.com/how-to-receive-a-million-packets/)
- [quic-go UDP buffer sizes](https://github.com/quic-go/quic-go/wiki/UDP-Buffer-Sizes)
- [quic-go optimizations](https://quic-go.net/docs/quic/optimizations/)

Stack measurements and papers:

- [microsoft/netperf dashboard](https://microsoft.github.io/netperf/dist)
- [Späth et al., Kernel Bypass Surgery, NOMS 2026](https://www.net.in.tum.de/fileadmin/bibtex/publications/papers/spaethj-noms2026.pdf)
- [König et al., LCN 2023](https://publikationen.bibliothek.kit.edu/1000161904/152028985)
- [König et al., IFIP Networking 2025 / IETF 123 MAPRG slides](https://publikationen.bibliothek.kit.edu/1000190603/174943268)
- [Jaeger et al., QUIC on the Highway, IFIP Networking 2023](https://arxiv.org/abs/2309.16395)
- [Zhang et al., QUIC is not Quick Enough over Fast Internet, WWW 2024](https://arxiv.org/abs/2310.09423)
- [Langley et al., SIGCOMM 2017](https://research.google/pubs/the-quic-transport-protocol-design-and-internet-scale-deployment/)
- [Yang et al., Making QUIC Quicker with NIC Offload, EPIQ 2020](https://doi.org/10.1145/3405796.3405827)
- [Mukherjee et al., ANRW 2025](https://dl.acm.org/doi/10.1145/3744200.3744780)
- [Fastly: Measuring QUIC vs TCP computational efficiency](https://www.fastly.com/blog/measuring-quic-vs-tcp-computational-efficiency)
- [Cloudflare: Accelerating UDP packet transmission for QUIC](https://blog.cloudflare.com/accelerating-udp-packet%2Dtransmission-for-quic/)
- [Huitema: QUIC performance](https://www.privateoctopus.com/2023/12/12/quic-performance.html)
- [Inden: fast UDP I/O in Firefox](https://max-inden.de/post/fast-udp-io-in-firefox/)
- [Inden: UDP I/O slides](https://mxinden-bot.github.io/slides/02-udp-io/)
- [Tailscale: QUIC/UDP throughput](https://tailscale.com/blog/quic-udp-throughput)
- [Tailscale: Surpassing 10Gb/s](https://tailscale.com/blog/more-throughput)
- [Tailscale: throughput improvements](https://tailscale.com/blog/throughput-improvements)
- [Microsoft: Making MsQuic Blazing Fast](https://techcommunity.microsoft.com/blog/networkingblog/making-msquic-blazing-fast/2268963)
