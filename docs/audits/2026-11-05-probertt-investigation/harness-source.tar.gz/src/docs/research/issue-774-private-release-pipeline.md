# Private wiremux v0.1.0 release pipeline audit

Research note for
[Audit the private release pipeline and artifact gaps](https://github.com/GridSwarm/wiremux/issues/774),
under
[Define the private wiremux v0.1.0 release plan](https://github.com/GridSwarm/wiremux/issues/767).

## Scope and evidence boundary

This audit answers what is present, and what must be added, to produce:

- annotated `v0.1.0-rc.1` and `v0.1.0` tags;
- GitHub Release notes that remain private with the repository;
- checksummed `wiremux-server` binaries for Linux/amd64 and Linux/arm64; and
- a repeatable final promotion that cannot drift away from the release
  candidate's commit.

The repository boundary is `main` at
`a0207b3bb1fd0ca28274267e476a0366e6f2be71` on 2026-07-14. Local sources,
the GitHub API, and official GitHub, Go, and GoReleaser documentation are the
only evidence used. At that boundary, the GitHub API reported a private
repository and empty tag and Release collections. It also reported no
repository rulesets, environments, or Actions secrets/variables; the
organization is on GitHub Team. Those settings are live state, not tracked
repository configuration. The live immutable-Release setting was disabled both
for the repository and as an organization-enforced policy. Repository and
organization settings also did not require action SHA pinning, even though the
checked-in workflows voluntarily use full action SHAs.

## Executive answer

The validation half of a release pipeline already exists. The publication and
artifact half does not.

| Requirement | Present today | Missing |
| --- | --- | --- |
| Release preflight | `task release-check` runs the complete validation gate, Darwin/arm64 and Windows/amd64 cross-build/vet checks, and the opt-in production-budget test (`Taskfile.yml:17-60`, `Taskfile.yml:102-106`). Pull requests that change recognized release files and a manual `release` dispatch run it (`.github/workflows/ci.yml:112-116`, `.github/workflows/ci.yml:129-131`). | The preflight does not build, name, inspect, smoke-test, or checksum either requested Linux artifact. It also has no packaging dry run. |
| Annotated tags | Nothing. The repository has no tags. | A validated, idempotent two-step annotated-tag creation path, with `contents: write`, a fixed target commit, tag messages, collision checks, and no tag movement/deletion. |
| Private GitHub Releases and notes | The repository is private, so a Release would inherit repository access. `docs/RELEASE.md` records release-facing status and downstream order, but is not a publication workflow or versioned Release-notes input (`docs/RELEASE.md:1-5`, `docs/RELEASE.md:81-91`). | A Release workflow, a notes source, prerelease/latest policy, asset upload, and draft-to-published handling. There is no separate per-Release `private` switch: GitHub says anyone with repository read access can view Releases. |
| Linux server artifacts | `wiremux-server` exists and is deployable from source (`README.md:9-14`, `docs/DEPLOYMENT.md:1-16`). Ordinary tests compile its package; in-process tests cover its flags and service behavior. | Explicit `CGO_ENABLED=0` Linux/amd64 and Linux/arm64 builds, stable artifact names, SHA-256 checksums, packaged-binary smoke evidence in approved representative Linux environments, metadata inspection, and Release upload. |
| Same-commit promotion | `docs/RELEASE.md` says wiremux tags before downstream consumers pin it (`docs/RELEASE.md:81-91`). | A promotion operation that resolves and peels the RC's annotated tag once, verifies its Release/assets, creates the final annotated tag at exactly that commit, and refuses every mismatch. No workflow currently models promotion or retries. |

This matches the repository's own statement that manual release preflight is
non-publishing and that no tag or Release automation exists (`docs/CI.md:46-49`,
`docs/CI.md:66-68`).

## What the current preflight actually proves

### Taskfile

`release-check` is a composition, not a packager (`Taskfile.yml:54-60`):

1. `verify` runs deterministic CI-script fixtures, documentation checks,
   ordinary Go checks, the required race gates, and `govulncheck`
   (`Taskfile.yml:17-43`).
2. `cross-check` cross-builds and cross-vets all packages for Darwin/arm64 and
   Windows/amd64 with `CGO_ENABLED=0` (`Taskfile.yml:45-52`). This is useful
   portability evidence, but neither target is a requested Release artifact.
3. `test-production-budget` runs one opt-in production cleanup-budget contract
   (`Taskfile.yml:102-106`).

The Go supply-chain posture is already strong enough to reuse: Task variables
force `GOTOOLCHAIN=local`; `audit-go` rejects a base toolchain below Go 1.26.3
and reports the relevant module-security environment; module download and
verification are explicit (`Taskfile.yml:6-14`, `Taskfile.yml:69-94`,
`Taskfile.yml:108-113`). The module and all current workflows pin Go 1.26.5
(`go.mod:3-5`, `.github/workflows/ci.yml:64-76`).

### GitHub Actions

The single required workflow has only pull-request, `main` push, and manual
dispatch events; it has no tag trigger (`.github/workflows/ci.yml:3-18`). Its
explicit permission is `contents: read`, and checkout deliberately does not
persist credentials (`.github/workflows/ci.yml:19-23`,
`.github/workflows/ci.yml:37-42`). It therefore cannot publish a tag or Release.

For pull requests, the classifier recognizes future `.goreleaser.*`,
`release.yml`, Docker, `release/`, and `packaging/` changes as release-affecting
(`scripts/classify-ci-changes.sh:61-79`), and a fixture already pins the
GoReleaser case (`scripts/test-classify-ci-changes.sh:64-67`). Those paths are
hooks for future configuration, not existing machinery: none of those release
or packaging files exists at the audited commit.

On a protected-branch push, CI runs only `task check`, not `release-check`
(`.github/workflows/ci.yml:118-123`). The live `main` rule requires the `Verify`
check and applies to administrators, but its status checks are non-strict.
Consequently a prior PR result is not a sufficient release predicate; the
publication operation must run `release-check` itself against the exact commit
it will tag.

Existing Actions and installed validation tools are pinned to full action SHAs
or exact versions (`.github/workflows/ci.yml:37-98`). The repository allows all
Actions in live settings, so a new release workflow should preserve full-SHA
action pins and isolate its write-capable jobs.

## Artifact feasibility and the promotion wrinkle

After the required local toolchain audit reported Go 1.26.5, a diagnostic build
at the audited commit successfully produced both requested targets with:

```text
CGO_ENABLED=0 GOOS=linux GOARCH=<amd64|arm64> GOTOOLCHAIN=local \
  go build -trimpath -buildvcs=true -o <artifact> ./cmd/wiremux-server
```

`file` identified statically linked x86-64 and AArch64 ELF executables. Two
successive builds of each target in the same environment compared byte-for-byte
equal. This establishes feasibility, not a cross-run reproducibility guarantee;
the workflow still needs a pinned runner/toolchain/configuration and explicit
checksum verification. The Go command documents that `-trimpath` removes local
filesystem paths, `-buildvcs=true` requires and embeds available VCS data, and
`go version -m` displays embedded module/build information
([Go command](https://pkg.go.dev/cmd/go#hdr-Compile_packages_and_dependencies)).
The current command has no `version` subcommand or flag
(`cmd/wiremux-server/main.go:56-80`), so `go version -m` and the external
checksum/provenance record are the only version diagnostics available on a
packaged binary.

A second clean-clone diagnostic created both requested annotated tags on the
same commit and built the same Linux/amd64 package once per tag. `go version -m`
reported `v0.1.0-rc.1` in the RC binary and `v0.1.0` in the final binary, and
their SHA-256 digests differed. The source commit was identical; the embedded
main-module version was not.

That result forces an explicit meaning of “promotion”:

- **Same commit, rebuilt final artifact (recommended):** create the final tag at
  the RC's peeled commit, then rebuild from the final tag. Code is unchanged,
  while the final binary correctly identifies as `v0.1.0`.
- **Byte-identical artifact promotion:** copy the RC binaries and checksum file
  to the final Release. This is stronger artifact identity, but the final asset
  retains `v0.1.0-rc.1` in Go build metadata unless the build deliberately
  suppresses or makes version metadata tag-neutral. That policy should not
  emerge accidentally from automation.

The recommendation below promotes the same code commit and rebuilds the final
versioned artifact. It records both sets of checksums and the common commit.

## Publication options

### Option A: Taskfile packaging plus a thin GitHub workflow

Add repository-owned packaging commands for the two raw binaries and
`checksums.txt`; use GitHub CLI/REST only for annotated tags and Releases. This
fits the small, fixed matrix and the repository's Taskfile-centered validation
model. It adds no release framework to the build trust base and makes the
special same-commit promotion checks visible. It does require careful
idempotency code and tests.

GitHub CLI's release command can upload assets, generate or read notes, mark a
prerelease, and refuse an absent remote tag with `--verify-tag`. Its manual is
also explicit that without an existing tag it automatically creates one, while
an annotated tag must be created and pushed first
([`gh release create`](https://cli.github.com/manual/gh_release_create)). The
workflow must always use `--verify-tag`; letting Release creation synthesize a
tag would violate the annotated-tag requirement.

### Option B: GoReleaser OSS plus custom tag/promotion orchestration

GoReleaser can own the two-target build matrix, raw-binary/archive naming,
SHA-256 checksum generation, changelog generation, and GitHub publication. Its
official docs support customized GOOS/GOARCH matrices, `CGO_ENABLED=0`,
`mod_timestamp`, and `-trimpath`; they also identify timestamp-bearing default
ldflags as a reproducibility hazard
([build configuration](https://goreleaser.com/customization/builds/builders/go/)).
It generates a Release checksum file by default
([checksums](https://goreleaser.com/customization/package/checksum/)) and offers
non-publishing validation via `goreleaser build` or
`goreleaser release --skip=publish`
([dry-run options](https://goreleaser.com/getting-started/quick-start/#dry-run)).

It does not remove the hard parts of this ticket: annotated tags must still be
created separately, promotion must still peel and compare commits, retry
semantics must still reject conflicting assets, and its defaults must be cut
down to exactly Linux/amd64 and Linux/arm64. A pinned GoReleaser binary/action
also becomes a new supply-chain input. Its public-Go-proxy “verifiable build”
mode is not an automatic fit for this private main module. GoReleaser is a good
choice if more platforms, archives, SBOMs, signing, or package registries are
imminent; for only two raw binaries, Option A is easier to audit.

### Option C: one workflow creates a tag, another reacts to tag push

This is not recommended with the repository `GITHUB_TOKEN`. GitHub documents
that events caused by `GITHUB_TOKEN` do not start new workflow runs, except for
`workflow_dispatch` and `repository_dispatch`
([`GITHUB_TOKEN` event behavior](https://docs.github.com/en/actions/concepts/security/github_token)).
A tag created by a manual workflow would therefore not reliably awaken a
separate `push.tags` publisher unless the repository introduced a GitHub App or
PAT. One manually dispatched workflow with dependent jobs avoids an extra
long-lived credential and keeps the exact commit in one run.

## Recommended repeatable workflow

Choose Option A initially: add a dedicated manual `release.yml` and small,
testable Taskfile/helper-script packaging surface. Keep publication out of the
required `CI` workflow.

### Shared invariants

1. Accept a release mode (`candidate` or `promote`) and a syntactically valid
   tag/source tag. For the first run, restrict values to `v0.1.0-rc.1` and
   `v0.1.0`; generalize only with tested SemVer validation. Both are canonical
   Go module version shapes; the Go module reference permits prerelease suffixes
   and maps root-module versions directly to repository tags
   ([Go Modules Reference](https://go.dev/ref/mod#versions)).
2. Capture one full commit SHA `C` and pass it between jobs. Never resolve
   `main` again after validation begins.
3. Run `task release-check` against `C` before any write. Refuse a dirty
   checkout and verify `C` is reachable from the protected default branch for a
   candidate.
4. Serialize all release mutation with one non-cancelling concurrency group.
   GitHub otherwise allows multiple workflow runs to execute concurrently
   ([Actions concurrency](https://docs.github.com/en/actions/concepts/workflows-and-actions/concurrency)).
5. Grant `contents: write` only to the minimal tag and Release jobs. Validation
   and building retain `contents: read`; no downloaded build tool should execute
   with a write-capable token when job separation can avoid it.

### Candidate path

1. A read-only validation job checks out the dispatch SHA with full history,
   installs the existing exact tool versions, performs the Go environment audit,
   and runs `task release-check`.
2. A minimal write job creates an **annotated tag object** for
   `v0.1.0-rc.1` whose target is `C`, then creates `refs/tags/v0.1.0-rc.1`.
   GitHub's Git database API explicitly requires these two operations for an
   annotated tag
   ([tag object](https://docs.github.com/en/rest/git/tags?apiVersion=2026-03-10#create-a-tag-object),
   [tag reference](https://docs.github.com/en/rest/git/refs?apiVersion=2026-03-10#create-a-reference)).
3. A fresh read-only build job checks out that exact tag, builds only
   Linux/amd64 and Linux/arm64 with Go 1.26.5, `GOTOOLCHAIN=local`,
   `CGO_ENABLED=0`, `-trimpath`, and `-buildvcs=true`, and emits stable names
   such as `wiremux-server_linux_amd64` and
   `wiremux-server_linux_arm64`. It sorts those names into a SHA-256
   `checksums.txt`, verifies it immediately, inspects both with `go version -m`
   and `file`, and executes the amd64 artifact's `--help` on the Linux runner.
   If the build and publication jobs are isolated, transfer the bundle with
   full-SHA-pinned `upload-artifact`/`download-artifact` actions and have the
   publisher re-run `sha256sum -c`; do not treat the transient Actions artifact
   as the long-term promotion store.
4. Before publication, read-only smoke jobs run the packaged binaries in the
   representative Linux environments approved by
   [Approve the private artifact, smoke-test, and promotion contract](https://github.com/GridSwarm/wiremux/issues/777).
   The retained evidence must bind each tested artifact digest to relay
   rendezvous, STUN Binding, TLS, and graceful-shutdown outcomes; in-process Go
   tests and `--help` are useful checks but are not substitutes for this packaged
   runtime gate.
5. A minimal write job creates a draft Release from the already-existing tag,
   with `prerelease=true`, `latest=false`, and `--verify-tag`; attaches the two
   binaries and checksum file; verifies the uploaded names/digests; then
   publishes it. Use a tracked, reviewed notes file such as
   `release/notes/v0.1.0.md`, because `docs/RELEASE.md` is broader status
   documentation rather than immutable version notes.

### Promotion path

1. Fetch `v0.1.0-rc.1`; require its ref to point to an annotated tag object,
   peel it to commit `C`, and verify the published RC Release is a prerelease
   with exactly the expected two binaries and checksum file. Download the RC
   assets and verify `checksums.txt` before proceeding.
2. Re-run `task release-check` at `C`. Do not substitute current `main`, even if
   it has advanced.
3. Create the annotated `v0.1.0` tag at exactly `C`, using the same two-step API
   operation. Then build from the final tag so embedded Go module metadata says
   `v0.1.0`. Repeat the checksum, metadata inspection, and approved packaged-
   binary Linux smoke gates against these final artifacts; the RC results do not
   cover their deliberately different bytes.
4. Publish a non-prerelease final Release from the verified existing tag with
   the final binaries and checksums. Reuse the reviewed base notes and prepend a
   deterministic statement that this promotes `v0.1.0-rc.1` at commit `C`.
   Do not rely on the default generated-note range: candidate and final tags
   share a commit, so a “commits since the RC” range is intentionally empty.
5. Record in the run summary both tag-object SHAs, their common peeled commit,
   all final asset digests, and the RC/final Release URLs.

### Rerun and collision rules

A partial failure may leave a tag or draft Release behind. Reruns should be
resume-safe, never destructive:

- absent tag: create it;
- existing annotated tag that peels to `C`: reuse it;
- existing lightweight tag, wrong tag-object name, or different peeled commit:
  fail without mutation;
- absent draft/published Release: create it;
- matching draft with missing assets: upload only missing assets after digest
  checks;
- any same-named asset with a different digest, or any conflicting published
  Release: fail; and
- never use forced tag updates, tag deletion, Release-asset `--clobber`, or a
  moving branch as recovery.

This is especially important for a Go module. The Go Modules Reference warns
that a released tag should not be deleted or moved because authenticated module
downloads may retain the old content in proxies and report security errors
after a move
([mapping versions to commits](https://go.dev/ref/mod#mapping-versions-to-commits)).

## Trust and provenance considerations

- **Private means repository-private.** GitHub says Releases are visible to
  anyone with repository read access; private Release assets require
  authenticated repository read access
  ([about Releases](https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases),
  [Release asset API](https://docs.github.com/en/rest/releases/assets)). Do not
  copy a private asset URL into a public channel and assume the URL itself is an
  authorization boundary.
- **Checksums detect corruption, not publisher compromise.** Publish the
  SHA-256 file, verify it before and after upload, and expose GitHub's recorded
  asset digests in the run summary. A checksum shipped beside a malicious binary
  does not authenticate the builder.
- **Attestations are a later strengthening option.** GitHub artifact
  attestations created directly by a workflow bind subjects to workflow/commit
  provenance and require `id-token: write` and `attestations: write`, but GitHub
  documents private or internal repository support as a GitHub Enterprise Cloud feature
  ([artifact attestations](https://docs.github.com/en/actions/how-tos/secure-your-work/use-artifact-attestations/use-artifact-attestations)).
  This organization is on Team, so the first release must not depend on that
  workflow feature. Keep a stable `checksums.txt` name so it can be added later.
- **Approval controls are plan-limited.** The repository has no environment,
  and GitHub documents required environment reviewers for private repositories
  as unavailable on Team
  ([deployment environments](https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments)).
  Manual dispatch plus least privilege, collision checks, and repository write
  access are the available in-product controls unless the plan or external
  approval mechanism changes.
- **Immutable Releases should be enabled if repository policy permits.** GitHub
  immutable Releases lock the associated tag and assets after publication while
  leaving drafts mutable for assembly, and automatically generate a Release
  attestation covering the tag, commit, and assets
  ([immutable Releases](https://docs.github.com/en/code-security/concepts/supply-chain-security/immutable-releases)).
  This complements, rather than replaces, the workflow's pre-publication
  target/digest checks. The live repository and organization API settings both
  reported it disabled at the audit boundary; enabling it is therefore a real
  prerequisite, not documentation cleanup.
- **Annotated is not signed.** GitHub's tag-object API creates a genuine
  annotated tag, but the API example reports an unsigned verification result.
  If cryptographically signed Git tags become a requirement, that is a separate
  keyless/signing-key design; do not silently equate a tagger identity and
  message with a verified signature.
- **No extra long-lived secret is necessary.** A same-workflow design can use a
  job-scoped `GITHUB_TOKEN` with `contents: write`. Preserve full-SHA action pins
  and never expose that token to the validation/install/build jobs. GitHub calls
  a full commit SHA the only immutable way to consume an action
  ([secure use of Actions](https://docs.github.com/en/actions/reference/security/secure-use));
  the repo/org setting does not currently enforce that practice.

## Recommendation

The first-release implementation should add a small Taskfile-owned two-target
packager and one manually dispatched, multi-job Release workflow. It should
create annotated tags through the Git database API, build from the created tag,
publish reviewed notes and checksummed raw binaries through a draft Release,
and implement final promotion by peeling the RC tag and refusing any commit
drift. Use same-commit/rebuilt-final semantics so the final binary's embedded Go
module version is `v0.1.0`; document that this intentionally does not promise
byte-identical RC and final assets.

GoReleaser remains a reasonable later substitution when the artifact matrix or
signing/SBOM/package needs expand. It is not needed to satisfy the first private
release, and it does not solve annotated-tag or promotion safety by itself.
