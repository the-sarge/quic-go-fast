# Issue #1815: Darwin recvmsg_x at a full receive queue

Research for [Does Darwin recvmsg_x save receiver CPU when the queue is full?](https://github.com/GridSwarm/wiremux/issues/1815) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). It adds a Darwin `recvmsg_x` receiver to the rig's raw `udp` arm, measures it against one `recvmsg` per datagram in the overrun single-socket cell on `tb`, derives where it breaks even, and checks the ticket's precommitted gate. It also measures the connected-socket shape that macOS now ships. Nothing here changes wiremux or the fork.

Sources are wiremux at `origin/main` [870295a4](https://github.com/GridSwarm/wiremux/tree/870295a4), the rig `cmd/nativerig` from `codex/native-gap-rig` [582257ec](https://github.com/GridSwarm/wiremux/tree/582257ec2f486c27a44ef346e45fb7310ca80c87/cmd/nativerig) (this ticket's additions: `-recvmsg`, `-recvx`, `-sendx` and a receiver table), the quic-go-fast fork's closed D2 experiment [the-sarge/quic-go-fast#259](https://github.com/the-sarge/quic-go-fast/pull/259) at `b3f11ad5` (the wrapper this copies) with its [protocol](https://github.com/the-sarge/quic-go-fast/blob/b3f11ad5/docs/audits/2026-09-12-d2-recvmsgx-protocol.md) and [results](https://github.com/the-sarge/quic-go-fast/blob/b3f11ad5/docs/audits/2026-09-12-d2-recvmsgx-results.md), the xnu source closest to the hosts' kernel that Apple publishes ([xnu-12377.121.6](https://github.com/apple-oss-distributions/xnu/tree/xnu-12377.121.6); both Macs run xnu-13432.1.9), and measurements taken for this note on 2026-10-16 UTC. Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cell.** `tb` only: mbp128 (M4 Max, 16 cores) sends from `bridge0` over Thunderbolt to m4mini (M4 Pro, 12 cores), both macOS 27 arm64, MTU 1500. The measured receiver is one raw IPv4 socket bound to m4mini's `bridge0` address, unconnected, with a 7 MiB receive buffer. The raw senders set don't-fragment (`-df`), the like-for-like raw baseline in the rig protocol.

## Answer

- **The gate passes as written.** At 8 slots, `recvmsg_x` cut the receiver's CPU per delivered GiB by 56%, 56% and 58% against one `recvmsg` per datagram, in three headline campaigns (9.74 → 4.28, 9.56 → 4.22 and 10.28 → 4.32 CPU-s/GiB, medians of 5 runs each, **measured**). The gate needed 25%. System CPU fell 54–56% and user CPU 94–95%, so the split doesn't change the verdict. The gap of about 5.5 CPU-s/GiB is far larger than the ±0.5–1 CPU-s/GiB run-to-run noise [#1827](https://github.com/GridSwarm/wiremux/issues/1827) found on this receiver.
- **Most of that saving is a change of state, not cheaper calls.** The full-queue baseline sits in a costly state that `recvmsg_x` at 4 or more slots never enters.
  - With the queue full and the socket buffer dropping, every receive call costs about 12–14 µs of receiver CPU per datagram: `read`, `recvmsg` and `recvmsg_x` alike (**measured**).
  - With the queue shallow, the same calls cost 6.4–6.8 µs, and `recvmsg_x` at 4–32 slots costs 5.8 µs (**measured**).
  - So within one state, 8 slots save about 10% against `read` and 15% against `recvmsg` (**derived**: 5.79 / 6.43 and 5.79 / 6.78, from the few baseline runs that stayed shallow). That is below the gate.
  - The single unconnected raw socket is bistable between these two states, which is why it delivers either about 105–125k or about 150–160k packets/s per run ([#1800](https://github.com/GridSwarm/wiremux/issues/1800)'s open question 4).
- **The break-even fill is about one datagram per call in this cell, and below two within one state** (**derived**).
  - Linear in fill between the 1- and 2-slot arms, the break-even is 1.05, 1.07 and 1.36 datagrams per delivering call in the three campaigns. A 1-slot `recvmsg_x` costs 2–4% more than `recvmsg`.
  - Among shallow-queue runs, 2 slots already cost less than one `recvmsg` or `read` (6.27 µs against 6.78 and 6.43). A fit of a per-datagram cost plus a per-call cost puts the break-even at 1.1 against `recvmsg` and 1.6 against `read`.
  - The same fit caps the one-state saving: even an unlimited fill would save only about 17% against `recvmsg` (5.6 / 6.78 µs).
  - On the connected socket, linear interpolation gives 2.1–2.7; the fit gives about 1.3.
- **Throughput rose too, because the reader left the costly state.** Delivery went from 110–122k to 161–164k packets/s (+35–46%, **measured**), and loss moved from the socket buffer to the receiving kernel's input thread, which became the wall (100% busy in the profile).
- **The connected row couldn't be filled.** A connected receiver driven by a `sendmsg_x` sender offering 0.66–0.92M packets/s delivered about 0.77M. Its queue stayed mostly shallow (median 8–76, brief bursts to the 856-datagram limit), with socket-buffer drops of 0.01–0.4%. The driver's receive-buffer refills, not the reader, were the wall: they held 2–14% loss. There, 8 slots cut receiver CPU per GiB by 13%, 22% and 22% at a realised fill of 4.2–4.8 (**measured**), which is below the gate.
- **None of the three campaigns is clean by the protocol's letter, and all three agree.** C1 had two standard-slate runs collide with another session's build on the sending Mac. C2 and C3 are noisy by the one-third rule on the two bistable arms (`rm` in C2, `rx2` in C3). No run was replaced and no fourth campaign was run ([Method](#method)).
- **What this means for [#1816](https://github.com/GridSwarm/wiremux/issues/1816).** The pass is real, but it is the full-queue state's pass. A native receiver only reaches that state when it falls behind. At today's native rates its queue is shallow, with a median depth of 2–3 ([#1800](https://github.com/GridSwarm/wiremux/issues/1800)). The shipping shape is a connected socket, where the steady-state saving is 13–22% of receiver CPU. Batching would mostly act as insurance against the collapse: once a single unconnected reader falls behind, its per-datagram cost doubles and it stays behind.

## 1. What was built

All additions are on `codex/native-gap-rig` ([582257ec](https://github.com/GridSwarm/wiremux/tree/582257ec2f486c27a44ef346e45fb7310ca80c87/cmd/nativerig)); `PROTOCOL.md` documents each flag.

- **`-recvx N`** reads the `udp` receiver's socket with `recvmsg_x(2)` (syscall 480), up to `N` datagrams per call (1–64), each into its own 64 KiB buffer with its own 128-byte control buffer and address buffer.
  - The wrapper is copied from PR #259's `sys_conn_recvmsg_x_darwin.go`, with `msghdrX` from its `sys_conn_sendmsg_x_darwin.go`. Its qualification, allowlist and fallback are left out: the rig measures one known kernel and fails loudly.
  - The socket is nonblocking. Each read goes through `syscall.RawConn.Read`, and a call that returns `EAGAIN` parks on Go's poller, as in #259.
  - The receiver's result line counts every call (parked and interrupted ones included), the delivering calls, the parked calls, the datagrams and the fill histogram. From those it derives receive calls per datagram, mean and median fill, the share of full calls and parked calls per delivering call.
  - `-qdepth -qevery 64` samples `SO_NUMRCVPKT` before every 64th call, and `-rconnect` works with it.
- **`-recvmsg`** is the per-datagram baseline: one `recvmsg(2)` per datagram through Go's `ReadMsgUDPAddrPort`, into the same buffer sizes. That is the system call the native binding makes on macOS (`ReadMsgUDP`, [`unicast.go` L935](https://github.com/GridSwarm/wiremux/blob/870295a4/internal/routeselection/unicast.go#L935)).
- **The plain `udp` arm reads with `read(2)`, not `recvmsg`.** Its receiver calls `UDPConn.Read`, and #1800's system-call census lists `read` for it. So the `recvmsg` baseline had to be added. The plain arm is recorded as-is, and `rd` (`udp -df`) gives a `read` receiver behind the same `-df` sender as the new arms.
- **`-sendx N`** is a connected sender that hands the kernel `N` datagrams per `sendmsg_x(2)` call (syscall 481). On a connected datagram socket xnu takes its list path ([`uipc_syscalls.c` L1907](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_syscalls.c#L1907), **source**). No batched connected sender was on the rig branch for [#1856](https://github.com/GridSwarm/wiremux/issues/1856) to reuse, so this minimal one was added to drive the connected row. At 16 per call it offered 0.63–0.92M packets/s in the campaigns, against about 0.50M for one `write` per datagram with `-df` in a smoke pair (**measured**). Runs saw from none to a few thousand `ENOBUFS` calls.
- **`summarize.py`** gains a receiver table: CPU per GiB (total with min and max, user and system), user and system µs per datagram, cycles per datagram, calls per datagram, fill, full share and parked share.
- **Loopback unit tests** (`recvx_darwin_test.go`, `sendx_darwin_test.go`) pass on macOS 27, also under `-race -count=20`. They cover what #259's tests did, against the real kernel where #259 used a scripted one:
  - a full batch in one call with each slot's own length, contents and source;
  - a queue deeper than the slots draining as 4, 4 and 2;
  - `EAGAIN` parking and waking;
  - a close ending a parked read;
  - a connected socket;
  - scripted `EINTR` and out-of-range counts;
  - the `msghdr_x` layout;
  - truncation (below).
- **Truncation, measured on macOS 27.** A datagram longer than its slot comes back cut to the slot. Its `msg_datalen` equals the buffer length, and its `msg_flags` carries no `MSG_TRUNC`. That matches the source: `recvmsg_x` ORs `MSG_TRUNC` into the call's own flags ([L2868](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_syscalls.c#L2868)), which go back to the kernel's argument copy and not to the caller ([L2935](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_syscalls.c#L2935)). A user of `recvmsg_x` can only detect truncation as "length equals buffer". The rig counts that as `truncated`, and it stayed zero in every run.

## 2. Is the queue full?

A smoke pass (`smoke/s1`–`s3`, never evidence) and the `-qdepth -qevery 64` companions in every campaign answer this. Per campaign, the companions' medians of per-run medians, with means (**measured**):

| Arm | Queue depth before reads: median / mean | Socket-buffer drops per run (median) | Full? |
| --- | --- | --- | --- |
| `rmq` (`recvmsg`) | 796–808 / 789–793 of about 856 | 311,135–351,687 | yes: the buffer holds about 856 datagrams on this cell, and the p90 is at or near that limit in every run |
| `rx1q` | 808–812 / 798–802 | 346,533–371,741 | yes |
| `rx2q` | 256–758 / 360–740 | 52,298–63,808 | in 8 of 15 runs (median above 500) |
| `rx4q` | 50–71 / 74–90 | 0 | no |
| `rx8q` | 2–7 / 16–24, empty at 3% of samples | 0 | no |
| `crmq` (connected, `recvmsg`) | 15–26 / 21–50; bursts to 856 | 2,924–21,078 | no: shallow, with bursts |
| `crx8q` (connected, 8 slots) | 3 / 4–19, empty at 21–30% | 31–9,724 | no |

- **The baseline cell is overrun at the socket.** One `recvmsg` per datagram keeps the queue at the buffer's limit and drops 21–25% of what reaches the socket there (**derived**: drops / (delivered + drops), run medians).
- **Four slots or more empty the queue.** The reader then drains faster than the receiving kernel's input thread delivers. That thread costs 6.0–6.7 µs per datagram for an unconnected socket ([#1800 §4](https://github.com/GridSwarm/wiremux/blob/b8dd6735e07434cf8276a6313ea127cf054775fb/docs/research/issue-1800-macos-native-ceiling.md#4-the-receiving-kernels-per-datagram-cost)), so it saturates at 160–170k packets/s.
- **Raising the offered rate didn't refill it.** The `frm`/`frx8` arms replace the 231–283k packets/s `-df` sender with the connected `-sendx 16` sender at 0.63–0.80M packets/s, into the same unconnected receiving socket. `frx8` still dropped nothing at the socket buffer; the extra load was lost at the driver as receive-buffer refill failures (**measured**). So the 4-slot-and-up arms can't be overrun at the socket on this cell, because the wall moves below it. The ticket's "queue full" condition holds for the baseline arms and for 1 and 2 slots, not for 4 and up.

## 3. Results on `tb`

Three headline campaigns, each `REPS=5 SECS=10` with a warm-up rotation and `LOADGATE=1`: C1 (04:07–05:29 UTC), C2 (05:29–06:37) and C3 (06:53–07:42), all at rig `582257ec`, clean tree. Each carries the standard slate and 20 added arms (the arm list is in each `meta.txt`):

- `rd` (`read`), `rm` (`recvmsg`), `rx1`, `rx2`, `rx4`, `rx8`, `rx16` and `rx32` (`recvmsg_x` at N slots), all behind the `-df` sender;
- `-qdepth -qevery 64` companions `rmq`, `rx1q`, `rx2q`, `rx4q` and `rx8q`;
- `frm` and `frx8`: the unconnected receiver behind the connected `-sendx 16` sender;
- `crm`, `crx1`, `crx8`, `crmq` and `crx8q`: a connected pair (`-connected -rconnect`) with the `-sendx 16` sender.

None of the three is clean by the protocol's letter; see [Method](#method). Medians of 5 runs per arm (**measured**):

| Arm | C1 pkt/s | C1 receiver CPU-s/GiB (min–max) | C2 pkt/s | C2 CPU-s/GiB | C3 pkt/s | C3 CPU-s/GiB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `udp` (`read`, no `-df`) | 147,154 | 7.67 (4.67–10.02) | 151,133 | 5.56 (4.56–9.64) | 136,997 | 8.09 (7.75–9.77) |
| `rd` (`read`) | 139,248 | 7.59 (5.75–9.38) | 158,039 | 5.44 (4.92–9.20) | 134,816 | 8.81 (5.98–9.64) |
| `rm` (`recvmsg`, baseline) | 119,319 | 9.74 (4.74–11.15) | 122,207 | 9.56 (5.13–10.34) | 110,507 | 10.28 (9.41–10.63) |
| `rx1` | 116,125 | 9.97 (9.09–11.19) | 116,720 | 9.87 (9.74–11.91) | 105,914 | 10.68 (9.88–12.14) |
| `rx2` | 150,741 | 5.45 (4.53–10.06) | 147,584 | 5.52 (4.59–10.04) | 127,177 | 9.56 (4.62–9.88) |
| `rx4` | 159,621 | 4.38 (4.35–4.57) | 160,986 | 4.39 (4.31–4.40) | 158,480 | 4.57 (4.40–5.11) |
| `rx8` | 162,828 | 4.28 (4.24–4.32) | 164,475 | 4.22 (4.19–4.30) | 161,091 | 4.32 (4.23–4.32) |
| `rx16` | 160,118 | 4.28 (4.08–5.07) | 164,058 | 4.19 (4.17–4.22) | 159,384 | 4.26 (4.07–4.40) |
| `rx32` | 161,071 | 4.30 (4.17–5.20) | 164,462 | 4.17 (4.07–4.22) | 163,506 | 4.23 (4.19–4.33) |
| `frm` (fast sender, `recvmsg`) | 122,098 | 9.31 (8.86–12.97) | 113,013 | 9.96 (8.68–10.43) | 108,566 | 10.36 (9.30–11.02) |
| `frx8` (fast sender, 8 slots) | 168,590 | 4.15 (3.89–5.11) | 168,083 | 4.07 (3.95–4.28) | 170,695 | 4.01 (3.92–4.28) |
| `crm` (connected, `recvmsg`) | 766,204 | 0.70 (0.69–0.81) | 766,789 | 0.67 (0.64–0.75) | 773,897 | 0.69 (0.66–0.71) |
| `crx1` | 710,802 | 0.77 (0.74–0.87) | 723,030 | 0.75 (0.73–0.85) | 714,255 | 0.78 (0.75–0.86) |
| `crx8` | 719,389 | 0.60 (0.54–0.90) | 813,536 | 0.53 (0.52–0.56) | 820,901 | 0.54 (0.54–0.58) |
| `udp4` | 156,988 | 3.39 | 156,848 | 3.30 | 158,642 | 3.26 |
| `binding` | 91,752 | 10.45 | 94,386 | 10.41 | 88,955 | 10.46 |
| `dgram` | 132,131 | 19.96 | 139,899 | 21.19 | 146,062 | 20.32 |
| `stream` | 1,433 Mbit/s | 16.12 | 1,525 Mbit/s | 16.88 | 1,593 Mbit/s | 16.99 |

Receive calls, realised fill (mean datagrams per delivering call), the share of calls that filled every slot, and parked calls per delivering call (**measured**):

| Arm | C1 | C2 | C3 |
| --- | --- | --- | --- |
| `rx1` | 1.001 calls/datagram, fill 1.00, 100% full, 0.001 parked | 1.000, 1.00, 100%, 0.000 | 1.000, 1.00, 100%, 0.000 |
| `rx2` | 0.501, 2.00, 100%, 0.001 | 0.501, 2.00, 100%, 0.002 | 0.500, 2.00, 100%, 0.000 |
| `rx4` | 0.253, 3.98, 99%, 0.007 | 0.251, 3.99, 100%, 0.004 | 0.252, 3.99, 99%, 0.005 |
| `rx8` | 0.140, 7.56, 71%, 0.056 | 0.137, 7.58, 70%, 0.037 | 0.140, 7.43, 51%, 0.054 |
| `rx16` | 0.104, 10.59, 34%, 0.088 | 0.112, 10.22, 30%, 0.065 | 0.131, 8.36, 11%, 0.093 |
| `rx32` | 0.095, 11.61, 8%, 0.109 | 0.115, 9.52, 3%, 0.064 | 0.112, 9.36, 3%, 0.053 |
| `frx8` | 0.139, 7.58, 61%, 0.062 | 0.153, 7.34, 39%, 0.120 | 0.140, 7.45, 50%, 0.043 |
| `crx1` | 1.022, 1.00, 100%, 0.022 | 1.005, 1.00, 100%, 0.005 | 1.004, 1.00, 100%, 0.004 |
| `crx8` | 0.296, 4.77, 19%, 0.328 | 0.297, 4.35, 14%, 0.289 | 0.301, 4.22, 14%, 0.270 |

`read` and `recvmsg` arms make one call per datagram plus parked calls inside Go's poller, which the rig cannot count. At these queue depths those parked calls are rare.

What the tables show:

- **8 slots fill well even with a shallow queue.** `rx8` realises 7.4–7.6 datagrams per call while its queue's median depth before a call is 2–7. For an unconnected socket, `soreceive_m_list` keeps taking datagrams while the buffer is non-empty ([`uipc_socket.c` L4247](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket.c#L4247)). It also drops and retakes the socket lock for a policy check on every datagram ([`soreceive_addr`, L2823–L2880](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket.c#L2823)), so arrivals during the call keep filling it (**source**; the inference is **derived**). Parked calls are 0.04–0.06 per delivering call, against D2's 0.615.
- **Fills above 8 add nothing.** 16 and 32 slots realise 8–12 and cost the same as 8 (4.17–4.30 CPU-s/GiB).
- **Delivery rises with 4 slots or more.** Every such arm delivers 158–171k packets/s, the receiving kernel's input-thread ceiling. The `recvmsg` and `read` baselines deliver 105–158k depending on their state (section 5).
- **The standard slate matches earlier tickets.** It reproduces the [protocol baseline](https://github.com/GridSwarm/wiremux/issues/1795#issuecomment-6055235817) and #1800 within their run-to-run ranges: native Datagrams 1,259–1,392 Mbit/s with no loss, `binding` 89–94k packets/s.

## 4. The gate

The precommitted gate: receiver CPU-s per delivered GiB falls by at least 25% at batch 8, against the per-datagram baseline, in the overrun cell. Ratio of medians, `rx8` against `rm` (**measured**):

| Measure | C1 | C2 | C3 |
| --- | --- | --- | --- |
| Total | 9.74 → 4.28 (−56%) | 9.56 → 4.22 (−56%) | 10.28 → 4.32 (−58%) |
| User | 0.55 → 0.03 (−94%) | 0.54 → 0.03 (−94%) | 0.59 → 0.03 (−95%) |
| System | 9.19 → 4.24 (−54%) | 9.02 → 4.19 (−54%) | 9.69 → 4.28 (−56%) |
| System µs per datagram | 12.43 → 5.74 | 12.20 → 5.66 | 13.10 → 5.79 |
| Behind the fast sender (`frx8` / `frm`), total | 9.31 → 4.15 (−55%) | 9.96 → 4.07 (−59%) | 10.36 → 4.01 (−61%) |
| Connected (`crx8` / `crm`), total | 0.70 → 0.60 (−13%) | 0.67 → 0.53 (−22%) | 0.69 → 0.54 (−22%) |

- **Pass on total CPU, in all three campaigns.**
- **The user/system split doesn't change it.** System time is 94% of the baseline's CPU and falls 54–56%. User time falls 94–95%.
- **The noise band doesn't change it on medians.** `rx8`'s runs span only 4.19–4.32 CPU-s/GiB.
- **The baseline's spread does matter for the worst case.** The baseline spans 4.74–11.15 because it is bistable. Against the baseline's best run (its single shallow-queue run in C1, 4.74), `rx8`'s worst run (4.32) is only 9% lower. In C2 it is 16% lower, and in C3, where every baseline run stayed full, 54% lower (**derived**).
- So the pass rests on the baseline being in its full-queue state. It was in 12 of its 15 runs (more than 5% of delivered datagrams dropped at the socket buffer).

## 5. The bistable baseline

Receiver CPU per delivered datagram (user + system), binned by each run's socket-buffer drops as a share of its delivered datagrams. Every unconnected single-socket run in all three campaigns is included, as runs: median (min–max) (**measured**):

| Socket-buffer drops / delivered | `read` (`udp`, `rd`) | `recvmsg` (`rm`, `rmq`, `frm`) | `recvmsg_x` 1 | `recvmsg_x` 2 | `recvmsg_x` 4–32 |
| --- | --- | --- | --- | --- | --- |
| 0–1% | 6: 6.43 µs (6.17–6.79) | 2: 6.78 (6.41–7.16) | – | 8: 6.27 (6.13–7.37) | 105: 5.79 (5.26–7.03) |
| 1–5% | 6: 7.93 (7.35–9.63) | 2: 8.19 (6.93–9.45) | – | 9: 8.45 (7.46–11.80) | – |
| 5–15% | 16: 11.48 (9.18–13.55) | 2: 12.55 (12.36–12.73) | 2: 13.07 (12.51–13.63) | 11: 12.57 (9.33–13.58) | – |
| 15–25% | 2: 13.12 (13.04–13.21) | 5: 12.43 (11.75–12.86) | 3: 12.92 (12.30–13.17) | 2: 13.48 (13.36–13.61) | – |
| 25% and more | – | 34: 14.00 (11.74–17.54) | 25: 14.18 (13.17–16.42) | – | – |

- **The receive call barely matters; the state does.** With the buffer full, every call costs 12–14 µs per datagram. With the queue shallow, `read`, `recvmsg` and 2-slot `recvmsg_x` cost 6.3–6.8 µs. So the bimodal arm medians in section 3 mostly report how many runs each arm spent in each state: `rd` landed shallow more often than `rm`, not more cheaply.
- **The state is self-sustaining.** The input thread costs 6.0–6.7 µs per datagram ([#1800](https://github.com/GridSwarm/wiremux/issues/1800)), about the same as a shallow-queue reader. A reader that keeps up stays shallow. One that falls behind fills the buffer, doubles its per-datagram cost and can't catch up. That is the single unconnected socket's 115k / 160k bimodality (**derived** from the two tables and #1800's input-thread cost).
- **2 slots straddle the edge.** At about 6.3 µs shallow, `rx2` is bimodal too: shallow (under 5% drops) in 17 of the 30 `rx2` and `rx2q` runs, full in the rest.
- **4 slots or more stay clear of it.** They cost 5.8–6.0 µs, below the input thread's cost, so the reader always keeps up.
- **Within one state the saving is small.** Among shallow-queue runs only (under 1% drops), 4–32 slots cost 5.79 µs (105 runs; `rx8` alone also 5.79, 15 runs) against 6.43 for `read` (6 runs) and 6.78 for `recvmsg` (2 runs): −10% and −15% (**derived**). Both are below the 25% gate, and the baseline side rests on few runs.
- **Per-call cost, roughly.** Fitting cost = a + b / fill to the shallow 4- and 8-slot arms gives about 5.6 µs per datagram plus about 1.3 µs per call (**derived**: 5.95 and 5.79 µs at fills 3.99 and 7.56, the `rx4` and `rx8` shallow runs). The fit predicts 6.3 µs at 2 slots, against 6.27 measured. It puts no fill below 5.6 µs, so in one state no fill can save more than about 17% against `recvmsg` or 13% against `read` (**derived**).
- **One slot is dearer.** A 1-slot `recvmsg_x` costs 2–4% more than `recvmsg` in the full state, and 10–12% more on the connected socket (**measured**).

## 6. Break-even fill

**Derived.** Receiver µs per datagram against realised fill, interpolated linearly in fill between the arms that bracket the baseline's cost:

| Where | Baseline µs/datagram | 1 slot | 2 slots | 4 slots | 8 slots | Break-even fill |
| --- | --- | --- | --- | --- | --- | --- |
| C1, overrun cell | `rm` 13.18 | 13.48 (+2%) | 7.37 (−44%) | 5.93 | 5.79 (fill 7.56) | 1.05 |
| C2 | 12.93 | 13.35 (+3%) | 7.46 (−42%) | 5.93 | 5.70 (7.58) | 1.07 |
| C3 | 13.90 | 14.44 (+4%) | 12.93 (−7%) | 6.18 | 5.84 (7.43) | 1.36 |
| Shallow-queue runs only, pooled | `recvmsg` 6.78, `read` 6.43 | – (fit: 7.0) | 6.27 | 5.95 | 5.79 | 1.1 against `recvmsg`, 1.6 against `read` (fit) |
| Connected, C1 / C2 / C3 | `crm` 0.94 / 0.91 / 0.94 | +10% / +11% / +12% | – | – | fill 4.77 / 4.35 / 4.22: −13% / −22% / −22% | 2.67 / 2.14 / 2.15 (linear); about 1.3 (fit) |

- In the overrun cell, any fill above about one datagram per call pays, because it changes the state. C3's figure is higher because `rx2` stayed in the full state there in 4 of 5 runs.
- In one state the break-even is between one and two datagrams per call. The shallow state has no 1-slot runs, so this comes from the per-call fit of section 5.
- On the connected socket only the 1- and 8-slot arms exist. Linear interpolation between them is an upper bound, because cost falls as 1 / fill. The same fit (about 0.64 µs per datagram plus 0.39 µs per call, pooled) gives about 1.3.
- #1798's reopen rule needs a measured mean read-time queue depth above the break-even fill. On the connected socket the break-even is 1.3–2.7 datagrams per call. At today's native rates, the unconnected native receiver's queue had a median of 2–3 and a mean of 11–14 (#1800). The connected native receiver's depth is not measured.

## 7. The connected row

- **Shape.** `udp -connected -rconnect -df -sendx 16`: the sender connects and sends 16 datagrams per `sendmsg_x` call. The receiver connects to the first sender after its first datagram and reads with `recvmsg` (`crm`) or `recvmsg_x` at 1 or 8 slots (`crx1`, `crx8`).
- **It isn't full.**
  - Offered: 0.66–0.92M packets/s.
  - Delivered: about 0.77M (`crm`), and 0.72–0.82M (`crx8`).
  - The queue sat at a median of 8–76 datagrams before reads, with p99s of 100–830 and bursts to the 856 limit.
  - Socket-buffer drops: about 1k–28k per run against about 7.7M delivered (0.01–0.4%).
  - Loss was 2–14%, almost all receive-buffer refill failures in the driver (`16k fail`).
  - So the connected receiving kernel, not the reader, binds first on this cell. The reader costs 0.9 µs per datagram there, against 1.7–1.8 µs for the input thread (#1800); the faster sender doesn't change that (**measured**; the bottleneck is **derived** from where the loss is).
- **What batching buys there.** 8 slots cut receiver CPU per GiB by 13–22%: system time 8–18% and user time about 47%, at a realised fill of 4.2–4.8 with 0.27–0.33 parked calls per delivering call. That is below the gate, which doesn't apply to this row. 1 slot costs 10–12% more than `recvmsg`. On a connected socket xnu skips the per-datagram policy check with its lock drop (it runs only for unconnected sockets, `soreceive_addr`, **source**). There is less per-datagram work to amortize, and the call's fixed costs weigh relatively more.

## 8. Where the time goes

Hand-run pairs after the campaigns, outside them (PROTOCOL.md profiling rule): one system-wide Time Profiler recording on m4mini per pair, window 8–15 s, frames resolved from the binary kept with the recording (`X/`). Kernel stacks need root, so kernel time shows as the system-call leaf.

| Pair | Delivered pkt/s | Receiver process | Its threads | In the receive call | In `kevent` (Go's poller) | Input thread `dlil_input_en2` |
| --- | ---: | ---: | --- | ---: | ---: | ---: |
| `rm-1` (`recvmsg`, full state) | 97,394 | 1.23 cores | 3, at 35–49% each | 0.85 cores (8.7 µs/datagram) | 0.33 cores (3.4 µs/datagram) | 86% |
| `rm-2` (`recvmsg`, full state) | 86,741 | 1.36 cores | 4, at 19–41% | 0.94 cores (10.8 µs) | 0.36 cores (4.2 µs) | 95% |
| `rx8-1` (8 slots) | 163,438 | 0.92 cores | 2, at 46% each | 0.91 cores (5.6 µs) | 0.01 cores | **100%** |

The per-datagram figures are **derived** (cores / datagrams per second). The rest is **measured**.

- **In the full state the receiving process spends about a third of a core in `kevent`.** That happens even though its reader never waits for data. Its one reader goroutine also hops among three or four OS threads; the `kevent` time sits under `findRunnable` / `netpoll` on threads not running the reader.
  - The receive call itself is also dearer: 8.7–10.8 µs per datagram, against 5.6 µs per datagram inside an 8-slot `recvmsg_x` (whose shallow-queue `recvmsg` equivalent is about 6.4 µs, section 5).
  - `rusage` agrees across the campaigns: receivers in the full state burn 1.5–1.6 cores, and shallow ones 0.92–1.0 (C1, **measured**).
- **With 8 slots there is no such churn.** The reader stays on two threads, 98% of its samples are inside `recvmsg_x`, and the receiving kernel's input thread is saturated. That is the 160–170k ceiling.
- **Why the full state costs more is not measured.** Kernel stacks would settle it. The source suggests contention on the socket lock among three parties: the input thread appending to, or failing to append to, a full buffer; the reader dropping and retaking that lock for every datagram's policy check; and the poller threads' `kevent` calls, which evaluate the socket's read filter. The `kevent` churn looks like Go's scheduler handing the processor away during slow receive calls (**hypothesis**).
- m4mini's `mediaanalysisd` ran on efficiency cores during the recordings (about 0.85 cores). The receiver's threads ran on performance cores throughout (99–100% of samples).

## 9. What this changes elsewhere on the map

- **For [#1816](https://github.com/GridSwarm/wiremux/issues/1816) (should the fork and wiremux batch macOS receives).** The ticket's gate passes, so #1816 gets this input:
  - **The mechanism works and is safe to rely on.** It returned correct lengths and sources in the unit tests, met no truncation or structural error in 252 campaign runs, and its 8-slot fill is high even with a shallow queue.
  - **The big saving is protection, not steady-state CPU.** A receiver that falls behind on an unconnected socket collapses into a state that costs twice the CPU per datagram. In this cell 4 or more slots prevented that and raised delivery 35–46%. A native receiver reaches that state only when it is the bottleneck. Today it isn't: its queue median is 2–3 (#1800).
  - **The steady-state saving on the shape that ships is 13–22% of receiver CPU** (connected socket, 8 slots, fill 4.2–4.8). On its own that is below this ticket's 25% bar. Whether it is worth a private system call in wiremux's binding, plus the fork offering wrappers more than one slot on Darwin (#1798's two conditions), is #1816's call.
  - **xnu reports truncation only as "length equals buffer"** (section 1). A production wrapper must size slots to the largest datagram it accepts, or treat a full slot as truncated.
- **For [#1798](https://github.com/GridSwarm/wiremux/issues/1798)'s reopen rule.** Pre-check 2 (this one) passes on the letter. Its break-even is about 1 datagram per call in the overrun cell, 1.1–1.6 in one state, and 1.3–2.7 on a connected socket.
- **For #1800's open question 4.** The single unconnected raw socket's bimodality is a self-sustaining full-buffer state, with about twice the receiver CPU per datagram (section 5). That is measured here. Its kernel cause is a hypothesis.

## Method

- **Builds.** Both campaign binaries were built by the rig itself from `582257ec` (clean tree; `meta.txt`: `dirty=0`), with the fork `v0.62.1-fast.7` through `rig.mod`.
  - **Toolchain deviation.** The rig branch's `go.mod` says `toolchain go1.27.1`, and the installed base Go here is 1.27.1, so every rig build and test in this ticket used go1.27.1. That is below this repository's go1.27.2 floor. Earlier sessions' rig builds used go1.27.2 because their worktrees carried a newer `go.mod`. The measured code is the same, but it is recorded as a deviation.
- **Scheduling.** Every run went through `scripts/rig1815.sh`. It is `rig.sh` with three scheduling-only changes:
  - a per-run busy gate on both Macs: any other session's `nativerig` send or receive, `tb` rig driver, pair or hold marker or `xctrace`, with full command lines from `ps -axo`;
  - a re-check after the "before" counter snapshots, retaking them if anything appeared, so a receiver starts right after a clear check;
  - a private receiver directory on m4mini (`/tmp/nativerig1815`).
  `LOADGATE=1` (load1 ≤ 8) applied to every run. Waits and starts are logged per campaign (`waits.log`, `starts.log`). The gate waited for other sessions' work before 11, 11 and 3 runs, and re-took the snapshots 9, 7 and 2 times; one C1 wait was a false positive, another session's tool shell whose command line named a `nativerig` sender. No run started with either Mac's load1 above 8, and no load flag fired.
- **Protocol status of the three campaigns.**
  - **C1 collided.** #1853's coordination log records a `go vet` and two `go build`s on mbp128, using all cores for 20–40 s at 04:53:50–04:54:35. That window covers C1's `r3-udp` and `r4-binding`, two standard-slate runs on the sending Mac. Neither run was flagged, and their senders' rates and per-packet costs look like the other runs'.
  - **C2 is noisy.** `rm` had 2 of 5 runs flagged as rate outliers (1.24× and 1.20× its median, its shallow-state runs).
  - **C3, the full repeat of C2, is noisy too.** `rx2` had 2 of 5 runs flagged (1.24× and 1.22×).
  - Both noisy arms are the bistable ones in section 5. As in #1800, the noise is structural on this cell, and another repeat would probably be flagged again. No fourth campaign was run, and no run was replaced.
  - The gate arms agree across all three campaigns: `rm`'s medians 9.56–10.28, `rx8`'s 4.22–4.32.
- **The other session.** #1853's claim placeholders (idle processes) coexisted with the first 1–5 s of 9 of this ticket's runs: each claim collided with a run that had just started and was released. #1853 ran no pair or load during them (its `overlap.log` and `claim.log`).
- **Profiles.** `scripts/xpair1815.sh` gated the same way, and ran after the campaigns had exited. Two baseline pairs were taken because the baseline is bistable; both landed in the full state.

## Open questions

1. **What makes the full-buffer state cost twice as much per datagram?** The candidates are socket-lock contention among the input thread, the reader's per-datagram policy check and the poller's `kevent` calls, plus Go's processor hand-offs during slow calls. Kernel stacks (root on m4mini) and a Go execution trace of a full-state receiver would separate them.
2. **Does a native receiver, once it falls behind, collapse the same way?** The native binding reads with `recvmsg` from Go on an unconnected or, now, connected socket. The connected socket skips the per-datagram policy check, so the state may not exist there at all. That was not measured, because the connected receiver couldn't be filled on this cell.
3. **Is a full-slot "truncation" ever a real datagram on the native path?** No, if slots are sized to the maximum packet, but a production wrapper must decide.

## Evidence

Everything is in `/Volumes/worktrees/wiremux/native-gap-evidence/1815-recvmsgx-full-queue/` (`README.txt` indexes it):

- the campaigns `C1/`, `C2/` and `C3/`, each with `meta.txt`, `summary.txt`, `summary.json`, `runs/`, `waits.log` and `starts.log`, and the built binaries;
- `notetables.md` and `an-C1-C2-C3.txt`, the tables above (`scripts/notetables1815.py`, `scripts/an1815.py`);
- the profiles `X/rm-1`, `X/rm-2` and `X/rx8-1`, each with its trace, export, binary and `xthreads.txt`;
- the smoke passes `smoke/s1`–`s3`, never evidence;
- the scripts in `scripts/`.
