# Local reliable-stream baseline

The corrected diagnostic completed its two clean captures and one separate TLS CPU capture on 2026-09-06 from clean revision `a4f5273842925d11167156f1aa944dd1501a26da`. Every declared measurement byte was validated. These are local harness examples, not capacity rankings, physical qualification or GridCast end-to-end measurements.

## Provenance and retained history

The optimized binary SHA-256 is `0ab41bbaf0ffe759070d7a7b5d6fd5ceee236857cc00a8d7ee50135f778e5c20`. The durable archive `/Users/josh/Documents/wiremux-measurements/1464-20260906-fixed` holds that binary, configuration/results, stderr, profiles and pprof output. [Archive inventory](archive-manifest.json) records file sizes/digests; [derived summary](summary.json) retains the table inputs. Report-only commits do not relabel the binary revision.

The earlier captures at `6aa6f47` remain in the [historical report](historical-6aa6f47.md), [historical summary](historical-summary-6aa6f47.json), [historical inventory](historical-manifest-6aa6f47.json) and original raw folders. Their TCP setup included unused certificate work, and controller cancellation could lose available partial results. The [review ledger](review.md) records those repairs. Each corrected configuration ran once; these are code-repair replacements, not repeated unchanged-code attempts to obtain passing performance.

Both clean modes used 1076-byte records, 100,000,000 offered bit/s, batched writes, GOMAXPROCS=4, 5 s warmup, 10 s measurement and up to 10 s drain. The separate CPU capture used 0 s warmup, 2 s measurement and up to 1 s drain. All three ran sequentially on Apple M4 Max / Darwin 25.6.0 arm64 / Go 1.27.0 / loopback lo0 MTU 16384. “Clean” means heavy profiling disabled; no affinity or quiet-host reservation was imposed. No external profiler, iperf, physical or impairment campaign ran.

## Delivered workload

| Run | Receiver-window Mbps | Desired = validated bytes | Late records | Cohort completion seconds |
| --- | ---: | ---: | ---: | ---: |
| [tcp](raw/final-tcp/result.json) | 99.992250 | 124999996 | 9 | 10.000109437 |
| [tls-tcp](raw/final-tls-tcp/result.json) | 99.989667 | 124999996 | 12 | 10.000612292 |
| [tls-cpu](raw/final-tls-cpu/result.json) | 99.973312 | 24999784 | 6 | 2.000011584 |

Eventual desired-cohort delivery was 100% in every run, with zero desired-unreceived, accepted-unreceived or unsent bytes at completion. Late records were excluded from receiver-window goodput. Receiver integrity/sequence checks, terminal counts and final EOF completed. The raw per-phase records retain write-call wall time, latency histograms, observed scalar backlog and materialized-output maxima; these do not infer kernel queue size or CPU time from blocked wall time.

TLS/TCP negotiated TLS 1.3 / TLS_AES_128_GCM_SHA256 with mutual ephemeral Ed25519 certificate pins. Setup and handshake durations are in both transport receipts. Raw TCP now generates/exchanges no certificate material and has no authentication/encryption. All modes enable TCP_NODELAY and retain OS-default buffers; effective buffer sizes, congestion and offloads remain unobserved. These differences preclude treating TCP as a substitute for QUIC acceptance.

## Resources and limits

Each CPU delta uses the first/last user-plus-system samples and their actual monotonic span. Resident peaks are sampled current proc_taskinfo resident bytes, not lifetime high-water RSS or instantaneous maxima. The diagnostic's generation/checking, runtime and collector costs are included; controller and foreign processes are excluded.

| Run / role | CPU seconds | Average cores | Sampled resident peak MiB | Post-drain GC heap MiB | Allocated MiB | Largest collection ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| tcp / send | 0.398851 | 0.0399 | 18.266 | 0.461 | 2.089 | 0.961 |
| tcp / receive | 0.255052 | 0.0255 | 14.031 | 0.483 | 0.048 | 0.694 |
| tls-tcp / send | 0.587149 | 0.0587 | 19.359 | 0.529 | 1.883 | 1.636 |
| tls-tcp / receive | 0.381181 | 0.0381 | 15.219 | 0.533 | 0.049 | 1.884 |
| tls-cpu / send | 0.107119 | 0.0536 | 16.172 | 0.605 | 0.583 | 5.935 |
| tls-cpu / receive | 0.070428 | 0.0352 | 15.547 | 0.576 | 0.168 | 0.736 |

Raw records retain local clock uncertainty, actual launch lateness, sample offsets and collection wall time. Effective OS CPU update resolution, collector CPU overhead, quiet-host conditions and physical alignment remain unqualified. Any collection above 1 ms exceeds S1's physical per-sample budget; retaining a complete local cohort does not waive that budget. Host load snapshots are retained in the durable archive. No result was discarded to hide scheduling or sampling deficits.

Both corrected CPU profiles passed run/role/hash/size checks, were untruncated and parsed against the archived binary: [sender pprof](raw/final-tls-cpu/send-pprof-top.txt), [receiver pprof](raw/final-tls-cpu/receive-pprof-top.txt). Profile windows include their declared preparation prefix and measurement; sampled profile weights are not the CPU-accounting source.

[Usage instructions](../../MEASUREMENT.md#local-reliable-stream-references-version-2) define versioned configuration, record/buffer/accounting semantics, profiling, memory definitions and independent iperf controls. [S3 (#1465)](https://github.com/GridSwarm/wiremux/issues/1465) can extend the engine to QUIC layers. [S1](../../work-items/1463-reliable-stream-workload.md) continues to govern physical qualification, including Windows runtime/host accounting, finite matrix and instrumentation budgets. No production optimization or end-to-end consumer benefit follows from this local report.
