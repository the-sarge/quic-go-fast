# Local reliable-stream baseline

All three approved captures completed on 2026-09-06 using clean code revision `6aa6f478c10e050d7694cb3c823e5aa9a9faea68`. Both clean transports validated every declared measurement byte; late receipt remains separate from window goodput. These are local harness examples, not capacity rankings or physical qualification under [S1](../../work-items/1463-reliable-stream-workload.md).

## Configuration and provenance

TCP and TLS/TCP ran once each, sequentially, at 100,000,000 offered bit/s with 1076-byte records, batched writes, GOMAXPROCS=4, 5 s warmup, 10 s measurement and up to 10 s drain. Heavy profiling was disabled for both. The separate TLS CPU capture used 0 s warmup, 2 s measurement and up to 1 s drain. There were no replacement runs. “Clean” describes disabled heavy instrumentation, not a quiet host. No physical, impairment, external-profiler or iperf campaign ran.

The optimized binary SHA-256 is `6c328ce6ca38becc099b9dacd7f31c9cf8603b689664ffd71fe7ab6a8bbbabad`. The durable archive `/Users/josh/Documents/wiremux-measurements/1464-20260906` retains the binary, configurations, raw results, stderr, CPU profiles and parsed pprof output. [Archive inventory](archive-manifest.json) records sizes and digests. Report-only commits do not relabel the code revision. [Derived summary](summary.json) and raw links below retain the observed values.

Host: Apple M4 Max, Darwin 25.6.0 arm64, Go 1.27.0, loopback lo0 MTU 16384, 16 logical CPUs. No affinity or quiet-host reservation was imposed. One-minute load averages were 12.61 before and 21.39 after the captures; ongoing background work and review processes were present. The implementing agent's repository verification had completed before capture. These observations do not establish OS causality, NIC capacity, instrumentation overhead qualification, or VM/host cost.

## Delivered workload

| Run | Receiver-window Mbps | Desired = validated bytes | Late records | Cohort completion seconds | Eventual completion |
| --- | ---: | ---: | ---: | ---: | --- |
| [tcp](raw/tcp/result.json) | 99.999997 | 124999996 | 0 | 9.999991417 | Complete |
| [tls-tcp](raw/tls-tcp/result.json) | 99.993110 | 124999996 | 8 | 10.000116250 | Complete |
| [tls-cpu](raw/tls-cpu/result.json) | 99.969008 | 24999784 | 7 | 2.000007771 | Complete |

All three had zero desired-unreceived, accepted-unreceived and unsent bytes at completion. Eight TLS clean records and seven TLS CPU records arrived during drain; they did not increase receiver-window goodput. A locally accepted write alone never counted as delivery. Warmup and terminal-record overhead are excluded from bulk metrics. The receiver verified the ordered deterministic content, terminal count and final EOF.

TCP sender write-call wall time totaled 102.747 ms with a 65.535 µs p99 upper bound. TLS clean totaled 234.225 ms with a 262.143 µs p99 upper bound. These include copying/syscall work and blocking; they are not process CPU or pure kernel wait. Maximum observed materialized output was 47,344 bytes for TCP and 64,560 bytes for TLS, below the approved 129,120-byte cap. Each sender also retains observed scalar-backlog metrics in its phase result.

TLS clean negotiated TLS 1.3 / TLS_AES_128_GCM_SHA256 with bilateral ephemeral Ed25519 certificate pins. Sender/receiver TLS handshakes took 0.762/0.801 ms; total setup took 2.608/1.938 ms. TCP has no encryption/authentication. All use TCP_NODELAY and untuned OS-default socket buffers; effective buffer sizes, congestion and offloads were not independently observed. These are declared differences, not grounds for substituting TCP for production QUIC.

## Resources and timing limits

CPU below uses each endpoint's first/last cumulative user-plus-system samples and actual sample span. Resident peaks are maxima of current proc_taskinfo samples, not lifetime high-water RSS or instantaneous maxima. Allocation and post-drain heap costs include the diagnostic engine. Controller and foreign-process costs are excluded.

| Run / role | CPU seconds | Average cores | Sampled resident peak MiB | Post-drain GC heap MiB | Allocated MiB |
| --- | ---: | ---: | ---: | ---: | ---: |
| tcp / send | 0.406454 | 0.0406 | 18.375 | 0.453 | 2.081 |
| tcp / receive | 0.257435 | 0.0257 | 14.141 | 0.470 | 0.044 |
| tls-tcp / send | 0.465452 | 0.0466 | 19.188 | 0.506 | 1.894 |
| tls-tcp / receive | 0.307321 | 0.0307 | 15.078 | 0.520 | 0.043 |
| tls-cpu / send | 0.090551 | 0.0453 | 16.141 | 0.581 | 0.594 |
| tls-cpu / receive | 0.059225 | 0.0296 | 15.422 | 0.548 | 0.065 |

Private-pipe clock uncertainty passed the existing 1 ms local alignment check in all three runs. Actual launch lateness and sample offsets remain in the raw records. Resource snapshots delayed first workload execution beyond the nominal boundary in some cases; effective OS CPU update resolution is unmeasured. The largest collection took 1.581 ms in TCP and 4.941 ms in TLS clean. Those exceed S1's 1 ms per-sample physical instrumentation budget, so this metric setup is **not physically qualified**. No run was discarded or repeated to hide that deficit. One clean local run per mode does not establish repeatability or satisfy S1's separate physical matrix.

## Separate profiling and next use

Both TLS CPU profiles passed run/role/hash/size association checks and parsed with the archived binary through `go tool pprof -top`; see [sender output](raw/tls-cpu/send-pprof-top.txt) and [receiver output](raw/tls-cpu/receive-pprof-top.txt). Their 2,006/1,758-byte files remain in the durable archive and were not truncated. CPU profiling includes its disclosed preparation prefix and measurement interval. Process resource deltas, not sampled pprof weights, own CPU accounting.

The [usage guide](../../MEASUREMENT.md#local-reliable-stream-references-version-2) provides build/run and separate profiling commands, accounting definitions, OS-specific resource meanings and independent iperf controls. [S3 (#1465)](https://github.com/GridSwarm/wiremux/issues/1465) can now extend the shared reliable engine to QUIC layers. Physical paths, Windows runtime/host accounting and collector-overhead qualification remain with later slices. This result authorizes no production optimization or GridCast end-to-end performance claim.
