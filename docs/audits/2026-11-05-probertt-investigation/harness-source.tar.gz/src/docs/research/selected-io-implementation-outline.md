# Selected I/O implementation outline

This provisional outline has been superseded by the [normative selected-I/O implementation plan](../adr/2026-09-22-selected-io-plan.md) and its [program index](../adr/2026-09-22-selected-io-program.md). The [design decision](../adr/adr-0015-selected-interface-continuity.md) retains the agreed policy and rationale. Use the current plan slice and its pinned child issue for implementation; do not dispatch this historical outline.
