# Issue #1817: Network.framework's user-space networking against BSD sockets on macOS

Research for [Can Network.framework's user-space networking beat BSD sockets for a native flow on macOS?](https://github.com/GridSwarm/wiremux/issues/1817) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). It measures one UDP flow between the two Macs on Network.framework's user-space path (Skywalk flowswitch channels) against connected and unconnected BSD sockets, on the send side and the receive side, with and without `nw_connection_batch`, from C and from Go through cgo. It says which interfaces get the user-space path, whether an unentitled command-line process gets it, and what a per-peer `nw_connection` would keep, move or lose of wiremux's per-datagram admission contract. Nothing here implements a change.

Sources are wiremux at `origin/main` [d30c3689](https://github.com/GridSwarm/wiremux/tree/d30c3689454c0db2b008562d276d991fe642354f), the quic-go-fast fork at `v0.62.1-fast.7`, the macOS 27.0 SDK's Network.framework headers, the xnu source closest to the hosts' kernel that Apple publishes ([xnu-12377.121.6](https://github.com/apple-oss-distributions/xnu/tree/xnu-12377.121.6); both Macs run xnu-13432.1.9), Apple's WWDC 2018 session 715 and TN3151, two throwaway probes (C and Go+cgo, kept in the evidence directory, never committed), the rig binary from [Where does the macOS ~1 Gbit/s native ceiling actually come from?](https://github.com/GridSwarm/wiremux/issues/1800) for its Go socket arm, and measurements taken for this note on 2026-10-14 and 15 (UTC). Every number is labeled **measured**, **derived** (with its arithmetic) or **source**. Comparisons with connected sockets use #1800's [research note](https://github.com/GridSwarm/wiremux/blob/b8dd6735e07434cf8276a6313ea127cf054775fb/docs/research/issue-1800-macos-native-ceiling.md) where they are about the `tb` cell.

**Cells.**

- `eth` (new for this ticket): mbp128 (MacBook Pro M4 Max) sends from `en8`, a 10GBASE-T adapter, through the home LAN switch to m4mini (Mac mini M4 Pro) `en0`, its built-in 10GbE port linked at 1000baseT, MTU 1500. Both ends have a flowswitch. The link is 1 Gbit/s at the receiver and shared, so offered load is capped (16-byte payloads at up to 850k packets/s, which is 571 Mbit/s on the wire; 1,232-byte payloads at 45k packets/s, 467 Mbit/s).
- `tb`: #1800's Thunderbolt pair (`bridge0`), which has no flowswitch, for what Network.framework does without one.

Both Macs host live GARM runner VMs and other sessions' builds and tests; the protocol's load gate held every campaign run until both load1 were at most 8 (see [Method](#method)).

## Answer

**On the send side, yes, but only with batching, and a connected socket's own batched send gets part of the way.** One `nw_connection_send` per datagram costs what a connected socket's `write` does: 3.5–4.0 µs of CPU per 16-byte datagram on the sender, process and kernel together, against 3.6 µs (**measured**). Wrapped in `nw_connection_batch` (4, 16 or 64 sends per batch) it costs 1.5–1.6 µs, 2.2–2.4× less, and the sender ran at the 850k packets/s cap where a connected `write` tops out at 425k on one thread (**measured**). Most of the saving is in the kernel: a batch of user-space sends reaches the driver with almost no kernel-thread time per packet. A connected socket's private batched send, `sendmsg_x` with 16 or 64 datagrams per call, came to 2.8 µs at 543–585k packets/s: a fifth less than `write`, but nearly twice the batched user-space send's 1.4–1.5 µs in the same campaign (**measured**, E2).

**On the receive side, no.** A per-peer `nw_connection` receiver costs 3.3–3.8 µs per 16-byte datagram near its ceiling, against 1.8–2.0 µs for a connected socket, and it tops out near 558k packets/s, where a connected socket carried 834–844k with under 2% loss and is itself good for about 870k (**measured**; the 870k is **derived** from the profiled pair). At a realistic rate it is worse: at 45k packets/s of 1,232-byte datagrams the user-space receiver's process alone spends 9.7–14.2 µs per datagram against 2.5–4.0 µs for a connected socket's process (**measured**, E1 and E2), because every datagram (or every small group) wakes the receiving threads. The Network.framework receive path is a per-message callback API; nothing in the public SDK receives a batch.

**Apple's "30% less" claim reproduces only against unconnected sockets.** WWDC 2018 session 715 claimed 30% less receive overhead for user-space UDP, on iOS and tvOS ([transcript](https://developer.apple.com/videos/play/wwdc2018/715/), **source**). Against an unconnected socket, which is what wiremux's native path uses today, the user-space receiver here is 70% cheaper at saturation (3.8 against 12.5 µs) and about 15% cheaper at 45k packets/s of 1,232 bytes (10.2 against 11.9 µs) (**measured**). Against a connected socket it is 1.7–2× dearer.

**Taken end to end, a user-space pair is no cheaper than a connected pair.** Per 16-byte datagram, send plus receive: connected sockets 5.5 µs (C and Go alike), user-space with batched sends 5.3 µs from C and 5.6 µs from Go (**derived** from the rows below). The best combination measured is a batched user-space sender into a connected-socket receiver, 3.4 µs.

**An unentitled command-line process does get user-space flows on macOS 27.** The probes are ad-hoc linker-signed with no entitlements. On `eth` the sender held no socket at all, only a Network.framework policy descriptor and a channel on `en8`'s flowswitch; `nettop` reports the flow as a channel; and the hosts' kernel UDP counters moved by a median of 0 datagrams per user-space datagram sent, against exactly 1 for a socket (**measured**, section 2). On `tb`, which has no flowswitch, the same code falls back to kernel sockets: a connected socket on the sender and, on the receiver, the listening socket plus one connected socket per peer on the same port, 26–28% slower than a plain connected pair (**measured**, T1).

**Admission: a per-peer `nw_connection` keeps wiremux's checks that live in wiremux, moves interface and peer filtering into the kernel per flow, and loses the per-datagram kernel-ingress check and the native send metadata.** Network.framework hands a connection no per-datagram interface, local address or remote address, and no descriptor, so `IP_PKTINFO` ingress, packet-info and TOS control messages, and the fork's descriptor-based don't-fragment and ECN setup have nothing to work on (section 7). Most of the rest is what a connected socket per peer would do too ([What would a connected socket per peer do to the native ceiling and to per-datagram admission?](https://github.com/GridSwarm/wiremux/issues/1842)): the flow is filtered to one address-and-port pair, a new peer is first seen by a shared listener, and a rebinding peer becomes a new connection.

**Verdict: not a lever to choose now.** Its receive side is slower than the connected socket the map is already deciding on ([Should the native path use a connected socket per peer?](https://github.com/GridSwarm/wiremux/issues/1843)), its admission cost is a superset of a connected socket's, and it brings cgo into a module that has none. Its one real advantage, cheap batched sends, beats even a connected socket's `sendmsg_x` by about 1.9× per packet; it is worth revisiting only if #1843 adopts connected sockets, batched sends on them are tried in the native path, and the sender is still the wall by a margin worth cgo (section 9).

| `eth`, 16-byte payloads unless noted | Delivered packets/s | Sender µs per packet (process + kernel) | Receiver µs per packet (process + kernel) | What took the datagrams |
| --- | ---: | --- | --- | --- |
| connected pair, C (`write` / `read`) | 425k (sender-bound) | 2.35 + 1.19 = 3.56 | 0.69 + 1.27 = 1.97 | sockets |
| connected pair, Go (rig `udp -connected -rconnect`) | 394k (sender-bound) | 2.56 + 1.12 = 3.63 | 0.78 + 1.14 = 1.90 | sockets |
| unconnected pair, C | 175k (receiver-bound, 25% lost) | 4.23 + 1.60 = 5.82 | 5.71 + 6.80 = 12.5 | sockets |
| unconnected pair, Go (rig `udp`, wiremux's socket shape) | 100k (receiver-bound, 54% lost) | 4.38 + 1.36 = 5.65 | 15.2 + 10.8 = 26.0 | sockets |
| `nw` per datagram → `nw` | 519k (both ends near their ceilings: this sender reached 477–521k alone; 2% lost) | 2.48 + 1.09 = 3.47 | 2.88 + 0.58 = 3.50 | channels |
| `nw` batches of 16 → `nw` | 558k (receiver-bound, 34% lost of 850k) | 1.36 + 0.13 = 1.50 | 2.97 + 0.82 = 3.83 | channels |
| `nw` batches of 4 / 16 / 64 → connected socket | 833k / 834k / 844k (850k cap) | 1.34–1.42 + 0.10–0.21 = 1.46–1.61 | 0.65–0.72 + 1.27–1.31 = 1.91–1.98 | channel → socket |
| connected socket → `nw` | 415k (sender-bound) | 2.40 + 1.19 = 3.62 | 2.69 + 0.49 = 3.26 | socket → channel |
| connected `sendmsg_x`, batches of 16 / 64 → connected socket | 543k / 585k (sender-bound) | 1.84 + 1.01 = 2.85 / 1.71 + 1.03 = 2.76 | 0.62–0.63 + 1.18–1.19 = 1.80–1.82 | sockets |
| Go+cgo: `nw` batches of 16 → callback per datagram | 549k (receiver-bound) | 1.49 + 0.15 = 1.64 | 3.09 + 0.77 = 4.00 | channels |
| Go+cgo: `nw` per datagram → C ring | 475k (receiver-bound) | 2.62 + 1.16 = 3.81 | 4.13 + 0.57 = 4.73 | channels |
| 1,232 bytes at 45k/s: connected pair | 45k | 6.37 + 1.56 = 7.1 | 2.54 + 2.71 = 5.3 | sockets |
| 1,232 bytes at 45k/s: `nw` batches of 16 → `nw` | 45k | 4.19 + 0.82 = 5.0 | 9.69 + 1.31 = 10.2 | channels |
| 1,232 bytes at 45k/s: unconnected pair | 45k | 9.32 + 2.40 = 11.7 | 6.66 + 5.36 = 11.9 | sockets |

All rows are medians of 5 runs of campaign E1 (**measured**), except the `sendmsg_x` row (E2, 3 runs). Process CPU is the probe's user plus system time per packet; kernel CPU is kernel_task's time per packet over the run's steady window less its time just before the run (**derived**; it carries the host's background noise, about ±1 µs per packet at 400k packets/s and ±3 µs at 45k, so read the low-rate kernel column with care). Per-thread recordings are in [section 5](#5-where-the-time-goes).

## 1. Which interfaces get user-space networking

A Network.framework flow can only be a user-space channel on an interface that has a flowswitch, the Skywalk nexus that classifies packets into per-flow channels, and that carries the flowswitch's "Userspace Networking" transport agent (`agent domain:Skywalk type:FlowSwitch flags:0x4483` in `ifconfig -v`). `ifconfig -v` on both Macs, 2026-10-14 (**measured**, `iface/`):

| Interface | mbp128 | m4mini | Flowswitch |
| --- | --- | --- | --- |
| Built-in or adapter Ethernet | `en8` 10GBASE-T, 192.168.1.110; `en12` (no link) | `en0` 10GbE linked at 1000baseT, 192.168.1.2 | yes |
| USB Ethernet | `en11` 2500Base-T, 192.168.1.10; `en14` (link-local); `en4`–`en6` (no link) | `en5` (link-local), `en6`, `en7` (no link) | yes |
| Wi-Fi | `en0`, 192.168.1.226; `ap1`, `awdl0` | `en1`, 192.168.1.123; `ap1`, `awdl0` | yes (`llw0`: netif only) |
| Thunderbolt ports | `en1`–`en3`, members of `bridge0` | `en2`–`en4`, members of `bridge0` | no: a netif, no flowswitch |
| `bridge0` (Thunderbolt Bridge) | 172.16.1.2 | 172.16.1.1 | no: neither |
| VPN tunnels (`utun`, Tailscale on both) | `utun0` 100.73.220.45 | `utun4` 100.68.146.61 | no: neither |
| VM interfaces | `vmenet0`–`vmenet7`, `bridge100`, `bridge101` | – | no: neither |

Two more facts matter for the cell:

- Both Ethernet ends of `eth` are *compat* netifs: a legacy mbuf driver that Skywalk wraps, not a native Skywalk driver. Neither shows `CHANNEL_DRV` in its `eflags`, and `skywalkctl interface` (which needs no root) counts `RxCopyAttach` equal to `RxPackets` on both (**measured**). Only the Wi-Fi interfaces are native here. The flowswitch copies every user-space packet once on its way in, from the driver's buffers into the channel's ([`fsw_dp.c` L2026](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/flowswitch/fsw_dp.c#L2026)), and once on its way out, which for a compat driver is a copy into an mbuf ([`fsw_dp.c` L2845](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/flowswitch/fsw_dp.c#L2845)) (**source**). A consumer's Mac mini built-in Ethernet is in the same class.
- BSD sockets on a flowswitch interface still pass through the flowswitch on receive: every inbound packet is looked up in the flow table, and a miss goes up the host path into the ordinary IP and UDP input ([`fsw_dp.c` L2243-L2246](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/flowswitch/fsw_dp.c#L2243-L2246)). Sends from BSD sockets bypass it.

**Why `bridge0` and its members have no flowswitch (source).** A compat netif is attached automatically only to `IFT_ETHER` and `IFT_CELLULAR` interfaces ([`dlil.c` L609-L630](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/dlil.c#L609-L630)); `bridge0` is `IFT_BRIDGE`, so it gets no netif and therefore no flowswitch. The Thunderbolt ports are Ethernet-family interfaces with a compat netif (`ifconfig -v` shows one), and a flowswitch is attached when IPv4 or IPv6 is attached to them ([`dlil.c` L4563-L4567](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/dlil.c#L4563-L4567)). As bridge members they carry no IP. The bridge also removes the user-space agent from every member it adds ([`if_bridge.c` L3085-L3096](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/if_bridge.c#L3085-L3096)), and the flowswitch refuses to register its agent on a bridged interface ([`fsw_netagent.c` L460-L465](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/flowswitch/fsw_netagent.c#L460-L465)). When a member leaves the bridge, the bridge re-adds the agent ([`if_bridge.c` L2845-L2851](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/if_bridge.c#L2845-L2851), [L2896-L2899](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/if_bridge.c#L2896-L2899)).

**A Thunderbolt port taken out of the bridge.** By that source, a port removed from `bridge0` and given an address of its own would get a flowswitch and the user-space agent like any other Ethernet-family interface (**source**, inference: not tested, and nothing was reconfigured). The flowswitch's other conditions (a Skywalk-capable interface, the TX-start model) already hold for these ports ([`dlil.c` L806-L816](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/dlil.c#L806-L816), [L908-L913](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/dlil.c#L908-L913); `ifconfig -v` shows `TXSTART` and a netif). The exact commands are in [Open questions](#open-questions).

**Consumers' interfaces.** Built-in Ethernet, USB Ethernet and Wi-Fi get user-space networking. The Thunderbolt Bridge, VM interfaces and loopback do not. A VPN `utun` gets it only if the tunnel's provider opts in ([`if_utun.c` L1901](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/if_utun.c#L1901), [L2510](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/if_utun.c#L2510); `dlil.c` [L405-L431](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/dlil.c#L405-L431)); neither Tailscale tunnel here has one. Apple's engineers add, in forum posts, that a legacy VPN opts a process out and that enabling the application firewall switched one test tool to sockets on macOS 14.4.1 (possibly changed in macOS 15); Apple calls all of it an implementation detail ([forum thread 751581](https://developer.apple.com/forums/thread/751581), [773493](https://developer.apple.com/forums/thread/773493), **source**). There is no public API to request or forbid it: the SDK headers have no such parameter (**source**).

## 2. An unentitled command-line process gets user-space flows

The probes are ordinary command-line binaries: built with `clang`, ad-hoc linker-signed (the minimum an arm64 Mac runs), no entitlements, no app bundle. Four checks that need no root agree (**measured**: the path-proof pairs in `P/`, and every E1 run):

- **Descriptors.** A Network.framework sender on `eth` holds, besides standard input, only `NPOLICY` (its network-policy client) and `CHAN flowsw DCE29AB3-…[8] user-packet-pool`, a channel on the flowswitch that `ifconfig -v` lists for `en8`. It holds no socket. The receiver holds its listener's kernel socket (`UDP 192.168.1.2:47917`, unconnected) and a channel on `en0`'s flowswitch (`FDFBACE5-…`) for the peer's connection (`lsof`). The probes' own descriptor census (`proc_pidinfo`) records the same in every run.
- **`nettop -m udp -x`** marks each flow's architecture: the sender's flow `en8 … ch`, the receiver's per-peer flow `en0 … ch` carrying all the bytes, and the listener's socket `so` with no bytes at all.
- **Kernel counters.** The hosts' `netstat -s -p udp` counters, which count every datagram that passes the kernel's UDP layer, moved by a median of 0 datagrams per user-space datagram sent (78 sender runs; one run's 0.22 was other traffic on the host) and by at most 0.0015 per datagram received (60 receiver runs). The interface counters (`netstat -I`, and `skywalkctl interface`'s `RxPackets`) counted every datagram. For a connected socket the UDP counter moves by 1.000 per datagram.
- **`netstat -anv -p udp`** lists a user-space flow with its addresses and byte count but zeroed socket fields, because the kernel appends a separate snapshot of user-space flows to the socket list ([`in_pcblist.c` L328-L341](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/in_pcblist.c#L328-L341)).

Nothing in the source gates it either (**source**): opening a channel needs a privilege only in low-latency mode ([`channel.c` L1577-L1581](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/channel/channel.c#L1577-L1581)), and the network-policy client checks entitlements only for delegation, interposition, custom Ethernet or IP protocols and offload ([`necp_client.c` L8249-L8301](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/necp_client.c#L8249-L8301)). Apple says user-space networking came to macOS in macOS 12 and that Network.framework uses it by default under constraints it does not document ([forum thread 751581](https://developer.apple.com/forums/thread/751581)).

On `tb` the same binaries hold kernel sockets ([section 6](#6-on-tb-networkframework-is-a-connected-socket)).

## 3. Send side

Campaign E1 medians, 16-byte payloads capped at 850k packets/s (**measured**). The C senders ran into a connected-socket receiver, which never limited them; the Go+cgo senders ran into Network.framework receivers, which does not change a sender's own cost.

| Sender | Sent packets/s | Process µs per packet (user / system) | Kernel µs per packet | Total |
| --- | ---: | --- | ---: | ---: |
| connected `write`, C | 425k | 2.35 (0.06 / 2.28) | 1.19 | 3.56 |
| connected `write`, Go (rig) | 394k | 2.56 (0.14 / 2.42) | 1.12 | 3.63 |
| unconnected `sendto`, C | 235k | 4.23 (0.09 / 4.14) | 1.60 | 5.82 |
| unconnected, Go (rig; wiremux's socket shape) | 231k | 4.38 (0.22 / 4.18) | 1.36 | 5.65 |
| `nw_connection_send` per datagram, C | 477k | 2.74 (1.31 / 1.40) | 1.21 | 3.95 |
| `nw_connection_batch` of 4, C | 850k (cap) | 1.34 (0.92 / 0.42) | 0.12 | 1.46 |
| `nw_connection_batch` of 16, C | 850k (cap) | 1.36 (0.90 / 0.46) | 0.10 | 1.46 |
| `nw_connection_batch` of 64, C | 850k (cap) | 1.42 (0.96 / 0.46) | 0.21 | 1.61 |
| connected `sendmsg_x` of 16 / 64, C (E2) | 543k / 585k | 1.84 (0.01 / 1.83) / 1.71 (0.00 / 1.71) | 1.01 / 1.03 | 2.85 / 2.76 |
| `nw_connection_send` per datagram, Go+cgo | 505k | 2.62 (1.29 / 1.33) | 1.16 | 3.81 |
| `nw_connection_batch` of 16, Go+cgo | 850k (cap) | 1.50 (0.92 / 0.57) | 0.13 | 1.63 |

- **A user-space send per datagram saves nothing.** It costs what a connected `write` does in total (3.5–4.0 against 3.6 µs). The process time splits into user (Network.framework's stack) and system (the channel synchronization that hands each packet to the kernel), where a `write` is almost all system.
- **Batching is where the saving is.** With 4 to 64 sends per batch, the per-packet kernel-thread time falls from about 1.2 µs to 0.1–0.2 µs and the process's system time from 1.4 to 0.45 µs: one channel synchronization carries the batch, and the flowswitch drains a user ring up to 64 packets at a time ([`nx_flowswitch.h` L85](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/flowswitch/nx_flowswitch.h#L85), **source**). A batch of 4 already gets all of it.
- **The batched sender's ceiling is above the cap.** Its bottleneck is the connection's serial dispatch context, about 96% busy at 850k packets/s, so about 885k (**derived** from the profiled pair, section 5). A connected `write` is one thread at 100%: 1 / 2.35 µs = 425k (**derived**).
- **A connected socket's own batched send closes about a third of the gap.** In E2, beside a connected `write` at 3.45 µs and a batched user-space sender at 1.42–1.47 µs in the same campaign, `sendmsg_x` of 16 or 64 datagrams cost 2.85 and 2.76 µs and ran at 543k and 585k packets/s, one thread at 100% in the profiled pair (**measured**). It saves process time (1.7–1.8 against 2.3 µs) but not the kernel's transmit work (1.0 µs per packet, as for `write`), which is where the user-space batch saves most.
- **The kernel time is the interface's transmit thread.** `ifnet_start_en8` ran 38% of a core for the connected sender at 348k packets/s (1.1 µs per packet) and 12.5% for the batched user-space sender at 850k (0.15 µs) (**measured**, section 5).
- On `tb` #1800 measured 5.4 µs for an unconnected `sendto` and 3.3 µs for a connected `write` from one thread at 100%; on `eth` the same calls cost 4.2 and 2.35 µs of process time (a different interface and driver).

## 4. Receive side

Campaign E1 medians (**measured**). "Offered" is what the sender sent; a receiver below it is at its ceiling.

| Receiver (sender) | Offered packets/s | Delivered packets/s | Loss | Process µs per packet (user / system) | Kernel µs per packet | Total |
| --- | ---: | ---: | ---: | --- | ---: | ---: |
| connected `read`, C (batched `nw`, 4 / 16 / 64) | 850k | 833k / 834k / 844k | 0.4–1.9% | 0.65–0.72 (0.07 / 0.59–0.65) | 1.27–1.31 | 1.91–1.98 |
| connected `read`, C (connected `write`) | 425k | 425k | 0 | 0.69 (0.07 / 0.62) | 1.27 | 1.97 |
| connected, Go (rig) | 394k | 394k | 0 | 0.78 (0.18 / 0.60) | 1.14 | 1.90 |
| unconnected `recvfrom`, C | 235k | 175k | 25% | 5.71 (0.07 / 5.63) | 6.80 | 12.5 |
| unconnected, Go (rig; wiremux's socket shape) | 231k | 100k | 54% | 15.2 (0.81 / 14.4) | 10.8 | 26.0 |
| `nw`, 32 receives outstanding, C (batched `nw`) | 850k | 558k | 34% | 2.97 (2.21 / 0.72) | 0.82 | 3.83 |
| same (`nw` per datagram) | 521k | 519k | 1.9% | 2.88 (2.38 / 0.54) | 0.58 | 3.50 |
| same (connected `write`) | 415k | 415k | 0.5% | 2.69 (2.31 / 0.39) | 0.49 | 3.26 |
| `nw`, Go+cgo callback per datagram | 850k | 549k | 36% | 3.09 (2.40 / 0.77) | 0.77 | 4.00 |
| `nw`, Go+cgo ring | 850k | 526k | 38% | 4.00 (2.92 / 1.11) | 0.87 | 4.87 |
| at 100k/s: connected `read` | 100k | 100k | 0 | 1.86 | 2.15 | 4.0 |
| at 100k/s: `nw`, 32 outstanding | 100k | 100k | 0.17% | 5.17 | 0.82 | 5.8 |
| at 100k/s: `nw`, 1 outstanding | 100k | 100k | 0.14% | 8.22 (3.44 / 4.78) | 1.37 | 9.6 |
| 1,232 B at 45k/s: connected `read` | 45k | 45k | 0 | 2.54 | 2.71 | 5.3 |
| 1,232 B at 45k/s: `nw` (batched sender) | 45k | 45k | 0.01% | 9.69 (7.12 / 2.59) | 1.31 | 10.2 |
| 1,232 B at 45k/s: `nw` (per-datagram sender) | 45k | 45k | 0.01% | 10.05 (7.34 / 2.65) | about 0 | about 10 |
| 1,232 B at 45k/s: unconnected `recvfrom` | 45k | 45k | 0 | 6.66 | 5.36 | 11.9 |

- **The user-space receiver costs 1.7–2× a connected socket per packet**, and its cost is in the process, mostly in user mode: Network.framework's input processing, the per-message completion block and its disposal, and dispatch. Its kernel share is small (0.5–0.8 µs, the compat netif's poller classifying and copying into the channel). A connected socket's cost is the reverse: a cheap `read` (0.6–0.7 µs) and about 1.2 µs in the kernel's input path.
- **Its ceiling is one serial dispatch context.** The thread running the connection's reads was 98% busy at 542k packets/s in the profiled pair (section 5), which matches the campaign's 558k. A connected socket carried 834–844k, at the sender's 850k cap, and is near its own ceiling there: in the profiled pair at 741k packets/s its reading thread and the kernel's input thread (`dlil_input_en0`) were each about 85% busy, so about 870k (**derived**: 741k / 0.85). Its losses at the top (0.4–1.9%) were between the interface and the UDP layer (in one run the interface counted 8.5 million datagrams and UDP 7.9 million, with no full-socket drops). That is 1.5× the user-space receiver's ceiling.
- **It costs most at low rates.** Per packet, the user-space receiver goes from 3.0 µs of process time at saturation to 5.2 µs at 100k packets/s and 9.7–10.1 µs at 45k packets/s of 1,232 bytes; a connected socket goes from 0.7 to 1.9 to 2.5 µs. At low rates every datagram, or every small group, wakes Network.framework's threads (0.16 involuntary context switches per datagram at saturation, 0.22 at 45k/s) and pays for the wake-up alone. E2 repeated the 1,232-byte arms on a busier host: 14.2 µs for the user-space receiver (13.7 µs behind a connected-socket sender) against 4.0 µs for a connected `read`, the same ratio of 3.5–3.8 as E1.
- **The obvious way to use the API is the slowest.** With one `nw_connection_receive_message` outstanding at a time, a receiver takes a context switch per datagram (1.04 per datagram at 100k/s), costs 8.2 µs per datagram there, and tops out near 180k packets/s, queueing the excess in user space (smoke runs `s6`). Keeping 32 receives outstanding, issued inside `nw_connection_batch`, cuts the cost by 40% and lifts the ceiling threefold; 128 outstanding added 3% (581k against 565k for 32 in E2, at the same 2.9 µs per datagram).
- **Its drops are invisible.** The user-space receiver's losses never reach `netstat -s -p udp`; only the probe's sequence gaps show them. Flowswitch drop counters need root (`sudo skywalkctl netstat -s`, not run).
- **Against an unconnected socket, which wiremux uses today, it is far cheaper**: 3.8 against 12.5 µs at saturation and a ceiling 3.2× higher (558k against 175k), and 10.2 against 11.9 µs at 45k/s of 1,232 bytes.

## 5. Where the time goes

One system-wide Instruments Time Profiler recording per Mac per hand-run pair (`X/`, window 9–15 s of the recording, the middle of the 10 s transfer; **measured**). The profiler slows the probes by 5–20%, so the rates below are lower than the campaign's and the recordings are used for attribution. Kernel threads are attributed by name; their call stacks need root.

| Pair (rate during the recording) | Sender's busiest threads | Receiver's busiest threads |
| --- | --- | --- |
| connected `write` → connected `read` (348k) | main thread **98.7%** (99% of it in `write`); `ifnet_start_en8` 37.6% | main thread 23.0%; `dlil_input_en0` 20.8%; `skywalk_netif_poller_en0` 10.1%; `BCM5701Enet` 4.0% |
| connected `sendmsg_x` of 16 → connected `read` (537k) | main thread **99.9%**; `ifnet_start_en8` 50.4% | main thread 38.8%; `dlil_input_en0` 36.6%; poller 14.8%; driver 6.0% |
| `nw` batches of 16 → connected `read` (850k sent, 741k delivered) | the connection's serial dispatch context on three worker threads, 46.0 + 24.6 + 23.4 = **94%**; main thread 18.5%; `ifnet_start_en8` 11.6% | main thread **85.0%**; `dlil_input_en0` **84.1%**; poller 23.1%; driver 11.4% |
| `nw` batches of 16 → `nw` (850k sent, 542k delivered) | serial context on three workers, 33.8 + 31.6 + 30.5 = **96%** (a third of it in `__channel_sync`); main thread 21.3%; `ifnet_start_en8` 12.5% | the connection's read context, one worker **97.8%** (`nw_flow_service_reads`, `nw_flow_process_input_frames`); two workers at 29.9% and 29.7% running and disposing of the completion blocks; poller 30.3%; driver 15.7%; `dlil_input_en0` 0.1% |
| connected `write` → `nw` (342k) | main thread **99.7%**; `ifnet_start_en8` 38.3% | three workers 33.2 + 27.1 + 26.1%; poller 13.2%; driver 4.0% |
| Go+cgo: `nw` batches of 16 → callback per datagram (850k sent, 490k delivered) | serial context on three workers, 39.7 + 28.5 + 26.7 = **95%**; Go's threads about 30% in all; `ifnet_start_en8` 13.1% | read context, one worker **98.8%**; two workers at 36.1% and 30.6% running the completion blocks and the Go callbacks; poller 30.4%; driver 13.8% |

What it shows:

- **Every sender is one serial context at 94–100%**: a thread for a socket, the connection's dispatch queue for Network.framework (which hops between worker threads, so no single thread shows it). In these recordings the user-space sender's context spends about 1.1 µs per packet (**derived**: 0.96 / 850k), a third of it in the channel synchronization system call, against 2.8 µs for a connected `write` (0.987 / 348k) and 1.9 µs for `sendmsg_x` of 16 (0.999 / 537k).
- **The kernel's transmit thread does much less for user-space packets**: `ifnet_start_en8` spends 0.14–0.15 µs per packet for the user-space sender against 0.94–1.1 µs for a socket sender, `sendmsg_x` included (**derived**: 0.116 / 850k, 0.125 / 850k; 0.504 / 537k, 0.376 / 348k).
- **The user-space receiver is one serial context at 98%**, about 1.8 µs per packet in Network.framework's input processing alone (**derived**: 0.978 / 542k), with the completion blocks on other threads. The kernel's work for it is the compat netif poller and the driver (0.56 and 0.29 µs per packet); the socket input thread (`dlil_input_en0`) is idle.
- **The connected receiver splits its work between the reading thread and the kernel's input thread**, each about 1.1 µs per packet at 741k (**derived**) and each about 85% busy, so it tops out near 870k: 1.5× the user-space receiver's single context.
- **Go changes neither bottleneck.** With the Go+cgo probe the sender's and the receiver's Network.framework contexts saturate the same way as from C; Go's own threads add about 30% of a core on the sender and the callbacks ride on the dispatch workers.
- `dlil_input_en0` costs 0.60 µs per datagram for a connected socket at 348k packets/s and 1.13 µs at 741k (**derived**), against #1800's 1.7–1.8 µs per datagram on `tb`'s Thunderbolt bridge (a different driver and the bridge's input processing).

## 6. On `tb`, Network.framework is a connected socket

On `bridge0`, which has no flowswitch, the same binaries get kernel sockets and nothing else changes in the code (**measured**, `P/tb-nw` and T1). The sender holds one connected UDP socket (`172.16.1.2:59650->172.16.1.1:47917`). The receiver holds the listener's unconnected socket on port 47917, which took the peer's first 32 datagrams (2,048 bytes, `nettop`), and a second socket on the same port connected to the peer, which took all the rest. That is Network.framework implementing, by itself, "a connected socket per peer on the shared port", one of the options #1842 weighs; the kernel's UDP counter moved by 1.003–1.005 per delivered datagram.

Campaign T1, 1,452-byte payloads, no rate cap, medians of 3 runs (**measured**):

| Arm (`tb`) | Delivered packets/s | Sender µs per packet (process + kernel) | Receiver µs per packet (process + kernel) |
| --- | ---: | --- | --- |
| connected pair, C | 289k (277–289k) | 3.45 + 4.86 = 8.3 | 1.14 + 4.36 = 5.5 |
| connected pair, Go (rig) | 294k (279–299k) | 3.44 + 4.67 = 8.1 | 1.66 + 4.49 = 6.2 |
| `nw` per datagram → `nw` | 208k (202–210k) | 5.52 + 5.39 = 11.0 | 6.12 + 5.42 = 11.5 |
| `nw` batches of 16 → `nw` | 213k (213–222k) | 4.95 + 4.83 = 9.8 | 5.28 + 4.88 = 10.3 |

- The connected pairs match #1800's `udpcr` (286–304k packets/s on the same cell).
- On the socket path Network.framework is a connected socket with its own stack in front: 26–28% fewer packets per second than a plain connected pair, 1.5–2.1 µs more process time per packet to send than the C connected pair, and 4.1–5.0 µs more to receive. Batching saves little here (0.6 µs on the sender); which system calls Network.framework makes on its socket path was not recorded.
- The kernel column is large on `tb` for every arm: the bridge's per-frame input and output work and the Thunderbolt driver, which #1800 measured by thread.

## 7. Admission: what a per-peer `nw_connection` keeps, moves and loses

**What Network.framework exposes** (**source**, macOS 27.0 SDK headers; copies in the evidence directory):

- Per datagram, on receive: the bytes (a `dispatch_data_t`) and a content context whose IP metadata carries the ECN flag, a service class and, if the connection asked for it, a receive time (`ip_options.h` L286, L324, L345). There is no interface index, no local address and no remote address per datagram: a connection's two endpoints are fixed. The only per-message endpoint and path accessors belong to `nw_connection_group` (`connection_group.h` L307, L349), which serves multicast groups and multiplexed protocols, not unicast UDP from many peers.
- Per datagram, on send: ECN and a service class through a content context (`ip_options.h` L268, L305), not an arbitrary DSCP byte, and no source address.
- Per connection: a required interface, prohibited interfaces and interface types, a local endpoint, address reuse and don't-fragment (`parameters.h` L341, L376, L467, L628, L666; `ip_options.h` L128); the current path with its interfaces, gateways and effective endpoints (`path.h` L136, L301, L320, L342); state, viability and path-change callbacks.
- Per listener: one connection per new local and remote address-and-port pair (`listener.h` L28-L34) and a cap on how many it hands out (`listener.h` L325).

**What the kernel enforces for a user-space flow.** The flow lives on one interface's flowswitch: the sender's channel names `en8`'s flowswitch, the receiver's `en0`'s (section 2, **measured**). Its network policy is evaluated once, when the flow is added, and the result is stamped on each of its packets; the flowswitch makes no per-packet policy call ([`necp_client.c` L5154-L5155](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/necp_client.c#L5154-L5155), [`fsw_dp.c` L2040-L2043](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/skywalk/nexus/flowswitch/fsw_dp.c#L2040-L2043), **source**). Flows are re-evaluated when policy or routes change ([`necp_client.c` L2682](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/necp_client.c#L2682)). A BSD socket's datagrams instead pass `necp_socket_is_allowed_to_send_recv_v4` in `udp_input` one by one ([`udp_usrreq.c` L846](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L846)).

**Promise by promise.** The promises are [`COMPATIBILITY.md`'s binding section](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/docs/COMPATIBILITY.md#binding-introduced-in-v027), its #1784 exception and the native-candidate rule that "every datagram is admitted by the owning binding" (unchanged between 2599a002 and d30c3689). The last column says whether a connected socket per peer, which [#1842](https://github.com/GridSwarm/wiremux/issues/1842) owns, lands in the same place.

| Promise today (where) | With a per-peer `nw_connection` | Same for a connected socket? |
| --- | --- | --- |
| Sockets bound to one interface and address at the caller's port, never widened ([`unicast.go` L299-L381](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/routeselection/unicast.go#L299-L381)) | **Per connection, kernel-enforced**: `nw_parameters_require_interface` plus the address as local endpoint; the flow is registered on that interface's flowswitch only | Yes (a connected socket keeps `IP_BOUND_IF`) |
| Local mode admits only LAN-classified interfaces ([`unicast.go` L306-L309](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/routeselection/unicast.go#L306-L309)) | **Kept**: a wiremux check before any connection exists | Yes |
| Kernel ingress per received datagram: its `IP_PKTINFO` interface must be the binding's ([`unicast.go` L952-L960](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/routeselection/unicast.go#L952-L960)) | **Lost as a per-datagram check**: no per-datagram interface exists to check. Replaced by the flow being registered on one flowswitch, which wiremux can't observe per datagram | No: a connected socket still delivers `IP_PKTINFO` with every datagram |
| Packet-local screen of the peer address, send and receive ([`unicast.go` L537-L549](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/routeselection/unicast.go#L537-L549)) | **Per connection**: the peer is fixed, so one check when the connection is made | Yes |
| Interface up, source assigned, interface-scoped route egress, route kind, per datagram with the verdict cache ([`unicast.go` L450-L476, L505-L593](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/routeselection/unicast.go#L450-L476)) | **Kept per datagram if wiremux keeps calling it**: it is wiremux code, run before each `nw_connection_send` and in the receive callback with the peer fixed. Network.framework adds its own per-connection path evaluation and moves the connection to waiting or failed when the path goes away | Yes |
| Verdict reused until an OS change notification (#1784, [`COMPATIBILITY.md` L105](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/docs/COMPATIBILITY.md?plain=1#L105)) | **Kept** (wiremux's cache and change feed) | Yes |
| Send metadata limited to packet info and TOS, per datagram ([`packet_darwin.go` L17-L77](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/routeselection/packet_darwin.go#L17-L77)) | **Partly lost**: the source is fixed by the connection; ECN and a service class can ride a per-message content context; an arbitrary TOS or traffic-class byte cannot | No: a connected socket keeps these control messages |
| No raw descriptor reads or writes ([`unicast.go` L657-L684](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/routeselection/unicast.go#L657-L684)) | **Kept trivially**: there is no descriptor. But the fork's descriptor-based setup (don't-fragment, ECN reception) has nothing to work on either | No: a connected socket has a descriptor |
| No filter to the promoted peer; the fork's server side processes admitted NAT rebinding ([`packet_policy.go` L171-L178](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/packet_policy.go#L171-L178)) | **Changed**: the kernel filters the flow to one address-and-port pair. A rebinding peer arrives as a new connection on a listener, and on a dialer is not delivered at all | Yes |
| One socket per interface address shared by every candidate; a new peer's first datagram is admitted, then reserved ([`endpoint.go` L208-L259](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/nativequic/endpoint.go#L208-L259)) | **Changed**: a listener plus one flow per peer; a new peer appears as a listener callback, where wiremux can admit or cancel it before QUIC sees anything; `nw_listener_set_new_connection_limit` can bound them | Yes, if the connected socket shares the port |

**How a new peer's first datagrams arrive (measured).** An `nw_listener` holds a kernel UDP socket on its port next to its policy descriptor. On `tb` that socket received the first 32 datagrams of a new peer, and Network.framework then opened a second, connected socket on the same port for that peer and moved the flow to it (`P/tb-nw`). On `eth` the listening socket carried no bytes (`nettop`), and the peer's datagrams arrived on the connection's channel. Either way the connection's first datagram was the peer's first (sequence 0 in every `nw` receiver run), and then the handover lost a burst: 17–383 datagrams at 45k packets/s, 14–3,500 at 100k and 14k–22k at 415k, all within the first 60 ms after the connection appeared, and nothing more below the receiver's ceiling (**measured**, each receiver's `gap_list`, E1). For a QUIC handshake, with one Initial in flight, that window is harmless. For moving an established flow onto a new connection, it would drop whatever is in flight.

**Rebinding and migration.** Because a flow is filtered to its exact address-and-port pair, a peer that rebinds (a NAT changing its port) or migrates reaches the host on a new pair: on a listener it becomes a new connection, on a dialer it is not delivered. The fork's server side processes admitted rebinding through path validation today, and its client side ignores remote changes ([`connection.go` L1317-L1344](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L1317-L1344)). Keeping the server's behavior would need an adapter that feeds every connection a listener opens into the one QUIC transport, where connection-ID routing finds the existing connection. A connected socket per peer has the same problem (#1842).

**How the fork would consume it.** Two shapes, neither built:

- **A `net.PacketConn` adapter per binding**, over one `nw_listener` plus the dialed connections, keyed by remote address: reads pop from a shared ring, writes pick the peer's connection, and the batch callback wiremux already registers with the fork ([`endpoint.go` L222](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/nativequic/endpoint.go#L222), [`packetconn.go` L112](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/internal/nativequic/packetconn.go#L112)) becomes one `nw_connection_batch` per batch. The fork's send queue already groups two or more packets to one destination into such a batch ([`send_queue.go` L267-L290](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/send_queue.go#L267-L290)); that is the hook the measured send saving needs. What does not map: `SyscallConn` has no descriptor to hand the fork, which sets don't-fragment and ECN reception through it ([`sys_conn_oob.go` L101-L151](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L101-L151)), and without don't-fragment the fork turns path MTU discovery off ([`connection.go` L1044](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L1044)). Keeping both needs a fork way to declare them without a descriptor, plus ECN translation per datagram (a content context and metadata object per send, whose cost was not measured). `SetReadBuffer` and `SetWriteBuffer` have nothing to set: a flow has no socket buffer. Packet info, the source address, is fixed by the connection.
- **A connection per Wire after promotion**: the Wire's traffic moves from the shared binding socket to its own flow on the same local port, so the peer sees the same pair. It needs the fork to run a connection over a per-peer conn (its fixed-peer mode requires a `*net.UDPConn`, [`packet_policy.go` L216-L248](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/packet_policy.go#L216-L248)), and the switch meets the handover loss above.

## 8. What cgo would cost wiremux and its consumers

Network.framework has no Go binding, so wiremux would call it through cgo. wiremux has no cgo today: no `import "C"` anywhere at d30c3689 (`git grep`).

- **Build shape.** The Network.framework file would be `darwin && cgo`, with a `darwin && !cgo` fallback that keeps today's BSD path. `task cross-check` builds and vets `GOOS=darwin GOARCH=arm64` with `CGO_ENABLED=0` on the Linux PR runner ([`Taskfile.yml` L126-L133](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/Taskfile.yml#L126-L133)); a cgo file is excluded there, so only the fallback is ever compiled, vetted and linted in required CI. The cgo file would be compiled only by the scheduled, non-required macOS lane ([`cross-platform.yml`](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/.github/workflows/cross-platform.yml)) and by a local `task verify` on a Mac. Every `unsafe.Pointer` at the boundary meets gosec's G103 rule, which the lint config keeps active ([`.golangci.yml` L77-L80](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/.golangci.yml#L77-L80)).
- **Consumers.** A darwin binary gets the Network.framework path only when it is built with `CGO_ENABLED=1` against a macOS SDK, which in practice means building on a Mac with the Xcode command-line tools. A consumer that cross-compiles its macOS binaries from Linux, or sets `CGO_ENABLED=0`, silently gets the fallback. wiremux's own release builds only Linux `wiremux-server` binaries with `CGO_ENABLED=0` ([`release-package.sh`](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/scripts/release-package.sh)), so it is unaffected.
- **Threads.** Network.framework runs each connection's work on libdispatch queues, on threads Go does not own. The receive handler either calls into Go on that thread (a cgo callback per datagram, `-mode cb`) or hands the datagram to a C ring that a goroutine drains with one cgo call per batch (`-mode ring`). The Go+cgo probe ran with 8–10 OS threads per process against 3–4 for the C probe (`ps -M` at the end of each run), and a C-to-Go callback from a dispatch thread needs Go to attach that thread to its runtime.
- **Buffers.** C may not keep Go memory, so a send copies the datagram into a `dispatch_data_t` (`dispatch_data_create` with the default destructor) and a receive copies it out again. Zero-copy would need C-allocated buffer pools handed to Go through `unsafe`, which nothing here measured.
- **Measured bridge cost** (E1 medians, **measured**; Go+cgo against the same C call):

| Path | C µs per packet | Go+cgo µs per packet | Bridge cost | Ceiling C / Go |
| --- | ---: | ---: | ---: | --- |
| send, one cgo call per datagram | 2.48–2.74 | 2.62 | about 0.1 | 477–521k / 505k sent |
| send, one cgo call per batch of 16 | 1.36 | 1.50 | 0.14 | both at the 850k cap |
| receive, C-to-Go callback per datagram | 2.69–2.97 | 3.09 | 0.1–0.4 | 558k / 549k |
| receive, C ring drained 64 at a time | 2.69–2.97 | 4.00 | 1.0–1.3 | 558k / 526k |

The bridge is cheap next to Network.framework's own cost: about 0.1 µs per datagram on send and on a callback receive. The ring, which avoids calling into Go from a foreign thread, is the dearer receive (one more copy and a wake-up hand-off). The Go+cgo pair (batched sends, callback receive) costs 1.64 + 4.00 µs per datagram, against 3.63 + 1.90 µs for Go on connected sockets: the same total, moved from sender to receiver.

## 9. Verdict and what it means for the map

**Not a lever the map can choose now; reopen only under a named condition.**

- **Throughput.** For one flow, the native path's two macOS walls are the sender's per-packet send and the receiving kernel's per-datagram cost on unconnected sockets (#1800). Network.framework removes the second wall, but so does connecting, and better: a user-space receiver tops out near 558k packets/s at 3.3–3.8 µs per datagram, a connected socket near 870k at 1.8–2.0 µs. On the send side it helps only through `nw_connection_batch`, which the fork could feed only through its existing batch callback; there it beats a connected socket's own batched send by about 1.9× (`sendmsg_x` of 16–64 datagrams: 2.8 µs per datagram at 543–585k packets/s on one thread, against 1.4–1.5 µs for `nw_connection_batch` and 3.5 µs for `write`). At the rates a 1 Gbit/s GridCast tier needs (about 90k packets/s of 1.4 KB), the user-space receiver is at its worst: 9.7–14.2 µs of process time per datagram against 2.5–4.0 µs for a connected socket at 45k packets/s (**derived** tier rate: 1 Gbit/s / 11.2 kbit per packet ≈ 89k packets/s).
- **Admission.** Everything a connected socket per peer changes, a per-peer `nw_connection` changes too (kernel filtering to one peer, a new peer first seen by a shared listener, rebinding as a new connection). On top, it removes the per-datagram kernel-ingress check, the packet-info and TOS send metadata, and the descriptor through which the fork sets don't-fragment and ECN, so path MTU discovery would be off until the fork learns another way.
- **Build cost.** It adds wiremux's first cgo, a darwin-only file that no required CI lane compiles, and it makes every consumer's macOS build need cgo and an SDK to get it.
- **Platform reach.** It works only on interfaces with a flowswitch: not the Thunderbolt Bridge, not VPN tunnels, not loopback, and, by Apple's account, not under a legacy VPN or (on some versions) the application firewall. Elsewhere it falls back silently to connected kernel sockets, where it is 26–28% slower than plain ones (section 6), so a fast path that depends on it would be unpredictable across consumers' machines.

**How it relates to [Should the native path use a connected socket per peer?](https://github.com/GridSwarm/wiremux/issues/1843).** A per-peer `nw_connection` is a connected flow with less admission visibility. On interfaces without a flowswitch it literally is a connected socket per peer on the shared port, which is one of #1842's options. So:

- if #1843 rejects connected sockets on admission grounds, Network.framework is rejected with them, because it loses more;
- if #1843 adopts connected sockets, Network.framework adds nothing on the receive side and, on the send side, competes only with a batched send on the connected socket (`sendmsg_x`'s list path, the map's existing fog bullet). It becomes worth a second look only if that batched send is measured in the native path and still leaves the sender as the wall by a margin worth cgo.

**New tickets.** None proposed now. The one follow-up with a real question, how far a batched send on a connected socket takes the native sender, is already on the map as the fog after #1843; this note's E2 numbers are input to it. The open questions below stay recorded, not filed.

## Method

**Cells.**

- `eth` (new for this ticket): mbp128 `en8` (10GBASE-T adapter, 192.168.1.110) → home LAN switch → m4mini `en0` (built-in 10GbE linked at 1000baseT, 192.168.1.2), MTU 1500, both flowswitch-backed compat netifs. The sender is always mbp128. Control runs over `ssh m4mini-tb` (Thunderbolt), off the measured path. mbp128 has three addresses on 192.168.1.0/24 (`en8`, `en11`, Wi-Fi `en0`); every probe socket and connection is pinned to `en8` (BSD: bound to its address with `IP_BOUND_IF`; Network.framework: `nw_parameters_require_interface` plus the address as local endpoint), and both hosts route the peer's address through the measured interface. The link is 1 Gbit/s at m4mini and shared with the house and with m4mini's GARM runner VMs, so offered load is capped: 16-byte payloads (64-byte frames, 84 bytes on the wire with preamble and gap) at 850k packets/s, which is 571 Mbit/s on the wire, find packet-rate ceilings where the CPU, not the link, binds; 1,232-byte payloads run at 45k packets/s (467 Mbit/s). Every run is 10 s.
- `tb`: #1800's cell, mbp128 `bridge0` → m4mini `bridge0` over Thunderbolt, which has no flowswitch, for what Network.framework does without one.

**Probes** (in the evidence directory; never committed or pushed):

- `nwprobe` (C, Apple clang 21.0.0, SDK 27.0, `-O2`, ad-hoc linker-signed, no entitlements): BSD unconnected (`sendto`/`recvfrom`) and connected (`write`/`read`; the receiver connects to its first sender, like the rig's `-rconnect`) sockets, a connected `sendmsg_x` batch sender, and Network.framework senders (`nw_connection_send` per datagram, or `-batch N` sends inside one `nw_connection_batch`) and receiver (`nw_listener` plus the per-peer `nw_connection`, with `-rbatch N` `nw_connection_receive_message` calls kept outstanding). The Network.framework parameters are `nw_parameters_create_secure_udp` with DTLS disabled, `nw_parameters_require_interface`, the interface address as local endpoint, and address reuse. Each send copies the datagram into a `dispatch_data_t`; every 32nd send carries a completion handler and at most 4,096 sends may be unprocessed. `-qos 1` runs the main thread and the dispatch queues at user-interactive QoS (used for every C arm). Pacing sleeps rather than spins, so CPU per packet stays honest. Every result line carries the process's descriptor census (`proc_pidinfo`: socket, channel and network-policy descriptors and every socket's addresses), user and system CPU from `getrusage`, and on receivers the sequence range and the first twelve gaps with their times.
- `nwgo` (Go 1.27.1, cgo): the same sender called from Go once per datagram or once per batch of 16, and two receivers, `cb` (an exported Go function called on the dispatch thread for every datagram) and `ring` (a C ring drained by one goroutine, up to 64 datagrams per cgo call).
- The rig binary `nativerig` from #1800 (rig d404687d, unchanged) for its Go `udp` arm with `-connected`/`-rconnect`, the shape #1800 measured on `tb`.

**Per run** (`scripts/pair.sh`): kernel_task CPU on both Macs over 3 s before the run (`top -l 2 -s 3 -pid 0`, the baseline) and over a 6 s window from the run's third second; snapshots before and after of load, `netstat -s -p udp`, `netstat -I IF -b` and `-d`, and `skywalkctl interface` for the measured interface. **Process CPU per packet** is the probe's user plus system CPU over its packets. **Kernel CPU per packet** is (kernel_task during − baseline) / packets per second; it carries the GARM VMs' noise and is read with care. **Total** is the two added.

**Campaigns** (`scripts/c.sh`, PROTOCOL.md's rules: `SECS=10`, rotation 0 a warm-up excluded from the statistics, arm order rotating each repetition, every run gated on no other session's rig work and both load1 ≤ 8, a run flagged when its rate is outside 0.8–1.2× its arm's median or a peer's load1 at its start exceeds 8):

| Campaign | What for | Runs per arm | When (UTC), load-gate waits | Noisy? |
| --- | --- | ---: | --- | --- |
| E1 | `eth` headline: 21 arms, 16-byte ceilings, 100k packets/s, 1,232 bytes at 45k packets/s | 5 + warm-up | 2026-10-14 22:09 – 10-15 00:38, 217 waits | no: 8 runs flagged (7 with load1 8.5–15.8 at the run's own snapshot seconds after the gate passed, 1 rate at 1.25× its median), no arm over a third |
| T1 | `tb`: connected C and Go pairs, `nw` per datagram and batched, 1,452 bytes, no cap | 3 + warm-up | 01:16 – 01:51, 58 waits | no: 2 load flags (8.03, 8.06) |
| E2 | `eth` supplementary: `sendmsg_x` senders, 128 outstanding receives, 1,232-byte arms, with E1's key arms beside them | 3 + warm-up | 01:51 – 02:06, 7 waits | no flags |

Every number in the measurement tables is a campaign median except section 5's, which come from profiled pairs. Before E1, smoke runs (`smoke/`, never evidence) found and fixed a probe bug that made `nw` receivers exit early, and settled the probe's shapes: `write` rather than `send` for the connected sender (Go and #1800 use `write`; `send` measured slower) and 32 outstanding receives for the `nw` receiver. Twice during E1 the gate script waited on another session's processes it misread as rig work; both were fixed and recorded (`notes.log`), and the two runs that followed started with load1 at most 8.

**Path proofs** (`P/`, `scripts/proof.sh`): a 2,000 packets/s pair held open for 12 s while `lsof`, `netstat -anv -p udp` and `nettop -m udp -x` recorded each side, on `eth` (Network.framework and connected sockets) and on `tb`.

**Profiled pairs** (`X/`, `scripts/x.sh`): one system-wide Instruments Time Profiler recording per Mac per pair (`xctrace record --template 'Time Profiler' --all-processes`, on m4mini through `DEVELOPER_DIR` as PROTOCOL.md says), never inside a campaign; per-thread utilization by `scripts/xthreads.py` from #1800.

**Sources.** WWDC 2018 session 715 (page and transcript saved), TN3151, Apple's forum threads 751581 and 773493, the macOS 27.0 SDK's Network.framework headers (`sources/sdk-headers/`), and xnu-12377.121.6 (sparse clone of `bsd/`, `sources/xnu/`); the hosts run xnu-13432.1.9, which Apple has not published.

**Limits.**

- No root: flowswitch drop counters and flow tables (`skywalkctl flow`, `flow-switch`, `netstat -s`), kernel call stacks and NECP internals were unavailable; where a user-space receiver lost datagrams, the loss is located by the probe's sequence gaps and by what the kernel's UDP and interface counters did and did not see.
- `eth` is a shared home LAN, 1 Gbit/s at the receiver: the connected socket's receive ceiling (about 870k packets/s, derived) sits just above the 850k the cell may offer, and no sender's ceiling above 850k was measured directly.
- Both `eth` interfaces are compat netifs. A native Skywalk Ethernet driver hands the flowswitch packets instead of mbufs; whether that changes the user-space path's cost was not measured (no such NIC here).
- The probes' Network.framework usage is one reasonable shape, not an exhaustive search: other receive patterns (more outstanding receives, other queue layouts) might do better.

**Evidence** is in `native-gap-evidence/1817-network-framework/` (`README.txt` indexes every campaign, pair, path proof, probe source and binary, script and source download).

## Open questions

These are candidate tickets only where noted; the rest are recorded so a later ticket can pick them up.

1. **Does a batched send on a connected socket close the gap to `nw_connection_batch`?** E2 measured one shape (`sendmsg_x` of 16 and 64 on a connected socket, section 3). Whether the fork's send queue can feed it on a connected socket, and what that does to the native ceiling, belongs to the follow-up the map already names under its connected-socket fog ("batched sends on a connected socket (`sendmsg_x`'s list path)"), after [#1843](https://github.com/GridSwarm/wiremux/issues/1843).
2. **Where does a user-space receiver drop datagrams at its ceiling and at connection setup?** The kernel's UDP counters never see them. One root command on m4mini during an `nw` receiver run would show the flowswitch's drop reasons: `sudo skywalkctl netstat -s` (and `sudo skywalkctl flow-switch` for the per-flow view). Only worth running if the map revisits Network.framework.
3. **Would a native Skywalk Ethernet driver change the result?** Both `eth` ends are compat netifs, which hand the flowswitch mbufs. The receiver's bottleneck here is Network.framework's own input context in the process, which a driver would not change, but the kernel side might. The Wi-Fi interfaces are native but unsuitable for packet-rate measurement, and no native-driver Ethernet NIC is available on these hosts.
4. **A Thunderbolt cell with a flowswitch**, if the map ever wants Network.framework at Thunderbolt rates (the `eth` results do not justify it now). The owner would take one Thunderbolt port on each Mac out of `bridge0` and address it directly, at runtime (a reboot or the Thunderbolt Bridge service may restore the bridge):
   - mbp128: `sudo ifconfig bridge0 deletem en3 && sudo ifconfig en3 inet 172.16.3.2/24 up`
   - m4mini: `sudo ifconfig bridge0 deletem en2 && sudo ifconfig en2 inet 172.16.3.1/24 up`
   - verify on both: `ifconfig -v en3` (mbp128) and `ifconfig -v en2` (m4mini) show a `flowswitch:` line and the `type:FlowSwitch` agent;
   - restore: `sudo ifconfig en3 inet 172.16.3.2 delete && sudo ifconfig bridge0 addm en3` on mbp128 and `sudo ifconfig en2 inet 172.16.3.1 delete && sudo ifconfig bridge0 addm en2` on m4mini.
   m4mini's `en4` (to minimax) stays in the bridge, and `tb`'s `bridge0` addresses are untouched.
5. **What does the handover from listener to connection lose, and why does it grow with the rate?** Measured (17–383 datagrams at 45k/s, up to 22k at 415k/s) but not localized. It matters only for a design that moves live traffic onto a new `nw_connection`.
