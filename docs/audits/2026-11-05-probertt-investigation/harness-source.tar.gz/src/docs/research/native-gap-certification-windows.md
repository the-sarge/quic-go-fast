# Windows native throughput certification

Slice [7.3](../adr/2026-10-19-native-certification-plan.md#slice-73--certify-the-windows-target), child [#1935](https://github.com/GridSwarm/wiremux/issues/1935), parent [#1915](https://github.com/GridSwarm/wiremux/issues/1915). The bounded certification campaigns are complete. 3 of four floors missed; see the [pooled results](#pooled-judged-floor-results). The final ten-run native pool uses headline-1-repeat and headline-2-fresh, including every counted stuck observation. Interrupted headline-2 is fully reported outside the pool. The original pushed protocol preceded the first headline; the combined collector recovery and record amendment preceded all new live measurement. Readiness, earlier diagnostics and collector validation are not certification evidence. A measured miss is a permitted outcome, linked to [diagnosis #2045](https://github.com/GridSwarm/wiremux/issues/2045); no product code or floor is changed to obtain a pass.

## Build and scope

**Source:** unchanged certification binaries built from wiremux main ff86096fa354eef4a1b3533696bc89e892deee9c with the published b9ab3e42a384178ad27ee3fd598c9e92d78b10d3 rig overlay and the accepted measurement-only coalesced-read observer. Fork github.com/the-sarge/quic-go-fast v0.62.1-fast.9 matches the adopted native lane. Installed build toolchain Go 1.27.3; Linux amd64 CGO_ENABLED=0 and Windows amd64, -trimpath and cmd/nativerig/rig.mod. Linux binary SHA-256 aa25f719f4876a76d6502416f8d42efc3828e66aba282100333152141e08a46c; Windows 45494c4ae1106b742ffcdd511137d40ddab3514a5895dc0c674365f0c65b05dd. No rebuild, Direct-mode substitution, fork kill switch or quic_go_no_private_syscalls tag is supplied. Both peers use the same product/fork source. The [fast.9 adoption](quic-go-fast-v0.62.1-fast.9-native-adoption.md) records the approved fast.8-plus-#1047 maintenance scope.

The authoritative [scoped correction #2046](https://github.com/GridSwarm/wiremux/pull/2046) is merged at 86df33a815ba069cd0e2abe726e0927ffda8463c; its exact full SHA is retained with the evidence. The matching published never-merged [winvm exception](https://github.com/GridSwarm/wiremux/blob/1ee368f2/cmd/nativerig/PROTOCOL.md#outliers) is a protocol-only change; it does not change these binaries or summarize.py. The initial frozen-binary driver retained rig.sh's run, rotation, counters and summary logic, replacing only compilation with copies of the immutable archived binaries and explicitly recording that fact in meta.txt. Its exact diff, source manifests, observer diff, build-info and hashes are retained under the durable evidence directory. The later collector-recovery aid described below changes collection and the authorized output-only recovery rule; application bytes and summarize.py remain pinned. The source measurement tree remains dirty solely for its archived rig overlay and observer; no instrumentation enters this product PR.

The supported domain is the pinned rig's raw per-run JSON for these named winvm arms. Pinned summarize.py owns parsing, medians/minima/maxima and pooling; figures are example-level, idle-consumer VM-cell estimates for one native Wire at MTU 1500, not compatibility promises or physical-NIC/hardware-URO claims. No in-process load is run; actual GOMAXPROCS and num_cpu are retained per peer. The only product evidence paths are this record and the Windows Status line/row; only own-slice completion and Track 7 frontier metadata are additionally admitted. Other platform rows, busy-consumer data, compatibility, dependencies and Go code remain untouched.

## Adopted stack

Both peers carry all adopted Windows-relevant improvements; the Linux sender additionally carries its Linux receive-coalescing grant. These are shipped code, with no stand-in flags. The fork includes F1–F11 and default-on equal-size Datagram gluing; Windows and Linux retain the original platform-specific availability of batch syscall counters.

| PR | Merged title |
| --- | --- |
| [1950](https://github.com/GridSwarm/wiremux/pull/1950) | perf(channel): send each channel record in one Write (slice 1.1) |
| [1952](https://github.com/GridSwarm/wiremux/pull/1952) | feat(nativequic): native Datagram ceiling follows path MTU discovery (slice 1.2) |
| [1954](https://github.com/GridSwarm/wiremux/pull/1954) | feat(native): send native Datagrams through one queue with one copy (slice 1.3) |
| [1960](https://github.com/GridSwarm/wiremux/pull/1960) | perf(binding): reuse the admitted sender address and send IPv4 without a per-call destination (slice 2.1) |
| [1967](https://github.com/GridSwarm/wiremux/pull/1967) | perf(datagrams): keep the merged receive context and skip the native second copy (slice 2.3) |
| [1944](https://github.com/GridSwarm/wiremux/pull/1944) | feat(nativequic): internal native connection readouts (slice 3.1) |
| [2006](https://github.com/GridSwarm/wiremux/pull/2006) | feat: expose native Datagram receive queue discard count |
| [1999](https://github.com/GridSwarm/wiremux/pull/1999) | Qualify fast.8 native adoption and optional queue counts |
| [2001](https://github.com/GridSwarm/wiremux/pull/2001) | feat(native): delegate network admission when offered (slice 5.2) |
| [2010](https://github.com/GridSwarm/wiremux/pull/2010) | feat(native): adopt Linux receive coalescing (slice 5.3) |
| [2013](https://github.com/GridSwarm/wiremux/pull/2013) | Grant native Windows receive coalescing and count refused segments |
| [2016](https://github.com/GridSwarm/wiremux/pull/2016) | feat(native): acknowledge every 16 packets on Reno transports |
| [2042](https://github.com/GridSwarm/wiremux/pull/2042) | Adopt published fast.9 maintenance release containing idle PMTU probe scheduling fix QUIC #1047 |

## Restored cell and queue identity

**Measured setup:** minimax Ubuntu 26.04.1 LTS / Linux 7.0.0-30-generic x86_64 → retained Windows Server 2025 build 26100 (registry UBR 32230) guest wiremux-1935-certification, 8 GiB and four vCPUs, exactly one Intel e1000e adapter on libvirt default network/virbr0. Driver 12.19.1.32, MTU 1500, Receive Buffers 2048; all other advanced settings match the pre-NIC-comparison inventory. Guest vCPUs 0/1/2/3 stay on host logical CPUs 4/5/6/7, emulator 18–19, Linux sender 0–1,16–17. Complete OS/driver/RSS/offload, golden-checksum and CPU facts are retained with the raw evidence. Every Windows and QEMU trace is off. No vhost or alternative NIC/backend is used.

The current state was preserved in quiesced external checkpoint pre-e1000e-certification-20261027 and a separate NVRAM copy, then the pre-virtio-model checkpoint's frozen disk was booted through new e1000e-certification-active.qcow2. This restores the pre-comparison guest without writing either retained history. Exactly one e1000e remains attached. No disk/backing layer/checkpoint was deleted or committed/rebased; the golden remains read-only.

The supported IP Helper API re-established owned active-only 192.168.122.2/24 with SkipAsSource=true. DHCP and preferred original .111 are preserved. Two of at most four allowed idle probes verified actual ring progress, following the new live RSS key and read-only address-pair hash/RETA calculation. The mappings reversed from the earlier boot; neither UDP port assumptions nor rate clusters define queue identity. Sender port 50001 is fixed for all native arms. Stock driver/UDP receiver binds are checked to agree on .111 before the standard slate. No further reboot/reset or NIC setting change is allowed without renewing the addressing/mapping check inside its remaining budget.

| Host source → guest target | Live calculated RSS hash | Actual idle ring advance | Queue |
| --- | --- | --- | --- |
| .1:50001 → .111:47869 | 0x90879753 | q1 +32, q0 +0 | q1 |
| .1:50001 → .2:47869 | 0x5F21D32A | q0 +33 including background, q1 +0 | q0 |

Two short readiness smokes each contained one five-second pinned 1397-ready Datagram pair and one five-second pinned stream pair, with no repeats; all passed the unchanged correctness/engagement checks. The q0 stream reproduced the stuck state, and that observation is retained rather than a readiness stop. Readiness is not floor evidence. Because its ordering differs by workload, the faster/slower floor labels are fixed per workload here before headline results: Datagram faster q0 (.2), slower q1 (.111); stream faster q1 (.111), slower q0 (.2). They will not be reassigned from headline results.

| Readiness only, measured | Datagram /s | Stream packets/s | Stream Mbit/s | Stream smoothed RTT | Coalesced reads, Datagram / stream |
| --- | ---: | ---: | ---: | ---: | ---: |
| q0 / .2 | 356,687 | 30,269 | 339.795 | 39.768 ms | 57,222 / 5,465 |
| q1 / .111 | 303,167 | 271,156 | 3,025.564 | 2.770 ms | 49,024 / 51,602 |

Every readiness receiver had zero guard trips and connect failures. The connection's promoted ceiling was at least 1397 on both peers, and each Datagram payload was exactly 1397. Generic --one output's zero stream application packets/s is not the stream statistic: the native ConnectionStats packets_received_per_s readout is present and supplies the positive stream values above and in the native summary table.

## Protocol fixed before headline measurement

The verbatim floor table is **source**, from the accepted plan:

| Floor (one native Wire, every adopted lever) | Faster queue | Slower queue |
| --- | --- | --- |
| Datagrams at the pin, 1,024 queue | ≥ 300k/s | ≥ 225k/s |
| Stream at the pin | ≥ 350k packets/s (≥ 3.8 Gbit/s) | ≥ 260k packets/s (≥ 2.85 Gbit/s) |

Judge packets/s, with Gbit/s beside it. Datagram size is 1397; the pinned 1191-byte rows are continuity only, and default-GC Datagram rows, Windows-sender and Arm rows are reported, never judged. Headline: REPS=5 SECS=10 WARMUP=1, rotating the standard slate and certification arms. The rig records r0 warm-up and excludes it; r1–r5 supply the non-warm-up statistic. Report median/minimum/maximum. On a floor miss, run one additional headline campaign and pool both campaigns' non-warm-up runs with the same pinned summarizer. A pooled miss is linked to #2045 and reverts nothing.

The persistent-state correction counts every non-warm-up run in an arm that exceeds the one-third stuck bound; it stops stuck reruns, explicitly labels stuck runs, and keeps already-performed reruns if any. Readiness has already established count-all for q0 stream, so no rerun is needed to rediscover it. Stuck-attributable rate flags remain reported but do not demand a noisy-campaign repeat or turn the miss into a stop. Independent noise retains its full-repeat-once rule and repeated-noise stop. Every other stop remains, especially zero coalesced reads, any guard/connect failure, incorrect payload/ceiling, unexplained errors, cell mismatch and shared-host gates. No binary, correctness check, floor, headline/review budget or source owner is changed.

Every run passes the existing guest busy-share ≤6% outside interrupt time, no-other-libvirt-guest, no-foreign-nativerig/heavy-work and YIELD gates, plus the guest-only address-preservation check. A fail-fast wrapper applies the existing raw-result correctness/engagement checker before starting another run; it does not filter or replace data. No profile runs inside a headline campaign. Receiving Windows native runs require binding_coalesced_reads >0 and receive_coalescing_fallbacks=0; both peers require connect_failures=0. Optional unavailable readouts stay absent, never silently zero. No stand-in lever flag, kill-switch environment or extra workload is admitted.

Durable OUTDIR parent: /Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/operator-reaudit/. Exact frozen-driver invocation uses FROZEN1935 pointing to ../resume-fixed-ip-smoke, WHOST=minimax, WGUEST=wiremux-1935-certification, WDIR=fwd, HCPUS=0-1,16-17, PORT=47869 and GATE=operator-reaudit/campaign-gate.py. The ordered forward slate is:

```text
dgram=dgram -native-min-payload 1397 -size 1397 -lport 50001
stream=stream -lport 50001
udp=udp
udp4=udp -sockets 4
binding=binding
q0dgrampin=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
q0continuity=dgram -target 192.168.122.2:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
q0streampin=stream -target 192.168.122.2:47869 -lport 50001 -ballast 64 -gc-role both
q0dgramgc=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397
q1dgrampin=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
q1continuity=dgram -target 192.168.122.111:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
q1streampin=stream -target 192.168.122.111:47869 -lport 50001 -ballast 64 -gc-role both
q1dgramgc=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397
```

The one WDIR=rev reported headline uses the same five standard arms plus pinned 1397-byte Datagrams and pinned stream, with no forward guest-target override; the driver selects host .1 and the original guest source. Arm remains **pending** under the existing unprivileged guest-operations/firewall stop; no new Arm attempt is made. No busy-consumer or admission campaign is run.


## Published protocol and statistical disposition

The final operator correction [#2049](https://github.com/GridSwarm/wiremux/pull/2049) is authoritative at 440627ba8e22d33301ff081a9c2c8526f47696ad. Its [matching protocol amendment](https://github.com/GridSwarm/wiremux/blob/0cc3c888c467925f90b12ca00c2ce192b35455d6/cmd/nativerig/PROTOCOL.md#outliers) closes the live measurement budget. No measurement followed this disposition. All existing reverse observations, including low-rate/elevated-RTT signatures, are retained under the normal warm-up exclusion; they do not by themselves identify the forward guest receive fault. The original reverse assessment remains unchanged as a historical stop receipt, with the final rule recorded separately in final-existing-data-disposition.json.

The completed reverse binding control is noisy: r2 delivered 23,467.870 packets/s (0.78× median), and r5 22,183.626 packets/s (0.74× median), two of five rate-flagged observations. Its median is 30,175.301 packets/s; all five observations, extrema, delivery/loss and flags remain in the full reverse summary below. Under the named correction those rate flags are report-only. No stable binding baseline or responsible-component claim follows. Forward binding, unrelated native noise and load gates are not waived. The [published prior stop record](https://github.com/GridSwarm/wiremux/blob/21428ecdffd948a2a66d77c518012f0c7bf3ea1d/docs/research/native-gap-certification-windows.md) preserves the earlier blocked disposition.

The generic meta.txt sender/Darwin line describes the mbp128 controller running rig.sh. The winvm-specific host/guest metadata and per-peer goos fields establish the actual Linux → Windows forward pair and Windows → Linux reverse pair; mbp128 is not a data peer in these campaigns.

The original pushed protocol commit 984c43fd preceded the first headline metadata. The operator's control-rate correction [#2047](https://github.com/GridSwarm/wiremux/pull/2047) is authoritative at 63ecc1d224e04b03b2819b558d6d287dd734f998; its matching never-merged [protocol amendment](https://github.com/GridSwarm/wiremux/blob/1af98426429081a58edba971b1ad1b7dc15f3aae/cmd/nativerig/PROTOCOL.md#outliers) and record amendment 24bce1aedd01ba12e54f19ecbff3876232c1354b were published before headline-2 began. The receipt control-protocol-before-headline2.json records both publication and campaign timestamps. This changes no binary, summarizer, workload, payload, floor, GC/affinity/NIC/backend setting, correctness requirement or review budget.

The original headline-1 and its full headline-1-repeat were both retained after the earlier any-arm noisy-campaign stop. The owner then directed reporting plain-UDP control rate variability while completing the remaining campaigns. The consumed full replacement remains the first forward native statistical source; headline-1 stays reported separately, outside the native pool. The existing floor-miss campaign headline-2 was interrupted by missing/misassociated native receiver output. The later collector-recovery decision replaced it with headline-2-fresh. Pool all non-warm-up rows of headline-1-repeat and headline-2-fresh; the unchanged pinned summarizer computes each median/minimum/maximum. Every counted native stuck observation is included, with no selective rerun or discard. WDIR=rev is reported only. The only additional validation workload was the separately reported short collector acceptance pair, excluded from certification. No fresh first campaign, noisy replacement, diagnosis or environment hunt was run.

Plain-UDP udp/udp4 delivery/loss and every pinned rate flag remain visible, including controls with more than one third flagged. They are reported as noisy where applicable and are not native-certification validity gates under the published correction. **These variable controls do not establish a stable cell-wide UDP baseline**, and no control-relative native performance or responsible-component claim follows from them. Apart from the later named reverse binding-control correction, native/load flags outside the persistent stuck-state exception and every setup/connection/cap/error/correctness/coalescing/guard/idle/shared-host/retention/GARM gate stayed binding. The old STOP.json and both old assessments remain historical receipts, not silently erased or rewritten.

A read-only pooled OUTDIR provides unique r1-r10 positive repetition prefixes with unchanged arm suffixes: first-source r1-r5 and second-source r6-r10. Its source-map.json maps every one of 130 counted rows to exactly one original run. The 26 effective-source warm-ups remain in their original OUTDIRs and are excluded by the normal rule. Controls are retained in the view as well; no new parser or hand-computed median replaces summarize.py. Warm-ups and 65 counted rows of the earlier original headline are also fully retained, outside the native pool.

## Pooled judged floor results

Measured 2026-10-27 on the fixed cell/build above, ten non-warm-up observations per arm. Faster/slower labels were fixed per workload from readiness before headline measurements and are not reassigned from these results. Packet/s is judged at full precision; Gbit/s is reported. PPS medians are the unchanged pinned summarizer medians. PPS minima/maxima are the direct extrema of the retained per-run readouts listed below (application Datagram rate and native ConnectionStats stream rate), not extrema of campaign medians. Gbit/s median/minimum/maximum come from the pinned summary. Pinned shipped-ceiling Datagram rows actually sent 1,397 bytes and retained the 1,024-entry application receive queue.

| Fixed label / arm | Median packets/s | Minimum | Maximum | Median Gbit/s | Minimum–maximum Gbit/s | Floor packets/s | Result |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Datagrams faster / q0 | 30,352.282 | 30,162.728 | 374,497.868 | 0.339217 | 0.337099–4.185388 | 300,000 | missed |
| Datagrams slower / q1 | 305,637.830 | 300,788.070 | 310,025.024 | 3.415808 | 3.361607–3.464840 | 225,000 | met |
| Stream faster / q1 | 304,581.177 | 293,335.061 | 310,234.971 | 3.397530 | 3.272125–3.460732 | 350,000 | missed |
| Stream slower / q0 | 90,983.472 | 30,342.158 | 260,597.806 | 1.015694 | 0.339450–2.907669 | 260,000 | missed |

The three pooled misses are recorded in [queue-0/Windows diagnosis #2045](https://github.com/GridSwarm/wiremux/issues/2045), linked from the Windows Status line and row. The issue retains the related virtio/GCP no-URO findings and proposes the full-rate plain UDP with 1,397-byte payloads queue-0 URO on/off experiment for owner triage. That experiment was not run under this slice. No code, lever, floor or correctness check is reverted; these estimates identify no responsible product, QEMU or Windows-driver component.

## Reported-only rows

The following are measured, never judged against a certification floor. Forward default-GC and 1,191-byte continuity rows use the same ten-run pool. The continuity comparison is contextual only; it does not decide the 1,397-byte floor.

| Reported forward arm | Median datagrams/s | Minimum | Maximum | Median Gbit/s | Minimum–maximum Gbit/s |
| --- | ---: | ---: | ---: | ---: | ---: |
| q0dgramgc | 170,907.491 | 30,088.480 | 322,481.559 | 1.910062 | 0.336269–3.604054 |
| q1dgramgc | 294,685.068 | 287,611.481 | 305,108.794 | 3.293400 | 3.214346–3.409896 |
| q0continuity | 30,390.351 | 30,140.866 | 384,813.522 | 0.289559 | 0.287182–3.666503 |
| q1continuity | 313,492.739 | 306,688.223 | 320,269.429 | 2.986959 | 2.922125–3.051527 |

Windows-sender campaign, reported only:

| Reported Windows-sender arm / WDIR=rev | Median packets/s | Minimum | Maximum | Median Gbit/s | Minimum–maximum Gbit/s |
| --- | ---: | ---: | ---: | ---: | ---: |
| dgrampin | 48,046.407 | 47,784.827 | 49,834.615 | 0.536967 | 0.534043–0.556952 |
| streampin | 49,010.871 | 47,150.379 | 49,825.052 | 0.545989 | 0.525268–0.555214 |
| dgram | 45,813.748 | 44,662.149 | 58,696.419 | 0.512014 | 0.499144–0.655991 |
| stream | 49,086.576 | 48,044.524 | 50,226.847 | 0.546780 | 0.535363–0.559622 |

Arm cell: **pending** under the existing unprivileged VMware guest-operations/firewall stop. No fresh Arm attempt was made; the retained guest and its disks/checkpoints remain available. Reported rows carry no floor verdict.

## Stuck observations and control variability

All counted queue-0 native observations and the judged q1 observations are shown below, with each effective campaign contributing five runs per arm. The earlier original headline is also shown separately. “Stuck” marks the documented below-about-60k packets/s class with elevated RTT; intermediate-rate observations are retained without being mislabelled as that low-rate class. RTT is the larger peer smoothed RTT; both peers minimum/smoothed values remain in raw JSON and assessments. No rate cluster is used to identify the receive queue.

| Campaign / arm | Counted runs | Stuck runs | Statistical disposition |
| --- | ---: | ---: | --- |
| headline-1 / q0continuity | 5 | 4 | all five retained in reported original; outside native pool |
| headline-1 / q0dgramgc | 5 | 1 | all five retained in reported original; outside native pool |
| headline-1 / q0dgrampin | 5 | 2 | all five retained in reported original; outside native pool |
| headline-1 / q0streampin | 5 | 5 | all five retained in reported original; outside native pool |
| headline-1-repeat / q0continuity | 5 | 3 | all five included in native pool |
| headline-1-repeat / q0dgramgc | 5 | 2 | all five included in native pool |
| headline-1-repeat / q0dgrampin | 5 | 4 | all five included in native pool |
| headline-1-repeat / q0streampin | 5 | 3 | all five included in native pool |
| headline-2-fresh / q0continuity | 5 | 3 | all five included in native pool |
| headline-2-fresh / q0dgramgc | 5 | 3 | all five included in native pool |
| headline-2-fresh / q0dgrampin | 5 | 2 | all five included in native pool |
| headline-2-fresh / q0streampin | 5 | 1 | all five included in native pool |

Per-run observations below retain every counted result, including intermediate and stuck rates:

| Campaign / counted run | Packets/s | Gbit/s | Smoothed RTT ms | Coalesced reads | Observation |
| --- | ---: | ---: | ---: | ---: | --- |
| headline-1 / r1-q0continuity | 30,328.178 | 0.288967 | 46.129 | 9,579 | stuck |
| headline-1 / r1-q0dgramgc | 367,285.150 | 4.104779 | 1.481 | 117,164 | included |
| headline-1 / r1-q0dgrampin | 30,319.043 | 0.338846 | 41.192 | 9,657 | stuck |
| headline-1 / r1-q0streampin | 30,396.088 | 0.340136 | 54.367 | 10,902 | stuck |
| headline-1 / r1-q1dgrampin | 311,509.694 | 3.481432 | 1.814 | 100,493 | included |
| headline-1 / r1-q1streampin | 317,124.695 | 3.535401 | 9.620 | 119,355 | included |
| headline-1 / r2-q0continuity | 30,238.661 | 0.288114 | 51.894 | 9,548 | stuck |
| headline-1 / r2-q0dgramgc | 317,548.280 | 3.548920 | 1.390 | 101,523 | included |
| headline-1 / r2-q0dgrampin | 180,140.070 | 2.013245 | 15.510 | 57,230 | included |
| headline-1 / r2-q0streampin | 30,603.505 | 0.342375 | 55.717 | 10,976 | stuck |
| headline-1 / r2-q1dgrampin | 304,046.737 | 3.398026 | 2.512 | 98,228 | included |
| headline-1 / r2-q1streampin | 303,759.122 | 3.388684 | 5.350 | 114,976 | included |
| headline-1 / r3-q0continuity | 359,742.359 | 3.427625 | 6.236 | 114,141 | included |
| headline-1 / r3-q0dgramgc | 30,196.968 | 0.337481 | 45.907 | 9,600 | stuck |
| headline-1 / r3-q0dgrampin | 29,928.668 | 0.334483 | 48.152 | 9,516 | stuck |
| headline-1 / r3-q0streampin | 31,830.362 | 0.356032 | 61.663 | 11,447 | stuck |
| headline-1 / r3-q1dgrampin | 308,267.767 | 3.445201 | 1.492 | 99,418 | included |
| headline-1 / r3-q1streampin | 306,654.980 | 3.421284 | 5.212 | 115,977 | included |
| headline-1 / r4-q0continuity | 30,339.640 | 0.289076 | 51.339 | 9,580 | stuck |
| headline-1 / r4-q0dgramgc | 325,565.496 | 3.638520 | 1.560 | 104,085 | included |
| headline-1 / r4-q0dgrampin | 136,144.134 | 1.521547 | 1.361 | 43,234 | included |
| headline-1 / r4-q0streampin | 30,709.348 | 0.342459 | 50.177 | 10,965 | stuck |
| headline-1 / r4-q1dgrampin | 307,613.120 | 3.437884 | 2.667 | 99,226 | included |
| headline-1 / r4-q1streampin | 301,411.883 | 3.362435 | 6.297 | 114,186 | included |
| headline-1 / r5-q0continuity | 30,357.839 | 0.289249 | 39.516 | 9,592 | stuck |
| headline-1 / r5-q0dgramgc | 310,336.079 | 3.468316 | 1.845 | 99,399 | included |
| headline-1 / r5-q0dgrampin | 294,280.394 | 3.288878 | 1.415 | 93,513 | included |
| headline-1 / r5-q0streampin | 31,725.340 | 0.353935 | 59.593 | 11,377 | stuck |
| headline-1 / r5-q1dgrampin | 304,018.319 | 3.397709 | 2.529 | 98,240 | included |
| headline-1 / r5-q1streampin | 307,687.339 | 3.429592 | 6.891 | 116,298 | included |
| headline-1-repeat / r1-q0continuity | 30,410.101 | 0.289747 | 47.401 | 9,603 | stuck |
| headline-1-repeat / r1-q0dgramgc | 321,496.977 | 3.593050 | 2.392 | 102,842 | included |
| headline-1-repeat / r1-q0dgrampin | 30,198.663 | 0.337500 | 54.618 | 9,611 | stuck |
| headline-1-repeat / r1-q0streampin | 30,806.636 | 0.344635 | 61.658 | 11,067 | stuck |
| headline-1-repeat / r1-q1dgrampin | 304,052.008 | 3.398085 | 2.919 | 98,104 | included |
| headline-1-repeat / r1-q1streampin | 308,706.553 | 3.443235 | 5.057 | 116,644 | included |
| headline-1-repeat / r2-q0continuity | 384,813.522 | 3.666503 | 5.520 | 121,839 | included |
| headline-1-repeat / r2-q0dgramgc | 30,222.218 | 0.337764 | 55.473 | 9,633 | stuck |
| headline-1-repeat / r2-q0dgrampin | 30,300.558 | 0.338639 | 50.604 | 9,639 | stuck |
| headline-1-repeat / r2-q0streampin | 226,884.100 | 2.531226 | 45.212 | 83,866 | included |
| headline-1-repeat / r2-q1dgrampin | 300,788.070 | 3.361607 | 1.962 | 97,136 | included |
| headline-1-repeat / r2-q1streampin | 298,863.017 | 3.334266 | 4.281 | 113,419 | included |
| headline-1-repeat / r3-q0continuity | 30,370.601 | 0.289371 | 49.183 | 9,589 | stuck |
| headline-1-repeat / r3-q0dgramgc | 30,322.043 | 0.338879 | 49.847 | 9,657 | stuck |
| headline-1-repeat / r3-q0dgrampin | 253,188.938 | 2.829640 | 1.716 | 80,507 | included |
| headline-1-repeat / r3-q0streampin | 30,740.380 | 0.343775 | 50.934 | 11,012 | stuck |
| headline-1-repeat / r3-q1dgrampin | 308,189.492 | 3.444326 | 1.549 | 99,447 | included |
| headline-1-repeat / r3-q1streampin | 306,944.324 | 3.423971 | 5.489 | 116,012 | included |
| headline-1-repeat / r4-q0continuity | 322,457.806 | 3.072378 | 2.246 | 102,056 | included |
| headline-1-repeat / r4-q0dgramgc | 316,429.705 | 3.536418 | 1.730 | 101,273 | included |
| headline-1-repeat / r4-q0dgrampin | 30,404.005 | 0.339795 | 39.952 | 9,651 | stuck |
| headline-1-repeat / r4-q0streampin | 30,636.863 | 0.342775 | 55.794 | 11,009 | stuck |
| headline-1-repeat / r4-q1dgrampin | 305,017.539 | 3.408876 | 4.902 | 98,443 | included |
| headline-1-repeat / r4-q1streampin | 304,442.142 | 3.396049 | 7.569 | 115,263 | included |
| headline-1-repeat / r5-q0continuity | 30,350.928 | 0.289184 | 43.237 | 9,611 | stuck |
| headline-1-repeat / r5-q0dgramgc | 320,095.497 | 3.577387 | 1.812 | 102,377 | included |
| headline-1-repeat / r5-q0dgrampin | 30,162.728 | 0.337099 | 51.844 | 9,602 | stuck |
| headline-1-repeat / r5-q0streampin | 117,694.343 | 1.313135 | 48.369 | 43,455 | included |
| headline-1-repeat / r5-q1dgrampin | 308,853.709 | 3.451749 | 1.455 | 99,575 | included |
| headline-1-repeat / r5-q1streampin | 293,335.061 | 3.272125 | 6.127 | 111,712 | included |
| headline-2-fresh / r1-q0continuity | 232,571.059 | 2.215937 | 20.321 | 73,399 | included |
| headline-2-fresh / r1-q0dgramgc | 30,273.331 | 0.338335 | 45.096 | 9,681 | stuck |
| headline-2-fresh / r1-q0dgrampin | 54,318.152 | 0.607060 | 1.723 | 17,270 | included |
| headline-2-fresh / r1-q0streampin | 30,342.158 | 0.339450 | 68.474 | 10,895 | stuck |
| headline-2-fresh / r1-q1dgrampin | 310,025.024 | 3.464840 | 2.218 | 99,999 | included |
| headline-2-fresh / r1-q1streampin | 310,234.971 | 3.460732 | 7.581 | 117,195 | included |
| headline-2-fresh / r2-q0continuity | 30,270.278 | 0.288415 | 53.068 | 9,558 | stuck |
| headline-2-fresh / r2-q0dgramgc | 322,481.559 | 3.604054 | 1.468 | 103,325 | included |
| headline-2-fresh / r2-q0dgrampin | 328,438.315 | 3.670627 | 1.820 | 104,375 | included |
| headline-2-fresh / r2-q0streampin | 170,252.224 | 1.899592 | 44.559 | 62,666 | included |
| headline-2-fresh / r2-q1dgrampin | 305,017.285 | 3.408873 | 2.497 | 98,439 | included |
| headline-2-fresh / r2-q1streampin | 304,720.211 | 3.399011 | 9.405 | 115,417 | included |
| headline-2-fresh / r3-q0continuity | 30,209.848 | 0.287839 | 40.157 | 9,543 | stuck |
| headline-2-fresh / r3-q0dgramgc | 311,492.939 | 3.481245 | 1.319 | 99,797 | included |
| headline-2-fresh / r3-q0dgrampin | 30,174.678 | 0.337232 | 44.420 | 9,602 | stuck |
| headline-2-fresh / r3-q0streampin | 95,075.471 | 1.061325 | 51.347 | 34,940 | included |
| headline-2-fresh / r3-q1dgrampin | 307,109.368 | 3.432254 | 2.736 | 99,114 | included |
| headline-2-fresh / r3-q1streampin | 301,459.229 | 3.363043 | 3.637 | 114,363 | included |
| headline-2-fresh / r4-q0continuity | 350,061.956 | 3.335390 | 2.706 | 110,780 | included |
| headline-2-fresh / r4-q0dgramgc | 30,279.393 | 0.338402 | 49.071 | 9,615 | stuck |
| headline-2-fresh / r4-q0dgrampin | 374,497.868 | 4.185388 | 4.543 | 120,059 | included |
| headline-2-fresh / r4-q0streampin | 260,597.806 | 2.907669 | 36.899 | 96,259 | included |
| headline-2-fresh / r4-q1dgrampin | 306,258.121 | 3.422741 | 2.055 | 98,853 | included |
| headline-2-fresh / r4-q1streampin | 302,768.849 | 3.377476 | 8.284 | 114,893 | included |
| headline-2-fresh / r5-q0continuity | 30,140.866 | 0.287182 | 53.737 | 9,528 | stuck |
| headline-2-fresh / r5-q0dgramgc | 30,088.480 | 0.336269 | 44.450 | 9,562 | stuck |
| headline-2-fresh / r5-q0dgrampin | 30,279.806 | 0.338407 | 52.205 | 9,653 | stuck |
| headline-2-fresh / r5-q0streampin | 86,891.473 | 0.970063 | 49.209 | 31,837 | included |
| headline-2-fresh / r5-q1dgrampin | 303,991.118 | 3.397405 | 2.405 | 98,259 | included |
| headline-2-fresh / r5-q1streampin | 308,756.846 | 3.443880 | 7.015 | 116,816 | included |

Recorded warm-ups with the same stuck signature are labelled here but remain excluded solely by the normal warm-up rule: headline-1/r0-q0continuity; headline-1/r0-q0dgramgc; headline-1/r0-q0dgrampin; headline-1-repeat/r0-q0continuity; headline-1-repeat/r0-q0dgrampin; headline-2-fresh/r0-q0dgramgc; headline-2-fresh/r0-q0dgrampin.

| Campaign / plain-UDP control | Counted runs | Rate-flagged counted runs | Pinned rate flags |
| --- | ---: | ---: | --- |
| headline-1 / udp | 5 | 0 | none |
| headline-1 / udp4 | 5 | 2 | r2-udp4: rate 0.68x median; r5-udp4: rate 0.68x median |
| headline-1-repeat / udp | 5 | 0 | none |
| headline-1-repeat / udp4 | 5 | 2 | r1-udp4: rate 0.01x median; r5-udp4: rate 0.75x median |
| headline-2-fresh / udp | 5 | 0 | none |
| headline-2-fresh / udp4 | 5 | 3 | r1-udp4: rate 0.73x median; r4-udp4: rate 1.29x median; r5-udp4: rate 1.29x median |
| reverse / udp | 5 | 0 | none |
| reverse / udp4 | 5 | 0 | none |

Control flags and loss remain in the pasted raw summaries, including their extreme observations. Controls exceeding one third flagged are noisy reported controls under #2047. This does not certify a general UDP baseline, explain the variability, or make the original historical stop disappear.

## Correctness, continuity and optional readouts

The Windows receiving coalesced-read counts in this record come from `<campaign>/runs/<rotation-arm>/recv.json`, JSON path `$.counts.binding_coalesced_reads`. The unchanged pinned `summarize.py` does not print this measurement-only observer field in `summary.txt`; the per-run table and engagement ranges above and below retain it directly from the receiver JSON. For example, `headline-2-fresh/runs/r1-q1streampin/recv.json` contains 117195, shown as 117,195 in the table.

headline-1: 78 complete pairs, unchanged engagement/correctness checker reported no errors. Its 60 Windows native receivers each have positive coalesced reads (range 9,516–122,383); guard and connect failures are zero.

headline-1-repeat: 78 complete pairs, unchanged engagement/correctness checker reported no errors. Its 60 Windows native receivers each have positive coalesced reads (range 9,589–121,839); guard and connect failures are zero.

headline-2-fresh: 78 complete pairs, unchanged engagement/correctness checker reported no errors. Its 60 Windows native receivers each have positive coalesced reads (range 9,528–120,059); guard and connect failures are zero.

reverse: 42 complete pairs, unchanged engagement/correctness checker reported no errors. Windows is the sender; the Linux receiver/native readouts are reported with their platform-specific availability.

In the complete accepted source/reverse campaigns, every shipped-ceiling Datagram arm actually used 1,397-byte payloads with both promoted ceilings at least 1,397; continuity arms used 1,191. Every complete accepted pair had zero connect failures, no failed sends, unexplained peer stderr or cap error; no verdict is inferred for the missing receiver in historical headline-2. No kill-switch environment or disabling build tag was supplied. Available native readouts and their exact absence/fallback values are retained in the pinned summaries; absent optional fields are not invented as zero. No profile was taken inside a headline.

The pre-remaining read-only continuity receipt confirmed the same guest boot, original binary, single e1000e/settings, .111/.2 addresses, CPU pins and identical live RSS key/RETA/MRQC. No extra mapping probe, register write or setting change was needed; only the authorized collector validation pair was added outside certification. The driver/default receiver continued to use .111; explicit native target .2 selected verified q0 and .111 selected q1 throughout the forward campaigns.

One optional OS-counter after-snapshot for headline-1-repeat/r5-q1continuity returned only “0.3” instead of the UDP/adapter/CPU block. Raw files are untouched, and its loss-localization counters remain unavailable rather than zero; mandatory native peer/correctness/engagement evidence is present. Any additional unavailable optional values remain explicitly absent in the raw summaries below. This bounds loss attribution and does not create missing throughput data.

The optional OS snapshots retain the older QGA stdout path. In reverse/r5-dgrampin, that metadata produced an impossible negative wire-loss delta (−21,042,198 in the raw summary); reverse/r5-stream also has an unusable +18,095,036 inferred wire-loss delta. These OS counter observations are unusable for loss attribution and are not physical negative packet loss. Their exact capture failure mechanism was not established. The separately captured native sender/receiver JSON and file receipts remain valid and supply throughput, payload, connection and correctness observations. No value is clamped to zero and no run is replaced because of this optional metadata failure.

The retained reverse assessment marks r4-dgram with its low-rate/elevated-RTT heuristic, plus five of five stream and three of five pinned-stream observations. All five reverse default-GC Datagram rates (44,662–58,696/s), every stream observation and their RTTs remain in raw JSON and the summaries below. These signatures alone do not establish the forward Windows queue-0 receive fault in the reverse direction. Under the final existing-data closure no stuck rerun or further diagnosis was performed.

## Collector repair and bounded validation

Combined scoped correction [#2048](https://github.com/GridSwarm/wiremux/pull/2048) is authoritative at 8175f9728e9d8bc3a4b1b6da5fac42b7e350891b; its matching published collector/protocol is [17a646255c0708d19e3c5a60cf1a90fd83d7c1d5](https://github.com/GridSwarm/wiremux/tree/17a646255c0708d19e3c5a60cf1a90fd83d7c1d5/cmd/nativerig). Both publication receipts and the pre-campaign record amendment precede every new live pair. Every Windows application attempt writes unique guest stdout/stderr/completion files. Before acceptance the controller checks launched run ID, rotation slot, arm, role, start/end timestamps (against the controller launch/collection window, with a five-second clock allowance), file sizes/digests and native payload arm/role. QGA exec-status stdout is never accepted as native output. The archived application bytes, argv, environment, workloads, packet sizes and pinned summarizer are unchanged.

The offline check rejected the retained old headline-2/r2-stream OS snapshot, mismatched identity and timestamps, and output/payload mismatches; it also exercised known execution-error exclusion, the one-immediate-pair rule and second-glitch/validation stops. The separate collector-live OUTDIR contains exactly one five-second pinned-stream acceptance pair on verified q1; its identical native binaries passed every existing correctness/engagement check and its receipt was accepted. Neither validation is certification evidence. No NIC reset or reboot occurred; pre-collector-cell.json verifies the same boot/settings/addresses/pins and live RSS key/indirection as the two original ring probes. No remaining idle probe was spent.

Live acceptance proof (not certification): run ID `collector-live/r1-q1streampin/7e4a0f9305214f7fbad9683b0bc8d829`, arm `stream`, role `recv`, Windows receipt interval `2026-10-27T15:20:29.9503456Z`–`2026-10-27T15:20:38.4672911Z`, exit 0; 57,257 coalesced reads, guard 0, connect failures 0. The unique guest prefix, request/receipt identity, size/hash checks and controller timestamps remain in the raw capture files; no validation throughput is pooled.

headline-2-fresh: no capture glitch or pair rerun occurred; every accepted Windows output has a retained identity receipt.

reverse: no capture glitch or pair rerun occurred; every accepted Windows output has a retained identity receipt.

A second capture glitch per campaign would have stopped; no stuck, slow or noisy run was retried under this rule. Missing proof of successful execution, any known application error, zero receiving coalescing or a guard trip would retain the existing stop. The repair is a one-shot verification aid on the never-merged rig, not shipped behavior. Optional OS snapshots continue to be reported as absent when unavailable; no mandatory native field is inferred from an optional snapshot.

## Interrupted headline-2: historical capture stop, never pooled

The control-rate correction is complete and remains authoritative. Headline-2 began only after the matching protocol and record were pushed. It attempted 39 pairs: all of warm-up r0 and counted rotations r1/r2. Thirty-eight have complete valid peer JSON. Standard native stream r2 has a valid Linux sender result, but its Windows recv.json contains an older UDP/adapter/CPU snapshot instead of native JSON. The next gate stopped before r3-udp4 started; that next slot has an arm directory but no peer output or data attempt. No replay or further measurement was run.

The affected run's gate passed at 2026-10-27T05:44:37Z. Its Linux sender transferred 4,181,721,088 bytes in 10.000480803 seconds, with failed=0, empty stderr and connect_failures=0. This is not evidence of a connection-setup timeout. The supposed receiver output instead has WCPU timestamp 134375492720014010, corresponding to 2026-10-27T04:34:32.001400Z, about 70 minutes earlier. Its UDP/adapter counters also appear in the earlier replacement's following snapshot, with a later CPU timestamp. The exact stale payload is retained in headline-2/runs/r2-stream/recv.json. The result-capture path demonstrably delivered a stale/misassociated result; the exact QGA/libvirt/controller mechanism has not been identified, and no claim about a general QEMU or Windows-driver defect follows.

A bounded tagged read-only recovery lookup confirmed no surviving nativerig process and found no process-creation audit event identifying the original receiver execution. It did not recover the native JSON. No tracing, debug setting, application binary or workload was changed to pursue recovery. The receiver's coalesced-read, guard and native packet-rate observations for this attempted run are therefore **unavailable**, never assumed positive/zero and never substituted from its sender or an earlier run.

The unchanged gate rejected invalid receiver JSON. The existing engagement checker reports 38 complete pairs with no errors among those valid pairs; it does not make the missing 39th result valid. The 29 valid Windows native receivers in this partial campaign have positive coalesced reads (9,504–118,589) and zero guard/connect failures. The missing native receiving record cannot discharge those mandatory requirements. This stop is separate from both persistent queue-0 rate collapse and reported plain-UDP rate variability.

At that historical stop, headline-2 was incomplete and was **not certification evidence or a pooled source**. No final ten-run pooled statistic had been produced, and WDIR=rev was unstarted. Its available queue-0 slow/fast observations remain reported without selective removal, but no final floor verdict is derived from the partial campaign. The first replacement's native statistic remained valid under #2047; the one allowed additional campaign had stopped rather than completing. The certification product PR, Windows Status line/row and completion/frontier transitions were pending at that stop. A trustworthy Windows result collector and an explicit disposition of the interrupted campaign were then needed before additional measurements; that stop itself granted no extra pair or campaign.

At that stop, the receiver-capture route needed repair before reuse. The proposed candidate was unique per-run guest output files with verified run/role identity, rather than accepting an uncorrelated process-status stdout payload. That controller repair had not yet been implemented or validated; the later published repair and validation are reported above and preserved the application binaries and correctness requirements. This is not another NIC, QEMU-configuration or GCP environment search.

Every local/GCP VM, disk, backing layer, NVRAM and checkpoint remains retained. At that historical stop, the original single-e1000e guest and its owned .2 alias were left in place; no handback address removal, reboot, adapter change or snapshot revert had followed it. The later final administrative handback removed only that owned alias, as recorded below. The tagged post-stop lookup found no native process. No profile or trace was started, and no GARM mutation occurred. STOP-native-capture.json, receiver-capture-mismatch.json, the tagged recovery receipt, the original malformed capture and partial raw output remain under the durable OUTDIR.

### Interrupted additional campaign: retained metadata and partial summary

OUTDIR: `/Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/operator-reaudit/headline-2/`. The unchanged pinned summarizer reports only its parseable rows here; n is incomplete and no row is a final pooled certification result. The malformed receiver bytes are retained separately from that summary, not repaired or overwritten.

`meta.txt`:

```text
date: 2026-10-27T05:22:00Z
cell: winvm reps: 5 secs: 10 warmup: 1
rig: ff86096fa354eef4a1b3533696bc89e892deee9c dirty=3
go: go version go1.27.3 darwin/arm64
frozen-binary campaign: original ff86096f + recorded observer; no rebuild; source /Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/resume-fixed-ip-smoke
modfile: cmd/nativerig/rig.mod
quic-go: replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.9
arms:
  dgram=dgram -native-min-payload 1397 -size 1397 -lport 50001
  stream=stream -lport 50001
  udp=udp
  udp4=udp -sockets 4
  binding=binding
  q0dgrampin=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
  q0continuity=dgram -target 192.168.122.2:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
  q0streampin=stream -target 192.168.122.2:47869 -lport 50001 -ballast 64 -gc-role both
  q0dgramgc=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397
  q1dgrampin=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
  q1continuity=dgram -target 192.168.122.111:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
  q1streampin=stream -target 192.168.122.111:47869 -lport 50001 -ballast 64 -gc-role both
  q1dgramgc=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397
quiet load before the first run: sender { 4.30 6.01 5.96 }
sender: Darwin mbp128.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
sender sysctl: 8388608 786896 9216
winvm host: Linux minimax 7.0.0-30-generic #30-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 18:22:54 UTC 2026 x86_64 GNU/Linux
winvm quiet load before the first run: 0.86 0.94 0.99 1/585 1110500
winvm direction: fwd (fwd: host sends to the guest; rev: the guest sends to the host); port 47869
winvm host peer: virbr0, taskset -c 0-1,16-17; guest wiremux-1935-certification, adapter Ethernet
winvm host sysctl: 4194304 4194304 212992
winvm guest pinning and domains:
   VCPU   CPU Affinity
  ----------------------
   0      4
   1      5
   2      6
   3      7

  emulator: CPU Affinity
  ----------------------------------
         *: 18-19

   Interface   Type      Source    Model    MAC
  -------------------------------------------------------------
   vnet541     network   default   e1000e   52:54:00:19:35:01

   Id    Name                         State
  ---------------------------------------------
   519   wiremux-1935-certification   running

winvm host offloads (virbr0):
  generic-segmentation-offload: on
  generic-receive-offload: on
  tx-udp-segmentation: off [requested on]
  rx-udp-gro-forwarding: off
winvm host cpu map:
  CPU CORE L1d:L1i:L2:L3
    0    0 0:0:0:0
    1    1 1:1:1:0
    2    2 2:2:2:0
    3    3 3:3:3:0
    4    4 4:4:4:0
    5    5 5:5:5:0
    6    6 6:6:6:0
    7    7 7:7:7:0
    8    8 8:8:8:1
    9    9 9:9:9:1
   10   10 10:10:10:1
   11   11 11:11:11:1
   12   12 12:12:12:1
   13   13 13:13:13:1
   14   14 14:14:14:1
   15   15 15:15:15:1
   16    0 0:0:0:0
   17    1 1:1:1:0
   18    2 2:2:2:0
   19    3 3:3:3:0
   20    4 4:4:4:0
   21    5 5:5:5:0
   22    6 6:6:6:0
   23    7 7:7:7:0
   24    8 8:8:8:1
   25    9 9:9:9:1
   26   10 10:10:10:1
   27   11 11:11:11:1
   28   12 12:12:12:1
   29   13 13:13:13:1
   30   14 14:14:14:1
   31   15 15:15:15:1
winvm guest 192.168.122.111 (Ethernet), host 192.168.122.1 (virbr0), tap vnet541
  guest: Microsoft Windows NT 10.0.26100.0
  guest:
  guest:
  guest: Name                 : Ethernet
  guest: InterfaceDescription : Intel(R) 82574L Gigabit Network Connection
  guest: LinkSpeed            : 1 Gbps
  guest: MtuSize              : 1500
  guest: DriverVersionString  : 12.19.1.32
  guest:
  guest:
  guest:
  guest:
  guest:
  guest: NlMtu : 1500
  guest:
  guest:
  guest:
  guest:
  guest: DisplayName                      DisplayValue
  guest: -----------                      ------------
  guest: Flow Control                     Rx & Tx Enabled
  guest: Interrupt Moderation             Enabled
  guest: IPv4 Checksum Offload            Rx & Tx Enabled
  guest: Jumbo Packet                     Disabled
  guest: Large Send Offload V2 (IPv4)     Enabled
  guest: Large Send Offload V2 (IPv6)     Enabled
  guest: Maximum number of RSS Processors 8
  guest: Preferred NUMA node              65535
  guest: Maximum Number of RSS Queues     2 Queues
  guest: Packet Priority & VLAN           Packet Priority & VLAN Enabled
  guest: Receive Buffers                  2048
  guest: Receive Side Scaling             Enabled
  guest: RSS Base Processor Number        0
  guest: Maximum RSS Processor Number     63
  guest: RSS load balancing profile       NUMAScalingStatic
  guest: Speed & Duplex                   Auto Negotiation
  guest: TCP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: TCP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Transmit Buffers                 512
  guest: UDP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: UDP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Adaptive Inter-Frame Spacing     Disabled
  guest: Interrupt Moderation Rate        Adaptive
  guest: Log Link State Event             Enabled
  guest: Gigabit Master Slave Mode        Auto Detect
  guest: Locally Administered Address
  guest: Wait for Link                    Auto Detect
  guest:
  guest:
  guest:
  guest: Querying active state...
  guest:
  guest: UDP Global Parameters
  guest: ----------------------------------------------
  guest: Receive Offload State               : enabled
  guest: Send Offload State                  : enabled
  guest:
  guest:
  guest:
  guest: ReceiveSideScaling           : Enabled
  guest: ReceiveSegmentCoalescing     : Enabled
  guest: Chimney                      : Disabled
  guest: TaskOffload                  : Enabled
  guest: NetworkDirect                : Enabled
  guest: NetworkDirectAcrossIPSubnets : Blocked
  guest: PacketCoalescingFilter       : Disabled
  guest:
  guest:
  guest:
```

`partial-summary.txt`:

```text
medians over non-warm-up runs; cpu/GiB is CPU seconds per delivered GiB; lost packets per run: wire = sender if out - receiver if in, stack = receiver if in - UDP in, rcvbuf = full socket buffer
arm             n Mbit/s med    min    max  pkt/s med    loss cpu/GiB s      r     wire    stack   rcvbuf
binding         2       3090   3029   3151     266015  58.18%      4.33   2.98        8        2        0
dgram           2       3251   3211   3291     290908   0.22%      2.09   3.64       10        2        0
q0continuity    2        288    287    289      30214   0.11%      2.56   6.46       10        2        0
q0dgramgc       2        338    338    338      30232   0.23%      2.52   5.94       10        2        0
q0dgrampin      2       2108    340   3876     188588   0.08%      2.09   4.19       10        2        0
q0streampin     2       1534    339   2729          0       -      1.82   4.49        9        0        0
q1continuity    2       3008   2968   3049     315721   0.22%      2.12   3.70        9        2        0
q1dgramgc       2       3311   3291   3332     296287   0.23%      2.10   3.62       10        2        0
q1dgrampin      2       3373   3340   3405     301779   0.17%      1.88   3.03       10        2        0
q1streampin     2       3413   3319   3507          0       -      1.56   3.29        8        6        0
stream          1       3414   3414   3414          0       -      1.57   3.45        8        1        0
udp             2       5769   5663   5875     496640  53.77%      1.51   0.69        6        1        0
udp4            2       4295   3950   4641     369785  86.45%      7.78   1.43        8        0        0

flagged runs (kept in the statistics; never dropped):
  r1-q0dgrampin: rate 1.84x median
  r1-q0streampin: rate 1.78x median
  r2-q0dgrampin: rate 0.16x median
  r2-q0streampin: rate 0.22x median
  r2-stream: failed
  r3-udp4: failed

extras (medians): sender member-queue drops; lost after the sender's member queue (member dequeued - receiver if in); receiver 16 KB cluster refill failures; receiver if in frames/s and bytes/frame; GC cycles/s per peer; -qdepth queued datagrams before each read (median, mean, share empty)
arm             q drop  after q  16k fail   in fr/s  B/frame  gc/s s  gc/s r             qdepth
binding              -        -         -         -        -     9.4   426.7                  -
dgram                -        -         -         -        -   401.6   163.2                  -
q0continuity         -        -         -         -        -     1.3     0.7                  -
q0dgramgc            -        -         -         -        -    27.0    25.2                  -
q0dgrampin           -        -         -         -        -     8.7     4.4                  -
q0streampin          -        -         -         -        -     0.2     0.1                  -
q1continuity         -        -         -         -        -    13.4     6.9                  -
q1dgramgc            -        -         -         -        -   401.4   158.4                  -
q1dgrampin           -        -         -         -        -    13.9     7.1                  -
q1streampin          -        -         -         -        -     0.3     0.2                  -
stream               -        -         -         -        -     4.6     1.1                  -
udp                  -        -         -         -        -     0.0     0.0                  -
udp4                 -        -         -         -        -     0.0     0.0                  -

sender CPU per offered packet (medians, min-max): user and system microseconds; share of each on performance cores
arm                       user us             sys us  user P   sys P
binding          0.68 (0.68-0.69)   1.77 (1.75-1.78)       -       -
dgram            2.04 (2.01-2.06)   0.68 (0.68-0.69)       -       -
q0continuity     2.02 (2.00-2.04)   0.81 (0.77-0.86)       -       -
q0dgramgc        2.49 (2.46-2.53)   0.78 (0.75-0.81)       -       -
q0dgrampin       2.00 (1.85-2.16)   0.72 (0.58-0.85)       -       -
q1continuity     1.81 (1.80-1.82)   0.54 (0.53-0.55)       -       -
q1dgramgc        2.04 (2.03-2.04)   0.68 (0.68-0.69)       -       -
q1dgrampin       1.85 (1.83-1.86)   0.60 (0.59-0.61)       -       -
udp              0.09 (0.09-0.09)   0.85 (0.85-0.85)       -       -
udp4             0.12 (0.12-0.12)   1.29 (1.29-1.29)       -       -

receiver per delivered datagram (medians; min-max for total CPU): receive call; CPU-s per delivered GiB, total, user, system; user and system microseconds per datagram; system share on performance cores; cycles per datagram; receive system calls per datagram (read and recvmsg: 1, a floor, as parked calls are not visible); recvmsg_x datagrams per delivering call (mean, median), share of calls that filled every slot, parked calls per delivering call
arm                   call         cpu/GiB r  user   sys user us sys us sys P  cyc/dg calls/dg      fill  full park/dc
udp                   read  0.69 (0.65-0.72)  0.11  0.58    0.15   0.78     -       -        1         -     -       -
udp4                  read  1.43 (1.35-1.50)  0.43  1.00    0.58   1.35     -       -        1         -     -       -

native readouts (medians; slice 3.1's seam): readouts mode; sender min, smoothed (at the end) and mean RTT over the send window (us); PTOs and spurious losses over the sender's window (recorder only); receiver packets received/s (ConnectionStats.PacketsReceived); receiver Datagram discards and unprocessed-queue drops at the end; runs with a missing snapshot. absent = no fork method, no recorder, or no snapshot
arm                mode  minRTT    sRTT  meanRTT   PTO  spur   r pkt/s  dg drop   unproc miss  env
dgram             stats     220    1296   absent absent absent    289476        2   absent    0  -
q0continuity      stats     239   30397   absent absent absent     30141        0   absent    0  -
q0dgramgc         stats     205   28318   absent absent absent     30165        0   absent    0  -
q0dgrampin        stats     209   17114   absent absent absent    188592        0   absent    0  -
q0streampin       stats     202   31520   absent absent absent    137549        0   absent    0  -
q1continuity      stats     160    5280   absent absent absent    314931        2   absent    0  -
q1dgramgc         stats     196     824   absent absent absent    296295        2   absent    0  -
q1dgrampin        stats     166    2008   absent absent absent    301805        1   absent    0  -
q1streampin       stats     212    7122   absent absent absent    305991        0   absent    0  -
stream            stats     176    8428   absent absent absent    306056        0   absent    0  -

native extra counts (medians of each peer's total at its final snapshot; counts a scratch build adds to 3.1's Readout)
binding        recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
dgram          recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6286; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 696; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 818; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 608; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6898; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6876; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 5038; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 572; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
stream         recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 3270; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
udp            recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
udp4           recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
```

The preceding interrupted campaign is historical and permanently outside the final statistic. Its 39 attempted/38 valid pairs and missing native receiver readouts remain distinct; no zero guard/coalescing verdict is assigned to the missing receiver. Only the owner-authorized complete fresh additional campaign supplies the second native source.

The plain-UDP udp4 control in headline-1-repeat/r1-udp4 delivered about 3,045 packets/s on the verified q1/.111 path. It uses no wiremux: this is a hint of VM receive-path instability without wiremux, not a finding or attribution. It is noted in diagnosis #2045.

## Address-gate interruption and same-campaign continuation

After 46 accepted pairs (13 warm-ups and 33 counted observations), headline-2-fresh paused before r3-q1continuity launched: the administrative address query returned empty stdout, while the idle gate passed. This was not a native error, address mismatch or application capture glitch. The exact transport fault was not identified. The earlier empty address.gate.json, gate/log/stop receipt and partial-summary.json remain preserved; address-gate-interruption-archive retains all four original gate-slot files matching the pre-resume stop manifest (the exact old gate.txt line was recovered from the retained append-only busy1935.log before archival); the [published interrupted record](https://github.com/GridSwarm/wiremux/blob/ecdd7d9e59ad7053dd494ece62dd019f0ad43b8d/docs/research/native-gap-certification-windows.md#current-stop-address-preservation-gate-received-no-output) reports that state.

The operator authorized a transport repair and continuation of only the 32 unstarted slots. The [read-only gate helper](https://github.com/GridSwarm/wiremux/commit/282bccbaaa2abebd05bf24eb1a57fe9a0cb355e4) writes unique guest output/completion files; identity, timestamps and file size/SHA-256 precede parsing. The unchanged address predicate still requires DHCP enabled, ownership marker, both addresses preferred, .111 first and .2 SkipAsSource. Offline empty/stale/mismatch rejection and 21 focused tests passed; the unchanged predicate accepted a live file-backed query before continuation. A same-boot/settings/address/pin/RSS continuity check passed without a reboot, reset or additional probe. The [repair receipt](https://github.com/GridSwarm/wiremux/blob/ea34a851adaddc16ce99e5dd7fbdbf707fda36a7/docs/research/native-gap-certification-windows.md#address-gate-repair-and-authorized-continuation) was pushed before resuming traffic.

Continuation retained the original campaign/rotation at r3-q1continuity with no extra warm-up, campaign or completed-pair rerun. All 46 accepted pair directories remain byte-identical against address-resume-preserved-46.json, verified before and after continuation and again while assembling this record. The native application collector remains byte-identical to #2048 source17a64625. The final fresh summary covers all78 canonical pairs, and every counted row remains in the ten-run pool. Administrative capture consumed none of the application capture-glitch allowance; all earlier raw evidence remains available. The file-backed admin gate and continuation are one-shot verification aids, never product code. The continuation used operator-reaudit/rig-address-resume.sh with GATE=operator-reaudit/campaign-gate-file.py, the original frozen binaries, 10-second runs, original thirteen-arm order/rotation and the same FROZEN1935/WHOST/WGUEST/WDIR/HCPUS/PORT settings published above. The one reverse campaign used run-address-reverse-campaign.py and rig-capture-file-gate-frozen.sh with the same corrected administrative gate; its default .111 address is independently verified before traffic, and its host target remains unchanged.

## Retention and handback

The owner authorized continuing certification with the retained guests on 2026-10-25 and repeatedly required keeping both VMs until explicit deletion instruction, including every VM/disk/checkpoint in the 2026-10-26 and current directions. All local and stopped GCP VMs, disks/backing layers, NVRAM and snapshots/checkpoints remain retained. No golden, VM, disk or checkpoint was deleted, committed into a backing file or rebased.

After all authorized traffic completed, handback removed only the owned active-only .2 guest address through the supported IP Helper API and verified DHCP, preferred .111, MTU1500, original single-e1000e settings, Windows binary hash and trace-off/no-native-process state. The snapshot-current marker was aligned metadata-only to pre-virtio-model for the new retained overlay branch; no snapshot/disk content was changed or removed. Fresh domain/storage/backing-chain/checkpoint and Fusion inventories plus handback-receipt.json remain in the durable OUTDIR.

x64 domain wiremux-1935-certification on minimax retains /srv/infra/libvirt/work/wiremux-1935-certification/: overlay.qcow2, recovery-active.qcow2, recovery-diagnosis-active.qcow2, virtio-comparison-active.qcow2, post-diagnosis-retained-active.qcow2, e1000e-certification-active.qcow2, nvram.fd and nvram.pre-e1000e-certification-20261027.fd. Checkpoints recovery-configured, recovery-after-diagnosis, pre-virtio-model and pre-e1000e-certification-20261027 remain. The golden /srv/infra/libvirt/images/garm/windows-server-2025-amd64/v4/base.qcow2 remains read-only.

Fusion Arm64 guest /Users/josh/.local/share/wiremux-1935/winarm/wiremux-1935-arm.vmwarevm/wiremux-1935-arm.vmx and all disks/checkpoints remain. Its package retains Virtual Disk-cl2.vmdk plus Virtual Disk-cl2-s001.vmdk through -s032.vmdk, wiremux-1935-arm.nvram and wiremux-1935-arm.vmsd; the exact paths and checkpoint metadata are archived in arm-retained-storage-paths.txt and arm-retained-checkpoint-names.txt. The stopped GCP pair wiremux-1935-linux / wiremux-1935-windows and their protected disks plus wiremux-1935-pre-gvnic-20261026 snapshot remain untouched, with the existing deletion-protection/auto-delete-disabled receipts preserved. No further GCP operation or alternative environment investigation was performed.

Historical [diagnostic reports](https://github.com/GridSwarm/wiremux/tree/codex/1935-gcp-readiness/docs/research) and [receive-stall research](https://github.com/GridSwarm/wiremux/blob/codex/1935-windows-rx-research/docs/research/issue-1935-windows-rx-stalls.md) are pushed separately and are not certification measurements. No GARM pool, runner, service or configuration was mutated by this session; every native run used the existing shared-host gates. No untraced host or product effect is claimed.

## Complete retained metadata and summaries

Durable OUTDIR parent: /Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/operator-reaudit/. All original per-run JSON, gates, coalescing/correctness observations, frozen identities, protocol/publication receipts and inventories are retained. The following pastes normalize line endings and strip trailing presentation padding only; raw outputs remain unmodified.

### headline-1

OUTDIR: `/Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/operator-reaudit/headline-1/`.

`meta.txt`:

```text
date: 2026-10-27T03:02:18Z
cell: winvm reps: 5 secs: 10 warmup: 1
rig: ff86096fa354eef4a1b3533696bc89e892deee9c dirty=3
go: go version go1.27.3 darwin/arm64
frozen-binary campaign: original ff86096f + recorded observer; no rebuild; source /Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/resume-fixed-ip-smoke
modfile: cmd/nativerig/rig.mod
quic-go: replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.9
arms:
  dgram=dgram -native-min-payload 1397 -size 1397 -lport 50001
  stream=stream -lport 50001
  udp=udp
  udp4=udp -sockets 4
  binding=binding
  q0dgrampin=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
  q0continuity=dgram -target 192.168.122.2:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
  q0streampin=stream -target 192.168.122.2:47869 -lport 50001 -ballast 64 -gc-role both
  q0dgramgc=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397
  q1dgrampin=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
  q1continuity=dgram -target 192.168.122.111:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
  q1streampin=stream -target 192.168.122.111:47869 -lport 50001 -ballast 64 -gc-role both
  q1dgramgc=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397
quiet load before the first run: sender { 3.71 4.11 4.32 }
sender: Darwin mbp128.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
sender sysctl: 8388608 786896 9216
winvm host: Linux minimax 7.0.0-30-generic #30-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 18:22:54 UTC 2026 x86_64 GNU/Linux
winvm quiet load before the first run: 1.07 1.10 1.09 3/599 869740
winvm direction: fwd (fwd: host sends to the guest; rev: the guest sends to the host); port 47869
winvm host peer: virbr0, taskset -c 0-1,16-17; guest wiremux-1935-certification, adapter Ethernet
winvm host sysctl: 4194304 4194304 212992
winvm guest pinning and domains:
   VCPU   CPU Affinity
  ----------------------
   0      4
   1      5
   2      6
   3      7

  emulator: CPU Affinity
  ----------------------------------
         *: 18-19

   Interface   Type      Source    Model    MAC
  -------------------------------------------------------------
   vnet541     network   default   e1000e   52:54:00:19:35:01

   Id    Name                         State
  ---------------------------------------------
   519   wiremux-1935-certification   running

winvm host offloads (virbr0):
  generic-segmentation-offload: on
  generic-receive-offload: on
  tx-udp-segmentation: off [requested on]
  rx-udp-gro-forwarding: off
winvm host cpu map:
  CPU CORE L1d:L1i:L2:L3
    0    0 0:0:0:0
    1    1 1:1:1:0
    2    2 2:2:2:0
    3    3 3:3:3:0
    4    4 4:4:4:0
    5    5 5:5:5:0
    6    6 6:6:6:0
    7    7 7:7:7:0
    8    8 8:8:8:1
    9    9 9:9:9:1
   10   10 10:10:10:1
   11   11 11:11:11:1
   12   12 12:12:12:1
   13   13 13:13:13:1
   14   14 14:14:14:1
   15   15 15:15:15:1
   16    0 0:0:0:0
   17    1 1:1:1:0
   18    2 2:2:2:0
   19    3 3:3:3:0
   20    4 4:4:4:0
   21    5 5:5:5:0
   22    6 6:6:6:0
   23    7 7:7:7:0
   24    8 8:8:8:1
   25    9 9:9:9:1
   26   10 10:10:10:1
   27   11 11:11:11:1
   28   12 12:12:12:1
   29   13 13:13:13:1
   30   14 14:14:14:1
   31   15 15:15:15:1
winvm guest 192.168.122.111 (Ethernet), host 192.168.122.1 (virbr0), tap vnet541
  guest: Microsoft Windows NT 10.0.26100.0
  guest:
  guest:
  guest: Name                 : Ethernet
  guest: InterfaceDescription : Intel(R) 82574L Gigabit Network Connection
  guest: LinkSpeed            : 1 Gbps
  guest: MtuSize              : 1500
  guest: DriverVersionString  : 12.19.1.32
  guest:
  guest:
  guest:
  guest:
  guest:
  guest: NlMtu : 1500
  guest:
  guest:
  guest:
  guest:
  guest: DisplayName                      DisplayValue
  guest: -----------                      ------------
  guest: Flow Control                     Rx & Tx Enabled
  guest: Interrupt Moderation             Enabled
  guest: IPv4 Checksum Offload            Rx & Tx Enabled
  guest: Jumbo Packet                     Disabled
  guest: Large Send Offload V2 (IPv4)     Enabled
  guest: Large Send Offload V2 (IPv6)     Enabled
  guest: Maximum number of RSS Processors 8
  guest: Preferred NUMA node              65535
  guest: Maximum Number of RSS Queues     2 Queues
  guest: Packet Priority & VLAN           Packet Priority & VLAN Enabled
  guest: Receive Buffers                  2048
  guest: Receive Side Scaling             Enabled
  guest: RSS Base Processor Number        0
  guest: Maximum RSS Processor Number     63
  guest: RSS load balancing profile       NUMAScalingStatic
  guest: Speed & Duplex                   Auto Negotiation
  guest: TCP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: TCP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Transmit Buffers                 512
  guest: UDP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: UDP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Adaptive Inter-Frame Spacing     Disabled
  guest: Interrupt Moderation Rate        Adaptive
  guest: Log Link State Event             Enabled
  guest: Gigabit Master Slave Mode        Auto Detect
  guest: Locally Administered Address
  guest: Wait for Link                    Auto Detect
  guest:
  guest:
  guest:
  guest: Querying active state...
  guest:
  guest: UDP Global Parameters
  guest: ----------------------------------------------
  guest: Receive Offload State               : enabled
  guest: Send Offload State                  : enabled
  guest:
  guest:
  guest:
  guest: ReceiveSideScaling           : Enabled
  guest: ReceiveSegmentCoalescing     : Enabled
  guest: Chimney                      : Disabled
  guest: TaskOffload                  : Enabled
  guest: NetworkDirect                : Enabled
  guest: NetworkDirectAcrossIPSubnets : Blocked
  guest: PacketCoalescingFilter       : Disabled
  guest:
  guest:
  guest:
```

`summary.txt`:

```text
medians over non-warm-up runs; cpu/GiB is CPU seconds per delivered GiB; lost packets per run: wire = sender if out - receiver if in, stack = receiver if in - UDP in, rcvbuf = full socket buffer
arm             n Mbit/s med    min    max  pkt/s med    loss cpu/GiB s      r     wire    stack   rcvbuf
binding         5       2991   2841   3127     257481  58.22%      4.48   2.95        9        1        0
dgram           5       3281   3240   3365     293566   0.19%      2.12   3.67        9        2        0
q0continuity    5        289    288   3428      30340   0.05%      2.52   6.09        9        2        0
q0dgramgc       5       3549    337   4105     317548   0.09%      2.10   3.43       10        2        0
q0dgrampin      5       1522    334   3289     136144   0.09%      1.93   3.25        9        2        0
q0streampin     5        342    340    356          0       -      2.19   5.72        8        1        0
q1continuity    5       3004   2949   3013     315298   0.21%      2.13   3.56        9        1        0
q1dgramgc       5       3312   3261   3365     296385   0.20%      2.11   3.57        9        2        0
q1dgrampin      5       3438   3398   3481     307613   0.19%      1.88   3.08        9        1        0
q1streampin     5       3421   3362   3535          0       -      1.59   3.19        8        1        0
stream          5       3480   3375   3532          0       -      1.60   3.02        8        1        0
udp             5       5744   5605   5874     494474  53.74%      1.51   0.73        7        1        0
udp4            5       5155   3508   5194     443799  83.52%      6.43   1.29        5        1        0

flagged runs (kept in the statistics; never dropped):
  r1-q0dgrampin: rate 0.22x median
  r2-q0dgrampin: rate 1.32x median
  r2-udp4: rate 0.68x median
  r3-q0continuity: rate 11.86x median
  r3-q0dgramgc: rate 0.10x median
  r3-q0dgrampin: rate 0.22x median
  r5-q0dgrampin: rate 2.16x median
  r5-udp4: rate 0.68x median

extras (medians): sender member-queue drops; lost after the sender's member queue (member dequeued - receiver if in); receiver 16 KB cluster refill failures; receiver if in frames/s and bytes/frame; GC cycles/s per peer; -qdepth queued datagrams before each read (median, mean, share empty)
arm             q drop  after q  16k fail   in fr/s  B/frame  gc/s s  gc/s r             qdepth
binding              -        -         -         -        -     9.2   414.9                  -
dgram                -        -         -         -        -   418.8   164.6                  -
q0continuity         -        -         -         -        -     1.3     0.7                  -
q0dgramgc            -        -         -         -        -   414.9   171.5                  -
q0dgrampin           -        -         -         -        -     6.3     3.2                  -
q0streampin          -        -         -         -        -     0.1     0.1                  -
q1continuity         -        -         -         -        -    13.4     6.8                  -
q1dgramgc            -        -         -         -        -   408.1   162.1                  -
q1dgrampin           -        -         -         -        -    14.2     7.2                  -
q1streampin          -        -         -         -        -     0.3     0.2                  -
stream               -        -         -         -        -     4.9     1.1                  -
udp                  -        -         -         -        -     0.0     0.0                  -
udp4                 -        -         -         -        -     0.0     0.0                  -

sender CPU per offered packet (medians, min-max): user and system microseconds; share of each on performance cores
arm                       user us             sys us  user P   sys P
binding          0.70 (0.67-0.71)   1.78 (1.77-1.83)       -       -
dgram            2.07 (2.05-2.09)   0.68 (0.66-0.70)       -       -
q0continuity     2.11 (1.84-2.13)   0.76 (0.52-0.77)       -       -
q0dgramgc        2.05 (2.02-2.34)   0.69 (0.67-0.75)       -       -
q0dgrampin       1.92 (1.86-2.22)   0.63 (0.58-0.87)       -       -
q1continuity     1.82 (1.81-1.84)   0.54 (0.52-0.55)       -       -
q1dgramgc        2.04 (2.02-2.08)   0.70 (0.69-0.71)       -       -
q1dgrampin       1.87 (1.85-1.87)   0.58 (0.57-0.60)       -       -
udp              0.09 (0.09-0.10)   0.86 (0.85-0.86)       -       -
udp4             0.13 (0.13-0.14)   1.30 (1.29-1.30)       -       -

receiver per delivered datagram (medians; min-max for total CPU): receive call; CPU-s per delivered GiB, total, user, system; user and system microseconds per datagram; system share on performance cores; cycles per datagram; receive system calls per datagram (read and recvmsg: 1, a floor, as parked calls are not visible); recvmsg_x datagrams per delivering call (mean, median), share of calls that filled every slot, parked calls per delivering call
arm                   call         cpu/GiB r  user   sys user us sys us sys P  cyc/dg calls/dg      fill  full park/dc
udp                   read  0.73 (0.66-0.75)  0.10  0.61    0.13   0.83     -       -        1         -     -       -
udp4                  read  1.29 (1.22-1.39)  0.29  0.98    0.40   1.33     -       -        1         -     -       -

native readouts (medians; slice 3.1's seam): readouts mode; sender min, smoothed (at the end) and mean RTT over the send window (us); PTOs and spurious losses over the sender's window (recorder only); receiver packets received/s (ConnectionStats.PacketsReceived); receiver Datagram discards and unprocessed-queue drops at the end; runs with a missing snapshot. absent = no fork method, no recorder, or no snapshot
arm                mode  minRTT    sRTT  meanRTT   PTO  spur   r pkt/s  dg drop   unproc miss  env
dgram             stats     191     991   absent absent absent    292111        2   absent    0  -
q0continuity      stats     224   27972   absent absent absent     30259        0   absent    0  -
q0dgramgc         stats     203    1348   absent absent absent    317544        1   absent    0  -
q0dgrampin        stats     170   12340   absent absent absent    136146        0   absent    0  -
q0streampin       stats     195   55717   absent absent absent     30709        0   absent    0  -
q1continuity      stats     171    3852   absent absent absent    315307        0   absent    0  -
q1dgramgc         stats     176    1295   absent absent absent    294941        2   absent    0  -
q1dgrampin        stats     184    2006   absent absent absent    306124        2   absent    0  -
q1streampin       stats     179    6297   absent absent absent    306655        0   absent    0  -
stream            stats     153    5244   absent absent absent    311934        0   absent    0  -

native extra counts (medians of each peer's total at its final snapshot; counts a scratch build adds to 3.1's Readout)
binding        recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
dgram          recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 5688; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 35; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 2898; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 1235; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6657; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 5992; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6001; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 867; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
stream         recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 2042; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
udp            recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
udp4           recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
```

### headline-1-repeat

OUTDIR: `/Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/operator-reaudit/headline-1-repeat/`.

`meta.txt`:

```text
date: 2026-10-27T03:52:07Z
cell: winvm reps: 5 secs: 10 warmup: 1
rig: ff86096fa354eef4a1b3533696bc89e892deee9c dirty=3
go: go version go1.27.3 darwin/arm64
frozen-binary campaign: original ff86096f + recorded observer; no rebuild; source /Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/resume-fixed-ip-smoke
modfile: cmd/nativerig/rig.mod
quic-go: replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.9
arms:
  dgram=dgram -native-min-payload 1397 -size 1397 -lport 50001
  stream=stream -lport 50001
  udp=udp
  udp4=udp -sockets 4
  binding=binding
  q0dgrampin=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
  q0continuity=dgram -target 192.168.122.2:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
  q0streampin=stream -target 192.168.122.2:47869 -lport 50001 -ballast 64 -gc-role both
  q0dgramgc=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397
  q1dgrampin=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
  q1continuity=dgram -target 192.168.122.111:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
  q1streampin=stream -target 192.168.122.111:47869 -lport 50001 -ballast 64 -gc-role both
  q1dgramgc=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397
quiet load before the first run: sender { 4.09 3.44 3.55 }
sender: Darwin mbp128.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
sender sysctl: 8388608 786896 9216
winvm host: Linux minimax 7.0.0-30-generic #30-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 18:22:54 UTC 2026 x86_64 GNU/Linux
winvm quiet load before the first run: 0.90 1.55 1.73 2/588 982714
winvm direction: fwd (fwd: host sends to the guest; rev: the guest sends to the host); port 47869
winvm host peer: virbr0, taskset -c 0-1,16-17; guest wiremux-1935-certification, adapter Ethernet
winvm host sysctl: 4194304 4194304 212992
winvm guest pinning and domains:
   VCPU   CPU Affinity
  ----------------------
   0      4
   1      5
   2      6
   3      7

  emulator: CPU Affinity
  ----------------------------------
         *: 18-19

   Interface   Type      Source    Model    MAC
  -------------------------------------------------------------
   vnet541     network   default   e1000e   52:54:00:19:35:01

   Id    Name                         State
  ---------------------------------------------
   519   wiremux-1935-certification   running

winvm host offloads (virbr0):
  generic-segmentation-offload: on
  generic-receive-offload: on
  tx-udp-segmentation: off [requested on]
  rx-udp-gro-forwarding: off
winvm host cpu map:
  CPU CORE L1d:L1i:L2:L3
    0    0 0:0:0:0
    1    1 1:1:1:0
    2    2 2:2:2:0
    3    3 3:3:3:0
    4    4 4:4:4:0
    5    5 5:5:5:0
    6    6 6:6:6:0
    7    7 7:7:7:0
    8    8 8:8:8:1
    9    9 9:9:9:1
   10   10 10:10:10:1
   11   11 11:11:11:1
   12   12 12:12:12:1
   13   13 13:13:13:1
   14   14 14:14:14:1
   15   15 15:15:15:1
   16    0 0:0:0:0
   17    1 1:1:1:0
   18    2 2:2:2:0
   19    3 3:3:3:0
   20    4 4:4:4:0
   21    5 5:5:5:0
   22    6 6:6:6:0
   23    7 7:7:7:0
   24    8 8:8:8:1
   25    9 9:9:9:1
   26   10 10:10:10:1
   27   11 11:11:11:1
   28   12 12:12:12:1
   29   13 13:13:13:1
   30   14 14:14:14:1
   31   15 15:15:15:1
winvm guest 192.168.122.111 (Ethernet), host 192.168.122.1 (virbr0), tap vnet541
  guest: Microsoft Windows NT 10.0.26100.0
  guest:
  guest:
  guest: Name                 : Ethernet
  guest: InterfaceDescription : Intel(R) 82574L Gigabit Network Connection
  guest: LinkSpeed            : 1 Gbps
  guest: MtuSize              : 1500
  guest: DriverVersionString  : 12.19.1.32
  guest:
  guest:
  guest:
  guest:
  guest:
  guest: NlMtu : 1500
  guest:
  guest:
  guest:
  guest:
  guest: DisplayName                      DisplayValue
  guest: -----------                      ------------
  guest: Flow Control                     Rx & Tx Enabled
  guest: Interrupt Moderation             Enabled
  guest: IPv4 Checksum Offload            Rx & Tx Enabled
  guest: Jumbo Packet                     Disabled
  guest: Large Send Offload V2 (IPv4)     Enabled
  guest: Large Send Offload V2 (IPv6)     Enabled
  guest: Maximum number of RSS Processors 8
  guest: Preferred NUMA node              65535
  guest: Maximum Number of RSS Queues     2 Queues
  guest: Packet Priority & VLAN           Packet Priority & VLAN Enabled
  guest: Receive Buffers                  2048
  guest: Receive Side Scaling             Enabled
  guest: RSS Base Processor Number        0
  guest: Maximum RSS Processor Number     63
  guest: RSS load balancing profile       NUMAScalingStatic
  guest: Speed & Duplex                   Auto Negotiation
  guest: TCP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: TCP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Transmit Buffers                 512
  guest: UDP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: UDP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Adaptive Inter-Frame Spacing     Disabled
  guest: Interrupt Moderation Rate        Adaptive
  guest: Log Link State Event             Enabled
  guest: Gigabit Master Slave Mode        Auto Detect
  guest: Locally Administered Address
  guest: Wait for Link                    Auto Detect
  guest:
  guest:
  guest:
  guest: Querying active state...
  guest:
  guest: UDP Global Parameters
  guest: ----------------------------------------------
  guest: Receive Offload State               : enabled
  guest: Send Offload State                  : enabled
  guest:
  guest:
  guest:
  guest: ReceiveSideScaling           : Enabled
  guest: ReceiveSegmentCoalescing     : Enabled
  guest: Chimney                      : Disabled
  guest: TaskOffload                  : Enabled
  guest: NetworkDirect                : Enabled
  guest: NetworkDirectAcrossIPSubnets : Blocked
  guest: PacketCoalescingFilter       : Disabled
  guest:
  guest:
  guest:
```

`summary.txt`:

```text
medians over non-warm-up runs; cpu/GiB is CPU seconds per delivered GiB; lost packets per run: wire = sender if out - receiver if in, stack = receiver if in - UDP in, rcvbuf = full socket buffer
arm             n Mbit/s med    min    max  pkt/s med    loss cpu/GiB s      r     wire    stack   rcvbuf
binding         5       3164   2993   3208     272405  57.08%      4.23   2.87        8        1        0
dgram           5       3310   3253   3351     296200   0.18%      2.12   3.51        9        2        0
q0continuity    5        290    289   3667      30410   0.13%      2.51   5.93       10        2        0
q0dgramgc       5       3536    338   3593     316430   0.12%      2.08   3.59        9        2        0
q0dgrampin      5        339    337   2830      30301   0.10%      2.31   5.18        9        2        0
q0streampin     5        345    343   2531          0       -      2.05   4.78        8        1        0
q1continuity    5       2987   2922   3006     313492   0.23%      2.12   3.62        9        2        0
q1dgramgc       5       3293   3222   3410     294633   0.23%      2.12   3.57       10        2        0
q1dgrampin      5       3409   3362   3452     305018   0.19%      1.88   3.09        9        2        0
q1streampin     5       3396   3272   3443          0       -      1.56   3.22        8        2        0
stream          5       3411   3352   3507          0       -      1.56   3.24        8        1        0
udp             5       5729   5126   5872     493234  53.79%      1.52   0.72        8        1        0
udp4            5       5302     35   5733     456435  83.08%      6.25   1.32        7        1        0

flagged runs (kept in the statistics; never dropped):
  r1-udp4: rate 0.01x median
  r2-q0continuity: rate 12.65x median
  r2-q0dgramgc: rate 0.10x median
  r2-q0streampin: rate 7.34x median
  r3-q0dgramgc: rate 0.10x median
  r3-q0dgrampin: rate 8.36x median
  r4-q0continuity: rate 10.60x median
  r5-q0streampin: rate 3.81x median
  r5-udp4: rate 0.75x median

extras (medians): sender member-queue drops; lost after the sender's member queue (member dequeued - receiver if in); receiver 16 KB cluster refill failures; receiver if in frames/s and bytes/frame; GC cycles/s per peer; -qdepth queued datagrams before each read (median, mean, share empty)
arm             q drop  after q  16k fail   in fr/s  B/frame  gc/s s  gc/s r             qdepth
binding              -        -         -         -        -     9.2   437.9                  -
dgram                -        -         -         -        -   422.1   163.5                  -
q0continuity         -        -         -         -        -     1.3     0.7                  -
q0dgramgc            -        -         -         -        -   413.5   168.9                  -
q0dgrampin           -        -         -         -        -     1.4     0.8                  -
q0streampin          -        -         -         -        -     0.1     0.1                  -
q1continuity         -        -         -         -        -    13.3     6.8                  -
q1dgramgc            -        -         -         -        -   423.4   160.7                  -
q1dgrampin           -        -         -         -        -    14.1     7.2                  -
q1streampin          -        -         -         -        -     0.3     0.2                  -
stream               -        -         -         -        -     5.5     1.1                  -
udp                  -        -         -         -        -     0.0     0.0                  -
udp4                 -        -         -         -        -     0.0     0.0                  -

sender CPU per offered packet (medians, min-max): user and system microseconds; share of each on performance cores
arm                       user us             sys us  user P   sys P
binding          0.69 (0.67-0.70)   1.78 (1.74-1.85)       -       -
dgram            2.06 (2.02-2.10)   0.68 (0.67-0.69)       -       -
q0continuity     2.02 (1.81-2.12)   0.66 (0.52-0.82)       -       -
q0dgramgc        2.02 (1.99-2.43)   0.69 (0.68-0.78)       -       -
q0dgrampin       2.14 (1.85-2.28)   0.85 (0.60-0.87)       -       -
q1continuity     1.80 (1.80-1.82)   0.54 (0.53-0.55)       -       -
q1dgramgc        2.05 (2.03-2.06)   0.69 (0.68-0.72)       -       -
q1dgrampin       1.85 (1.84-1.87)   0.60 (0.58-0.60)       -       -
udp              0.09 (0.09-0.09)   0.85 (0.84-0.86)       -       -
udp4             0.12 (0.12-0.13)   1.30 (1.29-1.31)       -       -

receiver per delivered datagram (medians; min-max for total CPU): receive call; CPU-s per delivered GiB, total, user, system; user and system microseconds per datagram; system share on performance cores; cycles per datagram; receive system calls per datagram (read and recvmsg: 1, a floor, as parked calls are not visible); recvmsg_x datagrams per delivering call (mean, median), share of calls that filled every slot, parked calls per delivering call
arm                   call         cpu/GiB r  user   sys user us sys us sys P  cyc/dg calls/dg      fill  full park/dc
udp                   read  0.72 (0.65-0.74)  0.10  0.61    0.14   0.83     -       -        1         -     -       -
udp4                  read  1.32 (1.20-2.28)  0.34  0.91    0.46   1.23     -       -        1         -     -       -

native readouts (medians; slice 3.1's seam): readouts mode; sender min, smoothed (at the end) and mean RTT over the send window (us); PTOs and spurious losses over the sender's window (recorder only); receiver packets received/s (ConnectionStats.PacketsReceived); receiver Datagram discards and unprocessed-queue drops at the end; runs with a missing snapshot. absent = no fork method, no recorder, or no snapshot
arm                mode  minRTT    sRTT  meanRTT   PTO  spur   r pkt/s  dg drop   unproc miss  env
dgram             stats     185    1488   absent absent absent    296002        2   absent    0  -
q0continuity      stats     224   27636   absent absent absent     30330        0   absent    0  -
q0dgramgc         stats     238    2392   absent absent absent    314901        1   absent    0  -
q0dgrampin        stats     202   32283   absent absent absent     30230        0   absent    0  -
q0streampin       stats     227   50934   absent absent absent     30807        0   absent    0  -
q1continuity      stats     173    3153   absent absent absent    311924        2   absent    0  -
q1dgramgc         stats     177    1245   absent absent absent    294220        2   absent    0  -
q1dgrampin        stats     176    1583   absent absent absent    304068        1   absent    0  -
q1streampin       stats     162    5489   absent absent absent    304442        0   absent    0  -
stream            stats     170    5100   absent absent absent    306041        0   absent    0  -

native extra counts (medians of each peer's total at its final snapshot; counts a scratch build adds to 3.1's Readout)
binding        recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
dgram          recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 5509; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 922; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 3471; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 616; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 7389; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6732; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 5718; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 1060; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
stream         recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 1337; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
udp            recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
udp4           recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
```

### headline-2-fresh

OUTDIR: `/Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/operator-reaudit/headline-2-fresh/`.

`meta.txt`:

```text
date: 2026-10-27T15:22:18Z
cell: winvm reps: 5 secs: 10 warmup: 1
rig: ff86096fa354eef4a1b3533696bc89e892deee9c dirty=3
go: go version go1.27.3 darwin/arm64
frozen-binary campaign: original ff86096f + recorded observer; no rebuild; source /Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/resume-fixed-ip-smoke
modfile: cmd/nativerig/rig.mod
quic-go: replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.9
arms:
  dgram=dgram -native-min-payload 1397 -size 1397 -lport 50001
  stream=stream -lport 50001
  udp=udp
  udp4=udp -sockets 4
  binding=binding
  q0dgrampin=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
  q0continuity=dgram -target 192.168.122.2:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
  q0streampin=stream -target 192.168.122.2:47869 -lport 50001 -ballast 64 -gc-role both
  q0dgramgc=dgram -target 192.168.122.2:47869 -lport 50001 -native-min-payload 1397 -size 1397
  q1dgrampin=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
  q1continuity=dgram -target 192.168.122.111:47869 -lport 50001 -size 1191 -ballast 64 -gc-role both
  q1streampin=stream -target 192.168.122.111:47869 -lport 50001 -ballast 64 -gc-role both
  q1dgramgc=dgram -target 192.168.122.111:47869 -lport 50001 -native-min-payload 1397 -size 1397
quiet load before the first run: sender { 7.21 5.28 5.36 }
sender: Darwin mbp128.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
sender sysctl: 8388608 786896 9216
winvm host: Linux minimax 7.0.0-30-generic #30-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 18:22:54 UTC 2026 x86_64 GNU/Linux
winvm quiet load before the first run: 0.95 0.94 0.96 2/586 1338607
winvm direction: fwd (fwd: host sends to the guest; rev: the guest sends to the host); port 47869
winvm host peer: virbr0, taskset -c 0-1,16-17; guest wiremux-1935-certification, adapter Ethernet
winvm host sysctl: 4194304 4194304 212992
winvm guest pinning and domains:
   VCPU   CPU Affinity
  ----------------------
   0      4
   1      5
   2      6
   3      7

  emulator: CPU Affinity
  ----------------------------------
         *: 18-19

   Interface   Type      Source    Model    MAC
  -------------------------------------------------------------
   vnet541     network   default   e1000e   52:54:00:19:35:01

   Id    Name                         State
  ---------------------------------------------
   519   wiremux-1935-certification   running

winvm host offloads (virbr0):
  generic-segmentation-offload: on
  generic-receive-offload: on
  tx-udp-segmentation: off [requested on]
  rx-udp-gro-forwarding: off
winvm host cpu map:
  CPU CORE L1d:L1i:L2:L3
    0    0 0:0:0:0
    1    1 1:1:1:0
    2    2 2:2:2:0
    3    3 3:3:3:0
    4    4 4:4:4:0
    5    5 5:5:5:0
    6    6 6:6:6:0
    7    7 7:7:7:0
    8    8 8:8:8:1
    9    9 9:9:9:1
   10   10 10:10:10:1
   11   11 11:11:11:1
   12   12 12:12:12:1
   13   13 13:13:13:1
   14   14 14:14:14:1
   15   15 15:15:15:1
   16    0 0:0:0:0
   17    1 1:1:1:0
   18    2 2:2:2:0
   19    3 3:3:3:0
   20    4 4:4:4:0
   21    5 5:5:5:0
   22    6 6:6:6:0
   23    7 7:7:7:0
   24    8 8:8:8:1
   25    9 9:9:9:1
   26   10 10:10:10:1
   27   11 11:11:11:1
   28   12 12:12:12:1
   29   13 13:13:13:1
   30   14 14:14:14:1
   31   15 15:15:15:1
winvm guest 192.168.122.111 (Ethernet), host 192.168.122.1 (virbr0), tap vnet541
  guest: Microsoft Windows NT 10.0.26100.0
  guest:
  guest:
  guest: Name                 : Ethernet
  guest: InterfaceDescription : Intel(R) 82574L Gigabit Network Connection
  guest: LinkSpeed            : 1 Gbps
  guest: MtuSize              : 1500
  guest: DriverVersionString  : 12.19.1.32
  guest:
  guest:
  guest:
  guest:
  guest:
  guest: NlMtu : 1500
  guest:
  guest:
  guest:
  guest:
  guest: DisplayName                      DisplayValue
  guest: -----------                      ------------
  guest: Flow Control                     Rx & Tx Enabled
  guest: Interrupt Moderation             Enabled
  guest: IPv4 Checksum Offload            Rx & Tx Enabled
  guest: Jumbo Packet                     Disabled
  guest: Large Send Offload V2 (IPv4)     Enabled
  guest: Large Send Offload V2 (IPv6)     Enabled
  guest: Maximum number of RSS Processors 8
  guest: Preferred NUMA node              65535
  guest: Maximum Number of RSS Queues     2 Queues
  guest: Packet Priority & VLAN           Packet Priority & VLAN Enabled
  guest: Receive Buffers                  2048
  guest: Receive Side Scaling             Enabled
  guest: RSS Base Processor Number        0
  guest: Maximum RSS Processor Number     63
  guest: RSS load balancing profile       NUMAScalingStatic
  guest: Speed & Duplex                   Auto Negotiation
  guest: TCP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: TCP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Transmit Buffers                 512
  guest: UDP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: UDP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Adaptive Inter-Frame Spacing     Disabled
  guest: Interrupt Moderation Rate        Adaptive
  guest: Log Link State Event             Enabled
  guest: Gigabit Master Slave Mode        Auto Detect
  guest: Locally Administered Address
  guest: Wait for Link                    Auto Detect
  guest:
  guest:
  guest:
  guest: Querying active state...
  guest:
  guest: UDP Global Parameters
  guest: ----------------------------------------------
  guest: Receive Offload State               : enabled
  guest: Send Offload State                  : enabled
  guest:
  guest:
  guest:
  guest: ReceiveSideScaling           : Enabled
  guest: ReceiveSegmentCoalescing     : Enabled
  guest: Chimney                      : Disabled
  guest: TaskOffload                  : Enabled
  guest: NetworkDirect                : Enabled
  guest: NetworkDirectAcrossIPSubnets : Blocked
  guest: PacketCoalescingFilter       : Disabled
  guest:
  guest:
  guest:
```

`summary.txt`:

```text
medians over non-warm-up runs; cpu/GiB is CPU seconds per delivered GiB; lost packets per run: wire = sender if out - receiver if in, stack = receiver if in - UDP in, rcvbuf = full socket buffer
arm             n Mbit/s med    min    max  pkt/s med    loss cpu/GiB s      r     wire    stack   rcvbuf
binding         5       3068   2959   3237     264140  58.02%      4.36   2.89        9        0        0
dgram           5       3266   3212   3334     292202   0.21%      2.13   3.62       10        2        0
q0continuity    5        288    287   3335      30270   0.13%      2.54   5.25        9        2        0
q0dgramgc       5        338    336   3604      30279   0.20%      2.45   5.50        9        1        0
q0dgrampin      5        607    337   4185      54318   0.10%      2.06   4.47       10        2        0
q0streampin     5       1061    339   2908          0       -      1.68   3.48        8        2        0
q1continuity    5       2987   2940   3052     313493   0.24%      2.12   3.58        9        2        0
q1dgramgc       5       3294   3214   3401     294737   0.23%      2.10   3.55        9        2        0
q1dgrampin      5       3423   3397   3465     306258   0.15%      1.88   3.09       10        2        0
q1streampin     5       3399   3363   3461          0       -      1.55   3.19        8        2        0
stream          5       3410   3356   3553          0       -      1.57   3.25        8        1        0
udp             5       5808   5054   5842     500032  53.77%      1.50   0.69        8        1        0
udp4            5       4430   3243   5723     381399  86.05%      7.52   1.30        6        1        0

flagged runs (kept in the statistics; never dropped):
  r1-q0continuity: rate 7.68x median
  r1-q0streampin: rate 0.32x median
  r1-udp4: rate 0.73x median
  r2-q0dgramgc: rate 10.65x median
  r2-q0dgrampin: rate 6.05x median
  r2-q0streampin: rate 1.79x median
  r3-q0dgramgc: rate 10.29x median
  r3-q0dgrampin: rate 0.56x median
  r4-q0continuity: rate 11.56x median
  r4-q0dgrampin: rate 6.89x median
  r4-q0streampin: rate 2.74x median
  r4-udp4: rate 1.29x median
  r5-q0dgrampin: rate 0.56x median
  r5-udp4: rate 1.29x median

extras (medians): sender member-queue drops; lost after the sender's member queue (member dequeued - receiver if in); receiver 16 KB cluster refill failures; receiver if in frames/s and bytes/frame; GC cycles/s per peer; -qdepth queued datagrams before each read (median, mean, share empty)
arm             q drop  after q  16k fail   in fr/s  B/frame  gc/s s  gc/s r             qdepth
binding              -        -         -         -        -     9.4   424.1                  -
dgram                -        -         -         -        -   419.4   160.6                  -
q0continuity         -        -         -         -        -     1.3     0.7                  -
q0dgramgc            -        -         -         -        -    29.7    25.1                  -
q0dgrampin           -        -         -         -        -     2.5     1.4                  -
q0streampin          -        -         -         -        -     0.1     0.1                  -
q1continuity         -        -         -         -        -    13.4     6.8                  -
q1dgramgc            -        -         -         -        -   407.0   161.0                  -
q1dgrampin           -        -         -         -        -    14.1     7.2                  -
q1streampin          -        -         -         -        -     0.3     0.2                  -
stream               -        -         -         -        -     5.1     1.2                  -
udp                  -        -         -         -        -     0.0     0.0                  -
udp4                 -        -         -         -        -     0.0     0.0                  -

sender CPU per offered packet (medians, min-max): user and system microseconds; share of each on performance cores
arm                       user us             sys us  user P   sys P
binding          0.70 (0.67-0.71)   1.77 (1.75-1.83)       -       -
dgram            2.07 (2.03-2.13)   0.69 (0.66-0.70)       -       -
q0continuity     2.07 (1.81-2.15)   0.71 (0.54-0.79)       -       -
q0dgramgc        2.46 (2.01-2.51)   0.70 (0.67-0.74)       -       -
q0dgrampin       2.02 (1.83-2.24)   0.66 (0.58-0.85)       -       -
q1continuity     1.81 (1.79-1.83)   0.54 (0.53-0.56)       -       -
q1dgramgc        2.05 (2.04-2.07)   0.69 (0.68-0.69)       -       -
q1dgrampin       1.85 (1.85-1.87)   0.59 (0.58-0.60)       -       -
udp              0.09 (0.08-0.09)   0.85 (0.85-0.86)       -       -
udp4             0.13 (0.12-0.13)   1.30 (1.29-1.31)       -       -

receiver per delivered datagram (medians; min-max for total CPU): receive call; CPU-s per delivered GiB, total, user, system; user and system microseconds per datagram; system share on performance cores; cycles per datagram; receive system calls per datagram (read and recvmsg: 1, a floor, as parked calls are not visible); recvmsg_x datagrams per delivering call (mean, median), share of calls that filled every slot, parked calls per delivering call
arm                   call         cpu/GiB r  user   sys user us sys us sys P  cyc/dg calls/dg      fill  full park/dc
udp                   read  0.69 (0.67-0.74)  0.08  0.60    0.11   0.82     -       -        1         -     -       -
udp4                  read  1.30 (1.28-1.37)  0.34  1.02    0.47   1.38     -       -        1         -     -       -

native readouts (medians; slice 3.1's seam): readouts mode; sender min, smoothed (at the end) and mean RTT over the send window (us); PTOs and spurious losses over the sender's window (recorder only); receiver packets received/s (ConnectionStats.PacketsReceived); receiver Datagram discards and unprocessed-queue drops at the end; runs with a missing snapshot. absent = no fork method, no recorder, or no snapshot
arm                mode  minRTT    sRTT  meanRTT   PTO  spur   r pkt/s  dg drop   unproc miss  env
dgram             stats     187    1265   absent absent absent    292214        1   absent    0  -
q0continuity      stats     231   25085   absent absent absent     30188        0   absent    0  -
q0dgramgc         stats     223   23416   absent absent absent     30210        0   absent    0  -
q0dgrampin        stats     194    1728   absent absent absent     54315        0   absent    0  -
q0streampin       stats     220   49209   absent absent absent     95075        0   absent    0  -
q1continuity      stats     195    1615   absent absent absent    311918        1   absent    0  -
q1dgramgc         stats     177    1424   absent absent absent    293263        1   absent    0  -
q1dgrampin        stats     199    2073   absent absent absent    305599        2   absent    0  -
q1streampin       stats     175    7581   absent absent absent    304720        0   absent    0  -
stream            stats     183    5919   absent absent absent    305700        0   absent    0  -

native extra counts (medians of each peer's total at its final snapshot; counts a scratch build adds to 3.1's Readout)
binding        recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
dgram          recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6260; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 93; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 858; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 1206; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 521; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 7545; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6690; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 4607; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 911; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
stream         recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 755; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
udp            recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
udp4           recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
```

### pooled

OUTDIR: `/Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/operator-reaudit/pooled/`.

`meta.txt`:

```text
Read-only statistical pool of all non-warm-up runs from the two effective forward campaigns listed in effective-forward.json. Original warm-ups remain in their source OUTDIRs. No excluded low-rate/stuck row. Each canonical r1-r10 view is mapped in source-map.json. Same pinned summarize.py, no new result parser or different aggregation.
```

`summary.txt`:

```text
medians over non-warm-up runs; cpu/GiB is CPU seconds per delivered GiB; lost packets per run: wire = sender if out - receiver if in, stack = receiver if in - UDP in, rcvbuf = full socket buffer
arm             n Mbit/s med    min    max  pkt/s med    loss cpu/GiB s      r     wire    stack   rcvbuf
binding        10       3126   2959   3237     269089  57.42%      4.29   2.88        9        1        0
dgram          10       3295   3212   3351     294842   0.21%      2.12   3.57       10        2        0
q0continuity   10        290    287   3667      30390   0.13%      2.51   5.59       10        2        0
q0dgramgc      10       1910    336   3604     170907   0.12%      2.23   4.46        9        2        0
q0dgrampin     10        339    337   4185      30352   0.10%      2.27   5.03        9        2        0
q0streampin    10       1016    339   2908          0       -      1.69   3.81        8        1        0
q1continuity   10       2987   2922   3052     313493   0.24%      2.12   3.61        9        2        0
q1dgramgc      10       3293   3214   3410     294685   0.23%      2.12   3.56       10        2        0
q1dgrampin     10       3416   3362   3465     305638   0.17%      1.88   3.09       10        2        0
q1streampin    10       3398   3272   3461          0       -      1.55   3.20        8        2        0
stream         10       3411   3352   3553          0       -      1.56   3.24        8        1        0
udp            10       5769   5054   5872     496633  53.78%      1.51   0.71        8        1        0
udp4           10       4866     35   5733     418917  84.57%      6.89   1.31        7        1        0

flagged runs (kept in the statistics; never dropped):
  r1-q0dgramgc: rate 1.88x median
  r1-q0streampin: rate 0.34x median
  r1-udp4: rate 0.01x median
  r10-q0dgramgc: rate 0.18x median
  r2-q0continuity: rate 12.66x median
  r2-q0dgramgc: rate 0.18x median
  r2-q0streampin: rate 2.49x median
  r3-q0dgramgc: rate 0.18x median
  r3-q0dgrampin: rate 8.34x median
  r3-q0streampin: rate 0.34x median
  r4-q0continuity: rate 10.61x median
  r4-q0dgramgc: rate 1.85x median
  r4-q0streampin: rate 0.34x median
  r5-q0dgramgc: rate 1.87x median
  r5-q0streampin: rate 1.29x median
  r6-q0continuity: rate 7.65x median
  r6-q0dgramgc: rate 0.18x median
  r6-q0dgrampin: rate 1.79x median
  r6-q0streampin: rate 0.33x median
  r6-udp4: rate 0.67x median
  r7-q0dgramgc: rate 1.89x median
  r7-q0dgrampin: rate 10.82x median
  r7-q0streampin: rate 1.87x median
  r8-q0dgramgc: rate 1.82x median
  r9-q0continuity: rate 11.52x median
  r9-q0dgramgc: rate 0.18x median
  r9-q0dgrampin: rate 12.34x median
  r9-q0streampin: rate 2.86x median

extras (medians): sender member-queue drops; lost after the sender's member queue (member dequeued - receiver if in); receiver 16 KB cluster refill failures; receiver if in frames/s and bytes/frame; GC cycles/s per peer; -qdepth queued datagrams before each read (median, mean, share empty)
arm             q drop  after q  16k fail   in fr/s  B/frame  gc/s s  gc/s r             qdepth
binding              -        -         -         -        -     9.3   430.7                  -
dgram                -        -         -         -        -   420.7   161.8                  -
q0continuity         -        -         -         -        -     1.3     0.7                  -
q0dgramgc            -        -         -         -        -   216.5    97.0                  -
q0dgrampin           -        -         -         -        -     1.4     0.8                  -
q0streampin          -        -         -         -        -     0.1     0.1                  -
q1continuity         -        -         -         -        -    13.3     6.8                  -
q1dgramgc            -        -         -         -        -   413.2   160.9                  -
q1dgrampin           -        -         -         -        -    14.1     7.2                  -
q1streampin          -        -         -         -        -     0.3     0.2                  -
stream               -        -         -         -        -     5.3     1.2                  -
udp                  -        -         -         -        -     0.0     0.0                  -
udp4                 -        -         -         -        -     0.0     0.0                  -

sender CPU per offered packet (medians, min-max): user and system microseconds; share of each on performance cores
arm                       user us             sys us  user P   sys P
binding          0.70 (0.67-0.71)   1.78 (1.74-1.85)       -       -
dgram            2.06 (2.02-2.13)   0.68 (0.66-0.70)       -       -
q0continuity     2.04 (1.81-2.15)   0.68 (0.52-0.82)       -       -
q0dgramgc        2.20 (1.99-2.51)   0.70 (0.67-0.78)       -       -
q0dgrampin       2.10 (1.83-2.28)   0.78 (0.58-0.87)       -       -
q1continuity     1.81 (1.79-1.83)   0.54 (0.53-0.56)       -       -
q1dgramgc        2.05 (2.03-2.07)   0.69 (0.68-0.72)       -       -
q1dgrampin       1.85 (1.84-1.87)   0.59 (0.58-0.60)       -       -
udp              0.09 (0.08-0.09)   0.85 (0.84-0.86)       -       -
udp4             0.13 (0.12-0.13)   1.30 (1.29-1.31)       -       -

receiver per delivered datagram (medians; min-max for total CPU): receive call; CPU-s per delivered GiB, total, user, system; user and system microseconds per datagram; system share on performance cores; cycles per datagram; receive system calls per datagram (read and recvmsg: 1, a floor, as parked calls are not visible); recvmsg_x datagrams per delivering call (mean, median), share of calls that filled every slot, parked calls per delivering call
arm                   call         cpu/GiB r  user   sys user us sys us sys P  cyc/dg calls/dg      fill  full park/dc
udp                   read  0.71 (0.65-0.74)  0.10  0.61    0.13   0.82     -       -        1         -     -       -
udp4                  read  1.31 (1.20-2.28)  0.34  0.96    0.46   1.30     -       -        1         -     -       -

native readouts (medians; slice 3.1's seam): readouts mode; sender min, smoothed (at the end) and mean RTT over the send window (us); PTOs and spurious losses over the sender's window (recorder only); receiver packets received/s (ConnectionStats.PacketsReceived); receiver Datagram discards and unprocessed-queue drops at the end; runs with a missing snapshot. absent = no fork method, no recorder, or no snapshot
arm                mode  minRTT    sRTT  meanRTT   PTO  spur   r pkt/s  dg drop   unproc miss  env
dgram             stats     186    1350   absent absent absent    293494        2   absent    0  -
q0continuity      stats     226   26360   absent absent absent     30313        0   absent    0  -
q0dgramgc         stats     231   12904   absent absent absent    170864        0   absent    0  -
q0dgrampin        stats     198   23752   absent absent absent     30264        0   absent    0  -
q0streampin       stats     223   50072   absent absent absent     90983        0   absent    0  -
q1continuity      stats     185    2780   absent absent absent    311921        2   absent    0  -
q1dgramgc         stats     177    1361   absent absent absent    293742        2   absent    0  -
q1dgrampin        stats     185    1858   absent absent absent    305316        1   absent    0  -
q1streampin       stats     166    6571   absent absent absent    304581        0   absent    0  -
stream            stats     177    5816   absent absent absent    305870        0   absent    0  -

native extra counts (medians of each peer's total at its final snapshot; counts a scratch build adds to 3.1's Readout)
binding        recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
dgram          recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6213; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 512; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 2164; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 27; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q0streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 530; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1continuity   recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 7526; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgramgc      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 6711; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1dgrampin     recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 5162; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
q1streampin    recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 1054; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
stream         recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 1046; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
udp            recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
udp4           recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
```

### reverse

OUTDIR: `/Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/operator-reaudit/reverse/`.

`meta.txt`:

```text
date: 2026-10-27T16:52:23Z
cell: winvm reps: 5 secs: 10 warmup: 1
rig: ff86096fa354eef4a1b3533696bc89e892deee9c dirty=3
go: go version go1.27.3 darwin/arm64
frozen-binary campaign: original ff86096f + recorded observer; no rebuild; source /Volumes/worktrees/wiremux/native-gap-evidence/1935-windows-certification/resume-fixed-ip-smoke
modfile: cmd/nativerig/rig.mod
quic-go: replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.9
arms:
  dgram=dgram -native-min-payload 1397 -size 1397 -lport 50001
  stream=stream -lport 50001
  udp=udp
  udp4=udp -sockets 4
  binding=binding
  dgrampin=dgram -lport 50001 -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
  streampin=stream -lport 50001 -ballast 64 -gc-role both
quiet load before the first run: sender { 3.92 3.21 3.37 }
sender: Darwin mbp128.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
sender sysctl: 8388608 786896 9216
winvm host: Linux minimax 7.0.0-30-generic #30-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 18:22:54 UTC 2026 x86_64 GNU/Linux
winvm quiet load before the first run: 2.08 1.66 1.46 2/594 1476562
winvm direction: rev (fwd: host sends to the guest; rev: the guest sends to the host); port 47869
winvm host peer: virbr0, taskset -c 0-1,16-17; guest wiremux-1935-certification, adapter Ethernet
winvm host sysctl: 4194304 4194304 212992
winvm guest pinning and domains:
   VCPU   CPU Affinity
  ----------------------
   0      4
   1      5
   2      6
   3      7

  emulator: CPU Affinity
  ----------------------------------
         *: 18-19

   Interface   Type      Source    Model    MAC
  -------------------------------------------------------------
   vnet541     network   default   e1000e   52:54:00:19:35:01

   Id    Name                         State
  ---------------------------------------------
   519   wiremux-1935-certification   running

winvm host offloads (virbr0):
  generic-segmentation-offload: on
  generic-receive-offload: on
  tx-udp-segmentation: off [requested on]
  rx-udp-gro-forwarding: off
winvm host cpu map:
  CPU CORE L1d:L1i:L2:L3
    0    0 0:0:0:0
    1    1 1:1:1:0
    2    2 2:2:2:0
    3    3 3:3:3:0
    4    4 4:4:4:0
    5    5 5:5:5:0
    6    6 6:6:6:0
    7    7 7:7:7:0
    8    8 8:8:8:1
    9    9 9:9:9:1
   10   10 10:10:10:1
   11   11 11:11:11:1
   12   12 12:12:12:1
   13   13 13:13:13:1
   14   14 14:14:14:1
   15   15 15:15:15:1
   16    0 0:0:0:0
   17    1 1:1:1:0
   18    2 2:2:2:0
   19    3 3:3:3:0
   20    4 4:4:4:0
   21    5 5:5:5:0
   22    6 6:6:6:0
   23    7 7:7:7:0
   24    8 8:8:8:1
   25    9 9:9:9:1
   26   10 10:10:10:1
   27   11 11:11:11:1
   28   12 12:12:12:1
   29   13 13:13:13:1
   30   14 14:14:14:1
   31   15 15:15:15:1
winvm guest 192.168.122.111 (Ethernet), host 192.168.122.1 (virbr0), tap vnet541
  guest: Microsoft Windows NT 10.0.26100.0
  guest:
  guest:
  guest: Name                 : Ethernet
  guest: InterfaceDescription : Intel(R) 82574L Gigabit Network Connection
  guest: LinkSpeed            : 1 Gbps
  guest: MtuSize              : 1500
  guest: DriverVersionString  : 12.19.1.32
  guest:
  guest:
  guest:
  guest:
  guest:
  guest: NlMtu : 1500
  guest:
  guest:
  guest:
  guest:
  guest: DisplayName                      DisplayValue
  guest: -----------                      ------------
  guest: Flow Control                     Rx & Tx Enabled
  guest: Interrupt Moderation             Enabled
  guest: IPv4 Checksum Offload            Rx & Tx Enabled
  guest: Jumbo Packet                     Disabled
  guest: Large Send Offload V2 (IPv4)     Enabled
  guest: Large Send Offload V2 (IPv6)     Enabled
  guest: Maximum number of RSS Processors 8
  guest: Preferred NUMA node              65535
  guest: Maximum Number of RSS Queues     2 Queues
  guest: Packet Priority & VLAN           Packet Priority & VLAN Enabled
  guest: Receive Buffers                  2048
  guest: Receive Side Scaling             Enabled
  guest: RSS Base Processor Number        0
  guest: Maximum RSS Processor Number     63
  guest: RSS load balancing profile       NUMAScalingStatic
  guest: Speed & Duplex                   Auto Negotiation
  guest: TCP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: TCP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Transmit Buffers                 512
  guest: UDP Checksum Offload (IPv4)      Rx & Tx Enabled
  guest: UDP Checksum Offload (IPv6)      Rx & Tx Enabled
  guest: Adaptive Inter-Frame Spacing     Disabled
  guest: Interrupt Moderation Rate        Adaptive
  guest: Log Link State Event             Enabled
  guest: Gigabit Master Slave Mode        Auto Detect
  guest: Locally Administered Address
  guest: Wait for Link                    Auto Detect
  guest:
  guest:
  guest:
  guest: Querying active state...
  guest:
  guest: UDP Global Parameters
  guest: ----------------------------------------------
  guest: Receive Offload State               : enabled
  guest: Send Offload State                  : enabled
  guest:
  guest:
  guest:
  guest: ReceiveSideScaling           : Enabled
  guest: ReceiveSegmentCoalescing     : Enabled
  guest: Chimney                      : Disabled
  guest: TaskOffload                  : Enabled
  guest: NetworkDirect                : Enabled
  guest: NetworkDirectAcrossIPSubnets : Blocked
  guest: PacketCoalescingFilter       : Disabled
  guest:
  guest:
  guest:
```

`summary.txt`:

```text
medians over non-warm-up runs; cpu/GiB is CPU seconds per delivered GiB; lost packets per run: wire = sender if out - receiver if in, stack = receiver if in - UDP in, rcvbuf = full socket buffer
arm             n Mbit/s med    min    max  pkt/s med    loss cpu/GiB s      r     wire    stack   rcvbuf
binding         5        351    258    375      30175   0.00%     22.80   3.96        0        1        0
dgram           5        512    499    656      45814   0.00%     19.59   5.64        0        2        0
dgrampin        5        537    534    557      48046   0.00%     18.48   6.09        0       16        0
stream          5        547    535    560          0       -     17.66   5.30        0        2        0
streampin       5        546    525    555          0       -     18.02   5.25        0        2        0
udp             5        442    370    464      38019   0.00%     18.66   1.81        0        1        0
udp4            5        761    753    846      65531   0.00%     33.91   1.63        0        1        0

flagged runs (kept in the statistics; never dropped):
  r2-binding: rate 0.78x median
  r5-binding: rate 0.74x median
  r5-dgram: rate 1.28x median

extras (medians): sender member-queue drops; lost after the sender's member queue (member dequeued - receiver if in); receiver 16 KB cluster refill failures; receiver if in frames/s and bytes/frame; GC cycles/s per peer; -qdepth queued datagrams before each read (median, mean, share empty)
arm             q drop  after q  16k fail   in fr/s  B/frame  gc/s s  gc/s r             qdepth
binding              -        -         -         -        -     0.5    52.2                  -
dgram                -        -         -         -        -    54.4    28.6                  -
dgrampin             -        -         -         -        -     2.3     1.2                  -
stream               -        -         -         -        -     1.0     2.0                  -
streampin            -        -         -         -        -     0.1     0.1                  -
udp                  -        -         -         -        -     0.0     0.0                  -
udp4                 -        -         -         -        -     0.0     0.0                  -

sender CPU per offered packet (medians, min-max): user and system microseconds; share of each on performance cores
arm                       user us             sys us  user P   sys P
binding          3.89 (3.18-4.80) 26.94 (24.47-30.92)       -       -
dgram            3.07 (2.21-3.23) 22.42 (7.02-22.99)       -       -
dgrampin         2.91 (2.57-3.22) 21.08 (20.81-22.11)       -       -
udp              3.21 (2.89-3.75) 22.03 (21.05-24.14)       -       -
udp4             1.93 (1.51-2.17) 43.80 (13.76-45.38)       -       -

receiver per delivered datagram (medians; min-max for total CPU): receive call; CPU-s per delivered GiB, total, user, system; user and system microseconds per datagram; system share on performance cores; cycles per datagram; receive system calls per datagram (read and recvmsg: 1, a floor, as parked calls are not visible); recvmsg_x datagrams per delivering call (mean, median), share of calls that filled every slot, parked calls per delivering call
arm                   call         cpu/GiB r  user   sys user us sys us sys P  cyc/dg calls/dg      fill  full park/dc
udp                   read  1.81 (1.79-1.87)  0.73  1.08    0.99   1.47     -       -        1         -     -       -
udp4                  read  1.63 (1.62-1.65)  0.69  0.94    0.93   1.27     -       -        1         -     -       -

native readouts (medians; slice 3.1's seam): readouts mode; sender min, smoothed (at the end) and mean RTT over the send window (us); PTOs and spurious losses over the sender's window (recorder only); receiver packets received/s (ConnectionStats.PacketsReceived); receiver Datagram discards and unprocessed-queue drops at the end; runs with a missing snapshot. absent = no fork method, no recorder, or no snapshot
arm                mode  minRTT    sRTT  meanRTT   PTO  spur   r pkt/s  dg drop   unproc miss  env
dgram             stats     420    8779   absent absent absent     45637        0   absent    0  -
dgrampin          stats     432    8352   absent absent absent     47860        0   absent    0  -
stream            stats     359   15046   absent absent absent     49087        0   absent    0  -
streampin         stats     444   10771   absent absent absent     49011        0   absent    0  -

native extra counts (medians of each peer's total at its final snapshot; counts a scratch build adds to 3.1's Readout)
binding        recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
dgram          recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
dgrampin       recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
stream         recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
streampin      recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
udp            recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
udp4           recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
```
