# Pinned independent-control recipes

These recipes implement the approved independent-control accounting in [S1](../work-items/1463-reliable-stream-workload.md), [T1](../work-items/1455-gridcast-datagram-workload.md) and the [shared preparation plan](../work-items/qualification-preparation.md). They are prepared commands, not executed qualification evidence. Native interval accounting, physical routing, process custody and report export must pass the finite readiness check at each venue before its controls are counted complete.

## Tool identity

Linux/macOS pairs use unmodified iperf3 3.21, built from the retained ESnet source with `--without-openssl --disable-shared`. The retained `iperf-3.21.tar.gz` source archive has SHA-256 `656e4405ebd620121de7ceca3eaf43a88f79ea1b857d041a6a0b1314801acdd8`. The identified Darwin arm64 executable has SHA-256 `5e3b75c63462876334a048d4e7f945a6ff28a8bd68333ebe6a119a0a1015c427`; the identified Linux amd64 executable has `3e2d13d684c47960d0405566302fbbf955d370e08045411a7b8f80062014d339`. Disabling OpenSSL affects independent iperf control authentication, not wiremux transport security. Use existing authenticated process dispatch and reserved, explicitly bound private endpoints.

Windows comparisons use iperf2 2.2.1 at both ends. The retained Windows amd64 executable has SHA-256 `96ddcf44d769c2a043faaf458b4d8703d968fde9bda68b0b8f540218f7f822fc`; the identified Darwin arm64 executable has `60d5b3d170571bb402ffa3702e37dce44fa2428630f18d8975a1b14201f9c9b3`. The retained upstream 2.2.1 source archive has `754ab0a7e28033dbea81308ef424bc7df4d6e2fe31b60cc536b61b51fefbd8fb`. Recheck deployed hashes and both native `--version` outputs at execution. Tool generations cannot be mixed within a pair. Native Windows readiness executions use the admitted disposable guest; each retained receipt must include an integer exit status.

## iperf3 3.21

The driver substitutes the manifest's absolute executable path, source/destination addresses, one run-owned unused port and capture ID. Bind both peers explicitly. Run one foreground server for one client; retain separate stdout/stderr and exit status from each process. The examples are argument recipes, not shell commands to run with unset variables.

```sh
"$IPERF3" -s -1 -B "$SERVER_IP" -p "$PORT" -J --idle-timeout 5 --server-max-duration 40
"$IPERF3" -c "$SERVER_IP" -B "$CLIENT_IP" -p "$PORT" -J -i 1 -O 0 -t 40 --connect-timeout 3000 --get-server-output --extra-data "$CAPTURE_ID"
```

For a UDP control, append `-u -b "$RATE_BPS" -l 1071 --udp-counters-64bit` to the client. `RATE_BPS` is exactly 8000000000 for the fixed row and 10000000000 on Ethernet or 40000000000 on Thunderbolt for H. `-l 1071` selects the total application UDP buffer, including iperf's metadata; verify actual socket datagram size in the approved readiness check. Leave GSO/GRO and socket-buffer options at the pinned tool defaults, record them and retain the tool's native attempted/sent/received distinction. UDP is a diagnostic packet-rate reference with intentional overload possible at H.

The client performs forty seconds of continuous active traffic without the native omission reset. Live 3.21 UDP and Thunderbolt TCP reports exposed malformed first non-omitted intervals with the reset enabled, including a start later than its end and counters spanning inconsistent durations. Preserve those failures; do not repair them by subtracting final summaries. Select the native interval boundary nearest elapsed ten seconds and retain every contiguous interval through the native end near forty seconds. Both selected endpoints must be within 100 ms of the requested boundaries; retain actual boundaries, duration and deviation separately for each peer. The first ten seconds of native intervals remain warmup evidence. This native control timing tolerance is independent of wiremux's one-millisecond boundary gate. Each endpoint's bytes and packet counters come from its selected intervals; final native summaries remain separate. The parser still accepts intact historical native-omission reports and rejects malformed, overlapping or truncated data.

The client control connection must reach the one-off server within its five-second `--idle-timeout 5` setup interval. The pinned server may exit zero without a normal JSON report when that interval expires. Retain this as a missing-report setup failure; exit zero alone is never a control result. Do not extend the timeout or consume an unrecorded retry to conceal the failure.

The driver allows at most ten seconds after measurement for stream controls and five seconds for Datagram-program controls, including native final exchange and process termination. Setup/readiness wait is separately bounded. `--server-max-duration 40` limits the requested active duration; it is not a process lifetime guarantee. The run owner enforces the outer deadline, closes only its owned processes on expiry and retains timeout/truncation. There is no post-test idle sleep or finite-record drain claim. Reverse data direction using the manifest's reversed sender/receiver or the pinned tool's `-R`, recording the chosen connection roles and routes.

## iperf2 2.2.1

Use one connection, enhanced CSV interval reports and UTC timestamps at both endpoints. The driver binds and supervises each foreground process, captures both stdout/stderr and preserves the complete report without assuming Windows and Darwin text line endings match.

```sh
"$IPERF2" -s -B "$SERVER_IP" -p "$PORT" -e -y C -i 1 --utc -t 50
"$IPERF2" -c "$SERVER_IP" -B "$CLIENT_IP" -p "$PORT" -e -y C -i 1 --utc -t 40
```

For a UDP control, append `-u -l 1071` to both invocations and `-b "$RATE_BPS"` to the client. The Windows path uses 8000000000 and 10000000000 bit/s. Preserve the native UDP final exchange; do not use `--no-udp-fin`, `--ignore-shutdown`, file input or compatibility mode. Upstream `Client.cpp` writes the configured UDP buffer length, with identifiers inside that buffer. Upstream `Reporter.c` owns interval byte counts, native loss adjustments and out-of-order accounting; these are not wiremux's finite-cohort deficit union.

iperf2 has no native omission option in this pin. Its forty seconds are all active traffic. Parse CSV through a CSV library and retain rows for the chosen connection/direction. Select the complete contiguous one-second intervals covering native elapsed [10,40], separately at each endpoint; retain [0,10] as warmup and the final [0,40] aggregate separately. Require actual interval boundaries, bytes and duration. For UDP also require interval packet and loss counters, attempted-rate/write-error evidence where provided, and a recorded interpretation of out-of-order adjustments. Do not subtract a rounded human-readable headline, infer delivery from link speed, substitute aggregate loss for measurement-window loss or invent unavailable attempted counters.

The server's `-t 50` is a safety ceiling spanning setup and traffic, not a requested extra measurement period or the driver shutdown allowance. The owner terminates the run-owned server once the native report exchange completes, or at the relevant five/ten-second post-measurement deadline. The server/client may report different elapsed endpoints; retain both and classify missing, overlapping, truncated or unsplittable intervals as unqualified. Native execution must establish that this pin emits the required canonical report fields on Windows. If it does not, stop that control at the existing tool-capability boundary and specify an equivalent before further captures.

## Evidence and counts

Each control receipt binds program, scenario, physical path, data direction, repetition, capture ID, exact argv/environment, source/binary versions and hashes, process identity, routes/interfaces/MTU, both native reports, interval selection, native shutdown duration, timeout/truncation and artifact hashes. Record shared-host contention; controls performed only for readiness are never promoted into qualification captures. Stream retains 18 TCP controls. Datagram retains 54 controls across TCP, UDP/8 Gbps and UDP/H. No recipe changes the five reliable-stream comparison layers, the Datagram QUIC workload, their targets or finite-cohort drain semantics.

Windows native supervisors inspect the exact owned PID and bound port using `netstat.exe -ano`; the non-admin session does not have CIM access. Normal stop and cancellation use a run-owned marker under the native output directory, delivered over the authenticated session channel. A redirected PowerShell stdin reader did not react reliably to the stop message in the live guest; the marker supplies an explicit bounded control path. The worker retains whether the marker requested normal stop or interruption and joins its process before reporting.
