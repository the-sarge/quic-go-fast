# Restricted-NAT release environment for wiremux v0.1.0

Research for
[Research a repeatable restricted-NAT release environment](https://github.com/GridSwarm/wiremux/issues/775),
under
[Define the private wiremux v0.1.0 release plan](https://github.com/GridSwarm/wiremux/issues/767).
Sources and repository coverage were reviewed on 2026-07-14.

## Decision answer

Use two complementary release-evidence layers:

1. Make a behavior-parametric, in-process IPv4 NAT fabric the deterministic
   release gate. Evolve the existing integration harness rather than creating a
   separate product or release service. It should model mapping and filtering
   independently, run the real STUN client/server, authenticated probe engine,
   synchronized relay fallback, QUIC transport, and root `wiremux.Dial`, and
   assert the NAT behavior it actually applied.
2. Add a Linux-only network-namespace smoke to release-candidate validation.
   Run real processes and sockets through `veth` links and explicit `nftables`
   rules for one restricted direct-success case and one endpoint-dependent
   fallback case. Treat the observed mapping/filter behavior as evidence;
   never label plain `MASQUERADE` as an RFC behavior oracle.

This is enough to demonstrate representative restricted-NAT success and safe
fallback for v0.1.0. It does not demonstrate universal hole-punch success, a
deployed-NAT success rate, or a TURN-like path. Direct failure continues over
wiremux's already-established reliable relay stream.

Use RFC 4787's separate mapping and filtering terms in test names and release
evidence. The older full-cone, restricted-cone, port-restricted-cone, and
symmetric labels combine independent properties and are explicitly described
as inadequate for real NAT behavior
([RFC 4787 §4.1](https://www.rfc-editor.org/rfc/rfc4787.html#section-4.1),
[§5](https://www.rfc-editor.org/rfc/rfc4787.html#section-5)). RFC 7659 maps
those legacy names to the separate axes
([RFC 7659 §5.2](https://www.rfc-editor.org/rfc/rfc7659.html#section-5.2)).
Legacy names can appear parenthetically for operator recognition, but must not
be the asserted behavior.

Matrix shorthand below uses EIM, ADM, and APDM for endpoint-independent,
address-dependent, and address-and-port-dependent mapping; it uses EIF, ADF,
and APDF for the corresponding filtering behaviors.

## Current executable coverage

### NAT and production matrix coverage

- The current [`natFabric`](../../internal/integration/restricted_nat_fabric_helpers_test.go) independently models EIM, ADM, or APDM external mappings and EIF, ADF, or APDF inbound permission keys while recording mapping, permission, delivery, filtering, blackhole, and unexplained-drop state.
- `TestRestrictedNATMatrixRows` in [`restricted_nat_fabric_test.go`](../../internal/integration/restricted_nat_fabric_test.go) self-characterizes every applicable declared profile with three observers on isolated state, then runs the exact nine controlled rows through production relay and STUN, root `wiremux.Dial`, authenticated probes, exact sockets, real QUIC where direct, synchronized `probe_failed` fallback, and bidirectional payload. `TestRestrictedNATMatrixUsesFullyIsolatedState` proves row, characterization, scheduler, and socket state do not leak across the maintained matrix.
- The root-Dial tests in
  [`consumer_upgrade_test.go`](../../internal/integration/consumer_upgrade_test.go)
  exercise real relay-to-direct QUIC, consumer channel shapes, selected-pair
  convergence, application payloads, and transferred socket identity over
  loopback with STUN disabled. They prove the root orchestration, not NAT
  behavior.

### Candidate, STUN, and authenticated-probe coverage

- [`gather_test.go`](../../connect/gather_test.go) covers explicit and wildcard
  host candidates, STUN reflexive candidates, deduplication, address-family
  constraints, candidate absence, best-effort STUN failure, timeout, and
  cancellation. [`stun/stun_test.go`](../../stun/stun_test.go) covers the
  repository's Binding client and responder. The responder returns the
  observed address; it is not an RFC 5780 multi-address behavior-discovery
  service.
- [`probe_test.go`](../../connect/probe_test.go) covers the nonce-derived key,
  candidate-pair token, HMAC-authenticated request/response transcript, and
  rejection when the packet's observed source does not exactly equal the
  offered source candidate. [`probe_engine_test.go`](../../connect/probe_engine_test.go)
  covers pair ordering and policy, concurrent attempts, retries, delayed
  responses, wrong IDs, recoverable writes, and preferred-pair selection.

### Synchronized fallback coverage

- `TestNegotiatorUpgradeNoPacketConnSynchronizesRelayFallback`,
  `TestNegotiatorUpgradeFirstPhaseFallbackReasonConvergesAsymmetrically`, and
  `TestNegotiatorUpgradeProbeFailureFallsBackToRelay` in
  [`negotiator_test.go`](../../connect/negotiator_test.go) prove pairwise reason
  settlement and continued relay payload use. The probe-failure case makes
  both sides send UDP probes to unreachable advertised host candidates, then
  converges on `probe_failed`; it is not generated by a NAT mapping or filter.
- [`upgrade_fallback_test.go`](../../connect/upgrade_fallback_test.go) pins the
  first-phase and terminal precedence matrices and symmetric resolution.
  [`upgrade_terminal_fallback_test.go`](../../connect/upgrade_terminal_fallback_test.go)
  covers commit/fallback sequencing, cancellation of an active probe when the
  peer falls back, selected-pair replay, and related races.
- Root tests in [`wiremux_test.go`](../../wiremux_test.go) prove that a
  caller-owned packet connection remains open on relay fallback, a transferred
  connection closes before fallback returns, an internally owned connection
  closes, and the returned relay Wires remain bidirectionally usable. Those
  cases force one side to be relay-only; they do not exercise restricted NAT.

The deterministic in-process matrix covers restricted-NAT mapping and post-STUN-blackhole fallback. The privileged `task nat-smoke-linux` lane complements it with fresh Linux namespaces, veth links, explicit nftables SNAT/filter rules, and conntrack state for EIM+APDF direct and APDM+APDF fallback; three public observers self-characterize each peer before the production Wire execution, and the weekly and release workflows retain the exact two-row kernel evidence artifact.

### Focused verification run

The installed base toolchain was `go1.26.5 darwin/arm64`. These focused current coverage checks passed on 2026-08-01; they are evidence for this inventory, not a substitute for `task verify` or the complete restricted-NAT release lane:

```bash
GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -run '^(TestNATFabricAccountsUnroutedAndOverflowDrops|TestRestrictedNATMatrixRows|TestRestrictedNATMatrixUsesFullyIsolatedState)$' -count=1 ./internal/integration
GOTOOLCHAIN=local go test ./connect \
  -run '^(TestGatherReturnsReflexiveCandidateFromSTUN|TestProbePairsRetriesAndRequiresMatchingProbeResponseID|TestNegotiatorUpgradeNoPacketConnSynchronizesRelayFallback|TestNegotiatorUpgradeFirstPhaseFallbackReasonConvergesAsymmetrically|TestNegotiatorUpgradeFallsBackToRelayOnDirectSetupFailures|TestNegotiatorUpgradeProbeFailureFallsBackToRelay|TestResolveFallbackReasonFirstPhaseConvergesSymmetrically|TestResolveFallbackReasonTerminalConvergesSymmetrically|TestProbeCandidatePairsWithTerminalFallbackStopsActiveProbeWhenPeerFallbackArrives)$' \
  -count=1
```

## Why endpoint-dependent mapping should fall back

RFC 4787 defines endpoint-independent mapping (EIM), address-dependent mapping
(ADM), and address-and-port-dependent mapping (APDM) independently from its
three filtering behaviors
([RFC 4787 §4.1](https://www.rfc-editor.org/rfc/rfc4787.html#section-4.1),
[§5](https://www.rfc-editor.org/rfc/rfc4787.html#section-5)). RFC 5128 explains
that ordinary UDP hole punching relies on EIM: when a NAT creates a different
mapping for the peer destination, the peer cannot predict the mapped endpoint
learned through the rendezvous/STUN destination
([RFC 5128 §3.3](https://www.rfc-editor.org/rfc/rfc5128.html#section-3.3),
[§5.2](https://www.rfc-editor.org/rfc/rfc5128.html#section-5.2)).

wiremux adds a deterministic security outcome. `probeObservedSourceMatches` in
[`connect/probe.go`](../../connect/probe.go) requires the observed source IP and
port to equal the authenticated offered candidate. If an ADM or APDM fabric
advertises the STUN mapping but emits a peer-directed probe from another
mapping, the receiver rejects that packet before selecting a pair. This is an
inference from the RFC mapping definition and the current source: with private
host candidates isolated and no other valid pair, both probes should exhaust
and the terminal exchange should settle `probe_failed` on the relay path.

This is desirable for v0.1.0. Accepting the unexpected mapping as a new
peer-reflexive candidate would be a protocol and security change, not test-lab
work.

## Feasible environments

| Option | Strengths | Limits | Verdict |
| --- | --- | --- | --- |
| Extend wiremux's in-process harness | Already accepts the exact `net.PacketConn` used by STUN, probes, and QUIC; deterministic; cross-platform; no privileged setup or new runtime component; can expose exact mapping/filter/drop counters. | It is a model, not a kernel or appliance. The model itself needs conformance tests against declared behaviors. | **Recommended semantic gate.** |
| Pion `transport/vnet` v4.0.2 | Its public `NATType` independently selects endpoint-independent, address-dependent, or address-and-port-dependent mapping and filtering, and its virtual socket is usable as `net.PacketConn` ([source](https://github.com/pion/transport/blob/v4.0.2/vnet/nat.go), [README](https://github.com/pion/transport/blob/v4.0.2/vnet/README.md)). | IPv4 only; hairpinning and port preservation are marked unimplemented; adds test dependencies and adaptation around wiremux's existing harness. | Credible fallback if extending the local harness becomes larger than expected; also a useful behavioral reference. |
| Tailscale NATLab | Runs in memory without root and has production-motivated `easy` EIM/address-and-port-filtered, `easyaf` EIM/address-filtered, and `hard` endpoint-dependent models ([framework](https://github.com/tailscale/tailscale/blob/318807bdb9b96c59f2499e39028723c38df30850/tstest/natlab/natlab.go), [NAT tables](https://github.com/tailscale/tailscale/blob/318807bdb9b96c59f2499e39028723c38df30850/tstest/natlab/vnet/nat.go)). | It does not expose the full independent RFC matrix, its lightweight packet connection panics on deadline methods wiremux probing requires ([source](https://github.com/tailscale/tailscale/blob/318807bdb9b96c59f2499e39028723c38df30850/tstest/natlab/natlab.go#L794-L802)), and importing it would bring a much larger dependency surface. | Reference implementation, not the v0.1.0 dependency choice. |
| Linux network namespaces plus `nftables` | Exercises real UDP sockets, routing, conntrack, and the packaged server. Upstream Linux NAT self-tests themselves build namespace/veth topologies and apply nft rules ([Linux `nft_nat.sh`](https://github.com/torvalds/linux/blob/3b029c035b34bbc693405ddf759f0e9b920c27f1/tools/testing/selftests/net/netfilter/nft_nat.sh)). Standard GitHub-hosted Linux VMs provide passwordless `sudo` ([GitHub runner reference](https://docs.github.com/en/actions/reference/runners/github-hosted-runners#administrative-privileges)). | Linux-only and privileged; requires `ip`, `nft`, cleanup traps, and explicit behavior validation. NAT chains create conntrack state from the first packet, and upstream source can change a preferred source tuple when uniqueness requires it, so plain masquerade names an implementation mechanism, not an RFC mapping/filter classification ([nftables man page](https://netfilter.org/projects/nftables/manpage.html#CHAINS), [kernel source](https://github.com/torvalds/linux/blob/3b029c035b34bbc693405ddf759f0e9b920c27f1/net/netfilter/nf_nat_core.c#L682-L748)). | **Recommended release-candidate smoke, not the sole semantic oracle.** |
| Physical routers, cloud NATs, or live Internet probes | Observes deployed devices. | Configuration and firmware drift, shared state, port reuse, load, and upstream NATs make results hard to reproduce or attribute. | Supplemental diagnostics only; never a release gate. |

RFC 5780 reinforces the last limitation: NAT behavior discovery is an
instantaneous observation, behavior may become more restrictive under load or
over time, and results can vary by source port
([RFC 5780 §2](https://www.rfc-editor.org/rfc/rfc5780.html#section-2),
[§4](https://www.rfc-editor.org/rfc/rfc5780.html#section-4)). Its alternate
address/port tests are useful for validating a lab profile
([mapping](https://www.rfc-editor.org/rfc/rfc5780.html#section-4.3),
[filtering](https://www.rfc-editor.org/rfc/rfc5780.html#section-4.4)); they do
not justify predicting every later flow through a real device.

## Recommended environment shape

### Deterministic semantic gate

Generalize the current harness around two independent enums:

- mapping key: internal endpoint only (EIM), internal endpoint plus remote IP
  (ADM), or internal endpoint plus remote IP and port (APDM);
- inbound permission key: none after a mapping exists (endpoint-independent
  filtering), remote IP (address-dependent filtering), or remote IP and port
  (address-and-port-dependent filtering).

Each test profile should first prove the harness declaration with three public
observers: two ports on one address and one port on another address. Record the
external source chosen for each outbound tuple, then inject inbound packets
from same-address/different-port and different-address observers to prove the
filter. Do this on fresh sockets so old permissions cannot contaminate a row.

For the wiremux run, provide two isolated private realms, one NAT instance per
peer, a public STUN responder, and the existing production relay. Restrict the
initial matrix to reflexive candidates so private host-candidate routing cannot
accidentally turn a NAT test into a LAN test. Run both peers through root
`wiremux.Dial` with real QUIC and the same packet socket used for STUN. Capture
the mapping chosen for each STUN/probe/QUIC write, filter drops, authenticated
probe reads/writes, selected pairs, path metadata, and application payloads.

Do not add a UDP relay, TURN server, `CandidateKindRelay` probing, or a
simulator-specific bypass. The only fallback carrier in these tests is the
reliable relay stream that rendezvoused the peers before probing.

### Kernel-realism smoke

Create public, left-router, left-client, right-router, and right-client Linux
namespaces linked with `veth` pairs. Run relay/STUN on the public side and one
wiremux peer in each client namespace. Use explicit SNAT port choices and
inbound filter rules rather than relying on the allocator behind
`MASQUERADE`. Before invoking wiremux, use the same observer arrangement as the
in-process harness to record the effective mapping/filter behavior.

Create fresh namespaces for each row so conntrack entries and dynamic filter
permissions cannot leak between profiles. Launch ordinary peer and server
subprocesses with `ip netns exec`; do not add Go thread-affinity/setns logic to
wiremux. Use a full `ubuntu-latest` VM, not the unprivileged `ubuntu-slim`
container described in the GitHub runner reference above.

Mirror only two high-value rows here: EIM plus address-and-port-dependent
filtering must reach direct QUIC after simultaneous authenticated probes, and
APDM plus address-and-port-dependent filtering must converge on usable relay
fallback. Run this lane during release-candidate validation (and optionally on
a schedule), while the pure-Go matrix remains the ordinary deterministic gate.

## Recommended evidence matrix

All NAT rows use distinct private realms and reflexive-only candidates. “Same”
or “different” mapping is an observed precondition, not trust in a profile
name.

| Profile | Required lab precondition | Expected wiremux outcome | Required evidence | Lane |
| --- | --- | --- | --- | --- |
| Public/host baseline | No NAT translation | Direct | Existing selected-pair convergence, exact socket handoff, real QUIC, bidirectional payload | Existing integration gate |
| EIM + endpoint-independent filtering (“full-cone-style”) on both peers | One external mapping across all observer tuples; inbound from both fresh observers is admitted | Direct | Reflexive candidates selected on both roles; authenticated probe traffic; real QUIC payload; zero unexplained drops | Existing coverage, strengthened by profile self-test |
| EIM + address-dependent filtering (“restricted-cone-style”) on both peers | Mapping is stable; fresh source IP is dropped until outbound traffic to that IP; source port is irrelevant | Direct | Initial filter drops are permitted; retries open both address permissions; selected pairs converge; QUIC payload succeeds | New deterministic matrix |
| EIM + address-and-port-dependent filtering (“port-restricted-cone-style”) on both peers | Mapping is stable; fresh source tuple is dropped until outbound traffic to that exact tuple | Direct | At least one permission-opening outbound probe per side; any raced first packet is accounted for; retry succeeds; QUIC payload succeeds | New deterministic matrix and Linux smoke |
| ADM + endpoint-independent filtering | Same external mapping for two ports on one observer IP, different mapping for another IP; inbound is admitted without prior permission | Relay with synchronized `probe_failed` | Peer-directed source differs from the advertised STUN candidate; zero filtering drops; both Wires report relay and exchange payload | New deterministic matrix |
| ADM + address-and-port-dependent filtering | Same external mapping for two ports on one observer IP, different mapping for another IP | Relay with synchronized `probe_failed` | Peer-directed source differs from advertised STUN candidate; mismatched probes are rejected/accounted for; both Wires report relay and exchange payload | New deterministic matrix |
| APDM + address-and-port-dependent filtering (“symmetric-like”) | A different external mapping for each observer IP:port tuple | Relay with synchronized `probe_failed` | Same fallback assertions as ADM; no selected pair and no direct transport exposure | New deterministic matrix and Linux smoke |
| Asymmetric EIM/APDF versus APDM/APDF | Each side independently satisfies its declared behavior | Relay with synchronized `probe_failed` | Both peers settle the same reason despite different local observations; relay payload remains usable in both directions | New deterministic matrix |
| UDP blackhole after successful STUN | STUN mapping is observed, then all peer UDP is dropped | Relay with synchronized `probe_failed` | Both sides exhaust bounded authenticated probes, clear packet deadlines, and continue over relay | Existing logical fallback plus new fabric row |

For every relay row, assert `Wire.Direct() == false`, `Info().Path` is relay,
both roles expose the same `probe_failed` reason, no selected pair is published,
and bidirectional reliable payload succeeds. For every direct row, assert the
reverse selected-pair invariant, exact supplied-socket reuse, positive probe
RTT, real QUIC in both directions, and relay retirement only after convergence.

## Limits and non-claims

- The matrix is representative, not exhaustive. It does not cover every one of
  the nine mapping/filter combinations, IP address pooling, port exhaustion,
  cascaded/CGNAT topologies, hairpinning, mapping expiry/rebinding, ALGs,
  fragmentation, NAT64, or IPv6 firewall policy.
- A successful EIM/restricted-filter row proves the current synchronized probe
  schedule works in that controlled topology. It does not promise success on
  all devices that an operator might give the same legacy label.
- An ADM/APDM fallback is evidence that v0.1.0 fails safely with its current
  authenticated-candidate contract. It is not a commitment to port prediction,
  peer-reflexive candidate learning, or future traversal algorithms.
- The Linux lane proves a representative kernel/socket path, not that Linux
  masquerade universally behaves like the chosen profile. The precondition
  observations are part of the evidence and must fail the test if the effective
  behavior differs.
- No release assertion should convert a transient live-network observation
  into a permanent NAT classification. Release notes should say which
  controlled profiles were exercised and whether wiremux selected direct or
  synchronized relay fallback.
