from pathlib import Path
import json,hashlib,subprocess
w=Path.cwd();c=w/'.cache/e02-d';f=c/'fork-source';out=c/'overlay';out.mkdir(exist_ok=True)
replace={};hashes={}
expected=json.loads((c/'expected-source-hashes.json').read_text())
def put(src,txt):
 name=hashlib.sha256(str(src).encode()).hexdigest()[:12]+'-'+src.name
 target=out/name;target.write_text(txt);replace[str(src)]=str(target)
def patch(base,name,pairs):
 src=base/name;txt=src.read_text();hashes[str(src)] = hashlib.sha256(txt.encode()).hexdigest()
 key=('fork:' if base==f else 'wiremux:')+name
 if expected[key]!=hashes[str(src)]: raise Exception('frozen source hash mismatch: '+key)
 for old,new in pairs:
  count=txt.count(old)
  if count!=1:raise Exception((name,old[:100],count))
  txt=txt.replace(old,new,1)
 put(src,txt)
put(f/'e02_observer.go',(c/'e02_observer.go.txt').read_text())
put(w/'internal/measurement/e02_observation.go',(c/'e02_measurement.go.txt').read_text())
patch(f,'transport.go',[('type Transport struct {','type Transport struct {\n e02slot *e02Slot')])
patch(f,'external_packet_io.go',[
 ('return newUDPBatchWriter(conn), nil','return newUDPBatchWriter(conn, t.e02slot), nil'),
 ('func ordinaryUDPBatchWriter(conn udpMessageWriter)', 'func ordinaryUDPBatchWriter(conn udpMessageWriter, slots ...*e02Slot)'),
 ('\t\tfor i, buf := range bufs {\n\t\t\tn, oobn, err := conn.WriteMsgUDP(buf, oob, addr)', '\t\tfor i, buf := range bufs {\n var slot *e02Slot; if len(slots)>0 {slot=slots[0]}; eo, at:=e02Start(slot)\n\t\t\tn, oobn, err := conn.WriteMsgUDP(buf, oob, addr)\n eo.ordinary(at,n,len(buf),err)'),
 ('\tl.lease.quic = true','\tl.lease.quic = true\n e.e02slot.bind(t.e02slot.get(), "managed")'),
 ('\treturn &externalPacketConn{rawConn: conn, config: c}','\tswitch raw:=conn.(type){case *basicConn:raw.e02slot=t.e02slot;case *oobConn:raw.e02slot=t.e02slot}\n\treturn &externalPacketConn{rawConn: conn, config: c}')])
patch(f,'managed_packet_endpoint.go',[
 ('e := &managedPacketEndpoint{conn: conn, buffers: inspectManagedBuffers(conn, receiveErr, sendErr)}','e := &managedPacketEndpoint{conn: conn, buffers: inspectManagedBuffers(conn, receiveErr, sendErr), e02slot: &e02Slot{}}'),
 ('e.sendBatch = newUDPBatchWriter(socket)','e.sendBatch = newUDPBatchWriter(socket, e.e02slot)'),
 ('type managedPacketEndpoint struct {','type managedPacketEndpoint struct {\n e02slot *e02Slot')])
patch(f,'send_conn_sendmsg_x_darwin.go',[
 ('type darwinBatch struct {','type darwinBatch struct {\n e02slot *e02Slot'),
 ('\t\taccepted, submitErr = sendmsgXSubmit(int(fd), bufs, bs.dest.name(), bs.dest.namelen, oob, msgs, iovs)','\t\teo, at := e02Start(bs.e02slot)\n\t\taccepted, submitErr = sendmsgXSubmit(int(fd), bufs, bs.dest.name(), bs.dest.namelen, oob, msgs, iovs)\n eo.native(at,fd,len(bufs),accepted,submitErr)'),
 ('func newUDPBatchWriter(conn udpMessageWriter)', 'func newUDPBatchWriter(conn udpMessageWriter, slots ...*e02Slot)'),
 ('fallback := ordinaryUDPBatchWriter(conn)', 'var slot *e02Slot; if len(slots)>0 {slot=slots[0]}\n fallback := ordinaryUDPBatchWriter(conn,slot)'),
 ('bs := &darwinBatch{raw: raw}','bs := &darwinBatch{raw: raw,e02slot:slot}')])
patch(f,'sys_conn.go',[
 ('type basicConn struct {','type basicConn struct {\n e02slot *e02Slot'),
 ('\treturn c.WriteTo(b, addr)','\teo,at:=e02Start(c.e02slot)\n n,err=c.WriteTo(b,addr)\n eo.ordinary(at,n,len(b),err)\n return n,err')])
patch(f,'sys_conn_oob.go',[
 ('type oobConn struct {','type oobConn struct {\n e02slot *e02Slot'),
 ('\tn, _, err := c.WriteMsgUDP(b, oob, addr.(*net.UDPAddr))','\teo,at:=e02Start(c.e02slot)\n\tn, _, err := c.WriteMsgUDP(b, oob, addr.(*net.UDPAddr))\n eo.ordinary(at,n,len(b),err)')])
patch(w,'transport/quic/transport.go',[
 ('\treturn &session{','\tsessionCtx = quicgo.E02Context(sessionCtx,quicgo.E02FromContext(ctx))\n\treturn &session{'),
 ('adapter.NewQUICTransport(conn, remote, s.packetPermission)','adapter.NewQUICTransport(conn, remote, s.packetPermission,quicgo.E02FromContext(s.ctx))')])
patch(w,'transport/internal/adapter/packet_permission.go',[
 ('grant packetpermission.Grant)', 'grant packetpermission.Grant, observers ...*quicgo.E02Observation)'),
 ('\ttransport := &quicgo.Transport{Conn: selected}','\ttransport := &quicgo.Transport{Conn: selected}\n if len(observers)>0 {transport.E02Attach(observers[0],conn.LocalAddr().String(),remote.String(),fmt.Sprintf("%T",selected))}'),
 ('\t\ttransport.Conn = selected','\t\ttransport.Conn = selected\n if len(observers)>0 {transport.E02Attach(observers[0],conn.LocalAddr().String(),remote.String(),fmt.Sprintf("%T",selected))}')])
patch(w,'internal/measurement/profile.go',[
 ('type profiler struct {','type profiler struct {\n e02 *quicgo.E02Observation'),
 ('func (p *profiler) setWindow(w phaseWindow) {','func (p *profiler) setWindow(w phaseWindow) {\n p.e02.Window(w.start,w.end)'),
 ('\tcaptures := make([]Capture, 0, len(p.files))','\tp.e02Finish()\n\tcaptures := make([]Capture, 0, len(p.files))'),
 ('\t\tcaptures = append(captures, m)','\t\tif m.Kind=="e02-packet-io.json" {m.Scope="E02-D exact-source observer sidecar; see internal monotonic window and attribution; post-window artifact write"}\n\t\tcaptures = append(captures, m)')])
patch(w,'internal/measurement/comparison_transport.go',[
 ('func (p *comparisonSetup) establishQUIC(ctx context.Context, h hello, pr *profiler) (*comparisonEndpoint, TransportInfo, error) {','func (p *comparisonSetup) establishQUIC(ctx context.Context, h hello, pr *profiler) (*comparisonEndpoint, TransportInfo, error) {\n if p.boot.Config.Layer=="wire" {ctx=pr.e02Context(ctx)}')])
patch(w,'internal/measurement/transport.go',[
 ('\t\treturn p.wire(ctx, info)','\t\treturn p.wire(pr.e02Context(ctx), info)')])
patch(w,'internal/measurement/controller.go',[
 ('validateRemoteCaptures(c, response.Result.Captures)','validateRemoteCaptures(c, response.Result.Captures, e02Expected(remote.Endpoints[i].Binary))')])
patch(w,'internal/measurement/remote.go',[
 ('func validateRemoteCaptures(c Config, captures []Capture) error {','func validateRemoteCaptures(c Config, captures []Capture, observed ...bool) error {'),
 ('\tif len(captures) != len(kinds) {','\tif c.Layer=="wire" && c.Connections==1 && len(observed)>0 && observed[0] {kinds=append(kinds,"e02-packet-io.json")}\n\tif len(captures) != len(kinds) {')])
put(w/'internal/integration/e02_observation_test.go',(c/'e02_managed_test.go.txt').read_text())
(c/'overlay.json').write_text(json.dumps({'Replace':replace},indent=2)+'\n')
(c/'overlay-source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
subprocess.run(['gofmt','-w',*replace.values()],check=True)
print('overlay files:',len(replace))
