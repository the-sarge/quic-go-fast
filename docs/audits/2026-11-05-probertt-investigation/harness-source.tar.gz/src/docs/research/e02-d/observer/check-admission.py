import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); mode=sys.argv[2]
x=json.loads((root/'result.json').read_text())
assert x['status']=='complete',x['status']
seen={}
for peer in x['peers']:
    captures=[c for c in peer['captures'] if c['kind']=='e02-packet-io.json']
    assert len(captures)==1, f"{peer['role']}: missing unique full-Wire packet observation"
    c=captures[0]; raw=(root/c['file']).read_bytes()
    assert not c['error'] if 'error' in c else True
    assert not c['truncated'] and hashlib.sha256(raw).hexdigest()==c['sha256']
    v=json.loads(raw); assert v['run_id']==x['run_id'] and v['role']==peer['role']
    assert v['binding']['local'] and v['binding']['remote'] and v['binding']['wrapper']
    seen[peer['role']]=v
assert seen['send']['counts']['ordinary_calls']>0
if mode=='enabled':
    assert seen['send']['counts']['native_multi_calls']>0, 'sender: no actual multi-message native submission'
    assert seen['send']['counts']['native_accepted']>0
else:
    assert all(v['counts']['native_calls']==0 for v in seen.values())
print(json.dumps({r:v['counts'] for r,v in seen.items()},indent=2))
