module github.com/GridSwarm/wiremux

go 1.27

toolchain go1.27.1

require (
	github.com/fxamacker/cbor/v2 v2.9.3
	github.com/letsencrypt/pebble/v2 v2.10.1
	github.com/miekg/dns v1.1.73
	github.com/pion/transport/v4 v4.1.0
	github.com/quic-go/quic-go v0.62.0
	github.com/santhosh-tekuri/jsonschema/v6 v6.0.3
	github.com/the-sarge/turn/v5 v5.3.0-gs.1
	golang.org/x/crypto v0.57.0
	golang.org/x/net v0.59.0
)

require (
	github.com/go-jose/go-jose/v4 v4.1.4 // indirect
	github.com/letsencrypt/challtestsrv v1.4.2 // indirect
	github.com/pion/dtls/v3 v3.1.4 // indirect
	github.com/pion/logging v0.2.4 // indirect
	github.com/pion/stun/v3 v3.1.6 // indirect
	github.com/wlynxg/anet v0.0.5 // indirect
	github.com/x448/float16 v0.8.4 // indirect
	golang.org/x/sys v0.48.0 // indirect
	golang.org/x/text v0.42.0 // indirect
)

replace github.com/quic-go/quic-go => /Volumes/worktrees/wiremux/e02-d-darwin/.cache/e02-d/fork-source
