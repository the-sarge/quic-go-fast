# macOS native throughput certification

Slice [7.1](../adr/2026-10-19-native-certification-plan.md#slice-71--certify-the-macos-target), child [#1933](https://github.com/GridSwarm/wiremux/issues/1933), measures one native Wire on the adopted macOS stack. The current accepted resumption plan is `0c4d112c251e942ea3152e9fb9ace85bff6b1af3` ([#2041](https://github.com/GridSwarm/wiremux/pull/2041)). This record owns the dated, example-level figures in [NATIVE-THROUGHPUT.md](../NATIVE-THROUGHPUT.md); they are not compatibility promises. Earlier stopped fast.8 evidence is retained below and contributes no fresh statistic.

## Fresh fast.9 protocol recorded before measurement

This section is committed and pushed before the fresh campaign. **Source:** the accepted plan's Decision and amended Slice 7.1, and [PROTOCOL.md at the published rig](https://github.com/GridSwarm/wiremux/blob/a08ce86907efc2b210ae31861643310446a4a47e/cmd/nativerig/PROTOCOL.md). The original protocol remains preserved below and in its original pushed commit.

### Build and cell

| Identity | Source selected before fresh measurement |
| --- | --- |
| wiremux main | `0c4d112c251e942ea3152e9fb9ace85bff6b1af3` |
| Published rig | `a08ce86907efc2b210ae31861643310446a4a47e`, remote `codex/1933-fast9-rig` |
| Fork | `github.com/the-sarge/quic-go-fast v0.62.1-fast.9`, source `0f717339f767df5d2e4091b2515266d61f66e2ac` |
| Module checksum | `h1:bxCYXEbnY35W5bstYGEkvOc0rVSu284KtjKmI2qbw4c=` |
| Modfile | `cmd/nativerig/rig.mod`; its fast.9 replacement matches the Mac adoption modfile and [adoption receipts](https://github.com/GridSwarm/wiremux/pull/2035#issuecomment-6403836243) |
| Build toolchain | Installed/base Go 1.27.3, `GOTOOLCHAIN=local` |
| Cell | `tb`: mbp128 `bridge0` → m4mini `bridge0`, Thunderbolt Bridge, MTU 1500 |
| Both peers | macOS 27.0.1, build `26A434`, Darwin 27.0.0, arm64 |
| Durable evidence root | `/Volumes/worktrees/wiremux/native-gap-evidence/1933-macos-resume-20261025/` |

The measured rig tree is the selected main tree plus the named published `cmd/nativerig` files. All rig Go files, driver and summarizer are unchanged from prepared rig `b5abe7db863a6e91386b3adc1240f479def255e3`; only the fork modfile/checksum bookkeeping changes. Both peers use the same Darwin binary built by `rig.sh`. No `QUIC_GO_DISABLE_*` variable, per-arm `-env` switch, `quic_go_no_private_syscalls` tag, stand-in lever or in-process load is permitted. Check binary build settings, environments, native readouts, `gomaxprocs` and `num_cpu`. The consumer is otherwise idle under the [processor headroom rule](../NATIVE-THROUGHPUT.md#processor-headroom).

[Fast.9](https://github.com/the-sarge/quic-go-fast/releases/tag/v0.62.1-fast.9) retains fast.8's stack and adds only the idle-MTU timer fix in [QUIC #1047](https://github.com/the-sarge/quic-go-fast/pull/1047); all other module-archive entries are byte-identical. It excludes adaptive loss recovery from current fork main. [Wiremux #2037](https://github.com/GridSwarm/wiremux/pull/2037), already in the measured main, repairs the Darwin startup qualification race. Public module identity/archive reconciliation, all six required Mac fork race packages, existing rig tests/build, module verification and the fork-graph vulnerability scan passed before traffic. The ordinary upstream graph and root module files are unchanged. These checks are setup evidence, not throughput results.

### Adopted stack on both peers

**Source:** merged product PRs and the fast.8 bundle record and fast.9 maintenance adoption. The selected fork carries the 32-entry send queue and cap 32, the 1,024-entry receive and post-confirmation unprocessed queues, Darwin read slots, and the optional acknowledgment and send-thread hooks. The following wiremux slices are present in the selected main commit; Slice 3.3 remains deferred and is not part of this certification.

| Slice | Shipped lever | Merged PR |
| --- | --- | --- |
| 1.1 | One `Write` per channel record | [#1950](https://github.com/GridSwarm/wiremux/pull/1950) |
| 1.2 | Promotion-time Datagram ceiling follows path MTU discovery | [#1952](https://github.com/GridSwarm/wiremux/pull/1952) |
| 1.3 | Native Datagram send with one queue and one copy | [#1954](https://github.com/GridSwarm/wiremux/pull/1954) |
| 2.1 | Binding allocation removal | [#1960](https://github.com/GridSwarm/wiremux/pull/1960) |
| 2.2 | Connected socket per peer on macOS | [#1963](https://github.com/GridSwarm/wiremux/pull/1963) |
| 2.3 | Native Datagram receive without the second copy | [#1967](https://github.com/GridSwarm/wiremux/pull/1967) |
| 5.1 | fast.8 bundle adoption | [#1999](https://github.com/GridSwarm/wiremux/pull/1999) |
| 5.2 | Admits-mode adoption | [#2001](https://github.com/GridSwarm/wiremux/pull/2001) |
| 6.1 | Acknowledge every 16 on native Reno transports | [#2016](https://github.com/GridSwarm/wiremux/pull/2016) |
| 6.2 | User-initiated send thread on Apple silicon | [#2020](https://github.com/GridSwarm/wiremux/pull/2020) |
| 6.3 | Connected macOS `sendmsg_x` send groups | [#2027](https://github.com/GridSwarm/wiremux/pull/2027) |
| 6.4 | Connected macOS `recvmsg_x` into eight fork read slots | [#2029](https://github.com/GridSwarm/wiremux/pull/2029) |

### Floors, verbatim

**Source:** [the target decision, section 2](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) and the accepted plan.

| Floor (one native Wire, `tb`, idle consumer) | Packets/s | Gbit/s |
| --- | ---: | ---: |
| Datagrams at the pin | ≥ 420k | ≥ 4.7 at 1,397-byte Datagrams |
| Stream | ≥ 440k | ≥ 4.8 |

Packets per second decide both rows; Gbit/s is reported beside them. **Derived:** 420,000 × 1,397 × 8 = 4.69392 Gbit/s, the rounded 4.7 in the source table. The stream runs with default GC; only `dgrampin` uses the consumer-heap pin. Default-GC Datagrams and the Terminal-launched rows are reported without floors.

### Exact arms and launch context

Each headline uses these exact `rig.sh` arguments, in this order, with `REPS=5 SECS=10 WARMUP=1`. Labels differ by more than case. `OUTDIR` is a fresh directory under the durable evidence root.

```sh
cmd/nativerig/rig.sh tb OUTDIR \
  'dgram=dgram -native-min-payload 1397 -size 1397' \
  stream=stream udp=udp 'udp4=udp -sockets 4' binding=binding \
  'dgrampin=dgram -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both'
```

The certified sender is started through its own `ssh mbp128` session and the existing daemon launcher `/Volumes/worktrees/wiremux/native-gap-evidence/1853-ecore-qos/tools/spawnctx/spawnctx -type daemon`. The receiver is always started through `ssh m4mini-tb` by the unmodified `tb` driver. One separate campaign runs the same arms from a shell launched by Terminal, at the sender's default class, reported only. Both use `GOTOOLCHAIN=local`, `PORT=49333`, `LOADGATE=1`, `MAXLOAD=8`, and `GATE=/Volumes/worktrees/wiremux/native-gap-evidence/1933-macos-resume-20261025/gate.sh`.

Hold the `tb` pair claim for each entire campaign. Announce CPU-heavy mbp128 work and queue behind any foreign pair work; verify claim acquisition against concurrent work. Before every run, `GATE` checks the live claim and absence of another session's `nativerig`, records Tart VM count and host load, and `LOADGATE=1` waits for both peers' load1 to be at most 8. No GARM configuration or running VM is changed. m4mini has its normal background work, historically about 1.5 cores mostly `mediaanalysisd`; retain each run's `recv.load` rather than assuming the host is idle. No Instruments recording or CPU profile is taken.

The retained Windows Fusion VM may remain running on mbp128; it is not changed or deleted. The gate records VMware processes beside Tart and load observations. Shared Arm-cell traffic queues behind the same whole-campaign pair claim.

### Statistic, budget and stops

**Source:** `summarize.py` at the pinned rig owns the headline median, minimum and maximum of the five non-warm-up runs; the warm-up rotation runs and remains in the record. Under the amended contract, the optional smoke and original noisy replacement are consumed. No new smoke or noisy replacement is allowed. Run one fresh daemon/SSH headline. If either floor misses, run the original unused miss campaign and pool both fresh campaigns' non-warm-up runs. A pooled miss files a diagnosis issue and reverts nothing. Run the still-unused Terminal headline once, reported only and never repeated for a miss. Any fresh noisy campaign stops for the operator. The stopped fast.8 attempts are never pooled with fresh results. No A/B, profile, busy-consumer remeasurement, additional platform/arm or unbounded repetition is admitted.

Report every run. Check both native peers' send-thread outcome is raised, connect failures and send/receive batch fallback reasons are zero, engagement counts are positive, and stream packets/s is present. Every Datagram sender size and both byte/packet ratios must be exactly 1,397, with promoted ceilings at least 1,397. Terminal's sender outcome `refused: 1` is its expected reported launch context, never certified engagement; its receiver remains SSH-launched. An unavailable outcome is null, never zero or engagement evidence. Smaller payload, unengaged adopted certification lever, missing readout, contradictory protocol, fork mismatch, unexplained closure/send error, lost claim, source change or a required edit outside the four accepted documentation paths stops execution.

The record terminates with met/missed statuses for both floors and figures for default-GC and Terminal rows. Product evidence changes only this record and the existing macOS Status line/row; completion metadata changes only this slice and Track 7's current frontier. Contract closure is not triggered. The certification product PR's review budget remains one fully briefed initial review plus at most one replacement, followed by exact-head local and hosted gates.

## Fresh measurement results

**Measured, 2026-10-25: both macOS floors met.** The daemon/SSH headline completed all 36 run pairs with no setup failure or flagged run. Each arm contributes five non-warm-up runs; the six-run warm-up rotation is retained and excluded. No miss campaign was needed and no fresh noisy replacement, extra smoke or performance-tuning run was performed. The two fresh campaigns use the source identities above; stopped fast.8 attempts contribute no statistic.

### Certified daemon/SSH headline

Durable `OUTDIR`: `/Volumes/worktrees/wiremux/native-gap-evidence/1933-macos-resume-20261025/headline-fast9-1/`. All figures below are **measured**; parentheses show minimum–maximum. Packets/s decide the verdict. Gbit/s is delivered payload throughput, rounded independently from packets/s.

| Floor row | Packets/s, median (min–max) | Gbit/s, median (min–max) | Verdict |
| --- | ---: | ---: | --- |
| Datagrams at the pin, 1,397 bytes | 583,489 (564,623–584,772) | 6.521 (6.310–6.535) | Met: ≥ 420,000/s |
| Stream, default GC | 584,483 (552,261–604,701) | 6.520 (6.160–6.746) | Met: ≥ 440,000 packets/s |

Stream packets/s is the receiver’s `native.packets_received_per_s` (`ConnectionStats.PacketsReceived`), not the top-level stream `pps: 0`. The same five runs’ receiver `bridge0` input-frame rate has median **584,514 frames/s**, reported beside the stream readout. Datagram packets/s is the receiver’s delivered Datagram rate. The exact unrounded medians agree with the pinned summarizer’s `summary.json`; per-run JSON supplies the packet-rate extrema. All Datagram arms, including reported default-GC and Terminal arms, sent exactly **1,397 bytes per Datagram**: sender `size` and both peers’ `bytes/packets` agree, and all promoted `max_payload` values are 1,397.

### Reported only

These rows have no floor. The default-GC daemon row uses the same headline; the Terminal rows use their own single campaign and are never pooled into certification. All figures are **measured**, with minimum–maximum in parentheses.

| Context and arm | Packets/s, median (min–max) | Gbit/s, median (min–max) | Status |
| --- | ---: | ---: | --- |
| Daemon/SSH, default-GC Datagrams | 500,711 (487,637–503,763) | 5.596 (5.450–5.630) | Reported |
| Terminal, default-GC Datagrams | 484,888 (475,330–492,889) | 5.419 (5.312–5.509) | Reported |
| Terminal, Datagrams at the pin | 513,791 (507,598–534,265) | 5.742 (5.673–5.971) | Reported |
| Terminal, stream with default GC | 547,943 (531,201–569,940) | 6.112 (5.927–6.357) | Reported |

Durable Terminal `OUTDIR`: `/Volumes/worktrees/wiremux/native-gap-evidence/1933-macos-resume-20261025/terminal-fast9/`. It completed all 36 pairs, with zero flagged runs or setup failures. The retained `terminal-ancestry.txt` traces the sender shell through `login` to `/System/Applications/Utilities/Terminal.app/Contents/MacOS/Terminal`. Its stream receiver's `bridge0` input-frame median is **547,980 frames/s**. The receiver stayed SSH-launched in both contexts. The Terminal sender's expected `send_thread_qos.refused: 1` is observed in all native runs; these rows are reported without a floor and do not discharge the certified QoS criterion.

### Engagement, load and preservation

All 36 native peer results per campaign, including warm-ups, have positive send/receive batch-call and batch-Datagram counts, zero connect failures, zero send/receive batch fallback reasons, zero control/data truncations, zero receive-coalescing fallbacks and zero batch ICMP drops/absorptions. Every daemon native peer and every Terminal native receiver reports `send_thread_qos = {off: 0, pending: 0, raised: 1, refused: 0, stood_down: 0}`; every Terminal native sender reports the same vector with `raised: 0, refused: 1`. No native snapshot is missing. Unavailable legacy PTO, spurious-loss and `unprocessed_drops` readouts remain absent; they are not asserted zero. Actual `unprocessed_packet_drops` and occasional delivered-Datagram drops remain recorded in the JSON and extra-count summary; no run was removed for packet loss. These counters are reported observations, not adopted-lever failures or evidence of loss-free delivery.

No `QUIC_GO_DISABLE_*` environment variable or `quic_go_no_private_syscalls` build tag was present. No arm used in-process load or a stand-in lever. Each peer's `gomaxprocs` equals its `num_cpu` (sender 16, receiver 12), with no forced scheduler or GC environment. Each campaign retains `build-info.txt` and `binary-sha256.txt`, including the published rig revision, `vcs.modified=false`, Go 1.27.3, and the fast.9 module checksum. Both campaign binaries have SHA-256 `5439b599b67262454891da2ef9e2d8095556b99927419390c4bdd7d67674636c`.

**Daemon/SSH host observations:** load1 across all 36 pairs, warm-ups included: send 3.72–7.52, recv 3.40–6.88. Each per-run gate observed zero running Tart VMs, no VMware VM process, a live owned pair claim and no foreign `nativerig`. `LOADGATE=1 MAXLOAD=8` remained enabled. m4mini retained its normal background work; these load snapshots do not claim an otherwise empty host.

**Terminal host observations:** load1 across all 36 pairs, warm-ups included: send 4.34–7.65, recv 3.39–7.06. Each per-run gate observed zero running Tart VMs, no VMware VM process, a live owned pair claim and no foreign `nativerig`. `LOADGATE=1 MAXLOAD=8` remained enabled. m4mini retained its normal background work; these load snapshots do not claim an otherwise empty host.

The pair claim was held for each entire campaign and released after exit 0. No GARM pool, runner, service or configuration was mutated; no Windows guest or disk was changed or deleted; no Instruments trace or CPU profile was taken. The two original stopped fast.8 campaigns remain outside the statistic. The optional smoke and noisy replacement remain consumed; the unused pooled-miss allowance was not exercised. No new diagnosis issue is needed because both floors met.

Protocol commit `0d725efbe0d25c89c5f39e41cca66414530a929f` was committed at `2026-10-25T22:21:46Z` and the remote PR/ref was confirmed before the first fresh `meta.txt` at `22:27:55Z`; Terminal `meta.txt` is later at `22:39:57Z`. The initial stale PR-metadata read stopped before any traffic; a refreshed PR read and `git ls-remote` confirmed the pushed protocol. The documentation-only merge of adoption [#2042](https://github.com/GridSwarm/wiremux/pull/2042) changes documentation only; product Go/module bytes match the measured main. The product diff contains only this record, the macOS Status line/row, this slice's completion state and Track 7's current frontier. These figures describe this dated cell and build, not other hardware, links, loads or a compatibility guarantee.

### Retained campaign metadata and authoritative summaries

Each block below is pasted from its named file with trailing whitespace omitted; the durable files retain the original bytes. `summary.txt` rounds rates; the tables above round the same unrounded medians, with packet-rate extrema read from the five non-warm-up receiver JSON files. All raw peer results, errors, loads, interface snapshots, gate observations, command/build identity and warm-up runs remain in the durable `OUTDIR`s. No run was dropped or quietly repeated.

#### Daemon/SSH `headline-fast9-1/meta.txt`

```text
date: 2026-10-25T22:27:55Z
cell: tb reps: 5 secs: 10 warmup: 1
rig: a08ce86907efc2b210ae31861643310446a4a47e dirty=0
go: go version go1.27.3 darwin/arm64
modfile: cmd/nativerig/rig.mod
quic-go: replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.9
arms:
  dgram=dgram -native-min-payload 1397 -size 1397
  stream=stream
  udp=udp
  udp4=udp -sockets 4
  binding=binding
  dgrampin=dgram -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
quiet load before the first run: sender { 3.70 3.76 4.03 }
quiet load before the first run: receiver { 3.40 2.90 2.65 }
sender: Darwin mbp128.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
sender sysctl: 8388608 786896 9216
receiver: Darwin m4mini.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
receiver sysctl: 8388608 786896 9216
members: sender bridge0 en1 en2 en3 | receiver bridge0 en2 en3 en4
```

#### Daemon/SSH `headline-fast9-1/summary.txt`

```text
medians over non-warm-up runs; cpu/GiB is CPU seconds per delivered GiB; lost packets per run: wire = sender if out - receiver if in, stack = receiver if in - UDP in, rcvbuf = full socket buffer
arm             n Mbit/s med    min    max  pkt/s med    loss cpu/GiB s      r     wire    stack   rcvbuf
binding         5       1163   1145   1182     100149  48.33%      7.44  10.32     3293       -9   941337
dgram           5       5596   5450   5630     500711   0.02%      4.56   4.15       25      -46      249
dgrampin        5       6521   6310   6535     583489   0.02%      3.65   3.55      991      -77        0
stream          5       6520   6160   6746          0       -      2.83   3.57      467      -23        0
udp             5       1794   1758   2005     154449  26.92%      4.86   7.72   335676      -71   201138
udp4            5       2250   2237   2276     193683  34.62%     15.45   4.29  1026789       -8        0

extras (medians): sender member-queue drops; lost after the sender's member queue (member dequeued - receiver if in); receiver 16 KB cluster refill failures; receiver if in frames/s and bytes/frame; GC cycles/s per peer; -qdepth queued datagrams before each read (median, mean, share empty)
arm             q drop  after q  16k fail   in fr/s  B/frame  gc/s s  gc/s r             qdepth
binding              0     3287      3283    195183     1494     3.1   161.7                  -
dgram                0       16         0    500730     1466   656.4   373.8                  -
dgrampin             0      988       983    583693     1466    27.5    14.3                  -
stream               0      462       435    584514     1469    14.1     9.8                  -
udp                  0   335671    335656    174300     1494     0.0     0.0                  -
udp4                 0  1026783   1026774    193696     1494     0.0     0.0                  -

sender CPU per offered packet (medians, min-max): user and system microseconds; share of each on performance cores
arm                       user us             sys us  user P   sys P
binding          0.40 (0.39-0.40)   4.76 (4.73-4.85)    100%    100%
dgram            2.80 (2.77-2.83)   3.13 (3.12-3.21)    100%     99%
dgrampin         2.16 (2.13-2.17)   2.59 (2.56-2.66)    100%     99%
udp              0.22 (0.21-0.22)   4.67 (4.55-4.68)    100%    100%
udp4             0.41 (0.41-0.43) 13.18 (12.99-13.28)    100%    100%

receiver per delivered datagram (medians; min-max for total CPU): receive call; CPU-s per delivered GiB, total, user, system; user and system microseconds per datagram; system share on performance cores; cycles per datagram; receive system calls per datagram (read and recvmsg: 1, a floor, as parked calls are not visible); recvmsg_x datagrams per delivering call (mean, median), share of calls that filled every slot, parked calls per delivering call
arm                   call         cpu/GiB r  user   sys user us sys us sys P  cyc/dg calls/dg      fill  full park/dc
udp                   read  7.72 (6.34-7.76)  0.53  7.19    0.72   9.72  100%   39876        1         -     -       -
udp4                  read  4.29 (4.08-4.62)  0.91  3.38    1.24   4.57   98%   21681        1         -     -       -

native readouts (medians; slice 3.1's seam): readouts mode; sender min, smoothed (at the end) and mean RTT over the send window (us); PTOs and spurious losses over the sender's window (recorder only); receiver packets received/s (ConnectionStats.PacketsReceived); receiver Datagram discards and unprocessed-queue drops at the end; runs with a missing snapshot. absent = no fork method, no recorder, or no snapshot
arm                mode  minRTT    sRTT  meanRTT   PTO  spur   r pkt/s  dg drop   unproc miss  env
dgram             stats      76     203   absent absent absent    500651        0   absent    0  -
dgrampin          stats      91     629   absent absent absent    581902        0   absent    0  -
stream            stats      78     963   absent absent absent    584483        0   absent    0  -

native extra counts (medians of each peer's total at its final snapshot; counts a scratch build adds to 3.1's Readout)
binding        recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
dgram          recv connect_failures 0; recv receive_batch_calls 896975; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 5006408; recv receive_batch_fallback_reason 0; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 4726; recv send_batch_datagrams 9535; recv send_batch_fallback_reason 0; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 354373; send receive_batch_control_truncated 0; send receive_batch_datagrams 197488; send receive_batch_fallback_reason 0; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 165423; send send_batch_datagrams 5005903; send send_batch_fallback_reason 0; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
dgrampin       recv connect_failures 0; recv receive_batch_calls 847812; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 5836536; recv receive_batch_fallback_reason 0; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 8285; recv send_batch_datagrams 16680; recv send_batch_fallback_reason 0; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 416728; send receive_batch_control_truncated 0; send receive_batch_datagrams 236312; send receive_batch_fallback_reason 0; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 185786; send send_batch_datagrams 5836234; send send_batch_fallback_reason 0; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
stream         recv connect_failures 0; recv receive_batch_calls 856454; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 5844795; recv receive_batch_fallback_reason 0; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 2523; recv send_batch_datagrams 5136; recv send_batch_fallback_reason 0; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 377966; send receive_batch_control_truncated 0; send receive_batch_datagrams 200353; send receive_batch_fallback_reason 0; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 208785; send send_batch_datagrams 5846732; send send_batch_fallback_reason 0; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
udp            recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
udp4           recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
```

#### Terminal `terminal-fast9/meta.txt`

```text
date: 2026-10-25T22:39:57Z
cell: tb reps: 5 secs: 10 warmup: 1
rig: a08ce86907efc2b210ae31861643310446a4a47e dirty=0
go: go version go1.27.3 darwin/arm64
modfile: cmd/nativerig/rig.mod
quic-go: replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.9
arms:
  dgram=dgram -native-min-payload 1397 -size 1397
  stream=stream
  udp=udp
  udp4=udp -sockets 4
  binding=binding
  dgrampin=dgram -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
quiet load before the first run: sender { 4.34 5.41 5.08 }
quiet load before the first run: receiver { 3.02 4.29 3.91 }
sender: Darwin mbp128.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
sender sysctl: 8388608 786896 9216
receiver: Darwin m4mini.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
receiver sysctl: 8388608 786896 9216
members: sender bridge0 en1 en2 en3 | receiver bridge0 en2 en3 en4
```

#### Terminal `terminal-fast9/summary.txt`

```text
medians over non-warm-up runs; cpu/GiB is CPU seconds per delivered GiB; lost packets per run: wire = sender if out - receiver if in, stack = receiver if in - UDP in, rcvbuf = full socket buffer
arm             n Mbit/s med    min    max  pkt/s med    loss cpu/GiB s      r     wire    stack   rcvbuf
binding         5       1274   1191   1440     109691  43.60%      6.80   9.54     5538      -91   840338
dgram           5       5419   5312   5509     484888   0.02%      4.55   4.11      441       22      226
dgrampin        5       5742   5673   5971     513791   0.01%      3.82   3.64      442       21        0
stream          5       6112   5927   6357          0       -      2.94   3.66      894      -56        0
udp             5       2228   2133   2273     191822   9.07%      3.90   4.46   173450       29    20561
udp4            5       2275   2207   2293     195859  34.93%     15.27   4.04  1056289      -61        0

extras (medians): sender member-queue drops; lost after the sender's member queue (member dequeued - receiver if in); receiver 16 KB cluster refill failures; receiver if in frames/s and bytes/frame; GC cycles/s per peer; -qdepth queued datagrams before each read (median, mean, share empty)
arm             q drop  after q  16k fail   in fr/s  B/frame  gc/s s  gc/s r             qdepth
binding              0     5531      5527    193750     1494     3.0   177.0                  -
dgram                0      432       413    484929     1466   639.2   359.7                  -
dgrampin             0      436       432    513815     1466    24.3    12.6                  -
stream               0      890       886    547980     1469    14.1     9.1                  -
udp                  0   173446    173443    193890     1494     0.0     0.0                  -
udp4                 0  1055500   1052841    195872     1494     0.0     0.0                  -

sender CPU per offered packet (medians, min-max): user and system microseconds; share of each on performance cores
arm                       user us             sys us  user P   sys P
binding          0.39 (0.38-0.41)   4.79 (4.74-4.81)    100%    100%
dgram            2.77 (2.75-2.82)   3.15 (3.10-3.20)    100%     99%
dgrampin         2.15 (2.12-2.18)   2.82 (2.71-2.86)    100%    100%
udp              0.21 (0.21-0.22)   4.64 (4.57-4.64)    100%    100%
udp4             0.42 (0.41-0.42) 13.02 (12.95-13.25)    100%    100%

receiver per delivered datagram (medians; min-max for total CPU): receive call; CPU-s per delivered GiB, total, user, system; user and system microseconds per datagram; system share on performance cores; cycles per datagram; receive system calls per datagram (read and recvmsg: 1, a floor, as parked calls are not visible); recvmsg_x datagrams per delivering call (mean, median), share of calls that filled every slot, parked calls per delivering call
arm                   call         cpu/GiB r  user   sys user us sys us sys P  cyc/dg calls/dg      fill  full park/dc
udp                   read  4.46 (3.69-5.34)  0.20  4.27    0.27   5.77  100%   23049        1         -     -       -
udp4                  read  4.04 (3.97-4.31)  0.79  3.25    1.07   4.39   94%   20427        1         -     -       -

native readouts (medians; slice 3.1's seam): readouts mode; sender min, smoothed (at the end) and mean RTT over the send window (us); PTOs and spurious losses over the sender's window (recorder only); receiver packets received/s (ConnectionStats.PacketsReceived); receiver Datagram discards and unprocessed-queue drops at the end; runs with a missing snapshot. absent = no fork method, no recorder, or no snapshot
arm                mode  minRTT    sRTT  meanRTT   PTO  spur   r pkt/s  dg drop   unproc miss  env
dgram             stats      72     209   absent absent absent    484864        0   absent    0  -
dgrampin          stats      89     527   absent absent absent    512620        0   absent    0  -
stream            stats     100     372   absent absent absent    547943        0   absent    0  -

native extra counts (medians of each peer's total at its final snapshot; counts a scratch build adds to 3.1's Readout)
binding        recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
dgram          recv connect_failures 0; recv receive_batch_calls 898257; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 4848659; recv receive_batch_fallback_reason 0; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 4160; recv send_batch_datagrams 8427; recv send_batch_fallback_reason 0; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 347060; send receive_batch_control_truncated 0; send receive_batch_datagrams 192226; send receive_batch_fallback_reason 0; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 159922; send send_batch_datagrams 4848378; send send_batch_fallback_reason 0; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
dgrampin       recv connect_failures 0; recv receive_batch_calls 848203; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 5137577; recv receive_batch_fallback_reason 0; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 5726; recv send_batch_datagrams 11566; recv send_batch_fallback_reason 0; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 386446; send receive_batch_control_truncated 0; send receive_batch_datagrams 210957; send receive_batch_fallback_reason 0; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 161628; send send_batch_datagrams 5139055; send send_batch_fallback_reason 0; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
stream         recv connect_failures 0; recv receive_batch_calls 827303; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 5478084; recv receive_batch_fallback_reason 0; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 2648; recv send_batch_datagrams 5328; recv send_batch_fallback_reason 0; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 0; send connect_failures 0; send receive_batch_calls 364083; send receive_batch_control_truncated 0; send receive_batch_datagrams 192685; send receive_batch_fallback_reason 0; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 179713; send send_batch_datagrams 5478894; send send_batch_fallback_reason 0; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
udp            recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
udp4           recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
```


## Stopped fast.8 attempts retained

The [raw stop receipt](https://github.com/GridSwarm/wiremux/pull/2035#issuecomment-6400446211), [completed debugging/integration](https://github.com/GridSwarm/wiremux/pull/2035#issuecomment-6401236741) and [accepted resumption](https://github.com/GridSwarm/wiremux/pull/2035#issuecomment-6404071918) retain the attempt boundaries and repair receipts. Raw outputs remain under `/Volumes/worktrees/wiremux/native-gap-evidence/1933-macos-certify/`; debugging outputs remain under `/Volumes/worktrees/wiremux/native-gap-evidence/1933-startup-diagnosis-20261025/`. No run was dropped or quietly repeated.

| Attempt | Disposition |
| --- | --- |
| Original optional smoke | Interrupted for the rig's missing QoS readout; retained and allowance consumed. The separately published rig repair did not reset it. |
| `headline-1` | 36 raw run directories retained. Setup failures made the pinned Datagram arm noisy; no valid certification statistic. |
| `headline-1-repeat` | 20 started-run directories retained, including the deliberately interrupted final run. Stopped on receive-batch fallback reason 3 and zero receive-batch calls; no valid floor verdict. The single noisy-repeat allowance is consumed. |

Both timing causes are repaired by merged wiremux #2037 and QUIC #1047. The three later short paired-Mac checks reached 1,397 bytes with both batch paths active in approximately 0.13 seconds from selection through promotion. Those runs are debugging evidence, never certification campaigns or performance/floor evidence.

<details>
<summary>Original pre-measurement fast.8 protocol, preserved as historical evidence</summary>

# macOS native throughput certification

Slice [7.1](../adr/2026-10-19-native-certification-plan.md#slice-71--certify-the-macos-target), child [#1933](https://github.com/GridSwarm/wiremux/issues/1933), measures one native Wire on the adopted macOS stack. The accepted plan is commit `68da9417d02208906034cfa4f2f231b131b309ef`. This record owns the figures presented in [NATIVE-THROUGHPUT.md](../NATIVE-THROUGHPUT.md); they are dated, example-level measurements, not compatibility promises.

## Protocol recorded before measurement

This section is committed and pushed before the first certification campaign. Results and raw campaign metadata are added afterward. **Source:** the accepted plan's Decision and Slice 7.1, and [PROTOCOL.md at the published rig commit](https://github.com/GridSwarm/wiremux/blob/b5abe7db863a6e91386b3adc1240f479def255e3/cmd/nativerig/PROTOCOL.md).

### Build and cell

| Identity | Source selected before measurement |
| --- | --- |
| wiremux main | `68da9417d02208906034cfa4f2f231b131b309ef` |
| Published rig | `b5abe7db863a6e91386b3adc1240f479def255e3`, remote `codex/native-gap-rig` |
| Fork | `github.com/the-sarge/quic-go-fast v0.62.1-fast.8`, source `8095c72244755f0c1e24f4158253bf09cfbe6e17` |
| Modfile | Unchanged `cmd/nativerig/rig.mod`; its replacement matches the [5.1 native adoption lane](quic-go-fast-v0.62.1-fast.8-native-adoption.md) |
| Build toolchain | Installed/base Go 1.27.3, `GOTOOLCHAIN=local` |
| Cell | `tb`: mbp128 `bridge0` → m4mini `bridge0`, Thunderbolt Bridge, MTU 1500 |
| Both peers | macOS 27.0.1, build `26A434`, Darwin 27.0.0, arm64 |
| Durable evidence root | `/Volumes/worktrees/wiremux/native-gap-evidence/1933-macos-certify/` |

The rig tree contains exactly the selected main tree plus the published `cmd/nativerig` files; no product, fork or rig source is modified for measurement. Both peers run the same Darwin binary built by `rig.sh`. No `QUIC_GO_DISABLE_*` variable, per-arm `-env` switch, `quic_go_no_private_syscalls` tag, stand-in lever or in-process load is permitted. The record checks binary build settings, process environments and native readouts. Each peer's `gomaxprocs` and `num_cpu` are retained in its result line. The consumer is otherwise idle under the [processor headroom rule](../NATIVE-THROUGHPUT.md#processor-headroom).

### Adopted stack on both peers

**Source:** merged product PRs and the fast.8 adoption record. The selected fork carries the 32-entry send queue and cap 32, the 1,024-entry receive and post-confirmation unprocessed queues, Darwin read slots, and the optional acknowledgment and send-thread hooks. The following wiremux slices are present in the selected main commit; Slice 3.3 remains deferred and is not part of this certification.

| Slice | Shipped lever | Merged PR |
| --- | --- | --- |
| 1.1 | One `Write` per channel record | [#1950](https://github.com/GridSwarm/wiremux/pull/1950) |
| 1.2 | Promotion-time Datagram ceiling follows path MTU discovery | [#1952](https://github.com/GridSwarm/wiremux/pull/1952) |
| 1.3 | Native Datagram send with one queue and one copy | [#1954](https://github.com/GridSwarm/wiremux/pull/1954) |
| 2.1 | Binding allocation removal | [#1960](https://github.com/GridSwarm/wiremux/pull/1960) |
| 2.2 | Connected socket per peer on macOS | [#1963](https://github.com/GridSwarm/wiremux/pull/1963) |
| 2.3 | Native Datagram receive without the second copy | [#1967](https://github.com/GridSwarm/wiremux/pull/1967) |
| 5.1 | fast.8 bundle adoption | [#1999](https://github.com/GridSwarm/wiremux/pull/1999) |
| 5.2 | Admits-mode adoption | [#2001](https://github.com/GridSwarm/wiremux/pull/2001) |
| 6.1 | Acknowledge every 16 on native Reno transports | [#2016](https://github.com/GridSwarm/wiremux/pull/2016) |
| 6.2 | User-initiated send thread on Apple silicon | [#2020](https://github.com/GridSwarm/wiremux/pull/2020) |
| 6.3 | Connected macOS `sendmsg_x` send groups | [#2027](https://github.com/GridSwarm/wiremux/pull/2027) |
| 6.4 | Connected macOS `recvmsg_x` into eight fork read slots | [#2029](https://github.com/GridSwarm/wiremux/pull/2029) |

### Floors, verbatim

**Source:** [the target decision, section 2](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) and the accepted plan.

| Floor (one native Wire, `tb`, idle consumer) | Packets/s | Gbit/s |
| --- | ---: | ---: |
| Datagrams at the pin | ≥ 420k | ≥ 4.7 at 1,397-byte Datagrams |
| Stream | ≥ 440k | ≥ 4.8 |

Packets per second decide both rows; Gbit/s is reported beside them. **Derived:** 420,000 × 1,397 × 8 = 4.69392 Gbit/s, the rounded 4.7 in the source table. The stream runs with default GC; only `dgrampin` uses the consumer-heap pin. Default-GC Datagrams and the Terminal-launched rows are reported without floors.

### Exact arms and launch context

Each headline uses these exact `rig.sh` arguments, in this order, with `REPS=5 SECS=10 WARMUP=1`. Labels differ by more than case. `OUTDIR` is a fresh directory under the durable evidence root.

```sh
cmd/nativerig/rig.sh tb OUTDIR \
  'dgram=dgram -native-min-payload 1397 -size 1397' \
  stream=stream udp=udp 'udp4=udp -sockets 4' binding=binding \
  'dgrampin=dgram -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both'
```

The certified sender is started through its own `ssh mbp128` session and the existing daemon launcher `/Volumes/worktrees/wiremux/native-gap-evidence/1853-ecore-qos/tools/spawnctx/spawnctx -type daemon`. The receiver is always started through `ssh m4mini-tb` by the unmodified `tb` driver. One separate campaign runs the same arms from a shell launched by Terminal, at the sender's default class, reported only. Both use `GOTOOLCHAIN=local`, `PORT=49333`, `LOADGATE=1`, `MAXLOAD=8`, and `GATE=/Volumes/worktrees/wiremux/native-gap-evidence/1933-macos-certify/gate.sh`.

Hold the `tb` pair claim for each entire campaign. Announce CPU-heavy mbp128 work and queue behind any foreign pair work; verify claim acquisition against concurrent work. Before every run, `GATE` checks the live claim and absence of another session's `nativerig`, records Tart VM count and host load, and `LOADGATE=1` waits for both peers' load1 to be at most 8. No GARM configuration or running VM is changed. m4mini has its normal background work, historically about 1.5 cores mostly `mediaanalysisd`; retain each run's `recv.load` rather than assuming the host is idle. No Instruments recording or CPU profile is taken.

### Statistic, budget and stops

**Source:** `summarize.py` at the pinned rig commit owns the per-arm headline median, minimum and maximum over five non-warm-up runs; the first rotation is retained and excluded. The one optional `REPS=2 SECS=5` smoke was interrupted before certification when the previous rig omitted QoS output; all completed and partial runs remain under `smoke/`. The separately authorized rig repair restores that existing readout and has its own bounded adapter-check receipts under `/Volumes/worktrees/wiremux/native-gap-evidence/1933-qos-readout/`; those checks supply no certification evidence and do not reset this slice's optional-smoke allowance. Resume with the first headline campaign at the published rig identity above. One headline in the certified context supplies the initial verdict. If either floor misses, run exactly one more headline in that context and pool the two campaigns' non-warm-up runs. A pooled miss files a diagnosis issue and reverts nothing. The Terminal campaign is reported once and is never repeated for a miss.

Report every run. If more than a third of an arm's runs are flagged by the rig, retain and label the campaign noisy and repeat the entire campaign once; that repeat replaces it in the statistic and is separate from the miss campaign. A repeat that is again noisy stops. No A/B, profile, busy-consumer remeasurement, fork-lane suite, extra platform, extra arm or unbounded repetition is admitted.

For native certification arms, check both peers' `native.send_thread_qos.raised` is 1 (the other current-outcome counts are 0), connect failures are zero, and send/receive batch fallback reasons are zero (none); inspect engagement counters and stream packets/s readouts. Check every Datagram sender size and both byte/packet ratios are exactly 1,397, with both promoted ceilings at least 1,397. Any smaller payload, unengaged adopted lever, missing stream packets/s, contradictory campaign protocol, fork mismatch, unexplained Wire closure/send error, lost pair claim, source change, or required change outside the accepted four documentation paths stops execution. Terminal's `native.send_thread_qos.refused: 1` is the expected reported sender context, not certification evidence; an unavailable outcome is `null`, never evidence of engagement.

The record terminates with met/missed verdicts for both floor rows and figures for the default-GC and Terminal rows. Product evidence changes only this record and the existing macOS Status line and row; completion metadata changes only Slice 7.1 and Track 7's current frontier. Contract closure is not triggered. Review budget: one fully briefed initial review and at most one replacement, followed by exact-head local and hosted gates.

## Measurement results

Pending the campaigns defined above.

</details>
