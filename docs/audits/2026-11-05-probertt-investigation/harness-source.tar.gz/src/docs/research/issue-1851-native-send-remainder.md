# Issue #1851: what the native send's remainder over its closest raw reproduction is made of

Research for [What makes up the 1.1–1.5 µs the native macOS send costs beyond its closest raw reproduction?](https://github.com/GridSwarm/wiremux/issues/1851) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). [Why does a native packet send on macOS cost about 7.5 µs when a raw UDP send costs 5.4?](https://github.com/GridSwarm/wiremux/issues/1841) built a raw sender up to the native call, its acknowledgment rate and its send-queue hand-off, and left 1.1–1.5 µs per send unexplained. This note measures that remainder again on the unconnected shape, measures it for the first time on the connected shape that [Should the native path use a connected socket per peer?](https://github.com/GridSwarm/wiremux/issues/1843) adopted, attributes it, and says what can go while every datagram keeps its per-datagram admission. Nothing here implements a change.

Sources are wiremux at `origin/main` [d30c3689](https://github.com/GridSwarm/wiremux/tree/d30c3689454c0db2b008562d276d991fe642354f) (the native path is unchanged on `main` since), the connected-socket probe from [What would a connected socket per peer do to the native ceiling and to per-datagram admission?](https://github.com/GridSwarm/wiremux/issues/1842) (local commit `dc7cb39a`, never pushed), the quic-go-fast fork at the version the rig selects (`v0.62.1-fast.7`, [55ea687d](https://github.com/the-sarge/quic-go-fast/tree/55ea687d68c9c6f33785a1875374ec6a0d7570e8)), Go 1.27.2, the rig `cmd/nativerig` from `codex/native-gap-rig` with this ticket's additions ([c6664ce0 to 5beb019a](https://github.com/GridSwarm/wiremux/compare/48583edf...5beb019a)), the xnu source closest to the hosts' kernel that Apple publishes ([xnu-12377.121.6](https://github.com/apple-oss-distributions/xnu/tree/xnu-12377.121.6); both Macs run xnu-13432.1.9), and measurements taken for this note on 2026-10-16 (UTC). Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cell.** `tb` only: mbp128 (MacBook Pro M4 Max: four efficiency cores and two clusters of six performance cores) sends from `bridge0` over Thunderbolt to m4mini (Mac mini M4 Pro), both macOS 27 arm64, MTU 1500. Raw rungs send 1,218-byte payloads, the native Datagram arm's packet size. Both Macs host live GARM runner VMs, and two other sessions used the pair during the window ([Method](#method)).

**Basis.** The same as #1841's: the time the sender spends in the send system call's leaf (`__sendmsg`) per call, from an untraced, system-wide Instruments Time Profiler recording on mbp128 that covers the whole sender process, divided by the sender's send calls. Three recordings per rung in a set, in rotation; differences are taken within a set. Six sets on this basis (`Y`, `Y2` to `Y6`) each carry the same anchors (`u5`, `u7`, native unconnected, `c5`, `c7`, native connected). Two discriminators that need no root back them: per-call thread counters (instructions, cycles, kernel time and the core's clock) read around sampled send calls, and an interposer that timestamps every send, receive, `kevent` and thread park and wake call of the sender process.

## Answer

**On the connected shape that ships there is no remainder to speak of: −0.06 to +0.15 µs, inside the spread.** The connected native send costs 3.64–3.82 µs per call in the leaf (set medians), and a raw connected sender with the native call, acknowledgments arriving at the native connected rate (49,000/s, **measured** on the native pairs' `bridge0`) and the send-queue hand-off (`c7`) costs 3.55–3.75. Across six sets the native send is −0.06, +0.07, +0.10, +0.12, +0.14 and +0.15 µs above `c7`, and in the two sets that also ran it, −0.12 and −0.01 µs below `c7p`, the same sender with the acknowledgments arriving evenly (**measured**). Within one set the connected native send is the call (2.40 µs), acknowledgment contention at 49k/s (+0.86), the hand-off (+0.30) and +0.12 more (**derived**, set `Y`). An interposer that times every send agrees (3.48 against 3.32 µs); about 0.11 µs of its difference is that the fork's send goroutine sends in shorter runs than the raw hand-off, so more of its sends are the first after a pause, which cost about 2 µs more (**derived**, section 5). With the send goroutine's Go work (0.36–0.38 µs) a connected native packet costs about 4.1 µs on this basis, not the 5.2–5.6 #1841 estimated or the 4.6 #1842 derived.

**The unconnected 0.8–1.3 µs remainder is the stand-in, not the native path.** It reproduces (native over `u7`: +0.82 to +1.28 µs in six sets; #1841 measured 1.12–1.43) and closes when the raw sender's acknowledgments look like the native ones. #1841's reflector sent each millisecond's 38 acknowledgments at once, so 41–44% of them arrived within 4 µs of the previous one and the drain read them in runs. The native acknowledgments arrive evenly (9–10% within 4 µs) and 11–16% more often (42,300–44,100/s). With an even reflector the raw sender costs 0.75–0.79 µs more at 38k/s and 0.49 more again at 42k/s, and then matches the native send: 6.63 against 6.62 µs (**measured**, set `Y2`). Even arrivals cost more per send than bunched ones because each acknowledgment is read on its own wake-up, so the receiving socket's lock is taken more often per acknowledgment.

**At a consumer-sized heap the connected native send costs 0.18–0.44 µs more, and that is the same acknowledgment effect, not the heap.** At the map's Datagram GC pin (a 64 MiB ballast on both peers) the connected native send costs 3.94–4.15 µs, 0.18–0.44 µs more than at Go's default heap in five sets (**measured**). Raw senders with the pinned native's own heap behavior do not reproduce it: payloads written across 62 MiB of buffers (+0.03), a 1.13 GB/s write stream through 128 MiB (+0.01), and a real Go allocation stream at the native rate with the 64 MiB ballast, which matched the pinned native's 19 collections and about 550 page faults per second (−0.01 against the same stream at the default heap) (**measured**). What the pin does change is how the native sender reads its acknowledgments: with collections every 50–90 ms instead of every 2–3 ms on the two peers, the reads lose their long gaps (65 µs or more: 3.3–3.4% of reads → 0.5%) and bunch less (32–33% within 4 µs → 28%), and acknowledgments come 3–5% more often (**measured**). That is the direction that costs a send more; putting the ballast on the sender alone gives most of the cost (+0.17), on the receiver alone less (+0.07) (**measured**, one set). The attribution is by elimination and direction (**derived**); no rung reproduced the pinned pattern itself.

**What the extra cost is: stall cycles in an unchanged kernel path, not a longer path or a slower core.** Per sampled call every connected rung, raw or native, executes about 28,000–29,200 instructions and every unconnected rung about 49,900–51,400. Acknowledgments arriving, their pattern, the native process around the send and the GC pin add only cycles, mostly in the slowest calls: `c6` takes 3,000–3,600 more cycles per call than `c5` at the same instruction count. The core's clock measured just before each sampled call is as high for the native senders as for the fastest raw rung (3.95–4.04 GHz, against 3.3–4.1 for the raw rungs) (**measured**). Kernel stacks would show which lines stall (a lock waited on with the wait-for-event instruction looks the same as a cache miss here), but no unattributed remainder near the 0.5 µs threshold is left, so no root recording is proposed.

**With admission unchanged, the remainder has nothing left to remove; the costs around it can shrink in the fork.** Skipping the binding's per-datagram admission on both receive and send changes the connected send's leaf by +0.02 µs and removes 0.06 µs of Go work per datagram from the send goroutine (**measured**); admission is not in the send. The real costs beyond the call are the acknowledgment contention (+0.86 µs at 49k/s, more when acknowledgments arrive evenly, as they do at a consumer-sized heap), which only fewer acknowledgments or batched receives lower, and the hand-off with its short runs (+0.30 and +0.11), which a send queue that keeps its goroutine fed would lower; both live in the fork, and batched receives also in the binding. `GOMAXPROCS=4` lowers the connected native send by 0.10–0.20 µs (leaf and interposer), but it is the application's process setting, not wiremux's.

| Ingredient | Connected, µs per send | Unconnected, µs per send | Removable with admission unchanged? | Where |
| --- | --- | --- | --- | --- |
| the call (native shape) | 2.34–2.54 (`c5`) | 4.13–4.25 (`u5`) | no (#1841) | – |
| acknowledgment contention at the native rate, as #1841's reflector delivered it | +0.86 at 49k/s (`c6` − `c5`) | inside `u7`'s +1.1–1.5 over `u5`, with the hand-off | only by acknowledging or receiving less often | fork (acknowledgment frequency); fork and binding (`recvmsg_x`) |
| the send-queue hand-off | +0.30 (`c7` − `c6`) | inside `u7` | in part | fork (send queue) |
| acknowledgments arriving evenly instead of bunched | +0.16–0.24 (`c7p` − `c7`); the native's are bunched more than `c7`'s, so this does not apply at the default heap | **+0.75–0.79** (`u7p` − `u7`) | no: the pattern follows the peers | – |
| the native acknowledgment rate over the stand-in's | 0 (matched at 49k/s) | **+0.49** (`u7p42` − `u7p`, 42k/s against 38k/s) | only by acknowledging less often | fork |
| **remainder over the reproduction** | **−0.06 to +0.15** over `c7` (six sets), −0.12 and −0.01 against `c7p` | **−0.01** against `u7p42` | – | – |
| of which: shorter send runs | +0.11 (**derived**, interposer) | not measured | yes | fork (keep the send goroutine fed) |
| a consumer-sized heap (the map's Datagram GC pin) | **+0.18 to +0.44** (`dgramC-b64` − `dgramC`, five sets): the acknowledgment reads turn even and 3–5% more frequent | not measured | only as for acknowledgment contention | fork (and the binding, for batched receives) |
| per-datagram admission | +0.02 leaf; −0.06 µs of Go work on the send goroutine | (#1841: Go work only) | **no**: it is the contract | – |
| run-loop work on other goroutines (packing, sealing, per-acknowledgment work) | +0.00 (`c7w` − `c7`, counters and interposer) | −0.05 (`u7w` − `u7`, counters) | – | – |
| the heap's memory and allocator traffic on the sender | +0.03, +0.01, −0.01 (three raw controls) | – | – | – |
| Go scheduler with 16 processors against 4 | −0.10 leaf, −0.20 interposer (raw `c7`: +0.09 and −0.08) | not measured | not by wiremux: a process setting | the application, or the fork by handing off less |
| the core's clock | none: the native sender's is as high as the fastest raw rung's | none | – | – |

The rest of the note has the rungs, both shapes across the six sets, the acknowledgment patterns, what kind of time the extra cost is, the GC pin and the campaign.

## 1. The rungs

Every raw rung is one change to the sender, on the native call shape #1841 established (`sendmsg` with the destination and one ECN record on an unconnected socket with `IP_BOUND_IF`, `IP_DONTFRAG`, `IP_RECVTOS` and `IP_RECVPKTINFO`; connected, the same without the destination). The native rungs run the probe build: native unconnected (`dgram`) is today's native Datagram sender, native connected (`dgramC`) the same build with #1842's connect on both peers, the shape #1843 adopted.

| Rung | What it is |
| --- | --- |
| `u5`, `c5` | the native call shape, unconnected and connected, one goroutine, nothing arriving |
| `c6` | `c5` + acknowledgment stand-ins at 49,000/s read by a drain goroutine |
| `u7`, `c7` | the closest raw reproduction: the call, acknowledgment stand-ins (38,000/s unconnected, as in #1841; 49,000/s connected) and the send-queue hand-off |
| `u7p`, `c7p` | `u7`, `c7` with the reflector sending the stand-ins evenly (`-reflect-burst 1`) instead of each millisecond's quota at once |
| `u7p42` | `u7p` at 42,000/s, the native unconnected acknowledgment rate |
| `u7w`, `c7w` | `u7`, `c7` with the run loop emulated: the drain hands each acknowledgment to the producer, which processes it (800 ns of CPU and an AES-GCM seal) in the same select as the queue's availability signal and resets a timer every iteration; the producer seals each packet (AES-128-GCM and header protection) and spends 1,100 ns packing it; the drain spends 1,000 ns per acknowledgment |
| `c7-g4`, `dgramC-g4` | `c7` and native connected with `GOMAXPROCS=4` on the sender |
| `dgramC-na` | native connected with the binding's per-datagram admission skipped on receive and send (probe only) |
| `dgramC-b64` | native connected at the map's Datagram GC pin (`-ballast 64 -gc-role both`); `-b64s` with the ballast on the sender only, `-b64r` on the receiver only |
| `c7t32`, `c7t64m` | `c7` with the producer writing every byte of each payload before queueing it, cycling through 32 buffers or 53,000 (about 62 MiB) |
| `c7m4`, `c7m128` | `c7` with a goroutine writing 1,130 MB/s (the native sender's allocation rate) through 4 or 128 MiB |
| `c7a`, `c7a-b64` | `c7` with a goroutine allocating and dropping 560-byte slices at 1,130 MB/s, at the default heap or with a 64 MiB ballast on the sender |
| `streamC` | the native connected stream (counter and interposer sets only) |

## 2. The connected shape

Send leaf µs per call, median (min–max) of three recordings per set (**measured**; every set in `leaf-cross-set.md` in the evidence directory):

| Rung | `Y` | `Y2` | `Y3` | `Y4` | `Y5` | `Y6` |
| --- | --- | --- | --- | --- | --- | --- |
| `c5` | 2.40 (2.27–2.41) | 2.34 (2.31–2.50) | 2.54 (2.34–2.55) | 2.49 (2.40–2.53) | 2.46 (2.41–2.52) | 2.52 (2.40–2.54) |
| `c6` | 3.26 (3.23–3.41) | – | – | – | – | – |
| `c7` | 3.55 (3.46–3.68) | 3.59 (3.43–3.83) | 3.75 (3.54–3.76) | 3.70 (3.50–3.78) | 3.59 (3.54–3.71) | 3.67 (3.45–3.68) |
| `c7p` | 3.80 (3.76–3.81) | 3.75 (3.69–3.78) | – | – | – | – |
| **native connected** | **3.68 (3.64–3.73)** | **3.75 (3.74–3.90)** | **3.82 (3.63–3.85)** | **3.64 (3.64–3.79)** | **3.73 (3.67–3.75)** | **3.77 (3.70–3.87)** |
| native connected − `c7` | **+0.12** | **+0.15** | **+0.07** | **−0.06** | **+0.14** | **+0.10** |
| `dgramC-na` | 3.69 (3.67–3.83) | – | – | – | – | – |
| `dgramC-g4` / `c7-g4` | 3.57 (3.53–3.77) / 3.64 (3.53–3.68) | – | – | – | – | – |

In set `Y` the other system calls' leaf time per send (`recvmsg` / `kevent` / thread park and wake / `usleep`) was 0.40 / 0.48 / 0 / 0.02 µs for `c6`, 0.43 / 0.76 / 2.00 / 0.10 for `c7` and 0.57 / 0.67 / 1.06 / 0.52 for native connected; profiled, `c5` sent 407,552 packets/s, `c7` 242,546 and native connected 222,670 (**measured**).

How to read it:

- **The reproduction matches.** The native connected send sits at `c7` or a little above it in every set, within `c7`'s own range in all six, and between `c7` and `c7p` where both ran.
- **The acknowledgment rate is the native one.** The native connected receiver acknowledges 0.22 of the packets, 49,300/s profiled on `bridge0` (**measured**, set `Y`), not the 38,000/s #1841 assumed: the connected sender is 1.6–1.7× faster, but its receiver acknowledges a smaller share (0.31 unconnected), so the rate rose only from 42,300/s. At 49k/s acknowledgment contention adds 0.86 µs to the connected call within one set (#1841's +0.99 at 38k/s compared two sets).
- **#1841's estimate and #1842's derivation, reconciled.** #1841 estimated the connected native send at 2.61 + 1.0 + 0.05 + 1.1–1.5 = 4.8–5.2 µs in the leaf; it is 3.64–3.82, because the 1.1–1.5 was the unconnected stand-in's (section 3), while the hand-off costs 0.30, not 0.05. With the send goroutine's Go work (0.36–0.38 µs per datagram in `sendQueue.Run`'s Go frames, of which 0.06 is admission), a connected native packet costs 3.68 + 0.38 ≈ 4.06 µs in set `Y` (**derived**), against #1842's 7.75 / 1.70 ≈ 4.6, which assumed that the per-packet cost scales with the throughput ratio.
- **Admission is not in the send leaf**: skipping it on both sides moves the leaf by +0.02 µs and takes 0.06 µs of Go work off the send goroutine (0.318 against 0.376 µs per datagram) (**measured**).

## 3. The unconnected shape

Send leaf µs per call, median (min–max), three recordings per set (**measured**):

| Rung | `Y` | `Y2` | `Y3` | `Y4` | `Y5` | `Y6` | Acknowledgments |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `u5` | 4.13 (4.10–4.25) | 4.21 (4.13–4.23) | 4.25 (4.18–4.26) | 4.23 (4.23–4.27) | 4.19 (4.19–4.25) | 4.14 (4.09–4.20) | none |
| `u7` | 5.29 (5.21–5.53) | 5.35 (5.23–5.38) | 5.45 (5.36–5.62) | 5.50 (5.33–5.52) | 5.55 (5.52–5.64) | 5.59 (5.30–5.62) | 38,000/s, bunched |
| `u7p` | 6.04 (6.00–6.05) | 6.14 (6.10–6.57) | – | – | – | – | 38,000/s, even |
| `u7p42` | – | 6.63 (6.45–6.87) | – | – | – | – | 42,000/s, even |
| **native unconnected** | **6.40 (6.33–6.52)** | **6.62 (6.46–6.76)** | **6.71 (6.36–6.79)** | **6.32 (6.30–6.61)** | **6.68 (6.64–6.81)** | **6.53 (6.43–7.15)** | 42,300/s (`Y`), even |
| native − `u7` | +1.11 | +1.28 | +1.25 | +0.82 | +1.14 | +0.94 | |
| native − `u7p` / `u7p42` | +0.36 / – | +0.48 / **−0.01** | | | | | |

#1841's remainder reproduces at +0.82 to +1.28 µs, and a raw sender whose acknowledgments arrive evenly at the native rate matches the native send to 0.01 µs. The native rate is what its own pairs counted on `bridge0` (42,300/s profiled, 0.31 per packet). The step from 38k/s to 42k/s with even arrivals (+0.49 µs for 4,000/s more) is steeper than #1841's bunched dose-response suggested near 38k/s (about +0.25 for the same step, **derived** from its 38k/s and 76k/s points), as even arrivals are the costlier kind.

## 4. How the acknowledgments arrive

The gaps between consecutive acknowledgment reads on the sender, as shares of reads (**measured**: the native receive path's probe timestamps in `ReadUnicastBatch`, the raw drain's with `-drainstats`; sets `P` and `P2`, 8 s; `P`'s `c7` pair was re-run at 15:00 because the first overlapped a build of this session's):

| Pair | within 4 µs | 4–16 µs | 16–65 µs | 65 µs or more | Reads per second |
| --- | ---: | ---: | ---: | ---: | ---: |
| native unconnected | 9.7% | 27.1% | 60.7% | 2.4% | 44,067 |
| `u7` (default reflector) | 40.7% | 27.3% | 29.3% | 2.7% | 37,969 |
| `u7p` (even) | 1.4% | 7.8% | 90.8% | 0.1% | 37,994 |
| native connected (`P2`, two pairs) | 32.2–33.4% | 21.4–21.5% | 41.8–43.0% | 3.3–3.4% | 53,585–54,711 |
| `c7` (default reflector) | 15.2% | 24.6% | 58.9% | 1.3% | 48,986 |
| `c7p` (even) | 6.4% | 24.0% | 69.5% | 0.1% | 48,991 |
| native connected at the pin (`P2`) | 27.8–28.0% | 21.1–21.4% | 50.1–50.6% | 0.5% | 56,057–56,227 |

- **#1841's stand-in was bunched; the unconnected native acknowledgments are not.** The default reflector sends each millisecond's quota back to back; unconnected at 38k/s the reflecting receiver keeps up, so 41% of the stand-ins arrive within 4 µs of the previous one. The native receiver's acknowledgments spread across the 23 µs between them.
- **Connected, the default reflector is already nearly even.** Its receiving socket on m4mini also takes about 260k data packets/s, so each reflected send is slow and the millisecond's burst spreads over most of the millisecond. The native connected acknowledgments are bunched more than either connected stand-in's, and cost the same as `c7` (section 2): at the default heap the pattern no longer separates the native send from its reproduction. The connected native reads also carry a 3.3% tail of long gaps, which the collector's pauses on the two peers explain (they disappear at the pin, section 6).
- **Why even arrivals cost more** (**measured** and **source**). With the even reflector the raw unconnected sender makes 3.87 BSD system calls per packet instead of 3.42 and 1.51 context switches instead of 1.20 (set `Y`), because each stand-in is read on its own wake-up: a `kevent` delivery, a `recvmsg` that returns it and a `recvmsg` that returns `EAGAIN`. Each takes the receiving socket's lock (the `kevent` delivery in `filt_sorprocess`, [`uipc_socket.c` L6712-L6722](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket.c#L6712-L6722)), and the kernel's `udp_input` takes it once more per datagram and, while holding it, posts the knote under the kqueue's spin lock ([`udp_usrreq.c` L923](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L923), [`uipc_socket2.c` L646-L648](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket2.c#L646-L648), [`kern_event.c` L808-L858](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/kern_event.c#L808-L858)). Bunched arrivals share one wake-up and one `EAGAIN` among several datagrams. Every send holds the same lock (#1841, section 4).

## 5. What kind of time it is

**Per-call thread counters** (`-selfcount`, and the probe's `WIREMUX_PROBE1851_SELFCOUNT`): every 64th (set `S`) or 61st (set `Q`) send call is bracketed by `thread_selfcounts(2)` reads on the calling thread, which give that call's instructions, cycles and kernel time, after a fixed calibration loop that gives the core's clock at that moment. Means per sampled call on performance cores, two pairs per rung (**measured**; every rung in `counters-table.md` in the evidence directory):

| Rung | Set | Wall µs | Kernel µs | Instructions | Cycles p10 / p50 / p90 | Calibration GHz |
| --- | --- | ---: | ---: | ---: | --- | ---: |
| `c5` | `Q` | 2.70 | 2.60 | 28,193 | 7,744 / 9,400 / 11,846 | 3.99 |
| `c6` | `Q` | 3.56 | 3.41 | 28,304 | 7,777 / 10,821 / 19,739 | 3.35 |
| `c7` | `Q` | 4.12 | 3.90 | 28,761 | 8,251 / 12,346 / 25,011 | 3.84 |
| native connected | `Q` | 4.58 | 4.25 | 28,939 | 8,634 / 13,552 / 31,590 | 4.03 |
| native connected, `GOMAXPROCS=4` | `Q` | 4.43 | 4.13 | 29,183 | 8,522 / 13,181 / 30,290 | 4.01 |
| native connected at the pin | `Q` | 4.95 | 4.62 | 29,124 | 9,126 / 15,008 / 35,135 | 4.04 |
| native connected stream | `Q` | 4.41 | 4.15 | 28,774 | 8,420 / 13,319 / 31,810 | 4.01 |
| `u5` | `S` | 4.47 | 4.33 | 49,919 | 13,034 / 14,556 / 20,092 | 3.47 |
| `u7` | `S` | 5.99 | 5.75 | 50,864 | 13,551 / 17,610 / 32,815 | 3.30 |
| `u7p` | `S` | 6.99 | 6.70 | 51,372 | 15,471 / 22,116 / 36,139 | 3.33 |
| native unconnected | `S` | 7.55 | 7.22 | 51,208 | 15,682 / 23,809 / 47,126 | 3.95 |

- **Same instructions, more cycles.** Within a shape every rung, raw or native, runs the same kernel path to within 4% of its instructions; everything that makes a send dearer adds cycles, mostly in the slowest calls (p90). So none of it is a longer code path, retries or lock-spin loops that execute instructions. The unconnected path itself runs 21,000–23,000 more instructions per send than the connected one: the per-datagram work for a destination that connecting removes (#1841, section 5).
- **Not a slower clock.** The calibration loop just before each sampled call ran at 3.3–4.1 GHz, and the native senders' cores among the fastest (3.95–4.04 GHz). #1841's recordings agree: during native sends the send thread's cluster had 2.5–2.8 busy cores, against 3.1–3.4 during `u7`'s (**measured**, `xcluster.py` on #1841's set `X`), and in every recording here at most 0.7% of a recording's send leaf ran on efficiency cores.
- **The counters overstate the native-minus-raw difference**, so they are used for what kind of time it is, not how much. On this basis native connected costs 0.46–0.63 µs more than `c7`, against −0.06 to +0.15 on the leaf and +0.16 on the interposer, which both cover every call. A sampled call is preceded by three counter reads and a 2 µs loop, so it never runs inside a run of back-to-back sends, and its cost depends on where the sample falls: sampling every 64th call, which lines up with the send queue's batches of eight, adds 0.12 µs to the native send against every 61st (**measured**, `Q`).

**The interposer** (`tools/interpose`, a `DYLD_INSERT_LIBRARIES` library on the sender) timestamps every `sendmsg`, `recvmsg`, `kevent`, condition wait and signal and `usleep` call of the sender process, on every thread, for 3 s of each run. Means of two 8 s pairs per rung (**measured**; each call's wall time includes the interposer's two clock reads, the same for every rung). A run is a sequence of sends on one thread, each starting within 2 µs of the previous one's end:

| Rung | Send µs, every call | First of a run: µs (share) | 2nd–9th: µs (share) | 10th on: µs (share) | Per packet: `recvmsg` / `kevent` / waits / `usleep` | `kevent` per s: polls / blocking / timed |
| --- | ---: | --- | --- | --- | --- | --- |
| `c7` | 3.32 | 5.48 (5.8%) | 3.58 (28.3%) | 3.02 (65.9%) | 0.35 / 0.25 / 0.54 / 0.06 | 30,250 / 33,532 / 0 |
| `c7p` | 3.30 | 5.22 (5.3%) | 3.49 | 3.07 | 0.36 / 0.27 / 0.52 / 0.06 | 33,742 / 37,099 / 0 |
| `c7w` | 3.22 | 5.38 (4.6%) | 3.49 | 2.97 | 0.34 / 0.23 / 0.32 / 0.05 | 30,179 / 32,208 / 0 |
| `c7-g4` | 3.24 | 5.10 (5.3%) | 3.43 | 3.02 | 0.35 / 0.24 / 0.59 / 0.06 | 30,691 / 34,093 / 0 |
| **native connected** | **3.48** | 5.45 (7.0%) | 3.63 (43.8%) | 3.08 (49.3%) | 0.36 / 0.26 / 0.25 / 0.30 | 33,626 / 4,409 / 21,918 |
| native connected, `GOMAXPROCS=4` | 3.28 | 4.99 (6.6%) | 3.40 | 2.97 | 0.36 / 0.25 / 0.21 / 0.20 | 35,548 / 3,436 / 20,816 |
| native connected at the pin | 3.63 | 5.40 (6.7%) | 3.78 | 3.20 (44.8%) | 0.39 / 0.28 / 0.24 / 0.22 | 34,615 / 5,236 / 25,544 |
| `u7` | 5.21 | 8.08 (6.4%) | 5.77 | 4.66 (64%) | 0.33 / 0.15 / 0.98 / 0.06 | 10,171 / 10,089 / 0 |

- **The connected remainder is mostly run length.** At each position in a run the native send costs about what `c7`'s does, but its runs are shorter: the fork's send goroutine takes a batch of up to eight packets and then waits for the next, while `c7`'s producer refills an eight-slot queue packet by packet. Re-weighted to the native's mix, `c7`'s position costs give 3.44 µs: the mix explains 0.11 of the 0.16 µs and the per-position cost 0.05 (**derived**: 0.070 × 5,480 + 0.438 × 3,577 + 0.493 × 3,021 = 3,436 ns, against 3,321 and 3,483).
- **The native process makes as many system calls per packet as `c7`, of other kinds.** About the same number of `recvmsg` and `kevent` calls per packet, but its `kevent` waits are timed (its timers) rather than blocking, it makes half as many condition waits (one batch hand-off per eight packets instead of one per packet) and five times as many `usleep` calls (the Go scheduler's spinning processors). With `GOMAXPROCS=4` its `usleep` and waits fall and every position costs 0.1–0.5 µs less; at the pin every position costs 0.1–0.2 µs more.
- **The run loop's work on other goroutines does not reach the send.** Handing every acknowledgment to the producer, 800 ns of work on it, sealing and 1,100 ns of packing per packet, and 1,000 ns per acknowledgment on the drain (`c7w`) leave the send at 3.22 against 3.32 µs here and at 4.08 against 4.09 µs on the counters.

## 6. A consumer-sized heap (the Datagram GC pin)

The map runs Datagram comparisons at `-ballast 64 -gc-role both` because a consumer's own live data keeps Go's collector off its 4 MiB floor ([How much native Datagram throughput does Go's garbage collector take?](https://github.com/GridSwarm/wiremux/issues/1833#issuecomment-6158306566)). Send leaf µs per call (**measured**):

| Rung | `Y2` | `Y3` | `Y4` | `Y5` | `Y6` |
| --- | --- | --- | --- | --- | --- |
| native connected | 3.75 | 3.82 | 3.64 | 3.73 | 3.77 |
| native connected at the pin | 4.12 (4.00–4.12) | 4.00 (3.98–4.08) | 4.08 (4.04–4.11) | 3.94 (3.90–4.17) | 4.15 (4.03–4.33) |
| difference | **+0.38** | **+0.18** | **+0.44** | **+0.21** | **+0.38** |
| ballast on the sender only / receiver only | | | | +0.17 / +0.07 | |
| raw controls (each against its own base) | | payloads across 62 MiB against 32 buffers: +0.03 | a 1.13 GB/s write stream through 128 MiB against 4 MiB: +0.01 | | Go allocation stream at 1.13 GB/s: +0.06 over `c7`; with the 64 MiB ballast: −0.01 over that |

- **Not the heap's memory traffic.** The pinned native sender allocates 1.06–1.15 GB/s (the same as at the default heap), collects 18–20 times a second instead of 460–500, has a 130 MiB heap goal and takes about 590 page faults a second against about 110 (**measured**). The raw `c7a-b64` reproduces all of that (1.21 GB/s, 19 collections a second, a 129 MiB goal, about 550 page faults a second) and its send costs no more than the same stream at the default heap. Neither cold payloads nor a write stream larger than the cluster's 16 MiB cache moves `c7`.
- **The acknowledgment reads.** At the pin the native sender's reads lose their long gaps and bunch less (section 4: 65 µs or more 3.3–3.4% → 0.5%; within 4 µs 32–33% → 28%), and the receiver acknowledges 3–5% more of the packets (0.229–0.237 per packet, against 0.221–0.228; **measured**, sets `Y2`–`Y4` and `P2`). At the default heap the sender collects about every 2 ms and the receiver about every 3 ms (470 and 320 times a second in the campaign), and the pauses hold back the sender's reads and the receiver's acknowledgments, so acknowledgments queue and are read together. Even reads cost more (`c7p` − `c7`: +0.16–0.24), and 3–5% more of them at 0.86 µs per send for 49k/s is about +0.03–0.04 (**derived**); together about +0.2–0.3 µs, the size of the effect. The ballast on the sender alone gives most of it (+0.17) and on the receiver alone less (+0.07), in one set.
- **Same kind of time.** On the counters the pinned send runs the same instructions (29,124 against 28,939) with 1,800 more cycles, mostly in the slowest calls (p90 35,135 against 31,590); on the interposer every run position costs 0.1–0.2 µs more (**measured**).

## 7. The headline campaign

`rig1851.sh tb` (rig.sh with a private receiver directory and port and a per-run busy gate; measurement unchanged), `REPS=5 SECS=10`, rotation 0 a warm-up, arm order rotating, `LOADGATE=1` at `MAXLOAD=8`, built from the probe worktree at `c8283c93` (clean; Go 1.27.2), 2026-10-16 14:07–15:00 UTC with the pair claimed throughout: the standard slate and 16 of this ticket's arms. Two runs were flagged (`r2-udp` at 0.74× its median, `r3-c5` at 1.23×), no arm was noisy, and the runs waited only on load (37 waits of 30 s). Medians of five runs (**measured**; `C1/summary.txt` in the evidence directory):

| Arm | Mbit/s delivered (min–max) | Packets/s offered by the sender | Sender CPU per offered packet, µs: user / system |
| --- | --- | ---: | --- |
| native unconnected (`dgram`) | 1,246 (1,087–1,263) | 130,824 | 6.14 / 12.54 |
| native unconnected at the pin | 1,218 (1,199–1,257) | 127,796 | 5.29 / 12.86 |
| native stream | 1,430 (1,376–1,442) | 130,966 | – |
| **native connected** | **2,068 (2,021–2,099)** | **217,157** | 5.67 / 7.56 |
| **native connected at the pin** | **2,045 (2,011–2,067)** | **214,751** | 4.75 / 7.56 |
| native connected stream | 2,361 (2,303–2,437) | 216,154 | – |
| `c5` | 1,202 (receiver-bound) | 477,817 | 0.14 / 1.97 |
| `c6` | 1,908 | 292,964 | 0.50 / 4.12 |
| `c7` | 1,967 | 242,310 | 2.40 / 7.22 |
| `c7p` | 1,966 | 231,404 | 2.48 / 7.63 |
| `c7w` | 1,968 | 243,991 | 3.75 / 6.35 |
| `c7a` / `c7a64` | 2,109 / 2,010 | 227,646 / 226,234 | 7.11 / 7.74; 6.98 / 7.83 |
| `u5` | 1,274 (receiver-bound) | 257,894 | 0.21 / 3.70 |
| `u7` | 1,638 | 168,334 | 2.85 / 9.64 |
| `u7p` | 1,238 | 127,239 | 3.79 / 14.07 |
| `u7p42` | 1,146 | 117,927 | 4.04 / 15.47 |
| `u7w` | 1,577 | 161,999 | 4.52 / 9.52 |
| `udp` / `udp4` / `binding` | 1,507 / 1,791 / 1,037 | 200,457 / 285,431 / 190,205 | 0.20 / 4.85; 0.41 / 13.78; 0.36 / 4.95 |

- **The standard slate matches the earlier bases** (#1841's C1: native Datagrams 1,209 Mbit/s, stream 1,390; #1842's connected probe: 2.0–2.1 and 2.4 Gbit/s), and the even reflector costs the raw unconnected sender 24% of its rate (168,334 → 127,239 packets/s offered) and 4.4 µs of kernel CPU per packet: each stand-in read on its own wake-up.
- **Rates are whole send loops, not the per-call basis.** The raw hand-off parks and wakes its threads per packet and the native send goroutine adds 0.36–0.38 µs of Go work per packet, so a rung's rate does not follow its send leaf alone. Over the whole sender process the connected native spends as much kernel CPU per packet as its reproduction (7.56 µs against 7.22–7.63 for `c7` and `c7p`).
- **At the pin the native connected rate falls only 1.1%** (217,157 → 214,751 packets/s), less than its leaf's +0.18–0.44 µs per call would suggest, because the pin also removes most of the collector's work (the native sender's user CPU falls from 5.67 to 4.75 µs per packet).

## 8. What can go with admission unchanged

The admission contract is `COMPATIBILITY.md`'s `binding` section: every send and every received datagram is admitted against current identity, source, kernel ingress and an interface-restricted route lookup, and kernel ingress is checked per datagram ([`COMPATIBILITY.md`](https://github.com/GridSwarm/wiremux/blob/d30c3689454c0db2b008562d276d991fe642354f/docs/COMPATIBILITY.md#binding-introduced-in-v027)); the connected shape adds that a promoted macOS Wire's socket is connected to its peer (#1843).

- **The remainder: nothing to remove.** Connected, what is left over the reproduction is −0.06 to +0.15 µs, and the interposer puts most of it in the hand-off's run length. Unconnected there is none once the stand-in arrives like the native acknowledgments.
- **Admission: not in the send.** Skipping it on both sides changes the connected send's leaf by +0.02 µs and its counters by −0.05 to −0.06 µs, and removes 0.06 µs of Go work per datagram from the send goroutine (**measured**). It stays.
- **Acknowledgment contention (+0.86 µs at 49k/s; more for even arrivals, which a consumer-sized heap brings): only by receiving less often.** Fewer acknowledgments ([How much native send cost and throughput would fewer acknowledgments buy on macOS?](https://github.com/GridSwarm/wiremux/issues/1854), the fork's acknowledgment frequency) or batched receives that read several queued acknowledgments per wake-up ([Should macOS receives be batched with recvmsg_x in the fork and wiremux?](https://github.com/GridSwarm/wiremux/issues/1816)). Neither changes admission. Because even arrivals cost more than bunched ones, a receiver that acknowledges less often and in bursts would gain on both counts.
- **The hand-off and its run length (+0.30 and +0.11 µs): the fork's send queue.** A send goroutine that finds the next batch already queued sends longer runs. The 32-entry send queue adopted in [Should the fork raise its packet send queue from 8 to 32 entries?](https://github.com/GridSwarm/wiremux/issues/1850#issuecomment-6207580215) may lengthen them (not measured here), and batched connected sends ([How much would batched connected sends add to the native macOS sender?](https://github.com/GridSwarm/wiremux/issues/1856)) would amortize the hand-off along with the call.
- **`GOMAXPROCS` (−0.10 to −0.20 µs per send): not wiremux's.** It is the application's process setting, which a library cannot set; fewer goroutine hand-offs per packet in the fork would cut the scheduler's spinning the same way.

## Method

**Rig additions** (`codex/native-gap-rig` [c6664ce0, 8aaa9c0e, 19b05cc4 and 5beb019a](https://github.com/GridSwarm/wiremux/compare/48583edf...5beb019a), documented in PROTOCOL.md; every flag is sender-only except `-reflect-burst`, so all rungs of a shape share one receiver):

- `-reflect-burst N` (receiver) sends `N` reflected datagrams back to back every `N`/rate seconds, paced by spinning; `-reflect-burst 1` is a uniform arrival. Without it the reflector sends each millisecond's quota at once, which is what #1841's rungs did.
- `-drainstats` records the gaps between consecutive drain reads.
- `-ackchain` makes the drain hand each acknowledgment to the hand-off's producer, which processes queued acknowledgments every iteration and in the same select as the queue's availability signal and resets a timer every iteration, the shape of the fork's connection run loop; `-ackwork NS`, `-packwork NS` and `-drainwork NS` add calibrated CPU per acknowledgment on the producer, per packet on the producer and per datagram on the drain; `-seal` makes the producer AES-128-GCM-seal and header-mask every packet. The `w` rungs use `-ackchain -ackwork 800 -seal -packwork 1100 -drainwork 1000`, sized from #1841's native profile: the run loop spends about 1.6 µs per packet, 0.26 of it handling received packets (about 0.8 µs per acknowledgment), and the receive goroutine about 1.3 µs of Go work per acknowledgment.
- `-memstream MIB` (with `-memrate MB/s`) runs a goroutine that writes through a `MIB`-MiB buffer at that rate; `-allocstream MB/s` runs one that allocates and drops 560-byte slices at that rate through Go's allocator and collector; `-spin N` runs spinning goroutines (not used in the evidence sets).
- `-selfcount N` brackets every `N`th send call with the calling thread's own counters from `thread_selfcounts(2)` ([`sys_recount.c` L175-L196](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/sys_recount.c#L175-L196): per perf level, instructions, cycles, user and system time; no root), after a fixed calibration loop that gives the core's clock at that moment; `-selfcount-out` writes the raw samples.
- Every result line's `proc` record gains the process's BSD and Mach system calls, context switches and page faults over the run (`proc_pidinfo(PROC_PIDTASKINFO)`).

**Probe build** (never pushed; detached worktree `1851-probe`, local commits on #1842's `dc7cb39a`; diffs and recipes in the evidence directory): `origin/main` d30c3689, #1842's connected-socket probe, the rig above, #1841's probes (the IPv4 send part of the adopted binding allocation slice, the native send counters and their JSON line), and this ticket's instrumentation: the same per-call counters on native sends and receives, the gaps between received datagrams in `ReadUnicastBatch`, and a switch that skips the binding's per-datagram admission on receive and send (probe only). #1842's connect is on only with the rig's `-connectpeer` on both peers, so one binary runs every raw rung and both native shapes, as #1841's did. `probe2` adds `-memstream` (sets `Y4`, `Y5`, `P2`), `probe3` adds `-allocstream` (`Y6`, and the campaign builds the same source).

**Interposer** (evidence `tools/interpose`): a `DYLD_INSERT_LIBRARIES` library on the sender only that timestamps every `sendmsg`, `recvmsg`, `sendto`, `kevent`, condition wait and signal and `usleep` call, on every thread, for a 3 s window, and writes them from an `_exit` hook (Go exits through `_exit`, which runs no destructors). It needs no root. `dyldexec` sets its variables right before the exec, because `env` and `perl` are protected by System Integrity Protection and dyld drops `DYLD_*` variables for them.

**Sets** (hand-run `tb` pairs, never inside a campaign; 8 s sends; the spec order rotating every repetition; every pair gated and claimed):

| Set | What | Pairs | UTC |
| --- | --- | ---: | --- |
| `S0` | smoke: patterns, rates, counters and the interposer once each (5 s; never evidence for leaf time) | 11 | 07:47–08:01 |
| `S` | per-call counters, every 64th call, 15 rungs × 2 | 30 | 08:03–08:56 |
| `Y` | untraced system-wide Time Profiler, 12 rungs × 3 | 36 | 08:56–10:25 |
| `Q` | per-call counters, every 61st call, 9 rungs × 2 | 18 | 10:25–11:19 |
| `Y2` | Time Profiler, 10 rungs × 3 | 30 | 11:19–11:50 |
| `P` | arrival patterns, 7 rungs × 1 | 7 | 11:50–11:53 (`c7` re-run 15:00) |
| `I` | interposer, 9 rungs × 2 | 18 | 11:53–11:59 (`dgram` re-run 15:00–15:01) |
| `Y3` | Time Profiler, 9 rungs × 3 | 27 | 11:59–12:28 |
| `Y4` | Time Profiler, `probe2`, 9 rungs × 3 | 27 | 12:28–12:55 |
| `Y5` | Time Profiler, `probe2`, 9 rungs × 3 | 27 | 12:55–13:20 |
| `P2` | arrival patterns at the pin, `probe2`, 4 rungs × 2 | 8 | 13:20–13:23 |
| `Y6` | Time Profiler, `probe3`, 9 rungs × 3 | 27 | 13:23–13:44 and 13:49–14:07 |
| `C1` | headline campaign | 126 runs | 14:07–15:00 |

Each profiled pair records a system-wide Time Profiler session on mbp128 that starts before the sender and outlives it; #1841's `xsend.py` takes the sender process's on-CPU samples, sums the send leaf and divides by the send calls (raw: packets plus failed; native: the probe's datagram count). Acknowledgment rates are the sender's `bridge0` input packets per send second for the native arms and the drain's reads for the raw ones; the reflector keeps sending until its receiver times out, so `bridge0` overstates the raw rungs' rate.

**Sharing the pair.** Two other sessions used `tb` in the window: [Does Darwin recvmsg_x save receiver CPU when the queue is full?](https://github.com/GridSwarm/wiremux/issues/1815) ran three headline campaigns (04:07–07:42) and profiled pairs, and [Does the native send goroutine leave macOS performance cores under host load, and can a thread priority class keep it there?](https://github.com/GridSwarm/wiremux/issues/1853) ran natural-load runs and its main sequence. This session prepared while #1815's campaigns ran and never interleaved with a campaign. Every pair started only when no other session's sender, receiver, recording or claim ran on either Mac and both Macs' load1 was at most 8, then held a claim (a placeholder named like the rig on m4mini) verified twice for races, and yielded 40 s after each pair while another session's driver was alive; #1853's sequence interleaved with it pair by pair under its own claims. A 2-second logger recorded every other session's `tb` process from 06:46 to 15:03, and no pair window (266) or campaign run (126) overlapped another session's sender, receiver, recording or claim. This session's own mistakes were quarantined and re-run (the evidence README lists them): a smoke pass whose senders never started, a pattern pair and three profiled pairs that overlapped this session's own builds (a few seconds on efficiency cores), two interposer pairs that ran without the interposer, and four profiled pairs damaged when the host's disk filled (below).

**The disk.** Instruments leaves a 2–4 GB raw kernel trace (`instruments*.ktrace`) in the user's temporary directory after every recording, even after its `.trace` bundle is exported and deleted. This ticket's 164 profiled pairs left 324 GB, which filled the shared data volume at about 13:35 UTC; the chain was stopped, the 164 files (each matched to one of this ticket's pairs by its creation time) were deleted, and `pair.sh` now deletes its own recording's file after the export. Other sessions' runs in about 13:35–13:50 may have failed for lack of space.

## Limits

- No root: no kernel call stacks. The kernel explanations are source reading against the closest published xnu, and what kind of stall the extra cycles are (a lock waited on with wait-for-event, or cache misses on lines another core wrote) is not resolved.
- The leaf and the interposer cover every call; the counter basis samples one call in 61 or 64 after a pause of its own and overstates native-minus-raw differences (section 5), so it is used only for instructions against cycles and for the clock.
- Sets differ by up to about 0.2 µs on the same rung (native connected 3.64–3.82, `c7` 3.55–3.75, native unconnected 6.32–6.71), so differences are taken within a set, and the connected remainder is given as its range over six sets.
- No reflector setting reproduces the native connected acknowledgment pattern: the native's are bunched more than `c7`'s and `c7p`'s. The pin's attribution to the acknowledgment reads is by elimination (three raw controls) and direction (the measured patterns and `c7p` − `c7`), not by a rung that reproduces the pinned pattern.
- The role split of the pin is one set; its sender-only and receiver-only effects (+0.17, +0.07) are near the spread.
- The run-loop emulation spends its CPU spinning on the clock (except the AES-GCM work), so it does not reproduce the run loop's memory footprint; the allocation-stream control covers the heap's.
- `GOMAXPROCS=4` was set on the sender only, and only on the connected shape.
- Acknowledgment rates differ between profiled and unprofiled runs (native connected 49,300/s profiled, 53,600–54,700/s unprofiled); the stand-in's 49,000/s matches the profiled basis the leaf uses.
- The receivers were not measured.
- The interposer adds two clock reads to every call it times, the same for every rung.

## Implications for the map

- **[Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801):** on the connected macOS shape the native send is fully accounted for. Per packet on this basis it is the call (2.3–2.5 µs), acknowledgment contention (0.86 µs at 49k/s, 0.2–0.4 µs more at a consumer-sized heap), the hand-off (0.30) and its run length (0.11), plus 0.36–0.38 µs of Go work: about 4.1 µs at the default heap and 4.2–4.5 at the pin (**derived**), so the send goroutine's ceiling on this basis is about 245k packets/s at the default heap and 220–235k at the pin (**derived**: 1 / 4.06 µs and 1 / 4.24–4.50 µs; profiling slows senders by 5–11%, #1841). No further native-only send cost waits to be found; the remaining macOS send levers are fewer acknowledgments or batched receives (the 0.9–1.3 µs around the call) and batched connected sends (the call and the hand-off).
- **[How much native send cost and throughput would fewer acknowledgments buy on macOS?](https://github.com/GridSwarm/wiremux/issues/1854):** the connected inbound cost is 0.86 µs per send at the native 49k/s with the near-even default reflector, and even arrivals cost more than bunched ones (+0.16–0.24 µs connected, +0.75–0.79 unconnected). A fewer-acknowledgments rung should model the rate and the pattern on the native pairs (`-reflect-burst`), at the GC pin as well as at the default heap, where the pattern turns even.
- **[How much would batched connected sends add to the native macOS sender?](https://github.com/GridSwarm/wiremux/issues/1856):** the per-packet hand-off (0.30 µs) and the cost of each batch's first send after a pause (about 2 µs, 7% of the native sends) are what a batched send would amortize besides the call; the acknowledgment contention is per lock acquisition and would be taken once per batched call.
- **[Should macOS receives be batched with recvmsg_x in the fork and wiremux?](https://github.com/GridSwarm/wiremux/issues/1816):** batched receives would read several queued acknowledgments per wake-up on the sender too, which is what makes bunched arrivals cheaper; the sender side of that saving is unmeasured.
- **[Does the native send goroutine leave macOS performance cores under host load, and can a thread priority class keep it there?](https://github.com/GridSwarm/wiremux/issues/1853):** in 174 recordings at load1 ≤ 8 at most 0.7% of any recording's send leaf ran on efficiency cores, and the native senders' cores ran as fast as the fastest raw rung's (3.95–4.04 GHz).
- **The rig.** #1841's `-reflect` stand-in delivers acknowledgments in per-millisecond bursts that the unconnected native path never sees; raw inbound rungs should use `-reflect-burst 1` at the rate the native pairs count on `bridge0`. Instruments' leftover kernel traces need deleting after every recording (this ticket's `pair.sh` does; #1841's and others' did not, and earlier tickets' files are still in the user's temporary directory).

## Open questions

These are candidate tickets only where noted; none is filed.

1. **Does the adopted 32-entry send queue lengthen the native send goroutine's runs on macOS?** The connected remainder that is left (about 0.11 µs) is runs cut short by the batch hand-off; one `tb` A/B with the fork's 32-entry queue would say whether it goes. Small; it can ride on the fork bundle's own gate runs.
2. **What exactly do the extra cycles stall on?** Lock waits on the receiving socket or misses on lines the receive path wrote. It decides nothing now (every cost is attributed and its levers are known), so root on mbp128 is not proposed; if a later lever needs it, one `sudo` Instruments recording with kernel call stacks of `c5`, `c6` and native connected in one window would answer it.
3. **How much of the connected inbound cost do the receiver's acknowledgment pattern and its collector set?** The pin made the native acknowledgments even and dearer; a reflector that replays a measured native gap distribution (for example from `ReadUnicastBatch` timestamps) would reproduce the pinned pattern directly. Input for the fewer-acknowledgments ticket.
