# QUIC Datagram conformance evidence

Current dependency and profile evidence is recorded in the [quic-go v0.62.0 source audit](quic-go-v0.62-source-audit.md). The v0.61.0 and 1280-byte profile statements below describe the historical carrier introduction and re-attestation.

Implementation evidence for the QUIC carrier accepted by
[ADR-0009](../adr/adr-0009-optional-datagram-capability.md). This record is
version-bound to wiremux's pinned `github.com/quic-go/quic-go v0.61.0`, the
explicit `InitialPacketSize` of 1280 in `transport/quic`, and the implementation
and tests in the PR that adds the carrier. Re-audit this record when any of
those inputs change.

## quic-go v0.61.0 re-attestation

[Issue #791](https://github.com/GridSwarm/wiremux/issues/791) re-attested the dependency-sensitive facts below by comparing quic-go's immutable v0.60.0 and v0.61.0 tags:

- [`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.61.0/datagram_queue.go#L12-L132) and [`internal/wire/datagram_frame.go`](https://github.com/quic-go/quic-go/blob/v0.61.0/internal/wire/datagram_frame.go#L10-L81) are unchanged, preserving the 32-entry send queue, 128-entry receive queue, blocking admission, receive copying, and `wire.MaxDatagramSize` value of 16,383.
- [`Conn.SendDatagram`](https://github.com/quic-go/quic-go/blob/v0.61.0/connection.go#L3023-L3044) and [`estimateMaxPayloadSize`](https://github.com/quic-go/quic-go/blob/v0.61.0/connection.go#L3145-L3150) are unchanged, preserving copy-on-send and the `mtu - 1 - 20 - 16` conservative payload estimate.
- The directional [`ConnectionState.SupportsDatagrams`](https://github.com/quic-go/quic-go/blob/v0.61.0/interface.go#L200-L208) surface is unchanged.
- wiremux still explicitly configures the 1280-byte initial-packet baseline, so the unchanged estimate yields 1243 bytes before the length-bearing DATAGRAM-frame overhead.
- The upstream teardown artifacts [`write on closed stream`](https://github.com/quic-go/quic-go/blob/v0.61.0/send_stream.go#L218-L223) and [`close called for canceled stream`](https://github.com/quic-go/quic-go/blob/v0.61.0/send_stream.go#L567-L571) remain present on the wiremux-used `Write` path. quic-go v0.61.0 also emits the same write artifact from [`tryWriteAll`](https://github.com/quic-go/quic-go/blob/v0.61.0/send_stream.go#L149-L163) behind `TryWriteAll`, which wiremux does not call; the existing prefix matcher covers the identical top-level artifact from either site.

The 1240-byte internal ceiling, 1239-byte public ceiling, and 1243-byte profile floor therefore remain correct and are not rebaselined.

## Capability and path binding

- Both wiremux QUIC configurations set `EnableDatagrams` and an explicit
  `InitialPacketSize` of 1280. Datagram-capable sessions offer ALPN
  `wiremux-quic/2` before legacy stream-only `wiremux-quic/1`; a session whose
  published frame-size policy is below 1243 omits `/2`. A returned stream
  reports a carrier only when `/2` was selected and the completed connection
  state has both `SupportsDatagrams.Local` and `.Remote` set. This follows RFC
  9221's directional
  [`max_datagram_frame_size` negotiation](https://www.rfc-editor.org/rfc/rfc9221.html#section-3)
  and quic-go's immutable v0.61.0
  [`ConnectionState` surface](https://github.com/quic-go/quic-go/blob/v0.61.0/interface.go#L200-L208).
- `streamConn.DatagramCarrier`, reliable stream I/O, and aggregate teardown all
  retain the same `*quic.Conn`. That connection is created over the existing
  selected-remote packet filter, certificate-pinned TLS configuration,
  `quic.Transport`, and transferred punched packet socket. There is no second
  socket, connection, route selection, or authentication path.
- The carrier lifetime is a cause-bearing child of the quic-go connection
  context, so ordinary local or peer connection termination preserves the
  native cause. A native send failure cancels that child synchronously with the
  send error before invoking aggregate owner cleanup; no later admission can
  succeed during QUIC's graceful-close window.
- Existing selected-remote and certificate-pin tests remain the injection
  boundary. The production-Wire contract test additionally establishes both
  planes through relay rendezvous, authenticated probing, and the ordinary
  direct-upgrade commit path.
- Each role validates its local optional carrier before the next control
  transition, then `connect` synchronizes exposure through the existing
  post-commit extension map. `"wiremux.datagram/1": true` flows through
  accepted, converged, and confirmed as an intersection and exact echo;
  omission means absence, malformed values or contradictory echoes fail
  convergence, and mixed-version or one-sided exposure resolves to absence on
  both roles.

## Security and duplicate suppression

- QUIC protects DATAGRAM frames with the same packet protection and connection
  authentication as stream frames. RFC 9221 requires DATAGRAM frames to be
  protected like other QUIC frames and forbids their use before handshake
  confirmation where replay would be unsafe
  ([RFC 9221 §5.5](https://www.rfc-editor.org/rfc/rfc9221.html#section-5.5)).
- wiremux disables session tickets and 0-RTT, requires TLS 1.3, and pins the
  peer's per-upgrade certificate fingerprint delivered over the authenticated
  upgrade channel. Therefore the carrier does not add a replayable early-data
  path or a weaker peer-binding path.
- The selected-remote packet adapter drops traffic from addresses other than
  the authenticated candidate selected by the upgrade. Existing adapter and
  QUIC transport tests cover mismatched sources and certificate fingerprints.

## Atomicity and no controlled-layer retransmission

- One payload admitted by the lower adapter queue is offered to quic-go at
  most once and maps to at most one QUIC DATAGRAM frame. A carrier lifetime
  ending before dequeue may discard it; wiremux never fragments or retries it.
  RFC 9221 states
  that DATAGRAM frames are not retransmitted after loss and must fit within one
  QUIC packet
  ([§5](https://www.rfc-editor.org/rfc/rfc9221.html#section-5),
  [§5.2](https://www.rfc-editor.org/rfc/rfc9221.html#section-5.2)).
- Lower admission reserves bounded capacity, then rechecks call cancellation
  and carrier lifetime under the same gate used to publish lifetime closure.
  Enqueue is provisional; the gate-serialized resolution commit is the
  admission protocol. A per-admission `context.AfterFunc` stop handshake is
  followed by a lifetime-state recheck; that successful recheck is the commit
  linearization point against carrier cancellation. A rejected provisional
  entry is discarded before the native sender, while an admitted call returns
  success only after the commit wins.
  Deterministic released-slot cancellation and lifetime-race tests pin the
  coherent outcome.
- quic-go v0.61.0 documents the same behavior at
  [`Conn.SendDatagram`](https://github.com/quic-go/quic-go/blob/v0.61.0/connection.go#L3023-L3044)
  and its loss integration test demonstrates missing marked DATAGRAM frames
  without later replay
  ([source](https://github.com/quic-go/quic-go/blob/v0.61.0/integrationtests/self/datagram_test.go#L216-L338)).
- Opaque recovery below UDP remains outside wiremux's controlled-layer claim,
  as recorded in ADR-0009.

## Congestion authority and overload

- Reliable stream frames and DATAGRAM frames are scheduled by the same
  `*quic.Conn`. RFC 9221 requires DATAGRAM frames to use the connection's
  congestion controller
  ([§5.4](https://www.rfc-editor.org/rfc/rfc9221.html#section-5.4)). No separate
  pacing or congestion API exists in the adapter.
- quic-go's v0.61.0 bounded queues and silent overload drops are contained
  behind the adapter and root handles. The source audit covers its 32-entry send queue,
  128-entry receive queue, copy behavior, and close wakeups
  ([`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.61.0/datagram_queue.go#L12-L132)).
  The QUIC adapter adds an eight-entry copied admission queue so lower
  `SendDatagram` waits are context-cancellable despite quic-go's non-contextual
  API; root adds its separate eight-entry consumer admission queue. Both layers
  serialize their send boundary, and root copies again at the public boundary.
  Native send failure first cancels carrier `Lifetime` with the native cause,
  then invokes the owning `StreamConn` teardown, whose hardened path progresses
  connection, transport, and packet-socket closure concurrently after its grace
  period. `streamConn.Close` preserves the full reliable-stream grace, then
  closes the parent connection to wake a blocked quic-go send and joins the
  worker before returning.
  `TestDatagramAdapterSendAdmissionUnblocksOnCallAndLifetimeCancellation`,
  `TestDatagramAdapterCanceledWaiterCannotCrossReleasedAdmissionSlot`,
  `TestDatagramAdapterLifetimeRaceHasCoherentAdmissionOutcome`,
  `TestDatagramAdapterCopiesPayloadOnAdmission`,
  `TestDatagramAdapterNativeSendFailureSynchronouslyStopsAdmission`,
  `TestDatagramAdapterAtCeilingNativeSizeRejection`,
  `TestDatagramSaturationDoesNotTruncateReliableClose`,
  `TestDatagramReceiveOverflowDoesNotDamageReliableStream`, and
  `TestDatagramNativeSendSaturationUnblocksOnAggregateClose` exercise both
  native queue edges. The latter also guards adapter teardown ordering:
  parent connection close precedes normal transport and packet-socket release;
  forced parallel resource teardown is reserved for abort cleanup. A blocked
  packet write therefore cannot prevent its own wakeup, and the worker is
  joined before aggregate close returns.
- `TestDatagramAdapterTreatsPostAcceptanceSilentDropAsOrdinaryLoss` injects a
  native adapter double with quic-go's documented post-admission packer-drop
  semantics: accepted sends have no receive or lifetime signal, later sends
  remain admissible, and the carrier stays live. This adapter-semantics test
  distinguishes ordinary silent loss from the explicit at-or-below-ceiling
  rejection that terminates the carrier; the adjacent source audit establishes
  where quic-go performs the silent pop.

## Payload ceiling

- With quic-go v0.61.0 and `InitialPacketSize = 1280`, the conservative
  short-header packet-payload estimate is 1243 bytes: 1280 minus 1 byte of
  short header, 20 bytes of connection ID, and 16 bytes of AEAD overhead. A
  length-bearing DATAGRAM frame at this size consumes one type byte and a
  two-byte length, leaving an audited 1240-byte lower Data ceiling. The
  calculation is grounded in quic-go's
  [`estimateMaxPayloadSize`](https://github.com/quic-go/quic-go/blob/v0.61.0/connection.go#L3145-L3150)
  and `SendDatagram` limit calculation. wiremux reserves one discriminator
  octet, yielding the public 1239-byte exact ceiling.
- The adapter rejects a lower payload larger than 1240. If quic-go explicitly
  rejects a payload at or below that frozen ceiling, the adapter terminates the
  carrier as an observed contract breach; root preserves the lifetime cause
  and closes the whole Wire rather than mutating the advertised value or
  fragmenting. A frame accepted and silently dropped later remains ordinary
  permitted loss.
- quic-go exposes only positive/absent peer Datagram support, not the peer's
  numeric `max_datagram_frame_size`. Consequently `/2` selection is an
  application-profile assertion that the authenticated peer honors the
  1243-byte floor; wiremux cannot independently verify that numeric value at
  runtime. A nonconforming `/2` peer can therefore trigger the documented
  at-or-below-ceiling contract-breach teardown.

## Executable coverage

- `transport/quic` tests bidirectional negotiation, exact lower ceilings,
  full-duplex Datagram exchange, both mixed-support orientations, marked packet
  loss without Datagram retransmission, receive overflow, native-send close,
  and reliable stream coexistence. Existing certificate-pin and selected-source
  tests exercise the same connection and packet filter used by both planes.
  ALPN coverage pins `/2` preference, `/1` mixed-support fallback, and omission
  of `/2` when the local profile-policy input is below the 1243-byte floor. The
  pinned quic-go API cannot inject a foreign peer's smaller positive native
  limit; that case remains source-audited with fail-closed contract-breach
  behavior for a nonconforming peer that selects `/2`.
- Root tests cover framing, zero-length payloads, reserved-frame drops, fixed
  public ceilings, local oversize and cancellation, ownership copies, close
  precedence, idle cause-bearing lifetime termination, aggregate failure, and
  classified reliable `Read` failures while carrier lifetime remains active.
  Those failures close the Datagram gate and release its workers without
  closing the independent reliable write direction. A separate lifetime
  observer remains active after gate closure, so later carrier termination
  still starts exactly-once aggregate stream teardown. Companion cases keep
  `channel.ErrStreamEmptyDataFrame` and an unclassified write error local while
  reliable traffic and Datagrams remain usable. Continuous empty-native and
  reserved-discriminator carrier doubles prove that every discard rechecks
  closed-Wire and call-context state without starving cancellation or close.
  Lower receive-result tests distinguish non-nil empty success, terminal error,
  payload-plus-error, and nil-plus-nil; invalid tuples deliver nothing and fail
  closed with a preserved lower or internal nonconformance cause. Post-admission
  unclassified lower send errors with a live lifetime are silent loss, while a
  classified at-ceiling rejection remains a terminal carrier breach.
  Aggregate teardown uses one synchronized close authority for public close
  and carrier failure: the underlying stream is closed once, concurrent callers
  join it, and the first close result is retained. Race
  coverage uses a stream double that panics on a second close and separately
  pins follow-up `net.ErrClosed`, repeated `io.EOF`, and unclassified errors.
- `wiremuxtest.RunDatagramContract`, `RunDatagramAbsenceContract`,
  `RunDatagramMalformedContract`, and
  `RunDatagramPostCommitMalformedContract` are exercised against fresh
  production relay-to-direct QUIC, both mixed-peer orientations, direct
  stream-only, malformed-capability, and relay Wire pairs. Asymmetric
  carrier-ceiling decorators pin directional bounds. The runners cover exact
  public boundaries in both roles, bidirectional/concurrent use, reliable
  coexistence, non-terminal local errors, ownership, aggregate and peer close
  in both roles, synchronized absence, accepted-transport malformed failure
  before observed commit, and exact post-commit pairwise failure. Focused
  `connect` coverage also pins typed-nil carrier and lifetime rejection without
  invoking methods and listener accepted-stream/socket cleanup before commit.
  Delivery assertions use bounded, uniquely matched retries because ordinary
  Datagram loss is permitted; deterministic helper fixtures drop the first
  frame in both directions and reject corruption, wrong-direction delivery,
  and persistent non-delivery.
- The required race gate runs the focused root lifecycle, QUIC adapter, and
  production-establishment Datagram tests under `-race`, in addition to the
  existing relay and `wiremuxtest` race packages.

Executable behavior does not replace this evidence for security,
retransmission, path binding, and congestion sharing.

## Source-compatibility inventory

Adding `UpgradeResult.Datagrams` is the accepted pre-release exception for
external unkeyed composite literals. A local search of the available codemux
checkout and a GitHub code search across `GridSwarm/wiremux`, `codemux`, and
`keymux` found no downstream `connect.UpgradeResult` literals. wiremux's own
literals are zero values or keyed. No downstream migration is required for
this field addition; the PR still calls out the source-compatibility break so
unindexed consumers can replace positional literals with keyed literals.
