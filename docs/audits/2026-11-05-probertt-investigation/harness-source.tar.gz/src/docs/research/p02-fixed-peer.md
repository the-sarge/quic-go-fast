# P02 fixed-peer wrapper evaluation

## Scope and selection

**Decision: keep wiremux's selected-peer wrapper.** P02 ships documentation and evidence only. The existing adapter and wrapper remain unchanged; no native-selection build tag or second production enforcement path is added.

The [P02 contract](../adr/2026-09-15-wiremux-packet-io-plan.md#p02--evaluate-and-selectively-remove-wiremux-peer-wrapper) evaluated removing the wrapper for direct concrete UDP sockets. After reviewing the inconclusive performance results and the limited maintenance benefit while fallback wrappers remain necessary, the owner chose retention. This supersedes the original deliverable to ship an equivalence-qualified selectable path. Future removal would require a new explicit decision; later qualification uses the retained wrapper.

The experimental implementation is preserved at `253361b2755278f89295b5df774f422ba866cc0c` in PR #1551's history and in the frozen binaries. It used `-tags=wiremux_native_fixed_peer` and required `ConfigureFixedPeerV1`, `ConfigureExternalPacketIOV1` and `UDPBatchWriterV1` before initialization. Those experimental source/test files are excluded from the merged product diff. The fork's native fixed-peer policy remains a documented optional **fork** capability, not a wiremux configuration option.

## Source audit and ownership

The compared fork is `a9b10a10260f2f7bdda6b2ba20b72146e7bdd8cc`, including [P01-B](https://github.com/the-sarge/quic-go-fast/pull/352). Its `packet_policy.go` copies the remote address and binds the local `*net.UDPConn`; `beginPacketIOLocked` rejects replacement of that connection. `packetPolicyConn.ReadPacket` filters before transport routing, including known connection IDs and non-QUIC traffic. `packetPolicyConn.WritePacket` checks ordinary, stateless and segmented output; `sconn.sendBatch` checks the same policy before invoking an external registered callback. Native batch writes use that policy too. Fixed-origin connections and fixed target transports reject alternate path attachment. The policy neither acquires socket Close ownership nor replaces TLS certificate fingerprint authentication.

The fork's `fixedPeerPolicy.allows` and wiremux's UDP branch of `ObservedAddrMatchesSelectedRemote` use the same port equality, `net.IP.Equal` semantics for IPv4/mapped addresses, and directional zone predicate: equal zones or an unscoped selected address. Native configuration additionally rejects invalid IPs, unspecified peers and invalid ports. Non-UDP representations remain on the existing wrapper path. Arbitrary in-process descriptor users and concurrent public-field mutation are outside this trusted dependency contract.

In the experiment, peer enforcement had exactly one owner per selected path: the acknowledged fork policy for tagged direct UDP, otherwise the existing wiremux filter. In the retained product, the existing wiremux wrapper remains the peer-filtering owner. The packet lifecycle and stream continue to own disposal; the immutable grant continues to own receive-format permission. No new lifecycle, global registry, runtime setting or temporary duplicate owner is introduced.

## Finite experimental correctness evidence

| Semantic class | Enforcement owner | Evidence |
| --- | --- | --- |
| Selected input/output and foreign source/destination | Wrapper or acknowledged fork policy | `TestQUICFixedPeerPreservesSelectedEndpoint`, in upstream and pinned-fork module selections |
| Exact owned/borrowed/different socket permission | Existing immutable grant and exact registration | `TestQUICFixedPeerPreservesPermissionAndOpaqueFallback` plus existing wrapper registration fixture |
| Opaque input and proven managed lease | Existing selected wrapper | Opaque regression; existing managed binding and production-Wire fixtures with native selection requested |
| Invalid peer before initialization | Fork setter; caller retains socket | `TestQUICFixedPeerRejectsInvalidPeerWithoutTakingSocket` |
| Foreign preconnection packets, certificate pins, settings and local socket | Fork policy plus unchanged QUIC session/authentication owners | Existing QUIC suite in ordinary and tagged fork builds |
| Reliable, Datagram and mixed production Wire | Existing establishment and carrier owners | `TestQUICProductionWireBatchDelivery`, production Datagram contracts and ordinary repository suite |
| Cancellation, listener failure, socket transfer and teardown | Existing session/stream/root lifecycle owners | Existing QUIC suite, focused race gates and `task verify` |
| Native enforcement guard | Fork policy installation at adapter construction | One bypass of fixed-peer installation must fail the foreign-output regression; restore before certification |

The test names in this table refer to the preserved experimental revision, not newly shipped tests. Tests are verification aids; no maintained framework or exhaustive network proof is claimed. Native address/path/send families already owned by P01-B remain supported by its source audit and focused evidence. This integration does not reimplement those owners or broaden their representation domain.

## Predeclared native comparison

The historical experiment used the [then-frozen E01 protocol](https://github.com/GridSwarm/wiremux/blob/253361b2755278f89295b5df774f422ba866cc0c/docs/MEASUREMENT.md#quic-io-frozen-measurement-protocol-e01), with its P02 paired substitution. The [current protocol](../MEASUREMENT.md#quic-io-frozen-measurement-protocol-e01) supersedes future collection requirements; the declarations and receipts below preserve the original experiment without authorizing another campaign. Compare the same wiremux source and exact fork above, changing only the `wiremux_native_fixed_peer` build tag. Both optimized binaries use Go 1.27.1 darwin/arm64. Record source, module graph, build flags and binary digests in the durable campaign manifest before execution.

The [frozen campaign manifest](p02-fixed-peer-manifest.json) pins source `253361b2755278f89295b5df774f422ba866cc0c`, both executable hashes, workloads and paired order. Both binaries are staged on each endpoint and their SHA-256 digests agree across hosts. The complete module graph, build information, six remote configurations and initial host inventory are in the durable archive.

The user-selected venue is mbp128 (`172.16.1.2`, sending endpoint/controller) and m4mini via `m4mini-tb` (`172.16.1.1`, receiving endpoint), both native macOS 26.6.2 arm64. Both routes use the active Thunderbolt `bridge0` link at MTU 1500. Keep the roles, route, MTU, four Go processors per endpoint and observed power policy fixed. Retain hardware, interface, load and process snapshots. Do not overlap captures with this task's builds, tests, lint or profiling. An unrelated compute-heavy job or changed route invalidates host admission; ordinary OS/application background activity is recorded and is a limitation of this comparison.

Declare the three direct paced cells: S-paced reliable records, D-paced 1071-byte Datagrams, and M-paced Datagrams plus reliable control. Each uses E01's 100 Mbit/s workload, 5 s warmup, 10 s measurement, original drain and no heavy profiler. Run exactly ten pairs per cell, retained/removed in odd rounds and removed/retained in even rounds; never run pair members concurrently. Retain every attempted capture, including failures, with no replacement rounds.

Primary metric is combined endpoint CPU seconds per receiver-delivered bulk byte. Use E01's paired log-ratio Student-t interval and conservative uncertainty bounds. Report resource benefit only at its predeclared 10% threshold. The maintainability decision uses E01's correctness, delivery, per-endpoint resident and applicable p99 latency noninferiority guards without a speedup claim. Reduced wiremux policy duplication is the maintainability hypothesis; it does not excuse failed preservation. No timing, allocation or throughput threshold is added.

This is a narrower direct-path P02 comparison, not platform qualification or default enablement. Capacity-rate selection, impaired traffic, TURN measurement and all-platform support remain with the native baseline/qualification slices; TURN and managed-path correctness are preserved here through the existing fixtures. E02 owns the final per-platform enablement decision. No offload engagement or physical capacity claim follows from selecting the fixed-peer path. An inconclusive benefit retains ordinary defaults; a correctness failure blocks completion, and an inconclusive preservation result is not a preservation pass.

## Decision and receipts

**Performance disposition: inconclusive preservation. Product decision: retain wrapper enforcement with no selectable native path.** The experimental tagged native path passed the finite correctness evidence but is not shipped. Neither a resource benefit nor the performance noninferiority needed for maintainability adoption is established. This is the allowed negative P02 design disposition, not a qualified preservation/default-enablement result. E02 retains its native qualification obligations using the retained wrapper.

All 60 declared captures completed on the two physical Macs with no replacements. Raw results, commands, endpoint identities, module/build receipts, process snapshots and the one-off analysis remain under `/Users/josh/Documents/wiremux-measurements/p02-20260915`. The [compact results](p02-fixed-peer-results.json) retain paired inputs, capture hashes and the complete analysis digest. Ratios are removed/retained; values below one mean less process CPU per delivered byte.

| Cell | Completed pairs | Both windows qualified | Descriptive CPU ratio, 95% interval |
| --- | ---: | ---: | --- |
| S-paced | 10 | 3 | 0.985 [0.935, 1.037] |
| D-paced | 10 | 8 | 1.011 [0.990, 1.033] |
| M-paced | 10 | 6 | 0.993 [0.978, 1.008] |

These intervals retain all ten pairs and are descriptive only: E01 requires ten valid pairs for a qualified decision. Individual timing bounds span 0.374–6.054 ms, and each cell contains windows exceeding the unchanged 1 ms bound. Per-endpoint sampled resident intervals are close to one, but no combined preservation verdict follows. The 59 capture-labelled pre-capture process snapshots show receive-host `fseventsd` at 147.0%–841.8% CPU (median 320.2%) and sender-host Time Machine `backupd` at 61.6%–93.6% (median 89.5%). These snapshots were taken immediately before each capture launch; they are not continuous during-window sampling and do not establish sustained contention or its cause. They also do not establish a quiet host venue, so host load remains an additional qualification limitation. Power-of-two latency buckets leave conservative p99 ratio envelopes much wider than the 5% margin, even when both variants occupy the same bucket. Actual CPU sampling spans and collector overhead also remain observation limits; the byte-bound envelope is not a substitute for instrument qualification.

Every reliable bulk cohort completed. Across all D/M captures, admitted Datagrams had no missing, duplicate, invalid, rejected or deadline-failed records at drain. Across both variants, the D cell recorded 16 late records (9 retained, 7 removed); the M cell recorded 21 late records (10 retained, 11 removed) and 96 generator-missed slots (63 retained, 33 removed). These are explicit window deficits, not erased by eventual delivery. All 40,000 scheduled reliable control requests per S/M cell received replies. No network-loss attribution or capacity claim is made.

### Timing-control follow-up

The owner's pointer to earlier timing work led to the already-merged [direct TLS control repair](../work-items/windows-direct-control.md), originally validated on the Windows venue. The frozen P02 campaign had used ordinary SSH control; it already contained the repair's round-trip-aware probe spacing but had not selected the optional direct TLS launcher. A separately [declared two-capture pilot](p02-tls-control-pilot-manifest.json) used the same binaries, S workload and physical Mac route, changing only the timing-control channel to authenticated direct TLS. Its bounds were 0.801375 ms and 1.451416 ms: one qualified and one unqualified. Both completed and remain separate from the original comparison; neither replaces a round. This does not establish reliable sub-millisecond alignment on this venue. No new full campaign or repeated pilot was run. The prior fork's four-core echo-latency improvement measures a different quantity from this cross-host clock-alignment bound; these captures already use four Go processors per endpoint, without exclusive physical-core reservation.

The harness's pre-existing static limitation string says the production wrapper is retained even in tagged captures. It is source-derived metadata, not runtime capability observation. Exact executable hashes, build tags, pinned module graph, constructor audit and equivalence fixtures identify the compared paths. This evaluation makes no receive-offload engagement or acceleration claim from that string or from compilation alone.

Experimental implementation checks (historical source): the peer regression failed before native selection existed; bypassing the fixed-peer setter then made its foreign-output assertion fail, and restoring the setter made it pass. The focused peer/permission cases pass on upstream, the pre-program fork F0 and the current fork. The complete QUIC suite passes on the tagged current fork; selected adapter/session/production-Wire/managed cases pass with the race detector, and tagged upstream plus current-fork root ownership cases pass. The initial `task verify` completed the ordinary tests but encountered another process's golangci-lint lock; separate `task lint` and `task deep-check` runs then passed, including the required races and vulnerability analysis. These do not certify the final documentation-only candidate; its exact-head repository validation remains required.

## Product scope and review

At the owner's explicit retention decision, the in-progress implementation review was canceled without a final synthesis; it supplies no approval. The final PR removes all experimental runtime/test changes and records this decision, evidence and program state. Review and certification apply to that documentation-only diff. The complete evidence archive `/Users/josh/Documents/wiremux-measurements/p02-20260915-evidence.tar.gz` is mirrored on mbp128 and m4mini with SHA-256 `b6ec2a288eb4d2280ce5df585e5969abece74c7c2d194d138aee062411b6ed16`; verify either copy with `shasum -a 256 /Users/josh/Documents/wiremux-measurements/p02-20260915-evidence.tar.gz`.
