# Issue #1865: how many busy goroutines a consumer can run before its native Wire stalls

Research for [How many busy goroutines can a consumer run before its native Wire stalls, and what restores it?](https://github.com/GridSwarm/wiremux/issues/1865) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). [Which realistic loads push the default-class native sender onto macOS efficiency cores?](https://github.com/GridSwarm/wiremux/issues/1857) found that 12 CPU-bound goroutines in the sender's own process cost the native Wire 15–40%, and 16 or 24 of them cut it to 3–16 Mbit/s. This note locates the tipping point, checks whether it follows `GOMAXPROCS` (Go's processor count), measures what headroom restores and what that costs the consumer's own work, runs the same sweep on Linux, and reads the runtime and the transport's goroutines to size what wiremux or the fork could change. Nothing here implements a change.

Sources are wiremux at #1857's probe (local commit `bef05a64`: #1861's probe with the connected socket, batched sends and receives, the acknowledgment threshold and the send-queue knobs, plus #1853's and #1857's rig readouts), with this ticket's rig commit cherry-picked. The fork is #1857's quic-go-fast copy (`v0.62.1-fast.7` plus the probes' knobs at their defaults). The rig is `cmd/nativerig` from `codex/native-gap-rig` (this ticket's addition is commit `b01af53f`, documented in PROTOCOL.md). Also cited: Go [1.27.2](https://github.com/golang/go/tree/go1.27.2)'s runtime, quic-go-fast [`v0.62.1-fast.7`](https://github.com/the-sarge/quic-go-fast/tree/v0.62.1-fast.7), wiremux `main` at `870295a4`, golang/go issues, and measurements taken for this note on 2026-10-17 and 2026-10-18 (UTC). Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cells.**

- **`tb`:** mbp128 (MacBook Pro M4 Max: 12 performance cores, 4 efficiency cores, 16 CPUs, so `GOMAXPROCS` 16 by default) sends from `bridge0` over Thunderbolt to m4mini (Mac mini M4 Pro), both macOS 27 arm64, MTU 1500. All load is goroutines inside the sender's own process (the rig's `-goload N`); the receiver carried none. 216 runs: 72 cells, three 10 s runs each, interleaved in one campaign.
- **`netns`:** minimax (Linux 7.0, Ryzen AI Max+ 395), the rig's two network namespaces joined by a `veth` pair, sender pinned to CPUs 4-7 and receiver to 12-15, the stock Linux native shape. `taskset` gives the sender 4 CPUs, so Go picks `GOMAXPROCS` 4. 69 runs: 23 cells, three 10 s runs each.

**Launch.** As in #1857, every `tb` sender starts through its own `ssh mbp128` session and #1853's daemon launcher, at the default class. `GOMAXPROCS`, where raised or lowered, is set in the sender's environment.

**Shapes** (flags on both peers):

- **connected:** the connected socket per peer, [adopted for macOS](https://github.com/GridSwarm/wiremux/issues/1843#issuecomment-6207453285), at the fork's acknowledgment rule.
- **batched receives:** connected, plus one `sendmsg_x` per send group, an acknowledgment every 16 packets, the bundle's 32-entry send queue and `recvmsg_x` with eight read slots: the fastest stack the map has adopted.

The arms are Datagrams at the GC pin (`-ballast 64 -gc-role both`), the stream, and on the connected shape Datagrams at Go's default GC (the map's default-GC row).

## Answer

**The Wire collapses as soon as the consumer's CPU-bound goroutines number `GOMAXPROCS`, on every shape, and one fewer is enough to avoid it.** At `GOMAXPROCS` 16 (**measured**, medians of three; percentages **derived**):

- **15 goroutines** cost the connected Wire 44% (Datagrams) and 36% (stream), and the batched-receive Wire 65% and 43%. The loss grows step by step from 12 goroutines (20–37%), with no cliff.
- **16 goroutines** cut every shape to 4–7 Mbit/s: 0.1–0.3% of its unloaded rate (2,026–4,496 Mbit/s). 24 do the same.
- **The tipping point follows `GOMAXPROCS`, not the core count.** At `GOMAXPROCS` 8, with eight of mbp128's 16 cores idle, 7 goroutines cost 11–15% and 8 cut the Wire to 7–8 Mbit/s, though the transport's kernel time stayed 99% on performance cores.

**Why:** with as many always-runnable goroutines as Go processors, no processor ever finds its run queues empty, so none reaches the network poll that wakes goroutines parked on a socket. The fork's read loop then waits for the runtime's 10 ms background poll, and everything it wakes waits behind 10 ms slices. The sender read acknowledgments 65 times a second instead of 47,800 (**measured**; **source**: Go 1.27.2 `runtime/proc.go`, section 3). The loss up to 15 goroutines is CPU sharing, as with #1857's spinners.

**What restores it, and the cost** (**measured**; the consumer's work is its goroutines' total iterations per second):

- **A worker pool one below `GOMAXPROCS`** (15 of 16): the Wire runs at 35–64% of its unloaded rate, and the consumer keeps 82–86% of what 16 goroutines do. Four below (12 of 16): 63–80% of the rate, 74–76% of the work.
- **A raised `GOMAXPROCS`** (24 or 32 with 16 busy goroutines): 44–58% of the rate and 78–82% of the work, about what one fewer goroutine gives. An unloaded sender at `GOMAXPROCS` 32 lost nothing. But the cliff moves with it: 24 goroutines at `GOMAXPROCS` 24 collapsed the Wire again (15–77 Mbit/s), so a pool sized from `GOMAXPROCS` defeats it.
- **Goroutines that block** never collapsed the Wire. 16 goroutines busy half of every millisecond cost it nothing; at 80% busy they cost 27–35%, at 95% busy 43–48%; 24 at 95% busy cost 76–77%.
- **Frequent garbage collection takes headroom away.** At Go's default GC (112–260 collections a second in the rig at 12–15 goroutines) the Datagram Wire lost 51% at 12 goroutines and 77% at 15, against 20% and 44% at the pin, because GC mark workers take a quarter of the processors first.

**Nothing inside wiremux or the fork removes the cliff.** In a microbenchmark at `GOMAXPROCS` 16 with 16–32 CPU-bound goroutines, a netpoll-parked UDP reader woke a median 9.6–15 ms late. A reader locked to its thread in blocking `recvfrom` woke a median 0.16–2.2 ms late (mean 2.6–7.3 ms), still 8 ms or more late 13–34% of the time, because a goroutine returning from a system call with no idle processor joins the same global queue. A busy-polling reader was as late as the netpoll one. Fewer hand-offs per packet change nothing at the cliff. The only fix found is in Go's runtime (polling the network from the scheduler), which a runtime team member suggested in a 2022 review but nobody has built. So a target either documents headroom as a consumer requirement or depends on an upstream runtime change (section 7).

**Linux behaves the same at its own `GOMAXPROCS`.** A sender pinned to 4 CPUs gets `GOMAXPROCS` 4, so there 3 CPU-bound goroutines cost the stock Linux Wire 45% (Datagrams) and 42% (stream), and 4 cut it to 18 and 6 Mbit/s, 0.5% and 0.05% of its unloaded rate. `GOMAXPROCS` 8 on the same 4 CPUs kept 35–45% of the rate with 4 or 6 goroutines, and goroutines busy 80% of each millisecond never collapsed it. The kernel's scheduler (EEVDF, lazy preemption) doesn't enter into it (section 6).

| Mbit/s, medians of three (change from unloaded at `GOMAXPROCS` 16) | 0 | 12 | 13 | 14 | 15 | 16 | 24 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| connected, Datagrams at the pin | 2,026 | 1,628 (−20%) | 1,522 (−25%) | 1,233 (−39%) | 1,142 (−44%) | 6 | 4 |
| connected, stream | 2,314 | 1,567 (−32%) | 1,595 (−31%) | 1,614 (−30%) | 1,486 (−36%) | 6 | 4 |
| connected, Datagrams at default GC | 2,002 | 989 (−51%) | 678 (−66%) | 619 (−69%) | 465 (−77%) | 4 | – |
| batched receives, Datagrams at the pin | 3,896 | 2,937 (−25%) | 2,347 (−40%) | 1,928 (−51%) | 1,378 (−65%) | 7 | – |
| batched receives, stream | 4,496 | 2,813 (−37%) | 3,136 (−30%) | 2,998 (−33%) | 2,553 (−43%) | 4 | – |

## 1. The tipping point at `GOMAXPROCS` 16

(**measured**; connected shape, Datagrams at the pin unless stated; medians of three)

| Goroutines | Mbit/s | Acknowledgment reads per second | Gaps of 8 ms or more per second | Mean smoothed RTT, ms | Go scheduler latency p99, µs | Goroutines' work, billions of iterations/s |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 2,026 | 47,824 | 0.1 | 0.23 | 20 | – |
| 12 | 1,628 | 42,471 | 0.5 | 0.59 | 66 | 6.22 |
| 13 | 1,522 | 38,918 | 0.7 | 0.60 | 98 | 6.57 |
| 14 | 1,233 | 32,178 | 4.0 | 0.94 | 131 | 6.89 |
| 15 | 1,142 | 26,349 | 23.8 | 3.17 | 164 | 7.20 |
| 16 | 6 | 65 | 51.4 | 18.7 | 2,621 | 8.37 |
| 24 | 4 | 44 | 28.5 | 33.5 | 50,332 | 8.58 |

- **The cliff is one goroutine wide.** From 12 to 15 goroutines every shape loses rate step by step (20% to 44% for connected Datagrams). At 16 the rate falls by two orders of magnitude on all five rows, the stream and the batched-receive shape included.
- **Below the cliff it is CPU sharing.** At 12–15 goroutines the transport's kernel time ran 45–64% on performance cores, and the sender's threads spent 14–25% of their time on efficiency cores, as under #1857's spinners. The unloaded sender used 2.2–3.1 CPU-seconds per second of offer (**derived**: process CPU over the 10 s offer, setup included), so on 16 cores it needs about three cores of its own to hold its rate.
- **At the cliff it is the scheduler.** The sender lost nothing and had no congestion events (1,335 in an unloaded run's median, 0 at 16). It read acknowledgments 65 times a second, with 51 gaps of 8 ms or more in every second, and its smoothed RTT rose from 0.23 to 18.7 ms. It simply ran rarely.
- **15 goroutines already show it in the tail.** Gaps of 8 ms or more rose from 0.7 a second at 13 to 23.8 at 15, and the smoothed RTT to 3.2 ms: with one processor free, the transport's goroutines take turns on it.
- **The consumer gains little from the last goroutine.** Going from 15 to 16 goroutines added 16–22% to their work (7.08–7.38 → 8.37–8.75 billion iterations a second) and cost the Wire 99.5% or more of its rate.

## 2. It follows `GOMAXPROCS`, not the core count

(**measured**; `GOMAXPROCS` 8 on the same 16-core Mac, connected shape)

| Goroutines | Datagrams Mbit/s | Stream Mbit/s | Acknowledgment reads per second | Gaps of 8 ms or more per second | Transport kernel time on performance cores |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 2,176 | 2,535 | 51,696 | 0.1 | 1.00 |
| 4 | 2,109 (−3%) | 2,376 (−6%) | 49,846 | 0.1 | 0.99 |
| 6 | 2,366 (+9%) | 2,713 (+7%) | 57,783 | 0.2 | 0.99 |
| 7 | 1,842 (−15%) | 2,251 (−11%) | 35,398 | 0.2 | 0.99 |
| 8 | 7 | 8 | 80 | 66.4 | 0.99 |

- With eight cores idle there is no CPU shortage: up to 6 goroutines the Wire ran at or above its unloaded rate (busy Macs clock their performance cores higher, as #1853 found), and the transport's kernel time stayed on performance cores throughout.
- At 7 goroutines (one processor free) it lost 11–15%. At 8 it collapsed exactly as at 16 of 16. So the trigger is the number of Go processors, not cores.

## 3. Why it collapses: the runtime and the transport's goroutines

(**source**, Go 1.27.2 `src/runtime/proc.go`, `preempt.go` and `mgcpacer.go`, quic-go-fast `v0.62.1-fast.7`, wiremux `main` at `870295a4`)

**How a Go processor picks its next goroutine.** `findRunnable` ([L3404](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3404)) runs its timers first ([L3430](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3430)) and then tries, in order:

1. a GC mark worker while a collection is marking ([L3446-L3452](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3446-L3452));
2. the global run queue, on every 61st scheduling tick ([L3458](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3458));
3. its own local run queue ([L3483-L3486](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3483-L3486));
4. the global run queue ([L3488-L3499](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3488-L3499));
5. only then a non-blocking network poll, from one thread at a time ([L3501-L3525](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3501-L3525)).

The network poll is the step that finds goroutines whose socket became readable. A processor reaches it only when both run queues are empty.

**Where CPU-bound goroutines go.** The runtime's monitor (`sysmon`) preempts a goroutine that has held a processor for 10 ms ([`forcePreemptNS` L6679](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L6679), [L6715](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L6715)). A tight loop is preempted by signal and lands in `gopreempt_m` ([`preempt.go` L327-L331](https://github.com/golang/go/blob/go1.27.2/src/runtime/preempt.go#L327-L331)), which puts it on the **global** run queue ([`goschedImpl` L4346-L4353](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L4346-L4353)). So with as many CPU-bound goroutines as processors, a preempted goroutine is the global queue's only entry, and the processor that preempted it takes it straight back at step 4. Step 5 never runs. A goroutine readied by another goroutine goes to the waker's processor's `runnext` slot ([`ready` L1150](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L1150)) and runs only when the waker blocks, and `sysmon` counts a chain of such goroutines as one 10 ms slice ([L6707-L6710](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L6707-L6710)).

**What wakes a goroutine parked on a socket then.**

- `sysmon` polls the network when nobody has for 10 ms ([L6618-L6635](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L6618-L6635)). It has no processor, so `injectglist` puts what it finds on the global queue ([L4102-L4107](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L4102-L4107)).
- Every stop-the-world restart polls too ([`startTheWorldWithSema` L1777-L1781](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L1777-L1781)), but while a collection marks, its dedicated workers take a quarter of the processors ahead of everything ([`gcBackgroundUtilization` = 0.25, `mgcpacer.go` L39](https://github.com/golang/go/blob/go1.27.2/src/runtime/mgcpacer.go#L39)). That is the default-GC row: at 112–260 collections a second it behaves as if three or four more goroutines were busy (**derived** from section 1's table: 989 Mbit/s at 12 goroutines sits between the pinned row's 15 and 16).
- A goroutine that blocked in a system call outside the poller and returns with no idle processor goes to the global queue as well, and one locked to its thread parks that thread until a processor picks it ([`exitsyscallNoP` L5106-L5136](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L5106-L5136), [`startlockedm` L3293](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3293)).
- Timers are different: a processor runs its timers on every pass through the scheduler, which is what Go 1.16 fixed for CPU-bound programs ([golang/go#38860](https://github.com/golang/go/issues/38860)). The network poller has no such hook.

**The transport's goroutines per packet** (**source**; the probe's knobs change system calls per packet, not goroutines):

| Path | Goroutines that run, in order | Parked on the network poller | Woken by another goroutine |
| --- | --- | --- | --- |
| Sender, Datagrams | application sender → wiremux's root Datagram pump → the native carrier's pump → the fork's run loop → its send goroutine → `sendmsg`; acknowledgments: the fork's read loop → run loop | 1 (the read loop) | 4 (both pumps, run loop, send goroutine) |
| Sender, stream | application writer (it seals on its own goroutine) → run loop → send goroutine; acknowledgments: read loop → run loop | 1 | 3 |
| Receiver, Datagrams | read loop → run loop → application receiver; acknowledgments: run loop → send goroutine | 1 | 3 |
| Receiver, stream | read loop → run loop → application reader (→ run loop again for window updates) → send goroutine | 1 | 3 |

- The read loop is the fork's `Transport.listen` goroutine ([`transport.go` L498](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/transport.go#L498), [L648-L666](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/transport.go#L648-L666)), reading through wiremux's binding (`ReadUnicastBatch`, [`internal/routeselection/unicast.go` L871](https://github.com/GridSwarm/wiremux/blob/870295a4/internal/routeselection/unicast.go#L871)). Every receive variant, `recvmsg_x` included, parks on the network poller when the socket is empty; none makes a blocking call.
- It hands each packet to the connection under a mutex and a one-entry notify channel ([`connection.go` L2003-L2033](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2003-L2033)), which wakes the run loop ([L695-L712](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L695-L712)).
- The run loop hands each packet to the send goroutine over an 8-entry channel ([`send_queue.go` L109](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/send_queue.go#L109), [L137](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/send_queue.go#L137)). The send goroutine starts with the connection ([`connection.go` L620-L624](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L620-L624)) and signals room back on a channel ([`send_queue.go` L176-L201](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/send_queue.go#L176-L201)). No mode lets the run loop write packets itself; only path probes do.
- wiremux's Datagram send has two pumps in series, each behind its own 8-slot admission queue ([`internal/datagramadmission/queue.go` L51-L96](https://github.com/GridSwarm/wiremux/blob/870295a4/internal/datagramadmission/queue.go#L51-L96)): the root `Datagrams.pumpSends` ([`datagrams.go` L69](https://github.com/GridSwarm/wiremux/blob/870295a4/datagrams.go#L69), [L240](https://github.com/GridSwarm/wiremux/blob/870295a4/datagrams.go#L240)) and the native carrier's `send` goroutine ([`internal/nativequic/promote.go` L446](https://github.com/GridSwarm/wiremux/blob/870295a4/internal/nativequic/promote.go#L446), [L493-L500](https://github.com/GridSwarm/wiremux/blob/870295a4/internal/nativequic/promote.go#L493-L500)), which calls the fork's `SendDatagram` ([`connection.go` L2900](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2900)). Stream sends and every receive add no wiremux goroutine.
- The run loop has one timer for the idle timeout, the 25 ms acknowledgment delay, loss detection and pacing. Nothing on the path calls `runtime.LockOSThread` (except #1853's opt-in probe hook) or `runtime.Gosched`, sets `GOMAXPROCS`, or busy-polls.

So every round trip needs the read loop, the run loop and the send goroutine (plus the application and, for Datagrams, two pumps) to get a processor. Only the read loop depends on the network poll, and at the cliff that is the one that waits for `sysmon`. The rest are woken by channel sends and run on the waker's processor.

## 4. What restores the rate, and what it costs the consumer

(**measured**; medians of three; "work" is the goroutines' total iterations per second, the consumer's own output; changes **derived**)

| Configuration | Connected Datagrams | Connected stream | Batched receives, Datagrams | Batched receives, stream | Goroutines' work, billions/s |
| --- | ---: | ---: | ---: | ---: | ---: |
| `GOMAXPROCS` 16, 16 goroutines (the cliff) | 6 | 6 | 7 | 4 | 8.37–8.75 |
| `GOMAXPROCS` 16, 15 goroutines | 1,142 (−44%) | 1,486 (−36%) | 1,378 (−65%) | 2,553 (−43%) | 7.08–7.38 |
| `GOMAXPROCS` 16, 12 goroutines | 1,628 (−20%) | 1,567 (−32%) | 2,937 (−25%) | 2,813 (−37%) | 6.22–6.64 |
| `GOMAXPROCS` 24, 16 goroutines | 1,097 (−46%) | 1,333 (−42%) | 1,790 (−54%) | 2,357 (−48%) | 6.60–7.06 |
| `GOMAXPROCS` 32, 16 goroutines | 1,115 (−45%) | 1,283 (−45%) | 1,723 (−56%) | 2,465 (−45%) | 6.81–7.08 |
| `GOMAXPROCS` 24, 24 goroutines | 15 | 21 | 40 | 77 | 8.27–8.61 |
| `GOMAXPROCS` 32, 24 goroutines | 797 (−61%) | 944 (−59%) | 921 (−76%) | 1,711 (−62%) | 7.26–7.91 |
| `GOMAXPROCS` 32, no goroutines | 2,147 (+6%) | 2,544 (+10%) | – | – | – |
| 16 goroutines busy 50% of each ms | 2,085 (+3%) | 2,350 (+2%) | – | – | 4.66–4.71 |
| 16 goroutines busy 80% | 1,469 (−27%) | 1,512 (−35%) | – | – | 6.38–6.46 |
| 16 goroutines busy 95% | 1,155 (−43%) | 1,197 (−48%) | – | – | 7.13–7.18 |
| 24 goroutines busy 50% | 1,470 (−27%) | 1,495 (−35%) | – | – | 6.38–6.41 |
| 24 goroutines busy 80% | 1,101 (−46%) | 987 (−57%) | – | – | 7.32–7.56 |
| 24 goroutines busy 95% | 459 (−77%) | 551 (−76%) | – | – | 7.93–8.09 |

Changes are against the same shape unloaded at `GOMAXPROCS` 16 (2,026, 2,314, 3,896 and 4,496 Mbit/s).

- **One free processor is the whole difference between a working Wire and a dead one.** A pool of 15 on 16 processors keeps 35–64% of the rate and 82–86% of the work of a pool of 16 (**derived**: 7.08–7.38 against 8.37–8.75). A pool of 12 keeps 63–80% of the rate and 74–76% of the work. Beyond the first free processor, rate and work trade smoothly: both draw on the same 16 cores.
- **A raised `GOMAXPROCS` works like one fewer goroutine, at a little more cost.** With 16 goroutines, `GOMAXPROCS` 24 or 32 brought the Wire to 44–58% of its rate, close to the 15-goroutine row, while the goroutines did 78–82% of their collapsed-row work, 2–8% less than the 15-goroutine pool (**derived**). The extra Go processors' threads then share 16 cores under macOS's scheduler, which displaces the transport as #1857's spinners did. An unloaded sender at `GOMAXPROCS` 32 lost nothing (+6% and +10%, within this campaign's run-to-run spread). But the cliff moves with it: 24 goroutines at `GOMAXPROCS` 24 collapsed the Wire to 15–77 Mbit/s. A consumer that sizes its pool from `runtime.GOMAXPROCS(0)` would grow its pool with any raise and stay on the cliff.
- **Goroutines that block leave the transport its turns.** No duty-cycled cell collapsed, even with 24 goroutines on 16 processors. 16 goroutines busy half of each millisecond cost the Wire nothing. At 80% and 95% busy the loss matched the busy share: about what 12–15 always-busy goroutines cost. The goroutines' sleeps ran long when processors were scarce (requested 200 µs, measured 237–255 µs at 16 goroutines and 586 µs at 24, which held their busy share at 0.58), so a blocking consumer's own timers are delayed too.
- **The default-GC row is a consumer with less headroom.** At 112–260 collections a second its Datagram Wire lost 51–77% at 12–15 goroutines, against 20–44% at the pin. A consumer whose heap is at Go's floor (the rig's case, not GridCast's per #1833) needs more free processors.

## 5. The mechanism microbenchmark

(**measured**, mbp128, `tools/wakelat` in the evidence directory: a pinger process sends one UDP datagram per millisecond over loopback; a reader goroutine in a process with N CPU-bound goroutines records each datagram's wait from send to receipt; two 6 s runs per cell, medians)

| `GOMAXPROCS` | Goroutines | netpoll reader: p50 / p99 µs, share ≥ 8 ms | blocking reader on a locked thread: p50 / p99 µs, share ≥ 8 ms | busy-polling reader: p50 / p99 µs, share ≥ 8 ms |
| ---: | ---: | --- | --- | --- |
| 16 | 0 | 65 / 184, 0 | 55 / 143, 0 | 38 / 70, 0 |
| 16 | 12 | 34 / 180, 0 | 34 / 510, 0 | 44 / 359, 0 |
| 16 | 14 | 60 / 2,972, 0 | 44 / 1,980, 0 | 32 / 282, 0 |
| 16 | 15 | 51 / 7,458, 0.008 | 71 / 8,394, 0.011 | 30 / 4,260, 0.003 |
| 16 | 16 | 10,548 / 42,437, 0.60 | 164 / 13,338, 0.13 | 5,184 / 28,124, 0.36 |
| 16 | 24 | 12,944 / 42,416, 0.69 | 990 / 31,738, 0.26 | 10,247 / 41,508, 0.60 |
| 16 | 32 | 14,298 / 60,483, 0.72 | 2,159 / 47,972, 0.34 | 16,112 / 70,198, 0.75 |
| 8 | 7 | 47 / 76, 0 | 47 / 92, 0 | 39 / 74, 0 |
| 8 | 8 | 10,332 / 23,774, 0.61 | 48 / 13,342, 0.16 | 11,612 / 24,033, 0.66 |
| 8 | 16 | 15,228 / 46,687, 0.74 | 66 / 35,620, 0.27 | 15,746 / 50,346, 0.75 |

- **The netpoll reader shows the cliff directly:** fine up to `GOMAXPROCS`−1, a median 9.6–15 ms late at or above it, with 54–74% of datagrams waiting 8 ms or more. Its mean wait at or above the cliff was 10.4–17.3 ms.
- **A reader outside the poller does better but doesn't escape.** Locked to its thread in blocking `recvfrom`, it woke within 0.05–2.2 ms at the median, because it often reclaims its own processor before `sysmon` hands it to a CPU-bound goroutine. When it has lost the processor it joins the global queue: 13–34% of its datagrams still waited 8 ms or more, and its mean was 2.5–7.3 ms. With eight idle cores (`GOMAXPROCS` 8) the median was 48–66 µs but 34–44% still waited a millisecond or more.
- **Busy polling doesn't help at the cliff.** Its `runtime.Gosched` puts it on the global queue, so it waits like everything else (median 5.2–16 ms). Below the cliff it makes about 2 million empty reads a second, a processor the consumer loses (the goroutines' work fell from 7.57 to 7.30 billion iterations a second at 12). Polling for 200 µs after each datagram at 20,000 datagrams a second behaved the same.
- **Hand-offs add little.** Two extra channel hand-offs after the read moved neither the median nor the tail materially (8.8–15.5 ms medians at the cliff).
- At 15 of 16 the netpoll reader's p99 rose to 7.5 ms because the 16 cores were all busy: the pinger itself ran 2.8 ms late at its p99 there.

## 6. Linux

(**measured**, minimax `netns` cell, the stock Linux native shape, sender `taskset -c 4-7`, so `num_cpu` and `GOMAXPROCS` 4; receiver on 12-15; medians of three)

| Configuration | Datagrams at the pin, Mbit/s | Stream, Mbit/s | Datagrams at default GC, Mbit/s | Acknowledgment reads per second (Datagrams) | Gaps of 8 ms or more per second | Goroutines' work, billions/s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `GOMAXPROCS` 4, no goroutines | 3,897 | 10,932 | 3,342 | 34,020 | 0.2 | – |
| `GOMAXPROCS` 4, 1 goroutine | 4,060 (+4%) | 8,541 (−22%) | – | 20,369 | 0.1 | 0.85 |
| `GOMAXPROCS` 4, 2 goroutines | 3,498 (−10%) | 8,869 (−19%) | – | 14,269 | 0.1 | 1.69–1.70 |
| `GOMAXPROCS` 4, 3 goroutines | 2,131 (−45%) | 6,312 (−42%) | 1,744 (−48%) | 7,221 | 0.2 | 2.54–2.55 |
| `GOMAXPROCS` 4, 4 goroutines | 18 | 6 | 5 | 84 | 83.5 | 3.41–3.42 |
| `GOMAXPROCS` 4, 6 goroutines | 5 | 6 | – | 36 | 36.2 | 3.42 |
| `GOMAXPROCS` 8, 4 goroutines | 1,766 (−55%) | 4,569 (−58%) | – | 17,093 | 1.6 | 2.51–2.64 |
| `GOMAXPROCS` 8, 6 goroutines | 1,448 (−63%) | 3,793 (−65%) | – | 5,341 | 11.6 | 2.77–2.83 |
| `GOMAXPROCS` 4, 4 goroutines busy 80% | 1,903 (−51%) | 5,284 (−52%) | – | 8,757 | 0.1 | 2.26–2.38 |
| `GOMAXPROCS` 4, 6 goroutines busy 80% | 948 (−76%) | 2,623 (−76%) | – | 3,900 | 0.3 | 2.90–2.92 |

- **The same cliff, at the pinned CPU count.** Go sets `GOMAXPROCS` from the CPUs the process may use, and `taskset` leaves 4, so the fourth CPU-bound goroutine collapses the Wire. Go 1.25 and later also lower the default to a container's CPU limit ([Go 1.25 release notes](https://go.dev/doc/go1.25#container-aware-gomaxprocs), **source**), so a Linux consumer in a container limited to 4 CPUs meets the cliff at 4 busy goroutines too.
- **Below it the loss is CPU sharing on four CPUs.** The unloaded sender used 1.9–2.2 CPU-seconds per second of offer (**derived**), so one goroutine cost the Datagram Wire nothing, two cost 10–19%, and three, leaving one CPU, cost 42–45%. There are no efficiency cores here.
- **A raised `GOMAXPROCS` restores part of it, as on macOS.** `GOMAXPROCS` 8 with 4 or 6 goroutines kept 35–45% of the rate, while the goroutines did 74–83% of their collapsed-row work (**derived**: 2.51–2.83 against 3.41–3.42).
- **Blocking goroutines never collapsed it.** At 80% busy, 4 goroutines cost 51–52% and 6 cost 76%; their 200 µs sleeps took 282–331 µs and 546–552 µs.
- **The default-GC row** lost 48% at 3 goroutines against 45% at the pin, at 496 collections a second.
- **The kernel doesn't change it.** minimax runs Linux 7.0 with `PREEMPT_DYNAMIC` in lazy mode, EEVDF with a 2.8 ms base slice and `HZ` 1000 (`sources/minimax-sched.txt`). The goroutines' threads are ordinary Linux threads the kernel shares fairly; the starvation happens inside Go's scheduler, which the kernel never sees.
- **The microbenchmark matches macOS** (**measured**, the same tool pinned to CPUs 4-7 with its pinger on 12-15; `W2/tables.md`). At or above 4 goroutines a netpoll reader woke a median 10.0–16.0 ms late (60–75% of datagrams 8 ms or more), and a busy-polling one the same. A blocking reader on a locked thread woke a median 11–28 µs late but averaged 3.0–5.1 ms, 17–27% of datagrams waited 8 ms or more, and it cost the CPU-bound goroutines 13–15% of their work (2.92–2.96 against 3.42 billion iterations a second).

## 7. Options and their likely size

**Inside wiremux or the fork** (sizes **derived** from sections 1–6; none built):

| Option | What changes | Likely size at the cliff (≥ `GOMAXPROCS` busy) | Likely size below it | Cost |
| --- | --- | --- | --- | --- |
| Read loop outside the poller: the fork's `Transport.listen` and wiremux's binding read with blocking `recvmsg` on a thread locked to it | Acknowledgments wake the read loop through the kernel, not `sysmon` | Mean wake 2–5× sooner (10–17 ms → 2.6–7.3 ms), 13–34% of wakes still 8 ms late; the run loop and send goroutine still queue behind CPU-bound goroutines. Estimated tens of Mbit/s, not Gbit/s (**derived**: the collapsed Wire's 4–7 Mbit/s and 65 acknowledgment reads a second, times 2–5) | None expected: wakes are already prompt below the cliff | One OS thread per Wire; closes and deadlines lose the poller's handling; Linux batch reads and macOS `recvmsg_x` slots rebuilt on a blocking path |
| Adaptive busy-polling in the read loop | Polls the socket with `runtime.Gosched` after traffic | None: as late as the poller (5–16 ms medians) | None measured | Up to a processor per Wire while polling |
| Fewer goroutines per packet: one Datagram pump (already in slice A, [#1826](https://github.com/GridSwarm/wiremux/issues/1826#issuecomment-6148612825)); a run loop that writes without the send goroutine | One or two fewer goroutines to schedule per round trip | None: the read loop still needs the poll | At most about one step of section 1's curve: 5–13% per goroutine between 12 and 15 busy goroutines (**derived**: (1,628 − 1,142) / 3 / 2,026 = 8% connected Datagrams; (2,937 − 1,378) / 3 / 3,896 = 13% batched receives) | The send goroutine exists to batch and to keep `sendmsg` off the run loop; removing it undoes #1845/#1850's queue work |
| Starvation detection: watch acknowledgment-read gaps or Go's `/sched/latencies` and report a starved Wire | Nothing on the rate | None | None | A metric or log line; turns a silent 99.7% loss into a diagnosis |
| A Go runtime change: poll the network from the scheduler when the last poll is old, as a runtime team member suggested on [golang/go#51651](https://github.com/golang/go/pull/51651) | The read loop is woken at the next scheduling pass | Not sized: needs a patched-runtime prototype in the rig | None | Upstream work; wiremux can't ship a patched runtime to consumers |
| The library sets `GOMAXPROCS` | Process-wide | The cliff moves with it (24 at 24 collapsed) | – | Changes every consumer's scheduling; rejected |

**On the consumer's side** (**measured**, section 4):

- **A documented headroom requirement:** keep the number of goroutines that never block below `GOMAXPROCS`. One free processor avoids the collapse (35–64% of the rate kept at 15 of 16, 82–86% of the consumer's work kept). Four free keep 63–80% of the rate for 74–76% of the work.
- **A raised `GOMAXPROCS`** (24–32 on 16 cores): 44–58% of the rate for 78–82% of the work, no idle cost, but only while the busy goroutines stay below the new value.
- **A worker pool sized below `GOMAXPROCS`:** the same trade as the first point; sizing it from `runtime.GOMAXPROCS(0) - k` keeps it correct under any `GOMAXPROCS`.
- **Pipelines that block** are already safe from the collapse; their cost is CPU sharing in proportion to their busy share.

## 8. What upstream Go has said

(**source**; each opened and checked on 2026-10-17)

- [golang/go#51651](https://github.com/golang/go/pull/51651), "runtime: let sysmon sleep in netpoll if possible" (CL 392314), open and unmerged since 2022. Its description is this mechanism: with plenty of runnable goroutines `findRunnable` never reaches the network poll, so `sysmon`'s 10 ms poll is the only path, and a localhost TCP dial took about 10 ms. In review a runtime team member suggested polling the network occasionally from the scheduler, as it checks the global queue. Nothing came of it.
- [golang/go#20457](https://github.com/golang/go/issues/20457), "runtime: network blips during concurrent GC", closed in 2017 as a duplicate of #17969. A Go team member explained the 10 ms gaps the same way: during GC there is always another goroutine to run, so only `sysmon` polls.
- [golang/go#56060](https://github.com/golang/go/issues/56060), "runtime: bgsweep does not yield to netpoller-readied goroutines", open. A goroutine that yields goes to the global queue, which outranks network-readied work.
- [golang/go#38860](https://github.com/golang/go/issues/38860), "runtime: CPU bound goroutines cause unnecessary timer latency", fixed in Go 1.16 for timers. No equivalent change was made for the network poller.
- [golang/go#65064](https://github.com/golang/go/issues/65064), "runtime: epoll scalability problem with 192 core machine and 1k+ ready sockets", fixed in Go 1.25 by polling from only one processor at a time. Any "poll more often" change has to live with that limit.
- [golang/go#51071](https://github.com/golang/go/issues/51071), "runtime: investigate possible Go scheduler improvements inspired by Linux Kernel's CFS", open in the backlog. It asks for I/O-first scheduling and cites network latency beside CPU-bound goroutines; no commitment.
- [golang/go#65874](https://github.com/golang/go/issues/65874), "runtime: allow preemption-disable around critical section", open. A runtime team member could find no goroutine-priority issue (2024). Another said in January 2026 that the team would not accept a preemption-disable API, would be more open to one that expresses intent ("latency-oriented" against "batch-oriented"), and tries very hard not to give goroutines identity.
- [golang/go#78329](https://github.com/golang/go/issues/78329), "proposal: runtime: add runtime.SleepUntilIdle cooperative yield API", open with no Go team answer yet. It lets background goroutines step aside when other work is waiting, but it says checking the network poller is expensive enough to be sampled at most, so poller waiters stay mostly invisible to it.
- [golang/go#32097](https://github.com/golang/go/issues/32097), "Does Golang need priority in Goroutine？", closed in 2019 without technical discussion.

No issue asks the scheduler to poll the network every N ticks, no accepted change makes a busy scheduler poll more often, and the 10 ms values are unchanged. quic-go upstream has no issue tying throughput collapse to a saturated process.

## Method

- **Rig addition** (`codex/native-gap-rig` [`b01af53f`](https://github.com/GridSwarm/wiremux/commit/b01af53f), documented in PROTOCOL.md):
  - `-goload-duty F` and `-goload-period D` (default 1 ms) make each `-goload` goroutine busy for F×D of wall time and then block in `time.Sleep` for the rest. The `goload` object reports the busy share and the sleeps the goroutines actually got. F = 1 is #1857's CPU-bound goroutine, unchanged.
  - Every result line now carries `num_cpu` beside `gomaxprocs`.
- **Build** (one binary for every `tb` cell, the same tree for minimax; nothing pushed but the rig commit):
  - #1857's probe `bef05a64` with the rig commit cherry-picked (`dba51f66`), built against #1857's fork copy (`qgf-1857` at `d78d71b`, read-only), go1.27.2. darwin/arm64 and linux/amd64 (`CGO_ENABLED=0`) from the same tree, both on mbp128 before the first run.
- **Launch:** every `tb` sender runs through `spawnctx -type daemon` inside its own `ssh mbp128` session, at the default class, with `WIREMUX_PROBE1851_RECVSTATS=1` (acknowledgment reads and the gaps between them) and `-threads -schedlat`. `GOMAXPROCS` is set in the sender's environment where a cell changes it; the receiver keeps its default.
- **`tb` campaign** (M1):
  - 72 cells in 23 load steps: A (0 and 12–16 goroutines at `GOMAXPROCS` 16, both shapes, three arms on connected; 24 on connected), B (`GOMAXPROCS` 24 and 32 with 16 and 24 goroutines, both shapes; 32 unloaded), C (`GOMAXPROCS` 8 with 0, 4, 6, 7 and 8 goroutines), D (16 and 24 goroutines at 50%, 80% and 95% busy).
  - Three 10 s runs per cell (216 runs), one claim, 2026-10-17 20:55–23:07 UTC. Each repetition visits the steps in a rotated order and each step's cells in a rotated order.
  - A run started only with mbp128 at most 4 busy cores in a 1 s sample (1.1–4.0, median 2.0) and m4mini's load1 at most 8. Loaded runs were followed by 15 s of settling. 21 gate waits, none longer than a minute.
  - A six-run smoke campaign (5 s runs, never evidence) checked the scripts and that `GOMAXPROCS` and the duty flags took effect.
- **Microbenchmark** (W1, mbp128, `tools/wakelat`): netpoll, blocking and busy-polling readers at 0, 8, 12, 14, 15, 16, 17, 20, 24 and 32 goroutines (`GOMAXPROCS` 16) and 0, 4, 6, 7, 8, 12 and 16 (`GOMAXPROCS` 8), plus two-hand-off chains and a 20,000-per-second rate with an adaptive poller. Two rotated repetitions of 6 s (128 runs), under its own claim, 23:07–23:38 UTC, gated like the campaign. The pinger's own lateness is recorded and excluded.
- **`netns` campaign** (N1): 23 cells (0, 1, 2, 3, 4 and 6 goroutines at the default `GOMAXPROCS` 4, Datagrams at the pin and the stream, plus the default-GC row at 0, 3 and 4; `GOMAXPROCS` 8 at 4 and 6; 80% busy at 4 and 6), three 10 s runs each (69 runs), 2026-10-18 01:55–02:18 UTC, with the rig's `netns` setup: the stock shape, sender `taskset -c 4-7`, receiver 12-15, port 47400, `-schedlat` and `WIREMUX_PROBE1851_RECVSTATS=1` on the sender. Every run was gated on no other session's `nativerig` on minimax and nothing on port 47400 (no waits), and a four-run smoke ran first. Then W2: the microbenchmark pinned to CPUs 4-7 with its pinger on 12-15, 0–8 goroutines (66 runs), 02:18–02:29 UTC. Analysis ran on mbp128 after the runs, never on minimax.
- **Source reading:** the fork at `v0.62.1-fast.7`, wiremux `main` at `870295a4` and the probe tree, Go 1.27.2's runtime. golang/go issues were searched with `gh` and each one cited was opened and checked on 2026-10-17; the review comment on CL 392314 was read on Gerrit.
- **Sharing the hosts:**
  - No other session's `tb` work ran during any run (overlap logger, 1,244 samples).
  - A read-only `ras consider` from a quic-go-fast session ran on mbp128 until 21:46 UTC, during the campaign's first 82 runs. Its reviewers used up to 0.4 of a core at times and ran no builds or tests: a 5 s logger of non-rig processes (from 21:10) saw no `ras review`, `go build`, `go test`, lint or compiler process at any time, and the minute-by-minute host log before it showed none either. Those 82 runs sat at a median 1.003 of their cells' other runs (25% off by more than 10%, against 36% of the runs after), so none was re-run. macOS daemons (`fseventsd`, `mediaanalysisd`, `corespotlightd`) used more than half a core in about 20% of samples; the busy-core gate held each run's start.
  - Two quic-go-fast sessions held their builds, tests and review rounds on mbp128 until this session's "tb free" at 23:38 UTC. minimax was assigned to a quic-go-fast session's counted stage until 01:47 UTC; this session's minimax runs started at 01:54 after its "minimax free". Before this session learned that stage was running, it made seven read-only checks on minimax between 23:47 and 00:51 UTC (load average and a process list, each a few milliseconds), logged in `coordination.log`.
- **Flags:** 18 runs fell outside 0.8–1.2× of their cell's median. 13 were in collapsed cells (4–94 Mbit/s), where a few Mbit/s is the whole spread. The others: one 95%-busy Datagram run at 632 against a median of 1,155, two default-GC runs (959 and 378 against 678 and 619), one stream run (1,274 against 1,614) and two 32/24 batched-receive Datagram runs (720 and 1,184 against 921). None was dropped: medians of three absorb them.

## Limits

- **Synthetic load.** The goroutines are pure integer loops, or loops that sleep on a timer. A real pipeline blocks on channels and I/O and allocates, which leaves more turns (section 4's duty-cycled rows bracket it) but also collects more often (the default-GC row).
- **The consumer's work is a proxy.** Iterations per second measure CPU time the goroutines got, not a real consumer's output.
- **One sending Mac.** The tipping point is Go's and should hold on any machine, but the loss below it depends on the core count and mix (12 performance and 4 efficiency cores here). The receiving Mac was idle.
- **The microbenchmark is loopback,** and its pinger sleeps on a timer that sometimes ran late; late pings arrive in bursts, which slightly flatters every reader. It sizes the receive styles; it doesn't measure a Wire built on them.
- **The design sizes are estimates.** No alternative read loop, merged goroutine or runtime change was built.
- **The sending Mac drifted.** The unloaded rows' second repetition (22:04 UTC, with no other session active) ran 7–14% above the first and third, the sender drift the map's Notes describe; each unloaded median is the first or third repetition. `GOMAXPROCS` 32 unloaded ran 6–10% faster than 16, within that spread; this note doesn't claim a gain from it.
- **The Linux cell is shape only:** one host, namespaces joined by `veth`, and a sender pinned to four CPUs of a 16-core Ryzen. The tipping point is Go's, so it should sit at any Linux consumer's own `GOMAXPROCS`; the size of the loss below it is this cell's.

## Implications for the map

- **For [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801):**
  - Any native throughput target, on macOS and on Linux, assumes the consumer leaves at least one Go processor free of goroutines that never block. With none free, every shape measured delivers under 2% of its rate (0.05–0.5% at the default `GOMAXPROCS`), and nothing found inside wiremux or the fork changes that.
  - On Linux the processor count is the CPUs the process may use, so a consumer pinned or limited to few CPUs reaches the cliff sooner: at 4 busy goroutines in the `netns` cell, where 3 already cost 42–45%.
  - Below that, a busy consumer shares cores with the transport: 12–15 always-busy goroutines on 16 processors cost 20–65%, as #1857's spinners did. A target measured on an idle Mac overstates a busy one by that much.
  - Whether to make headroom a documented consumer requirement (with starvation detection), or to pursue a runtime change upstream, is a decision for a grilling ticket (open question 1). A read loop outside the poller is the only in-tree option with any effect at the cliff, and its estimated effect is small.
- **For GridCast** (its own map's business, cited here only as evidence): a pipeline whose stages block is safe from the collapse; a CPU-bound worker pool sized to `GOMAXPROCS` is not.
- **For [Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858):** no thread class helps at the cliff (#1857 showed it at 16 and 24), and section 2 shows the cliff even with idle performance cores, so the class decision is independent of this one.
- **The default-GC row matters here.** A consumer that collects at the rig's rate loses 51–77% at 12–15 busy goroutines, against 20–44% at the pin.

## Open questions

These are candidate tickets.

1. **Should native throughput targets require consumer headroom, or should wiremux pursue a scheduler fix?** Decide between a documented requirement (at least one Go processor free of never-blocking goroutines, ideally `GOMAXPROCS` minus three or four for full rate on the macOS shapes), a starvation signal in wiremux, a read loop outside the poller, and a runtime proposal upstream. Blocks #1801.
2. **How much would a scheduler that polls the network when its last poll is old restore?** Prototype the change suggested on golang/go#51651 in a patched Go toolchain, run section 1's sweep with it, and decide whether to propose it upstream. Only worth doing if question 1 wants a design answer.
3. **How many never-blocking goroutines does a real consumer keep?** GridCast's pipeline was not measured; its stages may block often enough to stay clear.

## Evidence

`native-gap-evidence/1865-goroutine-headroom/` (README.txt indexes it):

- `M1/`: the `tb` campaign, with each run's `cmd`, gate, coalitions, both result lines and counters, plus `rows.jsonl` and `tables.md`.
- `S0/`: the smoke runs.
- `W1/`: the mbp128 microbenchmark (`rows.jsonl`, `tables.md`).
- `N1/`, `NS0/`, `W2/`: the `netns` campaign (`rows.jsonl`, `tables.md`), its smoke runs, and the pinned microbenchmark on minimax.
- `bin/q1865/`: the binaries and their recipe.
- `tools/`: `wakelat` (the microbenchmark), `spawnctx`, `coal` and the claim placeholder.
- `scripts/`: `campaign.sh`, `run.sh`, `sshsend.sh`, `nscampaign.sh`, `chainNS.sh`, `wcampaign.sh`, `wakelat.sh`, `busy.sh`, `claim*.sh`, `overlap.sh`, `hostlog.sh`, `foreign.sh`, `build.sh`, `sum.py`, `agg.py`, `wtab.py`.
- `sources/`: Go 1.27.2's `proc.go`, minimax's scheduler settings.
- Logs: `coordination.log`, `overlap.log`, `foreign.log`, `hostlog.txt`, `claim.log`.
