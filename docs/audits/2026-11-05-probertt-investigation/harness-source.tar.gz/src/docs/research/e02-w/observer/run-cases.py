import subprocess,time,json
from pathlib import Path
c=Path(__file__).resolve().parent
receipts=[]
for name,mode,linux,windows in [('direct','direct','observed','observed'),('disabled','disabled','observed','observed'),('managed','managed','observed','observed'),('mixed-upstream-linux','direct','upstream','observed'),('mixed-upstream-windows','direct','observed','upstream')]:
    leftlog=c/(name+'-linux.log');rightlog=c/(name+'-windows.log')
    left=['ssh','minimax',f'E02_CONTROL=192.168.122.1:42980 E02_CASE={mode} GOMAXPROCS=4 /home/josh/e02-w-native-20260916b/{linux}-linux -test.run ^TestE02WindowsCrossHost$ -test.v -test.timeout=5m']
    # Mixed-peer examples preserve functionality; upstream cannot supply URO batches.
    require='0' if name.startswith('mixed') else '1'
    right=['ssh','-F',str(c/'ssh-config'),'e02-w-guest',f'cmd /c "set E02_CONTROL=192.168.122.1:42980&&set E02_CASE={mode}&&set E02_REQUIRE_NATIVE={require}&&set GOMAXPROCS=4&&C:\\Users\\e02observer\\{windows}-windows.exe -test.run ^TestE02WindowsCrossHost$ -test.v -test.timeout=5m"']
    print('case started: '+name,flush=True)
    with leftlog.open('w') as lf,rightlog.open('w') as rf:
        lp=subprocess.Popen(left,stdout=lf,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+15
        while 'E02_CONTROL_READY' not in leftlog.read_text() and time.monotonic()<deadline:
            if lp.poll() is not None:break
            time.sleep(.1)
        if 'E02_CONTROL_READY' not in leftlog.read_text():raise SystemExit('host readiness failed: '+name)
        rp=subprocess.run(right,stdout=rf,stderr=subprocess.STDOUT,timeout=310)
        try:lc=lp.wait(timeout=15)
        except subprocess.TimeoutExpired:lp.terminate();lc=lp.wait(timeout=15)
    receipt={'case':name,'linux_exit':lc,'windows_exit':rp.returncode,'linux_command':left,'windows_command':right}
    receipts.append(receipt);(c/'native-exits.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print(receipt,flush=True)
    if lc or rp.returncode:raise SystemExit('case failed: '+name)
