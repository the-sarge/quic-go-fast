from pathlib import Path
import hashlib,json,subprocess
w=Path.cwd();c=w/'.cache/e02-w';f=c/'fork-source';out=c/'overlay';out.mkdir(exist_ok=True)
expected=json.loads((c/'expected-source-hashes.json').read_text());replace={}
def put(src,txt):
 target=out/(hashlib.sha256(str(src).encode()).hexdigest()[:12]+'-'+src.name);target.write_text(txt);replace[str(src)]=str(target)
def patch(base,name,pairs):
 src=base/name;txt=src.read_text();key=('fork:' if base==f else 'wiremux:')+name
 if hashlib.sha256(txt.encode()).hexdigest()!=expected[key]:raise ValueError('frozen source mismatch: '+key)
 for old,new in pairs:
  if txt.count(old)!=1:raise ValueError((name,old[:80],txt.count(old)))
  txt=txt.replace(old,new,1)
 put(src,txt)
put(f/'e02_observer.go',(c/'e02_observer.go.txt').read_text())
patch(f,'transport.go',[('type Transport struct {','type Transport struct {\n e02slot *e02Slot\n e02candidate *E02Observation')])
patch(f,'external_packet_io.go',[
 ('c.external = &externalPacketIO{conn: conn, allowReceiveCoalescing: allowReceiveCoalescing, sendBatch: sendBatch}','c.external = &externalPacketIO{conn: conn, allowReceiveCoalescing: allowReceiveCoalescing, sendBatch: sendBatch}\n t.e02slot.bind(t.e02candidate,"direct")'),
 ('return newUDPBatchWriter(conn), nil','return newUDPBatchWriter(conn, t.e02slot), nil'),
 ('func ordinaryUDPBatchWriter(conn udpMessageWriter)','func ordinaryUDPBatchWriter(conn udpMessageWriter, slots ...*e02Slot)'),
 ('\t\tfor i, buf := range bufs {','\t\tfor i, buf := range bufs {\n var slot *e02Slot;if len(slots)>0{slot=slots[0]};eo,at:=e02Start(slot)'),
 ('\t\t\tif err != nil {\n\t\t\t\tif isSendMsgSizeErr(err)', '\t\t\tif err != nil {\n eo.send(at,addr,n,len(buf),0,err)\n\t\t\t\tif isSendMsgSizeErr(err)'),
 ('\t\t\tif n != len(buf) || oobn != len(oob) {','\t\t\tif n != len(buf) || oobn != len(oob) {\n eo.send(at,addr,n,len(buf),0,io.ErrShortWrite)'),
 ('\t\t\t\treturn i, io.ErrShortWrite\n\t\t\t}', '\t\t\t\treturn i, io.ErrShortWrite\n\t\t\t}\n eo.send(at,addr,n,len(buf),0,nil)'),
 ('\tl.lease.quic = true','\tl.lease.quic = true\n e.e02slot.bind(t.e02candidate,"managed");t.e02slot=e.e02slot'),
 ('\treturn &externalPacketConn{rawConn: conn, config: c}','\tif raw,ok:=conn.(interface{e02Bind(*e02Slot)});ok{raw.e02Bind(t.e02slot)}\n\treturn &externalPacketConn{rawConn: conn, config: c}')])
patch(f,'external_packet_io_batch_fallback.go',[
 ('func newUDPBatchWriter(conn udpMessageWriter)','func newUDPBatchWriter(conn udpMessageWriter, slots ...*e02Slot)'),
 ('return ordinaryUDPBatchWriter(conn)','return ordinaryUDPBatchWriter(conn,slots...)')])
patch(f,'managed_packet_endpoint.go',[
 ('type managedPacketEndpoint struct {','type managedPacketEndpoint struct {\n e02slot *e02Slot'),
 ('e := &managedPacketEndpoint{conn: conn, buffers: inspectManagedBuffers(conn, receiveErr, sendErr)}','e := &managedPacketEndpoint{conn: conn, buffers: inspectManagedBuffers(conn, receiveErr, sendErr),e02slot:&e02Slot{}}'),
 ('e.sendBatch = newUDPBatchWriter(socket)','e.sendBatch = newUDPBatchWriter(socket,e.e02slot)'),
 ('\tpacket, err := e.receiver.ReadPacket()','\teo,at:=e02Start(e.e02slot)\n\tpacket, err := e.receiver.ReadPacket()'),
 ('\tdefer packet.buffer.Release()','\teo.receive(at,packet.remoteAddr,"delivery",len(packet.data),0)\n\tdefer packet.buffer.Release()'),
 ('\te.lease = nil','\te.e02slot.value.Store(nil)\n\te.lease = nil')])
patch(f,'managed_packet_receive_windows.go',[('\te.receiver = receiver','\treceiver.e02slot=e.e02slot\n\te.receiver = receiver')])
patch(f,'sys_conn.go',[
 ('type basicConn struct {','type basicConn struct {\n e02slot *e02Slot'),
 ('\treturn c.WriteTo(b, addr)','\teo,at:=e02Start(c.e02slot);n,err=c.WriteTo(b,addr);eo.send(at,addr,n,len(b),0,err);return n,err')])
put(f/'e02_basic.go','package quic\nfunc(c *basicConn)e02Bind(s *e02Slot){c.e02slot=s}\n')
patch(f,'sys_conn_windows.go',[
 ('type windowsConn struct {','type windowsConn struct {\n e02slot *e02Slot'),
 ('func (c *windowsConn) ReadPacket() (receivedPacket, error) {','func (c *windowsConn)e02Bind(s *e02Slot){c.e02slot=s}\nfunc (c *windowsConn) ReadPacket() (receivedPacket, error) {\n eo,at:=e02Start(c.e02slot)'),
 ('\t\tn, oobn, flags, addr, err := c.ReadMsgUDP(buffer.Data, c.oobBuffer)','\t\tn, oobn, flags, addr, err := c.ReadMsgUDP(buffer.Data, c.oobBuffer)\n eo.receive(at,addr,"call",n,0)'),
 ('\t\tif err != nil {\n\t\t\tbuffer.Release()','\t\tif err != nil {\n eo.receive(at,addr,"error",n,0)\n\t\t\tbuffer.Release()'),
 ('oobn > len(c.oobBuffer)) {','oobn > len(c.oobBuffer)) {\n eo.receive(at,addr,"reject",n,0)'),
 ('if c.cap.GRO && (!valid || segmentSize < 0 || segmentSize > n) {','if c.cap.GRO && (!valid || segmentSize < 0 || segmentSize > n) {\n eo.receive(at,addr,"reject",n,0)'),
 ('\t\treturn c.delivery.accept(p, segmentSize), nil','\t\teo.receive(at,addr,"valid",n,segmentSize)\n\t\treturn c.delivery.accept(p, segmentSize), nil'),
 ('\tn, _, err := c.WriteMsgUDP(b, oob, udpAddr)','\teo,at:=e02Start(c.e02slot)\n\tn, _, err := c.WriteMsgUDP(b, oob, udpAddr)'),
 ('\treturn n, err\n}', '\teo.send(at,addr,n,len(b),int(gsoSize),err)\n\treturn n, err\n}')])
patch(w,'transport/quic/transport.go',[
 ('\treturn &session{','\tsessionCtx=quicgo.E02Context(sessionCtx,quicgo.E02FromContext(ctx))\n\treturn &session{'),
 ('adapter.NewQUICTransport(conn, remote, s.packetPermission)','adapter.NewQUICTransport(conn, remote, s.packetPermission,quicgo.E02FromContext(s.ctx))')])
patch(w,'transport/internal/adapter/packet_permission.go',[
 ('grant packetpermission.Grant)','grant packetpermission.Grant, observers ...*quicgo.E02Observation)'),
 ('\ttransport := &quicgo.Transport{Conn: selected}','\ttransport := &quicgo.Transport{Conn: selected}\n if len(observers)>0{transport.E02Attach(observers[0],conn.LocalAddr().String(),remote.String(),fmt.Sprintf("%T",selected))}'),
 ('\t\ttransport.Conn = selected','\t\ttransport.Conn = selected\n if len(observers)>0{transport.E02Attach(observers[0],conn.LocalAddr().String(),remote.String(),fmt.Sprintf("%T",selected))}')])
put(w/'internal/integration/e02_native_test.go',(c/'e02_native_test.go.txt').read_text())
put(w/'internal/integration/e02_hook_test.go',(c/'e02_hook_test.go.txt').read_text())
subprocess.run(['gofmt','-w',*replace.values()],check=True)
(c/'overlay.json').write_text(json.dumps({'Replace':replace},indent=2)+'\n')
print('overlay files:',len(replace))
