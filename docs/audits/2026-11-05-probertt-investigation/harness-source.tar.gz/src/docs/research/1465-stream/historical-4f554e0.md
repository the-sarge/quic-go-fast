# Initial reliable-stream comparison evidence

These pre-fix captures retain their original bulk-delivery observations. They predate propagation of effective setup-resource shutdown errors and are superseded for final S3 evidence by the [corrected report](README.md).

All five clean layer captures and three separate profiler captures completed on 2026-09-06 from clean revision `4f554e0c99fb1a1d7d7fb4049f0802c4b01eec52`. Every declared measurement byte was validated. This is local harness evidence, not a capacity ranking, physical qualification or GridCast end-to-end measurement.

## Provenance and workload

The optimized binary SHA-256 is `c95b82a932f0a44c3d61db3d84224c50d7aea5e6bba28f65fff5b14e71dfe807`. The durable archive `/Users/josh/Documents/wiremux-measurements/1465-20260906` retains that binary, exact commands/configurations, raw results, stderr, host-load snapshot and profiles. [Archive inventory](historical-manifest.json) records sizes and digests; [derived summary](historical-summary.json) retains the report inputs. Documentation commits do not relabel the binary revision.

Each clean run used 100,000,000 offered bit/s, one forward connection, batched 1076-byte records, GOMAXPROCS=4, 5 s warmup, 10 s measurement and at most 10 s drain. The three separate captures used 0 s warmup, 2 s measurement and at most 1 s drain. Runs were sequential on local macOS loopback. Heavy profiling was off in all five clean captures. No quiet-host reservation or affinity was imposed; the retained host snapshot shows concurrent foreign test processes and OS/background activity. No OS/physical/impairment campaign ran, and resource differences cannot establish transport or OS causality.

## Finite delivery

| Run | Receiver-window Mbps | Desired = validated bytes | Cohort completion seconds |
| --- | ---: | ---: | ---: |
| [tcp](raw/tcp/result.json) | 99.993971 | 124999996 | 10.000095042 |
| [tls-tcp](raw/tls-tcp/result.json) | 99.989667 | 124999996 | 10.000164353 |
| [native](raw/native/result.json) | 99.999997 | 124999996 | 9.999985167 |
| [adapter](raw/adapter/result.json) | 99.991389 | 124999996 | 10.000184709 |
| [wire](raw/wire/result.json) | 99.991389 | 124999996 | 10.000195896 |
| [wire-cpu](raw/wire-cpu/result.json) | 99.960400 | 24999784 | 2.000131083 |
| [wire-trace](raw/wire-trace/result.json) | 99.947488 | 24999784 | 2.000116500 |
| [native-qlog](raw/native-qlog/result.json) | 99.994832 | 24999784 | 2.000009978 |

Every run retained zero desired-unreceived, accepted-unreceived and unsent bytes at completion, with validated terminal/phase-finished records and successful shutdown. Late records remain excluded from window goodput. Per-connection counters and resource samples are in the raw results; no write count is interpreted as remote delivery.

All Wire and adapter receipts report direct carriers. Full Wire verifies canonical `CarrierTopologyDirect` and uses production Dial, authenticated upgrade and encrypted channel framing. Native QUIC reports observed TLS ALPN/cipher/GSO, while wrapped receipts explicitly distinguish source-derived profile settings from private/unobserved negotiated values. TCP has no authentication/encryption; TLS/TCP and native QUIC pin ephemeral certificates. Native raw UDP and the production selected-remote socket wrapper remain different. Effective socket buffers, congestion/offload counters and remote flow-control negotiation remain unobserved.

## Profiling, resources and limits

Both Wire CPU files parsed against the archived binary: [sender](raw/wire-cpu/send-pprof-top.txt), [receiver](raw/wire-cpu/receive-pprof-top.txt). Both execution traces produced scheduler profiles: [sender](raw/wire-trace/send-sched-top.txt), [receiver](raw/wire-trace/receive-sched-top.txt). Both native qlogs parsed as JSON sequences: [sender receipt](raw/native-qlog/send-parsed.json), [receiver receipt](raw/native-qlog/receive-parsed.json). All six original capture manifests had nonempty, untruncated files, matching run/role/digest associations and no recorded capture error. Trace/qlog timelines retain their declared partial scopes; handshake/drain omission is not full connection coverage. Adapter/Wire qlog remains explicitly unavailable.

Raw samples retain process user/system CPU, allocation/heap counters, current resident bytes, actual monotonic collection offsets/cost and post-drain GC heap. Resource collection and deterministic generation/checking costs remain included. Samples are not instantaneous resident maxima; worker process cost excludes the controller, relay and foreign host work. Process CPU is not apportioned among connections. Short profiler runs differ in duration from clean runs and cannot establish a precise overhead percentage. Physical sample-boundary/collector-overhead budgets, OS update resolution, quiet-host conditions, Windows execution and host/VM accounting remain unqualified.

CPU deltas use each peer’s first/last actual monotonic sample span. The following values describe only these individual local runs; concurrent host activity prevents efficiency attribution.

| Clean run / role | CPU seconds | Average cores | Sampled resident peak MiB | Post-drain live heap MiB | Allocated MiB | Largest collection ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| tcp / send | 0.457848 | 0.0458 | 18.500 | 0.553 | 2.120 | 0.116 |
| tcp / receive | 0.261854 | 0.0262 | 14.594 | 0.559 | 0.125 | 0.074 |
| tls-tcp / send | 0.484837 | 0.0485 | 19.422 | 0.609 | 2.156 | 0.088 |
| tls-tcp / receive | 0.281844 | 0.0282 | 15.172 | 0.591 | 0.121 | 0.085 |
| native / send | 1.479409 | 0.1480 | 21.641 | 0.650 | 14.225 | 0.170 |
| native / receive | 1.589899 | 0.1590 | 22.203 | 0.767 | 22.429 | 0.665 |
| adapter / send | 1.485505 | 0.1486 | 21.094 | 0.658 | 14.168 | 0.479 |
| adapter / receive | 1.563496 | 0.1564 | 22.000 | 0.775 | 22.744 | 0.084 |
| wire / send | 1.515277 | 0.1515 | 22.781 | 0.780 | 13.897 | 2.754 |
| wire / receive | 1.478546 | 0.1479 | 22.812 | 0.691 | 22.855 | 1.371 |

The deterministic fixtures cover partial reads/writes, corruption, truncation, wrong sequence/identity/terminal, extra bulk after terminal, invalid control, stalled I/O and cancellation. Subprocess fixtures cover all five layers, four bidirectional Wires with small writes/control/receiver pauses, and four reverse native QUIC connections with separate qlogs. These finite scenarios are correctness checks, not extra capacity captures. The [approved contract](../../work-items/1465-stream-comparisons.md) and [usage documentation](../../MEASUREMENT.md#reliable-stream-comparison-ladder-version-3) define the representation, finality boundary and finite evidence budget.

S4/S5 own physical qualification and any unresolved instrumentation prerequisites. Version-2 EOF investigation #1477 remains separate. No production optimization, transport substitution or consumer benefit is claimed.
