# Local reliable-stream comparison evidence

All five clean layer captures and three separate profiler captures completed on 2026-09-06 from clean revision `87dfd462e4f6b7d00bbc714a17dc70cf184664ff`. Every declared measurement byte was validated. This is local harness evidence, not a capacity ranking, physical qualification or GridCast end-to-end measurement.

The [initial capture report](historical-4f554e0.md), [initial summary](historical-summary.json) and [initial inventory](historical-manifest.json) retain the original evidence. The [review ledger](review.md) explains the owned-resource shutdown-error correction. Each corrected configuration ran once; these replacements follow a correctness repair, not repeated attempts to improve performance.

## Provenance and workload

The optimized binary SHA-256 is `73fc4d510eb3c1e8e8280f4a54fd5fa80b36ad12c1733652d443b0e467bc8538`. The durable archive `/Users/josh/Documents/wiremux-measurements/1465-20260906-fixed` retains that binary, exact commands/configurations, raw results, stderr, host-load snapshot and profiles. [Archive inventory](archive-manifest.json) records sizes and digests; [derived summary](summary.json) retains the report inputs. Documentation commits do not relabel the binary revision.

Each clean run used 100,000,000 offered bit/s, one forward connection, batched 1076-byte records, GOMAXPROCS=4, 5 s warmup, 10 s measurement and at most 10 s drain. The three separate captures used 0 s warmup, 2 s measurement and at most 1 s drain. Runs were sequential on local macOS loopback. Heavy profiling was off in all five clean captures. No quiet-host reservation or affinity was imposed; the retained host snapshot shows concurrent foreign test processes and OS/background activity. No OS/physical/impairment campaign ran, and resource differences cannot establish transport or OS causality.

## Finite delivery

| Run | Receiver-window Mbps | Desired = validated bytes | Cohort completion seconds |
| --- | ---: | ---: | ---: |
| [tcp](raw/final-tcp/result.json) | 99.997414 | 124999996 | 10.000033541 |
| [tls-tcp](raw/final-tls-tcp/result.json) | 99.992250 | 124999996 | 10.000169146 |
| [native](raw/final-native/result.json) | 99.999997 | 124999996 | 9.999992480 |
| [adapter](raw/final-adapter/result.json) | 99.985363 | 124999996 | 10.000358979 |
| [wire](raw/final-wire/result.json) | 99.991389 | 124999996 | 10.000170374 |
| [wire-cpu](raw/final-wire-cpu/result.json) | 99.986224 | 24999784 | 2.000089771 |
| [wire-trace](raw/final-wire-trace/result.json) | 99.973312 | 24999784 | 2.000217229 |
| [native-qlog](raw/final-native-qlog/result.json) | 99.999136 | 24999784 | 1.999968980 |

Every run retained zero desired-unreceived, accepted-unreceived and unsent bytes at completion, with validated terminal/phase-finished records and successful shutdown. Late records remain excluded from window goodput. Per-connection counters and resource samples are in the raw results; no write count is interpreted as remote delivery.

All Wire and adapter receipts report direct carriers. Full Wire verifies canonical `CarrierTopologyDirect` and uses production Dial, authenticated upgrade and encrypted channel framing. Native QUIC reports observed TLS ALPN/cipher/GSO, while wrapped receipts explicitly distinguish source-derived profile settings from private/unobserved negotiated values. TCP has no authentication/encryption; TLS/TCP and native QUIC pin ephemeral certificates. Native raw UDP and the production selected-remote socket wrapper remain different. Effective socket buffers, congestion/offload counters and remote flow-control negotiation remain unobserved.

## Profiling, resources and limits

Both Wire CPU files parsed against the archived binary: [sender](raw/final-wire-cpu/send-pprof-top.txt), [receiver](raw/final-wire-cpu/receive-pprof-top.txt). Both execution traces produced scheduler profiles: [sender](raw/final-wire-trace/send-sched-top.txt), [receiver](raw/final-wire-trace/receive-sched-top.txt). Both native qlogs parsed as JSON sequences: [sender receipt](raw/final-native-qlog/send-parsed.json), [receiver receipt](raw/final-native-qlog/receive-parsed.json). All six original capture manifests had nonempty, untruncated files, matching run/role/digest associations and no recorded capture error. Trace/qlog timelines retain their declared partial scopes; handshake/drain omission is not full connection coverage. Adapter/Wire qlog remains explicitly unavailable.

Raw samples retain process user/system CPU, allocation/heap counters, current resident bytes, actual monotonic collection offsets/cost and post-drain GC heap. Resource collection and deterministic generation/checking costs remain included. Samples are not instantaneous resident maxima; worker process cost excludes the controller, relay and foreign host work. Process CPU is not apportioned among connections. Short profiler runs differ in duration from clean runs and cannot establish a precise overhead percentage. Physical sample-boundary/collector-overhead budgets, OS update resolution, quiet-host conditions, Windows execution and host/VM accounting remain unqualified.

CPU deltas use each peer’s first/last actual monotonic sample span. The following values describe only these individual local runs; concurrent host activity prevents efficiency attribution.

| Clean run / role | CPU seconds | Average cores | Sampled resident peak MiB | Post-drain live heap MiB | Allocated MiB | Largest collection ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| tcp / send | 0.455936 | 0.0456 | 18.453 | 0.571 | 1.985 | 0.119 |
| tcp / receive | 0.262880 | 0.0263 | 14.734 | 0.561 | 0.121 | 0.108 |
| tls-tcp / send | 0.501609 | 0.0502 | 19.109 | 0.632 | 2.023 | 0.105 |
| tls-tcp / receive | 0.289263 | 0.0289 | 15.562 | 0.608 | 0.121 | 0.098 |
| native / send | 1.731602 | 0.1732 | 22.031 | 0.654 | 13.704 | 0.072 |
| native / receive | 1.599030 | 0.1599 | 22.047 | 0.777 | 22.852 | 0.080 |
| adapter / send | 1.921622 | 0.1922 | 21.281 | 0.679 | 12.652 | 0.135 |
| adapter / receive | 1.551430 | 0.1552 | 21.516 | 0.767 | 22.276 | 0.115 |
| wire / send | 2.207937 | 0.2208 | 22.641 | 0.666 | 12.488 | 0.162 |
| wire / receive | 1.711002 | 0.1711 | 23.297 | 0.790 | 22.198 | 0.121 |

The deterministic fixtures cover partial reads/writes, corruption, truncation, wrong sequence/identity/terminal, extra bulk after terminal, invalid control, stalled I/O and cancellation. Subprocess fixtures cover all five layers, four bidirectional Wires with small writes/control/receiver pauses, and four reverse native QUIC connections with separate qlogs. These finite scenarios are correctness checks, not extra capacity captures. The [approved contract](../../work-items/1465-stream-comparisons.md) and [usage documentation](../../MEASUREMENT.md#reliable-stream-comparison-ladder-version-3) define the representation, finality boundary and finite evidence budget.

S4/S5 own physical qualification and any unresolved instrumentation prerequisites. Version-2 EOF investigation #1477 remains separate. No production optimization, transport substitution or consumer benefit is claimed.
