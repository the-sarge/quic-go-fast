# C01 — Consumer coverage and reusable example

This record owns the current inventory for [C01](https://github.com/GridSwarm/wiremux/issues/1538), under [track W](https://github.com/GridSwarm/wiremux/issues/1520). Its acceptance authority is plan commit `c4c9f62395820193b33fd3b9d4196e7a6667cd1a`, [“C01 — Reconcile consumer coverage and reusable example”](../adr/2026-09-15-wiremux-packet-io-plan.md#c01--reconcile-consumer-coverage-and-reusable-example). The historical [handoff inventory](../adr/2026-09-15-packet-io-handoff-audit.md#consumer-inventory) remains source history. This recheck is bounded to its six named repositories, not all GitHub repositories or every local checkout.

## Current inventory

Read back on 2026-09-17 from the default-branch revisions below. Go's module resolver owns module syntax and selection; each main module owns its fork replacement. Library replacements do not propagate to applications.

| Repository and inspected revision | Current selection and disposition | Adoption and rollback evidence |
| --- | --- | --- |
| [GridSwarm/codemux](https://github.com/GridSwarm/codemux/blob/5b6e3435cd24e60ef54113eed1bd8a91d2ad1a08/go.mod) `5b6e3435cd24e60ef54113eed1bd8a91d2ad1a08` | Library: wiremux `v0.2.2`, ordinary upstream QUIC `v0.62.0`, no replacement. Released as codemux `v0.5.1`. | [Compatibility PR #600](https://github.com/GridSwarm/codemux/pull/600), [release PR #602](https://github.com/GridSwarm/codemux/pull/602), [compatibility/rollback receipt](https://github.com/GridSwarm/codemux/blob/5b6e3435cd24e60ef54113eed1bd8a91d2ad1a08/docs/research/2026-09-17-wiremux-v022-compatibility.md). |
| [GridCastIO/gridcast](https://github.com/GridCastIO/gridcast/blob/0dc10dc53031b408369066f1775194a26ecd6880/go.mod) `0dc10dc53031b408369066f1775194a26ecd6880` | Application: codemux `v0.5.1`, wiremux `v0.2.2`, upstream-path QUIC `v0.62.0` replaced by `github.com/the-sarge/quic-go-fast v0.62.1-fast.3`. | [Adoption PR #1102](https://github.com/GridCastIO/gridcast/pull/1102), [selection and rollback instructions](https://github.com/GridCastIO/gridcast/blob/0dc10dc53031b408369066f1775194a26ecd6880/docs/quic-io-adoption.md), [fork/upstream regression and rebuilt-artifact receipt](https://github.com/GridCastIO/gridcast/pull/1102#issuecomment-5708134567). |
| [SwarmCast/tapmux](https://github.com/SwarmCast/tapmux/blob/bdda744f08ca1ce8a89a7f20ce02a2fdba8cfca9/go.mod) `bdda744f08ca1ce8a89a7f20ce02a2fdba8cfca9` | Application: codemux `v0.5.1`, wiremux `v0.2.2`, upstream-path QUIC `v0.62.0` replaced by `github.com/the-sarge/quic-go-fast v0.62.1-fast.3`. | [Adoption PR #701](https://github.com/SwarmCast/tapmux/pull/701), [selection, named evidence and upstream rollback](https://github.com/SwarmCast/tapmux/blob/bdda744f08ca1ce8a89a7f20ce02a2fdba8cfca9/docs/quic-io-adoption.md), [post-merge journal](https://github.com/SwarmCast/tapmux/pull/702). |
| [GridSwarm/keymux](https://github.com/GridSwarm/keymux/tree/67bdae31a7f933d1e0699d08e0042543eaf839a0) `67bdae31a7f933d1e0699d08e0042543eaf839a0` | Dormant implementation: unchanged since handoff, no Go module. No adoption is claimed. | Existing deferred-source disposition; no migration or rollback needed. |
| [SwarmCast/swarmcast](https://github.com/SwarmCast/swarmcast/blob/b251dbd4a232c7c21cd0ae88c1a3cda2eaa0025c/go.mod) `b251dbd4a232c7c21cd0ae88c1a3cda2eaa0025c` | Current module changed since handoff but still has no wiremux, codemux or QUIC dependency. Not a consumer of this integration. | No adoption or deployment claimed; no migration needed. |
| [SwarmCast/swarmcast-legacy](https://github.com/SwarmCast/swarmcast-legacy/blob/ea5eea40c6b133ac5d922412d6fb5b04251d58b1/go.mod) `ea5eea40c6b133ac5d922412d6fb5b04251d58b1` | The handoff's local `SwarmCast/legacy/swarmcast-legacy` checkout; unchanged upstream QUIC `v0.59.0`. Legacy migration remains explicitly excluded. | Separate authorization is required to migrate it; its old pin is not this program's rollback target. |

No newly active consumer appears in this finite inventory, so no adoption child is added. Upstream quic-go, go-libp2p examples/test plans and go-btfs checkouts retain their excluded third-party/example dispositions. Fork fixtures and wiremux's tools module are validation/dependency contexts, not application adopters.

The selected published artifacts are [wiremux v0.2.2](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.2), [codemux v0.5.1](https://github.com/GridSwarm/codemux/releases/tag/v0.5.1), and [quic-go-fast v0.62.1-fast.3](https://github.com/the-sarge/quic-go-fast/releases/tag/v0.62.1-fast.3). The fork release carries GitHub's prerelease flag; the explicit application pin is intentional. The [verified wiremux publication receipt](https://github.com/GridSwarm/wiremux/issues/1533#issuecomment-5706947357) and [codemux publication receipt](https://github.com/GridSwarm/codemux/blob/5b6e3435cd24e60ef54113eed1bd8a91d2ad1a08/docs/research/2026-09-17-codemux-v051-release.md) own publication gates and artifact verification.

Neither GridCast nor tapmux currently constructs a managed packet endpoint. GridCast's authenticated `ManagedWire`/Resume API is a different lifecycle abstraction. Both application receipts preserve their existing setup, failure, idle, cancellation and teardown owners. They record source/build adoption and rollback evidence, not deployment or measured consumer acceleration. The [E02 support decision](e02-support.md) retains ordinary library defaults and unavailable assembled performance. Advisory review of upstream and fork remains owned by each application's repin/release policy.

## Standard-type example outside wiremux

The released fork retains its [external-extension fixture](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.3/testdata/externalpacketio/main.go). The standalone example below also shows managed lease acquisition and return without importing wiremux or fork-only named types. It uses a transparent wrapper, not a selected-peer policy implementation. No native writer bypass is exposed: nil batch callbacks retain ordinary sends. A real policy wrapper must enforce policy on every exposed receive/send path and register only its checked callback.

Copy this block to `main.go` in each isolated module described below. It compiles unchanged under upstream and fork. Upstream explicitly reports that optional capability is absent; it does not emulate managed reuse. The fork path creates a fresh endpoint, registers its exact original lease through the wrapper, closes the transport before returning the lease, and reacquires once. This is construction/cleanup example code, not an authenticated QUIC session, network workload, deployment or native-engagement receipt. Real callers must finish and join establishment I/O before binding, clear obsolete establishment deadlines, and finish connection use before transport/lease teardown. Do not use parent packet operations while leased. Raw socket handback after coalescing remains unsupported.

```go
package main

import (
    "errors"
    "fmt"
    "net"

    quic "github.com/quic-go/quic-go"
)

type externalV1 interface {
    ConfigureExternalPacketIOV1(net.PacketConn, bool, func([][]byte, []byte, *net.UDPAddr) (int, error)) error
    UDPBatchWriterV1(*net.UDPConn) (func([][]byte, []byte, *net.UDPAddr) (int, error), error)
}

type managedV1 interface {
    NewManagedPacketEndpointV1(string, *net.UDPAddr) (net.PacketConn, func() (net.PacketConn, error), error)
    ConfigureManagedPacketIOV1(net.PacketConn, net.PacketConn, func([][]byte, []byte, *net.UDPAddr) (int, error)) error
}

type wrapper struct{ net.PacketConn }

func ordinaryExternal() (err error) {
    socket, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
    if err != nil {
        return err
    }
    defer func() { err = errors.Join(err, socket.Close()) }()
    outer := &wrapper{socket}
    transport := &quic.Transport{Conn: outer}
    defer func() { err = errors.Join(err, transport.Close()) }()
    if extension, ok := any(transport).(externalV1); ok {
        // No receive-format mutation on this ordinary external socket.
        return extension.ConfigureExternalPacketIOV1(outer, false, nil)
    }
    return nil // Upstream keeps its ordinary PacketConn path.
}

func managedAttempt(acquire func() (net.PacketConn, error)) (err error) {
    lease, err := acquire()
    if err != nil {
        return err
    }
    defer func() { err = errors.Join(err, lease.Close()) }()
    outer := &wrapper{lease}
    transport := &quic.Transport{Conn: outer}
    defer func() { err = errors.Join(err, transport.Close()) }()
    extension, ok := any(transport).(managedV1)
    if !ok {
        return errors.New("managed packet I/O unavailable")
    }
    // No establishment I/O was started in this construction-only example.
    // Bind once; do not also call ConfigureExternalPacketIOV1.
    return extension.ConfigureManagedPacketIOV1(outer, lease, nil)
}

func reusable() (err error) {
    factory, ok := any(&quic.Transport{}).(managedV1)
    if !ok {
        fmt.Println("managed packet I/O unavailable; use ordinary sockets")
        return nil
    }
    endpoint, acquire, err := factory.NewManagedPacketEndpointV1("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
    if err != nil {
        return err
    }
    defer func() { err = errors.Join(err, endpoint.Close()) }()
    if err := managedAttempt(acquire); err != nil {
        return err
    }
    return managedAttempt(acquire)
}

func main() {
    if err := ordinaryExternal(); err != nil {
        panic(err)
    }
    if err := reusable(); err != nil {
        panic(err)
    }
}
```

Use separate directories with this `go.mod` for the upstream compile:

```go
module example.invalid/c01

go 1.27

toolchain go1.27.1

require github.com/quic-go/quic-go v0.62.0
```

In the fork directory only, append:

```go
replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.3
```

Audit the installed Go floor before any module/build command: `GOTOOLCHAIN=local go version`, `go version`, and `go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS`. Use an installed Go at least as new as this repository's approved floor. In each directory run `GOTOOLCHAIN=local GOWORK=off go mod tidy`, `GOTOOLCHAIN=local GOWORK=off go build .`, and `GOTOOLCHAIN=local GOWORK=off go list -m -json github.com/quic-go/quic-go`. The upstream record must have no replacement; the fork record must select the exact release above. Never import both repository paths in one module graph. This recipe isolates selection without modifying a shared checkout or global Go configuration; ordinary Go download/build caches may be populated.

For real wiremux establishment, retain the released [managed facade example](../../managed_packet_example_test.go) and [release guidance](../release/v0.2.2/notes.md#managed-reuse-and-peer-policy). It supplies the parent facade to wiremux, which acquires and disposes each exact lease. The standalone example above demonstrates the lower-level extension for other consumers; it does not replace that facade.

## Evidence boundary and program transition

Inventory, dependency records and this document are traceability metadata; examples and existing tests are verification aids. Representation is owned by Go and the existing library interfaces. The inventory guarantee covers only the named modules at the recorded revisions; compilation is example-level evidence, not universal behavior or performance qualification. Contract closure is not triggered. No maintained analyzer, additional safety owner, temporary seam, runtime mutation, stress count or native campaign is introduced.

Terminating evidence is one current manifest and linked receipt readback per inventory entry, unchanged example compilation in isolated upstream/fork modules, `task docs-check`, bounded review, exact-head local certification and successful post-ready required CI. No synthetic failing test or guard mutation is required for prose. Exact command receipts and review history belong in the product PR and post-merge journal. Effects outside the finite inventory and measured E02 domains remain unclaimed.

On merge, C01 is complete and [Z01](https://github.com/GridSwarm/wiremux/issues/1539) is ready: C01-CR, C01-G and C01-T are closed and no additional consumer child is needed. The [program index](../adr/2026-09-14-quic-packet-io-program.md) and [track plan](../adr/2026-09-15-wiremux-packet-io-plan.md) carry this transition. Only Z01 may close the program; C01 does not perform aggregate closeout.
