# Issue #1827: what the native receive path's per-packet allocations cost

Research for [#1827](https://github.com/GridSwarm/wiremux/issues/1827) on the wayfinder map [#1794](https://github.com/GridSwarm/wiremux/issues/1794). It sizes, in receiver CPU per delivered GiB, the allocations the native path makes for every received UDP packet before QUIC sees it: the binding's sender address and its private copy, and the fork's re-encoding of the control message for its packet policy. It also says which of them can go while every datagram is still admitted from its own control message. Nothing here implements a change. Every removal was sized with a throwaway probe that was never committed; the probe diffs live only in the evidence directory.

Sources are wiremux at `origin/main` [2599a002](https://github.com/GridSwarm/wiremux/tree/2599a00292c70c9871794ce62a1266741d71d42a), the quic-go-fast fork at the version the rig selects (`v0.62.1-fast.7`, commit [55ea687d](https://github.com/the-sarge/quic-go-fast/tree/55ea687d68c9c6f33785a1875374ec6a0d7570e8)), `golang.org/x/net` v0.59.0, Go 1.27.1, the rig `cmd/nativerig` from `codex/native-gap-rig` [7310bdad](https://github.com/GridSwarm/wiremux/tree/7310bdad9271f6da39aa0b183afc7f183286e230/cmd/nativerig), and measurements taken for this note on 2026-10-13. Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cells.** Three cells, all run as interleaved multi-build rotations with a discarded warm-up rotation:

- **Linux `netns`**: minimax (AMD Ryzen AI Max+ 395, Linux 7.0), two namespaces joined by a `veth` pair, sender pinned to CCD0 and receiver to CCD1, `veth` offloads at their defaults, native receive coalescing off as on `main`. Two campaigns (N1, N2), 6 runs per build and arm in each. This is the precise instrument: run-to-run spread is about ±0.01 CPU-s/GiB.
- **macOS `tb`**: mbp128 sends over Thunderbolt to m4mini (Mac mini M4 Pro, macOS 27), MTU 1500, so the receiver's CPU is its own. Two campaigns (T1, T2), 6 runs per build and arm in each. The receiver's *total* CPU varies by ±0.5–1 CPU-s/GiB run to run (its system time follows m4mini's other load), which is larger than every effect here; its *user* CPU varies by about ±0.1 and resolves them. Both are reported.
- **macOS same-host** (C1, 10 runs per build and arm): both peers on mbp128, bound to `bridge0`'s own address. Deltas only, as in [#1823](https://github.com/GridSwarm/wiremux/issues/1823).

## Answer

Every received packet makes **six** allocations at these sites, not the 4.5 the ticket estimated (**measured**, exact runtime counters): three in the binding (two for the sender address the socket read returns, one for the binding's private copy of it) and three in the fork's packet policy (re-encoding the parsed packet info as a control message). Together they are 210–235 bytes per packet. After [#1823](https://github.com/GridSwarm/wiremux/issues/1823)'s adopted slice B they are 6.0 of the Datagram receiver's 9.6–10.0 allocations per Datagram.

All six can go without weakening admission. Kernel ingress is still read from each datagram's own control message and the peer verdict path of [#1784](https://github.com/GridSwarm/wiremux/issues/1784) is untouched. Three of the six go with wiremux-only changes on macOS. Linux needs a wiremux-owned `recvmmsg` for two of them, because `x/net`'s batch read allocates the sender address itself. The fork's three need a small fork API that wiremux adopts.

The CPU they cost is small. Removing all six saves about **0.09 receiver CPU-s/GiB on the Linux stream** (5.7% of the receiver's 1.50, and +3.6% stream throughput, because that receiver is CPU-bound), **0.04 on Linux Datagrams** (1%), and about **0.17–0.19 user CPU-s/GiB on macOS** (about 1% of a receiver that spends 15.5–19 CPU-s/GiB, most of it in `recvmsg`, `sendmsg` and thread wake-ups).

| Site | Owner | Allocations (bytes) per received packet | Linux receiver CPU-s/GiB, `dgram` | Linux, `stream` | macOS `tb` receiver user CPU-s/GiB, `dgram` | macOS, `stream` | Removable? | Contract impact |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- | --- |
| 1. Sender address from the socket read: `ReadMsgUDP` builds a `*net.UDPAddr` (macOS, Windows); `x/net`'s `parseInetAddr` does the same per message (Linux) | wiremux (Linux: the `x/net` call wiremux makes) | 2 (about 55) | **−0.023** [−0.031, −0.006] | **−0.048** [−0.061, −0.042] | +0.005 [−0.050, +0.074], not resolved | −0.025 [−0.100, +0.018], not resolved | yes, wiremux only. macOS: `ReadMsgUDPAddrPort`, a one-line change. Linux: a wiremux-owned `recvmmsg` (probe `ax`) | none |
| 2. `admitReceived`'s private copy of that address | wiremux | 1 (64) | **−0.018** [−0.029, −0.007] | +0.002 [−0.008, +0.010], not resolved | **−0.122** [−0.157, −0.061] | **−0.046** [−0.105, −0.009] | yes, wiremux only: reuse one immutable address while consecutive admitted senders are byte-identical (probe `a`) | none; the reused value is a representation of facts admitted for this datagram, not a cached decision |
| 1 + 2, the binding as a whole | wiremux | 3 (about 120) | **−0.040** [−0.048, −0.035] | **−0.049** [−0.054, −0.046] | **−0.108** [−0.186, −0.058] | **−0.113** [−0.156, −0.056] | yes, as above | none |
| 3. Fork `allowsReceive` re-marshals the parsed packet info (`packetInfo.OOB` → `ipv4.ControlMessage.Marshal`) for a callback that wiremux ignores | fork | 3 (about 95 macOS, 110 Linux) | +0.004 [−0.004, +0.009] total, not resolved; user −0.029 [−0.043, −0.013] | **−0.037** [−0.040, −0.033] | **−0.081** [−0.157, −0.029] | **−0.061** [−0.119, −0.019] | yes, with a fork API that hands the callback the parsed facts (probe `b`), which wiremux adopts. A wiremux-only workaround exists (probe `bw`) but is not recommended | none for wiremux; additive in the fork |
| **All six** | both | 6 (210–235) | **−0.036** [−0.050, −0.028] | **−0.086** [−0.091, −0.083] | **−0.189** [−0.299, −0.163] | **−0.174** [−0.235, −0.119] | yes | none |
| All six, on top of slice B (Datagrams) | both | 6 | +0.012 [−0.004, +0.023] total, not resolved; user −0.066 [−0.092, −0.044] | — | **−0.248** [−0.307, −0.195] | — | yes | none |

How to read the table:

- Values are receiver CPU-s per delivered GiB, as the median of the probe's runs minus the median of the base's runs, pooled over both campaigns of the cell. The brackets are a 95% bootstrap interval (**measured**). A negative value is a saving. "Not resolved" means the interval includes zero.
- **Rows 1 and 2 were sized separately on each platform.** Linux row 1 is probe `ax` minus probe `a` and row 2 is probe `a` alone, from N1. macOS row 1 is probe `a1` (one private copy, no reuse) against base and row 2 is `a` minus `a1`, from T2. The "binding as a whole" and fork rows are factorial main effects: the average of a site's effect with and without the other site removed, which uses all four builds' runs. On macOS they are user CPU (next point). The "all six" row is the combined probes `axb` (Linux) and `ab` (macOS) against base. The slice B row is `r12axb` against `r12` (N1) and `r12ab` against `r12` (T1), the only campaigns that carried `r12`.
- **macOS columns are user CPU.** The probes change only user-space work, and the `tb` receiver's total CPU spreads too widely to resolve them. Total-CPU deltas for "all six" on `tb` are −0.25 (`dgram`) and −0.27 (`stream`) pooled, with intervals spanning zero. T2 alone, the quieter campaign, gives −0.37 [−0.55, −0.16] and −0.32 [−0.59, +0.11]. The same-host cell agrees on user CPU: −0.225 [−0.308, −0.165] and −0.141 [−0.177, −0.031] for all six. So on macOS the true total saving is at least the user-CPU figure, and plausibly up to twice it.
- **Per packet:** a `dgram` packet carries one 1,191-byte Datagram (901,560 packets per GiB), and a `stream` packet carries about 1,365 payload bytes (786,500 packets per GiB) (**measured** counters). So 0.1 CPU-s/GiB is 111 ns per packet for Datagrams and 127 ns for the stream (**derived**: 10⁸ / 901,560 and 10⁸ / 786,500). All six cost about 110 ns of the Linux stream receiver's 1.91 µs per packet and about 0.22 µs of the macOS receiver's 19.9–21.2 µs (**derived**).
- **Linux Datagrams save less than their user CPU suggests.** The Datagram receiver is not the bottleneck there: the sender runs at 5.2 CPU-s/GiB against the receiver's 3.7. User CPU the receiver frees partly turns into more idle wake-ups in the kernel. Total CPU then falls less than user CPU (`axb`: −0.036 total against −0.096 user), and not at all on top of slice B. The Linux stream receiver is CPU-bound, so its savings show in full and raise throughput: stream median 11.10 Gbit/s for base against 11.50 for `axb` (**measured**, non-overlapping ranges 10.69–11.24 and 11.37–11.65, pooled n=12 each).

## The per-packet receive path

On every platform the native path's `quic-go` transport reads through wiremux's `packetConn`, which calls the binding's `ReadUnicastBatch`. The fork then applies its packet policy before routing the packet ([`transport.go` L666](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/transport.go#L666), [`packet_policy.go` L22-L32](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/packet_policy.go#L22-L32)). All of it runs on the fork's one listen goroutine per transport.

| Step | Allocations per packet | Code |
| --- | --- | --- |
| 1. The fork's `oobConn.ReadPacket` asks `packetConn.ReadBatch` for a batch: 1 message on macOS (fork `batchSize` 1), 8 on Linux | none (pooled packet buffers) | [`sys_conn_oob.go` L203-L261](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/sys_conn_oob.go#L203-L261), [`sys_conn_helper_darwin.go` L22](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/sys_conn_helper_darwin.go#L22), [`packetconn.go` L93-L96](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/packetconn.go#L93-L96) |
| 2a. macOS (and Windows): `receive` calls `UDPConn.ReadMsgUDP`, which reads into a `netip.AddrPort` and then converts it with `UDPAddrFromAddrPort` | **2**: the `*net.UDPAddr` (48 bytes) and its 4-byte `IP` (`AsSlice`) | [`unicast.go` L921-L948](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L921-L948) (the call at L935), Go 1.27.1 [`udpsock.go` L186-L193](https://github.com/golang/go/blob/go1.27.1/src/net/udpsock.go#L186-L193), [L102-L108](https://github.com/golang/go/blob/go1.27.1/src/net/udpsock.go#L102-L108) |
| 2b. Linux: `receive` calls `x/net` `ipv4.PacketConn.ReadBatch` → `recvmmsg`; `mmsghdrs.unpack` calls `parseInetAddr` for every message | **2 per message**: `make(net.IP, 4)` and `&net.UDPAddr{…}` (the header arrays are pooled) | [`unicast.go` L376-L378](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L376-L378), [L932](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L932), x/net [`mmsghdr_unix.go` L18-L32](https://github.com/golang/net/blob/v0.59.0/internal/socket/mmsghdr_unix.go#L18-L32), [`sys_posix.go` L66-L103](https://github.com/golang/net/blob/v0.59.0/internal/socket/sys_posix.go#L66-L103), [`rawconn_mmsg.go` L13-L32](https://github.com/golang/net/blob/v0.59.0/internal/socket/rawconn_mmsg.go#L13-L32) |
| 3. `admitReceived`: kernel ingress from this datagram's packet-info record (`receiveIngress`), scope, peer admission (`admit`, the #1784 verdict cache), then a private copy of the sender address because the caller retains it | **1**: `new(receivedAddr)` (64 bytes) | [`unicast.go` L950-L988](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L950-L988), [`unicast_unix.go` L93-L145](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast_unix.go#L93-L145) |
| 4. `ReadUnicastBatch` copies the admitted control bytes back to the caller | none | [`unicast.go` L871-L917](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L871-L917) |
| 5. The fork's `decodeReadPacket` parses those bytes: ECN from the TOS record, and the destination address and interface index from `IP_PKTINFO` into `packetInfo` | none | [`sys_conn_oob.go` L284-L359](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/sys_conn_oob.go#L284-L359) |
| 6. The fork's `allowsReceive` turns `packetInfo` back into a control message (`packetInfo.OOB` → `ipv4.ControlMessage.Marshal`) and hands it to the network-admission receive callback | **3**: the `ControlMessage` (64 bytes, escapes through `Marshal`'s function-pointer call), its 4-byte `Src` array, and the encoded message (24 bytes on macOS, 32 on Linux) | [`packet_policy.go` L57-L73](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/packet_policy.go#L57-L73), [`sys_conn_oob.go` L411-L440](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/sys_conn_oob.go#L411-L440), x/net [`control.go` L58-L70](https://github.com/golang/net/blob/v0.59.0/ipv4/control.go#L58-L70) |
| 7. The callback is wiremux's `admitBound`, which returns `true` without reading any argument | none | [`endpoint.go` L206](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/endpoint.go#L206), [L216](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/endpoint.go#L216) |

So step 6 builds a control message for every packet and the callback throws it away. wiremux's real admission is step 3, inside the binding, before the fork sees the packet. The fork's own copy of the facts (step 5) is also what its server uses for reply metadata, so the parse must stay; only the re-encoding is waste.

### Allocation census

Whole-process counters over each run, divided by the packets the binding delivered to QUIC (`udp_read`, an evidence-only counter in `packetConn`; medians, **measured**):

| Receiver | Linux `stream` | Linux `dgram` | macOS `tb` `stream` | macOS `tb` `dgram` |
| --- | ---: | ---: | ---: | ---: |
| base | 7.20 (258 B) | 14.03 (3,206 B) | 8.01 (261 B) | 14.97 (3,161 B) |
| binding sites gone (`ax` Linux, `a` macOS) | 4.19 | 11.07 | 4.99 | 11.96 |
| fork site gone (`b`) | 4.19 | 11.06 | 5.02 | 11.97 |
| both gone (`axb` Linux, `ab` macOS) | 1.19 (24 B) | 8.12 | 1.99 (50 B) | 8.94 |
| slice B (`r12`) | — | 9.12 (1,637 B) | — | 9.60 (1,607 B) |
| slice B + both gone (`r12axb`, `r12ab`) | — | 3.22 | — | 3.58 |
| Linux `a` (copy reused, `x/net` address kept) | 6.19 | 13.06 | | |
| macOS `a1` (`ReadMsgUDPAddrPort`, one fresh copy, no reuse) | | | 6.03 | 12.99 |

Each step removes a whole number of allocations per packet: 3.00 for the binding, 3.00 for the fork, 1.01 for the copy (Linux `a` against base), 2.00 for the `x/net` address (Linux `a` against `ax`) and 1.98 for the `ReadMsgUDP` address (macOS `a1` against base). GC cycles fell with the bytes: the Linux stream receiver ran 1,448 GCs per 10 s run at base and 156 at `axb`. What is left on the stream receiver after `axb` is about one allocation per packet in the fork's stream-frame handling, plus send-side allocations for its acknowledgments ([below](#probes-and-ab)).

## Where the CPU goes

### macOS: Instruments, same host

On macOS, attribution uses Instruments' Time Profiler, not Go's `-cpuprofile` (see [#1823's method note](https://github.com/GridSwarm/wiremux/issues/1823)). m4mini has only the `xctrace` shim, with no Xcode, so it cannot record. The recordings below are therefore same-host on mbp128, one 10 s run per build (`scripts/xprof.sh`, `scripts/xtsum.py`). The cells are receiver CPU-s/GiB (**measured**, one recording each, so about ±15% sampling noise on the small rows):

| Receiver bucket | base `stream` | `ab` `stream` | base `dgram` | `ab` `dgram` |
| --- | ---: | ---: | ---: | ---: |
| total on-CPU | 17.35 | 16.77 | 20.94 | 19.76 |
| listen goroutine (`Transport.listen`, user space) | 0.81 | 0.67 | 0.93 | 0.76 |
| binding `ReadUnicastBatch` | 0.44 | 0.34 | 0.49 | 0.38 |
| of which building the sender address (`ReadMsgUDP` minus `ReadMsgUDPAddrPort`) | 0.04 | 0 | 0.06 | 0 |
| of which `admitReceived`'s allocation (`mallocgc` under it) | 0.02 | 0 | 0.02 | 0 |
| fork `allowsReceive` (all of it the re-marshal) | 0.05 | 0 | 0.04 | 0 |
| `mallocgc` under the listen goroutine | 0.08 | 0 | 0.09 | 0 |
| GC workers and assists | 0.05 | 0.01 | 0.51 | 0.36 |
| leaf `recvmsg` | 3.74 | 3.68 | 4.33 | 4.28 |

The sites cost about 0.15 CPU-s/GiB directly on the listen goroutine (0.81 → 0.67 and 0.93 → 0.76), plus their share of GC. That matches the A/B's 0.17–0.19 user CPU-s/GiB. They are about 1% of a receiver whose time goes to `recvmsg` (3.7–4.3), `sendmsg` for acknowledgments, thread park and wake (about 1.7) and the scheduler (about 1.5).

### Linux: `pprof`

Go's profiler is accurate on Linux. One 10 s profiled run per build on the `netns` cell (`lprof/`) gives these receiver CPU-s/GiB (**measured**, 100 Hz sampling):

| Receiver bucket | base `stream` | `axb` `stream` | base `dgram` | `axb` `dgram` |
| --- | ---: | ---: | ---: | ---: |
| listen goroutine (`Transport.listen`, cumulative) | 0.733 | 0.646 | 0.912 | 0.831 |
| `x/net` `parseInetAddr` (inside `unpack`) | 0.014 | 0 | 0.059 | 0 |
| `admitReceived` (with the #1784 verdict lookup) | 0.052 | 0.037 | 0.061 | 0.058 |
| fork `allowsReceive` | 0.032 | 0 | 0.037 | 0 |
| GC workers | 0.029 | (below 0.01) | 0.432 | 0.417 |

The listen goroutine sheds 0.08–0.09 CPU-s/GiB, which matches the A/B. On the Linux stream receiver the whole receive goroutine, including its `recvmmsg` calls, is 0.73 of 1.50 CPU-s/GiB. A 0.09 saving there is real, and it is what moves throughput.

### Isolated costs

Exact copies of the three sites, benchmarked on mbp128 outside any connection (`bench/sites/`, medians of 5, wall time per operation, **measured**):

| Variant | ns/op | B/op | allocs/op |
| --- | ---: | ---: | ---: |
| binding base: `UDPAddrFromAddrPort` + private copy | 23.6 | 116 | 3 |
| binding `a1`: one private copy from an `AddrPort` | 10.1 | 64 | 1 |
| binding `a`: reuse the previous immutable address | 1.9 | 0 | 0 |
| fork base: `packetInfo.OOB` + callback | 25.9 | 92 | 3 |
| fork `b`: facts callback | 1.8 | 0 | 0 |

About 46 ns per packet directly, or 0.04 CPU-s/GiB at 901,560 packets per GiB (**derived**: (23.6 − 1.9) + (25.9 − 1.8) = 45.8 ns). The rest of the measured saving is GC work that the garbage drives, which a small benchmark heap does not reproduce.

## Probes and A/B

Each probe is a diff against 2599a002 plus the rig, in `probes/`. Its built binaries and exact applied diff are in `bin/<name>/`. Probes that touch the fork build against a scratch copy of the module (`fork-probe/quic-go-fast`, patched by `probes/fork-admission-probe.diff`, which adds two setters that do nothing unless called).

| Probe | What it changes | Owner |
| --- | --- | --- |
| `a` | The binding reads with `ReadMsgUDPAddrPort` (macOS) or converts the batch read's address (Linux) into a `netip.AddrPort`. Admission runs exactly as before. The admitted sender, meaning its delivered address bytes, port and validated zone, is the key of the retained `*net.UDPAddr`. While consecutive admitted datagrams have the same key, the same immutable address is returned, and a new one is allocated when it changes. The cache lives in the binding's borrowed receive scratch, so only one reader uses it at a time. | wiremux |
| `a1` | As `a`, but a fresh private address for every datagram (no reuse) | wiremux |
| `ax` | `a` plus, on Linux, a wiremux-owned `recvmmsg` through `syscall.RawConn.Read` in place of `x/net`'s `ReadBatch`, parsing each sender into a `netip.AddrPort` (about 80 lines with `unsafe`) | wiremux |
| `b` | The fork gains `ConfigureReceiveAdmissionFactsV1`: `allowsReceive` passes the already-parsed `(remote, local, ifIndex)` to a facts callback instead of re-marshaling. wiremux registers `admitBoundFacts`. | fork API, wiremux adopts |
| `bw` | wiremux only: `ReadUnicastBatch` hands QUIC the control bytes without the packet-info record. The fork's `packetInfo` stays empty and `OOB()` returns nil. | wiremux |
| `s` | Send side (in `abs` and `axbs`): `WriteUnicastMsg` and `WriteUnicastBatch` stop building a normalized `*net.UDPAddr` per call on IPv4, and the fork's `checkSend` lends the ancillary data to the send callback instead of copying it | wiremux + fork API |
| `r12` | [#1823](https://github.com/GridSwarm/wiremux/issues/1823)'s adopted slice B (`r1` + `r2`), the Datagram baseline | wiremux |

**Campaigns** (`meta.txt` and `summary.txt` in each directory; `effects.txt` holds every interval):

| Campaign | Cell | Builds × arms | Runs per build and arm | Gate and conditions |
| --- | --- | --- | ---: | --- |
| N1 | Linux `netns` | base, `a`, `ax`, `b`, `axb`, `r12`†, `r12axb`† × `dgram`, `stream` | 6 | load recorded per run, highest 3.3; no socket-buffer drops |
| N2 | Linux `netns` | base, `ax`, `b`, `axb`, `bw`, `axbs` × both | 6 | highest load 3.5; no drops |
| T1 | macOS `tb` | base, `a`, `b`, `ab`, `r12`†, `r12ab`† × both | 6 | both peers' load1 ≤ 8 before every run (1 wait); highest 7.6 |
| T2 | macOS `tb` | base, `a1`, `a`, `b`, `bw`, `ab`, `abs` × both | 6 | 14 waits; highest 7.99 |
| C1 | macOS same-host | base, `a`, `b`, `ab`, `r12`†, `r12ab`† × both | 10 | load1 ≤ 8 (24 waits); highest 7.91 |

† `dgram` only. Every campaign rotated the build order every repetition after a warm-up rotation, so drift lands on every build alike, and no run was flagged (rate outside 0.8–1.2× of its build's median, load above 8, failure). Losses outside warm-ups were at most 0.07% on `tb` and Linux, and 0.21% in one C1 run (`r12`). The `tb` receiver had small socket-buffer drops in 57 of 168 runs, warm-ups included (at most 793 packets), spread across builds. An earlier same-host attempt (`C1-aborted/`) gave up after its warm-up rotation, when another agent's tests drove load1 to 31, and is not used.

**Secondary results** (median deltas against base in the same campaign, [95% interval], **measured**):

| Probe | Cell | `dgram` receiver | `stream` receiver | Notes |
| --- | --- | --- | --- | --- |
| `bw` | Linux N2 | −0.030 [−0.044, −0.015] | −0.034 [−0.043, −0.018] | about the fork probe `b`'s saving, without a fork change |
| `bw` | macOS T2, user CPU | −0.118 [−0.184, −0.046] | −0.074 [−0.150, −0.034] | slightly more than `b`: the server's acknowledgments also stop carrying packet info |
| `a1` | macOS T2, user CPU | +0.005 [−0.050, +0.074] | −0.025 [−0.100, +0.018] | dropping `ReadMsgUDP`'s two small allocations alone is not resolvable; the 64-byte copy is what `a`'s reuse removes |
| `s` (`axbs` − `axb`) | Linux N2 | −0.071 [−0.087, −0.061] | −0.004 [−0.007, +0.001] | the Datagram *sender* saves 0.074 and its throughput rises 2%: on Linux it is the bottleneck and makes 2 fewer allocations per packet |
| `s` (`abs` − `ab`) | macOS T2, user CPU | −0.019 [−0.087, +0.010] | +0.007 [−0.053, +0.059] | not resolved |
| slice B (`r12`) | all | Linux −0.422, macOS `tb` user −1.001, same-host −0.889 | — | reproduces #1823's 1.0 CPU-s/GiB on macOS |

## Contract analysis

The guarantee every candidate is judged against is per-datagram kernel-ingress admission. [`docs/COMPATIBILITY.md` L103](../COMPATIBILITY.md) says that "every received datagram, including each batched datagram, is admitted against current identity, source, kernel ingress and an interface-restricted route lookup". The #1784 exception at [L105](../COMPATIBILITY.md) lets the peer's identity, source and route verdict be reused until the next observed network change, and says "Kernel ingress is still checked per datagram". In code, `admitReceived` reads the ingress index from that datagram's own packet-info record, rejects truncated, missing or conflicting records, applies scope, and calls `admit` for the peer (`unicast.go` L950-L976).

- **`a` (address reuse): preserves as-is.** `receiveIngress` and `admit` run for every datagram, in the same order, before any address work. The reused object is not a decision. It is the `*net.UDPAddr` built from facts this datagram has just been admitted with, handed out only when those facts (delivered address bytes, port and validated zone) are byte-identical to the previous admitted datagram's. A rejected datagram never reaches it, and a change of peer, port or zone allocates a new address. What the change does rely on is that no one mutates a received address, because the fork retains it: as the path address, in the server's send connection, and in `rebindPath`. The fork's external packet-I/O path never mutates or pointer-compares it. Its only pointer comparison is in the managed endpoint ([`managed_packet_endpoint.go` L308](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/managed_packet_endpoint.go#L308)), which wiremux does not use. Equality uses `addrsEqual`, a value comparison ([`path_manager.go` L196-L206](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/path_manager.go#L196-L206)). The fork already shares one `*net.UDPAddr` across all segments of a coalesced read ([`coalesced_delivery.go` L40-L44](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/coalesced_delivery.go#L40-L44)). The one public escape is `Transport.ReadNonQUICPacket`, which returns the packet's address to its caller ([`transport.go` L902](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/transport.go#L902)); wiremux never calls it. The real change updates [`TestUnicastMessagePathAllocations`](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast_alloc_test.go#L32-L74), which pins `ReadUnicastBatch` at exactly one allocation, to zero on a steady peer. It should also add a test that a reused address is never handed out for a datagram whose ingress or peer admission failed.
- **`a1` and the macOS half of row 1: preserves as-is.** `ReadMsgUDPAddrPort` returns the same facts without the conversion, and admission is unchanged.
- **`ax` (wiremux-owned `recvmmsg` on Linux): preserves as-is.** Every message still carries its own control buffer, and each is admitted separately as before. The cost is ownership: about 80 lines of `unsafe` syscall code per platform family in place of a maintained `x/net` call, and wiremux taking over the read's error and deadline mapping. The probe returned errors through `RawConn.Read`, which keeps deadline semantics. An upstream `x/net` option to read senders as `netip.AddrPort` would avoid owning it, but on `x/net`'s schedule.
- **`b` (fork facts callback): preserves as-is.** The fork still parses each datagram's own control message (step 5). Its policy check now gets the parsed values instead of a re-encoded copy. wiremux's admission is the binding's and does not move. `ConfigureNetworkAdmissionV1`'s documented contract ("Ancillary data is a private copy in the native platform format", [`packet_policy.go` L152-L179](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/packet_policy.go#L152-L179)) stays as it is for other users. The facts form is an additional, opt-in configuration.
- **`bw` (wiremux withholds packet info): changes an internal contract; not recommended.** It keeps per-datagram admission, because the binding still reads the record before withholding it. But `ReadUnicastBatch` today promises its caller the admitted kernel record, and [`TestUnicastBatchProvenance`](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast_test.go#L283-L317) fails with the probe. The fork would also lose the destination and interface index it uses for server replies, through `newSendConn` ([`send_conn.go` L52-L82](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/send_conn.go#L52-L82), [`server.go` L1002](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/server.go#L1002)) and stateless responses ([`candidate_authority.go` L390](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/candidate_authority.go#L390)). Today that loss is harmless: every binding socket is bound to one unicast address and pinned to its interface (`IP_BOUND_IF` on macOS, [`native_darwin.go` L122](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/native_darwin.go#L122)). But it hides facts from the fork to work around the fork's own cost, and `b` removes the same cost cleanly.
- **`s` (send side): preserves as-is** for IPv4, where `PrepareSend` already returns the caller's destination unchanged ([`packet.go` L139-L155](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/packet.go#L139-L155)). Every send is still admitted and its metadata checked. The fork's borrowed send callback is the same opt-in kind of API change as `b`.

No candidate needs a `docs/COMPATIBILITY.md` change.

## Fork changes and API sketch

Not implemented in the fork. The throwaway version is `probes/fork-admission-probe.diff`, and it belongs in the-sarge/quic-go-fast's tracker.

```go
// ConfigureReceiveAdmissionFactsV1 replaces the configured network
// admission's receive callback with one that takes the facts the transport
// already parsed from each datagram's own control message: the remote, the
// local endpoint (the extracted destination when present, otherwise the
// socket binding) and the kernel ingress interface index (zero when absent).
// Receive admission then re-encodes and allocates nothing. Call after
// ConfigureNetworkAdmissionV1 and before initialization.
func (t *Transport) ConfigureReceiveAdmissionFactsV1(receive func(remote, local netip.AddrPort, ifIndex uint32) bool) error

// ConfigureSendAdmissionBorrowedV1 lends the send callback each submission's
// ancillary data, valid only during the call, instead of a private copy.
func (t *Transport) ConfigureSendAdmissionBorrowedV1() error
```

An equally good alternative for wiremux is a V2 network-admission configuration that accepts a nil receive callback to mean "the packet connection admits every datagram before returning it", which skips the check entirely. wiremux's callback is the constant `true` because the binding is the admission owner. The facts form is more general; either removes the three allocations.

## Interaction with Linux receive coalescing

[#1824](https://github.com/GridSwarm/wiremux/issues/1824) would turn on coalesced receive for the native path. With it, the binding's costs become per coalesced read: one sender address and one admission cover all the read's segments. The fork's re-marshal does not. Each segment is returned through `packetPolicyConn.ReadPacket` as its own packet, carrying a copy of the read's `packetInfo`, and `allowsReceive` runs for each one. So the fork site stays per datagram under GRO, while the binding sites shrink by the coalescing factor. That makes the fork API the more durable of the two changes on Linux. This is from the source (**source**), not measured here.

## Corrections to the ticket's premises

- **Six allocations per packet, not 4.5.** The ticket's 2.3 (binding) and 2.2 (fork) came from #1823's allocation profile. That profile under-samples 4-byte tiny allocations: the `net.IP` that `ReadMsgUDP` (or `x/net`) makes, and the `[4]byte` array that escapes in `packetInfo.OOB`. The runtime's exact counters give 3.00 and 3.00.
- **About 60% of the Datagram receiver's remaining allocations, not about half.** After slice B the receiver makes 9.6–10.0 allocations per Datagram, and these sites are 6.0 of them.
- **The fork's re-marshal is not admission at all for wiremux.** Its output goes to `admitBound`, which ignores its arguments. Removing it changes nothing about who admits a datagram.
- **On Linux the binding does not call `ReadMsgUDP`.** The binding batch-reads through `x/net`, whose `parseInetAddr` allocates the address per message, so `ReadMsgUDPAddrPort` alone does not help Linux. Two of the binding's three allocations need a wiremux-owned `recvmmsg` (or an `x/net` change) there.
- **The cost is CPU, not throughput, except on the Linux stream.** On macOS the sites are about 1% of the receiver. Only the CPU-bound Linux stream receiver turns the saving into throughput (+3.6%).

## Open questions and suggested tickets

1. **(wiremux) Read the sender as `netip.AddrPort` and reuse an immutable admitted address.** This is probe `a`: `ReadMsgUDPAddrPort` plus reuse while the admitted sender is unchanged, applying to macOS and Windows and the copy on Linux. It needs no contract change. Expect about 0.11 user CPU-s/GiB on a macOS receiver and 0.02 CPU-s/GiB on Linux Datagrams. Update `TestUnicastMessagePathAllocations`, and add a test that a reused address is never returned for a datagram that failed admission. Windows has the same `ReadMsgUDP` path and is unmeasured.
2. **(fork) A receive-admission facts API** (or a nil "already admitted" receive callback), adopted by wiremux. Expect 0.036 CPU-s/GiB on the Linux stream receiver and about 0.06–0.08 user CPU-s/GiB on macOS. It is the change that stays per-datagram under GRO (#1824), so it is worth packaging with that work.
3. **(wiremux, Linux, owner decision) Own `recvmmsg` or wait for `x/net`.** This removes `x/net`'s two allocations per message: 0.048 CPU-s/GiB on the Linux stream receiver and 0.023 on Datagrams, at the cost of owning `unsafe` syscall code. It might be better asked upstream as an `x/net` `AddrPort` read mode. With GRO it amortizes over the segments of a read, so its value falls if #1824 lands.
4. **(wiremux + fork, new) Send-side per-packet allocations.** `WriteUnicastMsg` and `WriteUnicastBatch` build a normalized `*net.UDPAddr` per call, and the fork's `checkSend` copies the ancillary data for every submission. On Linux the Datagram sender saves 0.074 CPU-s/GiB without them and gains 2% throughput. This is outside this ticket's receive question.
5. **(rig) Keep per-packet counters in the rig.** This note's `udp_read` and `udp_written` counters (in `rig-evidence.diff`) are what made per-packet normalization exact. They could join the rig on `codex/native-gap-rig`.
6. **(rig, owner) `tb` attribution needs Xcode on m4mini.** Without it, receiver-side Instruments recordings are same-host only.

## Evidence

Everything is outside the repository, under `/Volumes/worktrees/wiremux/native-gap-evidence/1827-recv-alloc/`:

- `README.txt` describes the directory.
- `N1/`, `N2/` (Linux `netns`), `T1/`, `T2/` (macOS `tb`) and `C1/` (macOS same-host), each with `meta.txt`, `summary.txt`, `waits.log` and one directory per run (`send.json` and `recv.json` with allocation and datagram counters, plus UDP and interface counters, loads and, on Linux, `ethtool -k` per run). `effects.txt` is `scripts/effects.py` over all of them; `C1-aborted/` is the abandoned first attempt.
- `bin/<build>/`: every binary measured (darwin/arm64 and, where run on Linux, linux/amd64), with its exact `applied.diff`, `recipe` and, for fork builds, `fork.diff`.
- `probes/`: the probe diffs, the fork patch and `probe.mod`. `fork-probe/quic-go-fast/` is the scratch copy of the fork, a local git repository whose first commit is the pristine module.
- `rig-evidence.diff`: the evidence-only rig extension (allocation counters, `-memprofile`, and the `packetConn` datagram counters).
- `xprof/`: same-host `xctrace` recordings, `xtsum.txt` per case and `xtcompare.txt`. `lprof/`: the Linux CPU profiles with their binaries. `mprof/`: base allocation profiles. `bench/sites/`: the isolated benchmarks.
- `scripts/`: `build.sh`, `build-linux.sh`, `campaign.sh` (same-host), `tcampaign.sh` (`tb`), `ncampaign.sh` (`netns`), `pair.sh`, `an.py`, `effects.py`, `xprof.sh`, `xsum.sh`, `xtsum.py`. The `tb` and `netns` drivers copy `rig.sh`'s per-run procedure and differ only in rotating several prebuilt builds through every repetition.
- `smoke/`: functionality checks, not evidence.
