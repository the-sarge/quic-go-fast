# Issue #1833: how much native Datagram throughput Go's garbage collector takes

Research for [#1833](https://github.com/GridSwarm/wiremux/issues/1833) on the wayfinder map [#1794](https://github.com/GridSwarm/wiremux/issues/1794). The [#1829 note](https://github.com/GridSwarm/wiremux/blob/77f407959ba943e6995756f0b93b16946d451355/docs/research/issue-1829-native-receive-coalescing-throughput.md#3-the-stock-datagram-arm-gc-pacing-on-the-sender) found the rig's Datagram senders running at Go's 4 MiB minimum heap goal, where `GOGC=400` alone bought the stock sender 10.6% and the equal-size GSO probe sender 52%. This note measures how much Datagram throughput Go's garbage collector (GC) takes on both peers in the minimax `netns` cell and on the Thunderbolt pair, sweeps the heap goal four ways (`GOGC`, a live heap that stands in for a consumer's, a pointer-bearing live heap, and `GOMEMLIMIT`), attributes the bytes allocated per Datagram to their sites, reads what GridCast runs with, and says which GC setting rig comparisons should pin. Nothing here is implemented. Every build is a throwaway probe, and none is merged or pushed.

Sources are wiremux at `origin/main` [2599a002](https://github.com/GridSwarm/wiremux/tree/2599a00292c70c9871794ce62a1266741d71d42a), the quic-go-fast fork at [`v0.62.1-fast.7`](https://github.com/the-sarge/quic-go-fast/tree/v0.62.1-fast.7), Go [go1.27.1](https://github.com/golang/go/tree/go1.27.1), GridCast at [f812408f](https://github.com/GridCastIO/gridcast/tree/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b), and measurements in the `netns` cell, on the Thunderbolt pair (`tb`) and on mbp128 on 2026-10-13 and 2026-10-14 (UTC). Every derived number is marked **derived**. Statements about cause are marked as inferred where no measurement isolates them.

## Answer

- **Both peers of the rig run at Go's 4 MiB heap floor, because each Datagram allocates about 4.5 times its own size.** A 1,191-byte Datagram costs about 5,380 bytes of allocation on the sender (four full copies) and about 3,200 on the receiver (two copies and a per-call context), against a live heap of about 1 MiB. So the stock sender collects about 870 times a second in the `netns` cell and the GSO probe sender about 1,540 times; on macOS, where the rate is a third, about 275.
- **In the `netns` cell, GC takes about 14% of the stock sender's Datagram throughput, and all of it is the sender's.** It delivers 3,298 Mbit/s at Go's default and about 3,800–3,860 once the sender's runway (heap goal minus live heap) is about 50 MiB or more, however that is reached (`GOGC`, a live heap, or `GOMEMLIMIT`). The curve is within 2% of flat from a 30 MiB runway on. Raising only the receiver's goal changes nothing (−0.3%).
- **The GSO probe sender is different: the best setting is a middle one, and a consumer-sized heap gives back almost all of the gain.** It delivers 5,565 Mbit/s at the default, 8,451 (+52%) when the sender's runway is about 15 MiB, 6,437–6,665 at a 31–33 MiB runway, and 5,370–5,670 again from about 51 MiB. What sets its throughput is the runway, not the heap goal or the live heap: a 64 MiB live heap held to a 16 MiB runway delivers what `GOGC=400` delivers (section 3). So measured against its best runway GC takes 34% at the default, but measured against a consumer-like heap it takes about nothing, because a long runway costs this CPU-bound sender as much as the collections did: at a 127 MiB runway it executes the same instructions per byte as at 15 MiB but takes 33% more cycles, with five times the demand fills from DRAM (section 3).
- **On macOS, GC takes CPU but no measurable throughput.** Every off-floor arm is within −5% to +2% of the default (pooled medians of up to 12 runs, against run-to-run spreads of ±10–15%). Off the floor, the sender saves about 0.8 and the receiver about 0.6 user CPU-s per GiB (about −15% and −9% of user CPU). The macOS rate is set by per-packet system calls ([#1823](https://github.com/GridSwarm/wiremux/issues/1823#issuecomment-6066656578)), not by GC.
- **GridCast sets nothing: Go's defaults (`GOGC=100`, no memory limit), and its own live heap already puts it far off the floor.** Its sender holds about 59–75 MiB (measured median 67 MiB in one same-host transfer), its receiver an estimated 60–140 MiB at Datagram load, both 90–95% pointer-free. That gives each process a runway of tens of MiB, which the rig reproduces with a 64 MiB pointer-free live heap (`-ballast 64`): there, GC collections cost the stock sender about 0.6% (**derived**). What a consumer still pays is the long runway (section 3) and mark work on the pointer-bearing part of its heap, which in the rig costs 0.4–0.6 CPUs and raises Datagram loss at the receiver's 128-entry queue to 0.7–2% (section 4).
- **Pin rig Datagram comparisons at `-ballast 64` and report the default alongside.** `-ballast 64` is a consumer-like heap on both peers. The default row shows how much of a lever's gain is GC, which a consumer does not see. `GOGC=400` should not be the pin: it is a rig-only sweet spot that puts the GSO sender 53% above what it reaches with a consumer-sized heap (section 8).
- **By bytes, four copies are 96–97% of the sender's allocation and two copies plus a context are 88–91% of the receiver's.** The adopted [native send slice (A)](https://github.com/GridSwarm/wiremux/issues/1826#issuecomment-6148612825) removes 48% of the sender's bytes, which at the floor is worth about +7% of stock throughput in GC alone (**derived**), and the held fork APIs remove most of the rest. The adopted receive slice (B) removes 47% of the receiver's bytes, which matters little for throughput where the receiver's GC does not bind. [#1832](https://github.com/GridSwarm/wiremux/issues/1832#issuecomment-6152076446)'s two slices remove 1–2% of the sender's bytes and 5–6% of the receiver's: counts, not bytes, so they do not move the GC.

## 1. Where the Datagram path sits: Go's 4 MiB floor, on both peers

Go sets the next heap goal to the marked live heap plus `GOGC`% of the live heap, stacks and globals, and never below a minimum of 4 MiB × `GOGC`/100 ([`mgcpacer.go` L58-L60](https://github.com/golang/go/blob/go1.27.1/src/runtime/mgcpacer.go#L58-L60), [L1293-L1301](https://github.com/golang/go/blob/go1.27.1/src/runtime/mgcpacer.go#L1293-L1301), [L1343](https://github.com/golang/go/blob/go1.27.1/src/runtime/mgcpacer.go#L1343)). A process whose live heap is under about 2 MiB therefore runs at the 4 MiB floor, and the bytes it can allocate between collections (its runway) are about 4 MiB minus its live heap. The rig's Datagram peers are such processes. Pooled medians of the default arm (`netns`: N1 N2 and NB1 NB2, six runs each; `tb`: T1–T4, 12 runs), measured over each transfer window with `runtime/metrics`:

| Cell, sender | Peer | Mbit/s | Live heap MiB | Heap goal MiB | Allocated MB/s | Bytes per Datagram | GC cycles/s | GC pause ms/s | GC CPU (CPUs) | `GOMAXPROCS` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `netns`, stock | sender | 3,298 | 1.15 | 4.01 | 1,863 | 5,381 | 868 | 48.6 | 0.29 | 4 |
| `netns`, stock | receiver | | 1.29 | 4.00 | 1,108 | 3,209 | 589 | 39.2 | 0.23 | 4 |
| `netns`, GSO probe | sender | 5,565 | 1.31 | 4.01 | 3,206 | 5,387 | 1,542 | 83.0 | 0.51 | 4 |
| `netns`, GSO probe | receiver | | 1.57 | 4.06 | 1,877 | 3,220 | 986 | 60.1 | 0.38 | 4 |
| `tb`, stock | sender | 1,219 | 0.94 | 4.00 | 681 | 5,322 | 275 | 15.1 | 0.24 | 16 |
| `tb`, stock | receiver | | 0.93 | 4.00 | 404 | 3,164 | 185 | 12.2 | 0.18 | 12 |
| `netns`, stream | sender | 10,797 | 1.66 | 4.00 | 57 | — | 33 | 2.0 | 0.01 | 4 |
| `netns`, stream | receiver | | 1.79 | 4.06 | 255 | — | 143 | 13.8 | 0.07 | 4 |

- **Bytes per Datagram do not depend on the GC setting or the cell.** Across every arm and both cells the sender allocates 5,240–5,400 bytes and the receiver 3,090–3,220 bytes per Datagram (the full tables are in the evidence). So the number of collections is the allocation rate divided by the runway, and only the runway is a GC setting.
- **The receiver is at the floor too.** #1829 characterized only the sender. The receiver allocates 60% as much per Datagram and collects 590 (stock) to 990 (GSO probe) times a second.
- **The stream is not at the GC's mercy on the sender** (33 collections a second), but its receiver, allocating 255 MB/s, collects 143 times a second (section 2).
- **A collection's pauses alone are 5% of the stock sender's time and 8% of the GSO sender's** (48.6 and 83.0 ms of stop-the-world per second, **derived** as shares). The rest of a collection's cost is its mark phase: with `GOMAXPROCS=4` in the `netns` cell, a dedicated mark worker takes one of the four processors for the mark phase ([`mgcpacer.go` L39](https://github.com/golang/go/blob/go1.27.1/src/runtime/mgcpacer.go#L39)), and write barriers and assists slow the goroutines that remain.

## 2. Throughput against the heap goal in the `netns` cell

Each arm changes the GC on both peers unless it says otherwise. "Ballast N" keeps a live, pointer-free allocation of N MiB at the default `GOGC=100`, which is how a consumer's own buffers look to the pacer. "Pointer ballast N" keeps N MiB of live 64-byte objects that each hold pointers (section 4). "`GOMEMLIMIT` 64" is `GOGC=off` with a 64 MiB memory limit. Runway is the sender's mean heap goal minus its mean live heap. CPU is CPU-seconds per delivered GiB, whole process. Pooled medians of two interleaved campaigns, six runs per row.

### Stock sender (N1 N2)

| Arm | Sender goal MiB | Sender runway MiB | Mbit/s | Spread | Change | Sender GC cycles/s | Sender GC pause ms/s | Sender CPU | Receiver CPU |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| default (`GOGC=100`) | 4.0 | 2.9 | 3,298 | 3,128..3,321 | — | 868 | 48.6 | 5.28 | 3.82 |
| `GOGC=200` | 8.0 | 6.8 | 3,555 | 3,541..3,575 | +7.8% | 338 | 19.2 | 4.75 | 3.39 |
| `GOGC=400` | 16.0 | 14.8 | 3,634 | 3,618..3,669 | +10.2% | 151 | 8.9 | 4.61 | 3.28 |
| `GOGC=800` | 32.0 | 30.8 | 3,763 | 3,697..3,793 | +14.1% | 74 | 4.7 | 4.69 | 3.22 |
| `GOGC=1600` | 64.1 | 62.8 | 3,803 | 3,777..3,834 | +15.3% | 36 | 2.7 | 4.83 | 3.23 |
| `GOGC=3200` | 128.6 | 127.2 | 3,833 | 3,808..3,840 | +16.2% | 18 | 1.4 | 4.89 | 3.25 |
| ballast 2 MiB | 6.6 | 3.4 | 3,360 | 3,330..3,367 | +1.9% | 724 | 41.0 | 5.15 | 3.65 |
| ballast 8 MiB | 18.6 | 9.4 | 3,598 | 3,344..3,618 | +9.1% | 241 | 13.8 | 4.67 | 3.32 |
| ballast 16 MiB | 34.6 | 17.4 | 3,658 | 3,499..3,701 | +10.9% | 128 | 7.6 | 4.60 | 3.27 |
| ballast 64 MiB | 130.9 | 65.5 | 3,822 | 3,560..3,834 | +15.9% | 35 | 2.6 | 4.83 | 3.23 |
| `GOMEMLIMIT` 64 MiB | 52.1 | 50.9 | 3,821 | 3,784..3,846 | +15.9% | 46 | 3.3 | 4.79 | 3.22 |
| `GOGC=3200`, sender only | 128.2 | 126.8 | 3,859 | 3,788..3,890 | +17.0% | 18 | 1.4 | 4.85 | 3.62 |
| `GOGC=3200`, receiver only | 4.0 | 2.9 | 3,289 | 3,270..3,299 | −0.3% | 862 | 47.8 | 5.28 | 3.44 |

- **GC takes about 14% here, all on the sender.** The plateau is 3,803–3,859 Mbit/s and the default 3,298, so the default gives up 13–15% (**derived**). Raising only the sender's goal recovers all of it (+17.0%); raising only the receiver's recovers none (−0.3%), even though the receiver collects 589 times a second. As #1829 found, this sender is bound by its send path, so stalls on the sender cost throughput and the receiver has slack.
- **One model fits every pointer-free arm.** Seconds per delivered GiB = t0 + c × (sender GC cycles per GiB), fitted over all 78 runs of the 13 pointer-free arms (`fit1833.py`), gives c = 166 µs of the sender's critical path per collection and t0 = a no-GC ceiling of 3,787 Mbit/s (R² = 0.90; the receiver's term fits to −14 µs, that is, nothing). Every arm's median is within 1.7% of the model. At the default the model puts GC's share at 13.6%.
- **So `GOGC`, a live heap and `GOMEMLIMIT` are interchangeable, through the runway.** Ballast 16 MiB (runway 17 MiB) lands where `GOGC=400` (runway 15 MiB) does; ballast 64 MiB, `GOMEMLIMIT` 64 MiB and `GOGC=1600` (runways 51–65 MiB) all land on the plateau. A consumer whose live heap is L MiB at `GOGC=100` gets a runway of about L MiB (**derived** from the pacer formula above).
- **Where it flattens.** The curve is within 2% of the plateau from a 30 MiB runway (`GOGC=800`) and within 1% from 50 MiB. Every byte of runway above that buys less than one collection's worth.
- **Per collection, the cost is mostly not the pause.** 166 µs per collection against about 56 µs of stop-the-world per collection (48.6 ms/s over 868 cycles/s, **derived**) means about two thirds of each collection's cost to this sender is its mark phase: one of four processors given to the mark worker, plus write barriers and assists (inferred; not traced).
- **The sender spends less CPU per GiB off the floor, but not monotonically.** 5.28 CPU-s/GiB at the default, 4.60 at a 15–17 MiB runway, and 4.83–4.89 at 63–127 MiB, while its GC CPU falls throughout (section 3 has the reason).

### GSO probe sender (NB1 NB2)

| Arm | Sender goal MiB | Sender runway MiB | Mbit/s | Spread | Change | Loss | Sender GC cycles/s | Sender CPU | Sender user CPU | Receiver CPU |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| default (`GOGC=100`) | 4.0 | 2.7 | 5,565 | 5,502..5,596 | — | 1.85% | 1,542 | 3.47 | 2.46 | 2.85 |
| `GOGC=200` | 8.0 | 6.6 | 7,270 | 6,973..7,347 | +30.6% | 1.90% | 760 | 2.80 | 1.92 | 2.31 |
| `GOGC=400` | 16.0 | 14.5 | 8,451 | 8,185..8,493 | +51.9% | 1.61% | 362 | 2.53 | 1.72 | 2.07 |
| `GOGC=800` | 32.0 | 30.8 | 6,582 | 6,157..6,712 | +18.3% | 0.45% | 127 | 2.92 | 2.01 | 2.23 |
| `GOGC=1600` | 64.0 | 62.8 | 5,561 | 5,422..5,605 | −0.1% | 0.22% | 52 | 3.21 | 2.26 | 2.44 |
| `GOGC=3200` | 128.0 | 126.8 | 5,370 | 5,252..5,384 | −3.5% | 0.27% | 25 | 3.30 | 2.33 | 2.50 |
| ballast 2 MiB | 7.0 | 3.6 | 5,973 | 5,680..6,029 | +7.3% | 1.65% | 1,235 | 3.29 | 2.28 | 2.61 |
| ballast 8 MiB | 19.3 | 9.7 | 7,971 | 6,654..8,044 | +43.2% | 1.65% | 532 | 2.62 | 1.78 | 2.15 |
| ballast 16 MiB | 35.2 | 17.7 | 8,434 | 7,667..8,666 | +51.6% | 1.41% | 292 | 2.56 | 1.73 | 2.06 |
| ballast 64 MiB | 130.7 | 65.5 | 5,521 | 4,972..5,580 | −0.8% | 0.22% | 50 | 3.23 | 2.27 | 2.44 |
| `GOMEMLIMIT` 64 MiB | 52.2 | 51.0 | 5,667 | 5,557..5,752 | +1.8% | 0.26% | 67 | 3.17 | 2.20 | 2.40 |
| `GOGC=3200`, sender only | 128.1 | 126.8 | 5,241 | 5,173..5,337 | −5.8% | 0.49% | 24 | 3.31 | 2.35 | 2.94 |
| `GOGC=3200`, receiver only | 4.0 | 2.7 | 5,700 | 5,589..5,802 | +2.4% | 1.00% | 1,558 | 3.47 | 2.44 | 2.37 |

- **This sender peaks at a 10–18 MiB runway and falls back above 30 MiB.** At a 15 MiB runway it delivers 52% more than at the default, matching #1829 (8,496 at `GOGC=400`). At 51–127 MiB it delivers what it delivers at the default, give or take 6%. Its GC cycles keep falling across the whole range (1,542 → 25 a second); what rises after 15 MiB is its user CPU per GiB (1.72 → 2.33, +35%). So past the peak, something other than collection costs it per byte, and that cost grows with the runway (section 3).
- **Loss falls as throughput falls.** The receiver's received-DATAGRAM queue discards 1.4–1.9% at the fast arms and about 0.2–0.5% at the slow ones: the overrun #1824 and #1828 describe, which grows with the sender's rate.
- **Both peers matter for this pair.** A long runway on the sender alone costs 5.8%; on the receiver alone it gains 2.4% and cuts loss from 1.85% to 1.00%, so the receiver's collections slow its drain. Section 3 has the same split at a 15 MiB runway.
- **The model of the stock sender does not fit this sender** (R² = 0.05), because its throughput is not monotonic in the number of collections.

### The stream, as a control

The stream delivers 10,797 Mbit/s at the default and 11,085 with `GOGC=3200` (+2.7%, N campaigns; NB campaigns: 10,576 → 10,835, +2.4%). Its sender collects 33 times a second, so this is its receiver (143 collections a second at the floor, 13.8 ms/s of pauses), whose run loop is the stream's busiest stage ([#1829 §2](https://github.com/GridSwarm/wiremux/blob/77f407959ba943e6995756f0b93b16946d451355/docs/research/issue-1829-native-receive-coalescing-throughput.md#2-the-stream-the-receivers-delivery-path)). The spreads overlap in the N campaigns (10,274..10,940 against 9,763..11,152) and barely in the NB campaigns (10,452..10,920 against 10,705..11,070), so about 2.5% is the stream's GC share, at the edge of this cell's resolution.

## 3. Why a longer runway slows the GSO sender: allocation outruns the cache

Section 2 left two candidates for what slows the GSO probe sender past a 20 MiB runway: the heap goal (or the live heap) itself, or the runway, the span of fresh memory the sender allocates through between collections. Four more interleaved campaigns (RB1 RS1 RB2 RS2, six runs per row) hold the runway near 16 MiB three ways, one of them with a 64 MiB live heap, and step it from 15 to 127 MiB:

| Arm | Sender live heap MiB | Sender heap goal MiB | Sender runway MiB | GSO probe Mbit/s | Spread | Change | Stock Mbit/s | Spread | Change |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| default | 1.3 | 4.0 | 2.7 | 5,586 | 4,940..5,617 | — | 3,305 | 3,189..3,320 | — |
| `GOGC=400` | 1.5 | 16.0 | 14.5 | 8,493 | 8,364..8,544 | +52.0% | 3,660 | 3,568..3,673 | +10.7% |
| ballast 64 MiB, `GOGC=25` | 65.5 | 82.0 | 16.4 | 8,619 | 8,533..8,668 | +54.3% | 3,676 | 3,661..3,702 | +11.2% |
| `GOMEMLIMIT` 28 MiB, `GOGC=off` | 1.5 | 19.1 | 17.7 | 8,536 | 8,410..8,632 | +52.8% | 3,684 | 3,671..3,699 | +11.5% |
| `GOGC=600` | 1.4 | 24.0 | 22.7 | 8,136 | 8,105..8,247 | +45.6% | 3,723 | 3,705..3,743 | +12.6% |
| `GOGC=800` | 1.2 | 32.0 | 30.8 | 6,665 | 6,618..6,695 | +19.3% | 3,791 | 3,777..3,809 | +14.7% |
| ballast 64 MiB, `GOGC=50` | 65.2 | 98.0 | 32.7 | 6,437 | 6,337..6,469 | +15.2% | 3,798 | 3,782..3,820 | +14.9% |
| `GOGC=3200` | 1.2 | 128.1 | 126.8 | 5,313 | 5,249..5,361 | −4.9% | 3,855 | 3,799..3,865 | +16.6% |
| `GOGC=400`, sender only | 1.5 | 16.0 | 14.5 | 6,854 (loss 5.4%) | 6,824..6,886 | +22.7% | 3,732 | 3,723..3,745 | +12.9% |
| `GOGC=400`, receiver only | 1.3 | 4.0 | 2.7 | 5,885 | 5,867..5,905 | +5.4% | 3,268 | 3,236..3,289 | −1.1% |

(Live heap, goal and runway are the GSO probe sender's; the stock sender's are within 0.4 MiB of them.)

- **It is the runway.** A 64 MiB live heap held to a 16 MiB runway delivers what `GOGC=400` delivers on both senders (8,619 against 8,493; 3,676 against 3,660), and a 33 MiB runway with the same live heap delivers what `GOGC=800`'s 31 MiB runway delivers. `GOMEMLIMIT` reaches the same point by capping the goal instead. A large live heap of untouched buffers costs nothing by itself.
- **The GSO probe sender's knee is between a 23 and a 31 MiB runway.** It keeps 94–96% of its peak at a 22.7 MiB runway and falls another 18% by 30.8 MiB. The sender's CPUs share a 32 MiB last-level cache with four other cores' work on this host (CPUs 0–7 and 16–23).
- **Hardware counters say the long runway costs cache misses, not work.** One 10-second run per case and two rotations, `perf stat` in counting mode on each peer (`perf1833.py`; means of the two):

| Sender | Arm | Runway MiB | Mbit/s | Cycles per GiB (billions) | Instructions per GiB (billions) | Instructions per cycle | Demand fills from DRAM per GiB (millions) | Fills from L3 per GiB (millions) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GSO probe | default | 2.7 | 5,457 | 17.2 | 33.9 | 1.97 | 5.9 | 173 |
| GSO probe | `GOGC=400` | 14.5 | 8,297 | 12.6 | 25.1 | 1.99 | 6.3 | 139 |
| GSO probe | ballast 64 MiB, `GOGC=25` | 16.4 | 8,373 | 12.5 | 24.7 | 1.98 | 6.9 | 133 |
| GSO probe | `GOGC=3200` | 126.8 | 5,221 | 16.8 | 26.4 | 1.57 | 34.0 | 83 |
| stock | default | 2.9 | 3,304 | 26.5 | 49.0 | 1.85 | 9.9 | 216 |
| stock | `GOGC=400` | 14.8 | 3,692 | 23.0 | 41.9 | 1.82 | 10.2 | 182 |
| stock | `GOGC=3200` | 127.2 | 3,801 | 24.8 | 39.4 | 1.59 | 38.4 | 126 |

- **At the floor the sender does more work; at a long runway it waits on memory.** From a 2.7 to a 14.5 MiB runway, the GSO probe sender's instructions per GiB fall 26% (the collector's own work) at the same rate of fills from DRAM. From 14.5 to 126.8 MiB, its instructions rise only 5% but its cycles rise 33%: demand fills from DRAM go from about 7 to about 38 per Datagram (**derived**, at 901,557 Datagrams per GiB) and instructions per cycle fall from 1.99 to 1.57. A Datagram's four copies write about 81 fresh 64-byte lines (**derived**: 5,200 bytes); with a short runway those lines are still in cache from the last time the allocator handed them out, and with a long one they are not. The receiver shows the same pattern (demand fills from DRAM 0.6 → 12.7 million per GiB, instructions per cycle 2.21 → 1.81).
- **The stock sender pays the same miss cost but still gains from fewer collections.** Its demand fills from DRAM also rise about 4× at a long runway and its cycles per GiB 8%, yet it still gains 5% from a 15 to a 127 MiB runway. Its bottleneck is the goroutine that writes packets (busy 87% of the transfer, #1829), which makes none of the copies, while a collection stops or slows every goroutine; so the 152 collections a second left at a 15 MiB runway cost it more than the misses do (inferred from the busy shares, not traced).
- **Both peers matter for the GSO pair.** With only the sender at a 15 MiB runway, the receiver at the floor cannot drain: loss rises to 5.4% and the sender's own offer falls to about 7,240 Mbit/s (**derived**: 6,854 / 0.946). With only the receiver off the floor, throughput gains 5.4% and loss falls from 1.87% to 0.43%. For the stock pair, only the sender matters (+12.9% against −1.1%).

## 4. A pointer-bearing live heap

A consumer's live heap is not all pointer-free buffers. The pointer ballast keeps N MiB of 64-byte objects linked by pointers, so every collection must mark each of them (about 262,000 objects per 16 MiB, plus a slice of pointers to them):

| Cell, sender | Arm | Sender runway MiB | Mbit/s | Change against the pointer-free ballast of the same size | Sender GC CPU (CPUs) | Receiver GC CPU (CPUs) | Loss | Received-DATAGRAM queue discards per run |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `netns`, stock | pointer ballast 16 MiB | 23.3 | 3,514 | −3.9% | 0.42 | 0.27 | 0.72% | 26,141 |
| `netns`, stock | pointer ballast 64 MiB | 88.0 | 3,546 | −7.2% | 0.41 | 0.27 | 0.96% | 35,191 |
| `netns`, GSO probe | pointer ballast 16 MiB | 23.0 | 4,925 | −41.6% | 0.60 | 0.38 | 2.03% | 106,406 |
| `netns`, GSO probe | pointer ballast 64 MiB | 87.2 | 4,671 | −15.4% | 0.54 | 0.36 | 1.74% | 86,518 |
| `tb`, stock | pointer ballast 64 MiB | 74.6 | 1,203 | −0.6% | 0.28 | 0.17 | 0.15% | 1,291 |

The pointer-free ballasts of the same sizes run at 0.01–0.10 CPUs of GC (section 2). Collections are as rare with pointers as without, but each one marks the whole live heap, so GC CPU is about the same at 16 and 64 MiB: with a scannable heap, GC work per byte allocated is roughly fixed by `GOGC`, not by the heap's size (**derived** from the table: the goal grows with the live heap, so a larger scannable heap means proportionally fewer but proportionally longer marks). The cost shows as Datagram loss. Against the pointer-free ballast of the same size, loss rises from 0.02–0.06% to 0.7–1.0% on the stock pair in `netns` (the receiver's 128-entry received-DATAGRAM queue discards 26,000–35,000 per run instead of about 550–1,400), from 0.22% to 1.74% on the GSO pair at 64 MiB, and from none to 0.15% on `tb`. The likely cause is that the mark worker and assists slow the goroutine that drains the queue (inferred; the queue counter is measured, the cause is not traced). [#1828](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507)'s 1,024-entry queue is the fix already decided for that overrun.

## 5. macOS: the Thunderbolt pair

Pooled medians of four campaigns (T1–T4; 12 runs per row for the arms all four carry, six for the rest). mbp128's load was high through T1–T3 (load1 8–106 at run starts, from other work on the host), so by PROTOCOL.md's load rule T1–T3 are noisy; T4 (no run flagged for load) agrees with the pool. CPU is CPU-seconds per delivered GiB; user CPU is reported because the receiver's total CPU varies by ±0.5–1 run to run.

| Arm | Mbit/s | Spread | Change | Sender GC cycles/s | Receiver GC cycles/s | Sender CPU | Sender user CPU | Receiver user CPU |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| default | 1,219 | 960..1,323 | — | 275 | 185 | 17.03 | 5.50 | 6.86 |
| `GOGC=400` | 1,161 | 708..1,309 | −4.8% | 47 | 29 | 16.42 | 4.85 | 6.33 |
| `GOGC=3200` | 1,190 | 858..1,295 | −2.4% | 5 | 3 | 16.28 | 4.64 | 6.28 |
| ballast 64 MiB | 1,210 | 909..1,300 | −0.7% | 11 | 7 | 16.05 | 4.68 | 6.27 |
| `GOGC=3200`, sender only | 1,215 | 928..1,256 | −0.3% | 6 | 184 | 15.86 | 4.55 | 6.92 |
| `GOGC=3200`, receiver only | 1,222 | 960..1,278 | +0.2% | 272 | 3 | 16.69 | 5.32 | 6.24 |
| ballast 16 MiB (T1 T2) | 1,238 | 910..1,318 | +1.6% | 44 | 26 | 15.58 | 4.56 | 6.30 |
| stream | 1,411 | 1,033..1,634 | — | 10 | 19 | 12.28 | 3.07 | 5.05 |
| stream, `GOGC=3200` | 1,428 | 1,055..1,480 | +1.2% | 0 | 0 | 12.20 | 3.07 | 4.95 |

- **No arm gains throughput beyond the cell's noise.** Changes run from −4.8% to +1.6% against run-to-run spreads of ±10–15% within every arm, in every campaign including the quiet T4. So GC's share of macOS Datagram throughput is under the cell's resolution, a few percent at most.
- **GC costs CPU on both peers.** Off the floor the sender's user CPU falls 0.65–0.95 CPU-s/GiB (−12 to −17%) and the receiver's 0.5–0.6 (−8 to −9%), and each saving appears only when that peer's own goal rises (the per-peer rows). The sender's total falls less (17.03 → 15.9–16.3), because its CPU is mostly system time in `sendmsg` ([#1823](https://github.com/GridSwarm/wiremux/issues/1823#issuecomment-6066656578)).
- **The macOS peers are less exposed than the `netns` ones.** They collect a third as often (the rate is a third), and `GOMAXPROCS` is 16 and 12, so the mark worker takes 4 of 16 processors instead of 1 of 4 ([`mgcpacer.go` L39](https://github.com/golang/go/blob/go1.27.1/src/runtime/mgcpacer.go#L39)).

## 6. Bytes per Datagram by site, and what the adopted slices remove

Go's allocation profiles sample by bytes allocated, so unlike its CPU profiler they are valid on macOS. One 10-second run per case on both peers at the default (two for the default `dgram` arm in each cell), outside the campaigns, with Go's default sampling rate (`-memprofile`, `prof1833.py`); bytes are each site's share of the profile times the run's Datagrams. Means of the two default runs:

**Sender** (bytes per sent Datagram)

| Site | Owner | `netns` | `tb` | `netns` GSO probe | Removed by |
| --- | --- | --- | --- | --- | --- |
| Copy 1: root `Send` prepends the envelope ([`datagrams.go` L107-L109](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/datagrams.go#L107-L109)) | wiremux | 1,271 | 1,310 | 1,273 | held fork APIs (buffer recycled) |
| Copy 2: root admission queue ([`queue.go` L90](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/datagramadmission/queue.go#L90), from `Send`) | wiremux | 1,281 | 1,303 | 1,290 | slice A |
| Copy 3: native carrier admission queue (the same line, from [`promote.go` L472](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L472)) | wiremux | 1,279 | 1,291 | 1,286 | slice A |
| Copy 4: fork `SendDatagram` frame and payload copy ([`connection.go` L2905-L2916](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2905-L2916)) | fork | 1,329 | 1,301 | 1,303 | held fork APIs |
| Packet-buffer pools refilled after collections ([`buffer_pool.go` L86-L120](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/buffer_pool.go#L86-L120)) | fork | 58 | 15 | 126 | going off the floor |
| Binding send address, per packet ([`unicast.go` L601-L602](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L601-L602)) | wiremux | 46 | 7 | 5 | #1832 binding slice |
| Acknowledgment handling | fork | 35 | 33 | 42 | — |
| Packer frames slice ([`packet_packer.go` L652](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/packet_packer.go#L652)) | fork | 34 | 29 | 30 | — |
| Binding receive address (acknowledgments) | wiremux / `x/net` | 21 | 30 | 8 | #1832 binding slice (Linux: the private copy only) |
| Escaping `errors.As` targets ([`promote.go` L473, L501](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L473-L501)) | wiremux | 16 | 17 | 16 | slice A |
| Packet policy re-encode and copy ([`packet_policy.go` L44-L73](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/packet_policy.go#L44-L73)) | fork | 14 | 28 | 5 | #1832 fork mode |
| **Total** (profile; `runtime/metrics` in the campaigns) | | **5,389** (5,381) | **5,371** (5,322) | **5,385** (5,387) | |

**Receiver** (bytes per received Datagram)

| Site | Owner | `netns` | `tb` | Removed by |
| --- | --- | --- | --- | --- |
| Received-DATAGRAM queue copy and its growth ([`datagram_queue.go` L93-L99](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/datagram_queue.go#L93-L99)) | fork | 1,329 | 1,336 | — (required: the packet buffer is recycled) |
| Root `Receive` second copy ([`datagrams.go` L225-L226](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/datagrams.go#L225-L226)) | wiremux | 1,281 | 1,293 | slice B |
| Root `Receive` per-call context ([`datagrams.go` L183-L184](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/datagrams.go#L183-L184), with the `Done` channel the fork's `Receive` creates on it) | wiremux | 236 | 261 | slice B |
| Binding receive address ([`unicast.go` L980](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L980) plus the OS-layer address) | wiremux / `x/net` | 117 | 100 | #1832 binding slice: on macOS all of it; on Linux the 65-byte private copy, the 47-byte `x/net` address is [#1831](https://github.com/GridSwarm/wiremux/issues/1831)'s |
| Packet policy re-encode ([`sys_conn_oob.go` L411-L439](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L411-L439), from `allowsReceive`) | fork | 107 | 100 | #1832 fork mode |
| Packet-buffer pools refilled after collections | fork | 98 | 19 | going off the floor |
| DATAGRAM frame parse ([`datagram_frame.go` L26](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/wire/datagram_frame.go#L26)) | fork | 31 | 36 | — |
| **Total** (profile; `runtime/metrics` in the campaigns) | | **3,217** (3,209) | **3,189** (3,164) | |

- **By bytes it is all copies.** Each copy is a 1,192-byte payload in Go's 1,280-byte size class ([`sizeclasses.go` L39-L40](https://github.com/golang/go/blob/go1.27.1/src/internal/runtime/gc/sizeclasses.go#L39-L40)). Four of them are 96–97% of the sender's bytes; the fork's copy, wiremux's second copy and the per-call context are 88–91% of the receiver's. The per-packet allocations #1827 counted (six per received packet) are 6–7% of the receiver's bytes and 1–2% of the sender's.
- **What each adopted slice removes, in bytes** (**derived** from the `netns` columns):

| Slice | Peer | Bytes removed per Datagram | Share of that peer's bytes |
| --- | --- | --- | --- |
| [#1826](https://github.com/GridSwarm/wiremux/issues/1826#issuecomment-6148612825) slice A: native send with one queue and one copy | sender | 2,576 (copies 2 and 3, `errors.As`) | 48% |
| #1826 held fork APIs (fork owns the admitted copy, buffer recycled) | sender | about 2,600 more (copy 4, copy 1 reused) | 48% more, leaving about 190 bytes, as #1823's `all` probe measured (187) |
| #1826 slice B: receive without the second copy, reused context | receiver | 1,517 | 47% |
| [#1832](https://github.com/GridSwarm/wiremux/issues/1832#issuecomment-6152076446) binding slice | sender / receiver | about 57 / 65 (Linux), 37 / 100 (macOS) | 1% / 2–3% |
| #1832 fork "packet connection admits" mode | sender / receiver | 14 / 107 | 0.3% / 3% |
| [#1828](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507) 1,024-entry received-DATAGRAM queue | receiver | none (the copy stays; only the queue gets deeper) | — |

- **What that is worth through the GC** (**derived**; the bytes removed also save the copies' and allocations' own CPU, which #1823 measured and is not repeated here):
  - **Slice A at the floor, `netns`, stock sender:** 48% fewer bytes at an unchanged runway means 48% fewer collections (2,261 → 1,180 per GiB), which the stock model of section 2 turns into 3,298 → about 3,540 Mbit/s, **+7.4%**. With the held fork APIs as well, about +16%, which is the whole plateau.
  - **Slice A at the floor, GSO probe sender:** the same cut, read off that sender's measured curve between the ballast-2 and `GOGC=200` arms, is about **+21%** (5,565 → about 6,750).
  - **Slice B:** worth little to throughput where the receiver's GC does not bind (stock `netns`: the receiver-only arm gains nothing). On the GSO pair, the receiver's whole GC is worth +2.4% (section 2) and slice B removes about half of its bytes, so about +1% (**derived**, rough). On macOS its GC part is CPU only.
  - **#1832's slices: about 0.2% of stock throughput in GC terms.** They are worth what #1832 decided them for (CPU per packet), not for the GC.
  - **Off the floor, at a consumer-like heap, every slice's GC part is near zero** (collections are already rare). Their remaining throughput value there is the bytes' cache cost on a CPU-bound sender (section 3) and the copies' CPU.
- **The packet-buffer pools refill because collections empty them.** Go drops every `sync.Pool`'s contents within two collections ([`pool.go` L258-L282](https://github.com/golang/go/blob/go1.27.1/src/sync/pool.go#L258-L282)), so at 590–1,540 collections a second the fork's packet-buffer pools reallocate 1–3% of the peers' bytes (2.3% on the GSO sender, which uses 64 KiB buffers). That allocation is itself a product of the floor, and it falls to about 2 bytes per Datagram with `GOGC=3200`.

## 7. The consumer: GridCast

GridCast is a command-line program that its users run; the only deployed service on its path is the relay ([`real-life-user-test.md` L36-L37](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/docs/real-life-user-test.md#L36-L37)). It carries file Symbols (RaptorQ, 1,024-byte payloads in 1,099-byte Datagram records) over wiremux `v0.2.7` and quic-go-fast `v0.62.1-fast.7` ([`go.mod` L3-L45](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/go.mod#L3-L45)).

**GC settings: none.** No `GOGC`, `GOMEMLIMIT`, `GODEBUG`, `debug.SetGCPercent`, `debug.SetMemoryLimit`, ballast, `//go:debug` directive or memory-limit dependency appears anywhere in its code, configuration or documentation, and it ships no Dockerfile, systemd unit or launchd plist. Release builds set only `GOEXPERIMENT=simd` and `CGO_ENABLED=0` ([`release-build.sh` L35-L52](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/scripts/release-build.sh#L35-L52)). So it runs at `GOGC=100` with no memory limit and `GOMAXPROCS` equal to the CPU count. Its RaptorQ codec is pure Go, so codec memory is Go heap ([`DEPENDENCIES.md` L46-L50](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/docs/DEPENDENCIES.md#L46-L50)).

**Live heap, estimated from code at about 1 Gbit/s** (about 113,700 Datagrams a second):

- **Sender, about 59–75 MiB, about 95% pointer-free.** Six held 8 MiB source Blocks, the smaller of 8 sender slots and the receiver's 6-Block window, are 48 MiB ([`activate.go` L1167-L1188](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/transfer/activate.go#L1167-L1188), [`store.go` L42-L49](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/blockevidence/store.go#L42-L49), [`sender_scheduler.go` L89](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/transfer/sender_scheduler.go#L89)); codec working memory adds 8–24 MiB ([`sender_coding.go` L33-L38](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/transfer/sender_coding.go#L33-L38)); Symbol descriptors, the pointer-bearing part, 2.6 MiB ([`datagram_schedule.go` L69-L77](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/transfer/datagram_schedule.go#L69-L77)).
- **Receiver, about 60–140 MiB, about 90% pointer-free.** Each collecting Block holds about 8,208 separate 1,024-byte payload copies plus a map with two pointers per entry, about 9.3 MiB and 16,000 objects ([`store.go` L72-L75, L1351-L1362](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/blockevidence/store.go#L1351-L1362)); each of two decode workers adds 8 MiB of output and 8–25 MiB of codec memory; up to two retiring Blocks stay live in the cache ([`retention.go` L174-L200](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/blockevidence/retention.go#L174-L200)). The range runs from decoding keeping up (about 63–82 MiB) to decoding being the bottleneck (about 96–143 MiB). Its Datagram drain is a 63-entry channel of 56-byte records ([`datagram_schedule.go` L290-L324](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/transfer/datagram_schedule.go#L290-L324)), which holds wiremux's buffers and reuses none.
- **GridCast's own allocation per Datagram, on top of wiremux's:** about 3.1–3.5 KB on the sender (the encoded record, a job, per-Symbol context churn and an amortized fresh 8 MiB Block buffer: [`symbol_jobs.go` L101-L129](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/transfer/symbol_jobs.go#L101-L129), [`symbol_delivery.go` L152-L182](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/transfer/symbol_delivery.go#L152-L182)) and about 3.3–5.5 KB on the receiver (contexts, record slices, a payload copy and a TransferID string per record, decode: [`datagram.go` L357-L382](https://github.com/GridCastIO/gridcast/blob/f812408fdbfef7fd87c6b6bc22de3d99a7ddd19b/internal/blockevidence/datagram.go#L357-L382)). So a GridCast process allocates roughly twice what the rig does per Datagram.

**Measured, one same-host transfer** (mbp128, `gridcast send --listen` and `gridcast receive --direct` over `lo0`, a 256 MiB file, `GODEBUG=gctrace=1`, 2026-10-13 23:13:32–23:15:42Z):

| Process | Live heap MiB (median, max) | Heap goal MiB (median) | GC cycles/s | Allocated MB/s (gctrace estimate) |
| --- | --- | --- | --- | --- |
| sender | 67, 84 | 136 | 3.0 | 173 |
| receiver | 24, 40 | 49 | 7.8 | 179 |

The sender's heap matches the estimate. The transfer itself was slow, though: 256 MiB took 128 seconds (about 17 Mbit/s), with the receiver spending 128.7 of its 129 seconds in system time, so the receiver held few Blocks and this is not a Datagram-load measurement. The receiver's 24 MiB is the bottom of its range, not its value at 1 Gbit/s.

**What the rig predicts for it** (**derived**): at `GOGC=100` each GridCast process's runway is about its live heap, 24–140 MiB: the rig's ballast 16 and 64 MiB rows and beyond. There:

- GC collections cost the stock sender about 0.6% of throughput at a 65 MiB runway (the section 2 model at 78 collections per GiB), and the GSO probe sender collects as rarely there. GridCast's own allocation roughly doubles the bytes per Datagram, so about 1%. **GC collections take about 1% of Datagram throughput in a consumer like GridCast**, against 14% in the rig at its default.
- The long runway is GridCast's normal state, not a tuning choice. On a sender that is CPU-bound in the Datagram path, it costs what section 3 measures; on the stock path it costs nothing.
- About 5–10% of GridCast's live heap carries pointers (descriptors, maps, per-record strings, about 16,000 objects per collecting Block). That is between the rig's pointer-free and pointer ballast rows: its mark work is real CPU, and on a receiver that marks while it drains, it adds Datagram loss at the fork's queue (section 4).

## 8. Which GC setting rig comparisons should pin

**Pin `-ballast 64` on both peers for Datagram lever comparisons, and report the default row alongside it.**

- **`-ballast 64` is what a consumer looks like to the pacer.** A 64 MiB pointer-free live heap at `GOGC=100` gives a 65 MiB runway and 35–50 collections a second: GridCast's sender, measured, and the middle of its receiver's estimated range. On the stock sender it sits on the plateau (3,822 Mbit/s, within 0.3% of `GOGC=3200`), and on the GSO probe sender it includes the long-runway cost a real consumer pays (5,521).
- **The default row is the lever's GC sensitivity.** At the floor, any byte a lever allocates or keeps live costs throughput through collections: #1829's 0.5 MiB of coalescing slots cost 2.6–2.8% there and nothing at `GOGC=400`. A lever's gain at the default minus its gain at `-ballast 64` is the part a consumer does not see.
- **Not `GOGC=400`.** It was the right causal check in #1829, but its 15 MiB runway is a sweet spot specific to the rig's 1 MiB live heap: the GSO probe sender delivers 8,451 Mbit/s there and 5,521 with a consumer-sized heap. A comparison at `GOGC=400` would overstate the Datagram GSO lever by about half.
- **Not `GOGC=off` or a very large goal.** Throughput does not improve past a 50 MiB runway on the stock sender and gets worse on the GSO probe sender; memory then grows at gigabytes per second.
- **`-ballast 64` rather than `-gogc 1600` or `GOMEMLIMIT`,** although the three are equivalent by runway (section 2), because only the ballast scales the runway the way a consumer's own heap does, and it keeps `GOGC` at the default every consumer runs.
- **How to compare a lever that removes allocation bytes.** At the floor, its benefit shows partly as fewer collections (slice A: about +7% stock, +21% GSO, **derived**); at `-ballast 64` that part is gone and what remains is CPU per GiB and, on a CPU-bound sender, cache traffic. Report both rows, and judge adoption on the `-ballast 64` row plus CPU per GiB. On macOS, compare user CPU: there is no throughput to see in either row.
- **The pin is a ballast, not GridCast.** The rig's ballast is untouched memory. A real consumer also reads and writes its live heap, which adds cache pressure the rig does not model, so the rig's long-runway numbers are an upper bound for a consumer.

## What this means for the map

1. **(rig) Pin `-ballast 64` for Datagram comparisons, and keep the default as a second row.** The probe's knobs (`-ballast`, `-ballast-ptr`, `-gogc`, `-memlimit`, `-gc-role`, `-memprofile`) and its `runtime/metrics` window are in `wiremux-probe-1833.diff`; `-ballast` and `-gc-role` are the two worth adding to the rig on `codex/native-gap-rig`, with a PROTOCOL.md paragraph saying why. Every later Datagram ticket then reports both rows.
2. **(input, [What bounds the native Datagram send feed once Go's garbage collector is off its floor?](https://github.com/GridSwarm/wiremux/issues/1834))** Measure at `-ballast 64`, not `GOGC=400`. Off the floor the answer depends on the runway: at a 15 MiB runway the GSO probe sender reaches 8,451 Mbit/s and #1829 found its feed's hand-offs binding; at a consumer-like 65 MiB runway it reaches 5,521 and spends 32% more user CPU per GiB than at 15 MiB. So at the pinned setting the first suspect is the cost of the four per-Datagram copies landing in cold memory, not only the hand-off waits (section 3). That shifts #1834's premise: the feed question and the copies question are the same question at a consumer-sized heap.
3. **(input, [Should native receives adopt coalescing once the fork copies coalesced datagrams at read time?](https://github.com/GridSwarm/wiremux/issues/1835))** Measure at `-ballast 64` with the default row alongside. #1829's 2.6–2.8% stock-Datagram cost of the coalescing slots is a floor effect and disappears at the pinned setting (as it did at `GOGC=400`). Copy-at-read's receiver-side allocation cut (373 → 142 MB/s on the stream receiver) is worth more at the floor than at the pin, where the receiver's GC is worth about 2.5% of the stream and 2.4% of the GSO Datagram pair (section 2).
4. **(input, [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801))** State Linux Datagram targets at a consumer-like heap. In this cell the stock Datagram path is 16% faster there than at the rig's default, and the GSO probe's 8.5 Gbit/s at `GOGC=400` is not a consumer number; 5.5 Gbit/s is. Sequencing: slice A's value is largest at the floor (about +7% stock, **derived**), which a consumer is not at; at a consumer-like heap its value is CPU and cache.
5. **(input, [Where does the macOS ~1 Gbit/s native ceiling actually come from?](https://github.com/GridSwarm/wiremux/issues/1800))** GC is not part of the macOS ceiling: no measurable throughput effect on the Thunderbolt pair, about 0.8 sender and 0.6 receiver user CPU-s/GiB at the floor. The ceiling ticket can run at the default.
6. **(input, [Which per-Datagram cost reductions should native Datagrams adopt?](https://github.com/GridSwarm/wiremux/issues/1826) and [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825))** By bytes, slice A and the held fork APIs are the only levers that matter to the GC (48% of the sender's bytes each); #1832's slices do not. The held fork APIs' buffer recycling keeps the sender's allocation in a few warm buffers instead of a 65 MiB runway, which is the cost section 3 measures on a GSO sender at a consumer-sized heap. That is a reason to measure them at `-ballast 64` if GSO is adopted, which #1826's rule does not yet say.
7. **(new question) How much of the GSO sender's long-runway slowdown do the per-Datagram copies cause, and do slice A and the fork's ownership APIs recover it?** At a consumer-sized heap the GSO probe sender loses about a third against its best runway (8,451 → 5,521 Mbit/s) with fewer collections, through higher CPU per byte (section 3). Whether removing three of the four copies recovers that is measurable with #1823's probes at `-ballast 64`, and decides how far Datagram GSO gets in a consumer. It is sharp enough for its own ticket.
8. **(input, [How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828))** A receiver with a pointer-bearing live heap discards about 25–50 times more at the 128-entry queue than one with a pointer-free heap of the same size (section 4). That is consumer-shaped evidence for the 1,024-entry depth already decided, and the depth's own A/B should include a pointer-ballast receiver.

## Evidence

Cells: `netns` is namespaces `nr-send` and `nr-recv` on minimax (Ubuntu 26.04, Linux `7.0.0-30-generic`, Ryzen AI MAX+ 395, 32 MiB L3 per 8-core complex), joined by `veth` at MTU 1500, veth GRO off (the default) throughout, sender pinned to CPUs 4–7 and receiver to 12–15 (`GOMAXPROCS` 4 each). It is a shape cell: no real NIC, both peers on one host, the receive path's softirq on the sender's CPUs. `tb` is mbp128 (`bridge0`, M4 Max, `GOMAXPROCS` 16) to m4mini (`GOMAXPROCS` 12) over Thunderbolt at MTU 1500, macOS 27.

- **Builds** (throwaway, never pushed): the wiremux probe is #1829's probe (2599a002 plus the #1824 and #1829 rig probes, 7c97ef2b) plus `-gc-role`, `-ballast`, `-ballast-ptr`, `-memlimit`, `-memprofile` and `-memprofilerate` (4e52afd7) and `rig1833.sh`, `rig1829.sh` with a per-run wait for another session's `tb` run (0e674b50, a shell file only). Memory-profile sampling is off unless `-memprofile` is set, as in #1829's builds, which never link `runtime.MemProfile`. The fork is #1829's `qgf-1829-fx` (`v0.62.1-fast.7` plus passive counters, knobs off) for the stock sender and `qgf-1829b-fx` (plus #1824's equal-size Datagram GSO sender) for the GSO probe, used read-only.
- **Campaigns** (each `REPS=3 WARMUP=1 SECS=10`, standard slate plus the ticket's arms): `netns` N1 NB1 N2 NB2 (2026-10-13 22:10–23:33Z, interleaved stock and GSO probe), RB1 RS1 RB2 RS2 (2026-10-13 23:35Z to 2026-10-14 00:33Z, interleaved GSO probe and stock, runway arms); `tb` T1 T2 (22:15–23:12Z, 20 arms; T1 waited 730 s before one run for another session's `tb` run) and T3 T4 (23:19–23:46Z, 12 arms, repeated because T2's first rotation ran at mbp128 load1 33–106). Pooled medians are over the non-warm-up runs; every per-campaign median is in the evidence directory. The stock pairs (N, RS) and the RB pair agree within 1.9% on every arm except the N stream (5.1%). NB2 ran 1–3% faster than NB1 on most GSO-probe arms and 4.6–7.9% on three (`GOGC=800`, ballast 16 MiB, pointer ballast 16 MiB), the arms nearest that sender's knee; none of the GSO conclusions rests on a difference that small. No `netns` run was flagged. T1–T3 have every run of one or more rotations flagged for load (other work on mbp128, not this ticket's), which by PROTOCOL.md makes them noisy; T4 has one flag (a `udp` rate). The `tb` throughput conclusion rests on all four and on T4 alone agreeing.
- **Outside campaigns:** allocation profiles, one 10-second run per case on both peers (`netns`: stock and GSO probe at the default twice and at `GOGC=3200` once, stock stream once, 23:33–23:35Z; `tb`: default twice, `GOGC=3200` and stream once, 23:12–23:13Z), binaries kept beside them; hardware counters (`perf stat -x, -e cycles,instructions,ls_any_fills_from_sys.dram_io_all,ls_dmnd_fills_from_sys.dram_io_all,ls_any_fills_from_sys.local_ccx,ls_any_fills_from_sys.local_l2`, counting mode, run as root through the same `sudo ip netns exec` the rig uses, no host setting changed), one 10-second run per case on both peers, two rotations (2026-10-14 00:33–00:37Z); the counters were multiplexed (about 83% of the time enabled each) and are perf's scaled estimates; one GridCast same-host transfer (23:13–23:16Z) with `GODEBUG=gctrace=1`.
- **Caveats:** the model fit is over medians of a sender-bound shape cell and says nothing about a receiver-bound one; the pointer ballast is a linked list of uniform 64-byte objects, harsher to mark than most real heaps; the ballast is untouched memory, gentler on caches than a real consumer's heap; the GridCast run measured heap size, not behavior at Datagram load.

Directory: `/Volumes/worktrees/wiremux/native-gap-evidence/1833-gc/` on mbp128 (README.txt, campaign scripts, `an1833.py` → `an-n.txt`, `an-nb.txt`, `an-t.txt`, `an-t4.txt`, `an-rb.txt`, `an-rs.txt`; `fit1833.py` → `fit-n.txt`, `fit-nb.txt`, `fit-t.txt`; `prof1833.py` → `prof/*.txt`; `perf1833.py` → `perf/perf-summary.txt`; `gridcast-run/`; `gridcast-src` is the shallow GridCast clone; `wiremux-probe-1833.diff`).
