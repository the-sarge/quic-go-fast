# TURN publication characterization — 2026-09-05

This bounded receipt supports [T1.S1](../adr/2026-09-04-turn-composite-publication-plan.md#slice-1--own-turn-composite-publication-and-its-fault-handoff), [child #1436](https://github.com/GridSwarm/wiremux/issues/1436), and the accepted plan at `5cd6dcef0af97a4a5c896467e76ee6b60dae1ea1`. The starting product head was `a096db3b41b20f5553a17212f65156d440c346f4`. It records controlled outcomes, not physical failure frequency or a network-liveness guarantee.

## Characterization before correction

The pinned `github.com/the-sarge/turn/v5 v5.3.0-gs.1` client delivers allocation response traffic through `Client.HandleInbound`; `Client.Allocate` builds and activates the allocation before returning it. A test barrier immediately after that successful return orders external closure of the real dedicated UDP socket and joins the composite's base guard before allowing construction to continue. The existing socket seam alone cannot hold the allocator after response delivery, so the permitted private `testBeforePublication` barrier is nil in production. No TURN parser, transaction, or general scheduler was substituted.

With only that barrier and `TestAllocateRejectsRecordedBaseFailure` added, the regression failed: `Allocate after observed base failure: got (*pionturn.packetConn, <nil>), want (nil, base failure)`. Thus a supported lost-fault history was demonstrated before changing behavior. The test closed the returned composite before reporting the failure.

## Correction and consolidation

`packetConn.publish` owns allocation/address adoption, consumer registration, publication, and consumer launch. Publication and base-failure recording share the existing mutex. An earlier recorded failure rejects publication and the allocator disposes the successful allocation through the existing terminal executor, joining cleanup before returning nil/error. A later recorded failure takes the existing published terminal path. Production and both fake-allocation constructors call this operation; the forced-close fixture still omits the base guard, while the self-seal fixture still starts it.

The competing cancellation regression initially failed because the cancellation cause appeared twice. Allocated rejection now returns the terminal aggregate, which already carries its initiating cause, instead of adding that cause again. The invalid-address branch uses the same disposal return and remains ahead of the context check. No-allocation cleanup and pending-Allocate cancellation policy are unchanged.

## Finite evidence

| Controlled case | Evidence and result |
| --- | --- |
| Reader failure before publication | `TestAllocateRejectsRecordedBaseFailure`: red on the original publication recipe, green with nil/error, forced/base-failure identity, joined cleanup, and one owned socket close |
| Competing cancellation and independent reader failure | `TestAllocateCancellationPreservesRecordedBaseFailure`: red on duplicate cancellation cause, green with both causes retained once, no publication, joined cleanup, and one owned socket close |
| Successful publication of an already self-sealed allocation | `TestPublicationAdoptsAlreadySelfSealedAllocation`: terminal completion, exact self-seal classification, joined work, one allocation/socket close, and stable repeated result |
| Reader failure after publication | `TestPublishedBaseFailureJoinsTerminalCleanup`: autonomous terminal completion, forced/base-failure classification, joined cleanup, one owned socket close, and stable repeated result |

The caller/store audit found exactly three success callers and one publication store, all through `publish`; the only other allocation assignment is rejected-construction disposal. There are no independently callable consumer registration/launch methods. No optional fifth case was added: invalid-address and context rejection use the same allocated disposal route, and the unchanged address-before-context order remains explicit. The existing invalid-address fixture exercises dependency rejection and is not claimed as new evidence for the composite's defensive validator.

The named preservation suite, package race run, and repository gates provide the remaining validation. Exact-head certification and hosted CI receipts belong to the product PR discussion. No new mutation, platform, repetition, or hosted-experiment scope is claimed; no additional untraced effects were identified.
