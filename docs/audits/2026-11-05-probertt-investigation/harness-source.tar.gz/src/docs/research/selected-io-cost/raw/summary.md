| Workload | Selection | Delivered Mbit/s | CPU seconds | Allocated MiB | Million allocations | Establishment ms | Threads before→after |
|---|---|---:|---:|---:|---:|---:|---|
| relay | baseline | 15500.433 [14830.211, 16809.959] | 5.400 [5.382, 5.543] | 0.077 [0.075, 0.078] | 0.000 [0.000, 0.000] | 1.083 [1.002, 1.201] | 5→5, 5→5, 5→5 |
| relay | selected | 906.202 [757.692, 913.913] | 5.580 [5.217, 5.652] | 8112.899 [6775.567, 8166.597] | 14.046 [11.856, 14.140] | 2.884 [2.666, 2.911] | 5→6, 5→5, 5→5 |
| stream | baseline | 9224.626 [8077.023, 10109.007] | 5.789 [5.557, 5.860] | 300.441 [264.143, 329.739] | 10.861 [9.514, 11.903] | 9.075 [8.600, 9.454] | 4→5, 5→5, 5→5 |
| stream | selected | 811.665 [740.488, 846.108] | 5.620 [5.202, 5.622] | 6408.888 [5821.551, 6699.889] | 13.465 [12.280, 14.073] | 15.817 [15.637, 18.177] | 5→5, 5→5, 5→5 |
| datagram | baseline | 15.967 [15.807, 15.985] | 0.591 [0.550, 0.660] | 47.604 [47.162, 47.620] | 0.162 [0.161, 0.163] | 9.230 [9.069, 9.875] | 5→5, 5→5, 5→5 |
| datagram | selected | 15.963 [15.945, 15.984] | 2.073 [2.063, 2.228] | 845.156 [841.394, 845.485] | 1.810 [1.801, 1.811] | 15.401 [14.801, 15.863] | 5→5, 5→5, 5→5 |

| Datagram cell | Scheduled | Attempted | Accepted | In window | Unique after drain | Missing accepted | Duplicates |
|---|---:|---:|---:|---:|---:|---:|---:|
| datagram-baseline-1 | 6000 | 5996 | 5996 | 5996 | 5996 | 0 | 0 |
| datagram-baseline-2 | 6000 | 5988 | 5988 | 5988 | 5988 | 0 | 0 |
| datagram-baseline-3 | 6000 | 5928 | 5928 | 5928 | 5928 | 0 | 0 |
| datagram-baseline-profile | 6000 | 5918 | 5918 | 5918 | 5918 | 0 | 0 |
| datagram-selected-1 | 6000 | 5988 | 5988 | 5986 | 5988 | 0 | 0 |
| datagram-selected-2 | 6000 | 5996 | 5996 | 5996 | 5996 | 0 | 0 |
| datagram-selected-3 | 6000 | 5980 | 5980 | 5980 | 5980 | 0 | 0 |
| datagram-selected-profile | 6000 | 5998 | 5998 | 5998 | 5998 | 0 | 0 |

| Profile cell | Delivered Mbit/s | CPU seconds | Allocated MiB |
|---|---:|---:|---:|
| datagram-baseline-profile | 15.779 | 0.590 | 47.139 |
| datagram-selected-profile | 15.992 | 2.163 | 850.307 |
| relay-baseline-profile | 14939.325 | 5.595 | 0.091 |
| relay-selected-profile | 879.088 | 5.662 | 7895.060 |
| stream-baseline-profile | 7616.713 | 5.621 | 242.870 |
| stream-selected-profile | 849.553 | 5.695 | 6586.127 |
