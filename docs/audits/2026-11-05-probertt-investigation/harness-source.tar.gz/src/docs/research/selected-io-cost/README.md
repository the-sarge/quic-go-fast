# Selected I/O validation cost on Linux

This bounded investigation implements [issue #1610's approved brief](https://github.com/GridSwarm/wiremux/issues/1610#issuecomment-5781786199). It measures production revision `f4ba635a7b668b85f16b50574c5ffbe0f1076eb1` on 2026-09-22. The [capture declaration](PLAN.md) fixes the workload, operational and review budgets. The retained Go text is a disposable capture aid, excluded from ordinary builds and CI; no production code, public API, validation cadence or ownership changed.

## Reproduction and custody

The [raw ledger](raw/ledger.json) records every matrix command and exit status; [identity](raw/identity.json) records the binary and aid SHA-256 and container image digest. The [Linux environment](raw/environment.txt), [host description](raw/host.txt), per-cell `capture.log`, `result.json`, binary profiles and symbolized profile text are retained in `raw/`. Environment and build-toolchain text views strip trailing whitespace for repository formatting; the sibling `.txt.gz` files preserve their original bytes, and `raw/sha256.json` covers both views and all other raw files. The six smoke observations are retained separately under `raw/smoke/`; they are not repetitions in the analysis. The binary is rebuildable from the pinned source and aid rather than committed as an executable. The run requires Docker and Python 3; builds require an already-installed Go 1.27.1 or newer approved base toolchain. Perform both the host and container audits before Go build/test commands; stop if the base is below the approved floor.

Create a fresh worktree at the production revision, copy this investigation directory into it, and run from that worktree. Move the supplied `raw` evidence directory aside and create an empty `raw` directory before capturing: the runner refuses to overwrite existing cell directories. The supplied evidence remains immutable; a reproduction is a new campaign, not additional samples for this report.

```sh
GOTOOLCHAIN=local go version
go version
go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS
mkdir -p .cache/selected-io
cp docs/research/selected-io-cost/capture_test.go.txt cost_capture_linux_test.go
GOOS=linux GOARCH=arm64 CGO_ENABLED=0 GOTOOLCHAIN=local go test -c -o .cache/selected-io/capture.test .
rm cost_capture_linux_test.go
python3 docs/research/selected-io-cost/run.py --environment
python3 docs/research/selected-io-cost/run.py --smoke
python3 docs/research/selected-io-cost/run.py
python3 docs/research/selected-io-cost/summarize.py
```

`--environment` executes the container toolchain audit, kernel and resource inventory; compilation above uses the audited host toolchain for cross-compilation, not the container toolchain. The retained commands use an immutable Linux ARM64 Go image, a two-CPU cgroup quota, 2 GiB memory limit, `GOMAXPROCS=2`, and `--network none`. The Docker Linux VM runs on an Apple M4 Max. This is virtualized Linux loopback evidence, not native physical-NIC or WAN qualification. There is no deliberate impairment, competing traffic or affinity pinning. Other host activity and quota scheduling remain sources of variation.

Both peers and the TLS relay run in one fresh process per cell. Both selected endpoints independently resolve `lo`; this avoids introducing cross-peer contention through an artificially shared handle. Their own synchronous I/O and operation-owned observers still share each endpoint's production state and locks. Unselected direct peers transfer plain IPv4 UDP sockets explicitly bound to `127.0.0.1`; selected peers use the production selected socket constructor on `lo`. This necessary setup difference yields equivalent bound source addresses and actual routes. Every direct capture checks both peers' direct outcome and loopback local/remote candidates. Relay captures check both TCP endpoints. Diagnostic ports vary; routes, payloads, transport configuration and offered workload policy do not.

Relay transfer uses the paired `relay.Dial` TLS carrier. Direct stream and Datagram transfer use public `wiremux.Dial` with the default QUIC transport and encrypted channel, fixture authentication, no STUN and no TURN. Establishment measures handle resolution and the two concurrent dials after the relay starts; it excludes fixture certificate generation and relay creation. Transfer has one sender and one receiver, 1 second of warmup on that pair, then a 3-second measured phase. Stream blocks are 32 KiB, with saturated demand. Datagrams carry 1,000 bytes (including phase/sequence identifiers), with 6,000 scheduled slots over 3 seconds, offered in pairs every millisecond. Missed pacing slots are skipped, counted as unattempted and never called receiver loss. The achieved offered count is reported explicitly.

Delivered Mbit/s uses complete application payloads received before the sender phase stops, divided by the actual sender phase duration. A blocking stream write can slightly extend that duration; raw `SendSeconds` records it. Streams then send an excluded sentinel block and join the reader; all accepted blocks must be delivered. Datagrams drain for 250 ms, then join the receiver. Raw `Unique` is the fully drained count, `DeliveredInWindow` is the earlier count, and `Accepted - Unique` is missing accepted traffic. Duplicate and foreign-phase counts are separate. This does not equate accepted `Send` calls with delivered traffic.

Resource deltas are process-wide `getrusage` CPU and `runtime.MemStats` allocated bytes/allocation counts surrounding the measured phase plus its drain, excluding establishment, warmup and explicit pre-measurement GC. They include both endpoints, the relay, all background observers and ordinary runtime work. They are not per-peer or per-packet native syscall costs. Thread and goroutine counts are snapshots before/after, not peaks. The CPU cost can exceed wall time because two CPUs are permitted. Profiling uses separate cells: 100 Hz CPU sampling, mutex fraction 1, default allocation sampling, before/after allocation snapshots, and an 8 MiB cap per profile.

## Results

Recommendation: **optimize in a separately approved follow-up**. Repeated native interface/namespace inspection is a measured bottleneck in this Linux loopback workload. The evidence supports investigating a cheaper inspection/enforcement implementation; it does not establish a safe cache policy, a validation interval, a throughput target or authority to weaken checks.

All 18 unprofiled and six profiled cells passed, as did the six separate smoke cells. There were no unavailable cells, failed cells or matrix reruns. Values below are median [minimum, maximum] across the three unprofiled repetitions; Mbit/s is decimal, allocated MiB is cumulative allocation traffic rather than live memory or RSS.

| Workload | Selection | Delivered Mbit/s | CPU seconds | Allocated MiB | Million allocations | Establishment ms | Threads before→after |
|---|---|---:|---:|---:|---:|---:|---|
| relay | baseline | 15500.433 [14830.211, 16809.959] | 5.400 [5.382, 5.543] | 0.077 [0.075, 0.078] | 0.000 [0.000, 0.000] | 1.083 [1.002, 1.201] | 5→5, 5→5, 5→5 |
| relay | selected | 906.202 [757.692, 913.913] | 5.580 [5.217, 5.652] | 8112.899 [6775.567, 8166.597] | 14.046 [11.856, 14.140] | 2.884 [2.666, 2.911] | 5→6, 5→5, 5→5 |
| stream | baseline | 9224.626 [8077.023, 10109.007] | 5.789 [5.557, 5.860] | 300.441 [264.143, 329.739] | 10.861 [9.514, 11.903] | 9.075 [8.600, 9.454] | 4→5, 5→5, 5→5 |
| stream | selected | 811.665 [740.488, 846.108] | 5.620 [5.202, 5.622] | 6408.888 [5821.551, 6699.889] | 13.465 [12.280, 14.073] | 15.817 [15.637, 18.177] | 5→5, 5→5, 5→5 |
| datagram | baseline | 15.967 [15.807, 15.985] | 0.591 [0.550, 0.660] | 47.604 [47.162, 47.620] | 0.162 [0.161, 0.163] | 9.230 [9.069, 9.875] | 5→5, 5→5, 5→5 |
| datagram | selected | 15.963 [15.945, 15.984] | 2.073 [2.063, 2.228] | 845.156 [841.394, 845.485] | 1.810 [1.801, 1.811] | 15.401 [14.801, 15.863] | 5→5, 5→5, 5→5 |

The selected relay median delivered rate was 0.906 Gbit/s versus 15.500 Gbit/s for the baseline; the selected direct stream median was 0.812 versus 9.225 Gbit/s. These are measured treatment differences in this topology, not historical regressions or projected physical-link rates. Aggregate CPU time is similar because the saturated cases consume most of the two-CPU allowance while accomplishing different amounts of useful transfer. Selected allocation traffic rises to roughly 7.9 GiB for relay and 6.3 GiB for stream over three seconds, which is allocation churn, not resident storage.

At the offered Datagram policy, both treatments delivered approximately 16 Mbit/s. The selected median consumed 2.073 CPU seconds and 845.156 MiB of allocations, compared with 0.591 CPU seconds and 47.604 MiB for the baseline. Because realized attempted counts differ slightly with scheduler lateness, this is a near-equal offered-load comparison, not an identical packet schedule. The fully drained accepted count was delivered in every repetition; no duplicates or foreign-phase payloads were observed. Selected repetition 1 received two packets during drain. This fixed load does not measure Datagram saturation or the rate where loss begins.

| Datagram cell | Scheduled | Attempted | Accepted | In window | Unique after drain | Missing accepted | Duplicates |
|---|---:|---:|---:|---:|---:|---:|---:|
| datagram-baseline-1 | 6000 | 5996 | 5996 | 5996 | 5996 | 0 | 0 |
| datagram-baseline-2 | 6000 | 5988 | 5988 | 5988 | 5988 | 0 | 0 |
| datagram-baseline-3 | 6000 | 5928 | 5928 | 5928 | 5928 | 0 | 0 |
| datagram-baseline-profile | 6000 | 5918 | 5918 | 5918 | 5918 | 0 | 0 |
| datagram-selected-1 | 6000 | 5988 | 5988 | 5986 | 5988 | 0 | 0 |
| datagram-selected-2 | 6000 | 5996 | 5996 | 5996 | 5996 | 0 | 0 |
| datagram-selected-3 | 6000 | 5980 | 5980 | 5980 | 5980 | 0 | 0 |
| datagram-selected-profile | 6000 | 5998 | 5998 | 5998 | 5998 | 0 | 0 |

## Attribution and profiling limits

Cumulative CPU samples in the separate selected profiles put `nativeFacts.current` at 77.74% of relay CPU, 63.56% of direct stream CPU and 44.91% of Datagram CPU. Within those same profiles, `net.Interfaces` accounts for 58.48%, 45.60% and 37.04%; the namespace census accounts for 19.26%, 17.78% and 7.87%. These are nested stack percentages, not quantities to add together. The relay stacks include both paired-carrier admission and selected-socket checks around TLS I/O. Direct stream stacks include reliable admission and native QUIC send validation; the Datagram `PacketBinding.CheckSend` stack accounts for 51.39% of its sampled CPU. These observations attribute work to the production validation paths without adding counters or bypassing checks.

Before/after sampled allocation profiles place 99.08%, 95.46% and 92.28% of relay, stream and Datagram allocation bytes under `nativeFacts.current`. The dominant allocations are the netlink interface inventory (`syscall.NetlinkRIB`, `syscall.ParseNetlinkRouteAttr` and their callers), rather than the small per-thread namespace records. Allocation-profile estimates differ from exact MemStats deltas because sampling and profiler/snapshot shutdown work are included. They establish an allocation owner, not exact syscall counts.

The mutex profile records 27.73 ms of cumulative contended delay for selected relay versus 1.145 ms baseline; selected stream records 464.35 ms versus 30.54 ms baseline; selected Datagram records 15.275 ms versus 0.678 ms baseline. Within selected stream, `snapshot` appears on releasing stacks for 208.58 ms, and `PacketBinding.Validate` appears for 268.03 ms. Those stacks overlap and must not be summed. Profiles attribute delay to lock holders at unlock and aggregate blocked goroutines; they do not directly measure every uncontended lock operation or independent wall-clock time lost. Some cumulative stacks contain runtime allocation/GC locks below validation. Inspection/allocation cost is clearer evidence than any claim that the handle mutex alone caused the throughput gap. Observer-only overhead, exact lock-only causal cost, syscall counts, separate-process scaling, and behavior at higher thread/interface counts remain inconclusive within this budget.

| Profile cell | Delivered Mbit/s | CPU seconds | Allocated MiB |
|---|---:|---:|---:|
| datagram-baseline-profile | 15.779 | 0.590 | 47.139 |
| datagram-selected-profile | 15.992 | 2.163 | 850.307 |
| relay-baseline-profile | 14939.325 | 5.595 | 0.091 |
| relay-selected-profile | 879.088 | 5.662 | 7895.060 |
| stream-baseline-profile | 7616.713 | 5.621 | 242.870 |
| stream-selected-profile | 849.553 | 5.695 | 6586.127 |


Profile captures are not pooled into the baseline statistics. For example, the profiled baseline stream rate (7.617 Gbit/s) is below all three unprofiled repetitions (8.077–10.109 Gbit/s), while other profile rates lie near their unprofiled ranges. With one profile per cell, profiler overhead cannot be isolated from scheduling/run variation. The literal capture window includes the bounded drain: Datagram CPU profiles span about 3.26 seconds, not exactly 3 seconds. Mutex sampling remains enabled through CPU-profiler shutdown, and allocation snapshots additionally include shutdown/GC/snapshot work. This is a disclosed boundary detail relative to the declaration's shorthand “3-second phase,” not extra workload or an expanded matrix. Profiles remain finite and no file reached its 8 MiB cap.

The symbolized `cpu-top.txt`, `cpu-cumulative.txt`, `mutex.txt` and `alloc.txt` beside each profile expose these numbers. To regenerate a cell's interpretation, run these commands with `CELL` naming one of the six profile directories:

```sh
CELL=docs/research/selected-io-cost/raw/stream-selected-profile
GOTOOLCHAIN=local go tool pprof -top -nodecount=30 "$CELL/cpu.pprof"
GOTOOLCHAIN=local go tool pprof -top -cum -nodecount=50 "$CELL/cpu.pprof"
GOTOOLCHAIN=local go tool pprof -top -cum -nodecount=30 "$CELL/mutex.pprof"
GOTOOLCHAIN=local go tool pprof -top -cum -nodecount=30 -sample_index=alloc_space -base "$CELL/alloc-before.pprof" "$CELL/alloc-after.pprof"
```

## Follow-up boundary

A later optimization proposal should target repeated interface/namespace inventory and its allocation cost at the existing inspection owner, then explain how it preserves the current observation/admission guarantees. It must preserve rejection of threads in different namespaces, observed-loss handling and monotonic staleness, exact selection provenance, source-domain and per-send admission, fail-closed inspection errors, and socket/observer ownership. Neither a permanent global monitor nor simply removing repeated checks follows from these measurements. Any change in observation cadence or supported representation requires its own decision; no production optimization is implemented here.

These finite results justify an optimization investigation without establishing a performance threshold. They remain nonblocking for the routing program and do not qualify GridCast, other platforms, physical networks, TURN or multi-peer concurrency.
