#!/usr/bin/env python3
"""One finite issue-1610 matrix; no retries and no production instrumentation."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'docs/research/selected-io-cost/raw'
IMAGE = 'golang@sha256:69a7b9788769bec032d238959b61854e9ae87f57be9029ec04e9885fabf99195'
BINARY = ROOT / '.cache/selected-io/capture.test'

def execute(args, **kwargs):
    return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45, **kwargs)

base = ['docker', 'run', '--rm', '--network', 'none', '--cpus', '2', '--memory', '2g',
        '-e', 'GOMAXPROCS=2', '-e', 'GOTOOLCHAIN=local',
        '-v', f'{BINARY}:/capture.test:ro']
if '--environment' in sys.argv:
    result = execute(base + [IMAGE, 'sh', '-c',
        'GOTOOLCHAIN=local go version && go version && go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS && uname -a && cat /proc/cpuinfo && cat /proc/meminfo && cat /proc/net/route && cat /proc/net/ipv6_route && cat /proc/net/dev && cat /sys/class/net/lo/mtu && cat /sys/fs/cgroup/cpu.max && cat /sys/fs/cgroup/memory.max'])
    (OUT / 'environment.txt.gz').write_bytes(gzip.compress(result.stdout, mtime=0))
    (OUT / 'environment.txt').write_text('\n'.join(line.rstrip() for line in result.stdout.decode().splitlines()).rstrip() + '\n')
    raise SystemExit(result.returncode)
smoke = '--smoke' in sys.argv
ledger = []
# Alternate order by repetition; each capture uses a fresh process/container.
cells = [(w, s, rep, False) for rep in range(1, 4) for w in ('relay', 'stream', 'datagram')
         for s in ((False, True) if rep % 2 else (True, False))]
cells += [(w, s, 1, True) for w in ('relay', 'stream', 'datagram') for s in (False, True)]
if smoke:
    cells = [(w, s, 0, False) for w in ('relay', 'stream', 'datagram') for s in (False, True)]
for work, selected, rep, profile in cells:
    name = f'{work}-{"selected" if selected else "baseline"}-{"profile" if profile else rep}'
    directory = (ROOT / '.cache/selected-io/smoke' if smoke else OUT) / name
    directory.mkdir(parents=True, exist_ok=False)
    args = base + ['-e', f'COST_WORKLOAD={work}', '-e', f'COST_SELECTED={int(selected)}',
        '-e', f'COST_PROFILE={int(profile)}', '-e', f'COST_SMOKE={int(smoke)}',
        '-e', 'COST_OUTPUT=/out', '-v', f'{directory}:/out', IMAGE,
        '/capture.test', '-test.run=^TestSelectedIOCostCapture$', '-test.v', '-test.timeout=30s']
    try:
        result = execute(args)
        code, output = result.returncode, result.stdout
    except subprocess.TimeoutExpired as exc:
        code, output = 124, (exc.stdout or b'') + b'\nExternal 45-second timeout\n'
    (directory / 'capture.log').write_bytes(output)
    ledger.append({'cell': name, 'exit_code': code, 'command': args})
    print(name, code, flush=True)
    (directory.parent / 'ledger.json').write_text(json.dumps(ledger, indent=2) + '\n')
if not smoke:
    metadata = {'production_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
                'aid_sha256': hashlib.sha256((OUT.parent / 'capture_test.go.txt').read_bytes()).hexdigest(),
                'image': IMAGE}
    (OUT / 'identity.json').write_text(json.dumps(metadata, indent=2) + '\n')
raise SystemExit(any(cell['exit_code'] != 0 for cell in ledger))
