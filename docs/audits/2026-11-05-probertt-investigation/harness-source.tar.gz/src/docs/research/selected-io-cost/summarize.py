#!/usr/bin/env python3
"""Render the retained finite capture results; no threshold or pass verdict."""
import json
from pathlib import Path
import statistics

raw = Path(__file__).resolve().parent / 'raw'
def spread(values):
    return f'{statistics.median(values):.3f} [{min(values):.3f}, {max(values):.3f}]'
print('| Workload | Selection | Delivered Mbit/s | CPU seconds | Allocated MiB | Million allocations | Establishment ms | Threads before→after |')
print('|---|---|---:|---:|---:|---:|---:|---|')
for workload in ('relay', 'stream', 'datagram'):
    for selection in ('baseline', 'selected'):
        results = [json.loads((raw / f'{workload}-{selection}-{rep}/result.json').read_text()) for rep in range(1, 4) if (raw / f'{workload}-{selection}-{rep}/result.json').exists()]
        if not results:
            print(f'| {workload} | {selection} | unavailable | | | | | |')
            continue
        size = 1000 if workload == 'datagram' else 32768
        rates = [d['measurement']['DeliveredInWindow'] * size * 8 / d['measurement']['SendSeconds'] / 1e6 for d in results]
        fields = [spread(rates), spread([d['cpu_seconds'] for d in results]), spread([d['allocated_bytes']/2**20 for d in results]), spread([d['allocations']/1e6 for d in results]), spread([d['establishment_seconds']*1000 for d in results])]
        threads = ', '.join(f"{d['before']['Threads']}→{d['after']['Threads']}" for d in results)
        print(f'| {workload} | {selection} | ' + ' | '.join(fields) + f' | {threads} |')
print('\n| Datagram cell | Scheduled | Attempted | Accepted | In window | Unique after drain | Missing accepted | Duplicates |')
print('|---|---:|---:|---:|---:|---:|---:|---:|')
for p in sorted(raw.glob('datagram-*/result.json')):
    m = json.loads(p.read_text())['measurement']
    print(f"| {p.parent.name} | {m['Scheduled']} | {m['Attempted']} | {m['Accepted']} | {m['DeliveredInWindow']} | {m['Unique']} | {m['Accepted']-m['Unique']} | {m['Duplicates']} |")
print('\n| Profile cell | Delivered Mbit/s | CPU seconds | Allocated MiB |')
print('|---|---:|---:|---:|')
for p in sorted(raw.glob('*-profile/result.json')):
    d=json.loads(p.read_text());m=d['measurement'];size=1000 if d['workload']=='datagram' else 32768
    print(f"| {p.parent.name} | {m['DeliveredInWindow']*size*8/m['SendSeconds']/1e6:.3f} | {d['cpu_seconds']:.3f} | {d['allocated_bytes']/2**20:.3f} |")
