# Linux native throughput certification

Slice [7.2](../adr/2026-10-19-native-certification-plan.md#slice-72--certify-the-linux-target), child [#1934](https://github.com/GridSwarm/wiremux/issues/1934), parent [#1915](https://github.com/GridSwarm/wiremux/issues/1915). Certified on 2026-10-25: both Linux floors are met. The protocol was committed and pushed before the first certification campaign. These dated measurements describe one shape cell and are not compatibility promises.

## Build and scope

**Source:** wiremux main `68da9417d02208906034cfa4f2f231b131b309ef`, with only `cmd/nativerig/` overlaid from published rig `ce78280d8e1ad52549ac4abf78b9f20124695c10` in a separate measurement worktree. The rig files are never part of this PR. `meta.txt` will therefore identify the measured product commit and a dirty tree; the retained staged diff identifies the rig-only overlay. Fork replacement: `github.com/the-sarge/quic-go-fast v0.62.1-fast.8`, matching the copied modfile of the native fork qualification lane and the [adoption record](quic-go-fast-v0.62.1-fast.8-native-adoption.md). Build toolchain: installed Go 1.27.3, cross-compiled on macOS arm64 to Linux amd64 with `CGO_ENABLED=0`, `-trimpath`, and `-modfile=cmd/nativerig/rig.mod`.

**Source:** both peers run on minimax, Ubuntu 26.04.1 LTS, Linux `7.0.0-30-generic` x86_64. The retained `netns` shape cell joins `nr-send` (`10.77.0.1/30`, `nr-s`) and `nr-recv` (`10.77.0.2/30`, `nr-r`) with a veth pair at MTU 1500. Sender `SCPUS=4-7` lies on CCD 0; receiver `RCPUS=12-15` lies on CCD 1. Both veth ends retain GRO off and GSO on; their complete offload state is recorded before every run. Neither namespace nor host configuration is changed. “These are estimates: a shape cell with no NIC.” minimax's 10 GbE card has no hardware UDP segmentation; real-NIC behavior is unmeasured.

The supported domain is this rig's per-run JSON results for the named arms, build, release and cell. `summarize.py` at the pinned rig commit owns parsing and headline statistics. The guarantee is example-level: one native Wire, sub-millisecond cell round trip, idle consumer under the published processor-headroom rule. Neither peer runs `-goload` or other in-process load. Each result retains its actual `gomaxprocs` and `num_cpu`. No compatibility promise, other-host estimate or loaded-consumer guarantee is added.

## Adopted stack

Both peers use the same product build and fork. Each Linux-relevant shipped lever is enabled through production code; no stand-in flag is supplied.

| Slice | Shipped behavior | Merged PR |
| --- | --- | --- |
| 1.1 | One Write per channel record | [#1950](https://github.com/GridSwarm/wiremux/pull/1950) |
| 1.2 | Promotion-time Datagram ceiling follows PMTU discovery | [#1952](https://github.com/GridSwarm/wiremux/pull/1952) |
| 1.3 | Native Datagram send through one queue and one copy | [#1954](https://github.com/GridSwarm/wiremux/pull/1954) |
| 2.1 | Binding allocation removal | [#1960](https://github.com/GridSwarm/wiremux/pull/1960) |
| 2.3 | Native Datagram receive without the second copy | [#1967](https://github.com/GridSwarm/wiremux/pull/1967) |
| 3.1 | Native readouts, including stream received packets/s | [#1944](https://github.com/GridSwarm/wiremux/pull/1944) |
| 3.4 | Received-Datagram queue discard readout | [#2006](https://github.com/GridSwarm/wiremux/pull/2006) |
| 5.1 / F1–F11 | Adopt fast.8, including deeper queues, copy-at-read, cap 32 and default-on equal-size Datagram gluing (F10) | [#1999](https://github.com/GridSwarm/wiremux/pull/1999) |
| 5.2 | Delegate admission when the fork offers it | [#2001](https://github.com/GridSwarm/wiremux/pull/2001) |
| 5.3 | Linux receive-coalescing grant | [#2010](https://github.com/GridSwarm/wiremux/pull/2010) |
| 6.1 | Native Reno acknowledgment threshold 16 | [#2016](https://github.com/GridSwarm/wiremux/pull/2016) |

Slices 2.2, 6.2–6.4 are macOS-only; 5.4 is the Windows receive grant. They are present in the product commit but do not add a Linux lever. Slice 3.3 is deferred. The [fast.8 evidence](quic-go-fast-v0.62.1-fast.8-native-adoption.md) owns the fork's release identity and F10's default-on disposition. Before the campaign, inspect both launch environments for `QUIC_GO_DISABLE_*`; none may be set. No `quic_go_no_private_syscalls` tag is supplied. Retain build-info and environment receipts alongside the results. Available native engagement and missing-readout fields are reported from both peers; absent counts are never read as zero.

## Protocol fixed before measurement

The verbatim Linux floor table is **source**, from the [accepted plan](../adr/2026-10-19-native-certification-plan.md#the-floors-source-verbatim):

| Floor (one native Wire, `netns` shape cell, idle consumer) | Gbit/s |
| --- | ---: |
| Datagrams at the pin | ≥ 10.0 at 1,397-byte Datagrams (about 895k Datagrams/s) |
| Stream | ≥ 10.5 |

The judged unit is delivered Gbit/s. Datagram packets/s come from the receiver; stream packets/s come from native `ConnectionStats.PacketsReceived`, not interface counters blurred by GSO/GRO. Report median, minimum and maximum in both units. The default-GC Datagram row is reported only, never judged. The standard stream keeps default GC.

From the measurement worktree, the exact campaign recipe is:

```sh
GOTOOLCHAIN=local REPS=5 SECS=10 WARMUP=1 NHOST=minimax SCPUS=4-7 RCPUS=12-15 PORT=49344 \
  GATE=/Volumes/worktrees/wiremux/native-gap-evidence/1934-linux-certification/gate.sh \
  cmd/nativerig/rig.sh netns /Volumes/worktrees/wiremux/native-gap-evidence/1934-linux-certification/headline-1 \
  'dgram=dgram -native-min-payload 1397 -size 1397' \
  stream=stream udp=udp 'udp4=udp -sockets 4' binding=binding \
  'dgrampin=dgram -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both'
```

`rig.sh` launches both peers through SSH to minimax, `sudo ip netns exec`, `sudo -u` the SSH user, and the specified `taskset` pins. The dedicated `PORT` avoids the shared default. Before every run, `GATE` records process and domain inventories and refuses to start if another `nativerig` or a running libvirt guest is present; the Linux and Windows campaigns cannot overlap. A busy host is waited for, never altered. No Docker or GARM mutation is permitted. No profiler or trace runs inside the headline campaign.

Both 1,397-byte Datagram arms pass the explicit minimum and size to both peers. Verify every sender's size, both promoted ceilings and both bytes/packets ratios. A smaller payload is a stop, never a floor miss. Fork kill switches, missing required readouts, an unexplained Wire closure or send error, or a cell setup mismatch also stop certification.

One headline campaign has five measured rotations plus a recorded warm-up rotation excluded from statistics, with rotating arm order. `summarize.py` reports the non-warm-up median and range; no individual run is dropped. It flags rates outside 0.8–1.2 times the arm median, either peer's starting load1 above 8, or failure. More than one-third of an arm's measured runs flagged makes the whole campaign noisy: retain it and repeat once in full, replacing it in the statistic. A repeated noisy campaign stops the slice.

If either floor misses, run one further headline campaign with identical arms and gates, under `headline-2`, and pool both campaigns' non-warm-up runs with the pinned summarizer. A noisy repeat is separate from the miss campaign. A pooled miss files a diagnosis issue and reverts nothing. For a pooled Datagram miss, report whether sender process CPU is at least 3.8 of the four pinned processors in the median run, calculated as user plus system CPU seconds over offer duration (**derived**); if so, name the dropped ownership APIs' [reopen trigger](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084). This certification adopts or tunes nothing.

Evidence terminates when both floor rows have met/missed verdicts and the default-GC row has a figure, checked against pasted `meta.txt`, `summary.txt` and retained raw results. At most one smoke is allowed but none is planned. No A/B, 1,099-byte arm, mixed arm, busy-consumer measurement, fork-lane test run or additional stress campaign is included. Review is one fully briefed initial review plus at most one replacement. Contract closure is not triggered.

Consumer-facing Status and table cells are shipped documentation; this record and any diagnosis issue are process metadata. The existing rig, raw runs and evidence directory are verification aids, not new maintained deliverables. Only this record, Linux's Status line and row, slice 7.2's completion state, and the program's Track 7 row/current frontier may change in the PR.

## Campaign results

**Measured:** one headline campaign, started 2026-10-25 at 16:56:07 UTC, with all 36 run pairs (one warm-up and five measured rotations of six arms). All six arms have zero flagged runs; there are no error results, failed sends, nonempty error logs, missing native snapshots, foreign rigs or running guests. Both floors meet their thresholds, so no miss campaign, noisy repeat or diagnosis issue is needed. No smoke was run. The published protocol commit [`84c2e9eb33b84d795c87536087614214c73d6d70`](https://github.com/GridSwarm/wiremux/commit/84c2e9eb33b84d795c87536087614214c73d6d70), committed at 16:55:39 UTC and pushed before opening this campaign, precedes `meta.txt`'s campaign date.

| Workload | Delivered Gbit/s, median (min–max), measured | Packets/s, median (min–max), measured | Floor, source | Verdict |
| --- | ---: | ---: | --- | --- |
| Datagrams at the pin, 1,397 bytes | 15.516667 (15.443908–15.705874) | 1,388,392 (1,381,882–1,405,322) | ≥ 10.0 Gbit/s | Met |
| Stream, default GC | 11.848071 (11.741158–11.879298) | 1,062,150 (1,052,575–1,064,938) | ≥ 10.5 Gbit/s | Met |
| Datagrams at default GC, 1,397 bytes | 9.926229 (9.917265–9.947936) | 888,174 (887,372–890,116) | Reported only | Reported, never judged |

**Measured:** all 12 Datagram run pairs, including warm-ups and default GC, have sender `size=1397`, both peers' promoted `max_payload=1397`, and exactly 1,397 bytes per application packet on both peers. All 72 peer results report `gomaxprocs=4` and `num_cpu=4`. Both peers' ballast is 64 MiB in `dgrampin` and absent/zero in default-GC `dgram`; no in-process load or per-arm environment override was supplied. `local-kill-switches.txt` and `remote-kill-switches.txt` are empty. The retained Linux binary's build settings contain no build tags and identify Go 1.27.3, Linux amd64, `CGO_ENABLED=0` and fast.8. Its SHA-256 is `c2928b106eca427ea56f594f3c22469b7b03ffca099f8091718fed8632bdf591`.

**Measured:** native packet readouts are present and positive on every native peer, with zero connect failures. Linux's send/receive batch counters are zero with fallback reason 6 (compiled out): these fields describe the Darwin list paths and are not evidence of a disengaged Linux lever. Linux receive-coalescing fallbacks are zero. Default-on gluing, delegated admission, the Linux coalescing grant and ACK16 use the pinned production owners; no alternative switch is supplied. The stats readout has no recorder RTT samples or PTO counts, which remain absent rather than zero. The pasted summary reports received-Datagram and unprocessed-queue drops; these are observations, not additional certification gates. No sender-CPU reopen assessment is triggered because the Datagram floor met.

The summary's ordinary stream `pkt/s` column is zero because the stream application counts bytes. Its native-readout `r pkt/s` column supplies the stream packet rate above. Ranges for that native rate are taken from the same five non-warm-up receiver readouts. GSO/GRO can make interface-based wire/stack loss columns meaningless; the native and application counters retain their protocol meanings.

Durable `OUTDIR`: `/Volumes/worktrees/wiremux/native-gap-evidence/1934-linux-certification/headline-1/`. It retains binaries, metadata, summary text/JSON, every raw peer result, error file, per-run gate, load, UDP/interface snapshot and per-run offload state. The evidence root also retains `rig-overlay.diff`, the source-equivalence checks, toolchain/environment/build-info receipts, binary hashes, `campaign-check.txt`, and `cleanup-host.txt`. The overlay equals rig `ce78280d` exactly; outside it the measured tree equals product main `68da9417` exactly. The rig removed its owned remote `/tmp/nativerig-80577` directory; the existing namespaces remain, with no running `nativerig` or guest left by the campaign. No Docker, guest, GARM, namespace, offload or other host-configuration mutation occurred. No untraced host effect is accepted.

### Campaign metadata (source receipt)

```text
date: 2026-10-25T16:56:07Z
cell: netns reps: 5 secs: 10 warmup: 1
rig: 68da9417d02208906034cfa4f2f231b131b309ef dirty=45
go: go version go1.27.3 darwin/arm64
modfile: cmd/nativerig/rig.mod
quic-go: replace github.com/quic-go/quic-go => github.com/the-sarge/quic-go-fast v0.62.1-fast.8
arms:
  dgram=dgram -native-min-payload 1397 -size 1397
  stream=stream
  udp=udp
  udp4=udp -sockets 4
  binding=binding
  dgrampin=dgram -native-min-payload 1397 -size 1397 -ballast 64 -gc-role both
quiet load before the first run: sender { 2.86 3.70 4.30 }
sender: Darwin mbp128.local 27.0.0 Darwin Kernel Version 27.0.0: Tue Aug 11 21:05:48 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T6041 arm64
sender sysctl: 8388608 786896 9216
netns host: Linux minimax 7.0.0-30-generic #30-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 18:22:54 UTC 2026 x86_64 GNU/Linux
netns quiet load before the first run: 0.10 0.11 0.13 1/561 4141644
netns pinning: sender taskset -c 4-7, receiver taskset -c 12-15
netns sysctl: 4194304 4194304 212992
netns cpu map:
  CPU CORE L1d:L1i:L2:L3
    0    0 0:0:0:0
    1    1 1:1:1:0
    2    2 2:2:2:0
    3    3 3:3:3:0
    4    4 4:4:4:0
    5    5 5:5:5:0
    6    6 6:6:6:0
    7    7 7:7:7:0
    8    8 8:8:8:1
    9    9 9:9:9:1
   10   10 10:10:10:1
   11   11 11:11:11:1
   12   12 12:12:12:1
   13   13 13:13:13:1
   14   14 14:14:14:1
   15   15 15:15:15:1
   16    0 0:0:0:0
   17    1 1:1:1:0
   18    2 2:2:2:0
   19    3 3:3:3:0
   20    4 4:4:4:0
   21    5 5:5:5:0
   22    6 6:6:6:0
   23    7 7:7:7:0
   24    8 8:8:8:1
   25    9 9:9:9:1
   26   10 10:10:10:1
   27   11 11:11:11:1
   28   12 12:12:12:1
   29   13 13:13:13:1
   30   14 14:14:14:1
   31   15 15:15:15:1
netns offloads at start (nr-s | nr-r):
  generic-segmentation-offload: on
  generic-receive-offload: off
  tx-udp-segmentation: on
  rx-gro-list: off
  rx-udp-gro-forwarding: off
  generic-segmentation-offload: on
  generic-receive-offload: off
  tx-udp-segmentation: on
  rx-gro-list: off
  rx-udp-gro-forwarding: off
```

### Campaign summary (measured)

```text
medians over non-warm-up runs; cpu/GiB is CPU seconds per delivered GiB; lost packets per run: wire = sender if out - receiver if in, stack = receiver if in - UDP in, rcvbuf = full socket buffer
arm             n Mbit/s med    min    max  pkt/s med    loss cpu/GiB s      r     wire    stack   rcvbuf
binding         5       6050   6012   6063     520819   0.08%      2.09   1.73        0     4352     4352
dgram           5       9926   9917   9948     888174   0.00%      1.61   1.21        0        1        0
dgrampin        5      15517  15444  15706    1388392   0.01%      1.28   1.09        0        1        0
stream          5      11848  11741  11879          0       -      1.13   1.04        0        2        0
udp             5       6679   6627   6697     574951   0.00%      1.30   1.01        0        0        0
udp4            5      25610  25536  25712    2204704   0.02%      1.29   0.93        0     3855     3854

extras (medians): sender member-queue drops; lost after the sender's member queue (member dequeued - receiver if in); receiver 16 KB cluster refill failures; receiver if in frames/s and bytes/frame; GC cycles/s per peer; -qdepth queued datagrams before each read (median, mean, share empty)
arm             q drop  after q  16k fail   in fr/s  B/frame  gc/s s  gc/s r             qdepth
binding              -        -         -         -        -     7.7   524.8                  -
dgram                -        -         -         -        -  1130.9   618.2                  -
dgrampin             -        -         -         -        -    63.7    32.8                  -
stream               -        -         -         -        -    19.7     8.5                  -
udp                  -        -         -         -        -     0.0     0.0                  -
udp4                 -        -         -         -        -     0.0     0.0                  -

sender CPU per offered packet (medians, min-max): user and system microseconds; share of each on performance cores
arm                       user us             sys us  user P   sys P
binding          0.68 (0.66-0.68)   2.16 (2.14-2.16)       -       -
dgram            1.63 (1.62-1.64)   0.47 (0.45-0.48)       -       -
dgrampin         1.36 (1.34-1.37)   0.31 (0.30-0.32)       -       -
udp              0.16 (0.15-0.17)   1.60 (1.58-1.61)       -       -
udp4             0.16 (0.15-0.16)   1.59 (1.58-1.59)       -       -

receiver per delivered datagram (medians; min-max for total CPU): receive call; CPU-s per delivered GiB, total, user, system; user and system microseconds per datagram; system share on performance cores; cycles per datagram; receive system calls per datagram (read and recvmsg: 1, a floor, as parked calls are not visible); recvmsg_x datagrams per delivering call (mean, median), share of calls that filled every slot, parked calls per delivering call
arm                   call         cpu/GiB r  user   sys user us sys us sys P  cyc/dg calls/dg      fill  full park/dc
udp                   read  1.01 (1.01-1.02)  0.19  0.82    0.26   1.12     -       -        1         -     -       -
udp4                  read  0.93 (0.92-0.93)  0.27  0.66    0.36   0.89     -       -        1         -     -       -

native readouts (medians; slice 3.1's seam): readouts mode; sender min, smoothed (at the end) and mean RTT over the send window (us); PTOs and spurious losses over the sender's window (recorder only); receiver packets received/s (ConnectionStats.PacketsReceived); receiver Datagram discards and unprocessed-queue drops at the end; runs with a missing snapshot. absent = no fork method, no recorder, or no snapshot
arm                mode  minRTT    sRTT  meanRTT   PTO  spur   r pkt/s  dg drop   unproc miss  env
dgram             stats      20     119   absent absent absent    888371        0   absent    0  -
dgrampin          stats      25     130   absent absent absent   1388678        0   absent    0  -
stream            stats      28      71   absent absent absent   1062150        0   absent    0  -

native extra counts (medians of each peer's total at its final snapshot; counts a scratch build adds to 3.1's Readout)
binding        recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
dgram          recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 137; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
dgrampin       recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 957; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
stream         recv connect_failures 0; recv receive_batch_calls 0; recv receive_batch_control_truncated 0; recv receive_batch_datagrams 0; recv receive_batch_fallback_reason 6; recv receive_batch_icmp_absorbed 0; recv receive_batch_truncated 0; recv receive_coalescing_fallbacks 0; recv send_batch_calls 0; recv send_batch_datagrams 0; recv send_batch_fallback_reason 6; recv send_batch_icmp_drops 0; recv unprocessed_packet_drops 239; send connect_failures 0; send receive_batch_calls 0; send receive_batch_control_truncated 0; send receive_batch_datagrams 0; send receive_batch_fallback_reason 6; send receive_batch_icmp_absorbed 0; send receive_batch_truncated 0; send receive_coalescing_fallbacks 0; send send_batch_calls 0; send send_batch_datagrams 0; send send_batch_fallback_reason 6; send send_batch_icmp_drops 0; send unprocessed_packet_drops 0
udp            recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
udp4           recv connect_failures absent; recv receive_batch_calls absent; recv receive_batch_control_truncated absent; recv receive_batch_datagrams absent; recv receive_batch_fallback_reason absent; recv receive_batch_icmp_absorbed absent; recv receive_batch_truncated absent; recv receive_coalescing_fallbacks absent; recv send_batch_calls absent; recv send_batch_datagrams absent; recv send_batch_fallback_reason absent; recv send_batch_icmp_drops absent; recv unprocessed_packet_drops absent; send connect_failures absent; send receive_batch_calls absent; send receive_batch_control_truncated absent; send receive_batch_datagrams absent; send receive_batch_fallback_reason absent; send receive_batch_icmp_absorbed absent; send receive_batch_truncated absent; send receive_coalescing_fallbacks absent; send send_batch_calls absent; send send_batch_datagrams absent; send send_batch_fallback_reason absent; send send_batch_icmp_drops absent; send unprocessed_packet_drops absent
```
