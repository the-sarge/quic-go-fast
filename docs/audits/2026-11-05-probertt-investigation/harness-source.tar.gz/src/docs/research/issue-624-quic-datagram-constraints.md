# QUIC Datagram constraints for issue 624

Research note for [Establish QUIC Datagram constraints for the wiremux capability](https://github.com/GridSwarm/wiremux/issues/709), a Wayfinder ticket under [Datagram track: unreliable-unordered message primitive on the transport contract](https://github.com/GridSwarm/wiremux/issues/624).

> **Status:** This is the pre-implementation research record. See the
> [issue 624 QUIC Datagram conformance record](issue-624-quic-datagram-conformance.md)
> for the implemented behavior and current executable evidence.

## Sources and version boundary

This note uses only the following primary evidence:

- [RFC 9221](https://www.rfc-editor.org/rfc/rfc9221.html), the QUIC DATAGRAM specification.
- `quic-go` **v0.60.0**, which was the exact version pinned by wiremux's [`go.mod`](../../go.mod) when this pre-implementation record was written. The current dependency pin and re-attestation are maintained in the [QUIC Datagram conformance record](issue-624-quic-datagram-conformance.md); links below preserve this historical immutable source snapshot rather than following `main`.
- wiremux's pre-implementation transport contracts, QUIC adapter, and tests.

The queue sizes, copying behavior, conservative payload calculation, and close details below are implementation facts about `quic-go` v0.60.0. They are not promises made by RFC 9221 and must be re-audited when that dependency changes.

## Executive constraints

1. **The capability is bidirectional only when both directional advertisements are present.** RFC 9221's transport parameter is a unidirectional receive limit. In quic-go, `ConnectionState().SupportsDatagrams.Local` and `.Remote` must both be true, but those booleans are only necessary: the accepted design also requires the numeric-floor `/2` application profile and wiremux's pairwise exposure agreement. The selected transport name `"quic"` alone is insufficient.
2. **The strict no-retransmission property is real.** A lost DATAGRAM frame is not retransmitted. It is still ack-eliciting, consumes the same connection congestion window as streams, and can cause QUIC loss probes, but those probes do not replay its application bytes.
3. **The native limit is dynamic; wiremux publishes one lifetime-fixed atomic ceiling after its overhead.** One call maps to one non-fragmentable DATAGRAM frame. The native send-time maximum is the smaller of the peer's advertised frame limit and quic-go's current path-size estimate. quic-go exposes no numeric peer-limit query, so the accepted `wiremux-quic/2` ALPN profile requires both endpoints to advertise enough for the frozen 1240-byte lower frame-fit value; a smaller-limit endpoint must select stream-only `/1`. The public value subtracts the wiremux envelope and never shrinks; if the native carrier explicitly stops upholding the frozen admission ceiling, the aggregate Wire terminates.
4. **Replace `~1200 B` with an exact complete-record budget; do not equate that budget with GridCast's raw symbol size.** With v0.60.0, the minimum permitted `InitialPacketSize` of 1200 gives a conservative 1160-byte length-bearing DATAGRAM Data ceiling, while wiremux's current 1280 default gives 1240. After the one-byte wiremux envelope, public ceilings are 1159 and 1239. A 1024-byte symbol leaves 135 or 215 bytes for GridCast metadata. A 1152-byte symbol leaves only 7 bytes at the protocol-minimum configuration, or 87 under wiremux's current default, so its fit is conditional on the aggregate record overhead. A literal 1200-byte consumer payload does not fit the minimum configuration.
5. **A successful send means queued, not transmitted or delivered.** v0.60.0 copies the caller's bytes and enqueues at most 32 frames. The 33rd call blocks, has no context parameter, and wakes only when a frame is dequeued or the connection closes.
6. **Receive should have exactly one consumer.** Receive is context-cancellable and inbound datagrams are copied, queued FIFO by arrival, and returned as caller-owned slices. The v0.60.0 implementation is mutex-protected, but its one-slot coalesced wake-up channel can leave one of multiple simultaneous receivers blocked while another datagram is already queued. Wiremux must serialize receive or explicitly implement its own dispatcher.
7. **Congestion and overload are loss sites, not errors reliably reported to the sender.** QUIC congestion control can delay queued DATAGRAM frames. quic-go silently drops a queued frame if it no longer fits the available packet, and silently drops newly received frames when its 128-entry receive queue is full.
8. **The stream and datagram surfaces must share one aggregate owner.** The current returned stream owns the QUIC connection, quic-go transport, and punched packet socket. Closing that stream closes the parent connection and therefore ends datagram I/O too. A datagram handle cannot safely be bolted on as an independently owned resource.

## 1. Capability negotiation

RFC 9221 advertises receive support with the `max_datagram_frame_size` QUIC transport parameter. Zero or absence means unsupported; a positive value is the maximum complete DATAGRAM **frame** the endpoint is willing to receive. An endpoint must not send before receiving a positive value and must not exceed it. The parameter is explicitly unidirectional, and the application protocol must define what absence means ([RFC 9221 §3](https://www.rfc-editor.org/rfc/rfc9221.html#section-3)).

quic-go v0.60.0 exposes the two directions separately:

- `Config.EnableDatagrams` opts the local endpoint into receiving datagrams ([`interface.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/interface.go#L160-L175)).
- `ConnectionState().SupportsDatagrams.Local` records that local opt-in; `.Remote` records the peer's advertisement ([`interface.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/interface.go#L188-L204), [`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L769-L787)).
- `SendDatagram` rejects when the peer did not advertise support, while `ReceiveDatagram` rejects when local support was not enabled ([`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L3020-L3052)).

The upstream four-way negotiation test confirms that the two flags are independent and that sending in one direction depends on the receiver's setting ([`integrationtests/self/datagram_test.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/integrationtests/self/datagram_test.go#L24-L89)).

The state flags reveal only zero-versus-positive support, not the peer's
numeric `max_datagram_frame_size`. Therefore a fixed ceiling cannot safely be
derived from the booleans alone for heterogeneous peers. The accepted design
uses a versioned QUIC application profile: an endpoint offers
`wiremux-quic/2` only when its `max_datagram_frame_size` is at least 1243 and
therefore admits 1240 lower Data bytes, while legacy `wiremux-quic/1` remains
stream-only. ALPN selection then supplies the missing minimum-limit commitment
before carrier exposure.

At the time of this pre-implementation audit, wiremux did not enable either
side: `clientQuicConfig` and `serverQuicConfig` omitted `EnableDatagrams`, whose
zero value is false. The implementation now enables both configurations and is
tracked in the current [conformance record](issue-624-quic-datagram-conformance.md).
The conclusions at the research boundary were:

- selecting the transport named `quic` did not by itself imply DATAGRAM support;
- bidirectional availability would require local and remote support, not just a peer bit;
- the capability decision could only be final after the QUIC handshake exposed both state bits;
- if datagrams become required rather than optional for some future negotiated mode, that mode must fail or downgrade explicitly when either direction is absent, as RFC 9221 requires the application protocol to define.

## 2. Strict unreliability and atomicity

RFC 9221 defines DATAGRAM frames as application data carried without required retransmission ([§1](https://www.rfc-editor.org/rfc/rfc9221.html#section-1)). More precisely, they are ack-eliciting but are not retransmitted after loss detection. QUIC can still send probe packets to elicit an ACK; acknowledgements only prove transport processing, not that the receiving application processed the data ([§5.2](https://www.rfc-editor.org/rfc/rfc9221.html#section-5.2)). This satisfies issue 624's strict QUIC transport-level property: wiremux and QUIC do not repair or replay the original application message. It does not claim that every underlying link technology is free of its own local recovery. A literal “no retransmission at any underlying layer” promise is impossible for wiremux to verify or enforce because opaque Wi-Fi, cellular, and other link layers can perform their own ARQ or FEC; the enforceable contract boundary is every layer selected or controlled by wiremux and its transport adapter.

DATAGRAM frames cannot be fragmented. Their usable size is bounded by the peer's `max_datagram_frame_size`, the peer's `max_udp_payload_size`, and the path MTU ([RFC 9221 §5](https://www.rfc-editor.org/rfc/rfc9221.html#section-5)). quic-go repeats the contract directly on `SendDatagram`: no delivery guarantee, no retransmission, and one QUIC-packet fit required ([`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L3020-L3026)). Its loss integration test drops short-header packets and observes exactly the corresponding missing datagrams, with no later recovery ([`integrationtests/self/datagram_test.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/integrationtests/self/datagram_test.go#L229-L341)).

Thus one accepted wiremux send must represent one atomic message: delivered whole once, or not delivered. It must not split a large consumer message across DATAGRAM frames. Ordering must also remain unspecified: quic-go's receive queue happens to return frames in processing order, but neither RFC 9221 nor the public API gives the application a sequence or ordering guarantee.

## 3. Maximum atomic application payload

### The governing value is a payload value, not “the MTU”

RFC 9221's advertised number covers the frame type, optional length, and data—not merely application data—and the final limit can be smaller than that advertisement because the whole frame must fit one QUIC packet ([§3](https://www.rfc-editor.org/rfc/rfc9221.html#section-3), [§4](https://www.rfc-editor.org/rfc/rfc9221.html#section-4), [§5](https://www.rfc-editor.org/rfc/rfc9221.html#section-5)). Application-level flow or type prefixes are the application's responsibility and occupy bytes in the Datagram Data field ([§5.1](https://www.rfc-editor.org/rfc/rfc9221.html#section-5.1)). A wiremux capability must consequently state the maximum **consumer payload after wiremux framing**, not advertise a UDP or QUIC packet size.

quic-go has no public “current maximum” query. `SendDatagram` calculates a
conservative short-header packet-payload estimate at each call and returns
`*DatagramTooLargeError{MaxDatagramPayloadSize: ...}` only when the supplied
Data bytes exceed it
([`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L3026-L3044),
[`errors.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/errors.go#L95-L105)).
That comparison does not subtract the length-bearing DATAGRAM frame's type and
length encoding from the packet-payload estimate. The packer compares the full
frame length later and may silently discard a frame that `SendDatagram`
accepted but cannot fit
([`internal/wire/datagram_frame.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/internal/wire/datagram_frame.go#L44-L81),
[`packet_packer.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/packet_packer.go#L650-L668)).
Its integration tests use the reported field as a sendable value and show it
increasing after path-MTU discovery
([`integrationtests/self/datagram_test.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/integrationtests/self/datagram_test.go#L91-L226)),
but a stable wiremux ceiling must additionally reserve frame encoding so its
maximum is repeatedly deliverable on a lossless baseline path.

### Reconciliation of `~1200 B` with GridCast's `1024–1152 B`

GridCast's original consumer record asks for “payload ≥ ~1200 B per message” because one coded symbol must fit one loss-atomic unit ([ADR-0007 DP2](../adr/adr-0007-gridcast-consumer.md#dp2-requested-track--an-unreliable-unordered-message-primitive)). Issue 709 sharpens the actual symbol budget to 1024–1152 bytes.

For the exact pinned implementation:

- quic-go v0.60.0 permits `InitialPacketSize` no lower than 1200 and defaults it to 1280 ([public config](https://github.com/quic-go/quic-go/blob/v0.60.0/interface.go#L160-L168), [`config.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/config.go#L39-L47), [`internal/protocol/params.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/internal/protocol/params.go#L9-L13)).
- Its conservative short-header payload estimate subtracts 1 byte for the short-header first/type byte, 20 for the maximum connection ID, and 16 for the AEAD tag ([`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L3144-L3151)).
- `SendDatagram` limits Data bytes to the smaller of that estimate and the peer-advertised frame capacity. Both wiremux peers would advertise quic-go's large 16,383-byte frame ceiling when enabled, so the path estimate governs its public check ([`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L3026-L3044), [`internal/wire/datagram_frame.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/internal/wire/datagram_frame.go#L10-L15)).
- quic-go always constructs a length-bearing frame. At these sizes the frame adds one type byte and a two-byte QUIC varint length, so a Data field needs three bytes of the packet-payload budget ([`internal/wire/datagram_frame.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/internal/wire/datagram_frame.go#L44-L81)).

This yields the following initial send-time figures before any beneficial path-MTU discovery:

| Configuration | quic-go packet-payload estimate | Length-bearing DATAGRAM Data that fits | Public bytes after wiremux envelope | Headroom after 1024 B | Headroom after 1152 B |
| --- | ---: | ---: | ---: | ---: | ---: |
| Minimum allowed `InitialPacketSize = 1200` | `1200 - 1 - 20 - 16 = 1163 B` | `1163 - 1 - 2 = 1160 B` | 1159 B | 135 B | 7 B |
| wiremux current default (`InitialPacketSize = 1280`) | `1280 - 1 - 20 - 16 = 1243 B` | `1243 - 1 - 2 = 1240 B` | 1239 B | 215 B | 87 B |

The public figures are conservative frame-fit admission ceilings, not delivery
guarantees: an accepted frame can still be lost in the packer or network. They
apply after the complete DATAGRAM frame encoding and the wiremux envelope, so
the remaining headroom is available only for GridCast's block/ESI or other
record metadata. A 1152-byte symbol is viable under wiremux's current default
only if all GridCast metadata is at most 87 bytes, and at the protocol-minimum
configuration only if it is at most 7 bytes. The local sources do not establish
that overhead, so an unconditional “1152-byte symbols fit” conclusion would be
unsupported.

The result is intentionally narrower than “QUIC guarantees 1200-byte
payloads.” It does not. `~1200 B` remains useful motivation shorthand, but the
design must choose and advertise an exact **complete consumer-record** floor,
then GridCast must select a symbol size whose record fits it. A literal
1200-byte consumer message exceeds the 1159-byte public frame-fit ceiling in
the minimum configuration.

## 4. Send and receive behavior

### Send

`SendDatagram` copies the caller's slice into a new frame before enqueueing it, so the caller may reuse or mutate its buffer after the method returns ([`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L3026-L3044)). This is a pinned-source implementation fact, not an explicit public API promise; wiremux would need its own copy to make caller ownership independent of quic-go upgrades. The v0.60.0 queue:

- is mutex-protected, so simultaneous calls do not race internally;
- preserves queue order after calls acquire the mutex, but simultaneous callers have no defined relative order;
- holds 32 frames;
- blocks the next call once full until a frame is removed or the connection closes ([`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue.go#L12-L70)).

There is no context or deadline argument on `SendDatagram`. Closing the connection is the only upstream mechanism that unblocks a send waiting on the full internal queue. A nil return means the copied frame entered the queue; it does not mean the frame reached the socket or peer.

### Receive

`ReceiveDatagram(ctx)` blocks until a frame arrives, the connection closes, or `ctx` ends. The v0.60.0 receive path copies frame data before queueing it, so the returned slice is detached from the packet parser's storage and can be treated as caller-owned ([`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue.go#L92-L132)). As on send, this is an implementation fact; a durable wiremux ownership promise should make its own copy. Cancellation returns `ctx.Err()` and does not close the connection; the upstream test pins that behavior ([`datagram_queue_test.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue_test.go#L89-L146)).

The implementation's mutex prevents data races between receivers, but concurrent receives should not become a wiremux promise. Notifications use a channel of capacity one. Multiple arrivals can coalesce into one wake-up; with multiple goroutines already waiting, one can consume a frame and return while another remains asleep even though another frame is in the queue ([`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue.go#L34-L45), [`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue.go#L92-L132)). A single receive loop followed by wiremux- or consumer-level dispatch is the safe v0.60.0 shape.

## 5. Congestion control, blocking, and dropping

RFC 9221 requires DATAGRAM frames to use the QUIC connection's congestion controller. When congestion disallows sending, the implementation must either delay or drop the frame; pacing may also delay it ([§5.4](https://www.rfc-editor.org/rfc/rfc9221.html#section-5.4)). This is the required “sharing the connection's congestion control” property: reliable stream bytes and unreliable datagram bytes compete under the same QUIC connection authority ([RFC 9221 §2](https://www.rfc-editor.org/rfc/rfc9221.html#section-2)).

quic-go v0.60.0 chooses bounded delay at its application queue boundary: up to 32 frames wait, then the producer blocks. When packing, it sends the head datagram if it fits; if it does not fit and the packet has no ACK, quic-go removes it because retrying is unlikely to help. There is no application notification for that drop ([`packet_packer.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/packet_packer.go#L650-L668)).

There is no RFC DATAGRAM flow-control credit. A receiver may drop when it lacks resources ([RFC 9221 §5.3](https://www.rfc-editor.org/rfc/rfc9221.html#section-5.3)). quic-go implements a 128-frame receive queue and silently discards new frames once it is full ([`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue.go#L12-L14), [`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue.go#L92-L110)).

Consequences for the wiremux contract:

- loss can occur on the network, before socket transmission after a successful send call, or at the receiver queue;
- no public callback distinguishes those loss sites;
- backpressure is possible on send despite unreliable delivery;
- an API that promises context-cancellable send, nonblocking send, drop-newest, or drop-oldest cannot be a thin forwarding call to v0.60.0 `SendDatagram`; it needs a wiremux-owned queue/policy or a deliberately narrower promise.

## 6. Cancellation and close behavior

At the quic-go layer:

- `ReceiveDatagram(ctx)` has per-call cancellation.
- `SendDatagram` has no per-call cancellation. A call blocked on the full queue is released by connection close and returns the connection's close error ([`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue.go#L47-L70), [`datagram_queue_test.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue_test.go#L148-L180)).
- Connection shutdown closes the datagram queue with the connection error, unblocking empty-queue receivers and full-queue senders ([`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L2240-L2260)). `Receive` checks already-buffered data before observing close, so buffered inbound datagrams can be drained first; unsent outbound frames have no flush or delivery guarantee.
- `Conn.Context()` is cancelled with the close cause, and `CloseWithError` waits for that connection context to finish ([`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L760-L768), [`connection.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/connection.go#L2170-L2185)).

One private v0.60.0 edge makes a wiremux-side closed-state gate necessary if the public contract promises deterministic post-close failure: `datagramQueue.Add` checks the closed channel only while waiting for a full queue, so a post-close call can still enqueue into a non-full queue even though nothing will transmit it ([`datagram_queue.go`](https://github.com/quic-go/quic-go/blob/v0.60.0/datagram_queue.go#L47-L70)). The design should not delegate its post-close result identity to this implementation detail.

At the current wiremux layer, the returned `streamConn` is the aggregate lifetime owner. Its embedded adapter closes the QUIC stream first, then after a 500 ms grace closes the QUIC connection, `quicgo.Transport`, and punched `net.PacketConn`; connection termination also triggers transport and packet-socket cleanup ([`transport/quic/transport.go`](../../transport/quic/transport.go), [`transport/internal/adapter/stream_conn.go`](../../transport/internal/adapter/stream_conn.go)). The transport contract says that ownership of the punched socket transfers to the returned connection on successful dial or accept, and `Session.Close` does not close active connections ([`connect.Session`](../../connect/contracts.go)). Existing tests pin eventual packet-socket release after stream close and cleanup when the parent connection ends ([`transport/quic/transport_test.go`](../../transport/quic/transport_test.go), [`transport/internal/adapter/stream_conn_test.go`](../../transport/internal/adapter/stream_conn_test.go)).

A future stream-plus-datagram result therefore needs one close authority over all four resources: stream, QUIC connection, quic-go transport, and punched packet socket. Two independent handles that each believe they own the connection would race or terminate the other unexpectedly. Conversely, retaining today's rule that closing the stream closes the parent means callers must understand that datagram receive and blocked send end with it. DATAGRAM itself has no graceful half-close or flush operation comparable to a stream FIN.

## 7. Testability constraints

The behavior can be tested at three seams, but not all with the same machinery:

1. **Configuration and capability tests.** `clientQuicConfig` and `serverQuicConfig` are package-local constructors already tested for protocol shape ([`transport/quic/transport_test.go`](../../transport/quic/transport_test.go#L130)). They can pin local opt-in, `/2` preference, and `/1` fallback. A real dial/listen pair must pin the four local/remote state combinations and prove that a smaller-positive-limit peer cannot select `/2`; upstream's negotiation matrix is the primary precedent.
2. **Lifecycle unit tests.** The existing `transport/internal/adapter.StreamConn` depends on small `Stream` and `Connection` interfaces and uses fakes to deterministically test grace, abort, close, and packet ownership ([`stream_conn.go`](../../transport/internal/adapter/stream_conn.go#L17), [`stream_conn_test.go`](../../transport/internal/adapter/stream_conn_test.go#L13)). quic-go exposes datagram methods only on concrete `*quic.Conn`, so deterministic tests of send blocking, cancellation, and close propagation require a similarly small wiremux-owned datagram/connection interface rather than construction hard-wired to the concrete type.
3. **Real-QUIC integration tests.** wiremux already establishes actual QUIC peers over caller-supplied UDP sockets and validates bidirectional stream traffic and socket cleanup ([`internal/integration/quic_session_test.go`](../../internal/integration/quic_session_test.go), [`transport/quic/transport_test.go`](../../transport/quic/transport_test.go#L300)). The same harness can prove simultaneous stream/datagram use, atomic delivery at the exact complete-record floor the design chooses, oversize classification, context cancellation, and aggregate close. Loss/no-retransmission tests need a controlled packet-dropping `net.PacketConn`; quic-go's own deterministic loss test uses its internal simulated network, which wiremux cannot import because Go's `internal` boundary excludes downstream modules ([upstream loss test](https://github.com/quic-go/quic-go/blob/v0.60.0/integrationtests/self/datagram_test.go#L229-L341)).

Queue saturation, receiver overflow, and the concurrent-receiver notification edge are private quic-go implementation details. wiremux should test only the public behavior it chooses to expose and keep this source audit as the dependency-version canary; duplicating upstream private constants into the public wiremux contract would make an otherwise compatible quic-go update breaking.

## Design facts to carry forward

- Negotiate an **exact, bidirectional, consumer-payload capability**; do not infer it from `Transport.Name()`.
- Use a minimum-limit application profile when the transport API exposes only
  support booleans: `/2` commits both QUIC peers to the 1240-byte lower floor,
  and a smaller-limit or legacy peer selects stream-only `/1`.
- Specify an exact complete consumer-record floor. A 1024-byte GridCast symbol has portable headroom in the audited configurations; a 1152-byte symbol remains conditional on GridCast metadata fitting the 7-byte minimum-config or 87-byte current-default public margin.
- Preserve “not retransmitted” without promising “never delayed,” “send never blocks,” or sender-visible drop reports.
- Make receive single-consumer unless wiremux owns a dispatcher.
- Put a bounded copy-on-admission queue and one lifecycle-owned worker in the
  QUIC adapter so the accepted lower contract can cancel before admission;
  v0.60.0 does not supply context cancellation for its native send.
- Return one aggregate connection owner whose close ends stream and datagram activity and releases the punched socket exactly once.
- Pin public contract tests at the wiremux seam and retain real-QUIC integration coverage for negotiation, delivery at the chosen payload floor, simultaneous stream use, loss, and close.
