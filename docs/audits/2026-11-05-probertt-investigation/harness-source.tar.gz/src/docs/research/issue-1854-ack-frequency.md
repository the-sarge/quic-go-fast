# Issue #1854: what fewer acknowledgments buy the native path on macOS

Research for [How much native send cost and throughput would fewer acknowledgments buy on macOS?](https://github.com/GridSwarm/wiremux/issues/1854) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). It runs the native Datagram and stream arms on the connected shape macOS will ship, with probe fork builds that acknowledge every 2 (the fork's rule), 4, 8, 16 and 32 ack-eliciting packets, and measures rate, both peers' per-call send cost, acknowledgments per second, loss, retransmission and the congestion window, against a raw prediction and a Linux shape row. Nothing here implements a change.

Sources are wiremux at `origin/main` [d30c3689](https://github.com/GridSwarm/wiremux/tree/d30c3689454c0db2b008562d276d991fe642354f) (the native path is unchanged on `main` since), the connected-socket probe from [What would a connected socket per peer do to the native ceiling and to per-datagram admission?](https://github.com/GridSwarm/wiremux/issues/1842) (local commit `dc7cb39a`, never pushed), the quic-go-fast fork at the version the rig selects (`v0.62.1-fast.7`, [55ea687d](https://github.com/the-sarge/quic-go-fast/tree/55ea687d68c9c6f33785a1875374ec6a0d7570e8)), Go 1.27.2, the rig `cmd/nativerig` from `codex/native-gap-rig` at [5beb019a](https://github.com/GridSwarm/wiremux/tree/5beb019a) plus this ticket's probe flags ([Method](#method)), and measurements taken for this note on 2026-10-16. Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cells.** `tb`: mbp128 (MacBook Pro M4 Max) sends from `bridge0` over Thunderbolt to m4mini (Mac mini M4 Pro), both macOS 27 arm64, MTU 1500, every native arm connected (`-connectpeer`, #1842's probe, the shape [Should the native path use a connected socket per peer?](https://github.com/GridSwarm/wiremux/issues/1843) adopted). `netns`: minimax (Linux 7.0, x86_64), two network namespaces joined by a `veth` pair, Linux *shape* only, unconnected as Linux stays.

**Basis.** Rates, acknowledgment counts, loss and CPU come from headline campaigns (PROTOCOL.md: `REPS=5 SECS=10`, a warm-up rotation, arm order rotating). Per-call send cost is the send system call's leaf (`__sendmsg`) per call from untraced, system-wide Instruments Time Profiler recordings, the basis of #1841 and #1851, now taken on **both** Macs: the sender's leaf over its data sends, the receiver's over its sends, which are its acknowledgments. Datagram comparisons run at the GC pin (`-ballast 64 -gc-role both`) and report the default-GC row beside it.

## Answer

- **On macOS, yes: it is a 1.3–1.5× rate lever on the connected shape that ships, with a third less CPU on both peers and no new loss.** Acknowledging every 16 ack-eliciting packets instead of the fork's 2 lifts native Datagrams at the GC pin by 37% (1,987 → 2,729 Mbit/s) and the stream by 33% (2,279 → 3,028); every 32, by 46% and 36% (2,894 and 3,091 Mbit/s). Every 4 and 8 give +12% and +22–24% on both. CPU per delivered GiB falls 27–33% on each peer at 16 and 33–38% at 32 (**measured**, `C1`; [section 2](#2-rate-and-cpu-against-the-threshold-tb-connected)).
- **The sender stays the wall; each of its sends gets cheaper.** The fork's one send goroutine is 93–95% busy at every threshold. Its send call costs 4.61 µs in the leaf at the fork's rule (46,000 acknowledgments a second) and 3.05 µs at 32 (8,100), and the rate follows the per-call cost (**measured**, `X1`; [sections 3](#3-what-each-send-costs-on-both-peers) and [5](#5-what-holds-the-rate-at-16-and-32)). That is the inbound contention #1841 found: a raw connected sender with evenly spaced inbound datagrams at the same rates predicts 1.40 µs of the native 1.56 µs saving (**measured**, `X2`; [section 4](#4-the-raw-prediction)).
- **The receiver saves calls, not cost per call.** Its acknowledgment send costs 8.8–9.8 µs at every threshold, but it makes about a third as many a second at 16, so acknowledgment sends drop from 0.40 to 0.13 cores (0.08 at 32). No receiver thread is near full: its kernel input thread runs at 66–73%, no `nativerig` thread above 29%. The walls #1816 derived for it (about 263–296k packets/s) are already passed at 32 per acknowledgment (303,700 Datagrams a second).
- **Recovery and the window are unaffected.** Losses stay at the receiver's full socket buffer, 0.03–0.08% of Datagrams at every threshold; no spurious losses; at most one PTO per run, at the tail, at every threshold including the fork's rule. NewReno's window never binds (0.01–0.18% of send decisions). In flight and RTT samples grow with the rate (57 → 319 KB, 205 → 732 µs for Datagrams at 32): a queue builds somewhere on the path at the higher rate, not localized here; a mid-flow gap is still reported at once, because the receiver acknowledges at once after a gap, but the sender's packet-threshold detection then waits for the next regular acknowledgment, which a higher threshold spaces out ([section 6](#6-loss-recovery-and-the-congestion-window)).
- **A sender that is not saturated saves CPU only.** Paced at 1k, 10k and 100k Datagrams a second, 16 per acknowledgment costs the sender 10–31% and the receiver 8–26% less CPU per GiB, with no loss and RTT samples within 14 µs (114 µs at 1k/s). The cost is that the oldest packet of a group waits for the group (up to 15 ms at 1k/s; the 25 ms timer below 640 packets a second) ([section 7](#7-a-sender-that-is-not-saturated)).
- **On Linux, no rate at any threshold.** In the `netns` shape cell Datagrams stay at 3.86–3.91 Gbit/s and the stream at 10.66–10.73 Gbit/s from 2 to 32; the Datagram receiver spends up to 9% less CPU per GiB. The Linux stream's run loop already covers 27 packets per acknowledgment ([section 8](#8-the-linux-shape-netns)).
- **The fork's rule is already 4.4 packets per acknowledgment on macOS** because one acknowledgment covers each run-loop pass of up to 32 packets, so a threshold of 4 is the smallest step that changes anything there ([section 1](#1-how-often-the-fork-acknowledges)).
- **The map should count the fork's acknowledgment-frequency work as a macOS lever** of about +37% (Datagrams) and +33% (stream) at 16 per acknowledgment on the connected shape, about 30% less CPU per GiB on both peers, and CPU-only elsewhere. Whether it ships as a receiver-side rule or as the IETF Acknowledgment Frequency extension ([the-sarge/quic-go-fast#645](https://github.com/the-sarge/quic-go-fast/issues/645)), at which threshold and on which platforms, is a decision for a grilling ticket.

## 1. How often the fork acknowledges

The fork queues an acknowledgment after **2** ack-eliciting Application Data packets (`packetsBeforeAck`), or at once on a gap or an ECN-CE mark, or after its 25 ms `max_ack_delay` ([`received_packet_tracker.go` L79-L206](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/internal/ackhandler/received_packet_tracker.go#L79-L206); **source**). It *sends* the acknowledgment only when its run loop next sends, which is after it has handled the packets queued for it, up to 32 per pass ([`connection.go` L1050-L1095](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/connection.go#L1050-L1095); **source**), so one acknowledgment covers every packet that pass handled. Below a threshold of 32 the real ratio is therefore set by how deep the run loop's queue is when it wakes (**measured**, ack-eliciting packets per acknowledgment the receiver built):

| Shape | Packets per acknowledgment at the fork's rule | Acknowledgments per second |
| --- | ---: | ---: |
| `tb` unconnected (today's native Datagrams / stream) | 3.28 / 3.22 | 39,100 / 40,200 |
| `tb` connected, Datagrams at the pin / stream | 4.41 / 4.47 | 47,500 / 47,100 |
| `netns` Datagrams at the pin | 7.06 | 57,400 |
| `netns` stream (GSO) | 26.8 | 36,400 |

At every threshold 95–100% of acknowledgments were queued by the threshold; the rest by gaps (11–187 per 10 s run on `tb`). The 25 ms timer fired 0–2 times per run at every threshold, for the tail after the last data packet (the Datagram sender's largest RTT sample, 26–28 ms, is that tail at every threshold, the fork's rule included). So on macOS a threshold of 4 is the smallest step that changes anything, and on the Linux stream nothing up to 32 does much: its run loop already takes nearly full 32-packet passes and covers 27 packets per acknowledgment.

Acknowledgments counted three ways agree to within 0.5%: the receiver's built frames, its send calls through the binding, and the sender's received frames (`C1`, every arm).

## 2. Rate and CPU against the threshold (`tb`, connected)

Medians of five runs (`C1`; min–max of the rate in brackets; **measured**):

| Threshold | Packets per ack | Acks/s | Datagrams at the pin, Mbit/s | Default GC | Stream | Datagram CPU s/GiB sender / receiver | Stream CPU s/GiB sender / receiver |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2 (the fork) | 4.41 | 47,530 | 1,987 (1,980–2,058) | 2,033 | 2,279 (2,263–2,426) | 11.38 / 11.61 | 8.33 / 9.84 |
| 4 | 6.66 | 34,870 | 2,225 (2,104–2,267) | 2,142 | 2,560 (2,491–2,582) | 10.12 / 10.28 | 7.18 / 8.80 |
| 8 | 10.78 | 23,830 | 2,454 (2,429–2,507) | 2,385 | 2,773 (2,736–2,800) | 9.03 / 9.23 | 6.35 / 7.73 |
| 16 | 19.01 | 15,050 | 2,729 (2,676–2,802) | 2,508 | 3,028 (2,835–3,143) | 7.94 / 8.45 | 5.56 / 7.05 |
| 32 | 35.05 | 8,670 | 2,894 (2,850–2,938) | 2,673 | 3,091 (3,070–3,226) | 7.32 / 7.76 | 5.17 / 6.51 |

- **Rate.** Against the fork's rule, Datagrams at the pin gain +12%, +24%, +37% and +46%; the stream +12%, +22%, +33% and +36% (**derived** from the medians). The gain per halving shrinks: 16 → 32 adds 6% for Datagrams and 2% for the stream.
- **CPU.** Per delivered GiB, at 16 the sender spends 30% less (Datagrams) and 33% less (stream), the receiver 27% and 28% less; at 32, 36%/38% and 33%/34% (**derived**). Per packet, the sender's system time falls from 7.79 to 4.96 µs (Datagrams, 16) and the receiver's from 7.69 to 5.07.
- **Default GC.** Without the pin the gain is +31% at 32, not +46%: at 600 collections a second on each peer, collection starts to take rate on macOS at these packet rates (the default rows' 470–640 collections/s against 18–26 at the pin).
- **Unconnected reference.** Today's unconnected native arms in the same campaign: Datagrams 1,228 Mbit/s and stream 1,413 at the fork's rule.

## 3. What each send costs, on both peers

Profiled pairs (`X1`, three per rung in rotation, 8 s sends, Time Profiler on both Macs; medians, min–max in brackets; **measured**). The sender's send leaf is over its data sends; the receiver's over its acknowledgment sends; "receive per packet" is the sender's `recvmsg` leaf (its acknowledgment reads) divided by its data sends:

| Threshold | Sender packets/s | Sender send leaf, µs per call | Sender receive per packet, µs | Receiver acks/s | Receiver ack send leaf, µs per call | Receiver ack sends, cores |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| **Datagrams at the pin** | | | | | | |
| 2 | 189,400 | 4.61 (4.55–4.62) | 0.73 | 46,000 | 8.80 (8.52–8.90) | 0.40 |
| 4 | 208,400 | 4.15 (4.06–4.18) | 0.48 | 33,100 | 8.97 (8.78–9.29) | 0.30 |
| 8 | 233,500 | 3.66 (3.59–3.79) | 0.30 | 22,700 | 8.96 (8.95–9.32) | 0.20 |
| 16 | 254,700 | 3.32 (3.25–3.32) | 0.17 | 13,900 | 9.14 (9.08–9.93) | 0.13 |
| 32 | 277,900 | 3.05 (3.03–3.10) | 0.10 | 8,100 | 9.75 (9.69–9.83) | 0.08 |
| **Stream** | | | | | | |
| 2 | 194,400 | 4.44 (4.42–4.57) | 0.70 | 47,300 | 8.93 (8.89–9.23) | 0.43 |
| 4 | 215,800 | 4.00 (3.96–4.07) | 0.45 | 33,800 | 9.60 (9.14–10.11) | 0.33 |
| 8 | 231,100 | 3.68 (3.61–3.75) | 0.30 | 22,500 | 9.18 (9.08–9.44) | 0.21 |
| 16 | 257,000 | 3.29 (3.28–3.42) | 0.17 | 14,000 | 9.13 (8.86–9.40) | 0.13 |
| 32 | 265,800 | 3.20 (3.13–3.20) | 0.09 | 7,900 | 9.36 (8.37–9.54) | 0.07 |

- **The sender's send gets cheaper.** From the fork's rule to 32 the data send's leaf falls 1.56 µs per call for Datagrams (4.61 → 3.05) and 1.24 µs for the stream (4.44 → 3.20), and the sender's acknowledgment reads fall from 0.7 to 0.1 µs per data packet. The fall is steepest at the high acknowledgment rates: 0.46 µs per call from 46k to 33k/s, 0.27 from 14k to 8k (Datagrams).
- **The receiver's acknowledgment send does not.** It costs 8.8–9.8 µs per call at every threshold, connected, as [What would a connected socket per peer do to the native ceiling and to per-datagram admission?](https://github.com/GridSwarm/wiremux/issues/1842#issuecomment-6201882656) measured (8.5–9.2). What the receiver saves is the number of calls: 0.40 cores of acknowledgment sends at the fork's rule, 0.13 at 16 and 0.08 at 32. Per delivered packet that is 2.0 µs (8.80 / 4.41) against 0.28 µs (9.75 / 35.05) (**derived**), about 1.7 of the 4.3 µs per packet the receiver's whole-process CPU falls by in `C1` (12.88 → 8.60 µs).
- **Basis.** Recording the receiver as well costs the pair about 9% of its rate against the campaign (189k against 209k packets/s at the fork's rule), and the absolute leaf is higher than #1851's connected native at the pin (3.98 µs at 221k packets/s, sender-only recordings). Differences are taken within this set.

## 4. The raw prediction

#1841 and #1851 measured what acknowledgments arriving on a sender's socket cost a raw sender. Here the closest raw reproduction of the connected native send, #1851's `c7` (the native call shape on a connected socket, a goroutine reading the socket, and the send queue's hand-off), is driven by evenly spaced reflected datagrams (`-reflect-burst 1`) at the rates `C1` measured on the native pairs (`X2`, three sender-only recordings per rung, 8 s; **measured**):

| Inbound per second | Raw `c7` send leaf, µs per call (min–max) | Raw packets/s | Native send leaf at the nearest rate (`X1`, Datagrams) | Native − raw |
| ---: | ---: | ---: | ---: | ---: |
| 0 | 2.59 (2.59–2.62) | 332,900 | – | – |
| 8,500 | 2.81 (2.79–2.85) | 305,000 | 3.05 at 8,100 | 0.24 |
| 15,000 | 3.06 (2.93–3.06) | 276,300 | 3.32 at 13,900 | 0.26 |
| 24,000 | 3.22 (3.21–3.25) | 263,400 | 3.66 at 22,700 | 0.44 |
| 35,000 | 3.69 (3.65–3.94) | 226,500 | 4.15 at 33,100 | 0.46 |
| 48,000 | 4.21 (4.06–4.46) | 199,300 | 4.61 at 46,000 | 0.40 |

- **The prediction holds.** From 48,000 to 8,500 inbound datagrams a second the raw send gets 1.40 µs cheaper; the native send got 1.56 µs cheaper from 46,000 to 8,100 acknowledgments (**derived**). So the native saving is the inbound contention #1841 found, about 90% of it (its proposed mechanism, **source**: `udp_input` and the reading goroutine's receives take the socket lock each send also holds); the native send stays 0.24–0.46 µs above the raw one at every rate, the remainder #1851 described plus this set's two-Mac recording basis.
- **Faster than linear**, as #1841 found unconnected: 0.026 µs per 1,000/s between 0 and 8,500, 0.040 between 35,000 and 48,000.
- **What is left.** With no inbound at all the raw send costs 2.59 µs, so acknowledging even less often than every 32 packets could take at most about 0.46 µs more from the native send (**derived**: 3.05 − 2.59), about 15%.

## 5. What holds the rate at 16 and 32

The sender's one send goroutine, at every threshold (**measured**, `X1`). Its share of a core, the send leaf plus the fork's `sendQueue.Run` Go frames per call times the send rate, is 0.95 at the fork's rule and 0.93–0.94 at 4 to 32 for Datagrams, and 0.93–0.95 for the stream. Fewer acknowledgments make each of its calls cheaper, so the same goroutine sends more: Datagrams +47% from 2 to 32 in these pairs, against +49% from the per-call cost (**derived**: (4.61 + 0.39) / (3.05 + 0.31)). Nothing else on either Mac is near full (busiest thread per kind, utilization over a steady 5 s window):

| Threshold (Datagrams) | Sender: send goroutine | Sender: kernel transmit thread (`ifnet_start_en3`) | Sender: kernel input thread (acknowledgments) | Receiver: kernel input thread (`dlil_input_en2`) | Receiver: Thunderbolt IP thread | Busiest `nativerig` thread, sender / receiver |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2 | 95% | 72% | 34% | 66% | 48% | 26% / 28% |
| 8 | 94% | 77% | 19% | 68% | 53% | 26% / 28% |
| 32 | 94% | 84% | 7% | 73% | 55% | 23% / 29% |

The stream rungs read the same within 6 points. Go moves the send goroutine between threads (its send calls ran on 12–13 threads in every pair), so no single `nativerig` thread is above 29%; the goroutine's share is from the leaf and frame attribution above, not from a thread.

- **The next walls** are kernel threads, not the receiver's goroutines. If their cost per packet stays as measured, the sender's transmit thread would fill near 330k packets/s (**derived**: 277,900 / 0.84) and the receiver's input thread near 380k (277,900 / 0.73). The receiver's walls that [Should macOS receives be batched with recvmsg_x in the fork and wiremux?](https://github.com/GridSwarm/wiremux/issues/1816#issuecomment-6219113617) derived (input thread about 296k, receive goroutine about 263–286k packets/s) are already passed: at 32 per acknowledgment the campaign delivered 303,700 Datagrams and 282,800 stream packets a second with no growth in loss.
- **The stream gains least at 32** because its send leaf barely moves from 16 (3.29 → 3.20 µs) while its acknowledgment rate halves: at 14k/s the remaining inbound contention is small.

## 6. Loss, recovery and the congestion window

**Measured** (`C1`, the probe's counters on the sender's loss recovery and congestion controller, the fork's default NewReno; medians per 10 s run):

| Threshold | Datagrams: lost per 10⁵ sent | congestion events | stream: lost per 10⁵ | congestion events | in flight at each ack, KB (Datagrams / stream) | mean RTT sample, µs (Datagrams / stream) |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2 | 40 | 862 | 39 | 817 | 57 / 69 | 205 / 224 |
| 4 | 34 | 781 | 74 | 1,741 | 71 / 107 | 218 / 285 |
| 8 | 54 | 1,398 | 19 | 490 | 100 / 114 | 269 / 271 |
| 16 | 55 | 1,555 | 22 | 634 | 189 / 189 | 468 / 411 |
| 32 | 56 | 1,730 | 22 | 636 | 319 / 187 | 732 / 342 |

- **No new loss mechanism.** Every connected arm loses its packets at the receiver's full socket buffer (`rcvbuf` 480–1,540 per run against 8–51 on the wire), as at the fork's rule. Datagram application loss stays at 0.03–0.08% at every threshold (0.06–0.08% at the pin). The stream's declared losses are 39 per 10⁵ at the fork's rule, 74 at 4 and 19–22 at 8 to 32; the Datagram sender's rise from 34–40 to 54–56 per 10⁵ at 8 and above, at a 24–46% higher packet rate.
- **No spurious loss, and PTOs only at the tail.** No run at any threshold declared a loss that was later acknowledged. A PTO fired at most once per run, in 10 of the 100 `C1` runs: twice at the fork's rule, four times at 4, once each at 8, 16 and 32, and once on today's unconnected Datagrams, with no trend by threshold. That is the end of the run: the last few packets are always fewer than any threshold, so their acknowledgment waits for the 25 ms timer at every threshold, the fork's rule included, and the sender's PTO (smoothed RTT plus variance plus the same 25 ms) sometimes fires first (**derived** from the counters; the paced runs that had one declared no loss). Loss in the middle of a flow is still reported at once: the receiver acknowledges at once when a packet arrives after a gap (**source**, `hasNewMissingPackets` and the missing-packet rule above), at every threshold. That acknowledgment's largest packet is only one past the gap, though, and the sender declares a packet lost only once a packet three past it is acknowledged, or after 9/8 of an RTT ([`sent_packet_handler.go` L21-L23, L883-L884](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/sent_packet_handler.go#L21-L23)) (**source**). So detection waits for the next regular acknowledgment, which a higher threshold spaces out, or for the time threshold. These runs show no recovery cost from that; they do not measure the wait.
- **The window never binds.** NewReno's window averages 800–1,100 KB at every threshold (minimum the 39 KB initial window), and 0.01–0.18% of send decisions found it full. What grows is the data in flight before each acknowledgment (57 → 319 KB for Datagrams) and the RTT samples (205 → 732 µs against a minimum of about 61 µs at every threshold). Each acknowledgment covers more packets, and a queue builds somewhere between the sender's send call and the receiver's run loop at the higher rate. It is not localized here: the receiver's socket buffer overflows 480–1,540 times a run at every threshold, the sender's transmit thread is 84% busy at 32, and the receiver's receive goroutine (about 0.64 cores in its receive calls at 32) and run loop (about 0.41 cores of Go work) are both below a core (**measured**, `X1`).
- **`max_ack_delay` unchanged.** The probe keeps the fork's 25 ms delay and the matching transport parameter at every threshold, so PTO and the RTT estimator's ack-delay bound are unchanged. In these saturated runs an acknowledgment is due every 21–115 µs (**derived**: 4.41 packets at 208.5k packets/s to 35.05 at 303.7k), so the delay timer never matters except at the tail.

## 7. A sender that is not saturated

A consumer at GridCast's typical tier (1 Gbit/s) does not saturate the connected native path, so `P1` paces connected Datagrams at 1,000, 10,000 and 100,000 a second (about 10, 95 and 953 Mbit/s; the last in bursts of 10, the others one at a time) and compares thresholds 2, 8 and 16 (three runs each; **measured**):

| Offered | Threshold | Acks/s | Packets per ack | CPU s/GiB sender / receiver | Mean RTT sample / minimum, µs | Loss |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1,000/s | 2 | 496 | 2.02 | 110.5 / 123.6 | 404 / 158 | 0 |
| | 8 | 125 | 7.99 | 107.6 / 96.2 | 454 / 194 | 0 |
| | 16 | 63 | 15.9 | 97.5 / 91.6 | 518 / 232 | 0 |
| 10,000/s | 2 | 4,996 | 2.00 | 30.0 / 25.3 | 77 / 55 | 0 |
| | 8 | 1,251 | 8.00 | 22.9 / 21.8 | 81 / 59 | 0 |
| | 16 | 626 | 16.0 | 20.7 / 21.1 | 91 / 62 | 0 |
| 100,000/s | 2 | 12,269 | 8.15 | 9.25 / 6.32 | 96 / 47 | 0 |
| | 8 | 9,869 | 10.1 | 9.04 / 6.12 | 94 / 45 | 0 |
| | 16 | 5,000 | 20.0 | 8.31 / 5.82 | 97 / 52 | 0 |

- **CPU, not rate.** Every arm delivered what it was offered. At 16 per acknowledgment the sender spends 10–31% less CPU per GiB and the receiver 8–26% less (**derived**). At 100,000 a second in bursts of 10 the fork's rule already acknowledges about every 8 packets, because each burst reaches the run loop together, so the saving is the smallest there.
- **RTT samples stay honest.** An acknowledgment queued by the threshold is sent as soon as the threshold packet arrives, and the sender takes its RTT sample from that packet, so a higher threshold does not inflate the samples; the mean sample moved by at most 14 µs at 10k and 100k/s. At 1,000 a second it rose by 114 µs (and the minimum by 74 µs), on links whose hosts are otherwise idle between packets.
- **The cost is acknowledgment latency for the oldest packets in a group.** At 1,000 a second and a threshold of 16, the first packet of each group waits up to 15 ms for its acknowledgment (**derived**: 15 packets × 1 ms), so about 20 KB is in flight at each acknowledgment instead of 2. Below 640 packets a second (16 / 25 ms) the 25 ms timer would set the pace instead (**derived**). Neither bound reached the 39 KB initial window here, and the PTO already allows the 25 ms. A sender policy, as in the Acknowledgment Frequency extension, could keep low-rate or window-limited flows on the fork's rule.
- No paced run lost a packet or declared one lost; PTOs fired at most once per run, at the tail, in 7 of 27 runs, at every threshold.

## 8. The Linux shape (`netns`)

**Measured** (`N1`, unconnected, medians of five runs; the stream's packets per second are GSO send calls of about nine packets each):

| Threshold | Datagrams at the pin, Mbit/s | packets per ack | acks/s | CPU s/GiB sender / receiver | Stream, Mbit/s | packets per ack | acks/s | CPU s/GiB sender / receiver |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2 | 3,860 | 7.06 | 57,400 | 4.75 / 3.15 | 10,657 | 26.8 | 36,400 | 1.54 / 1.53 |
| 4 | 3,908 | 8.89 | 46,200 | 4.72 / 3.07 | 10,664 | 27.2 | 35,900 | 1.54 / 1.53 |
| 8 | 3,895 | 11.6 | 35,100 | 4.68 / 3.00 | 10,727 | 27.8 | 35,200 | 1.54 / 1.53 |
| 16 | 3,888 | 19.5 | 20,900 | 4.63 / 2.93 | 10,671 | 30.9 | 31,700 | 1.54 / 1.53 |
| 32 | 3,864 | 35.2 | 11,500 | 4.58 / 2.88 | 10,682 | 34.0 | 28,800 | 1.53 / 1.52 |

On Linux fewer acknowledgments buy no rate: Datagrams stay within 1.2% and the stream within 0.7% at every threshold, inside run-to-run spread. The Datagram receiver spends up to 9% less CPU per GiB (3.15 → 2.88 at 32) and the sender 4% less; the stream's run loop already covers 27 packets per acknowledgment, so its acknowledgment rate barely moves (36,400 → 28,800) and neither does its CPU. Loss and congestion events do not move either (Datagrams 30–37 lost per 10⁵ at every threshold).

## Method

**Fork probe** (`native-gap-evidence/1854-ack-frequency/qgf-1854`, a git copy of the `v0.62.1-fast.7` module; commit 1 is the pristine module-cache copy, `fork-1854.diff` the change; never pushed):

- `quic.Research1854SetAckN(n)` replaces `packetsBeforeAck = 2` with a process-wide setting read in `shouldQueueACK`; the 25 ms `max_ack_delay` and its transport parameter are unchanged.
- `quic.Research1854Snapshot()` returns process-wide counters (one connection per process): why each acknowledgment was queued (threshold, missing packet, new gap, ECN-CE), acknowledgment frames built and those built only by the timer, the ack-eliciting packets each covered; on the sender, 1-RTT acknowledgments received and packets newly acknowledged, the congestion window and bytes in flight at each such acknowledgment (sum, minimum, maximum), RTT samples (mean, maximum; the estimator's smoothed and minimum RTT at the last), ack-eliciting packets declared lost by time and by packet threshold and their bytes, spurious losses, congestion events, PTO expiries in the Application Data space, and send-mode decisions with those that found the window full.
- The fork's `internal/ackhandler` tests compile; `TestSentPacketHandlerECN` fails because its strict mock does not expect the probe's congestion-window read (a side-effect-free getter). Nothing else in the fork was built or tested.

**wiremux probe** (detached worktree `1854-probe`, local commits on #1851's probe `c8283c93`, itself #1842's `dc7cb39a` plus #1841's and #1851's instrumentation; never pushed; `probe1854.diff` in the evidence directory):

- `-ackn N` (native arms, both peers) calls `quic.Research1854SetAckN` before any connection; each native result line gains the snapshot as `ack1854`.
- `-nselfcount N` turns on #1851's per-call native send sampler (not used in the evidence).
- `-pace N` / `-paceburst B` (native Datagram sender): offer `N` Datagrams a second, `B` at a time on an absolute schedule (only `P1`).
- `cmd/nativerig/rig-1854.mod` points the rig's `replace` at the fork probe.

**Sets** (2026-10-16 UTC; evidence in `native-gap-evidence/1854-ack-frequency/`, `README.txt` there):

| Set | What | Runs or pairs | UTC |
| --- | --- | ---: | --- |
| `S0` | `tb` smoke, 5 arms, 5 s (never evidence) | 5 | 16:00–16:01 |
| `N1` | `netns` headline campaign: standard slate, Datagrams at the pin and the stream at thresholds 2–32 | 90 runs | 16:02–16:24 |
| `C1` | `tb` headline campaign: standard slate, connected Datagrams at the pin and at default GC, connected stream, thresholds 2–32 | 120 runs | 16:03–16:50 |
| `X1` | `tb` profiled pairs, Time Profiler on both Macs, 10 native rungs × 3 | 30 | 16:50–17:27 |
| `X2` | `tb` profiled pairs, sender's Mac only, 6 raw rungs × 3 | 18 | 17:27–17:49 |
| `P1` | `tb` campaign: standard slate and paced connected Datagrams (1k, 10k and 100k/s) at thresholds 2, 8 and 16, `REPS=3` | 56 runs | 17:49–18:09 |

Per-call costs come from #1851's `xsend.py` with a role switch (`xleaf.py`): the role's process's on-CPU samples, the send leaf summed and divided by that role's native send calls from the probe's binding counters (the sender's data sends; the receiver's sends, which are its acknowledgments plus, on the stream, about 0.4% flow-control updates). Thread utilizations are #1800's `xthreads.py` over a 5 s steady window, run on minimax from the same exports so that no analysis ran on mbp128 during `X2`'s pairs. Each pair deleted its own Instruments raw kernel traces on both Macs after export.

**Sharing the pair.** Every `tb` campaign held one claim for its whole length and every profiled pair its own (a placeholder process on m4mini that other sessions' gates wait for), verified 1 s and 6 s after claiming: 52 claims, no collision. Before every run and pair the gate also waited for both Macs' load1 to be at most 8 and for `bridge0` to carry no other traffic (a GridCast benchmark session uses the same link and runs no `nativerig`); no gate saw another session's work in the window. m4mini ran Photos media analysis (about 1.35 cores, on efficiency cores) during at least the first profiled pair, and its load1 reached 25 once between pairs, which the gate waited out.

**Incident.** At 16:26:25–16:26:33 UTC this session compiled the probe (`go vet` of the `-pace` change) on mbp128 at the end of `C1`'s `r3-binding` send window; that run is within its arm's 0.8–1.2 band and stays in the statistics, as PROTOCOL.md requires.

## Limits

- **One cell per platform, and the Linux one is a shape.** `tb` is the only macOS cell; its receiver is a Mac mini whose Thunderbolt driver and input thread are part of what is measured. `netns` has no NIC and runs both peers on one host.
- **A probe rule, not the extension.** The probe changes the receiver's threshold for every connection and keeps the 25 ms delay; the IETF Acknowledgment Frequency extension would let the sender choose both and send `IMMEDIATE_ACK`. What a sender policy would pick, and how it behaves on loss or at low rates, is not measured here.
- **NewReno only.** The native path runs the fork's default controller. BBR, whose bandwidth samples depend on how acknowledgments are spaced, is the fork's BBR map's question and out of scope here.
- **Saturating senders, plus one paced set.** The campaign arms send as fast as the Wire takes them; `P1` is the only application-limited evidence, with steady pacing, no idle periods and no loss injection.
- **The two-Mac recording basis** costs the profiled pairs about 9% of their rate, so `X1`'s absolute leaf times are not comparable with #1851's sender-only sets; `X2` is on #1851's basis.
- **Process-wide counters.** The probe counts per process; each rig peer runs one connection, so the counters are that connection's, plus its handshake.

## Implications for the map

- **[Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801).** On macOS the connected socket's 1.7× now has a second measured lever on top of it: fewer acknowledgments, +37% (Datagrams at the pin) and +33% (stream) at 16 per acknowledgment, +46% and +36% at 32, measured on the connected probe itself. On Linux it is CPU only (at most 9% on the Datagram receiver).
- **Packaging it is a decision.** A grilling ticket graduates from this one: the threshold (16 takes most of the gain; 32 adds 6% for Datagrams and 2% for the stream), the platforms (Linux gains no rate), and the mechanism. A receiver-side rule in the fork is the cheapest and works with any sender; RFC 9000 makes acknowledging every second packet a SHOULD ([§13.2.2](https://www.rfc-editor.org/rfc/rfc9000.html#section-13.2.2)), and a non-fork sender's congestion controller would see the thinner feedback. The Acknowledgment Frequency extension (draft-14, [the-sarge/quic-go-fast#645](https://github.com/the-sarge/quic-go-fast/issues/645)) lets the sender choose per connection, and keep low-rate or window-limited flows on the fork's rule, at the cost of negotiation, a sender policy and the fork's own evidence gate there ([the-sarge/quic-go-fast#619](https://github.com/the-sarge/quic-go-fast/issues/619)). Fork changes are decided on this map and executed in the fork's tracker, so nothing goes to #645 before that grilling.
- **[How much would batched connected sends add to the native macOS sender?](https://github.com/GridSwarm/wiremux/issues/1856).** The connected send's per-call cost depends on the acknowledgment rate: the raw `c7` shape costs 2.59 µs with no inbound traffic and 4.21 µs at 48,000 a second. Both levers cut the same goroutine's time per packet, so whether they add needs a measurement with fewer acknowledgments as well as at the fork's rule (an input comment there).
- **[Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858).** The send goroutine is the wall at every threshold, so its core placement matters as much with fewer acknowledgments as without.
- **The connected receiver** (Not yet specified). At 32 per acknowledgment and 278k packets/s (profiled) the receiver's input thread runs at 73% and its Thunderbolt IP thread at 55%, its acknowledgment sends take 0.08 cores, and the nearest kernel wall is the *sender's* transmit thread (84%, about 330k packets/s if its per-packet cost holds; **derived**). The receive-batching reopen trigger in #1816 (a measured receive-goroutine wall with a target above it) is not met.

## Open questions

These are candidate tickets.

1. **Should native connections acknowledge less often, and through which mechanism?** The threshold, the platforms, a receiver rule or the Acknowledgment Frequency extension with a sender policy, and what keeps low-rate and window-limited flows on the fork's rule (graduated as a grilling ticket).
2. **Do fewer acknowledgments and batched connected sends add up?** Folded into the batched-send research ticket as an input.
3. **What bounds the connected macOS pair once the send goroutine is cheaper still?** The sender's kernel transmit thread at 84% and the receiver's input thread at 73% are the candidates; it matters only if the per-platform targets ask for more than about 300k packets a second on one connected Wire.
4. **What does the fork's BBR do with fewer acknowledgments?** Its delivery-rate samples depend on acknowledgment spacing; that is the fork's BBR map's question.
