# Issue #1829: why native receive coalescing costs throughput, and a fix that keeps its CPU saving

Research for [#1829](https://github.com/GridSwarm/wiremux/issues/1829) on the wayfinder map [#1794](https://github.com/GridSwarm/wiremux/issues/1794). The [#1824 note](https://github.com/GridSwarm/wiremux/blob/54b72d4b98a89fe45d920e3df751abba36390bcf/docs/research/issue-1824-native-receive-gro.md) found that turning on the fork's receive coalescing (`UDP_GRO`) in the minimax `netns` shape cell cuts CPU per GiB but lowers delivered throughput, by 3.5% for the native stream and by 2.5% even for the stock sender's Datagrams, where nothing coalesces, with spare CPU on both peers and the cause unexplained. This note isolates the mechanism and tests a candidate fix. Nothing here is implemented. Every build is a throwaway probe, and none is merged or pushed.

Sources are wiremux at `origin/main` [2599a002](https://github.com/GridSwarm/wiremux/tree/2599a00292c70c9871794ce62a1266741d71d42a), the quic-go-fast fork at [`v0.62.1-fast.7`](https://github.com/the-sarge/quic-go-fast/tree/v0.62.1-fast.7), Linux [v7.0](https://github.com/torvalds/linux/tree/v7.0), Go [go1.27.1](https://github.com/golang/go/tree/go1.27.1), and measurements in the `netns` cell on 2026-10-13. Every derived number is marked **derived**. Statements about cause are marked as inferred where no measurement isolates them.

## Answer

- **It is not `UDP_GRO`, and it is not the acknowledgment cadence.** Receive coalescing costs throughput through the fork's coalescing read path: the 64 KiB read buffers and the per-datagram delivery machinery behind them. The same path with `UDP_GRO` never set costs the same on Datagrams (−2.3% against −2.4%) and far more on the stream (−22%, because nothing then amortizes it). The sender reads 9–12% fewer acknowledgments per GiB under coalescing, but with the fix below it still reads 9% fewer and throughput is fully restored, so that is a correlate.
- **Two mechanisms, on different peers:**
  - **Stream (where datagrams do coalesce): the receiver's delivery path.** Per coalesced read, the fork allocates a slab, a view per datagram and a growing pending list, and it copies each datagram off the shared buffer while holding the connection's receive lock, which the connection's run loop takes twice per packet. The receiver allocates 46% more (256 → 373 MB/s) and spends 30% more time in GC pauses. Moving only the copy out of the lock recovers about 40% of the loss (−2.4% → −1.4%). The run loop is the stream's busiest serial stage here (75–84% of wall time), so stalls added to it cost throughput even with idle CPUs. The split between GC and the remaining delivery overhead is inferred, not traced.
  - **Stock Datagrams (where nothing coalesces): GC pacing on the sender.** The cost is entirely on the sender, which reads its acknowledgments through the coalescing path. Its 8 read slots of 64 KiB add 0.5 MiB of live heap to a process whose heap goal sits at Go's 4 MiB floor while it allocates 1.9 GB/s. That shortens the allocation runway between collections by 17% (**derived**) and raises GC cycles by 22% (867 → 1,062 per second), which costs 2.4–2.8%. With `GOGC=400` the coalescing cost disappears (+0.1%), and the Datagram arm itself gains 10.6%.
  - **Coalesced Datagrams (the GSO-probe sender) carry both.** Receiver side −2.1% (−0.7% with the fix below), sender side −4.7% from the GC floor; this sender allocates 3.2 GB/s and gains 52% from `GOGC=400` alone. Off the GC floor a third, receiver-side cost of about 9% appears that the fix does not touch; it shows up as a longer wait in the sender's Datagram hand-offs, not in either mechanism above, and is left open (section 4).
- **The candidate fix, copy-at-read, restores the stream and keeps the CPU saving.** The reader copies every datagram of a coalesced read into an ordinary packet buffer straight away and keeps its 64 KiB buffer for the next read: no slab, no per-read allocation and no copy under the lock. It is about the same copy the fork already makes, done earlier. Stream throughput is +0.9% over no coalescing (10,932 against 10,831 Mbit/s, n = 6; a second pair of campaigns gives +0.7%), with −23% sender and −24% receiver CPU per GiB, better than today's coalescing path (−22% and −19%). Receiver GC cycles fall 62% against today's path. It does not change the Datagram arm's GC-floor cost (section 3). Only a higher GC goal removes that: 2 slots bring the collections back to baseline but cost reads and acknowledgments, and still lose 2.4%.
- **Verdict: adoptable, with one fork change.** Native receive coalescing is worth adopting once the fork's coalesced delivery copies at read time (a quic-go-fast change); wiremux's side stays the one-argument switch and one `COMPATIBILITY.md` sentence from #1824. With `v0.62.1-fast.7` as it is, it trades 2.4–2.8% of stream throughput for its CPU saving, so it should wait for the fork change. The remaining Datagram cost in this cell is not a coalescing defect: it belongs to the Datagram path's allocation rate, which keeps the rig's sender at Go's GC floor.

## 1. Which peer, and which part of coalescing

Coalescing is granted per process, so each peer can take it alone. `-gro` also has a variant, `-nosockopt`, that takes the whole coalescing read path but never sets `UDP_GRO`: the socket then delivers one datagram per read into 64 KiB buffers. Pooled medians of two interleaved campaigns (S1, S2), six 10-second runs per row, stock sender (build A plus counters). CPU is CPU-seconds per delivered GiB, whole process.

| Arm | Coalescing path on | Mbit/s | Spread | Change | Sender CPU | Receiver CPU | Sender GC cycles/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `dgram` | neither | 3,292 | 3,275..3,297 | — | 5.28 | 3.82 | 866 |
| `dgram` | both | 3,212 | 3,184..3,218 | −2.4% | 5.43 | 3.91 | 1,060 |
| `dgram` | receiver only | 3,322 | 3,311..3,336 | +0.9% | 5.21 | 3.87 | 872 |
| `dgram` | sender only | 3,179 | 3,173..3,194 | −3.4% | 5.51 | 3.83 | 1,047 |
| `dgram` | both, no `UDP_GRO` | 3,217 | 3,199..3,223 | −2.3% | 5.43 | 3.91 | 1,063 |
| `stream` | neither | 10,914 | 10,472..11,006 | — | 1.53 | 1.53 | 33 |
| `stream` | both | 10,606 | 10,580..10,636 | −2.8% | 1.19 | 1.24 | 34 |
| `stream` | receiver only | 10,606 | 10,369..10,645 | −2.8% | 1.18 | 1.24 | 29 |
| `stream` | sender only | 10,931 | 10,820..10,969 | +0.2% | 1.53 | 1.53 | 35 |
| `stream` | both, no `UDP_GRO` | 8,505 | 8,441..8,569 | −22.1% | 1.59 | 1.68 | 26 |

- **The two costs live on opposite peers.** The stream loses only when the receiver coalesces; the stock Datagram arm loses only when the sender does. The sender's side of a Datagram transfer is its acknowledgment reader.
- **`UDP_GRO` is not the cost.** Without it, the coalescing path costs Datagrams the same, and costs the stream 22%. In this cell a datagram coalesces only when the sender sent it in one segmented (GSO) send, because `veth` hands the segmented packet across whole ([`veth.c` L320-L326, L347-L379](https://github.com/torvalds/linux/blob/v7.0/drivers/net/veth.c#L320-L379)), and a socket with `UDP_GRO` accepts it whole instead of splitting it ([`udp.c` L2512-L2530](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/udp.c#L2512-L2530), [`include/linux/udp.h` L193-L200](https://github.com/torvalds/linux/blob/v7.0/include/linux/udp.h#L193-L200), [`udp.c` L3079-L3088](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/udp.c#L3079-L3088)). Without `UDP_GRO`, each stream datagram pays for a whole 64 KiB slot and the delivery machinery (section 2) and nothing amortizes it, which is where the 22% goes: the receiving run loop is then busy 91% of the transfer and its queue averages 97 packets (against 81% and 35 without coalescing, S campaigns).
- **The CPU saving lands partly on the sender in this cell.** The receive side of a `veth` transfer runs in the softirq of the *sending* CPU: `veth` posts the packet to the current CPU's backlog ([`dev.c` L5664-L5694](https://github.com/torvalds/linux/blob/v7.0/net/core/dev.c#L5664-L5694), with RPS off on both ends), and minimax's kernel charges softirq time to the interrupted task ([`cputime.c` L170-L207](https://github.com/torvalds/linux/blob/v7.0/kernel/sched/cputime.c#L170-L207); `CONFIG_IRQ_TIME_ACCOUNTING` is off). So when the receiver stops splitting segmented packets, the sender's CPUs save the softirq time: 0.63 → 0.12 CPUs (per-CPU `/proc/stat`, F campaigns). On a real NIC that work would be on the receiving host.

## 2. The stream: the receiver's delivery path

### What the coalescing path does per read

With coalescing on, the fork's reader ([`sys_conn_oob.go` L203-L261](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L203-L261)) fills each of 8 batch slots ([`sys_conn_helper_linux.go` L24](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_helper_linux.go#L24)) with a 65,535-byte buffer from a pool ([L218-L224](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L218-L224)), and hands each filled buffer to the coalesced-delivery holder ([L358](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L358)). Per read, that:

1. allocates a slab ([`coalesced_delivery.go` L32](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_delivery.go#L32)), a slice of views and one view object per datagram ([`coalesced_slab.go` L67-L85](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_slab.go#L67-L85)), and appends every datagram after the first to a pending list that regrows on most reads ([`coalesced_delivery.go` L40-L45](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_delivery.go#L40-L45));
2. counts the views with an atomic reference count and returns the 64 KiB buffer to its pool when the last one goes ([`coalesced_slab.go` L94-L104](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_slab.go#L94-L104));
3. copies each datagram into an ordinary packet buffer when the connection queues it, so a queued packet cannot pin the slab ([`coalesced_slab.go` L115-L154](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_slab.go#L115-L154)). That copy runs inside `Conn.handlePacket`'s critical section on the receive lock ([`connection.go` L2003-L2034](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2003-L2034)), which the connection's run loop also takes, twice for every packet it pops ([`connection.go` L1050-L1100](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L1050-L1100)).

The fork's [coalesced-delivery plan](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/docs/adr/2026-09-13-coalesced-delivery-plan.md) built this for correctness and explicitly ran no performance campaign.

### Two candidate changes

Both are knobs in one throwaway fork build (`qgf-1829-fx`), so every arm below runs the same binary; with the knobs off it is the counters build.

- **Copy-out (`-fix-co`):** only moves the existing retention copy in front of the lock. Everything else stays.
- **Copy-at-read (`-fix-cr`):** the reader copies every datagram of a coalesced read into an ordinary pool buffer as it decodes the read, keeps its 64 KiB buffer in its slot for the next read, and hands QUIC ordinary packets. No slab, no views, no atomic count, no pending-list growth (its backing array is reused), and nothing is copied under the lock, because nothing slab-backed reaches the connection. A datagram larger than the 20 KiB packet tier would be copied into a 64 KiB buffer instead; QUIC never produces one here.

### Measured

Pooled medians, F1 and F2, six runs per row. "Run loop busy" is the share of the transfer the receiving connection's run loop spent outside its wait for work. "Queue" is the mean length of the 256-packet unprocessed queue when a packet joins it, and "first-packet delay" is how long the first packet of each processed batch waited between its read and its processing.

| Stream arm | Mbit/s | Spread | Change | Sender CPU | Receiver CPU | Receiver alloc MB/s | Receiver GC cycles/s | Receiver GC pause ms/s | Run loop busy | Queue | First-packet delay µs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| no coalescing | 10,831 | 10,776..10,897 | — | 1.53 | 1.53 | 256 | 143 | 14.1 | 0.80 | 35.4 | 28.5 |
| coalescing, `v0.62.1-fast.7` path | 10,572 | 10,347..10,630 | −2.4% | 1.19 | 1.24 | 373 | 146 | 18.3 | 0.84 | 62.6 | 56.9 |
| coalescing, copy-out | 10,678 | 10,664..10,711 | −1.4% | 1.18 | 1.22 | 378 | 147 | 17.8 | 0.77 | 50.8 | 43.5 |
| coalescing, copy-at-read | 10,932 | 10,679..10,981 | **+0.9%** | 1.18 | 1.16 | 142 | 55 | 6.6 | 0.75 | 47.3 | 37.3 |

A second pair of campaigns (G1, G2) repeats it: no coalescing 10,981, copy-at-read 11,053 Mbit/s (+0.7%), with the same CPU per GiB (1.17 and 1.16).

- **The lock part is measured.** Copy-out leaves the allocation unchanged (378 MB/s) and recovers 1.0% of throughput (**derived**: 10,572 → 10,678), with the run loop's busy share back below the no-coalescing level (0.77) and a shorter queue. In one traced run of each (below), the receiving run loop was blocked on the receive lock for 14 ms of a 3-second window with today's path, against 1 ms without coalescing and 1 ms with copy-at-read.
- **The rest goes with the delivery machinery as a whole.** Copy-at-read adds another 2.4% (**derived**) on top of copy-out. It removes the per-read allocations (receiver allocation 378 → 142 MB/s, below the 256 MB/s of no coalescing, because the binding's per-datagram address allocations are now paid once per read), and with them 63% of the receiver's GC cycles and 63% of its GC pause time. It also removes the 64 KiB pool traffic and the atomic per-view counts. These measurements do not split the 2.4% between GC and those other costs; that most of it is GC stalls on the run loop and the reader is an inference from the GC counters, not a traced attribution.
- **Net allocation added by today's path:** about 1.2 KB per coalesced read (**derived**: +117 MB/s over about 96,000 reads/s at 10,572 Mbit/s, 1,438-byte packets and 9.55 datagrams per read), after subtracting the per-datagram address allocations that coalescing saves.
- **The CPU saving is kept.** Copy-at-read keeps all of the sender's saving (1.53 → 1.18) and more of the receiver's (1.53 → 1.16, against 1.24 with today's path). Per-CPU accounting over a mid-transfer window agrees: sender CPUs' softirq time 0.63 → 0.12 CPUs and receiver system time 0.60 → 0.25 CPUs in all three coalescing arms; receiver idle 2.21 → 2.67 CPUs with copy-at-read.

### Why a few percent of stalls cost throughput with idle CPUs

Both peers have 2.1–2.7 of their 4 pinned CPUs idle in every stream arm (per-CPU `/proc/stat`). The stream is a chain of single goroutines, though, and the receiving connection's run loop is its busiest link: it spends 75–84% of the transfer outside its wait for work, and in a traced run it was running 56% of a 3-second window and waiting for a processor (runnable) another 33% (the trace inflates both). Each stall on that goroutine (a lock handoff, a GC pause or assist, a slower delivery hand-off) adds directly to the time per packet, whatever the other CPUs are doing (inferred from the busy shares; individual stalls are not traced). The receiver's read loop was the other near-saturated link before coalescing (0.76 CPU-s/GiB, about 95% of a core **derived**); coalescing halves it (0.39), so after coalescing the run loop is the stage that sets the pace.

The CPU profiles also show the run loop's decryption costing more per byte when its packets were copied by the reader just before (AES-GCM decrypt 0.115 CPU-s/GiB without coalescing, 0.128 with today's path, 0.160 with copy-at-read; one profile each). The likely cause, inferred and not traced, is that the run loop reads lines the reader core has just written. It does not decide throughput: copy-at-read has the costliest decrypt and the highest throughput.

### The acknowledgment cadence is a correlate

Sender-side counters over the transfer window (pooled F):

| Stream arm | ACK frames per GiB | Packets per ACK | Reported ack delay µs | RTT sample µs | Window cutbacks/s | Unprocessed-queue drops per run |
| --- | --- | --- | --- | --- | --- | --- |
| no coalescing | 29,152 | 27.0 | 26.0 | 141 | 3.3 | 854 |
| coalescing, today's path | 25,761 | 30.5 | 58.6 | 151 | 4.1 | 590 |
| coalescing, copy-out | 26,127 | 30.1 | 45.2 | 139 | 2.6 | 442 |
| coalescing, copy-at-read | 26,437 | 29.7 | 40.1 | 129 | 1.6 | 282 |

- The receiver acknowledges once per batch its run loop processes (up to 32 packets, [`connection.go` L1050-L1100](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L1050-L1100), then [L774](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L774)). Coalesced reads arrive in bursts of about 9.5 datagrams, so batches are fuller (72% → 82–88% full 32-packet batches) and acknowledgments fewer. That stays true with copy-at-read (−9% ACK frames per GiB), which restores throughput, so fewer acknowledgments do not cost throughput here.
- What the cost does change is the delay: with today's path, packets wait twice as long between read and processing, the reported ack delay doubles (26 → 59 µs), and the sender's window is cut more often. Copy-at-read brings the delay most of the way back and has the fewest cutbacks and drops of all four arms.
- **The filtered qlog agrees but perturbs.** The #1818 tracer, refiltered to keep only acknowledgment-bearing packets, recovery metrics, losses and congestion-state changes and run on the stream sender alone, still cut the stream to 8.2–8.5 Gbit/s in every arm (two 10-second runs each), probably because the connection still builds every event that the filter then drops (inferred, not traced). So its runs say nothing about throughput. Their acknowledgment timing matches the counters: coalescing cuts acknowledgments from about 33,500 to 29,200 a second (30,300 with copy-at-read) and roughly doubles the mean reported ack delay (15 → 31 µs; 23 µs with copy-at-read), and without coalescing 60% of acknowledgments arrive within 5 µs of the previous one, against 40% with today's path.

## 3. The stock Datagram arm: GC pacing on the sender

Nothing coalesces on this arm, so coalescing can only cost, and the split in section 1 puts all of the cost on the sender. Its only coalescing reads are acknowledgments. The heap gauges (sampled every 5 ms over the transfer, G campaigns) show why:

| Datagram arm | Mbit/s | Spread | Change | Sender live heap MiB | Sender heap goal MiB | Sender GC cycles/s | Sender alloc MB/s | Receiver CPU |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| no coalescing | 3,303 | 3,292..3,314 | — | 1.15 | 4.01 | 867 | 1,866 | 3.83 |
| coalescing, today's path | 3,211 | 3,202..3,216 | −2.8% | 1.65 | 4.04 | 1,062 | 1,830 | 3.94 |
| coalescing, copy-at-read | 3,213 | 3,199..3,224 | −2.7% | 1.64 | 4.04 | 1,042 | 1,819 | 3.93 |
| copy-at-read, 2 slots | 3,224 | 3,210..3,236 | −2.4% | 1.25 | 4.01 | 887 | 1,825 | 4.10 |
| copy-at-read, 1 slot | 3,177 | 3,167..3,188 | −3.8% | 1.18 | 4.01 | 848 | 1,798 | 4.19 |

- **The heap goal is Go's floor.** The sender's live heap is about 1.15 MiB, so the goal that GOGC=100 would give it is below Go's 4 MiB minimum, and the minimum applies ([`mgcpacer.go` L57-L59, L1293-L1301](https://github.com/golang/go/blob/go1.27.1/src/runtime/mgcpacer.go#L1293-L1301)). At 1.9 GB/s of allocation that is about 870 collections a second.
- **The coalescing reader's slots are live heap.** Eight 65,535-byte slots are 0.50 MiB (**derived**), and the measured live heap rises by exactly that (1.15 → 1.65 MiB); with 2 slots by 0.10 MiB, with 1 by 0.03. With the goal pinned, every byte of it comes out of the allocation runway between collections: 2.86 → 2.36 MiB, which predicts 21% more collections (**derived**); measured, 22%.
- **The collections cost the throughput.** In the F campaigns, the same comparison with `GOGC=400` (which raises the floor to 16 MiB):

| Datagram arm | Mbit/s | Spread | Sender GC cycles/s | Sender GC pause ms/s | Sender CPU | Receiver CPU |
| --- | --- | --- | --- | --- | --- | --- |
| no coalescing | 3,298 | 3,278..3,317 | 865 | 48.3 | 5.26 | 3.81 |
| coalescing | 3,213 | 3,201..3,229 | 1,062 | 58.8 | 5.43 | 3.91 |
| coalescing, copy-at-read | 3,206 | 3,201..3,221 | 1,036 | 57.4 | 5.46 | 3.91 |
| no coalescing, `GOGC=400` | 3,648 | 3,632..3,655 | 151 | 8.9 | 4.59 | 3.27 |
| coalescing, `GOGC=400` | 3,653 | 3,643..3,662 | 157 | 9.1 | 4.57 | 3.26 |

- With `GOGC=400`, coalescing costs nothing (+0.1%), and the Datagram arm is 10.6% faster with 13% less sender CPU per GiB. Its bottleneck is the sender's send path: the goroutine that writes packets is busy 87% of the transfer, and the run loop finds the send queue full 68% of the time, so every stop-the-world pause and mark phase lands on it. A linear fit through the two `GOGC` points predicts −2.9% for the 197 extra collections a second (**derived**); measured, −2.6%.
- **Fewer slots trade GC for reads.** Two slots bring the collections back to baseline but cap a read at two datagrams, so the receiver reads more often (receiver CPU 3.83 → 4.10) and the receiver's run loop processes smaller batches, sending 20% more acknowledgments (163,746 against 135,916 per GiB) for the sender to process. Throughput stays 2.4% down. One slot is worse.
- **What this is.** It is a property of the rig's Datagram sender, not of coalescing: a process allocating 1.9 GB/s with a heap at Go's floor pays for any persistent memory, and the per-Datagram allocations are what put it there. A process with a heap above the floor, or the Datagram path with fewer allocations, would not see it. Copy-at-read neither helps nor hurts here; it keeps the same 8 slots.

## 4. Coalesced Datagrams: the GSO-probe sender

#1824's throwaway equal-size GSO sender (build B, the [Datagram GSO note](https://github.com/GridSwarm/wiremux/blob/ed76d00647568523f6b9fad1804346a09f1db024/docs/research/issue-1814-datagram-gso.md)'s probe) sends Datagrams in segmented sends, so its Datagrams do coalesce at the receiver, about 8.8 per read. It carries both mechanisms. Pooled medians, six runs per row: B1 B2 for the first three rows, BS1 BS2 for the rest (their no-coalescing row is 5,596, [5,582..5,625]).

| GSO-probe Datagram arm | Mbit/s | Spread | Change | Loss | Sender GC cycles/s | Sender live heap MiB | Sender CPU | Receiver CPU |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| no coalescing | 5,603 | 5,573..5,623 | — | 1.81% | 1,553 | 1.30 | 3.45 | 2.82 |
| coalescing, both peers | 5,247 | 5,212..5,292 | −6.4% | 0.62% | 1,689 | 1.68 | 3.20 | 2.47 |
| coalescing, both, copy-at-read | 5,280 | 5,254..5,308 | −5.8% | 0.77% | 1,666 | 1.66 | 3.22 | 2.37 |
| receiver only | 5,476 | 5,434..5,499 | −2.1% | 0.84% | 1,467 | 1.21 | 3.06 | 2.47 |
| receiver only, copy-at-read | 5,559 | 5,538..5,595 | −0.7% | 1.16% | 1,489 | 1.21 | 3.06 | 2.36 |
| sender only | 5,332 | 5,315..5,342 | −4.7% | 1.41% | 1,744 | 1.77 | 3.62 | 2.83 |
| no coalescing, `GOGC=400` | 8,496 | 8,396..8,565 | +51.8% | 1.60% | 364 | 1.49 | 2.52 | 2.05 |
| coalescing, `GOGC=400` | 7,641 | 7,592..7,671 | −10.1% against `GOGC=400` | 0.38% | 325 | 1.68 | 2.20 | 1.75 |
| coalescing, copy-at-read, `GOGC=400` | 7,665 | 7,618..7,733 | −9.8% against `GOGC=400` | 0.50% | 328 | 1.69 | 2.22 | 1.71 |

- **At Go's default GC, both mechanisms add up.** The receiver's share (−2.1%) is the delivery path of section 2, and copy-at-read removes most of it (−0.7%). The sender's share (−4.7%) is the GC floor of section 3: the sender allocates 3.2 GB/s and its collections rise 12% (1,553 → 1,744 a second) with its reader's slots. Together, −6.4%, and copy-at-read leaves the GC part (−5.8%).
- **This sender is GC-bound.** With `GOGC=400` it delivers 52% more (8,496 Mbit/s) at 27% less sender CPU per GiB. The stock sender gains 10.6% from the same change. So at the default GC, a comparison between the two senders understates the GSO lever.
- **Off the floor, coalescing still costs this sender about 9%, all on the receiver's side, and copy-at-read barely changes it.** BG1 BG2, everything at `GOGC=400`, six runs per row:

| GSO-probe Datagram arm, `GOGC=400` | Mbit/s | Spread | Change | Loss | Sender send path busy | Sender run loop finds no data | Sender CPUs idle | RTT sample µs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| no coalescing | 8,461 | 8,386..8,537 | — | 1.58% | 0.78 | 0.37 | 1.55 | 121 |
| sender only | 8,483 | 8,395..8,560 | +0.3% | 1.65% | 0.78 | 0.37 | 1.55 | 123 |
| receiver only | 7,638 | 7,528..7,659 | −9.7% | 0.36% | 0.34 | 0.49 | 2.14 | 77 |
| receiver only, copy-at-read | 7,718 | 7,667..7,828 | −8.8% | 0.54% | 0.34 | 0.50 | 2.10 | 71 |
| both, copy-at-read | 7,753 | 7,708..7,794 | −8.4% | 0.55% | 0.34 | 0.50 | 2.11 | 72 |

- **Everything is less busy, yet slower.** With the receiver coalescing, the sender's send path drops from 78% to 34% busy (its CPUs no longer run the receiver's segmentation softirq), its CPUs idle more, loss and RTT fall and window cutbacks fall from 4.8 to 1.2–1.7 a second. But the sender's run loop finds nothing to send half the time instead of 37%: the limit has moved into the sender's Datagram feed.
- **The feed is a chain of hand-offs.** wiremux passes each Datagram through two 8-slot admission queues and two pump goroutines ([`datagrams.go` L16, L51-L69](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/datagrams.go#L51-L69), [`promote.go` L418-L446](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L418-L446)). In one traced 5-second run of each, the GSO sender's application goroutine woke about 93,000 times a second, about once per 7.5 Datagrams (**derived** from the traced rate), and so did each pump. It spent 55–59% of the window runnable, waiting for a processor, and its mean wait per wake-up rose from 5.9 to 6.8 µs with the receiver coalescing, about 8% of its whole cycle per wake-up (**derived**: 10.8 → 11.6 µs running, runnable and blocked), the size of the loss. Why the wait grows when the sender's other threads are idler (fewer busy threads to pick up a woken goroutine, inferred) is not traced, and is left as a question.
- **Coalescing still cuts the receive loss.** At the default GC, loss falls 1.81% → 0.62–0.77%, and with `GOGC=400` 1.60% → 0.38–0.50%. As #1824 found, the loss that remains is the received-DATAGRAM queue's depth, which this ticket did not touch.

## What this means for the map

1. **(fork, new) Copy coalesced datagrams out at read time.** The decision for quic-go-fast is whether its coalesced delivery should copy every datagram into ordinary packet storage when the read is decoded, as the probe does (`fix-knobs.diff` in the evidence), instead of the slab, views, atomic count and the retention copy under the receive lock. What the fork would need to settle: the Windows reader's equivalent path; whether the slab and its ADR 0005 atomic exception are still needed for anything; datagrams above the 20 KiB packet tier; and that each reader then keeps 512 KiB of slots for its whole life (**derived**: 8 × 64 KiB). Measured value in this cell: stream throughput +0.7–0.9% over no coalescing instead of −2.4–2.8%, with the CPU saving kept, receiver GC cycles −62%, and fewer drops and window cutbacks.
2. **(wiremux) Turn native receive coalescing on after that fork change.** The wiremux side is unchanged from #1824: `allowReceiveCoalescing` at [`endpoint.go` L222](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/endpoint.go#L222) plus one `COMPATIBILITY.md` sentence. On `v0.62.1-fast.7` as it is, coalescing trades 2.4–2.8% of stream throughput for its CPU saving.
3. **(input, [Should Linux native receives own recvmmsg to drop x/net's per-message address allocations?](https://github.com/GridSwarm/wiremux/issues/1831))** This ticket no longer blocks it. Under coalescing with copy-at-read, the binding's per-read costs (the `x/net` address and wiremux's private copy, [`unicast.go` L952-L983](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L952-L983)) are paid once per 9.5 stream datagrams, so their stream value shrinks by about that factor; on Datagrams that do not coalesce they stay per datagram. Section 3 adds a reason to value allocation removal on the Datagram path in throughput, not only CPU: that path runs at Go's GC floor, where allocation is throughput.
4. **(input, [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825))** In this cell the GSO probe's Datagram rate is bound by Go's GC: its sender allocates 3.2 GB/s at the 4 MiB floor (about 1,550 collections a second), and `GOGC=400` alone takes it from 5,596 to 8,496 Mbit/s (+52%), against +10.6% for the stock sender. A comparison of the two senders in this cell should state its GC setting, or follow the per-Datagram allocation removals. With coalescing on the receiver, the GSO sender's receive loss falls by two-thirds or more. At the default GC, copy-at-read removes most of the receiver's throughput cost and the sender's is the GC floor. Off the floor, the GSO sender is bound by wiremux's Datagram feed (application → two 8-slot admission queues → the fork), and receiver coalescing costs it about 9% there through a longer wait per hand-off that this ticket did not explain (section 4). So the GSO lever's ceiling in this cell is set by GC and by the per-Datagram hand-offs before the fork, not by receive or send syscalls.
5. **(new question) Why does the Datagram feed slow down when the sender's threads are idler?** Off the GC floor, the GSO sender's application goroutine spends 55–59% of the time runnable, waiting for a processor, at one wake-up per 7.5 Datagrams, and receiver coalescing, which takes the receiver's segmentation softirq off the sender's CPUs, raises that wait from 5.9 to 6.8 µs and costs 9%. Whether the two 8-slot admission queues and their pumps should be deeper, batched or merged is a question about wiremux's Datagram feed, sharp enough for its own ticket.
6. **(new question) What does GC cost the native Datagram path?** The rig's stock Datagram sender allocates 1.9 GB/s against a 1.15 MiB live heap and runs about 870 collections a second at Go's 4 MiB floor. `GOGC=400` alone gives +10.6% throughput and −13% sender CPU per GiB. Whether the map should measure Datagrams above the floor, and how much of that a user would see, is a question for the per-Datagram allocation work rather than for coalescing. The same floor applies on macOS, so it may matter to [Where does the macOS ~1 Gbit/s native ceiling actually come from?](https://github.com/GridSwarm/wiremux/issues/1800) too (not measured there).
7. **(rig) Counters worth keeping.** The probe's transfer-window counters (run-loop and send-queue idle time, emission stop reasons, batch sizes, queue length and delay, ACK cadence), `runtime/metrics` deltas and heap gauges, the `-gro-role` split and the per-CPU `/proc/stat` window are in `wiremux-probe-1829.diff` and `counters1829.diff`; they answered this ticket without a profiler.

## Evidence

All runs are in the rig's `netns` cell: namespaces `nr-send` and `nr-recv` on minimax (Ubuntu 26.04, Linux `7.0.0-30-generic`, Ryzen AI MAX+ 395), joined by `veth` at MTU 1500, veth GRO off (the default) throughout, sender pinned to CPUs 4–7 and receiver to 12–15. It is a shape cell: no real NIC, no hardware offload, both peers on one host, and the receive path's softirq runs on the sender's CPUs (section 1). Its absolute numbers are not Linux numbers.

- **Builds** (throwaway, never pushed), all from `v0.62.1-fast.7`: `qgf-1829` is #1824's build A (passive counters) plus passive #1829 counters and goroutine profile labels; `qgf-1829-fx` adds the copy-out, copy-at-read and slot-count knobs (all off = `qgf-1829`); `qgf-1829b-fx` adds #1824's equal-size Datagram GSO probe sender to that. The wiremux probe adds `-gro-role`, `-nosockopt`, `-gogc` and the fix flags to the rig and records counters, `runtime/metrics` deltas and heap gauges over each transfer window.
- **Campaigns** (2026-10-13, each `REPS=3 WARMUP=1 SECS=10`, standard slate plus the ticket's arms, minimax load1 0.2–3.2 at run starts, no run flagged): S1 S2 (18:19–18:45Z, per-peer and `-nosockopt` split), F1 F2 (18:47–19:11Z, copy-out, copy-at-read and `GOGC=400`), G1 G2 (19:13–19:35Z, slot counts and heap gauges), B1 B2 (19:35–19:53Z, GSO-probe sender), BS1 BS2 (19:57–20:20Z, GSO-probe sender per peer and with `GOGC=400`), BG1 BG2 (20:20–20:41Z, GSO-probe sender per peer at `GOGC=400`). Pooled medians are over the six non-warm-up runs of the two campaigns; every per-campaign median is in the evidence directory, and the pairs agree within 1% on every native arm.
- **Outside campaigns:** one 5-second Go execution trace per case on both peers (stream without coalescing, receiver-only coalescing, and that with copy-at-read; the GSO-probe sender at `GOGC=400` without and with receiver coalescing; summarized per goroutine with a small `x/exp/trace` tool), one 10-second CPU profile per case on both peers, and two 10-second runs per case with a filtered qlog on the stream sender only. Traced and profiled runs are single runs: their mechanisms are evidence, their throughput is not.
- **Counter caveats:** with `UDP_GRO` on, Linux counts coalesced reads as datagrams, so the rig's `stack` column means nothing for coalescing arms (as in #1824). "Run loop busy" counts everything outside the run loop's wait for work, including time blocked on locks or preempted; the wake-up latency after a wait counts as waiting. The heap gauges exist only from the G campaigns on, and the per-CPU window only from F on.

Directory: `/Volumes/worktrees/wiremux/native-gap-evidence/1829-gro-throughput/` on mbp128 (README.txt, campaign scripts, `an1829.py` → `an-split.txt`, `an-fix.txt`, `an-g.txt`, `an-b.txt`, `an-bs.txt`, `an-bg.txt`, the diffs, fork copies, campaign directories, `trace/`, `trace-b/`, `prof/`, `qlog/`, `tools/tracegs`).
