# fast.8 native adoption and dependency evidence

Slice [5.1](../adr/2026-10-19-bundle-adoption-plan.md#slice-51--repin-onto-the-bundle-release-with-the-dependency-evidence-record), child [#1925](https://github.com/GridSwarm/wiremux/issues/1925), qualifies the program's native fork lane at `github.com/the-sarge/quic-go-fast v0.62.1-fast.8`. The ordinary graph remains upstream quic-go `v0.62.0`, without a replacement. This is an internal adoption record, not a wiremux release, advertised fork selection, or throughput claim. The [repair audit](../adr/2026-10-23-bundle-adoption-repair-audit.md) owns prior failed runs; they are not certification here.

## Identity

The [published fork prerelease](https://github.com/the-sarge/quic-go-fast/releases/tag/v0.62.1-fast.8) was published on 2026-10-23 at 05:32:35 UTC, non-draft and prerelease. The release API reports `immutable: false`; this record pins the observed identity rather than claiming GitHub-enforced immutability.

| Identity | Value |
| --- | --- |
| Tag | `v0.62.1-fast.8` |
| Source commit | `8095c72244755f0c1e24f4158253bf09cfbe6e17` |
| Annotated tag object | `da8ef60b17aec90d2745bc5b0f5dd5a69cace033` |
| Public-proxy module sum | `h1:zfSVC+3U5nypmRaZASfavBZSCPXqQ7Ite7XWrLbSLWA=` |
| Public-proxy go.mod sum | `h1:kzQzvSE26oBNHy1O/XK5lZY6fBE6ba5/o6+34xsu8v4=` |
| Upstream base | quic-go `v0.62.0`; the bundle stays on the ordinary graph's v0.62 minor |
| Comparison release | `v0.62.1-fast.7` |

Both module archives were resolved with `GOPROXY=https://proxy.golang.org`, `GOSUMDB=sum.golang.org`, and empty `GOPRIVATE`, `GONOPROXY`, and `GONOSUMDB`. `go mod verify` passed for the copied fork graph. Inspection used files extracted from those module ZIPs, not a fork checkout. The release's [bundle issue #851](https://github.com/the-sarge/quic-go-fast/issues/851) and all six consumer gate issues are closed.

## What the release carries

With wiremux slice [6.1](../adr/2026-10-19-macos-native-stack-plan.md#slice-61--acknowledge-every-16-on-native-transports), native connections acknowledge every 16 ack-eliciting packets (1 ms group cap, Reno only). The native endpoint enables the optional fork capability before transport initialization after checking both native configurations' fork-reported congestion controller; absent capability or a sender other than Reno retains the default rule. Upgraded QUIC Wires retain their acknowledgment behavior.

All eleven fork slices ship. A closed gate can represent a measured pass, an amended reading, or an explicitly accepted cost; these distinctions survive adoption. The [Track 4 contract](../adr/2026-10-19-fork-bundle-plan.md) owns the thresholds and amendments. Historical figures describe the cited revisions and cells, not a new measurement of fast.8.

| Slice | Shipping behavior and default | Consumer disposition; wiremux switch |
| --- | --- | --- |
| F1 | Received-DATAGRAM queue: 1,024 entries on every fork connection; newest full-queue arrivals discarded; `DatagramReceiveDropsV1() uint64`. | [4.G1 final resolution](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6323452830): pass on final F5 `2a83ed29` under the owner's smoothed-RTT reading. Full-queue discards only, not every discard reason. Arrives with this fork selection. |
| F2 | `DelegateNetworkAdmissionV1() error`, opt-in after network admission registration and before initialization; skips both admission callbacks while retaining structural and fixed-peer checks. Off by default. | [Fork contract and tests](https://github.com/the-sarge/quic-go-fast/issues/852#issuecomment-6275557082). Permission withheld here; wiremux 5.2 owns adoption. |
| F3 | Linux GRO copies at read time; eight reader-owned 64 KiB slots when GRO is active. Existing permission and GRO kill switch remain. | [4.G4 resolution](https://github.com/GridSwarm/wiremux/issues/1940#issuecomment-6296569186): pass, stream +0.79% and receiver CPU/GiB −24.1% against coalescing off. Accepted 512 KiB slot cost; roughly 4% default-GC stock-Datagram coalescing cost is reported separately. Native receive permission stays withheld until 5.3; managed readers also receive this change. |
| F4 | Every fork connection has a 32-entry send queue; no setting. | [4.G2 record](https://github.com/GridSwarm/wiremux/issues/1938#issuecomment-6303532449) failed six original rows. [Owner decision](https://github.com/GridSwarm/wiremux/issues/1938#issuecomment-6306221100) keeps F4 with amended discard/latency readings and about 2% Thunderbolt stream slowdown accepted as an interim cost. This is not an original-threshold pass. Arrives with this fork selection. |
| F5 | Unprocessed-packet bound: 256 before handshake confirmation, 1,024 after. DATAGRAM-enabled admission accounts for queued packets plus waiting DATAGRAMs at every depth; extra slots require packets no larger than 1,452 bytes. `UnprocessedPacketDropsV1() uint64`. | [4.G1 resolution](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6323452830): pass on final `2a83ed29`, after two fork repairs and the owner's Datagram smoothed-RTT reading. Default-GC halving is judged; consumer-heap loss is reported separately. Arrives with this fork selection. |
| F6 | `ConfigureAckThresholdV1(int) error`, opt-in, range 2–32; off by default. | [Fork tests](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.8/ack_threshold_test.go). wiremux 6.1 owns the acknowledgment switch and its documentation. |
| F7 | Optional `ReadBatchSlotsV1() int` on macOS adapters, 2–64 slots; default one, ignored by managed endpoints and other platforms. Private-syscall build and environment exclusions remain. | [Fork tests](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.8/sys_conn_read_slots_darwin_test.go). wiremux 6.4 owns the opt-in; no reader grant here. |
| F8 | `maxSendBatch = sendQueueCapacity = 32`, one fork constant for Reno and BBR, no setting or kill switch. | [4.G3 record](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6329860799) failed five rows. [Owner acceptance](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6330277355) keeps cap 32 until the later macOS send work: RTT and receiver CPU costs remain recorded, not relabeled passes. Arrives with this fork selection. |
| F9 | `ConfigureSendThreadQoSV1() error`, opt-in user-initiated send-worker QoS on Apple-silicon macOS; off by default, no-op elsewhere. | [Fork contract](https://github.com/the-sarge/quic-go-fast/issues/859). wiremux 6.2 owns the opt-in and launch-context gate. |
| F10 | Equal-size short DATAGRAM gluing on by default for ordinary and BBR segmented sends, including Windows USO; 64-segment cap, a lone packet uses segment size zero. `QUIC_GO_DISABLE_SHORT_GSO_SEGMENTS=true` disables it. | [4.G5 record](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331860438) on `642f014e`: 2.48× throughput, sender/receiver CPU −57%/−53%, mean RTT +22.7 µs within 40 µs. [Owner acceptance](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331887768) and [reading](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331999513) make lifetime minimum RTT reported rather than judged. F1 and final F5 ship with it. |
| F11 | Windows copy-at-read, including managed URO-off reads; one reader-owned 64 KiB buffer, slab/retention budget retired. URO-on reads over 1,452 bytes without segment metadata are dropped and attempt lifetime URO disable; `ReceiveCoalescingFallbacksV1() uint64` counts at most once per socket. | [4.G6 record](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345139618) and [owner decision](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345797171): x64 and Arm64 accepted on `1c4a28b7`, including the full-suite-without-race/reader-race test reading, process CPU reading, and [Arm guest crash watch #1988](https://github.com/GridSwarm/wiremux/issues/1988). Native permission stays withheld until 5.4; managed readers also change now. |

## ADR-0003 call-path reconciliation

The accepted invariant is unchanged: returned packets originate from the selected peer, and writes to other destinations fail before submission. The selected-peer adapter and native binding remain its enforcement owners. Privileged descriptor setup is trusted dependency code, not a packet filter. The audit is a canonical-subset source census over [ADR-0003's path list](../adr/adr-0003-quic-selected-path-binding.md), using the [v0.62 search method](quic-go-v0.62-source-audit.md) and the [fast.6 reconciliation](../release/v0.2.4/qualification.md).

The archive comparison has 304 changed, added, or removed files overall. Searches covered production `.go` files across every platform build variant for `SyscallConn`, `syscall.RawConn`, `Control`, `ReadBatch`, `ReadMsgUDP`, `WriteMsgUDP`, `ReadFrom`, and `WriteTo`, then traced socket setup, receive, registered batch submission, probes, closes, resets, and ordinary/segmented emission. Test utilities and HTTP/3 are outside wiremux's transport; they confer no new authority on its supplied packet connection. Every production `sys_conn*.go`, managed/external packet-I/O file, `send_conn*`, `send_queue.go`, and `packet_emission*` file was compared; byte-identical owners retain their prior reconciliation.

| Path family and archive owners | Reconciliation and enforcement |
| --- | --- |
| Descriptor setup: `sys_conn.go`, buffer inspect/force helpers, all platform DF and helper files, `sys_conn_windows.go` | Existing setup uses `RawConn.Control` for options. The new Windows guard's `disableURO` uses only `SetsockoptInt(UDP_RECV_MAX_COALESCED_SIZE, 0)`. DF, ECN, packet-info, receive/send buffers, GSO/USO/GRO probes retain their owners. No new descriptor packet I/O is introduced. wiremux's guard still rejects raw `Read`/`Write`. |
| Unix receive: `sys_conn_oob.go`, `sys_conn_read_slots_{darwin,stub_darwin,other}.go`, `coalesced_read.go` | Supplied `ReadBatch` wins before fallback. Only exact `*net.UDPConn` reaches `ipv4.NewPacketConn`; other supported wrappers retain supplied `ReadMsgUDP`. F3 changes copying/lifetime; F7 changes offered slots only after an optional declaration. Neither replaces the binding's reader or admission. Linux, FreeBSD, Darwin, iOS/private-syscall exclusions were inspected. |
| Windows receive: `sys_conn_windows.go`, `coalesced_read.go` | Both ordinary and managed/coalesced paths retain supplied `ReadMsgUDP`. F11 changes buffer lifetime and missing-segment recovery; no socket read bypass is added. The managed flag retains whole-datagram delivery through the larger tier. |
| Plain receive and writes: `sys_conn.go`; OOB/segmented writes: `sys_conn_oob.go`, `sys_conn_windows.go`, `send_conn.go` | Plain paths use supplied `ReadFrom`/`WriteTo`; OOB writes use supplied `WriteMsgUDP`. Segmentation remains OOB grouping through those methods, on Linux and Windows. New `gsoSize > 0` guarding GSO-error fallback prevents a zero-size retry loop without changing destination enforcement. |
| Registered writers: byte-identical `external_packet_io.go`, `send_conn_sendmsg_x_darwin.go`, `sys_conn_sendmsg_x_darwin.go` | External/native `packetConn.writeBatch` remains the explicitly registered checked callback. The fork's private writer selects exact native UDP sockets; wrappers cannot acquire it through `udpSyscallConn`. Managed `UDPBatchWriterV1` remains behind the selected-peer lease wrapper. Its raw socket implementation is deliberately privileged, as in the separate optional-writer audit. |
| Emission: `packet_emission.go`, `packet_emission_bbr.go`, new `packet_emission_gso.go`, `send_queue.go`, transport close/reset/probe workers | F4/F8 change bounds and F10 changes segment grouping; both congestion paths hand buffers to the same queue/send connection. DATAGRAM-only short continuations do not pack stream/control frames at the short size. Probe allowance changes still end at `SendProbe`/checked `WriteTo`; transport writes, closing packets, and stateless resets still reach supplied `WritePacket`. F9 is inert without opt-in. |
| Managed lifecycle: byte-identical `managed_packet_endpoint.go`, `managed_packet_receive_ecn.go`, `managed_packet_df_unix.go`, `managed_packet_buffers.go`; changed Linux/Windows receive installers | Exact lease binding, stale-generation rejection, active-I/O joining, DF/deadline restoration and the selected-peer wrapper are retained. Linux's installer marks its reader managed. Windows releases an ordinary lease's retained read buffer before falling back to ordinary delivery. Neither grants an old lease authority over a replacement lease. |
| Network admission and additional release changes: `transport.go`, `client.go`, `server.go` | F2 remains unregistered; `admitBound` and required capability sets are unchanged. Removal of coalesced-retention bookkeeping, setup-budget/default Retry and closing-state lifecycle changes do not replace packet methods. `DialAddr`'s family-specific socket creation is outside wiremux's supplied-socket constructors. Protocol/congestion changes elsewhere are fork-owned and covered by the fork's release evidence; this audit makes no general correctness or performance claim about them. |

The selected-path closure matrix in the plan is discharged by this table and the fork-lane suites. No new wiremux enforcement, authority owner, transitional seam, or guard mutation is introduced. The three specifically traced effects are accounted for: release changes outside F1–F11 retain packet-method submission; F10 reaches Windows only through supplied segmented writes; F11 reaches the managed Windows reader through its existing lease. No unresolved packet-I/O effect remains outside an identified owner.

## Bounds and counts

The decided record lines are preserved verbatim:

> received-DATAGRAM bound 1,024 entries, discards counted internally

[Received-Datagram queue decision](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507). The released counter covers full-queue discards only, the accepted F1 deviation.

> unprocessed-packet bound 1,024 after handshake confirmation, 256 before; drops counted internally

[Unprocessed-packet queue decision](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120). Final F5 additionally constrains combined packet/DATAGRAM backlog at every depth when DATAGRAMs are enabled; its drop count is not a count of packets discarded after acknowledgment.

The send queue has 32 entries. The batch cap is the same fork constant, without a setting or kill switch. Short-DATAGRAM gluing ships on by default with both deeper queues, under the stated owner acceptance. The admits mode stays off until 5.2; the binding continues to admit every read and write while the existing callbacks return true. Ack, QoS, read-slot and native coalescing opt-ins remain separate slices.

Both queue counts are read through 3.1's internal, normally disabled native seam and by optional interface assertions in the two raw-QUIC measurement layers. Supported zero is recorded as zero; absent methods remain absent. Measurement snapshots are taken once on endpoint Close before QUIC teardown, published only after endpoint cleanup joins, and carried through final worker/controller receipts. They are lifetime observations, not window deltas or verdict inputs; setup receipts omit them. [MEASUREMENT.md](../MEASUREMENT.md) describes the additive fields. The controller retains final transport observations through its normal, early armed/drained, and cancellation handoffs after existing reply association checks. The configuration version and older transcript decoding remain unchanged.

Count campaigns used product commit `4d90da3aa05ab12fd227fd5f19966d0a099420ba` with rig source `bb45b10ebd83c172b1aaa0781c423cddf7e88d0e` copied into a dedicated worktree and `MODFILE=.cache/fast8.mod`; `cmd/nativerig/rig.mod` was untouched. Each campaign used `REPS=3 SECS=10 WARMUP=1`, `-ballast 64 -gc-role both`, no A/B, no threshold. Entries below are receiver lifetime totals at each final snapshot for the three counted runs; every sender reported zero for both counters. Full run JSON, including warmup, remains in the retained evidence directory.

| Cell/arm | Datagram receive drops, runs 1/2/3 | Unprocessed-packet drops, runs 1/2/3 |
| --- | --- | --- |
| minimax `netns` Datagram | 0 / 0 / 1 | 3948 / 2707 / 1196 |
| minimax `netns` stream | 0 / 0 / 0 | 2156 / 1253 / 3133 |
| mbp128 → m4mini `tb` Datagram | 0 / 0 / 0 | 0 / 0 / 0 |

The rig's generic extra-count field is `unprocessed_packet_drops`, derived from this slice's `Readout.UnprocessedPacketDrops`. Its older reserved `unprocessed_drops` placeholder stays null and must not be mistaken for the observed count. This naming difference needs no rig code change. The rig pin moves only after this PR merges; the journal will cite that later commit.

## Managed mode

F3 and F11 affect upgraded `transport/quic` Wires as well as native Wires. Linux copies GRO datagrams at read time. Windows retires the slab and copies reads out of its reader-owned buffer even with managed URO off. [Fork `TestWindowsManagedReceiveHandback`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.8/managed_packet_receive_windows_test.go) and [fork `TestWindowsManagedECNCoalescedMetadata`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.8/managed_packet_ecn_windows_test.go) are the named handback and coalesced-metadata evidence. Native receive-coalescing permission stays withheld on every platform in this slice.

The macOS, Linux and Windows fork-lane `transport/quic`, adapter and production integration suites passed. No coalesced reads were observed in the captured Windows wiremux test output; those same-host receipts have no aggregate engagement recorder and therefore do not establish physical URO engagement or a zero-coalescing count. The two named fork tests supply the coalesced-path evidence.

## Executed evidence

Receipts and raw logs are retained at `/Volumes/worktrees/wiremux/native-gap-evidence/1925-fast8-adoption/`. All Go builds/tests used audited base Go 1.27.3. macOS execution was on mbp128, macOS 27.0.1 / Darwin 27.0.0 arm64; Linux execution was on minimax, Linux 7.0.0-30-generic amd64. The fork lane selects only fast.8 through a copied modfile with one replacement.

| Check | Result and boundary |
| --- | --- |
| Archive identity/census and fork graph verification | Public proxy and sum database identity above; `go mod verify` passed; all path families reconciled against fast.7. |
| Ordinary graph boundary | `go list -m -json github.com/quic-go/quic-go` reports v0.62.0, no `Replace`; root module files, advertised-fork sentence and release `FORK_VERSION` are byte-identical to base. |
| Raw measurement count cases | Red established on base, then `-race -count=1` passed upstream and fast.8 for both raw layers; fake final-value test captures nonzero values before subsequent teardown activity. |
| Transcript preservation and interrupted receipts | `TestRemoteControllerRetainsOnlyAssociatedPostArmResults`, `TestRemoteWitnessPreservesPartialResultAfterInterleavedDrain`, `TestQualificationDriverConsumesActualScenarioReceipts` passed with race; the existing interleaved-drain fixture additionally verifies nonzero nested final counts in returned and persisted incomplete results. Decoding is additive and configuration version unchanged. |
| Native seam counts | Red established for the missing unprocessed count; the full fast.8 nativequic race pass includes present/absent/zero readouts and real promoted connections offering both methods. |
| macOS fork race lane | Passed once: root, `internal/nativequic`, `internal/routeselection`, `internal/integration`, `transport/quic`, `transport/internal/adapter`, with `WIREMUX_TEST_NATIVE=required WIREMUX_TEST_MANAGED_PACKET_IO=required -race -count=1`. Includes managed reuse, selected-peer, Datagram and promotion suites. |
| Linux fork race lane | Same six packages, flags and required capabilities passed once on minimax. Both prerequisite regressions pass under fast.8. |
| Windows fork race lane | [Passed](https://github.com/GridSwarm/wiremux/actions/runs/39931664188) on `garm-wiremux-win64-n6wrbnolg44w` / `INFRAIN-00L3LD4`, windows/amd64, Go 1.27.3: all six prescribed packages with both required capability flags and `-race -count=1`. Reader source was `4d90da3a`; subsequent code changes are confined to `internal/measurement`, outside these six packages and their dependency graph. Shell and MSVC/race-linker startup failures ran no tests; the passing job used the checksum-verified job-local MinGW compiler below. No product workflow or GARM configuration changed. |
| Fork vulnerability scan | Snapshot using the fork modfile as `go.mod`, the fast.6 method: zero reachable vulnerabilities, zero vulnerabilities in imported packages; one module-only advisory. An attempted `GOFLAGS=-modfile` scan failed in package loading and is retained as a setup failure, not evidence. |
| Count campaigns | All three completed; totals above, all runs retained, per-run no-other-rig gate on minimax and load/Tart/receiver gate on Thunderbolt. No guest or GARM configuration changed. |
| Final local and hosted certification | Exact-head ordinary `task verify` and post-ready required `ci-*` results belong in the product PR's validation receipt. No historical partial pass substitutes for them. |

The Windows runner's default MSVC-targeted Clang produced race binaries that failed in ThreadSanitizer startup (error 87); forced internal linking was unavailable for its `runtime/race` objects. The passing job selected [LLVM-MinGW 20261020, UCRT x86_64](https://github.com/mstorsjo/llvm-mingw/releases/tag/20261020) inside its temporary workspace, verifying the publisher asset digest `sha256:fd5462b7f5d93b2ff981fcd3f9c7e427e47f3203c64ea91c27bcc444eebd74cd` before extraction. It reported Clang 23.1.4. The Go toolchain and race flags were unchanged. The full logs and copied fork mod/sum files are retained with the successful run's `slice-5.1-windows-fork` artifact; no compiler workaround enters the product PR.

## Boundary and next owners

This record selects fast.8 only for subsequent program native fork runs; consumers still opt into the fork explicitly under [ADR-0014](../adr/adr-0014-optional-quic-fork-integration.md). It adds no root replacement, public count, wire byte, setting, refusal rule, required capability, coalescing grant, or advertised release change. All eleven bundle slices shipped; none waits for a later fork release. Remaining wiremux switches and their gates belong to 5.2–5.4 and Track 6. Platform throughput certification remains Track 7's work. The acknowledged queue, latency, CPU, and Arm crash costs retain their Track 4 dispositions.
