# Issue #1824: native receive coalescing (GRO) and the receiver overrun

Research for [#1824](https://github.com/GridSwarm/wiremux/issues/1824) on the wayfinder map [#1794](https://github.com/GridSwarm/wiremux/issues/1794). It answers three questions: where the receiver overrun that a faster Datagram sender exposes actually drops, whether Linux receive coalescing (GRO) fits wiremux's per-datagram kernel-ingress admission, and what GRO is measured to buy. Nothing here implements a change. Two throwaway fork copies and a one-flag wiremux probe were built for measurement only, and none of them is merged or pushed.

Sources are wiremux at `origin/main` [2599a002](https://github.com/GridSwarm/wiremux/tree/2599a00292c70c9871794ce62a1266741d71d42a), the quic-go-fast fork at [`v0.62.1-fast.7`](https://github.com/the-sarge/quic-go-fast/tree/v0.62.1-fast.7), Linux [v7.0](https://github.com/torvalds/linux/tree/v7.0), and measurements in the rig's new `netns` cell on minimax. Every derived number is marked **derived**.

## Answer

- **Where the overrun drops:** in the fork's 128-entry received-DATAGRAM queue, after the packet has been acknowledged, so congestion control never sees it. With the faster GSO-probe sender, 99.6% of the receive-side Datagram loss (1.92% in all) was dropped there, and 0.4% in the 256-packet unprocessed queue. The unprocessed-queue share is the only part the sender's congestion controller sees: in all 127 native runs, the sender's declared-lost count equals the receiver's unprocessed-queue drops exactly. The socket never dropped a packet. The overrun is a buffering-depth problem between the connection's run loop and the consuming goroutine, not a read-rate problem. A 1,024-entry queue absorbs it completely. In a follow-up, the same sender's loss fell from 1.90% to 0.01% with no CPU change and +1.7% throughput, with or without GRO. Upstream quic-go has the same 128-entry queue, which discards silently.
- **Does GRO fit the admission contract:** yes, exactly. Linux merges only datagrams that share the receiving device, source and destination addresses and ports, and TOS. Those include every fact the binding's receive admission reads. So admitting each coalesced read once gives every datagram in it the verdict it would get alone. It is a one-argument change in wiremux (`allowReceiveCoalescing` at [`endpoint.go` L222](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/endpoint.go#L222)). The native endpoint already meets the fork's exclusive-socket condition, and `docs/COMPATIBILITY.md` would gain one sentence (below).
- **Measured shape (minimax `netns` shape cell, Linux 7.0):** where datagrams arrive coalesced, GRO nearly halves the receiver's read path and cuts receiver CPU by 12–18% per GiB. It also cuts the probe sender's Datagram loss by about two-thirds (1.92% → 0.69%), but the loss that remains is still in the DATAGRAM queue. It does not raise throughput here: −3.5% for the stream and −6.6% for the probe's Datagrams, consistently, with spare CPU on both peers and the cause unexplained. Datagrams from the stock sender (one `sendmsg` each) never coalesce in a veth cell, so the cell cannot show what a real NIC's GRO would give them.

## 1. Where the overrun drops

### The receive path above the socket

A received native packet passes four stages before the application has it, and two of them are bounded queues that drop when full:

1. **Transport read loop.** The fork's `oobConn.ReadPacket` reads a batch through wiremux's `packetConn.ReadBatch` and returns one packet per call ([`sys_conn_oob.go` L203-L261](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L203-L261)). The transport hands each packet to its connection's `handlePacket`.
2. **Unprocessed queue (256 packets).** `handlePacket` drops the packet if 256 are already waiting for the connection's run loop ([`connection.go` L2003-L2030](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2003-L2030), [`params.go` L43](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/protocol/params.go#L43)). A packet that arrived in a coalesced read is first copied off the shared read buffer into an ordinary one, and it is dropped if a retention budget refuses it ([`coalesced_slab.go` L115-L154](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_slab.go#L115-L154)).
3. **Received-DATAGRAM queue (128 payloads).** The run loop decrypts the packet and handles its frames. A DATAGRAM frame's payload is copied into a 128-entry queue, or silently discarded when the queue is full ([`datagram_queue.go` L93-L110](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/datagram_queue.go#L93-L110)).
4. **Application.** Wiremux has no queue of its own here: `Datagrams.Receive` calls the carrier's `ReceiveDatagram`, which calls the connection's directly ([`promote.go` L515-L531](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/promote.go#L515-L531)).

### Which drops congestion control sees

The two queues differ in what the sender learns:

- **An unprocessed-queue drop is seen.** The packet is never processed, so it is never acknowledged. The sender's loss detection declares it lost and reports a congestion event ([`sent_packet_handler.go` L852-L925](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/sent_packet_handler.go#L852-L925), [`cubic_sender.go` L199-L200](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/congestion/cubic_sender.go#L199-L200)). Datagrams are not retransmitted, so the payload is gone, but the sender slows down.
- **A DATAGRAM-queue drop is not seen.** The run loop handles a packet's frames, including the discard, before it records the packet for acknowledgment ([`connection.go` L1807-L1812](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L1807-L1812)). The packet is acknowledged normally, so the sender's congestion controller counts it as delivered and does not slow down.

### What the counters show

Both fork copies carried passive counters on every drop point above, on the sender's loss detection, and on receive batching (`counters.diff` in the evidence directory). The `netns` campaigns (Evidence, below) give, per 10-second run, pooled medians with veth GRO off:

| Sender | Arm | Application loss | DATAGRAM-queue drops | Unprocessed-queue drops | Declared lost by the sender | Socket-buffer drops |
| --- | --- | --- | --- | --- | --- | --- |
| A v0.62.1-fast.7 | `dgram` | 0.03% | 791 | 0 | 0 | 0 |
| B GSO probe | `dgram` | 1.92% | 114,638 | 410 | 410 | 0 |
| A v0.62.1-fast.7 | `stream` | — | 0 | 876 | 876 | 0 |

- **The Datagram overrun is the DATAGRAM queue.** With the faster probe sender, 99.6% of the dropped Datagrams (**derived**: 114,638 of 115,048) were discarded by the 128-entry received-DATAGRAM queue after their packets were acknowledged. Congestion control never saw them. The other 0.4% overflowed the unprocessed queue. The stock sender's 0.03% loss is entirely DATAGRAM-queue drops.
- **The unprocessed queue is exactly what the sender sees.** In all 127 native runs, the sender's declared-lost count equals the receiver's unprocessed-queue drops, packet for packet.
- **The socket never drops.** No native run in any cell recorded a socket-buffer drop.
- **The stream drops only in the unprocessed queue.** That is about 0.009% of its packets, all declared lost and retransmitted.
- **The counters close the books.** For the stock sender, sent minus received Datagrams equals the two queues' drops exactly in every run. The probe sender leaves about 250–300 Datagrams per run (0.2–0.3% of its loss) that neither receive queue accounts for. A follow-up build with one more counter (Bx) attributes all of them to the packer's DATAGRAM discard under the probe's shrunken size limit: a median of 258 per run, leaving a residual of 0 in 11 of 12 runs and −1 in one. That is the hazard the [Datagram GSO note](https://github.com/GridSwarm/wiremux/blob/ed76d00647568523f6b9fad1804346a09f1db024/docs/research/issue-1814-datagram-gso.md) predicted for [quic-go-fast#743](https://github.com/the-sarge/quic-go-fast/issues/743), a sender-side loss, not a receive one.

The overrun is therefore not a read-rate problem. Every packet reaches the receiving socket and nearly every one is read. The loss is a queue-depth problem between the connection's run loop and the application, at a point that is invisible to congestion control. 128 payloads is about 0.2 ms of buffering at the probe's ~590,000 Datagrams per second (**derived**), and about 0.37 ms at the stock sender's 350,000. Any garbage-collection pause or scheduling delay of the consuming goroutine longer than that drops Datagrams. The follow-up confirms it: with a 1,024-entry DATAGRAM queue, the same probe sender lost no Datagram at that queue in any run ([What absorbs the overrun](#what-absorbs-the-overrun-queue-depth-not-coalescing)).

## 2. Does GRO receive fit the admission contract?

Yes. Linux merges only datagrams that share every fact the binding's receive admission reads, so admitting one coalesced read gives each datagram in it exactly the verdict it would get alone. Turning GRO on is a one-argument change in wiremux, and the fork already does the splitting.

### What turning it on does

Native receive coalescing is off because the endpoint passes `false` as `allowReceiveCoalescing` ([`endpoint.go` L222](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/endpoint.go#L222)). [#1793](https://github.com/GridSwarm/wiremux/issues/1793) left it off pending a batched-receive decision. With `true`:

1. **Activation.** The fork treats a wrapper that provides `ReadBatch`, as wiremux's `packetConn` does, as eligible on Linux ([`sys_conn_oob.go` L153-L170](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L153-L170)). It sets `UDP_GRO` on the binding's socket through `SyscallConn().Control` ([L191-L194](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L191-L194), [`sys_conn_helper_linux.go` L89-L101](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_helper_linux.go#L89-L101)). Wiremux's control connection allows option control ([`unicast.go` L652-L683](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L652-L683)).
2. **Reading.** Each of the 8 batch slots gets a 65,535-byte buffer instead of a 1,452-byte one ([`sys_conn_oob.go` L213-L226](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L213-L226), [`sys_conn_helper_linux.go` L24](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_helper_linux.go#L24)). The binding requires only that all slots share one shape, which they do ([`unicast.go` L871-L918](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L871-L918)).
3. **Admission.** The binding admits each *read* (each slot the kernel filled): kernel ingress from the packet-info record, then the source peer ([`unicast.go` L952-L983](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast.go#L952-L983)). Its packet-info parser skips other control records ([`unicast_unix.go` L103-L145](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/unicast_unix.go#L103-L145)), and it copies the whole control buffer, including the kernel's `UDP_GRO` segment-size record, through to QUIC ([`packet.go` L257-L265](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/routeselection/packet.go#L257-L265)). The fork's 128-byte control buffer holds the three records a coalesced IPv4 read carries (TOS, packet info and segment size, 80 bytes **derived** from `CMSG_SPACE` on 64-bit Linux; 88 for IPv6), so nothing is truncated.
4. **Splitting.** The fork reads the segment size and splits the read into one view per datagram. Each view copies the read's source address, ECN mark and packet info ([`sys_conn_oob.go` L284-L358](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_oob.go#L284-L358), [`coalesced_delivery.go` L24-L47](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_delivery.go#L24-L47)). QUIC still sees one packet per datagram, and every queue limit above still counts datagrams, not reads.

### Why one admission per coalesced read is exact

The binding's receive admission reads three facts: the source address and port, the kernel ingress interface, and (for scoped peers) the header destination. Linux GRO only merges datagrams that agree on all of them, and on more:

| Linux v7.0 rule | Source |
| --- | --- |
| same receiving device | [`net/core/gro.c` L358](https://github.com/torvalds/linux/blob/v7.0/net/core/gro.c#L358) |
| same IPv4 protocol, source and destination address | [`net/ipv4/af_inet.c` L1521-L1524](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/af_inet.c#L1521-L1524) |
| same IPv6 source and destination, traffic class and flow label | [`net/ipv6/ip6_offload.c` L255-L268](https://github.com/torvalds/linux/blob/v7.0/net/ipv6/ip6_offload.c#L255-L268) |
| same TTL, TOS (so the same ECN mark) and DF bit | [`include/net/gro.h` L452](https://github.com/torvalds/linux/blob/v7.0/include/net/gro.h#L452) |
| same UDP ports | [`net/ipv4/udp_offload.c` L734-L738](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/udp_offload.c#L734-L738) |
| equal lengths, except that one shorter datagram may end the run; at most 64 | [`udp_offload.c` L701, L745-L778](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/udp_offload.c#L745-L778) |
| only for sockets that set `UDP_GRO` | [`udp_offload.c` L800-L814](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/udp_offload.c#L800-L814) |

`UDP_GRO` also lets the socket accept a locally built segmented (GSO) packet whole instead of having it re-segmented on delivery ([`udp.c` L3079-L3085](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/udp.c#L3079-L3085), [`include/linux/udp.h` L193-L200](https://github.com/torvalds/linux/blob/v7.0/include/linux/udp.h#L193-L200), [`udp.c` L2512-L2530](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/udp.c#L2512-L2530)). That happens over loopback and `veth`, where a sender's GSO send is never split. Such a packet came from one `sendmsg` to one destination, so its datagrams share the same facts too.

So a refused read is refused for the same reason each of its datagrams would be, and an admitted read admits datagrams that would each have been admitted. The verdict is the same; only its granularity changes. The send side already has this shape: a segmented send is admitted once per `sendmsg`, against the one peer every segment shares ([Datagram GSO note](https://github.com/GridSwarm/wiremux/blob/ed76d00647568523f6b9fad1804346a09f1db024/docs/research/issue-1814-datagram-gso.md)).

The fork attaches one condition to the permission: the caller must own the socket's packet I/O exclusively and must not reuse it after the transport closes, because the receive format stays changed ([`external_packet_io.go` L43-L48](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/external_packet_io.go#L43-L48)). The native endpoint meets it: it creates its own binding set ([`endpoint.go` L156](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/internal/nativequic/endpoint.go#L156)), `packetConn` is the only reader, and `Endpoint.Close` closes the set after every transport.

### What `COMPATIBILITY.md` would say

Today the `binding` entry says "every received datagram, including each batched datagram, is admitted" and, since #1784, "Kernel ingress is still checked per datagram" ([`COMPATIBILITY.md` L103-L105](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/docs/COMPATIBILITY.md#L103-L105)). That text describes the public `binding` package, whose reads never set `UDP_GRO` and are untouched. Native GRO changes only how the native path reaches the same verdicts, so the entry would gain one sentence in the style of the #1784 exception, for example:

> On Linux, native transports read with receive coalescing. Datagrams the kernel delivers in one coalesced read share their source, destination, receiving interface and ECN mark, and they are admitted together, once per read, with the verdict each would receive alone.

No error kind, refusal rule or wire byte changes, so this is a documented reading, not a contract break.

## 3. The measured shape of the gain

### Throughput, loss and CPU

Pooled medians, six 10-second runs per row from two interleaved campaigns. CPU is CPU-seconds per delivered GiB. "Datagrams per read" is datagrams delivered per kernel read (8.7 means reads held about 8.7 coalesced datagrams).

| veth GRO | Sender | Arm | Receive coalescing | Mbit/s | Loss | Sender CPU | Receiver CPU | Datagrams per read |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| off | A | `dgram` | off | 3,332 | 0.03% | 5.18 | 3.73 | 1.00 |
| off | A | `dgram` | **on** | 3,250 | 0.03% | 5.34 | 3.82 | 1.00 |
| off | B | `dgram` | off | 5,635 | 1.92% | 3.39 | 2.76 | 1.00 |
| off | B | `dgram` | **on** | 5,264 | 0.69% | 3.16 | 2.44 | 8.71 |
| off | A | `stream` | off | 11,173 | — | 1.51 | 1.48 | 1.00 |
| off | A | `stream` | **on** | 10,778 | — | 1.17 | 1.21 | 9.54 |
| on | A | `dgram` | off | 3,143 | 0.01% | 5.42 | 3.89 | 1.00 |
| on | A | `dgram` | **on** | 3,069 | 0.02% | 5.57 | 4.01 | 1.00 |
| on | B | `dgram` | off | 5,658 | 1.95% | 3.40 | 2.77 | 1.00 |
| on | B | `dgram` | **on** | 5,264 | 0.69% | 3.16 | 2.46 | 8.83 |
| on | A | `stream` | off | 11,156 | — | 1.52 | 1.50 | 1.00 |
| on | A | `stream` | **on** | 10,755 | — | 1.19 | 1.23 | 9.54 |

The B sender's `stream` rows match A's within 1.5% (full table in `an.txt`). The four interleaved campaigns of each build agree within 1% on every native arm.

What the rows say:

- **Coalescing happens only when the sender segments.** In this cell, a datagram read holds several datagrams only when the sender sent them as one segmented (GSO) send: the B probe's Datagrams (about 8.7 per read) and the stream (9.5). The stock sender issues one `sendmsg` per Datagram, and those never coalesce, even with veth GRO and UDP GRO forwarding turned on (1.00 datagrams per read). The likely reason, inferred and not traced, is that each veth transmit schedules the receive poll, which runs before the next send arrives, so a one-packet send never meets another to merge with. A real NIC moderates interrupts and would merge them, but this cell cannot show that.
- **Receive coalescing cuts receiver CPU by 12–18% per GiB where it coalesces** (B `dgram` 2.76 → 2.44, `stream` 1.48 → 1.21). The sender's CPU per GiB also falls 7–23%, and it reads 7–12% fewer acknowledgment packets per GiB.
- **It cuts the probe sender's Datagram loss by about two-thirds** (1.92% → 0.69%). The remainder is still 99.6% DATAGRAM-queue drops (38,041 of 38,208 per run), so coalescing shrinks the overrun without changing where it happens.
- **It does not raise throughput in this cell.** Delivered Mbit/s fell 3.5% for the stream (11,173 → 10,778) and 6.6% for B's Datagrams (5,635 → 5,264), consistently across all four campaigns of each. With the stock sender, where nothing coalesces, it costs 2.5% throughput and 2.4% receiver CPU for the 64 KiB buffers and the copy off the shared buffer. The throughput loss is measured but not explained. Both peers have spare CPU. The sender reads 7–12% fewer acknowledgment packets per GiB, but that happens even with the stock sender, where nothing coalesces, so it is a correlate, not a mechanism.
- **veth GRO changes no conclusion for the native arms.** Coalescing ratios are identical, and rates are within 6% (the stock sender's Datagrams run 5.7% slower with it on). It moves veth onto its receive poll and a 256-entry ring ([`veth.c` L37](https://github.com/torvalds/linux/blob/v7.0/drivers/net/veth.c#L37)). That cost the unthrottled four-socket raw-UDP baseline arm 62% loss (the sending veth's `tx_dropped` rose 24.5 M in one run), a cell artifact outside the native arms.

### Where the receiver's CPU goes

One 10-second profile per case, veth GRO on, both peers (`prof/`). Cumulative CPU-seconds per delivered GiB on the receiver:

| Bucket | B `dgram` | B `dgram`, coalescing | A `stream` | A `stream`, coalescing |
| --- | --- | --- | --- | --- |
| read path (`Transport.listen`, including `ReadUnicastBatch` and `recvmmsg`) | 0.78 | **0.42** | 0.67 | **0.38** |
| per-packet decrypt and frame handling (`handleShortHeaderPacket`) | 0.48 | 0.45 | 0.31 | 0.31 |
| per-Datagram consumer (`Datagrams.Receive`) | 0.53 | 0.47 | — | — |
| copy off the coalesced buffer (`retainForRetentionQueue`) | — | 0.05 | — | 0.06 |

Coalescing nearly halves the read path, which is the part wiremux's binding and the system calls own. It leaves the per-packet decrypt and the per-Datagram consumer unchanged, and those are what fill the DATAGRAM queue.

### What absorbs the overrun: queue depth, not coalescing

The follow-up alternated Bx (B plus the packer counter, 128-entry queue) and C (the same with a 1,024-entry received-DATAGRAM queue), with veth GRO off. Pooled medians, six runs per row (`an-followup-pooled.txt`):

| Build | Arm | Mbit/s | Loss | DATAGRAM-queue drops | Unprocessed drops (= declared lost) | Packer discards (sender) | Sender CPU | Receiver CPU |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Bx, 128 | `dgram` | 5,638 | 1.90% | 114,180 | 336 | 258 | 3.40 | 2.77 |
| C, 1,024 | `dgram` | 5,735 | 0.01% | **0** | 329 | 284 | 3.33 | 2.73 |
| Bx, 128 | `dgram`, coalescing | 5,290 | 0.70% | 38,477 | 132 | 215 | 3.14 | 2.43 |
| C, 1,024 | `dgram`, coalescing | 5,293 | 0.01% | **0** | 139 | 228 | 3.13 | 2.44 |
| Bx, 128 | `stream` | 11,029 | — | 0 | 873 | 0 | 1.52 | 1.50 |
| C, 1,024 | `stream` | 11,025 | — | 0 | 720 | 0 | 1.51 | 1.50 |

A deeper queue removes the whole DATAGRAM-queue loss, at no measurable CPU cost and +1.7% delivered throughput. What remains (0.01%) is the unprocessed queue, which congestion control sees, plus the probe's own packer discards. Coalescing adds nothing to that, and it still costs 6–8% throughput. So the overrun is absorbed by buffering, not by a cheaper read. 1,024 is the only depth tested: it is sufficient in this cell, and the smallest sufficient depth is unmeasured. At the probe's rate, a full 1,024-entry queue holds about 1.7 ms of Datagrams and about 1.2 MB of payload copies per connection (**derived**: 1,024 / 590,000 per second; 1,024 × 1,191 bytes). It is only that full while the consumer lags.

## What this means for the map

1. **(fork, new decision) The received-DATAGRAM queue depth.** The 128-entry queue is the entire Datagram receive overrun, and congestion control cannot see it. The depth is inherited from upstream unchanged ([v0.62.0](https://github.com/quic-go/quic-go/blob/v0.62.0/datagram_queue.go#L14) and [v0.63.0](https://github.com/quic-go/quic-go/blob/v0.63.0/datagram_queue.go#L14)). A deeper queue removes the overrun at no measured cost. Still open: a fixed depth or a configured one; entries or bytes; the memory and latency bound; and whether discards become visible (a counter or statistic), so a consumer that sizes repair from observed loss, such as GridCast, sees them. This should be settled before any faster Datagram sender (quic-go-fast#743) is adopted, since that sender is what exposes the overrun.
2. **(wiremux, candidate lever) Native receive coalescing.** It is safe under the admission contract: a one-argument change plus one `COMPATIBILITY.md` sentence. In this cell, though, it buys 12–18% receiver CPU, costs 3.5–6.6% throughput, and does not absorb the overrun. The throughput cost is unexplained, so this evidence does not support adopting it yet. The only visible correlate is 7–12% fewer acknowledgment packets per GiB, and that appears even where nothing coalesces. Its value for one-packet sends on a real NIC cannot be measured without Linux hardware.
3. **(fork, existing) Additions for quic-go-fast#743**, for [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825):
   - The packer's discard under a shrunken limit is real: a median of 258 Datagrams per 10-second run (0.004% of those sent).
   - The probe's first-packet rule can exceed Linux's 128-segment limit and fail the send with `EINVAL`, closing the Wire. #743 needs a segment cap, and a short control packet must not set the segment size.
   - The receiver loss the faster sender exposes is the DATAGRAM queue's depth (item 1), not something receive coalescing fixes.
4. **(reuse) The fork-queue counters.** `counters.diff` and `packer-counter-over-b.diff` are the instrumentation the per-Datagram cost note asked for before judging its zero-hop send's unexplained loss ([Which per-Datagram cost reductions should native Datagrams adopt?](https://github.com/GridSwarm/wiremux/issues/1826)).

## Evidence

All runs are in the rig's new `netns` cell: two network namespaces on minimax (Ubuntu 26.04, Linux `7.0.0-30-generic`, Ryzen AI MAX+ 395), joined by a veth pair at MTU 1500. The sender is pinned to CPUs 4–7 (CCD 0) and the receiver to 12–15 (CCD 1). Every run records both veth ends' offloads. The cell is the owner's [shape-cell decision](https://github.com/GridSwarm/wiremux/issues/1794#issuecomment-6064330111), added to the rig as `codex/native-gap-rig` [7310bdad](https://github.com/GridSwarm/wiremux/tree/7310bdad9271f6da39aa0b183afc7f183286e230/cmd/nativerig). It is a shape cell: no real NIC, no hardware offload, and both peers share one host. Its absolute numbers are not Linux numbers.

- **Builds** (throwaway, never pushed): A is v0.62.1-fast.7 with passive counters only. B is A plus the [Datagram GSO note](https://github.com/GridSwarm/wiremux/blob/ed76d00647568523f6b9fad1804346a09f1db024/docs/research/issue-1814-datagram-gso.md)'s equal-size GSO probe. Both carry a wiremux probe whose `-gro` flag passes `true` as `allowReceiveCoalescing` and adds the counters to each result. A follow-up added Bx (B plus a counter on the packer's DATAGRAM discard) and C (Bx with the received-DATAGRAM queue raised from 128 to 1,024 entries).
- **Campaigns** (2026-10-09 05:00–05:57Z, minimax load 0.0–2.7): veth GRO off A1 B1 A2 B2, then veth GRO and UDP GRO forwarding on A3 B3 A4 B4. Each was `REPS=3 WARMUP=1 SECS=10` with the standard slate plus `dgram -gro` and `stream -gro`. No run was flagged. One B warm-up run failed (below). Profiles followed at 05:57Z. Follow-up campaigns Bx1 C1 Bx2 C2 ran at 06:02–06:27Z with veth GRO off, the standard slate plus `dgram -gro`, and minimax load ≤ 2.8. None was flagged.
- **Smoke checks** on 2026-10-08 (`smoke-a`, `smoke-trap`) proved the cell and are not evidence.
- **Counter caveat:** with `UDP_GRO` on, Linux's `InDatagrams` counts coalesced reads, not datagrams ([`udp.c` L2136-L2138](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/udp.c#L2136-L2138)), so the rig's `stack` column is meaningless for coalescing arms, as it already was for GSO senders. The probe counters measure loss directly instead.
- **B probe failure (input for quic-go-fast#743):** one B warm-up run (`B4/runs/r0-stream-gro`) ended when the sender's `sendmsg` returned `EINVAL`, which closed the Wire. The only Linux rule that fits is a segmented send of more than 128 segments ([`udp.c` L1147-L1150](https://github.com/torvalds/linux/blob/v7.0/net/ipv4/udp.c#L1147-L1150), [`include/linux/udp.h` L133](https://github.com/torvalds/linux/blob/v7.0/include/linux/udp.h#L133)). The probe takes the first packet's size as the segment size, so a small control packet at the head of a batch sets a tiny segment, and any segment under 160 bytes fills the 20 KiB buffer past 128 segments (**derived**). The probe was never meant to ship. #743 needs a segment-count cap and must not let a short control packet set the segment size. Upstream's rule (segment size is always the maximum) can never exceed 16 segments.

Directory: `/Volumes/worktrees/wiremux/native-gap-evidence/1824-gro-receive/` on mbp128 (README.txt, `campaign.sh`, `an1824.py` → `an.txt`, the diffs, `qgf-*` fork copies, `rig-*.mod`, campaign directories, `prof/` with binaries).
