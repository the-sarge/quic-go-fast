# Issue #1962: native late-read diagnosis

Fresh Linux runs reproduce genuine sender-zero counts, including an unflagged Datagram row in the complete reserve repeat. The historical detector still exceeds the receiver CPU/GiB gate with rig tracking disabled symmetrically. The largest measured CPU saving comes from removing the socket timestamp/control-record group, which also removes the required input and is not a valid remedy. The exact predicate or state responsible for each zero remains unresolved because the instrumented captures counted positively.

Diagnosis for [#1962](https://github.com/GridSwarm/wiremux/issues/1962), which follows the failed [slice 3.3 gate](https://github.com/GridSwarm/wiremux/issues/1924#issuecomment-6294412066). The deliverable is evidence and a recommendation for [#1924](https://github.com/GridSwarm/wiremux/issues/1924); [PR #1958](https://github.com/GridSwarm/wiremux/pull/1958) remains draft. Slice 3.2's processor-headroom rule and published targets remain shipped. This report changes no detector, threshold, API, or throughput promise.

## Contract and measurement boundary

The accepted detector counts a returning read only when its oldest admitted datagram's kernel receive timestamp is at least 5 ms before the read's return and at least 5 ms elapsed since the previous returning read. Counting begins at promotion, is monotonic and retains its value after close. The [observability plan](../adr/2026-10-19-native-observability-plan.md#slice-33--late-read-count-on-wirenative) and [H22](../adr/2026-10-19-native-gap-handoff-audit.md#handoff-decisions) retain the sender-positive cliff criterion and the -1% receiver-throughput / +2% receiver-CPU-per-GiB limits. A wait-only build is a diagnostic control, not an amendment to that definition.

The approved diagnosis contract permits an explicit non-reproduction within its fixed run budget. Conclusions are example-level for the pinned builds, environments and traffic below. Instrumented runs explain mechanisms; their rates are not uninstrumented gate evidence. No experiment patch or rig change is a maintained deliverable or part of this documentation PR. C-004's teardown-sensitive root test remains a separate implementation follow-up.

## Revisions and evidence

| Input | Pinned revision |
| --- | --- |
| Historical product base A | `462473f684617f80d47d69cf07dae657a7af0d00` |
| Historical detector B | `7455358ad5d88525c9897182f86532986c4d7f6b` |
| Rig | `bd4c120c754de4af1e4acc333e7fc504d2936600` |
| QUIC fork | `v0.62.1-fast.7`, selected by `cmd/nativerig/rig.mod` |
| Existing draft PR head at diagnosis start | `4e3bf84b6b6b56f88d6608f5f99dbe8c20e47345` |
| Report starting base | `f5c06a0ec582b732b4cbdd9ccd3869d6b7b80bcb` |

New raw evidence is retained at `mbp128:/Volumes/worktrees/wiremux/native-gap-evidence/1962-late-read-diagnosis/`: the approved contract, source issue JSON, complete worktree patches, scripts, audit outputs, binary artifacts, campaign `meta.txt` / `summary.txt` / `summary.json`, raw peer JSON and profiles. The original campaign remains separately at `native-gap-evidence/1924-late-reads/`; its receipt and triage recomputation are historical results, not fresh certification of the later draft head.

Builds use audited Go 1.27.3 with `GOTOOLCHAIN=local`. The experiment overlays change the historical root, tools and rig toolchain directives from 1.27.2 to 1.27.3 identically. Linux binaries are cross-compiled on mbp128 with `GOOS=linux GOARCH=amd64 CGO_ENABLED=0`; macOS binaries are built there with the same compiler. The Linux host's installed Go is also 1.27.3. m4mini's installed Go was audited as 1.27.2; no build, test or other non-audit Go subcommand runs there, and it executes the binary built by the approved 1.27.3 compiler.

The Linux cell uses minimax's existing `nr-send` / `nr-recv` namespaces and veth pair, sender CPUs 4-7 and receiver CPUs 12-15. Both Linux peers report `GOMAXPROCS=4`. This is the protocol's Linux shape cell without a physical NIC, not a representative-hardware throughput claim. Port 47962 separates these runs from other sessions. Traffic runs use ten-second windows; idle holds use 35 seconds. Pinned Datagram uses `-ballast 64 -gc-role both`. Ordinary readouts and the recorder are off throughout rate comparisons. `-goload-role send|recv|both` is a startup-only rig extension; the resulting peer load is retained in raw JSON.

The fresh shared-host gate checks for other `nativerig` processes, waits for Linux load1 at most 4 and inspects each running VM's live vCPU and emulator affinity before every run, with a 900-second wait cap. It blocks overlap with CPUs 4-7 or 12-15. The initial quiet-window audit found no running libvirt domains. These checks are snapshots, not a reservation of the host, and no unrelated work is stopped. The earlier overlapping allocation and the retained preliminary attempts are described below. The standard protocol's rotations, recorded warm-ups, flags and noisy-campaign rule apply. No flagged run is silently removed or replaced.

## Experiment design

The count matrix compares the accepted detector and the wait-only control under no load, sender-only load, receiver-only load and bilateral load, on pinned Datagram and stream. Three scored repetitions per row plus each detector's idle control consume the approved 54 Linux count/control runs. The twelve macOS healthy-backlog runs compare both definitions on pinned Datagram and stream; all completed, with recorded warm-ups.

The six cost blocks use A,B,A,B campaigns, each with three scored repetitions and a recorded warm-up. Compare pooled medians, retaining each campaign and all run flags. The original comparison additionally reports default-GC Datagram. One reserve block may discharge a protocol-required noisy repeat or a current-head/remedy check. At most eight separate profile/trace captures are allowed.

| Block | First build | Second build | Interpretation ceiling |
| --- | --- | --- | --- |
| H | Historical A, original tracker behavior | Historical B, original tracker behavior | Reconstructs the original comparison under the current approved toolchain |
| O | B with late tracking | B with `newLateTracker` returning nil | Measures the rig observer's contribution on the same product |
| P | A with no effective late tracking | B with late tracking disabled | Product comparison with symmetric observer work |
| C | B with tracker disabled | Same, returning-read observation bypassed | Clock/count observation group; compiler removal of unused aggregation may also contribute |
| D | Observation bypassed | Timestamp value decode bypassed, record stripping retained | Decode and aggregation group, not admission or all control parsing |
| T | Minimal timestamp processing | Same, timestamp socket option never requested | Socket timestamp/control-record group; global enablement must be audited separately |

All ablations retain packet-info admission and strip any timestamp record they receive. Their changed counter behavior is intentional and makes them diagnostic controls, not candidate implementations. Disabling the rig tracker makes `late_reads` absent; it is not interpreted as a measured zero. The diagnostic binding separately aggregates timestamp presence and the four packet-wait/read-gap combinations using the existing read-return clock. Those aggregates perturb execution and do not certify a rate or a false-negative frequency.

## Results

### Linux timestamp scope

A read-only probe of the running kernel found `netstamp_wanted=4`, deferred changes zero and `netstamp_needed_key=1` with no `nativerig` process present. That probe, `audit/key-during-A.txt`, records 06:46:07 UTC; adjacent gate entries show load-only waits between runs. The separate `audit/kernel-key-probe.txt` records `wanted=8`, deferred zero and key one without an embedded date or process census. Its 06:30:22 UTC file modification time and the preliminary `LOAD-B` warm-up admission at 06:30:12 UTC attribute it to that detector warm-up; this is inferred chronology, not a fresh campaign probe. Descriptor inspection identified timestamp-enabled IPv6 and packet sockets held by systemd-networkd; timestamp-enabled Unix logging sockets were also present. The descriptor snapshot is in `audit/timestamp-users-families.json`. Fresh probes before and after all twenty O/P/C/D/T cost campaigns also found `wanted=4`, deferred zero and key one; their snapshots are under `quiet-20261022T1130/audit/key-{before,after}-*.txt`.

[Linux's timestamp documentation](https://docs.kernel.org/networking/timestamping.html) explains that early receive timestamping is enabled across packets because the destination socket is not yet known. The [v7.0 receive-key implementation](https://github.com/torvalds/linux/blob/v7.0/net/core/dev.c#L2364-L2417) tracks references and defers key transitions; [socket enable/disable handling](https://github.com/torvalds/linux/blob/v7.0/net/core/sock.c#L3879-L3895) associates requests with socket lifetime. These upstream sources explain the mechanism; the running Ubuntu kernel's observed state is reported separately.

Consequently these comparisons do not measure the incremental cost of switching that global key from off to on: the baseline key is already enabled by unrelated host activity. The per-socket timestamp/control-record and binding costs remain measurable. A host without existing timestamp users could pay an additional global cost that this diagnosis does not quantify. No system service is stopped to manufacture a different baseline.

### Measurement stop: overlapping CPU allocation

At 07:04:22 UTC on 2026-10-22, a libvirt affinity audit found the running `wiremux-1942-uro` VM's four vCPUs pinned to CPUs 4, 5, 6 and 7, exactly the netns sender's allocation. The earlier host-state capture also showed this VM consuming CPU. The global load-average gate had admitted runs without establishing a quiet sender allocation. `audit/qualification-affinity-tools.txt` retains the affinity evidence.

The diagnosis stopped its own campaigns and retained all output. The 41 completed non-smoke scored pairs comprise 24 `LOAD-B` pairs, three `IDLE-B` pairs, nine `H-A1` pairs and five pairs from the interrupted `H-B1` campaign. They are preliminary attempts under overlapping CPU use and cannot support the planned controlled reproduction or cost attribution. They are not quietly removed from an otherwise accepted campaign. The four smoke pairs remain smoke only. No profile capture or macOS control occurred before this stop, and no reserve block was used during the preliminary attempt.

The user expected the booking to end at approximately 06:30 America/New_York and directed resumption around 07:00-07:30. The original bounded valid-run campaigns restarted at 07:33 (11:33 UTC) on 2026-10-22 under `quiet-20261022T1130/`, with the new affinity check. The 41 preliminary pairs and their complete raw output remain separately in the evidence root. The original valid-run ceiling, revisions, both 5 ms conditions and ship limits remain unchanged. The fresh sender-zero runs passed the no-VM-overlap snapshot gate, so the prior VM overlap is not a necessary explanation for the failure. This does not rehabilitate the preliminary comparisons or turn a shared-host snapshot into an exclusive reservation. `resumption.md`, `contract.md` and `quiet-20261022T1130/campaign-manifest.json` record this amendment. The timestamp-scope observations retain their snapshot limits.

### Quiet-window campaign

The first fresh accepted-detector count matrix reproduced the sender-zero failure on two of three bilateral stream runs. Their raw sender `late_reads.final` values are `488, 0, 0`; the receiver values are `0, 508, 591`. The sender zeros are present in raw JSON, with `start=end=final=window=0`, rather than absent fields or summary substitution. Receiver throughput in those runs is approximately `5.54, 9.67, 19.93` Mbit/s against the healthy stream median of 11,744.79 Mbit/s. Two bilateral stream rates are flagged at 0.57x and 2.06x their arm median, so the campaign is noisy. The approved reserve was consumed by a full 24-pair repeat, `RESERVE-LOAD-B`, retaining this campaign and every flag. The repeat also produced a genuine sender zero, described below. No additional reserve remains.

The first complete cost block pools six scored samples per build per arm, with zero flags. Receiver CPU/GiB includes user plus system process CPU divided by delivered GiB. The table retains the direction A to B; its rows are comparisons of historical revisions under the same approved Go 1.27.3 compiler, not certification of the later PR head.

| Arm | A receiver Mbit/s | B receiver Mbit/s | Throughput delta | A receiver CPU s/GiB | B receiver CPU s/GiB | CPU delta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Pinned Datagram | 3651.704 | 3589.634 | -1.700% | 3.28309 | 3.40035 | +3.572% |
| Stream | 11718.819 | 11728.595 | +0.083% | 1.46938 | 1.51525 | +3.122% |
| Default-GC Datagram | 3460.267 | 3426.966 | -0.962% | 3.73138 | 3.82767 | +2.581% |

Pinned Datagram fails both preserved no-harm limits, and stream fails the receiver CPU limit. Default-GC Datagram stays inside the -1% throughput limit but also exceeds the +2% receiver CPU limit. The historical stream throughput penalty did not reproduce in this block. The observer-control and symmetric product blocks below distinguish the rig observer from the retained product cost; the component controls and profiles below bound the remaining attribution.

### Observer control and symmetric product comparison

Each row pools six scored samples per build, with no flags. O changes only the rig observer on B; P compares historical A with B while disabling late tracking symmetrically. Negative CPU deltas mean the second build used less receiver CPU per delivered GiB.

| Block / arm | First receiver Mbit/s | Second receiver Mbit/s | Throughput delta | First receiver CPU s/GiB | Second receiver CPU s/GiB | CPU delta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| O / pinned Datagram | 3607.579 | 3620.091 | +0.347% | 3.38570 | 3.37397 | -0.346% |
| O / stream | 11753.039 | 11768.860 | +0.135% | 1.51771 | 1.51664 | -0.071% |
| P / pinned Datagram | 3645.623 | 3615.288 | -0.832% | 3.27805 | 3.38052 | +3.126% |
| P / stream | 11749.736 | 11734.908 | -0.126% | 1.46689 | 1.51660 | +3.388% |

The observer asymmetry exists in the rig, but disabling it changes the measured CPU median by less than 0.4% and does not remove the more-than-3% CPU penalty in the symmetric comparison. It is not the dominant explanation for that penalty in these runs. P falls inside the throughput limit but still exceeds the +2% CPU limit on both traffic arms. H, O and P are separate interleaved blocks; their percentage deltas must not be subtracted as an additive cost model or used to certify an unmeasured remedy.

### Returning-read clock/count control

C compares B with the rig observer disabled against the same build with `observeLateRead` bypassed. It removes clock and atomic observation together, and may let the compiler remove unused oldest-timestamp aggregation. Six scored samples per build/arm have no flags.

| Arm | Observation receiver Mbit/s | Bypass receiver Mbit/s | Throughput delta | Observation receiver CPU s/GiB | Bypass receiver CPU s/GiB | CPU delta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Pinned Datagram | 3608.916 | 3617.446 | +0.236% | 3.38251 | 3.36187 | -0.610% |
| Stream | 11746.273 | 11697.613 | -0.414% | 1.51362 | 1.51842 | +0.317% |

This block does not show a large common CPU saving from removing that observation group. Its small, opposite-direction point estimates do not prove that clocks or atomics are free, and do not assign an exact share of P's cost to them. The bypass also destroys the required count and is not a remedy. The decode and socket-timestamp controls below address the remaining product groups.

### Decode and socket-timestamp controls

D removes timestamp value decoding from the clock/count-bypassed build while retaining timestamp record identification and stripping. T then stops requesting socket receive timestamps on that minimal build. Each row pools six scored samples per build/arm, with no flags.

| Block / arm | First receiver Mbit/s | Second receiver Mbit/s | Throughput delta | First receiver CPU s/GiB | Second receiver CPU s/GiB | CPU delta |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| D / pinned Datagram | 3630.526 | 3631.281 | +0.021% | 3.35369 | 3.34593 | -0.231% |
| D / stream | 11764.301 | 11766.891 | +0.022% | 1.51294 | 1.51414 | +0.079% |
| T / pinned Datagram | 3623.842 | 3659.489 | +0.984% | 3.35083 | 3.26496 | -2.563% |
| T / stream | 11744.238 | 11700.599 | -0.372% | 1.51486 | 1.47867 | -2.389% |

The largest consistent CPU reduction is in T, the socket timestamp/control-record group. Its receiver system-CPU median falls from 1.18508 to 1.10989 s/GiB for pinned Datagram and from 0.54635 to 0.50945 for stream. User-CPU medians move from 2.18078 to 2.15461 and from 0.96805 to 0.96675, respectively. These independently calculated component medians do not add exactly to the median of total CPU; they indicate direction rather than an exact partition of the saving.

T removes per-socket timestamp/control-record work in the kernel and the extra record's traversal/copying in the binding. It does not isolate those costs from one another, and the host's global receive-timestamp key remains enabled before and after every cost campaign. The result therefore cannot be described as the cost of global packet timestamp generation. D finds little common saving in value decoding, while C finds little common saving in clock/count observation; neither proves a zero cost. T's saving is materially larger in these controlled runs, but it removes the required timestamp input and cannot serve as a semantics-preserving remedy or a ship result.

### Receiver profiles

The six planned Linux captures used receiver `perf record -F 999 -e cpu-clock -g --call-graph fp`, outside all headline campaigns. Their saved reports resolve the running binary before its remote cleanup. All report zero lost samples. They cover the receiver process and inherited execution from startup through exit, including kernel CPU; their sample fractions are not rates, exact throughput-window costs or additive differences between builds.

| Capture | Approximate samples | `parseReceivedControl` self | `observeLateRead` self | `__sock_recv_cmsgs` self | `__sock_recv_timestamp` self | `put_cmsg` self |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| A / pinned Datagram | 13K | — | — | — | — | 0.13% |
| B / pinned Datagram | 14K | 0.38% | 0.08% | 0.23% | 0.13% | 0.29% |
| A / stream | 19K | — | — | — | — | 0.33% |
| B / stream | 20K | 0.51% | 0.02% | 0.83% | 0.28% | 0.50% |
| B, tracker disabled / stream | 20K | 0.46% | 0.03% | 0.87% | 0.27% | 0.52% |
| B, observation bypassed / stream | 20K | 0.61% | — | 0.99% | 0.28% | 0.49% |

A dash means no separate reported symbol, not measured zero work; inlining, unresolved addresses and sampling limit attribution. `put_cmsg` also handles pre-existing non-timestamp control records, so its A samples are expected. The profiles locate additional kernel control-record and binding-parser work on B and show that it persists when rig tracking or returning-read observation is removed. They support the T group attribution together with process system-CPU measurements, but do not price individual instructions or establish a pure kernel-versus-binding split. Raw `recv.perf`, leaf and children reports, matching binaries and `profile-summary.json` remain in the evidence directory.

### Linux count matrix

Each row has three scored pairs. Counts below are final sender and receiver values in repetition order; complete start/end/window/rate fields remain in raw peer JSON. Flags are retained and refer to receiver-rate outliers. The `LOAD-B` bilateral stream row makes that campaign noisy and consumes the one full-campaign reserve repeat. Each `LOAD-WAIT` arm has at most one flagged run, so it does not cross the protocol's more-than-one-third rule.

| Detector | Load / traffic | Receiver median Mbit/s | Sender final counts | Receiver final counts | Flags |
| --- | --- | ---: | --- | --- | ---: |
| Accepted | none-d | 3592.704 | 0, 0, 0 | 0, 0, 0 | 0/3 |
| Accepted | none-s | 11744.785 | 0, 0, 0 | 0, 0, 0 | 0/3 |
| Accepted | send-d | 5.115 | 491, 496, 963 | 0, 0, 0 | 1/3 |
| Accepted | send-s | 5.490 | 492, 492, 490 | 0, 0, 0 | 0/3 |
| Accepted | recv-d | 59.826 | 0, 0, 0 | 495, 496, 560 | 0/3 |
| Accepted | recv-s | 118.790 | 0, 0, 0 | 491, 493, 490 | 0/3 |
| Accepted | both-d | 5.025 | 488, 477, 482 | 493, 492, 489 | 0/3 |
| Accepted | both-s | 9.669 | 488, 0, 0 | 0, 508, 591 | 2/3 |
| Wait-only | none-d | 3627.594 | 0, 0, 0 | 0, 0, 0 | 0/3 |
| Wait-only | none-s | 11713.332 | 0, 0, 0 | 0, 0, 0 | 0/3 |
| Wait-only | send-d | 9.988 | 961, 973, 490 | 0, 0, 0 | 1/3 |
| Wait-only | send-s | 5.490 | 943, 493, 489 | 0, 0, 0 | 1/3 |
| Wait-only | recv-d | 60.093 | 0, 0, 0 | 13303, 15231, 13384 | 0/3 |
| Wait-only | recv-s | 119.211 | 0, 0, 0 | 13403, 13625, 13578 | 0/3 |
| Wait-only | both-d | 5.075 | 502, 486, 475 | 1017, 991, 403 | 0/3 |
| Wait-only | both-s | 5.555 | 483, 503, 40 | 980, 1018, 1337 | 1/3 |

The healthy Linux controls and all six 35-second scored idle pairs are zero on both peers and both definitions. Sender-only load makes the sender positive and leaves the receiver zero; receiver-only load does the converse. The wait-only bilateral stream sender finals are 483, 503 and 40, with the third run's rate flagged at 1.41x its arm median. The reserve accepted-detector stream finals below are also all positive: 503, 507 and 657. These independent stochastic runs do not identify which predicate or state failed in the original accepted-detector zero runs. The counts supply neither a returning-read denominator nor a wait/gap, timestamp or arming distribution, and changing the predicate can change execution phase. The Thunderbolt control below reproduces the healthy-backlog false positive and rejects the wait-only change as a remedy under the current definition.

### Complete reserve repeat

`RESERVE-LOAD-B` repeats all eight accepted-detector traffic arms, with three scored pairs per row and a recorded warm-up. No arm has more than one of three flagged runs, so this complete repeat is not noisy under the protocol. Every flagged run remains in the statistics. Its healthy controls again have zero final counts on both peers.

| Load / traffic | Receiver median Mbit/s | Sender final counts | Receiver final counts | Flags |
| --- | ---: | --- | --- | ---: |
| none-d | 3604.429 | 0, 0, 0 | 0, 0, 0 | 0/3 |
| none-s | 11741.881 | 0, 0, 0 | 0, 0, 0 | 0/3 |
| send-d | 5.144 | 959, 485, 502 | 0, 0, 0 | 1/3 |
| send-s | 5.577 | 923, 491, 509 | 0, 0, 0 | 1/3 |
| recv-d | 60.268 | 0, 0, 0 | 566, 491, 499 | 0/3 |
| recv-s | 120.048 | 0, 0, 0 | 489, 491, 492 | 0/3 |
| both-d | 5.004 | 478, 483, 0 | 0, 0, 493 | 0/3 |
| both-s | 5.566 | 503, 507, 657 | 510, 510, 347 | 1/3 |

The third bilateral Datagram sender's raw `late_reads` object is present and `start=end=window=final=0`; the receiver's final count is 493. That row's receiver rates span 4.995–5.055 Mbit/s and have no flags, against the healthy Datagram median of 3604.429 Mbit/s. H22's every-cliff-sender-positive criterion therefore fails in a non-noisy repeat as well. All repeated stream senders are positive; this is a stochastic failure state, not a claim that each bilateral stream run must count zero. The repeated Datagram zero also prevents treating stream-only pacing as a complete explanation.

Across the twelve scored bilateral accepted-detector pairs in the original and reserve matrices, six have exactly one zero peer: three sender zeros and three receiver zeros; none has both peers zero. In sender/receiver order, these are original stream (488, 0), (0, 508), (0, 591) and reserve Datagram (478, 0), (483, 0), (0, 493). Every zero object explicitly contains zero start/end/window/final fields. Separately, three of the four recorded bilateral warm-ups have one zero peer; the fourth has (26, 482), so the pattern is not a universal binary state. All these bilateral runs record four progressing load goroutines on each peer. That confirms applied load, not identical scheduling or satisfaction of either read predicate. Complementary peer timing or mutual pacing remains a hypothesis; the aggregate counters do not isolate a mechanism or establish a detector false negative. The derived enumeration is retained in `quiet-20261022T1130/bilateral-peer-pattern.json`.

### Thunderbolt healthy-backlog control

The foreign #1942 claim remained held at 09:05 Eastern and had cleared by the 10:00 check. This workflow left it untouched, waited for the existing busy/foreign/load gates, then held its own bounded claim from 14:00:50 to 14:05:31 UTC. Both campaigns completed and released that claim. The cell is mbp128 `bridge0` to m4mini `bridge0` over Thunderbolt; the recorded bridge members are sender `en1 en2 en3` and receiver `en2 en3 en4`. Both run Darwin 27 arm64 and the prebuilt Go 1.27.3 binaries, with default `GOMAXPROCS` 16 on the sender and 12 on the receiver. There is no added in-process load, no readout/recorder, and the pinned Datagram arm retains `-ballast 64 -gc-role both`. `LOADGATE=1` and the shared-host gates apply before every run.

Each row has three scored ten-second pairs, plus recorded warm-ups. No scored run is flagged. Receiver CPU/GiB is reported for completeness; these controls test counter behavior and do not certify the later product head or a no-harm remedy.

| Detector / traffic | Receiver median Mbit/s | Receiver CPU s/GiB | Sender final counts | Receiver final counts |
| --- | ---: | ---: | --- | --- |
| Accepted / pinned Datagram | 1281.777 | 20.36320 | 0, 0, 0 | 0, 0, 0 |
| Accepted / stream | 1504.342 | 17.25562 | 0, 0, 0 | 0, 0, 0 |
| Wait-only / pinned Datagram | 1289.557 | 19.84321 | 0, 0, 0 | 4317, 4443, 4077 |
| Wait-only / stream | 1506.021 | 16.85027 | 0, 0, 0 | 1754, 78508, 3300 |

The wait-only receiver counts healthy saturated backlog in every scored run, while the accepted detector remains zero on both peers. This reproduces the known distinction at the pinned historical product revisions with the approved compiler. Dropping the gap predicate cannot be recommended: its positive Linux cliff counts come with a measured healthy-receiver false positive and a definition change. No run is removed because its counter differs sharply from another run; the protocol's flags concern rate, load or failure, and the receiver rates remain within its allowed band.

### Diagnostic traces: observed starvation, with a reproduction limit

The two planned instrumented sender captures completed on bilateral-load and sender-only stream traffic. Both counted positively (`488` and `487` final sender counts), so neither is a capture of the sender-zero state. Their aggregate wait/gap bins and traces can explain observed behavior but cannot identify the exact cause of the uninstrumented zero runs.

In the bilateral sender's measurement window, all 494 observed returning reads carried a timestamp and had packet wait at least 5 ms; 488 also had a read gap at least 5 ms and counted, while six had a shorter gap. In the sender-only sender, all 490 reads had packet wait at least 5 ms and 487 also had a qualifying gap. These observations reject a blanket absence of Linux receive timestamps and confirm that this detector can count the loaded sender.

The unloaded receiver in the sender-only capture shows the other distinction: 486 returning reads had a gap at least 5 ms but packet wait below 5 ms, and its count remained zero. A gap alone is therefore not evidence that an already-arrived datagram waited in the kernel. In the bilateral receiver, 501 reads had packet wait at least 5 ms with a short gap, and 502 qualified on both dimensions. Independent atomic bin snapshots are not transactional, so these are diagnostic deltas rather than a conservation proof.

The sender read goroutine in each trace spent about 5.08 s and 5.01 s ready to run over whole-trace lifetimes of 10.85 s and 10.56 s, respectively; median ready-to-run intervals were approximately 10.05 ms. A second short-lived read goroutine in each capture lived less than 0.01 ms. These state intervals include establishment and teardown and exclude a final partial interval; they are not CPU time or the rig's exact throughput window. `go tool trace` network profiles also show read blocking, and synchronization profiles place approximately 10.31 s and 10.03 s in the stream write path. Blocking time and scheduler delay coexist with packet wait; none alone establishes why a separate run counted zero.

Raw captures, Go-tool profiles, parsed trace output and the bounded state-interval interpretation are under `quiet-20261022T1130/DIAG-{BOTH,SEND}/` and `read-loop-trace.json`. All planned Linux campaigns and diagnostic captures are complete. All twelve Thunderbolt controls also completed after the foreign claim cleared. PR #1958 remains draft.

## Preservation and evidence limits

The historical B Linux test binary passed the focused `TestUnicast(LateRead|ReceiveIngressAndReturnRoute|BatchProvenance|MessagePathAllocations)` set once on minimax after the profiles. It includes timestamp/control-byte identity for IPv4 and IPv6, full QUIC control retention, malformed/missing timestamp handling, no timestamp request from public binding construction, prompt/stale/backlog/unarmed behavior, ingress/return-route and batch provenance, and the existing message-path and late-read allocation pins. The exact output is `quiet-20261022T1130/preservation-linux-b.txt`. This supports the original B fixtures; it is not evidence that a diagnostic bypass preserves the count, nor does it certify the later draft PR head or resolve C-004.

The report proposes no changed admission decision, QUIC-visible control bytes, allocation allowance, arming point or counter lifetime. Any future implementation must preserve those obligations, including monotonic values after close, and rerun its applicable tests and gate on the actual proposed revision. Report validation and hosted CI validate the documentation branch; they do not certify an experimental or product build.

## Supported explanations and remaining uncertainty

| Explanation | Evidence and disposition |
| --- | --- |
| A missing counter or summary default manufactured the zeros | Rejected for the observed failures: the typed `late_reads` objects and zero start/end/window/final values are present in the original and reserve raw sender JSON. |
| The earlier sender-CPU VM overlap is required for failure | Rejected as a necessary cause: fresh zeros occurred after pre-run checks found no running domains. The overlap still invalidates the 41 preliminary controlled comparisons. |
| The rig's asymmetric observer explains most of the CPU penalty | Not supported: O changes CPU medians by less than 0.4%, while P retains a more-than-3% penalty with symmetric observer work. |
| Returning-read clock/atomic observation or timestamp value decoding is the dominant common CPU cost | Not supported by the C/D point estimates; they are small and reverse direction on stream. This does not prove that either group is free. |
| The socket timestamp/control-record group contributes substantial receiver CPU | Supported by T's 2.4–2.6% saving, lower system CPU/GiB and receiver kernel/control-parser profiles. A pure kernel-versus-binding-copy partition remains unresolved. |
| The measurement prices global receive timestamp generation from off to on | Rejected: the global kernel key was already enabled by unrelated timestamp users. That additional cost on another host is unquantified. |
| Linux never supplies usable receive timestamps | Rejected as a blanket explanation by both diagnostic captures' stamped reads and positive counts. Per-run timestamp presence and arming/binding state in the zero captures were not instrumented, so those specific states are not ruled out. |
| A returning-read gap by itself proves a queued datagram waited | Rejected by 486 long-gap, short-wait reads on the unloaded receiver in the sender-only capture. |
| Dropping the gap condition is a measured repair | Rejected under the accepted contract: it changes the definition, and all six scored wait-only Thunderbolt receiver controls count healthy saturated backlog. All three Linux bilateral stream senders were positive on wait-only, but those independent runs do not reveal which predicate failed in the accepted detector's zero runs. |
| Stream-only pacing or flow control explains every failure | Rejected as a complete explanation because the reserve also has an unflagged Datagram sender zero. Stream blocking and bilateral traffic timing remain plausible contributors to the stream case. |
| Bilateral load guarantees both peers count, or only senders exhibit zeros | Rejected for these runs: six of twelve scored bilateral pairs have exactly one zero peer, split equally between sender and receiver zeros. Applied load is recorded on both peers; mutual pacing remains a possible explanation, not an isolated cause. |
| The exact zero mechanism has been isolated | Unresolved: the two instrumented captures show real read-loop scheduling delay and positive counts. They did not capture the zero state. Packet wait below 5 ms, a short returning-read gap, per-run timestamp/arming state and traffic/scheduling phase cannot be discriminated for the six uninstrumented scored zero-peer examples, including three sender zeros, from these records. |

## Recommendation for #1924

Keep PR #1958 draft and retain H22, both 5 ms conditions and the -1% throughput / +2% receiver CPU/GiB limits. This diagnosis has not measured a semantics-preserving remedy. Turning off socket timestamps, disabling observation or removing the gap predicate would each remove an accepted obligation, so none is a shortcut to a green gate. Changing scheduler policy, `GOMAXPROCS`, public knobs or slice 3.2's headroom rule is outside this report.

The next implementation brief should target the socket timestamp/control-record path first, because it contains the largest consistent measured CPU group; require an actual semantics-preserving candidate and a new exact-revision no-harm comparison. It should also obtain a bounded instrumented zero-state capture on both peers that records both wait/gap predicates, timestamp availability and each counted binding's arming state without confusing its instrumented rate with a ship measurement. That is new implementation/measurement work, not an extension silently added after this report's budget ceiling.

If that follow-up cannot satisfy H22 with the preserved two-condition definition, the precise product decision is whether to retain the every-cliff-sender-positive requirement and redesign the signal, or amend H22 and the claimed headroom coverage to a returning-read detector whose conjunction need not hold merely because overall throughput has collapsed. Such an amendment must explicitly state the narrower detection guarantee and the consequence for consumers; it must not be inferred from these measurements or enacted by merging this report. The current evidence proves that this B implementation fails the gate, not that every possible implementation of the accepted contract is impossible.

The six cost blocks and one reserve are exhausted. The report therefore terminates the Linux experiment campaign with the stated uncertainty; it does not spend an unapproved current-head/remedy comparison or another diagnostic capture. The twelve TB controls are complete, and their healthy-backlog result also rejects removing the gap condition. Slice 3.2 and unrelated slices continue independently.

## Evidence index and attempt accounting

Paths below are relative to `mbp128:/Volumes/worktrees/wiremux/native-gap-evidence/1962-late-read-diagnosis/`; `F/` abbreviates its `quiet-20261022T1130/` subdirectory.

| Evidence | Location |
| --- | --- |
| Approved boundaries and quiet-window amendment | `contract.md`, `resumption.md`, historical `stop-decision.md` |
| All 41 preliminary completed scored pairs, four smoke pairs, warm-ups and interrupted output | Original root campaigns `LOAD-B`, `IDLE-B`, `H-A1`, `H-B1`, `SMOKE-B`; non-binary hashes in `audit/preliminary-output-sha256.json` |
| Complete experiment overlays and prebuilt identity | `patches/{a,b,quiet,nocount,minimal,nostamp,wait,diag}.patch`, `prebuilt/`, `audit/prebuilt-manifest.json`, `F/audit/worktrees.json` |
| Fresh completed Linux count/idle and six cost blocks | `quiet-20261022T1130/{LOAD-B,LOAD-WAIT,IDLE-B,IDLE-WAIT,H-*,O-*,P-*,C-*,D-*,T-*}/` |
| Complete protocol-required reserve repeat and decision | `quiet-20261022T1130/RESERVE-LOAD-B/`, `reserve-decision.md` within that fresh root |
| Every campaign's recipe, per-run flags, ranges, user/system CPU, counters and raw output | Each campaign's `meta.txt`, `summary.txt`, `summary.json`, `runs/r*/{arm,send.json,recv.json,send.err,recv.err}` and host/network snapshots |
| Sender diagnostics and receiver profiles with matching binaries | `F/DIAG-{BOTH,SEND}/`, `F/PERF-{A-D,B-D,A-S,B-S,Q-S,N-S}/`, `F/read-loop-trace.json`, `F/profile-summary.json` |
| Raw-row arithmetic and helper sources | `F/tables.json`, `F/tables.txt`, `F/scripts/tables.py`, trace helpers and full launch scripts |
| Actual affinity, toolchain and pre-run VM/load snapshots | `F/audit/resumption-linux.txt`, `F/audit/live-peer-affinity-second.txt`, `F/gate-netns.log` |
| Kernel reference/key and unrelated socket users | Original `audit/kernel-key-probe.txt`, `audit/timestamp-users-families.json`; `F/audit/key-{before,after}-*.txt` |
| Thunderbolt controls, bounded claim and completion audit | `F/TB-{B,WAIT}/`, `F/claim.log`, `F/audit/tb-completion.json`, `F/audit/tb-output-sha256.json` |
| Completed Linux attempt/binary/source audit and frozen raw file hashes | `F/audit/linux-completion.json`, `F/audit/linux-output-sha256.json` |
| Historical gate receipt | `audit/historical-gate-receipt.md` and the separately retained `1924-late-reads/` campaign |

The completed fresh Linux work comprises 234 scored traffic/control pairs (54 count/idle, 156 cost, 24 reserve), 78 recorded warm-up pairs, and eight separate diagnostic profile/trace pairs. All output remains retained; the first noisy count campaign is included. The 41 earlier preliminary scored pairs and four smoke pairs are separate attempts, not part of the fresh comparison denominators. The twelve scored TB controls and four TB warm-up pairs also completed, bringing the fresh total to 246 scored pairs, 82 warm-up pairs and eight separate diagnostic pairs. No extra reserve or capture budget remains.
