# Relay completion characterization — R1

## Result and disposition

**Demonstrated early completion:** the proxy completion callback and runtime proxy slot can finish while a proxy-owned reader is still inside `Read`, after both socket closes have completed and the opposite direction's final byte has arrived. This is an absent reader join at the existing proxy aggregate, not evidence of a persistent production leak. R1 is complete; repair requires a new scoped architecture handoff and is not implemented here.

[Accepted R1 contract](../adr/2026-09-24-relay-completion-characterization-plan.md#slice-r1--relay-completion-characterization) · [child #1702](https://github.com/GridSwarm/wiremux/issues/1702) · [parent #1701](https://github.com/GridSwarm/wiremux/issues/1701).

## Provenance and finite evidence

Committed source head: `11ddd8d8fb6e067e5da9540894ec9df82c59425c`. The diagnostic ran on that source plus **one untracked temporary file**, `relay/handoff_completion_test.go`, reproduced below. No production or existing test source was modified. These are not claims that a pristine committed head contained or ran the diagnostic. The temporary file was removed before committing this report; the report's source is disposable historical evidence, not a maintained fixture or CI gate.

Host: darwin/arm64, installed and selected Go `go1.27.1`. The required base-toolchain audit preceded Go tests; inherited `GOTOOLCHAIN` was `auto`, with every test explicitly using `GOTOOLCHAIN=local`. No dependency changes, guard mutations, stress repetitions, external platform runs, or timing-bound experiments were made.

The first, deliberately red held-reader run used the same fixture with its held-case assertion inverted: it required `leavingRead` to be closed when completion was observed. It failed with `completion: got held owned reader, want reader exited`. Only that assertion was then changed to characterize the observed early completion; no runtime fix was made.

```sh
GOTOOLCHAIN=local go test ./relay -run '^TestHandoffRelayCompletion/held-reader-return$' -count=1 -v
```

The successful final fixture ran once normally and once with the race detector, including both named existing tail regressions:

```sh
GOTOOLCHAIN=local go test ./relay -run '^(TestHandoffRelayCompletion|TestProxyWriteFailureDrainsOppositeDirection|TestProxyShapedTailIsDeliveredAfterPeerCloses)$' -count=1 -v
GOTOOLCHAIN=local go test -race ./relay -run '^(TestHandoffRelayCompletion|TestProxyWriteFailureDrainsOppositeDirection|TestProxyShapedTailIsDeliveredAfterPeerCloses)$' -count=1 -v
```

Both commands passed, including both characterization subcases and both existing regressions; the race command reported no races. Package elapsed times were 0.179s normally and 1.195s with race instrumentation, recorded only as run output, not a timing guarantee.

| Case | Observation | Meaning |
| --- | --- | --- |
| Normal | Release channel starts open; final `F` arrives, socket closes return, callback/runtime slot complete, and the read reaches its return marker. | Baseline termination with no diagnostic hold; no claim that the reader exits before completion. |
| Held reader return | Destination write fails; second source read starts; opposite `F` arrives; underlying I/O unblocks on Close; both closes and callback/runtime slot complete while `leavingRead` remains unavailable. | Deterministic counterexample to completion implying every owned reader has exited. Cleanup releases the read even on assertion failure. |

## Completion interpretation and limits

At the recorded source head, [proxy.go](../../relay/proxy.go) waits for the two `copyAndClose` writer paths, closes the pair through `once`, signals `idle.stop`, releases the shaping stream, invokes `onDone`, and finally calls `proxyDone`. Each `copyWithActivity` launches a separate reader with no aggregate join. A destination write failure returns its writer and signals `writerDone`; a reader already inside `Read` can remain there until it is scheduled to process the socket error. The fixture extends exactly this return interval with a channel. The opposite direction drains before closure, preserving `TestProxyWriteFailureDrainsOppositeDirection` and `TestProxyShapedTailIsDeliveredAfterPeerCloses`.

[Runtime tracking](../../relay/runtime.go) removes both tracked connections and decrements its wait group in `proxyDone`. The fixture waits directly for that wait group after observing the callback; it does not call `ServeContext` or claim a complete server shutdown experiment. [ADR-0005 D1](../adr/adr-0005-runtime-shutdown-supervision.md#d1-relayservecontext-is-the-managed-relay-lifecycle-api) describes waiting for relay-owned goroutines and proxy connections to stop. The observed proxy/runtime accounting completion is weaker than that joined-work interpretation.

The scoped source inspection also found that `pairIdleMonitor.stop` signals without joining its goroutine; the optional allowance timer exits via `pairDone` without an explicit join. Shaping waits execute within the joined writer paths, and `shapingStream.release` synchronously removes the stream under the policy lock. Monitor/timer exit ordering was not separately exercised, and the temporary cases use nil shaping/allowance; the existing shaped-tail regression supplies the bounded shaping preservation evidence. No new relay-wide owner or ledger responsibility is justified by this observation.

The supported representation is the existing `net.Conn` seam: `net.Pipe` supplies the real I/O and prompt Close, a wrapper gates only the error return, and the existing `writeFailingConn` supplies EPIPE plus a controlled final tail. Channels establish ordering; five-second watchdogs and deadlines prevent test hangs, and the one-minute idle timeout keeps the normal idle path outside the intended sequence. They do not establish a product latency bound. `leavingRead` marks departure from the adapter's hold immediately before returning; it is not a reader-goroutine join. Cleanup releases the hold and closes both sides, leaving no intentionally gated reader. This is example-level evidence, not coverage of every scheduler, custom connection, restart, monitor/timer schedule, or persistent production leak. No known untraced effect of the documentation-only change remains.

## Proposed repair boundary — new handoff required

Prioritize a focused repair before cosmetic refactors, while retaining the existing proxy aggregate as the completion owner: preserve opposite-direction draining, then close both sockets, then join owned reader and monitor/timer work before publishing completion. Exclude callback self-join and retain the existing runtime timeout as bounded abandonment. Do not add a reader wait inside each `copyWithActivity`: both writers could then wait for reads that only aggregate closure can unblock. Do not close early on the first failed write, which could discard the opposite tail. Scope and audit the repair separately; R1 creates no repair child or new blocking edge for A1–F1.

## Disposable fixture source

To inspect or reproduce, place this source at `relay/handoff_completion_test.go` in a dedicated worktree at the recorded source head, run the two successful commands above, and remove it afterward. It reuses `newWriteFailingConn` from the existing `relay/relay_test.go`. Final fixture SHA-256: `8f515d77ea1dc74a1fbf69d0362d2c15ded0c332ecd0bbfb20f73c96ea6da6a2`.

```go
package relay

import (
	"io"
	"net"
	"sync"
	"testing"
	"time"
)

// Disposable R1 evidence; wrap a real pipe so Close unblocks I/O before
// the diagnostic alone holds the error return. Never hold Close itself.
type handoffReadReturnConn struct {
	net.Conn
	readingAgain  chan struct{}
	ioUnblocked   chan struct{}
	release       chan struct{}
	leavingRead   chan struct{}
	closeReturned chan struct{}
	closeOnce     sync.Once
	reads         int // only the proxy reader accesses this field
}

func (c *handoffReadReturnConn) Read(p []byte) (int, error) {
	c.reads++
	if c.reads == 2 {
		close(c.readingAgain)
	}
	n, err := c.Conn.Read(p)
	if err != nil {
		close(c.ioUnblocked)
		<-c.release
		close(c.leavingRead)
	}
	return n, err
}

func (c *handoffReadReturnConn) Close() error {
	err := c.Conn.Close()
	c.closeOnce.Do(func() { close(c.closeReturned) })
	return err
}

func TestHandoffRelayCompletion(t *testing.T) {
	for _, held := range []bool{false, true} {
		name := "normal"
		if held {
			name = "held-reader-return"
		}
		t.Run(name, func(t *testing.T) {
			wait := func(ch <-chan struct{}, what string) {
				t.Helper()
				select {
				case <-ch:
				case <-time.After(5 * time.Second):
					t.Fatalf("%s: got watchdog expiry, want completion", what)
				}
			}
			pipe, client := net.Pipe()
			left := &handoffReadReturnConn{
				Conn: pipe, readingAgain: make(chan struct{}),
				ioUnblocked: make(chan struct{}), release: make(chan struct{}),
				leavingRead: make(chan struct{}), closeReturned: make(chan struct{}),
			}
			right := newWriteFailingConn() // existing EPIPE / delayed final-tail adapter
			var releaseOnce sync.Once
			release := func() { releaseOnce.Do(func() { close(left.release) }) }
			if !held {
				release()
			}
			rt := newRelayRuntime(DefaultShutdownTimeout)
			callback := make(chan struct{})
			runtimeDone := make(chan struct{})
			t.Cleanup(func() {
				release() // unconditional, including Fatal/watchdog paths
				_ = left.Close()
				_ = client.Close()
				_ = right.Close()
				wait(runtimeDone, "cleanup runtime slot")
			})
			proxyWithRuntimePrefixes(rt, left, right, nil, nil,
				time.Minute, DefaultBlockedWriteTimeout, nil, nil,
				func() { close(callback) })
			go func() { rt.wg.Wait(); close(runtimeDone) }()
			_ = client.SetDeadline(time.Now().Add(5 * time.Second))
			if _, err := client.Write([]byte("x")); err != nil {
				t.Fatalf("initial write: got %v, want nil", err)
			}
			wait(right.writeFailed, "destination write failure")
			wait(left.readingAgain, "source second read")
			right.deliver([]byte("F"))
			var tail [1]byte
			if _, err := io.ReadFull(client, tail[:]); err != nil {
				t.Fatalf("opposite tail: got %v, want nil", err)
			}
			if tail[0] != 'F' {
				t.Fatalf("opposite tail: got %q, want F", tail[0])
			}
			wait(left.closeReturned, "prompt left Close")
			wait(right.closed, "right Close")
			wait(left.ioUnblocked, "underlying source I/O unblocked")
			wait(callback, "proxy completion callback")
			wait(runtimeDone, "runtime proxy slot completion")
			if held {
				select {
				case <-left.leavingRead:
					t.Fatal("read return: got released, want still held at completion")
				default:
				}
			}
			release()
			wait(left.leavingRead, "released read return")
			t.Logf("held=%v: tail F delivered; socket Close returned; proxy callback and runtime slot completed", held)
		})
	}
}
```
