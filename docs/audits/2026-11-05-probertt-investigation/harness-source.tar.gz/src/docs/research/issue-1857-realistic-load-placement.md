# Issue #1857: which realistic loads push the native sender off macOS performance cores

Research for [Which realistic loads push the default-class native sender onto macOS efficiency cores?](https://github.com/GridSwarm/wiremux/issues/1857) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). [Does the native send goroutine leave macOS performance cores under host load, and can a thread priority class keep it there?](https://github.com/GridSwarm/wiremux/issues/1853) loaded the sender's Mac with spinners that shared the sender's coalition, and so its thread group. This note puts three realistic kinds of load beside the native sender: CPU-bound goroutines inside the sender's own process, the way a consumer's pipeline runs beside its Wire; spinners in another program's coalition; and #1853's same-coalition spinners as the reference. It measures each with the send thread at the default class and raised to user-initiated, on today's connected shape and on the two faster shapes the map has adopted or is deciding. Nothing here implements a change.

Sources are wiremux at [#1861's](https://github.com/GridSwarm/wiremux/issues/1861) probe (local commit `f417fe0f`: the connected socket, batched sends, the acknowledgment threshold, the send-queue knobs and batched receives, each switched by a flag), with two local commits: #1853's rig readouts and this ticket's rig flags. The fork is #1861's quic-go-fast copy (`v0.62.1-fast.7` plus that ticket's knobs at their defaults) with #1853's send-thread hook added. The rig is `cmd/nativerig` from `codex/native-gap-rig` (this ticket's addition is commit `600e0707`, documented in PROTOCOL.md). Also cited: Go [1.27.2](https://github.com/golang/go/tree/go1.27.2)'s runtime, the closest xnu Apple publishes ([xnu-12377.121.6](https://github.com/apple-oss-distributions/xnu/tree/xnu-12377.121.6); both Macs run xnu-13432.1.9) and measurements taken for this note on 2026-10-17 (UTC). Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cell.** `tb` only: mbp128 (MacBook Pro M4 Max: 12 performance cores, 4 efficiency cores, Edge scheduler) sends from `bridge0` over Thunderbolt to m4mini (Mac mini M4 Pro), both macOS 27 arm64, MTU 1500. All load is on the sender's Mac; the receiver carried none. Each load runs at 12 and 24 units (in-process also at 16), started 2 s before the receiver and ended with the sender. Every cell has three 10 s runs, interleaved within each load step, 180 runs in all.

**Launch.** Every sender starts through its own `ssh mbp128` session and #1853's daemon launcher, so it has its own coalition and a daemon's QoS ceiling (user-initiated), the way a consumer started by launchd would. #1853's senders shared the agent app's coalition, and whether that app is in front can change how its thread group is treated. Two continuity cells repeat #1853's exact setup.

**Load kinds.**

- **In-process:** N CPU-bound goroutines in the sender's own process (the rig's new `-goload N`), sharing its 16 Go processors (`GOMAXPROCS`), its threads and its thread group with the transport's goroutines.
- **Another thread group:** N one-thread spinners started from a separate `ssh mbp128` session, so in their own coalition: another program's busy threads.
- **Same thread group (reference):** N spinners in the sender's own ssh session, #1853's relationship.

The rig recorded each run's coalitions. Every run had the relationship it was meant to have.

**Shapes** (flags on both peers):

- **connected:** the connected socket per peer, [adopted for macOS](https://github.com/GridSwarm/wiremux/issues/1843#issuecomment-6207453285), at the fork's acknowledgment rule.
- **batched sends:** connected, plus one `sendmsg_x` per send group ([adopted](https://github.com/GridSwarm/wiremux/issues/1860#issuecomment-6229119445)), an acknowledgment every 16 packets ([adopted](https://github.com/GridSwarm/wiremux/issues/1859#issuecomment-6224678494)) and the bundle's 32-entry send queue. This pair is receiver-bound.
- **batched receives:** batched sends plus `recvmsg_x` with eight read slots ([being decided](https://github.com/GridSwarm/wiremux/issues/1863)). This pair is sender-bound again ([What makes up the connected macOS receive goroutine's cost per datagram, and what would lower it?](https://github.com/GridSwarm/wiremux/issues/1861#issuecomment-6235012064)).

The arms are Datagrams at the GC pin (`-ballast 64 -gc-role both`) and the stream.

## Answer

**Another program's load displaces the default-class sender as much as load in its own thread group, and user-initiated keeps its whole gain there.** With 12 or 24 spinners in another coalition (another thread group), on the connected shape (**measured** medians of three; percentages **derived**):

- **Where the work runs:** 34–45% of the default-class sender's CPU ran on efficiency cores, and only 47–58% of its kernel time stayed on performance cores.
- **Default-class rates:**
  - Datagrams at the pin fell 22% and 11% (2,034 → 1,585 and 1,808 Mbit/s).
  - The stream fell 38% and 35% (2,555 → 1,595 and 1,666).
  - The same-coalition reference fell 10% and 10% (Datagrams) and 42% and 27% (stream). So #1853's caveat, that its spinners shared the sender's thread group, doesn't weaken its result.
- **User-initiated:** the send thread stayed on performance cores, with at most 0.34% of its time on efficiency cores.
  - Datagrams ran at 2,427 and 2,471 Mbit/s (+5% and +7% on unloaded).
  - The stream ran at 2,517 and 2,814 (−5% and +7%).
  - Over the default class at the same load: +53% and +37% for Datagrams, +58% and +69% for the stream (**derived**).

**A consumer's own goroutines act in two regimes, split by Go's processor count.**

- **12 CPU-bound goroutines** (4 of the 16 Go processors left over) cost the default class 15% (Datagrams) and 40% (stream), as much as 12 spinners did.
  - User-initiated recovered most of that: +5% and −13% against unloaded, +41% and +50% over the default class.
  - The raised send thread itself still spent 17–19% of its time on efficiency cores in the two runs whose thread readout listed it. Under every spinner load it spent 0.5% or less there. This note doesn't find why.
- **16 or 24 goroutines** (as many as `GOMAXPROCS`, or more) collapsed the native sender to 3–16 Mbit/s, in every shape and both classes. That is under 0.5% of its unloaded rate, with nothing lost and the sender rarely limited by its congestion window.
  - This isn't core placement. With no Go processor ever idle, a goroutine waiting on the network is woken only by the runtime's background poll every 10 ms. Once readied, it waits behind the spinners' 10 ms slices.
  - The sender read acknowledgments 24–108 times a second instead of 49,000, with 20–37 gaps of 8 ms or more in every second, and Go's scheduler latency reached a p99 of 17–67 ms (**measured**; mechanism from Go's source, section 2).
  - A thread's class can't help: user-initiated ran at 4–16 Mbit/s too.

**The faster the stack, the more the class buys under load.**

- **Batched sends** (receiver-bound when idle): user-initiated adds nothing on an idle host (3,062 against 3,068 Mbit/s for Datagrams). With 24 other-group spinners the default class lost 15% (Datagrams) and 28% (stream) while user-initiated held (+2%, +4%), a gain of +19% and +45%.
- **Batched receives too** (sender-bound): the default class lost 21% and 34% (4,035 → 3,178 and 4,684 → 3,090 Mbit/s). User-initiated ran above its unloaded rate, at 5,420 and 6,084 Mbit/s (+17%, +25%): +71% and +97% over the default class (**measured**; percentages **derived**).

**The class costs other work about 3%.** Beside a user-initiated sender, the competing spinners or goroutines made 1–10% less progress than beside a default-class one (median 3%), and in two cells more. Meanwhile the sender moved 19–97% more data (**measured**, **derived**; section 6).

| Mbit/s, medians of three (change from the same cell unloaded) | unloaded | 12 goroutines | 16 goroutines | 24 goroutines | 12 other-group | 24 other-group | 12 same-group | 24 same-group |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| connected, Datagrams, default | 2,034 | 1,729 (−15%) | 5 | 3 | 1,585 (−22%) | 1,808 (−11%) | 1,839 (−10%) | 1,838 (−10%) |
| connected, Datagrams, user-initiated | 2,317 | 2,440 (+5%) | 7 | 6 | 2,427 (+5%) | 2,471 (+7%) | 2,366 (+2%) | 2,355 (+2%) |
| connected, stream, default | 2,555 | 1,532 (−40%) | 5 | 4 | 1,595 (−38%) | 1,666 (−35%) | 1,482 (−42%) | 1,856 (−27%) |
| connected, stream, user-initiated | 2,640 | 2,301 (−13%) | 4 | 4 | 2,517 (−5%) | 2,814 (+7%) | 2,384 (−10%) | 2,792 (+6%) |
| batched sends, Datagrams, default / user-initiated | 3,068 / 3,062 | – | – | 3 / 14 | – | 2,611 (−15%) / 3,108 (+2%) | – | – |
| batched sends, stream, default / user-initiated | 3,485 / 3,500 | – | – | 4 / 4 | – | 2,511 (−28%) / 3,631 (+4%) | – | – |
| batched receives, Datagrams, default / user-initiated | 4,035 / 4,649 | – | – | 3 / 9 | – | 3,178 (−21%) / 5,420 (+17%) | – | – |
| batched receives, stream, default / user-initiated | 4,684 / 4,870 | – | – | 4 / 16 | – | 3,090 (−34%) / 6,084 (+25%) | – | – |

## 1. How each kind of load meets the sender

macOS's Edge scheduler gives each thread a scheduling bucket by its QoS class and picks its preferred core cluster per thread group and per bucket ([`sched_clutch.c` L6250-L6261](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L6250-L6261), **source**; #1853's section 1 has the rest). A thread leaves a busy performance cluster when the load there, counting threads at its own bucket and above, exceeds the efficiency cluster's. So a default-class thread competes with every busy default-class thread on the Mac, whatever its thread group. A user-initiated thread competes only with user-initiated and higher threads. That is #1853's reading of the scheduler, and this note's spinner results fit it: whether the spinners shared the sender's thread group changed little.

Goroutines in the sender's own process meet it twice. On the operating-system side their threads are default-class threads in the sender's thread group, like same-group spinners. Inside Go, they also compete for the process's 16 Go processors (`P`s), and Go has no priorities: a goroutine runs only when a `P` picks it.

## 2. The consumer's own goroutines

(**measured**; connected shape; medians of three)

| Goroutines | Datagrams default / user-initiated, Mbit/s | Stream default / user-initiated | Go scheduler latency p99, µs (default) | Acknowledgment reads per second | Gaps of 8 ms or more per second | Sender kernel time on performance cores, default / user-initiated |
| ---: | --- | --- | ---: | ---: | ---: | --- |
| 0 | 2,034 / 2,317 | 2,555 / 2,640 | 16 | 49,200 | 0.1 | 1.00 / 1.00 |
| 12 | 1,729 / 2,440 | 1,532 / 2,301 | 57 | 44,228 | 0.2 | 0.56 / 0.72 |
| 16 | 5 / 7 | 5 / 4 | 16,777 | 56 | 36.5 | – |
| 24 | 3 / 6 | 4 / 4 | 50,332 | 40 | 28.2 | – |

- **Below the processor count it is core placement.** At 12 goroutines Go's scheduler latency stayed at a p99 of 57–82 µs, and gaps of 4 ms or more between acknowledgment reads came under once a second. But 44–52% of the transport's kernel time ran on efficiency cores at the default class. The process's threads, mostly the goroutines', ran 19–21% of their time on efficiency cores. The goroutines made 6.3–6.6 billion iterations a second in all.
- **The raised send thread was displaced too.** At user-initiated the transport's kernel time was 72% on performance cores, against 81–94% under every spinner load. In the two runs where `-threads` listed the raised thread among the eight busiest, it spent 17% and 19% of its time on efficiency cores, about the same share as the goroutines' threads. In the other four, the goroutines' threads, at 7.5–9 CPU-seconds each, pushed it out of the list. Under spinners the same thread spent 0.01–0.46%. The difference between in-process load and same-coalition spinners, which share one thread group, is that the in-process threads also hand the send goroutine its Go processor. This note doesn't find why that moves the raised thread. The rate still held: +5% for Datagrams, −13% for the stream.
- **At or above the processor count it is Go's scheduler.** The sender sent no less per acknowledgment: it lost nothing, had no congestion events, and found its congestion window full on 0.1–0.5% of its send decisions, against 2.6% unloaded. It simply ran rarely. It read acknowledgments only 24–108 times a second, against 49,000 unloaded. Gaps of 8 ms or more came 20–37 times a second, so wakes were spaced about 27–50 ms apart (**derived**: 1 s / 37 to 1 s / 20). Go's scheduler latency had a p99 of 16.8–67 ms. The class made no difference: the raised thread got 0.0–0.1 CPU-seconds at user-initiated per run.
- **Why, from Go's source** (**source**, Go 1.27.2 `runtime/proc.go`):
  - A goroutine woken by another goes into that goroutine's processor's next slot. An idle processor is started only if one exists ([L1149-L1152](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L1149-L1152)).
  - A processor looking for work takes its local queue, then the global queue, and polls the network only when both are empty ([L3482-L3512](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3482-L3512)). With a spinner always queued, that poll never happens.
  - The runtime's monitor polls the network only when nobody has for 10 ms ([L6617-L6620](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L6617-L6620)), and preempts a goroutine after a 10 ms slice ([L6676-L6679](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L6676-L6679), [L6713-L6716](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L6713-L6716)).
  - A goroutine locked to its thread runs only once a processor picks it and hands itself over ([`startlockedm` L3293](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3293)), so a raised class can't jump the queue.

  So the fork's receive goroutine, parked on the socket, waits for the 10 ms poll. The run loop and the send goroutine then wait for slices behind CPU-bound goroutines.
- **The tipping point lies between 12 and 16 goroutines,** that is, once CPU-bound goroutines leave the transport fewer free processors than it has busy goroutines (its run loop, send goroutine, receive goroutine and the application's sending goroutine). This campaign didn't measure 13–15 goroutines, or a raised `GOMAXPROCS`.

## 3. Another program's load

(**measured**; spinners in a separate ssh session's coalition)

| Spinners | Shape, arm | Default Mbit/s | User-initiated Mbit/s | Class gain | Sender CPU on efficiency cores, default / user-initiated | Kernel time on performance cores, default / user-initiated | Raised thread on efficiency cores |
| ---: | --- | --- | --- | ---: | --- | --- | ---: |
| 12 | connected, Datagrams | 1,585 (−22%) | 2,427 (+5%) | +53% | 0.43 / 0.26 | 0.53 / 0.81 | 0.0003 |
| 12 | connected, stream | 1,595 (−38%) | 2,517 (−5%) | +58% | 0.45 / 0.18 | 0.50 / 0.87 | 0.0002 |
| 24 | connected, Datagrams | 1,808 (−11%) | 2,471 (+7%) | +37% | 0.34 / 0.12 | 0.58 / 0.91 | 0.0032 |
| 24 | connected, stream | 1,666 (−35%) | 2,814 (+7%) | +69% | 0.45 / 0.10 | 0.47 / 0.92 | 0.0034 |
| 24 | batched sends, Datagrams | 2,611 (−15%) | 3,108 (+2%) | +19% | 0.42 / 0.12 | 0.43 / 0.93 | 0.0046 |
| 24 | batched sends, stream | 2,511 (−28%) | 3,631 (+4%) | +45% | 0.54 / 0.10 | 0.34 / 0.94 | 0.0037 |
| 24 | batched receives, Datagrams | 3,178 (−21%) | 5,420 (+17%) | +71% | 0.39 / 0.17 | 0.51 / 0.92 | 0.0024 |
| 24 | batched receives, stream | 3,090 (−34%) | 6,084 (+25%) | +97% | 0.46 / 0.15 | 0.45 / 0.94 | 0.0024 |

- **The thread group doesn't shield the sender.** Against same-coalition spinners (section 4), other-group spinners displaced the default class as much or more: 34–54% of its CPU and 42–66% of its kernel time ran on efficiency cores. #1853's natural-load runs, against GARM VMs and system daemons, stayed on performance cores. So what spared them was most likely the load's shape (bursty, about 8–12 busy cores, not sustained busy threads), not its being another thread group.
- **The loss doesn't grow from 12 to 24.** Datagrams lost 22% at 12 spinners and 11% at 24, the stream 38% and 35%. #1853 saw the same: once the performance cores are full, more spinners mostly share the efficiency cores.
- **A receiver-bound pair still loses.** With batched sends the idle pair is receiver-bound, and its send goroutine had margin (#1856: 69–78% busy). The default class still lost 15% and 28% under 24 spinners, so displacement used up that margin and more.
- **User-initiated under load beat its own idle rate on the fastest shape.** With batched receives it ran 17% (Datagrams) and 25% (stream) above unloaded. #1853 found the same on the connected shape (a raised send call 2.42 µs under load against 3.52 µs unloaded) and traced it to performance cores clocking higher on a busy Mac. The receiving Mac then limits it: 0.48% Datagram loss with no full-socket-buffer drops, so inside the receiver, where #1861 found it mostly at the 128-entry received-Datagram queue that the fork bundle replaces.

## 4. The same thread group, and continuity with #1853

(**measured**)

| Spinners | Connected, Datagrams default / user-initiated | Connected, stream default / user-initiated | Sender CPU on efficiency cores, default (Datagrams / stream) |
| ---: | --- | --- | --- |
| 12, sender's own coalition | 1,839 (−10%) / 2,366 (+2%) | 1,482 (−42%) / 2,384 (−10%) | 0.35 / 0.52 |
| 24, sender's own coalition | 1,838 (−10%) / 2,355 (+2%) | 1,856 (−27%) / 2,792 (+6%) | 0.31 / 0.38 |
| 24, agent app's coalition (#1853's setup) | 1,648 (−17%) / 2,357 (+1%) | – | 0.39 / – |
| #1853's campaign, agent app's coalition | 1,688 at 24 (−24%) / 2,419 at 24 (+2%) | 1,844 at 24 (−30%) / 2,872 at 24 (+4%) | 0.38 / 0.41 |

- **#1853's loaded results reproduce.** Its exact setup (agent coalition, 24 spinners) ran 1,648 against its 1,688 Mbit/s at the default class, and 2,357 against 2,419 raised. The stream loss at 24 spinners (−27%) matches its −30%.
- **The idle default class is slower in this build.** It ran at 2,034 Mbit/s (1,993 in the continuity cell) against #1853's 2,225. User-initiated ran at 2,317 against 2,381. So on an idle host the class gains +14–18% here, against #1853's +7%. This campaign's build differs from #1853's (#1861's probe lineage and its counters), so every comparison here is within this campaign's interleaved runs.
- **A sender in its own coalition loses less to same-group spinners** (−10%) than one in the agent app's coalition (−17%), whose thread group also holds the app's own work.

## 5. The faster shapes

(**measured**)

- **Unloaded,** the class adds nothing on the receiver-bound batched-send pair (3,062 against 3,068 Mbit/s, 3,500 against 3,485). On the sender-bound batched-receive pair it adds +15% for Datagrams and +4% for the stream, as on the connected shape (+14% and +3%).
- **Under 24 other-group spinners,** the default class lost 15–34% on both faster shapes, and user-initiated kept or beat its unloaded rate (section 3). With the class, the fastest shape ran at 5.4 and 6.1 Gbit/s on one Wire under load.
- **Under 16 or more goroutines,** every shape collapsed alike (section 2).

## 6. What the class costs other work

(**measured** progress of the competing work, billions of iterations per second, beside a default-class / user-initiated sender; change **derived**)

| Load | Shape, arm | Other work, default → user-initiated | Sender Mbit/s, default → user-initiated |
| --- | --- | --- | --- |
| 12 goroutines | connected, Datagrams / stream | 6.45 → 6.27 (−2.8%) / 6.60 → 6.45 (−2.3%) | 1,729 → 2,440 / 1,532 → 2,301 |
| 12 other-group | connected, Datagrams / stream | 6.54 → 6.28 (−3.9%) / 6.56 → 6.33 (−3.4%) | 1,585 → 2,427 / 1,595 → 2,517 |
| 24 other-group | connected, Datagrams / stream | 6.46 → 5.83 (−9.8%) / 6.69 → 6.47 (−3.3%) | 1,808 → 2,471 / 1,666 → 2,814 |
| 24 other-group | batched sends, Datagrams / stream | 7.01 → 7.21 (+2.9%) / 7.26 → 7.14 (−1.6%) | 2,611 → 3,108 / 2,511 → 3,631 |
| 24 other-group | batched receives, Datagrams / stream | 6.80 → 6.32 (−7.1%) / 6.53 → 6.83 (+4.6%) | 3,178 → 5,420 / 3,090 → 6,084 |
| 12 same-group | connected, Datagrams / stream | 6.37 → 6.20 (−2.6%) / 6.66 → 6.48 (−2.7%) | 1,839 → 2,366 / 1,482 → 2,384 |
| 24 same-group | connected, Datagrams / stream | 6.39 → 6.32 (−1.0%) / 6.69 → 6.06 (−9.4%) | 1,838 → 2,355 / 1,856 → 2,792 |

One raised thread is one of 16 cores (6%, **derived**), which brackets these. A faster sender also does more kernel work per second for the same bytes. The sender's own CPU per GiB fell 21–43% with the class under spinner load (for example 9.20 → 6.92 CPU-s/GiB at 24 other-group spinners, Datagrams), because its work ran on faster cores (**measured**).

## Method

- **Rig addition** (`codex/native-gap-rig` [`600e0707`](https://github.com/GridSwarm/wiremux/commit/600e0707), documented in PROTOCOL.md):
  - `-goload N` starts N CPU-bound goroutines in the process before the run and reports their progress over the send window.
  - `-schedlat` reports the delta of Go's `/sched/latencies:seconds` over the send window (quantiles are histogram-bucket upper bounds).
  - The native senders mark the window.
- **Build** (one binary for every cell; nothing pushed):
  - #1861's probe `f417fe0f`, plus #1853's rig readouts (`-threads`, `proc` energy and per-class CPU, which that probe lacked) and this ticket's rig flags.
  - Built against #1861's fork copy plus #1853's send-thread hook (`WIREMUX_PROBE_SENDQOS=user-initiated` locks the fork's send goroutine to its thread and raises it; it prints the class before and after).
  - Every sender sets `WIREMUX_PROBE1851_RECVSTATS=1`, #1851's probe, which records the gaps between its receive calls that returned data, that is its acknowledgment reads.
  - go1.27.2.
- **Launch:**
  - Every sender runs through `spawnctx -type daemon` (#1853's daemon context) inside its own `ssh mbp128` session.
  - Other-group spinners run in a second ssh session; same-group spinners run in the sender's session.
  - #1853's spinner (one thread, a xorshift loop at default priority, with a hard lifetime).
  - Each run records the sender's, a spinner's and the campaign shell's jetsam coalition. All 180 runs had the intended relationship, and every user-initiated run reported `after=user-initiated`.
- **Campaign:**
  - One claim on the pair for the whole campaign, 2026-10-17 16:41–18:23 UTC.
  - Each repetition visits the load steps in a rotated order and each step's cells in a rotated order.
  - A run started only with mbp128 at most 4 busy cores in a 1 s sample (1.0–4.0, median 1.9) and m4mini's load1 at most 8.
  - A loaded run was followed by 15 s of settling.
  - A 9-run smoke campaign (5 s runs, never evidence) checked the scripts first. It showed the in-process collapse at 24 goroutines, which added the 16-goroutine step.
- **Sharing the hosts:**
  - [How much would a fork send batch cap above 8 add once the macOS receiver is faster?](https://github.com/GridSwarm/wiremux/issues/1862) held the pair until 16:36. This campaign waited for it.
  - Once, at 15:16, before that wait was set up, this session compiled the rig on mbp128 during three of that ticket's runs. It reported them so they could be flagged.
  - A quic-go-fast session held its mbp128 work until this campaign ended.
  - The overlap logger saw no other session's pair work during any run.
- **Flags:** 13 runs fell outside 0.8–1.2× of their cell's median. Ten were in collapsed cells, at 3–19 Mbit/s, where a few Mbit/s is the whole spread. The others were single fast stream runs (2,203, 3,749 and 1,791 Mbit/s against medians of 1,666, 3,090 and 1,482). None was dropped: medians of three absorb them.

## Limits

- **Synthetic load.** Spinners and goroutines are pure integer loops. A real pipeline blocks, allocates and wakes, so it leaves the transport more turns than a spinner does. The tipping point between 12 and 16 goroutines is for CPU-bound goroutines. The other-group load is one program with N busy threads, not many programs.
- **The tipping point isn't located,** and a raised `GOMAXPROCS` wasn't tried.
- **The raised thread's placement under in-process load comes from two runs.** The thread readout lists only the eight busiest threads.
- **Process CPU includes the goroutines** under in-process load, so per-GiB sender CPU isn't comparable there. Kernel time on performance cores is, because the goroutines make no system calls.
- **The idle default class ran 9% below #1853's** for reasons not found (section 4). The class's idle gain is +14–18% here against +7% there.
- **One host and one receiver, both unloaded except the sender's Mac.** Load on the receiving Mac, which binds the batched-send pair, wasn't measured.
- **Contexts are emulated,** as in #1853: daemon spawn attributes and ssh sessions, not launchd.
- **The xnu source is 12377.121.6, not the hosts' 13432.1.9,** and the performance controller that sets cluster preferences is closed source.

## Implications for the map

- **For [Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858):**
  - The lever survives realistic other-program load in full: +37–69% on the connected shape at 12–24 spinners, holding the unloaded rate.
  - It grows on the faster stack: +19–45% with batched sends, +71–97% with batched receives.
  - It costs other work about 3%.
  - Other-group spinners displace the sender as much as same-coalition ones, so a gate can use either. Other-group spinners (an ssh session or a launchd agent) are closer to a consumer's real neighbors.
  - Against a consumer that oversubscribes Go's processors it does nothing. Below that point it still recovers most of the loss, though the raised thread itself was displaced.
- **For [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801):**
  - A macOS target measured on an idle Mac overstates a busy one at the default class: by 10–42% on the connected shape (12–24 spinners or 12 goroutines) and 15–34% on the faster shapes (24 other-group spinners). With the raised send thread, busy and idle agree within −13% to +25%.
  - A consumer whose CPU-bound goroutines fill `GOMAXPROCS` gets almost nothing from a native Wire, on any shape and at either class. That is a property of Go's scheduler, so a target either assumes headroom or the transport needs a design answer (open question 1).
- **For [Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863):** on a busy sender at the default class, the batched-receive shape kept 3,178 and 3,090 Mbit/s, still above the batched-send shape's idle rate for Datagrams (3,068) and below it for the stream (3,485). With the class it reached 5,420 and 6,084.
- **Linux is untouched by the class** (no QoS classes). The in-process collapse is Go's and would apply on any platform. This campaign measured it only on macOS.

## Open questions

These are candidate tickets.

1. **What should a native Wire do when its consumer keeps every Go processor busy?** Locate the tipping point (13–15 CPU-bound goroutines here). Find out whether headroom (a raised `GOMAXPROCS`, a worker pool smaller than `GOMAXPROCS`) restores the rate. Find out whether anything inside wiremux or the fork can keep the transport's goroutines scheduled. Then decide whether it's a documented consumer requirement or a design change.
2. **Why does a raised send thread spend 17–19% of its time on efficiency cores beside the process's own busy goroutines,** but under 0.5% beside spinners in the same thread group?
3. **Does realistic load on the receiving Mac cost the batched pair, and does the receive goroutine need the class too?** (#1853's open question 4; it binds the batched-send shape.)
4. **Why is the idle class gain +14–18% in this build** against #1853's +7%?

## Evidence

`native-gap-evidence/1857-load-kinds/` (README.txt indexes it):

- `M1/`: the campaign, with each run's `cmd`, gate, coalitions, spinner lines, both result lines and counters, plus `rows.jsonl` and `tables.md`.
- `S0/`: the smoke runs.
- `bin/q1857/`: the binary and its recipe.
- `qgf-1857/`: the fork copy, a git repository with the hook commit.
- `tools/`: spinner, `spawnctx`, `coal` and the claim placeholder.
- `scripts/`: `campaign.sh`, `run.sh`, `sshsend.sh`, `sshspin.sh`, `busy.sh`, `claim*.sh`, `overlap.sh`, `hostlog.sh`, `build.sh`, `sum.py`, `agg.py`.
- `sources/`: Go 1.27.2's `proc.go` and notes.
- Logs: `coordination.log`, `overlap.log`, `hostlog.txt`, `claim.log`.
