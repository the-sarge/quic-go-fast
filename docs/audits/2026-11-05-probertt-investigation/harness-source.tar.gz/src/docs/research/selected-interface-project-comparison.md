# Selected-interface observation: project comparisons

Status: research input to the selected-interface continuity design; no production behavior is changed. Researched 2026-09-22. Wiremux baseline: `49a64cb7b91d5c236abe639c31bb73fbdad35ce7`.

Design update: the subsequent interview accepted ordinary OS binding for established Wires and withdrew removal-triggered termination. The deletion-history requirements and monitoring recommendation below explain alternatives under the earlier policy, not the latest accepted direction. See the [continuity decision](../adr/adr-0015-selected-interface-continuity.md) for current decisions and open questions.

The three projects below separate socket configuration or path selection from ordinary data transfer. They provide useful design precedents, but none of these sources establishes wiremux's proposed guarantee that observing an interface removal permanently invalidates the old selection even if a replacement appears.

## curl: configure the socket, then perform socket I/O

`CURLOPT_INTERFACE` chooses an outgoing interface, address, or hostname; explicit interface syntax reports an interface failure when it does not match an existing interface. This is a transfer configuration option. [Official API documentation](https://curl.se/libcurl/c/CURLOPT_INTERFACE.html)

At curl revision `4c67658f953751de9e66bb5f9729af821a641341`, `cf_socket_open` calls `bindlocal` during socket setup. On systems with `SO_BINDTODEVICE`, `bindlocal` tries that option for an interface selection and can return immediately on success. Other paths resolve/bind a local address; these should not be represented as universally equivalent kernel interface confinement. [Binding implementation](https://github.com/curl/curl/blob/4c67658f953751de9e66bb5f9729af821a641341/lib/cf-socket.c#L652), [socket setup](https://github.com/curl/curl/blob/4c67658f953751de9e66bb5f9729af821a641341/lib/cf-socket.c#L1201)

The inspected `cf_socket_send` and `cf_socket_recv` functions call the socket write/read primitives and handle their results; they do not enumerate interfaces or verify interface identity for every call. This is an observation about those functions, not a claim that curl never inspects interfaces elsewhere or guarantees permanent identity continuity after removal. [Data I/O implementation](https://github.com/curl/curl/blob/4c67658f953751de9e66bb5f9729af821a641341/lib/cf-socket.c#L1570)

Design implication: socket setup can enforce routing choice without making full inventory scans part of ordinary I/O. Curl alone does not answer what wiremux should do upon removal, missed events, or interface-index reuse.

## Tailscale: shared asynchronous observations drive recovery

At Tailscale revision `8af8f861c032ee5c221b4189a1c68e8dff18068c`, `netmon.New` subscribes before taking its initial snapshot. `InterfaceState` returns a cached snapshot. The monitor pumps notifications, obtains a fresh snapshot, compares state, and publishes deltas/callbacks. The implementation waits one second after each processed snapshot to coalesce subsequent events; this is not a hard notification-latency guarantee. [Monitor initialization and snapshot API](https://github.com/tailscale/tailscale/blob/8af8f861c032ee5c221b4189a1c68e8dff18068c/net/netmon/netmon.go#L370), [event processing](https://github.com/tailscale/tailscale/blob/8af8f861c032ee5c221b4189a1c68e8dff18068c/net/netmon/netmon.go#L581)

Linux uses routing netlink notifications and falls back to polling if that subscription cannot be created. Ordinary polling uses ten seconds, with different Android and Cloud Run behavior. Crucially, the inspected Linux subscription includes address, route, and rule groups, not `RTMGRP_LINK`. Its handling of link messages as generic wakeups does not establish that it subscribes to every interface deletion. [Linux implementation](https://github.com/tailscale/tailscale/blob/8af8f861c032ee5c221b4189a1c68e8dff18068c/net/netmon/netmon_linux.go#L59), [polling fallback](https://github.com/tailscale/tailscale/blob/8af8f861c032ee5c221b4189a1c68e8dff18068c/net/netmon/polling.go#L64)

The userspace engine marks network availability, rebinds magicsock on relevant major changes when a link is up, and re-runs STUN. This is a concrete consumer of network-change observations for recovery. It is not a policy of permanently invalidating one selected interface handle. [Engine response](https://github.com/tailscale/tailscale/blob/8af8f861c032ee5c221b4189a1c68e8dff18068c/wgengine/userspace.go#L1155)

Design implication: share expensive discovery and snapshots outside packet processing. Borrow the architecture, not its exact subscriptions, coalescing interval, error policy, or recovery policy. Wiremux would need explicit deletion-event handling and its own continuity-loss semantics; snapshot equality alone can hide deletion followed by recreation between snapshots.

## quic-go: application-controlled migration and automatic NAT rebinding

The official connection-migration documentation describes constructing another `quic.Transport` around another packet connection, adding a path, probing it, and explicitly switching to it. The example uses separate connections for Wi-Fi and cellular. It also describes automatic server handling of NAT rebinding through path validation. [Official migration documentation](https://quic-go.net/docs/quic/connection-migration/)

Design implication: QUIC can preserve connection continuity across address/path changes, but that ability is distinct from permission to use a different local interface. The documentation does not promise automatic operating-system interface monitoring or persistent interface identity. Wiremux's selected-interface policy must decide which transports/paths it permits and whether a removed interface invalidates the Wire; QUIC migration capability cannot make that decision for it.

## Recommendation for the design discussion

The evidence supports considering setup-time binding plus a shared background observer and cheap local I/O state checks. This is a design inference, not a consensus guarantee copied from these projects. Before choosing it, specify whether the observer consumes deletion events directly, what happens when its event stream loses continuity, and whether polling is an acceptable fallback. Mere snapshot caching cannot itself uphold the distinction between a surviving interface and a replacement that looks identical.

## Practical observation options

These are design alternatives, not accepted decisions or measured performance predictions. They assume socket binding and packet-metadata admission continue enforcing the selected interface. The separate namespace trust model remains unresolved in the design interview.

| Approach | Ordinary I/O cost | Tradeoff |
| --- | --- | --- |
| Bind once; rely on socket errors and transport timeouts | No additional live interface inspection | Simplest, but does not implement proactive observed-removal invalidation or prompt closure of an idle Wire. Adopting it would require revisiting the accepted lifecycle contract. |
| Inspect before every operation, with a narrower OS query | OS work on every operation | Could reduce current enumeration costs, but cost still scales with I/O; checking and sending remain separate operations. |
| Refresh a cached snapshot when an I/O call finds it too old | Usually cheap; occasional I/O waits for inspection | Amortizes inspection, but adds occasional latency and does not notice removal while idle without an additional observer. |
| Poll in the background; check recorded state during I/O | Cheap local state check | Inspection cost depends on time and observer count rather than traffic; detection is delayed and snapshots can miss removal/recreation between polls. |
| Consume OS notifications; check recorded state during I/O | Cheap local state check | Usually prompt and quiet when the network is unchanged; requires platform code, startup ordering, lifecycle management, and notification-loss handling. |
| Notifications plus snapshot reconciliation, with an explicit polling fallback policy | Cheap local state check | Adds recovery and diagnostics at greater implementation complexity; reconciliation restores current facts, not missed historical events. |

Linux routing netlink supplies separate interface creation, deletion, and query messages (`RTM_NEWLINK`, `RTM_DELLINK`, `RTM_GETLINK`); subscriptions to link events can distinguish deletion from a surviving interface's ordinary changes. The documented API also permits creating an interface with a requested interface index, so an index must not be treated as an unrepeatable lifetime identifier. [Routing netlink manual](https://man7.org/linux/man-pages/man7/rtnetlink.7.html)

Netlink notifications can be dropped when receive buffers fill. Linux documents detecting this through `ENOBUFS` and resynchronizing. A refreshed snapshot cannot prove that an interface was never removed and replaced during the gap. A deletion already consumed by the observer must therefore remain recorded even if the next snapshot looks identical. [Netlink manual](https://man7.org/linux/man-pages/man7/netlink.7.html)

An observation failure admits a separate policy choice: continue constrained I/O while observation recovers; temporarily pause admission; or terminate affected selections. The first prioritizes availability within an explicitly best-effort observation contract. The last prioritizes continuity assurance but can terminate a working connection because monitoring failed. Pausing and taking a new snapshot cannot recover lost historical identity evidence. No choice is accepted here, and none implies atomic enforcement against interface replacement.

Observer ownership is another independent choice: per operation, per active selection, or shared across active selections in the same supported namespace domain. Sharing can reduce duplicate work; it does not require a permanent process-global monitor. The existing operation-owned lifetime requirements must be explicitly reconciled before adopting sharing.

The recommended direction is notifications plus reconciliation for the intended Linux design, with background polling as a possible smaller first step if its observation limits are accepted. Bind and validate new sockets at construction; preserve cheap packet-metadata guards and recorded terminal-state checks during I/O. Keep observed deletion terminal, allow the accepted rename/link/address continuity behavior, and leave transport errors and timeouts authoritative. Automatic migration or rebinding onto a replacement interface would be a different policy requiring separate caller authorization.
