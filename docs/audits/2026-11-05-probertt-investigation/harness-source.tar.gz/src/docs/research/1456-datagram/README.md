# Local Datagram baseline

All five approved captures completed on 2026-09-06 against clean code revision `b10ada1afb2dea0c8485ee771edc83894cd79d78`. Every admitted measurement message arrived inside its receiver window in each run. Generator misses and over-budget admission remain visible below; successful delivery does not erase those deficits. This is a single local diagnostic per configuration on a busy workstation, not a capacity ranking or qualification of the [1071-byte physical workload](../../work-items/1455-gridcast-datagram-workload.md).

## Configuration and provenance

The three clean runs and separate Wire CPU run used 1024-byte records, 100,000,000 offered bit/s, two Go processors per worker, 5 s warmup, 10 s measurement and 2 s drain. Native qlog used a 5 s measurement window with the other settings unchanged. The 100 ms preparation/release gap and post-drain hold are outside traffic phases. Each configuration ran once, sequentially, with no replacements. “Clean” means heavy profiling disabled; it does not mean a quiet host.

Host: Apple M4 Max, 16 logical CPUs, Darwin 25.6.0 arm64, Go 1.27.0, quic-go v0.61.0, loopback `lo0` MTU 16384. Both workers used `GOMAXPROCS=2` without CPU affinity. Native observed TLS_AES_128_GCM_SHA256 and no GSO; wrapped cipher/GSO/qlog are inaccessible through current production interfaces. Wire reported `wiremux-quic/2`, a 1191-byte carrier ceiling, and production Dial evidence `path=direct topology=direct`. All measurement payloads were 1024 bytes including the tool header; Wire adds its one-byte envelope. Network framing overhead is excluded.

The archived optimized binary SHA-256 is `dfe650514fe1dfe62d5ae41b276d97606f7e61ecd8f7c08ede5ea8140349591b`; [build metadata](binary-b10ada1.json) records the exact clean revision and compiler settings. Report-only commits do not relabel the captured revision. The durable local archive is `/Users/josh/Documents/wiremux-measurements/1456-20260906`; it holds the binary, all raw results/configurations, stderr, CPU profiles and qlogs. [Archive inventory](archive-manifest.json) records file sizes and digests. Small raw receipts are committed below, along with [derived summary](summary.json) and [qlog inspection](qlog-inspection.json).

## Delivered workload

| Run | Receiver goodput (Mbps) | Scheduled | Attempted = admitted = received | Generator missed | Admission over 5 ms | Deficit union | Eventual admitted delivery |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| [native](raw/native/result.json) | 99.57786 | 122070 | 121555 | 515 | 0 | 515 | 100% |
| [adapter](raw/adapter/result.json) | 99.99974 | 122070 | 122070 | 0 | 0 | 0 | 100% |
| [wire](raw/wire/result.json) | 99.99974 | 122070 | 122070 | 0 | 0 | 0 | 100% |
| [wire-cpu](raw/wire-cpu/result.json) | 99.35012 | 122070 | 121277 | 793 | 1 | 794 | 100% |
| [native-qlog](raw/native-qlog/result.json) | 98.12869 | 61035 | 59893 | 1142 | 1 | 1143 | 100% |

All runs had zero rejected, canceled, missing-admitted, duplicate, early, late, invalid and received-without-admission measurement messages. No native watchdog closed a carrier. Deficit is the per-identity union of generator misses, failed/over-budget admission and absent/out-of-window delivery. The native clean run’s 515 deficits were generator misses; the separate CPU and qlog captures each also contained one admitted-but-over-budget send. These observations do not establish the cause of individual scheduling delays or quantify instrumentation overhead from one unmatched-duration pair.

## Admission, echo and clocks

Latency values below are power-of-two histogram upper bounds, capped by the observed maximum. Admission includes the sender’s serialization wait; echo RTT includes admission and peer echo handling. Echo traffic is separate from bulk goodput.

| Run | Admission p50 / p95 / p99 (µs) | Echo RTT p50 / p95 / p99 (µs) | Echo attempts = replies | Echo generator misses | Summed clock uncertainty (µs) |
| --- | ---: | ---: | ---: | ---: | ---: |
| native | 1.023 / 2.047 / 4.095 | 65.535 / 131.071 / 262.143 | 997 | 3 | 25.021 |
| adapter | 1.023 / 2.047 / 4.095 | 65.535 / 131.071 / 170.666 | 1000 | 0 | 18.792 |
| wire | 2.047 / 4.095 / 8.191 | 131.071 / 131.071 / 262.143 | 1000 | 0 | 40.979 |
| wire-cpu | 2.047 / 4.095 / 8.191 | 65.535 / 131.071 / 524.287 | 996 | 4 | 28.042 |
| native-qlog | 1.023 / 2.047 / 8.191 | 131.071 / 262.143 / 2097.151 | 490 | 10 | 18.980 |

All originator echo attempts received one reply, with zero missing/duplicate replies or rejected attempts. Responder reply attempts/admissions are retained separately. Every run’s summed best-exchange clock uncertainty was below the declared 1 ms local alignment ceiling; this is private-pipe same-host evidence, not external clock certification. Raw receipts retain start lateness and actual phase offsets.

## Resource observations

Each delta uses the first and last cumulative process samples. Clean and CPU sample spans were about 10.100 s; qlog spans were about 5.100 s, including the declared preparation prefix. Average cores equals user-plus-system CPU delta divided by actual sample span. Allocation counts include the measurement aid and transport. RSS is process high-water RSS. These exclude the controller/relay and other host processes.

| Run / role | CPU seconds | Average cores | Allocated MiB | Mallocs | GC cycles | High-water RSS MiB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| native / send | 3.808 | 0.377 | 205.12 | 1905224 | 69 | 20.83 |
| native / receive | 3.547 | 0.351 | 274.62 | 1563496 | 96 | 21.06 |
| adapter / send | 3.909 | 0.387 | 339.10 | 2172126 | 114 | 21.03 |
| adapter / receive | 3.552 | 0.352 | 315.30 | 2188928 | 111 | 20.66 |
| wire / send | 4.152 | 0.411 | 638.20 | 2427203 | 226 | 22.34 |
| wire / receive | 3.781 | 0.374 | 534.45 | 3176802 | 188 | 21.45 |
| wire-cpu / send | 4.213 | 0.417 | 634.09 | 2406153 | 326 | 22.56 |
| wire-cpu / receive | 3.933 | 0.389 | 531.33 | 3155158 | 263 | 22.22 |
| native-qlog / send | 2.246 | 0.440 | 132.86 | 1466595 | 45 | 21.02 |
| native-qlog / receive | 1.871 | 0.367 | 159.52 | 1165002 | 55 | 21.23 |

The largest individual resource collection was 79.458 µs across the clean runs, 8.700 ms in the CPU capture, and 3.081 ms in qlog. Collection overhead and scheduling disturbance remain part of these results. The Wire runs recorded greater allocation volume than the native/adapter runs, but the current layered harness and unmatched external scheduling prevent attributing that difference to a single production owner. No runtime optimization is justified by this report alone.

## Separate profiling evidence

Both CPU files parsed successfully with the archived binary using `go tool pprof -top`. [Sender output](raw/wire-cpu/send-pprof-top.txt) contains 3.28 s of sampled weight and [receiver output](raw/wire-cpu/receive-pprof-top.txt) contains 2.71 s. Dominant flat entries are `runtime.kevent`, `syscall.rawsyscalln`, `runtime.pthread_cond_wait` and `runtime.pthread_cond_signal`. This is a sampling observation, not proof that blocked wall time is CPU work or a causal bottleneck. Process resource deltas above remain the CPU accounting source.

CPU files are 5,751 and 6,404 bytes; native qlogs are 50,901,746 and 27,960,051 bytes. All four manifests match the run, role, retained size and SHA-256; none is truncated. The qlogs parse as JSON sequences with 266,953 sender events and 96,286 receiver events. Observed event times fall inside the intended five-second measurement window using the recorded reference clock with 1 ms timestamp-conversion tolerance. They omit setup/drain and cannot be analyzed as complete connection timelines. ACK/packet events do not replace application receipt accounting.

## Limits and next use

Host snapshots before/after the campaign showed 1/5/15-minute load averages of 17.61/24.70/34.66 and 20.34/23.08/32.68. Active system/UI/storage services and background applications were present. No quiet-host, CPU-affinity, frequency, thermal, physical NIC, remote clock, impairment, VM/host cost or deployment-throughput certification was performed. The clean captures are therefore retained as operational examples under substantial external contention. No repeat was taken.

Local tool availability: Go profiling and native qlog worked; xctrace was unavailable from xcrun; DTrace probe listing required additional privileges, and usable dtruss attachment was not established. iperf2 2.2.1 was installed, iperf3 absent. No external profiler/iperf capture, installation, privilege escalation or security-setting change was needed. [Usage recipes](../../MEASUREMENT.md) document the separate platform workflows and their bounds.

The next qualification work remains [#1457](https://github.com/GridSwarm/wiremux/issues/1457) under its frozen workload, physical matrix and hardware prerequisites. Reliable-stream extension [#1464](https://github.com/GridSwarm/wiremux/issues/1464) may reuse this versioned foundation. The review history, including out-of-budget reviewer probes excluded from this baseline, is recorded in [review evidence](review.md).
