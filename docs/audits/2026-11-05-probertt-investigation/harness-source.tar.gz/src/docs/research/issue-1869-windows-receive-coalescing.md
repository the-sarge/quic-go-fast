# Issue #1869: Windows native receive coalescing (URO) through wiremux

Research for [Does Windows native receive coalescing (URO) fit wiremux's admission, and what does it buy through wiremux?](https://github.com/GridSwarm/wiremux/issues/1869) on the wayfinder map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). Windows entered the map for native receive coalescing only ([Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797)); this note measures it, Windows' copy-at-read question and equal-size Datagram gluing on Windows, through wiremux, in the minimax Linux-host ↔ Windows Server VM cell. Nothing here is implemented: every build is a throwaway probe, none is merged or pushed except the rig.

Sources are wiremux `main` at [870295a4](https://github.com/GridSwarm/wiremux/tree/870295a497ef862fa51f523c5f64d0eaf06dbed8), the quic-go-fast fork at [`v0.62.1-fast.7`](https://github.com/the-sarge/quic-go-fast/tree/v0.62.1-fast.7), the rig at `codex/native-gap-rig` [b47a253a](https://github.com/GridSwarm/wiremux/tree/b47a253a/cmd/nativerig), Microsoft's driver and Winsock documentation (pages cited with their dates), and measurements on 2026-10-18. Figures are labelled **measured**, **derived** or **source**; a statement about cause that no measurement isolates says it is inferred.

## Answer

1. **URO fits wiremux's per-datagram admission exactly.** Windows coalesces only datagrams that share their source address and port, destination, TOS, ECN, TTL, DF and size, and keeps flows apart and in order (documented, and measured stricter here). Every fact wiremux's Windows binding admits a received datagram on (sender address, receiving interface, the bound destination), and the sender port it passes on, is therefore the same for every datagram of a coalesced read, and one admission per read gives each datagram the verdict it would get alone. Through wiremux on the guest, coalescing gave the same per-datagram verdicts as one read per datagram (480 admitted, 160 refused of 640), a refused sender's coalesced reads were refused whole and none of their datagrams reached QUIC, and admission ran 18 times less often. `COMPATIBILITY.md` would need the Windows counterpart of #1824's Linux sentence. Against GridCast's admission bar: the check runs before QUIC, the one packet-info record is required per read and inherited by every split datagram, and Microsoft states the address and port rules outright, and this guest's software URO kept them in every pattern measured. The shared arrival interface is derived for hardware URO. For the software URO this guest uses, it is neither documented nor measurable here, because the guest has one adapter (section 2). One field risk is outside admission: some Windows hosts deliver coalesced reads without the segment-size record ([Potential bug in GRO code for Windows?](https://github.com/quinn-rs/quinn/issues/2041), quinn-rs/quinn#2041), which wiremux would admit correctly but QUIC would lose; quinn-udp keeps Windows URO off by default for it, and the fork has no guard (section 2).
2. **What URO buys, host → guest.** On the faster of the guest's two receive queues: Datagrams +17% at the default GC and +15% at the pin with today's fork reader, and +12.4% with copy-at-read and the bundle's 1,024-entry queue (290k → 326k Datagrams/s, 3.11 Gbit/s); the stream −0.7% / +4.4% with today's reader and +12.1% / +7.1% with copy-at-read (327k → 366k packets/s at the default GC, 4.00 Gbit/s). Receiver CPU per GiB falls 11–23% (process) and 9–21% (whole guest); 95–100% of datagrams coalesce, 27–31 per read. On the slower queue the same levers gain more (+20% on the stream).
3. **The Windows reader needs copy-at-read, for the stream.** Its slab, views and pending list raise the receiver's allocation 57% and its GC cycles 2.2 times. They keep away all of URO's stream gain at the default GC and 38% of it at the pin. Copy-at-read cuts allocation 80% and turns −0.7% / +4.4% into +12.1% / +7.1%. Datagrams are neutral to it (+4% at the default GC, −1.6% at the pin, unexplained). Of the fork's Windows URO tests that were run, all pass with it except four that encode the slab. Two managed-mode tests that also encode it were not run.
4. **Equal-size Datagram gluing works on a Windows sender and needs no exception.** Guest → host: today a Windows sender sends each Datagram in its own send call, about 70 µs of kernel CPU each in this guest, so it reaches only about 12k Datagrams/s; sending those one-packet sends untagged (roughly quic-go-fast#742's shape) changes nothing. #1814's gluing probe puts about 10 Datagrams in each segmented send and lifts a Windows sender's Datagrams 2.7× at the default GC and 3.4× at the pin (12.3k → 41.4k/s), 3.4× at GridCast's 1,099-byte records, with 57% less sending CPU per GiB and no loss or send failure; the stream is within −1.6% (overlapping ranges). The `e1000e` adapter offers no USO, so Windows segments in software, and that path took every segment count tried, up to 4,000 per send and 80,000 bytes: on this guest the fork's 20 KiB batch (16 Datagram packets) is the only bound.
5. **Baselines, one Wire at MTU 1500, 1,191-byte Datagrams (faster / slower receive queue):** host → guest today, 275k / 188k Datagrams/s at the pin (2.62 / 1.79 Gbit/s, 7.8% / 8.8% discarded at the fork's 128-entry queue) and 355k / 237k stream packets/s (3.88 / 2.59 Gbit/s); with URO, Windows copy-at-read and the 1,024 queue, 326k / 245k Datagrams/s (3.11 / 2.33 Gbit/s) and 380k / 285k stream packets/s (4.15 / 3.11 Gbit/s). A Windows sender is far slower: a Windows guest sends about 12k Datagrams/s (0.12 Gbit/s) and 44k stream packets/s (0.48 Gbit/s) today, and 41k Datagrams/s (0.39 Gbit/s) with gluing.

**Found on the way:** at the golden's 256 receive buffers the guest's receive path is bistable (a run sticks at about 27k packets/s behind a 16–40 ms queue), so every campaign here runs at 2,048; the guest spreads flows over two receive queues by 4-tuple, so the sender's ephemeral port alone moved a run 20–36% and every comparison fixes it; and each one-packet send through the fork costs a Windows sender here about 70 µs of kernel CPU, against 22 µs for a plain `sendto`. In these runs only putting more packets in each send (segmented sends) brought the per-packet cost down.

## 1. The cell and the method

### Cell (measured)

- **Host:** minimax, AMD Ryzen AI MAX+ 395 (16 cores, 32 threads; CCD 0 = cores 0–7, CCD 1 = 8–15, SMT sibling = CPU + 16), Linux 7.0.0-30-generic, QEMU 10.2.1, libvirt 12.0.0. The host peer binds the libvirt bridge `virbr0` (192.168.122.1/24, MTU 1500) and runs under `taskset` on CPUs 0, 1, 16 and 17 in F1 and F2, and on CPUs 0–3 (with the guest's emulator threads moved to 18–19) in every later campaign. `net.core.rmem_max` and `wmem_max` are 4 MiB, so the fork's 7 MiB socket-buffer request gets 4 MiB on the host.
- **Guest:** `wiremux-1869-uro`, a copy-on-write overlay of infra's sealed GARM Windows Server 2025 golden `v4` (Windows Server 2025 Standard Evaluation, 24H2, build 26100.32230), 4 vCPUs pinned 1:1 to host CPUs 4–7, QEMU emulator threads on 2, 3, 18 and 19 (18–19 from 20:55Z), 8 GiB, q35 with OVMF, one `e1000e` adapter (Intel 82574L, Microsoft driver 12.19.1.32, NDIS 6.50, MTU 1500, link speed reported 1 Gbit/s) on the host tap `vnet333` (MTU 1500, `tx-udp-segmentation` off, so the host's segmented sends are split before the tap). No vTPM: minimax's `swtpm` AppArmor profile admits only infra's own TPM paths, and Windows Server needs none. Windows' UDP offloads are on in the stack (`netsh int udp show global`: receive and send offload enabled); the adapter offers neither hardware URO nor USO, so both are the stack's software paths. Windows Firewall is on, with one inbound rule for UDP 47869–47872.
- **The guest's idle cost:** about 14% of its vCPUs is interrupt time with nothing running (no Hyper-V enlightenments in infra's domain definition, kept as is), and its QEMU process uses about 0.79 host CPUs at idle. A freshly generalized guest also runs post-install maintenance (Windows Update, .NET native-image generation, Defender cache maintenance, defragmentation) at 30–80% of its vCPUs for the first 40 minutes; every run is gated on the guest's busy share outside interrupt time being at most 6% (`busy1869.sh`).
- **One change from the golden's defaults:** the adapter's `Receive Buffers` is 2,048 instead of 256 for every campaign, because the default makes the receive path bistable (below).
- **Round trip:** 0.10–0.15 ms minimum RTT at idle (the fork's minimum RTT sample on the sender), so sub-millisecond as #1801's target shape requires.

### Method

- **Rig:** `cmd/nativerig` on `codex/native-gap-rig`, with the new `winvm` cell (rig commits below): the host peer over ssh, the guest peer through the QEMU guest agent only. One native Wire per run (NativeEndpoint → Promote → Wire), `Local` mode, MTU 1500, Datagrams at the Wire maximum of **1,191 bytes** (the ceiling today, not the adopted 1,397), the stream with 256 KiB writes. `REPS=3 WARMUP=1 SECS=10`, every arm rotating within each campaign, so the arms of a campaign are interleaved run by run. Host → guest: F1 and F2 (ephemeral sender ports), then P1 (a fixed sender port; a second fixed-port campaign, P2, was stopped after its warm-up runs when GARM CI jobs held the host for over ten minutes, so P1's levels are replicated only by F1 and F2's runs on the same queue); guest → host: R1 and R2, then R3 for one extra switch.
- **Builds:** one probe worktree (detached at wiremux `main` 870295a4 plus the rig, never pushed) with switches that apply per peer, and one fork copy (`qgf-1869`: `v0.62.1-fast.7` plus knobs and counters, every knob off by default), so every arm of a campaign runs the same two binaries:
  - `-uro` grants the fork's receive-coalescing permission on the receiving peer only (`ConfigureExternalPacketIOV1(conn, true, …)` instead of `false`).
  - `-wcr` makes the fork's Windows reader copy every datagram of a coalesced read into an ordinary packet buffer as it splits the read, keeping one reader-owned 64 KiB buffer: no slab, no views, no pending list of slab views, and nothing slab-backed reaches the connection (the Windows counterpart of #1829's Linux copy-at-read, reusing its `acceptCopy`).
  - `-glue` turns on equal-size Datagram gluing on the sending peer only: #1814's probe unchanged (the first packet's size becomes the batch's segment size), so it still lacks #743's safeguards 1 and 3.
  - `-rq 1024` sets the fork's received-Datagram queue to the bundle's 1,024 entries.
  - `-ballast 64 -gc-role both` is the Datagram pin; every Datagram comparison also has its default-GC row.
- **Counters:** the fork copy counts socket reads, coalesced reads and their segments, packets reaching the transport's read loop, segmented sends and their segments, packer, received-queue and unprocessed-queue drops, and the sender's ACK frames, RTT samples, losses and congestion cutbacks; the binding counts admissions per read and their verdicts.
- **CPU:** both peers' process CPU per delivered GiB (the guest's from `GetProcessTimes`). On Windows the receive path's DPC and interrupt work is not charged to the process, so the tables also give the **whole guest's** CPU per GiB beyond its idle baseline (from the `_Total` idle counter around each run, **derived**; it includes the run's start and end, so it overstates slow runs most).
- **Packets per second:** Datagrams delivered by the rig's reader; for the stream, packets reaching the receiver's QUIC read loop over the receiver's transfer time (**derived**, handshake packets included).
- **Host sharing:** every run gated by `busy1869.sh`: no other session's rig or campaign scripts, no `go build`, `go test`, `go vet`, lint, RAS or `perf`, no other process above half a core, the guest idle as above, and the YIELD protocol. Each run records the libvirt domain list; from 00:10Z on 2026-10-19 the gate also waits up to 15 minutes for other guests (GARM runners) to finish, and runs that overlapped one anyway are left out of the tables (quarantined).

### The stock guest's receive path is bistable (found on the way)

With the golden's adapter defaults (`Receive Buffers` 256), host-to-guest runs fell into one of two states for the whole run, whatever the arm (`diag1`–`diag4`, `smoke1`–`smoke3`; **measured**, diagnostic runs, never evidence):

| State | Delivered | Guest vCPU 0 DPC time | NIC interrupts/s | QEMU main thread | UDP ping beside the run (separate socket) |
| --- | --- | --- | --- | --- | --- |
| fast | 114k–196k packets/s | 33–47% | 8,300 (one run) | 22% of a core (one run) | 220–390 µs |
| slow | 26k–29k packets/s | 76–79% | 890–1,250 | 4.5% (one run) | 16–40 ms, growing through the run |

- In the slow state the queue is ahead of every socket (a ping to an idle echo socket waits 16–40 ms), the guest's receive DPC on vCPU 0 is three-quarters busy for a sixth of the packets, and QEMU's main thread, which normally moves frames from the host tap into the guest's receive ring, is nearly idle. That fits the ring having filled once: QEMU then stops reading the tap and delivers queued frames only when the guest returns descriptors, inside the vCPU's register write, so the delivery is charged to the guest's DPC and the ring stays full (inferred from the per-thread split; not traced inside QEMU).
- Plain Datagram runs were slow 9 times in 10 (`diag1`, `diag3`); the same arm with URO granted was slow 1 time in 6 (`diag2`). With `Receive Buffers` raised to 2,048 (the driver's maximum), 6 of 6 plain Datagram runs were fast (`diag4`), and 1 of the 216 native host → guest runs at 2,048 stuck (`pintest3` r3-dg-b64, 282 Mbit/s): rarer, not gone. Every campaign here runs at 2,048, set once at 19:09:49Z and recorded in `incidents.txt`. The raw `udp`, `udp4` and `binding` floods still reach only 27k–30k packets/s with 96–99% loss at either setting: an unpaced flood of about a million packets per second overruns any ring.
- The fork's W3 guest used the golden's defaults, and its runs show no bimodality (no run tripped its 1.30× rule), perhaps because its bare-fork receiver is cheaper per packet or its vCPUs were unpinned; this was not retested.

### Each flow's receive queue sets its level (found on the way)

Even at 2,048 buffers, runs of one arm landed on two levels 20–36% apart, at random: 34 of the 84 non-warm-up native runs of F1 and F2 sat on the lower one, in every arm but the default-GC Datagram arms, whose GC-bound reader hides it. Two placement checks did not change it: the guest peer restricted to vCPUs 1–3 (`WCPUMASK=E`, `pintest3`: wcr stream 3,249–3,294 and 4,376–4,402 Mbit/s) and the host peer on four separate cores 0–3 with the emulator threads moved to 18–19 (`pintest4`: 3,089–4,039). Fixing the native sender's local port did (`porttest1`, `-lport`, URO with copy-at-read, stream, **measured**):

| Sender port | Runs | Mbit/s |
| --- | ---: | --- |
| 50001 | 3 | 4,013, 4,031, 4,037 |
| 50002 | 2 (1 failed) | 4,046, 4,048 |
| 50003 | 3 | 4,007, 4,036, 4,038 |
| 50004 | 2 (1 failed) | 3,107, 3,116 |

The guest spreads flows over its two receive queues by their 4-tuple (RSS on, two queues, the indirection table alternating vCPUs 0 and 1), so the host's ephemeral port picked the queue. In the diagnostic runs at 2,048 buffers the slower runs also carried about 20% DPC time on vCPU 1 besides vCPU 0's 38–44%, against about 1% on vCPU 1 in the faster ones (`diag4`), so the slower queue costs the guest more DPC time per packet; why it does is not traced. The `P` and `R` campaigns therefore run every native arm with the sender on port 50001 (the faster queue) and repeat four arms on port 50004 (the slower one), and the host peer on CPUs 0–3 with the emulator on 18–19. The two failed runs here lost the guest receiver's output (the agent returned no result) and are kept as failures.

## 2. Question 1: does URO fit wiremux's per-datagram admission?

### What wiremux checks for every received datagram on Windows (source)

A native transport reads through wiremux's packet connection, never the socket. The fork's Windows reader calls `ReadMsgUDP` on that connection with a 65,535-byte buffer once permission is granted ([`sys_conn_windows.go` L157-L209](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_windows.go#L157-L209), buffer at L169) and a 128-byte control buffer (L24). wiremux's `ReadMsgUDP` ([`packetconn.go` L81-L89](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/packetconn.go#L81-L89)) goes to `ReadUnicastBatch` with one slot ([`unicast.go` L871-L917](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast.go#L871-L917)), which reads the socket with the caller's own buffer and a private control buffer of the caller's size plus 256 bytes (L886, L935; [`packet.go` L246](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/packet.go#L246)), admits the read once (`admitReceived`, [L952-L983](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast.go#L952-L983)), and copies the control bytes back verbatim, flagging truncation if they do not fit ([L909](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast.go#L909), [`packet.go` L259-L265](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/packet.go#L259-L265)). The fork splits the read into datagrams only after that (L191-L207). So **admission runs once per socket read, before the split**, exactly as #1824 found for Linux GRO.

The facts `admitReceived` uses for one read:

| Fact | Where | Per datagram or per read |
| --- | --- | --- |
| Sender address (IP) | the read's source address ([L961-L970](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast.go#L961-L970)); the port is not an admission input and is copied into the returned address after admission ([L981](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast.go#L981)) | per read |
| Receiving interface | `IP_PKTINFO` / `IPV6_PKTINFO` interface index; missing, zero, conflicting or truncated records refuse the read ([`unicast_windows.go` L207-L256](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast_windows.go#L207-L256)) | per read |
| Destination address | the socket is bound to one unicast address of the interface; the packet-info record's address is parsed but not used on receive | fixed by the socket |
| Peer verdict | screen (valid, not unspecified or multicast, family, zone) then the cached native-facts verdict for the sender's IP: self-delivery, directed and limited broadcast, interface-restricted route, on-link versus gateway, default route, Local or Direct mode ([`unicast.go` L450-L594](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast.go#L450-L594)) | a function of the sender's IP and the interface |
| ECN, TOS, TTL, DF, size | not read: wiremux's Windows binding requests only packet info, and the fork's Windows connection reports ECN unsupported outside its managed mode | never |

The packet-info parser skips every other record (L233-L235), so `UDP_COALESCED_INFO` passes through untouched; the private control buffer (384 bytes) and the fork's 128 bytes both hold the 48 bytes of packet info plus coalesced info, so nothing is truncated.

### What Windows merges (source and measured)

- **Microsoft's documented rules** ([UDP Receive Segment Coalescing Offload (URO)](https://learn.microsoft.com/en-us/windows-hardware/drivers/network/udp-rsc-offload), page dated 2024-12-19): same IP version, source and destination addresses, source and destination ports, a nonzero UDP length that is equal for all but a possibly shorter last datagram, a valid checksum if nonzero, an identical layer-2 header; for IPv4 no options, identical TOS, ECN, DF and TTL; for IPv6 no extension headers and identical traffic class, ECN, flow label and hop limit. Datagrams of different flows are never merged, and order within a flow is kept. The Winsock contract is shorter: datagrams coalesce "only if they originated from the same source address and port", all of one size except the last ([IPPROTO_UDP socket options](https://learn.microsoft.com/en-us/windows/win32/winsock/ipproto-udp-socket-options)). These rules are written for NIC (miniport) URO. This guest's `e1000e` adapter (Intel 82574L, driver 12.19.1.32, NDIS 6.50) offers no hardware URO, so what coalesces here is the stack's software URO, which the page only says "continues to be available"; its rules are not separately documented.
- **Measured on this guest** (raw IPv4 bursts of 32 × 1,200-byte datagrams from the host to a plain Winsock socket with `UDP_RECV_MAX_COALESCED_SIZE` 65,535, three bursts per pattern; `checks/rules1`):

| Burst | Datagrams delivered | Reads | Largest read (datagrams) | Reads mixing two variants |
| --- | ---: | ---: | ---: | ---: |
| identical headers | 96 of 96 | 4 | 32 | — |
| TOS alternating every datagram | 96 | 96 | 1 | 0 |
| ECN alternating | 96 | 96 | 1 | 0 |
| TTL alternating | 96 | 96 | 1 | 0 |
| DF alternating | 96 | 96 | 1 | 0 |
| TTL or ECN changing halfway | 96 | 7, 6 | 16 | 0 |
| source port alternating | 96 | 8 | 16 | 0 (each read one port, in order) |
| source address alternating | 96 | 8 | 16 | 0 (each read one address, in order) |
| on-link and off-link source alternating | 96 | 6 | 16 | 0 |
| IP ID varying | 96 | 4 | 32 | — |
| one shorter datagram at index 8 | 96 | 10 | 23 | 0 (the short one alone) |
| UDP checksum zero | 96 | 96 | 1 | — |
| one bad checksum at index 8 | 93 | 7 | 23 | 0 (bad one dropped, the run split around it) |

  Software URO here is at least as strict as the documented rules: any header difference ends the coalesced unit, interleaved flows are separated by flow and kept in order, and it does not coalesce zero-checksum datagrams or append a shorter datagram as the tail. Every coalesced read carried `UDP_COALESCED_INFO` with the right segment size, and every segment's payload checked.

### Through wiremux (measured)

`uro1869.exe` (probe worktree `cmd/uro1869`) listens with one native endpoint (Local mode, the guest's `Ethernet`) with the receive-coalescing grant on or off, and counts each binding read's verdict and segments and what reaches the fork's read loop. The host sent four bursts of 32 junk datagrams per round for five rounds: from its own address (on-link, admitted), from a second on-link address (admitted), alternating its source port, and from an off-link address 10.69.0.1, which the guest routes through its default gateway, so Local mode refuses it.

| Grant | Binding reads | Admitted reads (datagrams) | Refused reads (datagrams) | Coalesced reads | Fork reads | Datagrams to QUIC |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| off (today) | 640 | 480 (480) | 160 (160) | 0 | 480 | 480 |
| on | 35 | 30 (480) | 5 (160) | 29 | 30 | 480 |
| on, copy-at-read | 40 | 34 (480) | 6 (160) | 33 | 34 | 480 |

A fifth burst alternated the admitted and the refused source datagram by datagram: 10 reads, 5 admitted (80 datagrams, all from the admitted source), 5 refused (80), 80 to QUIC (`checks/admit-mix`). So every datagram received the same verdict as with one read per datagram; a coalesced read from a refused sender was refused whole and none of its datagrams reached QUIC; and admission ran 18 times less often (35 against 640 calls).

The fork's own Windows URO tests also pass on this guest at `v0.62.1-fast.7`, including the external-wrapper engagement test against a host peer (one coalesced read, 32 exact datagrams) and the USO/URO interaction matrix (`checks/forktests/fast7.log`).

### Answer

**Yes, URO fits.** Every fact wiremux admits a received datagram on is identical across a Windows coalesced read (source address, destination, receiving interface), and so is the source port the binding passes on. One admission per read is therefore exact, as on Linux. A coalesced read from a refused sender is refused whole. The facts Windows also requires to match (TOS, ECN, TTL, DF, size) are ones wiremux does not read on Windows. The only wording change is the one #1824 proposed for Linux: kernel ingress is then checked per read, not per datagram, so `COMPATIBILITY.md`'s "Kernel ingress is still checked per datagram" needs the same one-sentence exception for Windows.

**One field risk that is not an admission breach.** quinn-udp turned Windows URO off by default after users saw coalesced reads delivered *without* `UDP_COALESCED_INFO` on some hosts (Windows on Arm with WSL installed, reproduced by a Mozilla engineer, and some x64 machines behind one Dell dock; [Potential bug in GRO code for Windows?](https://github.com/quinn-rs/quinn/issues/2041), quinn-rs/quinn#2041, open). quinn first stopped enabling URO on Windows on Arm ([fix(udp): do not enable URO on Windows on ARM](https://github.com/quinn-rs/quinn/pull/2071), merged 2024-12-06), and its `set_gro` is now documented as "Disabled by default on Windows due to" that issue ([`quinn-udp/src/windows.rs` L179](https://github.com/quinn-rs/quinn/blob/17596dde/quinn-udp/src/windows.rs#L179), **source**). The fork has no such guard: `enableURO` turns URO on whenever the permission is granted, on every architecture, with only the `QUIC_GO_DISABLE_GRO` kill switch ([`sys_conn_windows.go` L133-L155](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_windows.go#L133-L155), **source**). Through wiremux such a read would still be admitted correctly (one flow), but the fork would hand QUIC the merged bytes as one datagram, so every datagram in it would fail to decrypt and be lost. Nothing in this cell reproduced it. #1870 should decide whether a grant needs a guard (for example, the fork treating a read longer than its largest packet without the record as proof of the defect and disabling URO for the socket's life) and whether Windows on Arm is excluded.

### Against GridCast's admission bar

GridCast's admission bar for coalesced receives was posted on this ticket while the research ran ([Input: GridCast's admission bar for coalesced receives](https://github.com/GridSwarm/wiremux/issues/1869#issuecomment-6253077929), read from GridCast `main` at 40950e1b). Point by point:

- **The platform guarantee that merged datagrams share source and destination addresses, ports and arrival interface.** Addresses and ports are stated outright: "`IpHeader.SourceAddress` and `IpHeader.DestinationAddress` are identical for all packets", and the same for both ports ([UDP Receive Segment Coalescing Offload (URO)](https://learn.microsoft.com/en-us/windows-hardware/drivers/network/udp-rsc-offload), ms.date 2024-12-19, docs commit [81d06fd7](https://github.com/MicrosoftDocs/windows-driver-docs/blob/81d06fd79dd36cdd74ec0b3aeed6c4e52c2e2fc3/windows-driver-docs-pr/network/udp-rsc-offload.md), **source**). The arrival interface is not named. It follows from the page's construction: a NIC "combine[s] UDP datagrams from the same flow" and indicates them "as a single large packet" with one IP header, one UDP header and one layer-2 header that must be identical across the merged datagrams, so a coalesced unit is one packet received on one adapter (**derived**). Of the stack's software URO, which is what coalesces on this guest's `e1000e`, the page says only that it "continues to be available"; its rules are not documented, and here they were measured at least as strict as the NIC rules (table above). So for hardware URO the guarantee is cited for addresses and ports and derived for the interface. For software URO, addresses and ports are measured. The interface is neither documented nor measured for it, because this cell has one adapter and nothing here varies the arriving interface. Whether that meets GridCast's first condition is #1870's call.
- **Where the check runs.** Before QUIC sees any byte: `ReadUnicastBatch` admits the read before returning it to the fork, which splits it afterwards, so a refused read never reaches CID lookup, decryption or connection state (**source**, links above).
- **What it must refuse.** Measured on first contact: the off-link sender's coalesced reads were refused whole and nothing from them reached QUIC (the junk bursts above open no connection). On an established connection the same per-read code runs before the fork and consults no connection state, so the verdict cannot differ (**source**; not separately measured here, and the implementing slice's test should cover both).
- **What it must keep.** The coalesced read carries one packet-info record. wiremux refuses a read whose record is missing, zero, conflicting or truncated ([`unicast_windows.go` L207-L256](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast_windows.go#L207-L256)), so the record is present and checked against the bound interface for every read, not inferred from the socket's binding. The fork's split then hands that same record to every datagram it extracts: `TestWindowsUROReadPacketInfoInheritance` passed on this guest at `v0.62.1-fast.7` (`checks/forktests/fast7.log`, **measured**).
- **What stays per datagram.** On Windows the fork reads one message per call (`ReadMsgUDP`, one binding slot), so unrelated datagrams are still separate reads, each with its own check. A coalesced read holds one flow only.
- **Which Windows binding tests need a coalesced-path row.** wiremux has no Windows-only receive admission test; the receive admission tests in [`unicast_test.go`](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast_test.go) build on Windows too (`//go:build linux || darwin || windows`) and fake the kernel's reads with `queueReceive`. The rows belong in `TestUnicastReceiveIngressAndReturnRoute` (L249) and `TestUnicastBatchProvenance` (L283): a queued coalesced read whose control data carries packet info plus `UDP_COALESCED_INFO` is admitted with both records returned verbatim and untruncated, and the same read from a foreign interface, with missing or truncated packet info, or from an off-link sender in Local mode is refused whole. In `internal/nativequic` the on/off-per-OS and refused-merged-read tests that [Should native receives adopt coalescing once the fork copies coalesced datagrams at read time?](https://github.com/GridSwarm/wiremux/issues/1835#issuecomment-6196268143) asked for on Linux gain a Windows row. An end-to-end row for independently sent datagrams needs two machines. The fork's W3 audit found that a URO socket returned only single-datagram reads for same-host traffic, whether the sends were segmented or independent, on loopback or on the host's own adapter address ([W3 results](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/docs/audits/2026-09-11-w3-uro-results.md), post-collection diagnostics). On this guest, though, one segmented (USO) send across loopback did arrive as one coalesced read: `TestWindowsUROEndToEndLoopback` logged 8 datagrams in 1 read (`checks/forktests/fast7.log`). Independent same-host sends were not retested here. `uro1869` (probe worktree `cmd/uro1869`) is the two-machine test in this cell.

## 3. Question 2: what URO does to rates and CPU per GiB

Host → guest, one native Wire, campaign P1 (2026-10-18 21:05–23:15Z, paused for eight yields to other sessions; every native sender on port 50001, the faster receive queue, plus four arms on port 50004, the slower one), three non-warm-up runs per arm, every arm rotating within the campaign. "URO" is the probe's permission grant on the Windows receiver with today's fork reader (slab, views and pending list); "URO + copy-at-read" adds `-wcr`. Packets per second are delivered Datagrams, or QUIC packets reaching the stream receiver's read loop. CPU is CPU-seconds per delivered GiB: each peer's process, then the whole guest beyond its idle baseline and the guest's QEMU process on the host beyond its idle baseline (both **derived**). "Coalesced" is the share of delivered packets that arrived in multi-datagram reads, "per read" the mean datagrams in one. All rates **measured**.

| Arm | Runs | Mbit/s | Range | Packets/s | Change | Loss | Sender CPU | Receiver CPU | Guest CPU | Guest QEMU CPU | Coalesced | Per read |
| --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `stream` | 3 | 3,567 | 3,507..3,611 | 327k | — | — | 1.65 | 4.18 | 5.93 | 7.49 | — | — |
| `uro-st` | 3 | 3,541 | 3,528..3,549 | 324k | -0.7% | — | 1.55 | 3.71 | 5.40 | 7.18 | 95% | 26.6 |
| `wcr-st` | 3 | 3,998 | 3,980..4,021 | 366k | +12.1% | — | 1.54 | 3.36 | 5.06 | 6.39 | 95% | 27.0 |
| `st-b64` | 3 | 3,879 | 3,836..3,961 | 355k | — | — | 1.63 | 3.99 | 5.79 | 6.96 | — | — |
| `uro-st-b64` | 3 | 4,048 | 4,007..4,057 | 371k | +4.4% | — | 1.54 | 3.48 | 5.07 | 6.36 | 95% | 26.9 |
| `wcr-st-b64` | 3 | 4,152 | 4,119..4,153 | 380k | +7.1% | — | 1.53 | 3.31 | 4.82 | 6.24 | 95% | 27.0 |
| `dgram` | 3 | 1,382 | 1,333..1,389 | 145k | — | 11.46% | 5.60 | 8.88 | 13.03 | 18.92 | — | — |
| `uro-dg` | 3 | 1,621 | 1,609..1,660 | 170k | +17.3% | 11.66% | 5.43 | 7.66 | 10.98 | 16.00 | 100% | 29.5 |
| `wcr-dg` | 3 | 1,690 | 1,662..1,705 | 177k | +22.3% | 12.53% | 5.47 | 7.15 | 10.55 | 15.43 | 100% | 29.8 |
| `dg-b64` | 3 | 2,617 | 2,560..2,625 | 275k | — | 7.79% | 4.91 | 5.98 | 8.47 | 10.55 | — | — |
| `uro-dg-b64` | 3 | 3,003 | 2,995..3,021 | 315k | +14.8% | 3.69% | 4.64 | 4.67 | 6.78 | 8.78 | 100% | 31.3 |
| `wcr-dg-b64` | 3 | 2,954 | 2,949..2,967 | 310k | +12.9% | 5.06% | 4.69 | 4.63 | 6.84 | 8.74 | 100% | 31.4 |
| `rq-dg-b64` | 3 | 2,765 | 2,735..2,789 | 290k | — | 0.12% | 4.55 | 5.52 | 7.92 | 10.08 | — | — |
| `rqwcr-dg-b64` | 3 | 3,107 | 3,092..3,120 | 326k | +12.4% | 0.05% | 4.46 | 4.28 | 6.27 | 8.39 | 100% | 31.4 |
| `q4-st-b64` | 3 | 2,590 | 2,555..2,609 | 237k | — | — | 1.68 | 4.55 | 7.86 | 9.39 | — | — |
| `q4-wcr-st-b64` | 3 | 3,110 | 3,108..3,149 | 285k | +20.1% | — | 1.59 | 3.57 | 6.42 | 7.69 | 95% | 25.6 |
| `q4-dg-b64` | 3 | 1,787 | 1,761..1,804 | 188k | — | 8.81% | 5.13 | 6.67 | 11.63 | 14.08 | — | — |
| `q4-rqwcr-dg-b64` | 3 | 2,333 | 2,319..2,357 | 245k | +30.5% | 1.02% | 4.64 | 4.99 | 8.81 | 10.73 | 100% | 30.4 |

- **Stream (where most datagrams coalesce, 95% of them, about 27 per read):** URO with today's reader adds nothing at the default GC (−0.7%, inside the spread) and 4.4% at the pin. With copy-at-read it adds 12.1% and 7.1%. Receiver process CPU per GiB falls 11–13% with URO and 17–20% with copy-at-read, the whole guest's 9–12% and 15–17%, and the guest's QEMU process's 4–9% and 10–15%. The sender's CPU per GiB falls 5–7%: it receives 24% fewer acknowledgment frames per GiB (34,200 → 25,900), each covering 30 packets instead of 23, because the receiver now handles a read's datagrams in one pass.
- **Datagrams (where nearly all coalesce, about 31 per read):** URO adds 17% at the default GC and 15% at the pin; with copy-at-read the gains are 22% and 13%. The receiver's process CPU per GiB falls 14–22% with URO. With the bundle's 1,024-entry received-Datagram queue both arms lose almost nothing (0.12% and 0.05%), and URO with copy-at-read still adds 12.4%. Without it, 7.8% (base) and 3.7–5.1% (URO) of Datagrams are discarded after acknowledgment at the fork's 128-entry queue: on Windows the application's Datagram reader is the bound, and URO, by making the guest's receive path cheaper, gives it more of the CPU.
- **The slower receive queue gains more.** On port 50004 the same levers add 20.1% to the stream (2,590 → 3,110 Mbit/s at the pin, copy-at-read) and 30.5% to Datagrams (1,787 → 2,333, but that pair also adds the 1,024-entry queue, so it is not URO alone).
- **The unpinned campaigns agree.** F1 and F2 (2026-10-18 19:14–20:29Z, ephemeral sender ports, host peer on 0–1 and 16–17) put about 40% of runs on the slower queue at random; within each level the gains have the same sign and size (stream on the faster queue: 3,580–3,618 → 3,626–3,693 → 4,000–4,166 Mbit/s; Datagrams at the pin with the 1,024 queue: 2,834–2,877 → 3,260–3,277). Pooled medians across both levels are in `an-F12.txt` and are not used as headline numbers, because they mostly report which queue the runs drew.
- **What URO does in the guest:** 0.033–0.036 socket reads per delivered Datagram and 0.084 per stream packet (12 to 30 times fewer reads), and wiremux's binding admits once per read. No read was rejected (malformed or truncated metadata) in 114 URO runs and about 20 million reads.

## 4. Question 3: does the Windows reader need copy-at-read?

**Yes, for the stream; for Datagrams it is neutral.** The Windows reader does what #1829 found in the Linux reader: per read it takes a 64 KiB buffer from a pool, wraps it in a slab, makes a view per datagram and a pending list ([`sys_conn_windows.go` L157-L209](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_windows.go#L157-L209), [`coalesced_delivery.go` L24-L46](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_delivery.go#L24-L46), [`coalesced_slab.go` L67](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_slab.go#L67)), and each slab-backed datagram is copied again under the connection's receive lock when it is queued ([`connection.go` L2004-L2022](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2004-L2022), [`coalesced_slab.go` L115](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/coalesced_slab.go#L115)). The probe's copy-at-read keeps one reader-owned 64 KiB buffer and copies each datagram into an ordinary packet buffer as it splits the read, so nothing slab-backed reaches the connection (`fork/qgf-1869.diff`).

The receiver's Go runtime counters over the same P1 runs (medians, **measured**; allocations per delivered packet include the binding's and the rig's):

| Arm | Runs | Allocated MB per GiB | Allocations per packet | GC cycles/s | GC CPU-s per GiB | Peak working set MB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `stream` | 3 | 163 | 6.21 | 31 | 0.145 | 22 |
| `uro-st` | 3 | 256 | 3.77 | 68 | 0.277 | 21 |
| `wcr-st` | 3 | 50 | 2.49 | 11 | 0.039 | 21 |
| `st-b64` | 3 | 147 | 6.18 | 1 | 0.005 | 90 |
| `uro-st-b64` | 3 | 225 | 3.71 | 2 | 0.007 | 89 |
| `wcr-st-b64` | 3 | 45 | 2.49 | 0 | 0.002 | 90 |
| `dgram` | 3 | 2,921 | 13.22 | 230 | 2.524 | 23 |
| `uro-dg` | 3 | 3,015 | 10.06 | 289 | 2.434 | 23 |
| `wcr-dg` | 3 | 2,757 | 8.79 | 260 | 2.236 | 24 |
| `dg-b64` | 3 | 2,754 | 12.71 | 13 | 0.093 | 92 |
| `uro-dg-b64` | 3 | 2,839 | 9.52 | 16 | 0.095 | 91 |
| `wcr-dg-b64` | 3 | 2,619 | 8.40 | 15 | 0.089 | 91 |
| `rq-dg-b64` | 3 | 2,739 | 12.19 | 14 | 0.102 | 94 |
| `rqwcr-dg-b64` | 3 | 2,615 | 8.28 | 15 | 0.085 | 92 |

- **Stream:** today's coalesced path raises the receiver's allocation by 57% over no coalescing (163 → 256 MB per GiB) and more than doubles its GC cycles (31 → 68 a second at the default GC); copy-at-read cuts it to 50 MB per GiB and 11 cycles a second. That is where the throughput goes, as on Linux: URO alone gains −0.7% / +4.4%, URO with copy-at-read +12.1% / +7.1% (default GC / pin). On Linux the same path cost the stream 2.4–2.8% against no coalescing ([Why does native receive coalescing cost throughput in the netns shape cell?](https://github.com/GridSwarm/wiremux/issues/1829#issuecomment-6154923896)). On Windows it costs nothing outright, but it holds back URO's stream gain: all of it at the default GC (3,567 → 3,541 Mbit/s, against 3,998 with copy-at-read) and 38% of it at the pin (104 of the 273 Mbit/s between 3,879 and 4,152; **derived**). That the remaining split between GC and the lock-held copy is like Linux's is inferred, not traced.
- **Datagrams:** allocation is dominated by the Datagram path's own copies (2.6–3.0 GB per GiB) and copy-at-read trims about 8% of it. At the default GC copy-at-read adds 4% over URO alone (1,621 → 1,690 Mbit/s); at the pin it is 1.6% slower (3,003 → 2,954, ranges 2,995–3,021 and 2,949–2,967), the one losing row, with more received-queue discards (3.7% → 5.1%); with the 1,024 queue the pin row is +12.4% over no URO. Why copy-at-read costs Datagrams 1.6% at the pin is not explained.
- **Correctness:** the fork's Windows URO tests run on the guest with copy-at-read forced on (`R1869_WCR=1`) pass every payload, packet-info and engagement check (including the external-wrapper engagement test against a host peer) and, of the tests in that run, fail exactly the four whose assertions encode the slab representation (`TestWindowsUROReadSplitsCoalescedRead`, `TestWindowsUROReleaseReadBuffersReleasesPendingViews`, `TestWindowsUSOUROInteractionMatrix` and `TestWindowsUROEndToEndLoopback` check `p.buffer.slab != nil`; `checks/forktests/qgf1869-wcr.log`). That run did not include the fork's managed-mode Windows tests. Two of them also assert slab-backed views on the same reader: `TestWindowsManagedReceiveHandback` ([`managed_packet_receive_windows_test.go` L184](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/managed_packet_receive_windows_test.go#L184)) and `TestWindowsManagedECNCoalescedMetadata` ([`managed_packet_ecn_windows_test.go` L248-L254](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/managed_packet_ecn_windows_test.go#L248-L254)). The probe's copy-at-read also covers only a reader with coalescing on (`c.cap.GRO`), while a managed reader without it still takes slab buffers ([`sys_conn_windows.go` L167](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_windows.go#L167)). A Windows copy-at-read slice would rewrite those storage assertions, as the Linux one does. It would leave the slab and ADR 0005's atomic exception with no Windows producer only if it covers the managed reader too.

## 5. Question 4: equal-size Datagram gluing on Windows

Guest → host: the Windows guest sends, the Linux host receives (its binding reads without coalescing, as on `main`). Campaigns R1 and R2 (2026-10-18 23:15 to 2026-10-19 00:52Z; every native sender on port 50001, two arms also on 50004), three runs per arm each, pooled; R3 (00:52–01:12Z) adds `-nogso`. Gluing is #1814's probe (`-glue`, the sender only) against today's fork in the same binary. Runs that overlapped a GARM Windows runner are quarantined (5 in R1, none in R2). "Guest CPU" is the sending guest's whole CPU beyond idle. All rates **measured**.

| Arm | Runs | Mbit/s | Range | Packets/s | Change | Loss | Guest sender CPU | Host receiver CPU | Guest CPU | Guest QEMU CPU |
| --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `dgram` | 5 | 118 | 109..122 | 12k | — | 0.00% | 74.58 | 12.55 | 127.80 | 176.30 |
| `glue-dg` | 5 | 317 | 313..323 | 33k | +169.6% | 0.00% | 33.43 | 10.02 | 54.51 | 66.81 |
| `dg-b64` | 6 | 117 | 112..138 | 12k | — | 0.00% | 69.88 | 12.98 | 123.22 | 170.41 |
| `glue-dg-b64` | 6 | 394 | 388..405 | 41k | +236.4% | 0.00% | 29.84 | 10.52 | 48.19 | 57.91 |
| `rq-dg-b64` | 6 | 114 | 107..117 | 12k | — | 0.00% | 73.90 | 12.98 | 132.56 | 176.38 |
| `gluerq-dg-b64` | 6 | 393 | 382..406 | 41k | +243.4% | 0.00% | 30.26 | 10.51 | 49.46 | 58.33 |
| `d1099-b64` | 6 | 109 | 106..113 | 12k | — | 0.00% | 78.29 | 13.82 | 135.91 | 187.76 |
| `glue1099-b64` | 6 | 375 | 363..382 | 43k | +244.9% | 0.00% | 31.88 | 11.25 | 52.45 | 61.41 |
| `q4-dg-b64` | 5 | 159 | 156..166 | 17k | — | 0.00% | 58.35 | 12.15 | 83.18 | 128.40 |
| `q4-glue-dg-b64` | 5 | 374 | 352..396 | 39k | +135.8% | 0.00% | 27.80 | 10.46 | 38.66 | 49.40 |
| `stream` | 5 | 469 | 456..485 | 43k | — | — | 23.64 | 7.65 | 37.26 | 46.77 |
| `st-b64` | 6 | 481 | 476..501 | 44k | — | — | 23.29 | 7.59 | 36.92 | 45.70 |
| `glue-st-b64` | 6 | 473 | 446..487 | 43k | -1.6% | — | 23.45 | 7.66 | 37.70 | 46.18 |
| `udp` | 6 | 427 | 376..459 | 37k | — | 0.00% | 18.89 | 1.80 | 24.18 | 23.00 |
| `udp4` | 5 | 619 | 587..826 | 53k | — | 0.00% | 33.96 | 1.63 | 38.86 | 33.17 |
| `binding` | 6 | 293 | 279..382 | 25k | — | 0.00% | 25.38 | 4.11 | 35.54 | 35.71 |

Five runs that overlapped a GARM runner are left out (R1 r2-dgram, r2-q4-dg-b64, r2-q4-glue-dg-b64, r2-stream, r3-udp4; four of them ran 12–20% below their arm's median, r2-stream 2%), and one failed run (R2 r3-glue-dg: the guest sender's output was lost) is counted as failed.

- **Today a Windows sender sends each Datagram packet alone**, and each of those one-packet sends costs this guest about 70 µs of kernel CPU. The fork tags every hand-off with a segment size on a USO-capable connection, even a buffer holding one packet, so each Datagram is a `WSASendMsg` carrying `UDP_SEND_MSG_SIZE` with one segment (`q69_gso_sends` = packets). It costs 67–74 µs of kernel CPU per Datagram (**derived**: process system time over packets) against 22 µs per datagram for the raw `udp` arm's plain `sendto` and 26–27 µs per stream packet sent about 9.6 to a call, and it holds a Windows sender to about 12k Datagrams/s (115–120 Mbit/s) on one saturated core. The tag is not the cost. R3 turned segmented sends off on the sender (`-nogso`, `QUIC_GO_DISABLE_GSO=1`, so one-packet sends go untagged, roughly what quic-go-fast#742 does for them) and Datagrams stayed where they were (+4.3% at the default GC, −8.3% at the pin, 70–80 µs per Datagram either way), while the stream, which then loses its segmented sends, fell 72%:

| Arm | Runs | Mbit/s | Range | Packets/s | Change | Loss | Guest sender CPU | Host receiver CPU | Guest CPU | Guest QEMU CPU |
| --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `dgram` | 3 | 112 | 110..115 | 12k | — | 0.00% | 72.52 | 12.68 | 129.20 | 180.43 |
| `nogso-dg` | 3 | 117 | 113..121 | 12k | +4.3% | 0.00% | 70.96 | 12.52 | 124.42 | 167.89 |
| `glue-dg` | 3 | 311 | 310..321 | 33k | +177.1% | 0.00% | 33.51 | 10.00 | 52.90 | 66.75 |
| `dg-b64` | 3 | 117 | 108..117 | 12k | — | 0.00% | 75.08 | 12.92 | 126.42 | 173.95 |
| `nogso-dg-b64` | 3 | 107 | 102..108 | 11k | -8.3% | 0.00% | 78.67 | 13.17 | 132.22 | 180.37 |
| `glue-dg-b64` | 3 | 379 | 378..391 | 40k | +223.6% | 0.00% | 30.09 | 10.60 | 48.95 | 57.58 |
| `st-b64` | 3 | 484 | 469..487 | 44k | — | — | 22.60 | 7.63 | 36.95 | 45.87 |
| `nogso-st-b64` | 3 | 133 | 117..140 | 12k | -72.4% | — | 60.07 | 10.11 | 103.18 | 147.60 |

- **Gluing:** about 10 Datagram packets per send (at most 16, the 20 KiB buffer's limit at this size), about 29 µs of kernel CPU per Datagram, and **3.4× the Datagram rate at the pin** (12.3k → 41.4k/s, 117 → 394 Mbit/s), 2.7× at the default GC, 3.4× at GridCast's 1,099-byte record size, 2.4× on the slower receive queue, with 57% less sending CPU per GiB. The host tap carried one frame per Datagram (407,361 frames for 407,104 Datagrams in one run): the guest segments in software. The receiver lost nothing beyond a handful of received-queue discards in two runs (at most 59), no send failed, and the probe's packer discarded 0–12 Datagrams per run (its missing safeguard 1).
- **Stream:** −1.6% at the pin (481 → 473 Mbit/s; the ranges 476–501 and 446–487 overlap). Stream batches stay at about 9.6 segments per send either way, and the probe formed at most two glued batches in a stream run, one of 26 segments, so with stream packets below the maximum size: the case #1825's safeguard 6 forbids. The adopted shape should therefore leave the stream as it is; the probe cannot show that to better than about 2%.
- **In this cell a Windows sender is far slower than a Windows receiver** (a stream sends about 43k packets/s, about 9.6 per segmented send, against 327k/s received), because every send call costs the guest tens of microseconds. That is a property of the emulated adapter as much as of Windows; a real NIC's send path, and the size of gluing's gain on it, are unmeasured.
- **Gluing harms nothing measured here, so it needs no Windows exception**, and its default-on scope can stand.

### Does the guest offer USO, and what is Windows USO's segment limit?

- **No NIC USO here; the stack segments in software.** `Get-NetAdapterUso` finds no USO settings for the `e1000e` adapter (Intel 82574L, driver 12.19.1.32 dated 2015, NDIS 6.50), and its advanced properties list LSOv2 for TCP only. `netsh int udp show global` reports `Send Offload State: enabled`, and the fork's probe (`UDP_SEND_MSG_SIZE` readable) turns segmented sends on (`q69_uso_enabled` = 1 in every run). Segmented sends therefore leave the guest as separate frames (the host tap counts one frame per datagram), and the saving is in the guest's send calls, not on the wire. **measured**
- **Microsoft documents no segment-count limit for the Winsock option.** `UDP_SEND_MSG_SIZE` only says the stack breaks the buffer into messages of the given size, the last possibly shorter ([IPPROTO_UDP socket options](https://learn.microsoft.com/en-us/windows/win32/winsock/ipproto-udp-socket-options)). The NDIS USO rules bind hardware offload only: the stack offloads a send to a USO NIC only if it exceeds `MSS × (MinSegmentCount − 1)`, fits the driver's `MaxOffLoadSize`, and (unless the driver reports `SubMssFinalSegmentSupported`) divides evenly into segments; otherwise the stack does the work ([UDP Segmentation Offload (USO)](https://learn.microsoft.com/en-us/windows-hardware/drivers/network/udp-segmentation-offload-uso-), page dated 2024-12-18). **source**
- **Measured on this guest: no segment-count limit up to 4,000 segments.** One `WSASendMsg` per row, with `UDP_SEND_MSG_SIZE` as a control record (the fork's encoding), from the guest to a Linux receiver on the host (`checks/usolimit`, `checks/usolimit2`):

| Segment size (bytes) | Segments per send | Bytes per send | Send result | Datagrams received |
| ---: | --- | --- | --- | --- |
| 1,200 | 1, 2, 8, 16, 32, 48, 54 | up to 64,800 | success | all, intact |
| 1,200 | 55, 56 | 66,000, 67,200 | success | all |
| 1,200 | 32 with a 700-byte last segment | 37,900 | success | all, last 700 |
| 100 | 64 … 655 (255, 256, 257, 511, 512, 513 included) | up to 65,500 | success | all |
| 64 | 512, 513, 1,000, 1,023 | up to 65,472 | success | all |
| 20 | 512, 1,024, 2,048, 3,275, 3,276, 4,000 | up to 80,000 | success | all |
| 1,452, 1,472, 1,473 | 2, 8 | up to 11,784 | success | all (1,473 fragmented; this socket had no DF) |

  Winsock reports 0 bytes sent for a segmented send up to 65,535 bytes and the full length above it (the fork already treats any success as complete). So on Windows Server 2025 with software USO the only bound a fork batch could meet is the buffer, and the fork's GSO buffer is 20 KiB ([`protocol.go` L114](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/protocol/protocol.go#L114)): at most 20,480 / size segments, for example 16 Datagram packets of 1,218 bytes or 512 of 40 bytes. quinn-udp hard-codes 512 Windows segments as "empirically found on Windows 11 x64" ([`quinn-udp` `windows.rs`](https://searchfox.org/firefox-main/source/third_party/rust/quinn-udp/src/windows.rs)); this guest accepted more, so that figure is a library choice, not a Windows limit here. A NIC with hardware USO was not tested.

## 6. Question 5: baseline Windows rates

One native Wire, MTU 1500, sub-millisecond round trip, an otherwise idle guest, Datagrams of 1,191 bytes (the ceiling today; the adopted 1,397-byte ceiling would carry about 17% more per packet if the packet rate held, **derived**, not measured). Medians (**measured**): three runs per row host → guest (P1), five or six guest → host (R1 and R2 pooled, GARM-overlapped runs left out); the faster receive queue first, the slower one after the slash where it was measured. "Today" is `main` with `v0.62.1-fast.7`; the lever rows add the probe switches named.

| Direction and stack | Datagrams at the pin | Datagrams, default GC | Stream at the pin | Stream, default GC |
| --- | --- | --- | --- | --- |
| Host → guest, today | 275k/s, 2.62 Gbit/s (7.8% discarded) / 188k/s, 1.79 | 145k/s, 1.38 (11.5%) | 355k/s, 3.88 / 237k/s, 2.59 | 327k/s, 3.57 |
| + 1,024-entry received-Datagram queue | 290k/s, 2.77 (0.12%) | — | — | — |
| + URO (today's reader) | 315k/s, 3.00 (3.7%) | 170k/s, 1.62 (11.7%) | 371k/s, 4.05 | 324k/s, 3.54 |
| + URO + Windows copy-at-read | 310k/s, 2.95 (5.1%) | 177k/s, 1.69 (12.5%) | 380k/s, 4.15 / 285k/s, 3.11 | 366k/s, 4.00 |
| + URO + copy-at-read + 1,024 queue | 326k/s, 3.11 (0.05%) / 245k/s, 2.33 (1.0%) | — | — | — |
| Guest → host, today | 12.3k/s, 0.117 / 16.7k/s, 0.159 | 12.3k/s, 0.118 | 44.1k/s, 0.48 | 43.0k/s, 0.47 |
| Guest → host + gluing (#1814 probe) | 41.4k/s, 0.394 / 39.3k/s, 0.374 | 33.3k/s, 0.317 | 43.4k/s, 0.47 | — |

- The host → guest direction is the one #1801 named for the Windows target, because URO is a receive lever. The guest's own sends are far slower (about 12k Datagrams/s and 44k stream packets/s today, 41k Datagrams/s with gluing, section 5), so a Windows target for a Windows *sender* would be a different and much lower number.
- Datagram rows without the 1,024-entry queue discard 4–13% of Datagrams after acknowledgment at the fork's 128-entry queue; the target should be set on the bundle's 1,024 entries, where discards are 0.05–0.12% on the faster queue and about 1% on the slower one.
- Per-packet framing: a stream packet here carries about 1,365 bytes of payload on average (**derived**: Mbit/s over packets per second), a Datagram packet 1,191.

## 7. Not explained

- **Why the guest's second receive queue is 25–33% slower** (P1's four pairs). The slower runs carry DPC time on vCPU 1 as well as vCPU 0 (`diag4`), but what makes that queue costlier was not traced.
- **What sets the stuck state's onset at 2,048 buffers** (1 of 216 runs), and whether the W3 guest avoided it by luck or by its unpinned vCPUs.
- **Why copy-at-read costs Datagrams 1.6% at the pin** (3,003 → 2,954 Mbit/s with more received-queue discards, 3.7% → 5.1%). Over URO alone it gains 4% on Datagrams at the default GC, and 13% / 2.6% on the stream (default GC / pin).
- **Why a one-packet send through the fork costs about 70 µs of kernel CPU** when the raw `udp` arm's plain `sendto` costs 22 µs. The segment-size tag is not the cause (R3, section 5); what is was not traced.
- **Why the stream without URO is 9% faster at the pin than at the default GC** in P1 (3,567 → 3,879 Mbit/s); the receiver's GC (31 cycles a second at the default, 1 at the pin) is the likely part, untested.
- **The probe's rare short stream batches:** with `-glue` a stream run formed a handful of glued batches (up to 26 segments, so below the maximum packet size), the gap #1825's safeguard 6 closes; too few to move the rate, but the probe is not the adopted shape.
- **Real hardware.** Every figure is one virtual NIC without hardware URO or USO, on a guest without Hyper-V enlightenments (14% of its vCPUs in timer interrupts at idle). A physical Windows host with a URO- and USO-capable NIC would change the per-packet costs and probably the size of every gain here.

## 8. Evidence and builds

- **Evidence directory** (mbp128): `/Volumes/worktrees/wiremux/native-gap-evidence/1869-windows-uro/` (`README.txt` describes every file). Campaigns F1, F2, P1, R1, R2, R3 (and the stopped P2's warm-up runs) with their `meta.txt`, `summary.txt`, per-run JSON and counters; analysis outputs `an-*.txt`, `md-*.txt`, `q3-*.txt`; the checks in `checks/`; the cell diagnosis in `diag1`–`diag4`, `pintest1`–`pintest4`, `porttest1`; the gate log `busy1869.log`; `incidents.txt`.
- **Rig** (pushed, fast-forward, never merged): `codex/native-gap-rig` (this ticket's commits f190cb0d, c452b087, 6d08b84c, 1ff590f0 and b47a253a, on top of b01af53f): Windows CPU and working set (`usage_windows.go`), the `winvm` cell and its guest-agent helper (`winqga.py`), `PORT` and `GATE` for every cell, the guest's QEMU CPU per run, `WCPUMASK` and `-lport`, and PROTOCOL.md's `winvm` paragraphs.
- **Probe** (never pushed): worktree `/Volumes/worktrees/wiremux/1869-probe`, detached at 870295a4 with local commits (`-uro`, `-wcr`, `-glue`, `-rq`, `-nogso`, per-peer roles, binding admission counters, `cmd/uro1869`, `rig-1869.mod`).
- **Fork copy** (never pushed): `fork/qgf-1869` = `v0.62.1-fast.7` + `fork/qgf-1869.diff` (knobs off by default, counters only otherwise); the fork's tests cross-compiled for the guest as `fork/quic-fast7.test.exe` and `fork/quic-1869.test.exe`.
- **The guest** `wiremux-1869-uro` (owner-approved for this ticket and #1870): an overlay on the read-only infra golden `garm/windows-server-2025-amd64/v4/base.qcow2`, with its overlay, NVRAM copy and domain XML in `/srv/infra/libvirt/work/wiremux-1869-uro/` on minimax. Guest changes: one inbound firewall rule for UDP 47869–47872 and `Receive Buffers` 2,048. It was deleted on 2026-10-19, after #1870 closed. Its final domain XML and a rebuild recipe are kept in the evidence directory's `vm/` (`domain-final.xml`, `REBUILD.txt`).
- **Host sharing:** every run passed `busy1869.sh`; nine yield requests from the quic 743, 809 and 822 sessions were granted between runs (and quic 742's hold was kept before the guest's first boot); runs that overlapped a GARM guest are quarantined in the tables; nothing on minimax was changed outside the guest's own directory and domain.
