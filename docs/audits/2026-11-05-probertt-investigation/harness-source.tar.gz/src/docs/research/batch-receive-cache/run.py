#!/usr/bin/env python3
"""Disposable, finite issue #1661 comparison. Refuse overwrites; no retries."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / 'raw'
BIN = ROOT / '.cache/batch-receive-cache'
IMAGE = 'golang@sha256:69a7b9788769bec032d238959b61854e9ae87f57be9029ec04e9885fabf99195'


def write_new(path, data):
    with path.open('x') as f:
        f.write(data)


def execute(args, timeout=45):
    try:
        r = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        return r.returncode, r.stdout
    except subprocess.TimeoutExpired as exc:
        return 124, (exc.stdout or b'') + b'\nExternal timeout\n'


mode = sys.argv[1]
if mode == 'environment':
    commands = {
        'host': ['sh', '-c', 'uname -a; sw_vers; docker version'],
        'host-toolchain': ['sh', '-c', 'GOTOOLCHAIN=local go version && go version && go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS'],
        'container': ['docker', 'run', '--rm', '--network', 'none', '--cpus', '2', '--memory', '2g', '-e', 'GOTOOLCHAIN=local', IMAGE, 'sh', '-c', 'GOTOOLCHAIN=local go version && go version && go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS && uname -a && cat /proc/cpuinfo && cat /proc/meminfo && cat /sys/fs/cgroup/cpu.max && cat /sys/fs/cgroup/memory.max'],
    }
    for name, args in commands.items():
        code, output = execute(args)
        write_new(OUT / f'{name}.txt', '\n'.join(s.rstrip() for s in output.decode().splitlines()).rstrip() + '\n')
        if code:
            raise SystemExit(code)
    raise SystemExit(0)
if mode == 'identity':
    revision = sys.argv[2]
    sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    data = {'revision': sha, 'binary_sha256': hashlib.sha256((BIN / f'{revision}.test').read_bytes()).hexdigest(), 'aid_sha256': hashlib.sha256((OUT.parent / 'capture_test.go.txt').read_bytes()).hexdigest(), 'image': IMAGE}
    write_new(OUT / f'{revision}-identity.json', json.dumps(data, indent=2) + '\n')
    raise SystemExit(0)
if mode in ('baseline-pre', 'candidate-pre'):
    revision = mode.removesuffix('-pre')
    cells = [(revision, s, 'smoke', False) for s in (False, True)]
    cells += [(revision, True, 'profile', True)]
elif mode == 'compare':
    cells = [(rev, sel, str(rep), False) for rep in range(1, 4)
             for rev in (('baseline', 'candidate') if rep % 2 else ('candidate', 'baseline'))
             for sel in ((False, True) if rep % 2 else (True, False))]
else:
    raise SystemExit('expected environment, identity REV, baseline-pre, candidate-pre, or compare')
ledger = []
for revision, selected, label, profile in cells:
    name = f'{revision}-{"selected" if selected else "unselected"}-{label}'
    directory = OUT / name
    directory.mkdir(exist_ok=False)
    args = ['docker', 'run', '--rm', '--network', 'none', '--cpus', '2', '--memory', '2g',
            '-e', 'GOMAXPROCS=2', '-e', 'GOTOOLCHAIN=local', '-e', 'COST_WORKLOAD=stream',
            '-e', f'COST_SELECTED={int(selected)}', '-e', f'COST_PROFILE={int(profile)}',
            '-e', f'COST_SMOKE={int(label == "smoke")}', '-e', 'COST_OUTPUT=/out',
            '-v', f'{BIN / (revision + ".test")}:/capture.test:ro', '-v', f'{directory}:/out',
            IMAGE, '/capture.test', '-test.run=^TestSelectedIOCostCapture$', '-test.v', '-test.timeout=30s']
    code, output = execute(args)
    (directory / 'capture.log').write_bytes(output)
    ledger.append({'cell': name, 'exit_code': code, 'command': args})
    (OUT / f'{mode}-ledger.json').write_text(json.dumps(ledger, indent=2) + '\n')
    print(name, code, flush=True)
raise SystemExit(any(c['exit_code'] for c in ledger))
