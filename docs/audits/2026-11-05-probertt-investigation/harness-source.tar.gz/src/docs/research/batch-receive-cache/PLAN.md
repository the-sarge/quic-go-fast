# Selected batch receive allocation reduction

User-approved execution contract for [#1661](https://github.com/GridSwarm/wiremux/issues/1661), approved 2026-09-23. This standalone one-PR follow-up is outside the completed SIO slice graph. Baseline: `c18c11538896c238e626699553d1006621d32b21`.

## Outcome and implementation boundary

Reduce avoidable allocation traffic at `capableConn.ReadBatch` without changing admission, caller buffer ownership, socket ownership, or concurrent-read behavior. Confirm current allocation sites and escapes before runtime changes. A private scratch object holds eight message headers and 384 ancillary bytes per slot; retain at most one idle object per connection. Borrow/return under a short mutex, never held during reads, filtering, or copying. Concurrent borrowers have independent scratch. Oversized batches or ancillary requirements retain the existing uncached path. Keep the current effective ancillary lengths even when capacity is larger. Clear borrowed references, result metadata, and private ancillary contents before caching. The adapter's idle reference has the connection's lifetime. Linux's existing x/net native-header pool may additionally retain cleared scratch until its temporary entry is reused or discarded by garbage collection; no immediate collectibility on connection release is promised. This lifetime clarification was explicitly approved by the user; the [review disposition](https://github.com/GridSwarm/wiremux/pull/1662#issuecomment-5801074061) records the evidence that prompted it.

Keep `selectedScopeBatch`, remote filtering, compaction, and control-copy semantics unchanged. Ordinary/OOB reads, unselected reads, managed packet adapters, public APIs, dependencies, and socket construction remain unchanged. Added blast radius is bounded retention and brief synchronization on selected batch reads. No global pool, new socket owner, goroutine, dependency fork, receive-stack redesign, maintained benchmark framework, broad performance claim, or unrelated optimization is authorized.

## Acceptance

- Confirm the current allocation owner and document a scoped implementation/evidence plan before making runtime changes.
- Implement the justified change at the owning receive seam, with focused regressions for the buffer lifetime and admission behavior it changes. If safe reduction is not justified, document the evidence and decision rather than claiming an improvement.
- Use a predeclared bounded before/after comparison with pinned revisions, environment and actual selected/unselected stream paths. Separate profiling from headline results; report delivered work, CPU, allocation traffic and any retention/throughput tradeoffs. Do not introduce an arbitrary speedup threshold or expand the historical SIO-5 campaign.
- Run the repository-required validation and appropriate focused concurrency checks, then complete review and exact-head merge gates for any implementation PR.

## Representation and safety

Supported inputs are the existing typed `ipv4.Message`/native socket result contract, including the existing QUIC single-payload-buffer compaction domain; this change does not generalize scatter/gather support. QUIC owns caller buffers, `capableConn` owns scratch, `PacketBinding` owns scope admission, and existing OS parsers own ancillary decoding. Safety invariants apply universally inside that existing supported domain; finite regressions provide evidence, not an exhaustive proof. Performance claims are example-level measurements only. Preserve exact-socket/source/family/index enforcement, numeric IPv6 ingress scope, unrelated ancillary metadata, truncation, remote filtering, accounting, deadlines, cancellation, and Close behavior.

Closure is triggered by admission/lifetime consequences and multiple reachable reuse/concurrency states. The following finite matrix bounds it. The cache owner enforces independent call lifetime; existing binding/filter/copy owners retain packet semantics.

| Semantic class | Required disposition | Evidence |
| --- | --- | --- |
| First call and sequential reuse | Correct independent results; caller backing storage unchanged | Focused batch-read regression and allocation observation |
| Changed batch/OOB sizes | Preserve effective lengths and truncation; oversized calls remain uncached | Small/large/small batch-read regression |
| Mixed scope/remote admission | Scope first, then peer filter, byte-copy compaction, accurate count, invalidated tail | Existing admission tests plus selected reuse regression |
| All rejected | Reread without returning rejected or stale results | Focused batch-read regression |
| Partial result with error | Original error, zero returned count, invalidated caller metadata | Existing error tests plus selected reuse regression |
| IPv6 ancillary scope | Matching numeric index admitted; missing/wrong/truncated index rejected; other metadata preserved | Native scope tests plus repeated batch admission regression |
| Overlapping reads | Independent scratch and caller storage | Deterministic overlap test under race detector |
| Deadline/cancellation/Close | Preserve wakeup; cache does not block termination | Focused native deadline/Close coverage and existing cancellation tests |

Runtime cache is shipped behavior; retained admission checks are required safety enforcement. Tests and the capture aid are verification aids. This plan, the result report, and receipts are process/traceability metadata. No verification aid is an independently maintained deliverable. The disposable capture remains outside ordinary builds and retires when this finite report is complete. No recursive harness closure, mutation campaign, or additional stress campaign is authorized.

## Finite comparison

Retain a new report and raw evidence here, leaving all historical SIO-5 artifacts untouched. Reuse its public `wiremux.Dial` stream topology and delivery accounting. Capture baseline and final runtime-candidate binaries with pinned revisions and checksums. Use image `golang@sha256:69a7b9788769bec032d238959b61854e9ae87f57be9029ec04e9885fabf99195`, Linux ARM64 loopback, two CPUs, 2 GiB memory, `GOMAXPROCS=2`, and audited Go 1.27.1. Both peers, relay, and runtime share a process.

Budget: four smoke cells (two revisions × selected/unselected); twelve unprofiled cells (two revisions × selected/unselected × three repetitions), alternating revision/treatment order; two separate selected-stream profile cells, one per revision. Run the baseline smoke/profile before runtime changes, then the interleaved headline comparison with both pinned binaries available. Each headline/profile cell uses one-second warmup and three-second measurement plus drain. Smoke retains the existing 100 ms warmup and one-second measurement. The 18 cells terminate the campaign. Failed cells remain evidence; only demonstrated external infrastructure failures permit replacing an identical cell. No extra platform, workload, repetition, or threshold.

Report delivered bytes/rate, CPU seconds, allocation bytes/counts, normalized resource cost per delivered byte, and post-measurement/post-GC heap observations. Keep profile results separate from headline medians. Distinguish bounded scratch retention from process-wide heap observations. If results do not justify safe reuse, report the outcome and stop before runtime merge.

## Operating discipline and completion

Use focused TDD at the approved batch-read seam, relevant existing admission/native tests, focused concurrency coverage once under `-race`, and `task verify`. Follow [the repository review protocol](../../REVIEW-LOOP.md) and its shared baseline: one initial RAS review, at most one replacement after accepted fixes, scoped verification, exact-head local certification, successful ready-phase CI, then squash merge. No `task preflight` exists at the baseline; `task verify` and relevant native/focused gates are the local certification equivalents. Any changed runtime candidate invalidates its evidence/certification; stop to reconcile the fixed measurement budget rather than silently adding cells. Docs-only reporting follows the baseline polish exemption.

Stop if safe reuse requires broader ownership, altered admission semantics, expanded evidence, repeated unresolved precise-invariant failures, or unsafe completion within this one PR. Keep audit chronology and receipts in the PR discussion rather than appending them to this contract. After merge only, append the dev journal, revalidate any deferred findings, and complete OmniFocus task `kNdmLgHOTOl`.
