#!/usr/bin/env python3
"""Summarize the fixed issue #1661 cells; not a maintained benchmark tool."""
import hashlib
import json
from pathlib import Path
from statistics import median

OUT = Path(__file__).resolve().parent / 'raw'
ledgers = [json.loads((OUT / f'{stage}-ledger.json').read_text()) for stage in ('baseline-pre', 'candidate-pre', 'compare')]
cells = [c for ledger in ledgers for c in ledger]
assert [len(x) for x in ledgers] == [3, 3, 12]
assert len({c['cell'] for c in cells}) == 18
accounting = []
for cell in cells:
    assert cell['exit_code'] == 0, cell
    result = json.loads((OUT / cell['cell'] / 'result.json').read_text())
    for phase in ('warmup', 'measurement'):
        m = result[phase]
        assert m['Accepted'] == m['Unique'] == m['Attempted'], (cell, phase)
        assert m['Bytes'] == m['Unique'] * 32768, (cell, phase)
        assert 0 <= m['DeliveredInWindow'] <= m['Accepted'], (cell, phase)
    accounting.append({'cell': cell['cell'], 'accepted': result['measurement']['Accepted'], 'delivered': result['measurement']['Unique']})
(OUT / 'accounting.json').write_text(json.dumps(accounting, indent=2) + '\n')
rows = []
for revision in ('baseline', 'candidate'):
    for selection in ('unselected', 'selected'):
        data = [json.loads((OUT / f'{revision}-{selection}-{rep}/result.json').read_text()) for rep in range(1, 4)]
        metrics = {'delivered_gbit_s': [], 'delivered_gib': [], 'cpu_seconds': [], 'allocated_mib': [], 'million_allocations': [], 'cpu_seconds_per_gib': [], 'allocated_mib_per_gib': [], 'heap_mib_after': [], 'heap_mib_after_gc': []}
        for r in data:
            m = r['measurement']
            gib = m['Bytes'] / 2**30
            metrics['delivered_gbit_s'].append(m['DeliveredInWindow'] * 32768 * 8 / m['SendSeconds'] / 1e9)
            metrics['delivered_gib'].append(gib)
            metrics['cpu_seconds'].append(r['cpu_seconds'])
            metrics['allocated_mib'].append(r['allocated_bytes'] / 2**20)
            metrics['million_allocations'].append(r['allocations'] / 1e6)
            metrics['cpu_seconds_per_gib'].append(r['cpu_seconds'] / gib)
            metrics['allocated_mib_per_gib'].append(r['allocated_bytes'] / 2**20 / gib)
            metrics['heap_mib_after'].append(r['after']['HeapAlloc'] / 2**20)
            metrics['heap_mib_after_gc'].append(r['after_gc']['HeapAlloc'] / 2**20)
        rows.append({'revision': revision, 'selection': selection, 'metrics': {k: {'median': median(v), 'min': min(v), 'max': max(v)} for k, v in metrics.items()}})
(OUT / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
for row in rows:
    print(row['revision'], row['selection'])
    for key, values in row['metrics'].items():
        print(f"  {key}: {values['median']:.3f} [{values['min']:.3f}, {values['max']:.3f}]")
checksums = {str(p.relative_to(OUT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.rglob('*')) if p.is_file() and p.name != 'sha256.json'}
(OUT / 'sha256.json').write_text(json.dumps(checksums, indent=2) + '\n')
