# Remote Datagram foundation review

Package C of the [approved preparation](../work-items/qualification-preparation.md) adds version-4 single-forward Datagram measurements to the existing controller and bounded artifact owners. This is measurement tooling, not qualification evidence. Burst, reliable control, four connections, operational recovery and campaign verdicts belong to D/G. Production transport and earlier workload/result formats remain unchanged.

Initial review: PR1499, head `547aa386f77f59dfdd82dd074f9fad09be20f73f`, run `20260913T084416-752d568c4947e3417c229a72`, synthesis SHA-256 `1a1f7a049d5aa9da24f05b1294f28a36f050bf9f8e014efd1e12633453d1f3c3`. The claude-fable provider failed; the completed providers met synthesis quorum. The operator agent independently dispositioned the findings below. No earlier fresh review exists for C; the bounded review budget is one initial review, accepted-fix verification and at most one replacement.

| Finding | Disposition | Evidence and enforcement owner |
| --- | --- | --- |
| C001 | fix-now | `runController` must collect associated partial peers for version 4 without inventing a reliable-stream summary. Restrict only `summarizeStream` to versions 2/3, preserving cancellation and collection. Failed copy, rejected identity and cancellation regressions reproduced the defect; each now checks returned and persisted results. |
| C010 | fix-now | Add a short native version-4 local CLI subprocess check that builds the actual entry point and verifies both finite ledger artifacts. It exercises the local controller branch and does not assert timing qualification. |
| C002 | defer | Existing local timing-qualification semantics are unchanged. Actual physical calibration and readiness remain package G obligations. |
| C003, C004, C007, C009, C011, C012 | duplicate | Same C001 stream-summary predicate and owner. Missing verified artifacts cannot be reconciled as complete; the CLI returns an error before printing a successful headline. No separate implementation root remains. |
| C005 | defer | A fixed remote copy deadline may be insufficient for the maximum artifact. Package G must recover a retained source without recapturing traffic; C already preserves source custody on failed copy. |
| C006, C008 | reject | Existing phase-entry evidence includes collection in the measurement-start convention; the proposed alternate timing interpretation is not the accepted convention. |

The local review receipts retain red/green regressions and CLI evidence under `qualification-preflight-20260913`. Verification and final candidate certification are recorded after completion. No physical qualification capture is claimed.


Verification run `20260913T084416-752d568c4947e3417c229a72-verify-20260913T092652-c95dd115f3bde0bb7d2cca7a` completed at `13f1fa5bd65521a95b438ce17c9cc1809606015b` with blocking projection clear and all twelve clusters covered. It resolved C001 and its duplicates and accepted the remaining scope dispositions. C010 remained open because the local fixture did not explicitly inspect its local qualification field. The fixture now checks that the persisted field exists and is Boolean, while accepting either observed timing outcome; requiring a universally passing local calibration would invent a hardware guarantee. No production code or qualification semantics change in this follow-up.

At the same candidate, `task verify` passed, the focused failure-path race checks passed, and Linux/amd64 and Windows/amd64 CLI builds passed. Those receipts precede the test-only field-presence addition; the final candidate is recertified separately.
