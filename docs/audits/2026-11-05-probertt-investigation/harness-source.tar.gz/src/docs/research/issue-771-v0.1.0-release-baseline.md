# Exact wiremux v0.1.0 release baseline

Research note for
[Audit the exact v0.1.0 release baseline](https://github.com/GridSwarm/wiremux/issues/771),
under
[Define the private wiremux v0.1.0 release plan](https://github.com/GridSwarm/wiremux/issues/767).

## Answer

The connectivity kernel is substantially evidenced, but the repository is not
ready to promote v0.1.0. At the audited default-branch commit, the full local
non-publishing release preflight passes and the source implements the accepted
relay, STUN, authenticated probing, QUIC upgrade, encrypted channel, root
`Dial`, Datagram, and server-kit commitments. The remaining release gaps are
outside that gate: genuinely restricted-NAT evidence, immutable-candidate
consumer evidence, a frozen v0.1.x compatibility contract, retained Linux
artifacts and checksums, packaged-binary Linux smoke tests, private GitHub
Release controls, and exact-candidate promotion/rollback evidence.

No existing non-Wayfinder issue represents those large gaps. The release plan
therefore must turn them into execution blockers or checklist items; an empty
ordinary blocker queue would not be release-readiness evidence. The two open,
non-deferred CI bugs can receive narrow evidence-backed deferrals, but they
must not remain silently undispositioned. The other ordinary open issues are
already explicitly deferred and do not invalidate the current kernel baseline.

## Snapshot and method

This audit is bound to the following snapshot:

- Repository: private `GridSwarm/wiremux`; default branch `main`.
- Commit: [`a0207b3bb1fd0ca28274267e476a0366e6f2be71`](https://github.com/GridSwarm/wiremux/commit/a0207b3bb1fd0ca28274267e476a0366e6f2be71),
  with clean local `main`, `origin/main`, and the GitHub default-branch head all
  matching.
- Audit date: 2026-07-14.
- Local audit host: Darwin/arm64 with installed and selected Go `go1.26.5`.
- Sources: accepted repository ADRs and PRD, tracked source/tests/workflows,
  repository documentation, and first-party GitHub state queried with `gh`.
  No secondary source was used.

The principal executable observation was:

```text
task release-check: PASS
  task verify: PASS
  docs/module/tests/lint: PASS (golangci-lint: 0 issues)
  required race gates: PASS
  govulncheck -test ./...: PASS (0 reachable vulnerabilities)
  Darwin/arm64 and Windows/amd64 cross-build and cross-vet: PASS
  production-budget contract: PASS
```

The exact commit also has a successful GitHub
[`Verify` push check](https://github.com/GridSwarm/wiremux/actions/runs/29291222308),
but the change was documentation-only. The workflow consequently skipped Go
setup and all Go/preflight steps, as
[`ci.yml`](../../.github/workflows/ci.yml) and
[`docs/CI.md`](../CI.md) prescribe. That green check is documentation evidence,
not exact-commit release-preflight evidence; the local `task release-check`
result above supplies the latter for this audit only.

## Requirements already evidenced

| Requirement area | Current evidence | Baseline judgment |
| --- | --- | --- |
| Accepted v1 scope and public kernel | [ADR-0001](../adr/adr-0001-vision-and-scope.md) and [PRD-0001](../prd/prd-0001-connectivity-kernel.md) are accepted. The implementation and tests cover root `wiremux`, `connect`, `relay`, `relayurl`, `stun`, `channel`, `transport/quic`, `wiremuxtest`, and `cmd/wiremux-server`; `task release-check` passed all packages. | Evidenced at source/test level. |
| Identity-agnostic auth and lifecycle | [ADR-0010](../adr/adr-0010-auth-context-lifecycle-ownership.md), the root tests, [`connect`](../../connect), and [`channel`](../../channel) pin least-privilege transport auth, channel-use claims, release, revocation, and aggregate teardown. Focused race gates passed. | Evidenced at source/test level. Downstream implementations still need immutable-candidate evidence. |
| Relay, STUN, and server kit | [`docs/DEPLOYMENT.md`](../DEPLOYMENT.md) documents private TLS, ACME, co-located and split relay/STUN, mode restrictions, rate limits, and graceful shutdown. [`cmd/wiremux-server/serve_test.go`](../../cmd/wiremux-server/serve_test.go) exercises explicit TLS/fingerprint output, relay TLS, STUN Binding, co-location, mode restrictions, and clean shutdown; service-group tests cover bounded error and shutdown paths. | Strong in-process evidence. Not packaged-binary Linux smoke evidence. |
| Direct upgrade and relay fallback | [`internal/integration/consumer_upgrade_test.go`](../../internal/integration/consumer_upgrade_test.go) covers tapmux- and file-sync-shaped relay-to-direct QUIC upgrades. The accepted PRD's upgrade-control, authenticated-probe, selected-pair, socket-ownership, fallback, and QUIC criteria are backed by the `connect`, `transport/quic`, and integration suites run by the gate. | Evidenced for loopback and deterministic test paths. |
| Optional Datagram surface | [ADR-0009](../adr/adr-0009-optional-datagram-capability.md), [the conformance record](issue-624-quic-datagram-conformance.md), root/QUIC tests, and [`internal/integration/datagram_contract_test.go`](../../internal/integration/datagram_contract_test.go) cover negotiated presence/absence, payload limits, loss, concurrency, ownership, and teardown. Focused race gates passed. | Evidenced at the current QUIC configuration and dependency versions. Consumer adoption remains separate. |
| Toolchain and dependency integrity | [`go.mod`](../../go.mod) uses `go 1.26` and `toolchain go1.26.5`. The base toolchain was `go1.26.5`; module download and verification passed. CI pins Go `1.26.5` and reports the required environment. | Evidenced for the audited checkout. |
| Portable validation | [`Taskfile.yml`](../../Taskfile.yml) defines `verify`, `cross-check`, and non-publishing `release-check`; [`docs/CI.md`](../CI.md) describes their routing. Full local preflight and cross-build/vet passed. GitHub protects `main` and requires the stable `Verify` context for everyone. | Gate exists and passes. It is not an artifact-production or runtime-smoke gate. |
| Vulnerability and static-analysis baseline | Pinned golangci-lint `v2.12.2` reported zero findings, including the configured gosec checks. Pinned govulncheck `v1.3.0` reported zero reachable vulnerabilities and zero vulnerabilities in imported packages. | Supports the no-known-reachable-vulnerability claim, with the qualification below. |
| Linux build feasibility | Diagnostic `CGO_ENABLED=0` cross-builds of `./cmd/wiremux-server` for Linux amd64 and arm64 both produced statically linked ELF executables. The temporary files were deleted after inspection. | Source is cross-buildable; this is deliberately not retained artifact or smoke evidence. |

The govulncheck verbose result also reported
[`GO-2026-5932`](https://pkg.go.dev/vuln/GO-2026-5932) at module level because
the required `golang.org/x/crypto v0.54.0` module contains the unmaintained
`openpgp` package. wiremux does not import or call the affected package, and
govulncheck explicitly reported that the code is affected by zero
vulnerabilities. The release evidence should retain that distinction instead
of claiming that every required module is advisory-free.

## Release gaps and required treatment

| Requirement | Exact baseline gap | Required release treatment |
| --- | --- | --- |
| Restricted-NAT success/fallback matrix | [`restricted_nat_fabric_helpers_test.go`](../../internal/integration/restricted_nat_fabric_helpers_test.go) independently models EIM, ADM, and APDM mappings with EIF, ADF, and APDF permission keys. `TestRestrictedNATMatrixRows` and `TestRestrictedNATMatrixUsesFullyIsolatedState` in [`restricted_nat_fabric_test.go`](../../internal/integration/restricted_nat_fabric_test.go) maintain the exact nine-row deterministic matrix through root Dial, production STUN/probes/fallback, exact sockets, real QUIC where direct, synchronized relay fallback, and bidirectional payload. Immutable-candidate execution, the separate privileged kernel rows 4/7, and evidence aggregation remain outstanding. | Block final promotion until the exact candidate runs the maintained matrix and the approved kernel/aggregation evidence is complete. The destination does not require universal punch success. |
| Consumer compatibility and migrations | [`docs/RELEASE.md`](../RELEASE.md) says downstream consumers have not migrated to the optional Datagram surface and requires immutable revisions for consumer evidence. It names owner-first sequencing, but the wiremux checkout contains no exact-candidate gates for codemux, keymux, tapmux, SwarmCast, or GridCast. | Audit every known and newly discovered consumer. Buildable integrations must gate promotion; unavailable integrations need explicit evidence-backed deferral. Do not treat in-repo consumer-shaped tests as downstream build evidence. |
| v0.1.x compatibility freeze | Release documentation records the `ErrUpgradeTransportNotConverged` display-text change, the accepted `UpgradeResult.Datagrams` unkeyed-literal source break, and supported `wiremuxtest`, but there is no approved v0.1.x compatibility inventory or API/protocol snapshot tied to a candidate. There is also specification drift: PRD package layout includes `wiremuxtest` and release docs protect it, while acceptance criterion 1 still says the package set is “exactly” the older list that omits it. [ADR-0008](../adr/adr-0008-immediate-packet-socket-ownership-transfer.md) still calls consumer-shaped root `Dial` Accept-before-commit cleanup a future obligation, but the referenced tracker item is closed and [`wiremux_accept_before_commit_test.go`](../../wiremux_accept_before_commit_test.go) now supplies the root exactly-once evidence. | Resolve both stale-document statements, approve the Go API/protocol compatibility inventory, and bind it to the immutable candidate before promotion. |
| Exact-candidate validation | The audited commit passes `task release-check`, but no `v0.1.0-rc.1` candidate has been selected. The green GitHub push check on this commit was documentation-only and did not execute Go validation. | Run and retain both `task verify` and `task release-check` against the exact immutable candidate. Candidate evidence must include command, environment/tool versions, commit SHA, logs, and outcome. |
| Linux release artifacts | There are no Git tags, GitHub Releases, retained binaries, checksums, GoReleaser configuration, packaging script, or tracked artifact definition. The current release preflight does not construct Linux artifacts. | Define and execute reproducible Linux amd64/arm64 builds; retain exact filenames, SHA-256 checksums, build inputs, candidate SHA, and provenance. Final release requires the annotated module tag and private GitHub Release notes named by the map. |
| Packaged-server runtime smoke | Strong in-process tests exercise relay, STUN, explicit TLS, ACME listener lifecycle, and shutdown on the development/test platform. No retained evidence runs the packaged Linux amd64/arm64 binaries in representative Linux environments. PRD acceptance criterion 9's public-relay ACME end-to-end claim also has no observed live certificate-issuance/deployment record; the current tests start the ACME listeners without obtaining a public certificate. | Block promotion until both packaged architectures pass the approved relay, STUN, TLS, and graceful-shutdown smoke contract, with logs tied to artifact checksums. Decide separately whether live ACME issuance is required or explicitly deferred; in-process listener tests are not equivalent. |
| Publication, promotion, and rollback controls | [`docs/CI.md`](../CI.md) explicitly says no tag or release publication automation is present. No repository file defines private release permissions, manual approval, same-commit candidate-to-final promotion, rollback, or release-note assembly. | Approve and exercise a private publication contract before promotion. It must prevent accidental public publication and prove the final tag normally targets the tested candidate commit. |
| Security-product coverage | The repository API reported Code Security, Dependabot security updates, secret scanning, and push protection disabled. The Dependabot open-alert API returned zero open alerts, while code- and secret-scanning APIs were unavailable because those features are disabled. Required gosec, govulncheck, PR changed-content TruffleHog, and scheduled scans do exist. | This is not evidence of a current code vulnerability, but it limits negative assurance. Carry an explicit release risk acceptance/deferral if v0.1.0 proceeds without enabling the private-repository security products; do not describe disabled scanners as clean scans. |
| Operator/release packaging | Deployment documentation is substantive, but there is no version command or embedded build metadata in the server and no release-note/checksum layout. | Decide whether version metadata is part of the artifact contract. At minimum, release notes and checksum records must unambiguously map artifacts to the tag and commit. |

## Existing issue disposition

### Planning tickets that must resolve before handoff

The following named tickets are the map's decision path. They block completion
of the release **plan**, and their resulting decisions/evidence become release
gates; they are not substitutes for later implementation tickets:

- [Audit compatibility across the known wiremux consumers](https://github.com/GridSwarm/wiremux/issues/768)
  owns the downstream inventory and buildability facts.
- [Inventory the v0.1.x compatibility contract](https://github.com/GridSwarm/wiremux/issues/769)
  owns the frozen API/protocol surface and must resolve the `wiremuxtest`
  package-list contradiction.
- [Research a repeatable restricted-NAT release environment](https://github.com/GridSwarm/wiremux/issues/775)
  and [Define the v0.1.0 NAT evidence matrix](https://github.com/GridSwarm/wiremux/issues/770)
  own the currently missing restricted-NAT evidence mechanism and acceptance
  matrix.
- [Audit the private release pipeline and artifact gaps](https://github.com/GridSwarm/wiremux/issues/774)
  and [Approve the private artifact, smoke-test, and promotion contract](https://github.com/GridSwarm/wiremux/issues/777)
  own artifact construction, packaged Linux smoke, private publication,
  promotion, and rollback.
- [Set the named-consumer release gates](https://github.com/GridSwarm/wiremux/issues/776)
  and [Set the v0.1.0 release-blocker disposition](https://github.com/GridSwarm/wiremux/issues/773)
  must convert the evidence into explicit promotion blockers and deferrals.
- [Draft and approve the executable v0.1.0 release plan](https://github.com/GridSwarm/wiremux/issues/772)
  must carry the resulting work, ordering, commands, owners, and go/no-go
  checks into the handoff.

### Open ordinary issues requiring a new explicit release disposition

- [ci: route .gitignore changes through CI contract validation](https://github.com/GridSwarm/wiremux/issues/764)
  is a real change-routing bug: a `.gitignore`-only pull request can bypass the
  CI-contract fixture. It need not block v0.1.0 if the candidate process runs
  `task ci-scripts-check`/`task release-check` directly and no release change
  relies on `.gitignore`-only routing, but that condition and deferral must be
  explicit.
- [ci: make the no-Task lint-cache fallback coverage explicit](https://github.com/GridSwarm/wiremux/issues/765)
  is a documented-fallback equivalence bug. It need not block v0.1.0 if the
  release contract requires the pinned Task runner and uses `task
  release-check`, but that condition and deferral must be explicit. If the
  no-Task path is accepted as release evidence, this issue blocks until fixed.

Neither issue currently carries the repository's `deferred` label. Leaving
them open without one of the explicit treatments above would violate the map's
“no open un-deferred release blocker” rule.

### Existing explicit deferrals that do not block this release baseline

The following issues already contain evidence that they are low/nit coverage,
diagnostic, or refactoring follow-ups and carry `deferred`. They may remain
deferred for v0.1.0 unless later consumer, candidate, or smoke evidence raises
their severity:

- [Follow up low-priority PR #296 RAS polish](https://github.com/GridSwarm/wiremux/issues/297)
- [Add Wire-boundary tests for syscall and closed-pipe teardown errors](https://github.com/GridSwarm/wiremux/issues/599)
- [Bound wiremuxtest consumption-observation stream cleanup](https://github.com/GridSwarm/wiremux/issues/700)
- [Complete wiremuxtest relay configuration-error classification](https://github.com/GridSwarm/wiremux/issues/701)
- [Cover DialPair half-success ownership in black-box contract tests](https://github.com/GridSwarm/wiremux/issues/704)
- [Harden long-lived nil-auth accepted-connection cleanup](https://github.com/GridSwarm/wiremux/issues/728)
- [Extract fallback listener observer helper if test setup grows](https://github.com/GridSwarm/wiremux/issues/742)

These architecture/future-carrier issues are beyond the map's v0.1.0
destination and are already explicitly deferred:

- [transport: lift the accept-once listener state machine into the adapter kit](https://github.com/GridSwarm/wiremux/issues/418)
- [Investigate relay-capable unreliable message paths](https://github.com/GridSwarm/wiremux/issues/707)
- [Explore multi-transport and multipath Wire architecture](https://github.com/GridSwarm/wiremux/issues/708)

The two security-product issues are also explicitly deferred, but their risk
must be named in the release go/no-go record because repository settings confirm
the underlying features remain disabled:

- [[Deferred] ci: enable routed CodeQL coverage](https://github.com/GridSwarm/wiremux/issues/758)
- [[Deferred] ci: add dependency review for module changes](https://github.com/GridSwarm/wiremux/issues/759)

The required gosec/govulncheck/TruffleHog controls and the exact-candidate
security output are the compensating evidence; they do not make disabled
CodeQL, dependency review, or repository secret scanning equivalent to a clean
run.

## Uncertainty and boundaries

- This ticket did not audit downstream repositories; that belongs to
  [Audit compatibility across the known wiremux consumers](https://github.com/GridSwarm/wiremux/issues/768).
  Therefore no consumer is classified here as buildable, unavailable, or safe
  to defer.
- No genuinely restricted NAT, cloud lab, home-router pair, or packet-filter
  environment was exercised. The only NAT implementation audited here declares
  its endpoint-independent/full-cone limitation in source.
- No retained Linux artifact was executed. The diagnostic cross-build proves
  compilation only and was intentionally discarded.
- No live ACME issuance, GitHub pre-release/final publication, release
  permission boundary, promotion, or rollback was exercised.
- The local ordinary `go test ./...` portion of `task release-check` reported
  cached package results; source- and environment-keyed Go test caching is valid
  gate behavior, while the focused `-race -count=1` and production-budget
  commands ran uncached. The immutable candidate record may choose `-count=1`
  for stronger audit readability.
- Govulncheck supplies reachability, not a complete severity-ranked inventory
  of every transitive module advisory. The non-reachable `GO-2026-5932` result
  and disabled GitHub security products must remain visible in the go/no-go
  evidence.
