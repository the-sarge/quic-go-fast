# Issue #1853: where the native send goroutine runs on a busy Mac, and what a thread QoS class does

Research for [Does the native send goroutine leave macOS performance cores under host load, and can a thread priority class keep it there?](https://github.com/GridSwarm/wiremux/issues/1853) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). It puts controlled CPU load beside the native sender on mbp128 and measures how much of the sender's work moves to efficiency cores and what that costs. It then repeats the ladder with the fork's send goroutine locked to its thread, and with that thread raised to the user-initiated or user-interactive QoS class. It reads the scheduler, libpthread and Go sources for why, says how the way a process is launched limits a class, what the class costs other work, and where the change would live. Nothing here implements a change.

Sources are wiremux at the connected-socket probe of [What would a connected socket per peer do to the native ceiling and to per-datagram admission?](https://github.com/GridSwarm/wiremux/issues/1842) (local commit `dc7cb39a` on [d30c3689](https://github.com/GridSwarm/wiremux/tree/d30c3689454c0db2b008562d276d991fe642354f), the shape [Should the native path use a connected socket per peer?](https://github.com/GridSwarm/wiremux/issues/1843#issuecomment-6207453285) adopted for macOS) and `origin/main` [870295a4](https://github.com/GridSwarm/wiremux/tree/870295a497ef862fa51f523c5f64d0eaf06dbed8) for the capability code; the quic-go-fast fork at [`v0.62.1-fast.7`](https://github.com/the-sarge/quic-go-fast/tree/v0.62.1-fast.7); the rig `cmd/nativerig` from `codex/native-gap-rig` (this ticket's additions are under [Method](#method)); the closest xnu Apple publishes ([xnu-12377.121.6](https://github.com/apple-oss-distributions/xnu/tree/xnu-12377.121.6); both Macs run xnu-13432.1.9); [libpthread-539.100.4](https://github.com/apple-oss-distributions/libpthread/tree/libpthread-539.100.4); the macOS 27.0 SDK headers; Go [1.27.2](https://github.com/golang/go/tree/go1.27.2); Apple's developer documentation; and measurements taken for this note on 2026-10-16 (UTC). Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cell.** `tb` only: mbp128 (MacBook Pro M4 Max: 12 performance cores, 4 efficiency cores; `sysctl kern.sched` reports the Edge scheduler) sends from `bridge0` over Thunderbolt to m4mini (Mac mini M4 Pro), both macOS 27 arm64, MTU 1500. The load is on the sender only: N copies of a one-thread CPU-bound spinner at default priority, started 2 s before each pair and stopped with it, at N = 0, 8, 12, 16 and 24 spinners. The cells at 0, 12 and 24 have three runs each, the cells at 8 and 16 one. Both Macs host live GARM runner VMs, and two other sessions used the pair in the same window; see [Method](#method).

**Builds.** One connected-probe binary with the stock fork (`conn`), and one against a fork copy whose `sendQueue.Run` can lock its goroutine to its thread and raise that thread's class (`connqos`). An environment variable on the sender picks the mode, so "locked", "user-initiated" and "user-interactive" are one binary. Arms: native Datagrams at the GC pin (`-ballast 64 -gc-role both`), the native stream, and Datagrams at the default GC. Today's unconnected path (`conn` with the connect turned off on both peers) is included for continuity with [Why does a native packet send on macOS cost about 7.5 µs when a raw UDP send costs 5.4?](https://github.com/GridSwarm/wiremux/issues/1841).

**Launch context.** The kernel caps a QoS class at the process's ceiling, which depends on how the process was started (section 2). The rig had always started the sender from a shell under an app, where user-initiated and user-interactive are both squashed to the default priority, so a class measured there measures nothing. The main ladder therefore starts the sender the way launchd starts a daemon (ceiling: user-initiated), and the user-interactive cells start it as the focal foreground app (no ceiling), through a small launcher that sets those spawn attributes.

## Answer

**Yes, it leaves them, and the connected sender loses a quarter of its Datagram rate and a third of its stream rate.** With 12 to 24 spinners beside it, the native sender process runs 33–38% of its CPU time on efficiency cores (Datagrams; 41–46% for the stream), against 0.1% unloaded, and only 53–60% of its kernel time stays on performance cores (**measured**). Datagrams at the pin fall from 2,225 Mbit/s unloaded to 1,812 at 12 spinners and 1,688 at 24 (−19% and −24%), and the stream from 2,621 to 1,668 and 1,844 Mbit/s (−36% and −30%) (**measured** medians of three runs; percentages **derived**). Today's unconnected path loses less (−7% Datagrams, −12% stream at 24 spinners), but it starts 40% lower.

**User-initiated keeps the send thread on performance cores and the rate at its unloaded level, when the process may use it.** The raised send thread spent at most 0.1% of its time on efficiency cores at every load step, and Datagrams ran at 2,464 and 2,419 Mbit/s at 12 and 24 spinners against 2,381 unloaded; the stream at 2,537 and 2,872 against 2,749 (**measured**). That is +36% and +43% over the default class at the same load for Datagrams, and +52% and +56% for the stream (**derived**). User-interactive, in a focal app, gave the same rates (2,461 and 2,474 Mbit/s for Datagrams), so in a daemon, whose ceiling is user-initiated, nothing is lost. Even unloaded the class was 5–7% faster (2,381 against 2,225 Mbit/s for Datagrams, 2,749 against 2,621 for the stream; **measured**): its send call took 3.52 µs instead of 4.09 at the same performance-core clock (section 7), for a reason this note does not find.

**Locking the goroutine without a class that takes effect makes it much worse.** A send goroutine locked to one default-class thread spent 53–58% of that thread's time on efficiency cores at 12–24 spinners and ran Datagrams at 1,483 and 974 Mbit/s, −34% and −57% from its unloaded 2,254 (**measured**). Unlocked, the goroutine moves between Go's threads and usually finds one on a performance core; locked, its one thread takes its turns on the efficiency cores like every other default-class thread (section 1). The same happens when a class is requested but squashed: user-interactive requested by a process started under an app ran at 998 Mbit/s at 24 spinners, against 1,849 for that context's default class (**measured**). So a change must lock only when the class actually took effect, and unlock otherwise.

**The class costs other work little and energy nothing per byte.** At 24 spinners the spinners' combined progress was 6.49 billion iterations per second beside a user-initiated sender and 6.58 beside a default-class one (−1.4%), and 6.14 beside a user-interactive one (−6.7%) (**measured**). The sender's energy per GiB stayed the same (24.3 J/GiB user-initiated, 23.6 default; 32.0 and 33.2 unloaded), and its system CPU per GiB fell by 41% (3.77 against 6.36 CPU-s/GiB) because its sends ran on the faster cores (**measured**). It draws more power because it moves more bytes: 69 J against 46 J per 10 s run, for 43% more data (**measured**, **derived**).

**How far a class can rise is set by how the consumer is launched** (section 2, **source** and **measured**): a command-line tool started from Terminal, an IDE or any app gets neither class (both are squashed to the default priority), an off-screen app gets neither, a launchd daemon or agent gets user-initiated, and only a focal foreground app gets user-interactive. Nothing raises a class process-wide, and new threads never inherit one.

**The change would live in the fork, switched on by wiremux.** Only the thread itself can set its class, and Go creates every thread at the default class and has no API for it (section 2), so the fork's send goroutine has to lock itself to its thread and raise that thread, which a hook at the top of `sendQueue.Run` can do. wiremux would turn it on through a versioned capability, as it reaches every other fork feature. The libSystem calls need no cgo; the probe made them the way `golang.org/x/sys/unix` calls libc. Section 9 has the options.

| Datagrams at the GC pin, Mbit/s (medians, min–max) | 0 spinners | 12 spinners | 24 spinners |
| --- | --- | --- | --- |
| default class (today), daemon | 2,225 (2,217–2,277) | 1,812 (1,657–1,844) | 1,688 (1,649–1,690) |
| locked, default class | 2,254 (2,219–2,270) | 1,483 (1,325–1,563) | 974 (973–1,012) |
| user-initiated, daemon | 2,381 (2,376–2,449) | 2,464 (2,297–2,479) | 2,419 (2,347–2,484) |
| user-interactive, focal app | 2,403 (2,316–2,451) | 2,461 (2,129–2,502) | 2,474 (2,397–2,516) |
| **stream**, default class | 2,621 (2,610–2,622) | 1,668 (1,604–1,703) | 1,844 (1,744–1,987) |
| **stream**, user-initiated | 2,749 (2,710–2,766) | 2,537 (2,296–2,752) | 2,872 (2,777–2,898) |
| unconnected Datagrams (today's path), app child | 1,336 (1,333–1,395) | – | 1,242 (1,210–1,328) |
| share of the send thread's time on efficiency cores: locked / user-initiated | 0.000 / 0.000 | 0.533 / 0.000 | 0.579 / 0.000 |
| share of the sender process's CPU on efficiency cores: default / user-initiated | 0.001 / 0.001 | 0.33 / 0.19 | 0.38 / 0.11 |

**Profiled, the send call itself moves.** In untraced Time Profiler recordings of the whole sender (three per cell), 48% of the default-class send call's time was on efficiency cores at 12 spinners and 60% at 24, against none unloaded, and the sends ran on 12–15 of Go's threads spread over all 16 cores. The raised send thread's calls never ran on an efficiency core: one thread, the 12 performance cores only (**measured**; section 7).

## 1. How macOS decides which core type runs a thread

Both Macs run the Edge scheduler (`sysctl kern.sched` is `edge` on mbp128, **measured**). Its rules, from the closest published xnu (**source**):

- **A thread's scheduling bucket comes from its base priority**, which its QoS class sets: above 37 is the foreground bucket (user-interactive, 46 or 47), above 31 the user-initiated bucket (37), above 20 the default bucket (31) ([`sched_clutch.c` L344-L360](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L344-L360); priorities in [`sched.h` L159-L166](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched.h#L159-L166) and [`thread_policy.c` L84-L90](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/thread_policy.c#L84-L90)).
- **The preferred cluster is set per thread group and per bucket** by the closed-source performance controller (CLPC): in the Edge scheduler "the preferred pset is specified on a per-QoS basis within a thread group" ([`sched_clutch.c` L6250-L6261](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L6250-L6261), read per thread at [L1486-L1500](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L1486-L1500)).
- **A thread leaves its preferred performance cluster when that cluster is busier at its own bucket.** Each cluster keeps a load average per bucket that counts the runnable and running threads at that bucket and every higher one ([L1590-L1633](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L1590-L1633), [L4397-L4421](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L4397-L4421), [L4472](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L4472)). A thread migrates when the destination's load at its bucket is lower by at least the edge's weight ([L5754-L5812](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L5754-L5812)). The kernel's default edges let threads spill from performance to efficiency clusters with weight 64 and never back ([L6353-L6362](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L6353-L6362)); CLPC can change them. So a default-class thread is weighed against every default-class and higher thread on the performance cores, and a user-initiated thread only against user-initiated and higher ones.
- **Threads of one class also take turns on the performance cores.** "Stir-the-pot" swaps a thread that used up its quantum on a performance core with one on an efficiency core so that a multi-threaded workload's threads make roughly equal progress, but only with a thread of the same bucket ([L5555-L5560](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L5555-L5560), [L5130-L5136](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L5130-L5136)). This is what the locked default-class send thread meets: it is one busy default-class thread among 25, so it is rotated onto efficiency cores for its share of the time.
- **On one core, higher buckets usually win.** Buckets are chosen earliest-deadline-first with worst-case latencies of 0 ms (foreground), 37.5 ms (user-initiated) and 75 ms (default), plus a short warp for the higher ones ([L190-L221](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/sched_clutch.c#L190-L221)). So user-interactive is strictly preferred over default work, and user-initiated gets a large but bounded share.

Apple's guidance says the same in general terms: on Apple silicon a task's QoS class influences which cores the system runs it on, background work being more likely on the efficiency cores, and `pthread_set_qos_class_self_np` is the call for a POSIX thread ([Tuning your code's performance for Apple silicon](https://developer.apple.com/documentation/apple-silicon/tuning-your-code-s-performance-for-apple-silicon), "Assign Quality-of-Service (QoS) Classes to Work"). The Energy Efficiency Guide adds that the class also sets CPU scheduling priority, I/O throughput and timer latency, and that higher classes typically use more energy ([Prioritize Work at the Task Level](https://developer.apple.com/library/archive/documentation/Performance/Conceptual/power_efficiency_guidelines_osx/PrioritizeWorkAtTheTaskLevel.html)); xnu's table gives user-initiated and default the same timer-latency and I/O tiers ([`thread_policy.c` L92-L123](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/thread_policy.c#L92-L123)).

## 2. What a class can become, and who can set it

**Only the thread itself can set its class, and new threads never inherit it** (**source**, **measured**). `pthread_set_qos_class_np` refuses any thread but the caller ([`qos.c` L147-L169](https://github.com/apple-oss-distributions/libpthread/blob/libpthread-539.100.4/src/qos.c#L147-L169)). `pthread_create` with default attributes starts every thread at the default class whatever its creator's class: the default attribute carries `THREAD_QOS_LEGACY`, and `pthread_create` passes it to the kernel ([`pthread.c` L101-L111](https://github.com/apple-oss-distributions/libpthread/blob/libpthread-539.100.4/src/pthread.c#L101-L111), [L1547-L1550](https://github.com/apple-oss-distributions/libpthread/blob/libpthread-539.100.4/src/pthread.c#L1547-L1550)); the SDK's `sys/qos.h` says so too. On mbp128 a thread created by a user-interactive thread read the default class and base priority 31 in every launch context (`tools/qosfacts/inherit`, **measured**).

**Go sets no class anywhere** (**source**). Go 1.27.2 creates every thread with `pthread_attr_init`, `pthread_attr_getstacksize`, `pthread_attr_setdetachstate` and `pthread_create` ([`os_darwin.go` L220-L254](https://github.com/golang/go/blob/go1.27.2/src/runtime/os_darwin.go#L220-L254)), and nothing under `src/runtime`, `src/syscall` or `src/internal` mentions a QoS class. A thread locked with `runtime.LockOSThread` never creates threads itself: the runtime asks its template thread to, so that a locked thread's kernel state is not cloned ([`proc.go` L2891-L2913](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L2891-L2913)), and a raised class therefore stays on the one thread that set it. The `golang/go` tracker has no issue proposing a thread QoS API or a runtime setting for Darwin (searched 2026-10-16 for qos, QOS_CLASS, pthread_set_qos_class_self_np, efficiency core, performance cores, thread priority darwin). The nearest, [x/sys/unix: add darwin efficiency core scheduling integer constants](https://github.com/golang/go/issues/75529) (closed 2026-09), exposed `setpriority`'s `PRIO_DARWIN_*` constants, which can only lower a thread or process.

**Nothing raises a class process-wide** (**source**, **measured**). `posix_spawnattr_set_qos_class_np` accepts only utility and background (SDK `pthread/spawn.h`; it returned `EINVAL` for user-interactive here), `taskpolicy -c` clamps only to utility, background or maintenance (`man taskpolicy`), and a raised main thread's class never reaches the threads Go creates. So the class has to be set on the send goroutine's own thread, with the goroutine locked to it.

**How far a class can rise depends on how the process was launched** (**source**, **measured**). The kernel caps every thread's class at its task's QoS ceiling ([`thread_policy.c` L1686-L1691](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/thread_policy.c#L1686-L1691)), and the ceiling comes from the task's type and role ([`task_policy.c` L833-L889](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/task_policy.c#L833-L889)). A child inherits its parent's type ([L736](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/task_policy.c#L736)); the role is set for apps by the system. Base priority per requested class, measured with `tools/spawnctx` (which starts a program with a given spawn type and role, as launchd and the window server would) and `tools/qosfacts`:

| Launch context | How a consumer gets it | user-interactive | user-initiated | default | Main thread |
| --- | --- | ---: | ---: | ---: | --- |
| child of an app, no role | started from Claude here (**measured**); from Terminal or an IDE by the same inheritance (**source**) | **31** | **31** | 31 | requests user-interactive, gets 31 |
| off-screen app | app role "non-UI" | **31** | **31** | 31 | requests user-interactive, gets 31 |
| daemon or agent | launchd job with the standard process type; an ssh session (also measured on m4mini) | **37** | 37 | 31 | default |
| focal foreground app | the frontmost app | **47** | 37 | 31 | requests user-interactive, gets **47** |

So a raised class does nothing for a consumer that runs as a command-line tool under an app or as an off-screen app; a daemon reaches user-initiated and no further; only a foreground app gets user-interactive, and in one Go's main thread already runs at 47 with whatever goroutine it carries.

## 3. The default class under load

(**measured**, daemon context, medians of three runs, one run at 8 and 16 spinners; relative figures **derived** against the same build unloaded)

| Spinners | Datagrams Mbit/s | vs unloaded | Process CPU on efficiency cores | Kernel time on performance cores | Stream Mbit/s | vs unloaded | Process CPU on efficiency cores |
| ---: | --- | ---: | ---: | ---: | --- | ---: | ---: |
| 0 | 2,225 (2,217–2,277) | – | 0.001 | 1.00 | 2,621 (2,610–2,622) | – | 0.001 |
| 8 | 1,955 (one run) | −12% | 0.35 | 0.67 | 2,660 (one run) | +1% | 0.22 |
| 12 | 1,812 (1,657–1,844) | −19% | 0.33 | 0.60 | 1,668 (1,604–1,703) | −36% | 0.45 |
| 16 | 1,767 (one run) | −21% | 0.35 | 0.57 | 1,526 (one run) | −42% | 0.46 |
| 24 | 1,688 (1,649–1,690) | −24% | 0.38 | 0.53 | 1,844 (1,744–1,987) | −30% | 0.41 |

- **The loss starts below the performance-core count.** At 8 spinners the spinners and the sender's threads together already exceed the 12 performance cores some of the time: a third of the sender's CPU went to efficiency cores and Datagrams lost 12%.
- **It does not grow much past 12.** Once the performance cores are full of default-class threads, more spinners mostly share the efficiency cores and time-slice; the Datagram loss went from 19% at 12 spinners to 24% at 24, the stream's stayed at 30–42%.
- **The sender's kernel work moves most.** Its system CPU per GiB rose from 6.2 to 6.4 CPU-s/GiB while its user CPU per GiB fell (3.96 to 3.65), and the share of its system time on performance cores fell to 0.53–0.60. Half or more of the send call's own time moved to efficiency cores (section 7).
- **The receiver is not the cause.** m4mini carried no load; its user CPU per GiB moved from 4.56 to 4.92, and loss stayed at 0.03–0.16% in every cell.
- **Today's unconnected path loses less:** 1,336 → 1,242 Mbit/s for Datagrams (−7%) and 1,601 → 1,412 for the stream (−12%) at 24 spinners, with 27–29% of its CPU on efficiency cores. It was not profiled, so why is not measured.
- **The default GC row** fell less at 24 spinners (2,262 → 1,995, −12%) than the pin; with the class it held (2,377 → 2,360).

## 4. The goroutine locked, default class

(**measured**) Locking the fork's send goroutine to its thread changed nothing unloaded (2,254 against 2,225 Mbit/s, as [the send-cost ticket's `dgramL` rung](https://github.com/GridSwarm/wiremux/blob/2689dce8921ede4970c34a856bcd583ac56f290c/docs/research/issue-1841-native-send-cost.md#4-the-sends-environment) found), and under load it was the worst build:

| Spinners | Datagrams Mbit/s | vs unloaded | vs unlocked at this load | Send thread's time on efficiency cores |
| ---: | --- | ---: | ---: | ---: |
| 0 | 2,254 (2,219–2,270) | – | +1% | 0.000 |
| 8 | 1,370 (one run) | −39% | −30% | 0.38 |
| 12 | 1,483 (1,325–1,563) | −34% | −18% | 0.53 |
| 16 | 1,381 (one run) | −39% | −22% | 0.56 |
| 24 | 974 (973–1,012) | −57% | −42% | 0.58 |

The rig's per-thread readout (`-threads`, per-perf-level CPU from `PROC_PIDTHREADCOUNTS`) names the locked thread by its CPU time. More than half of its time on efficiency cores is what stir-the-pot's fair sharing among same-bucket threads predicts (section 1); unlocked, the goroutine is carried by whichever Go thread is running: the process's work spread over 15–18 threads of about 2 CPU-s each, and each of the three busiest spent 31–42% of its time on efficiency cores at 12 and 24 spinners. A squashed class is the same thing: user-interactive requested by a sender started under an app (ceiling: default) ran at 998 Mbit/s (973–1,009) at 24 spinners, against 1,849 (1,844–1,881) for that context's default class, and its CPU time was all at the default class (`qos_s`).

## 5. A raised class

(**measured**; daemon context for user-initiated, focal-app context for user-interactive)

| Spinners | user-initiated Datagrams | vs unloaded | vs default class | user-interactive Datagrams | user-initiated stream | vs default class | Send thread on efficiency cores (user-initiated / user-interactive) | Process CPU on efficiency cores |
| ---: | --- | ---: | ---: | --- | --- | ---: | --- | ---: |
| 0 | 2,381 (2,376–2,449) | – | +7% | 2,403 (2,316–2,451) | 2,749 (2,710–2,766) | +5% | 0.000 / 0.000 | 0.001 |
| 8 | 2,405 (one run) | +1% | +23% | – | 2,540 (one run) | −5% | 0.000 / – | 0.29 |
| 12 | 2,464 (2,297–2,479) | +3% | +36% | 2,461 (2,129–2,502) | 2,537 (2,296–2,752) | +52% | 0.000 / 0.000 | 0.19 |
| 16 | 2,239 (one run) | −6% | +27% | – | 2,708 (one run) | +77% | 0.000 / – | 0.13 |
| 24 | 2,419 (2,347–2,484) | +2% | +43% | 2,474 (2,397–2,516) | 2,872 (2,777–2,898) | +56% | 0.000 / 0.000 | 0.11 |

- **The send thread stayed on performance cores at every step** (its largest efficiency-core share in any run was 0.0018), and its CPU time was accounted at the requested class (`qos_s`: 6.0–9.6 CPU-s at user-initiated per run). The rest of the process still spilled: 11–29% of its CPU ran on efficiency cores, which the rate did not feel.
- **User-interactive bought nothing over user-initiated here.** In a focal app it ran at 2,461 and 2,474 Mbit/s against 2,464 and 2,419; the stream at 24 spinners 2,877 (2,742–2,946) against 2,872. The default class in a focal app ran at 1,586 (1,585–1,705) at 24 spinners, so the context alone did not help; its main thread, at 47 there, carried 0.2–0.5 CPU-s per run.
- **The kernel side got cheaper.** System CPU per GiB at 24 spinners fell from 6.36 to 3.77 (Datagrams) and from 5.57 to 3.16 (stream) CPU-s/GiB, and user CPU per GiB from 3.65 to 3.18.
- **Unloaded, the class was 5–7% faster** than the default class (Datagrams 2,381 against 2,225, stream 2,749 against 2,621), and the locked default build was not (2,254). The profiled send call was 14% cheaper on the raised thread (3.52 against 4.09 µs) while the performance cores ran at the same clock (3.59 against 3.62 GHz, **derived** as in section 7) and the process's instructions per cycle were 1.84 against 1.76; locking alone is not it, and kernel stacks would be needed to say what is.

## 6. What the class costs elsewhere

(**measured**; spinners' progress is the sum of their iterations per second over the sender's offer window)

| Spinners | Spinners' progress, billion iterations/s: default / locked / user-initiated / user-interactive | Spinners' user time on performance cores | Sender J per GiB: default / user-initiated / user-interactive | Sender energy per 10 s run: default / user-initiated |
| ---: | --- | --- | --- | --- |
| 0 | – | – | 33.2 / 32.0 / 31.3 | 87 / 89 J |
| 8 | 4.74 / 4.63 / 4.70 / – | 0.96–0.97 | 26.1 / 25.3 / – | 59 / 71 J |
| 12 | 6.38 / 6.55 / 6.33 / 6.19 | 0.86–0.90 | 22.8 / 23.1 / 23.0 | 46 / 65 J |
| 16 | 6.45 / 6.99 / 5.95 / – | 0.82 | 24.2 / 24.6 / – | 50 / 64 J |
| 24 | 6.58 / 7.48 / 6.49 / 6.14 | 0.78–0.81 | 23.6 / 24.3 / 25.0 | 46 / 69 J |

- **Other work loses little.** Beside a user-initiated sender the spinners did 0.8% less at 12 and 1.4% less at 24 spinners than beside a default-class one; beside a user-interactive one 3.0% and 6.7% less (**derived** from the medians). At 16 spinners (one run) user-initiated took 7.8%. A full raised thread takes about one core from the default-class work: 1/16 of the machine is 6% (**derived**), which brackets these.
- **Energy per byte is unchanged; power rises with the rate.** The sender's energy per GiB was within 3% of the default class at every step; per run it used 69 J instead of 46 at 24 spinners because it sent 43% more (**derived**: 69 / 46 = 1.50, 2,419 / 1,688 = 1.43). Spinners plus sender used 380 J against 360 J (+5.5%) per run (**derived** from 311 + 69 and 314 + 46). Energy is `rusage_info_v6`'s `ri_energy_nj` per process; the rest of the system (GARM VMs, the window server, idle power) is not in it.
- **The locked default build left more for the spinners** (7.48 at 24) only because it sent 42% less.
- **What the sources say about energy** is the general rule: higher classes run sooner and with more resources and so typically use more energy, and Apple suggests running at utility or lower most of the time when nothing is user-visible ([Prioritize Work at the Task Level](https://developer.apple.com/library/archive/documentation/Performance/Conceptual/power_efficiency_guidelines_osx/PrioritizeWorkAtTheTaskLevel.html)). For a transfer the measured cost is the rate itself: the same joules per GiB, delivered sooner.
- **Timer coalescing and I/O are unaffected** at user-initiated: xnu gives it the same latency tier (1) and I/O tier (0) as the default class; user-interactive's latency tier is 0 ([`thread_policy.c` L92-L123](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/osfmk/kern/thread_policy.c#L92-L123), **source**). App Nap applies to apps, not to a daemon's threads, and was not examined.

## 7. Where the send runs, from the profiler

(**measured**: untraced, system-wide Time Profiler recordings on mbp128 that cover the whole sender, three per cell in rotation, Datagrams at the pin; the send call is the `__sendmsg` leaf, and calls are the probe's count of connected sends)

| Build | Spinners | Sends/s while profiled | Send leaf per call, µs | Share of the leaf's time on efficiency cores | Threads the sends ran on | Cores they ran on | Core changes per second |
| --- | ---: | --- | --- | --- | --- | --- | --- |
| default class | 0 | 213k (209–215k) | 4.09 (4.06–4.20) | 0.000 | 12 (12–13) | 13 (12–13) | 454 (397–456) |
| default class | 12 | 173k (173–176k) | 4.25 (4.09–4.59) | **0.478** (0.430–0.494) | 13 (13–14) | 16 | 490 (479–537) |
| default class | 24 | 165k (163–167k) | 4.89 (4.77–5.05) | **0.595** (0.589–0.627) | 15 (14–16) | 16 | 375 (362–385) |
| locked, default class | 24 | 100k (98–102k) | 4.63 (4.51–4.63) | 0.522 (0.491–0.541) | 1 | 16 (15–16) | 257 (241–277) |
| user-initiated | 0 | 242k (237–244k) | 3.52 (3.52–3.63) | 0.000 | 2 (1–2) | 13 (12–13) | 431 (414–520) |
| user-initiated | 24 | 242k (238–249k) | 2.42 (2.40–2.44) | 0.000 | 1 | 12 | 487 (466–489) |
| user-interactive, focal app | 24 | 255k (238–260k) | 2.55 (2.41–2.56) | 0.000 | 1 | 12 (12–13) | 508 (493–545) |

- **At the default class half or more of the send call's time is on efficiency cores under load**, and the average call grew from 4.09 to 4.89 µs. Time Profiler samples time, not calls, so the cost of one call on each core type cannot be separated here; [the send-cost ticket's forced efficiency-core rung](https://github.com/GridSwarm/wiremux/blob/2689dce8921ede4970c34a856bcd583ac56f290c/docs/research/issue-1841-native-send-cost.md#4-the-sends-environment) (15.2 against 4.6 µs per call) bounds it. Because a call on an efficiency core takes longer, the share of *calls* made there is smaller than the share of time.
- **The raised thread never ran a send on an efficiency core**, and it stayed on one thread, as the lock intends, moving among the 12 performance cores about 490 times a second, as busy macOS threads do.
- **A raised send call was cheaper under load than unloaded** (2.42 against 3.52 µs). Under load the performance cores ran faster and did more per cycle: the sender's performance-core cycles per performance-core CPU-second were 3.89 GHz at 12 and 24 spinners against 3.59 unloaded, and its instructions per cycle 2.2–2.4 against 1.8–1.9 (**derived** from `rusage_info_v6` cycles and times; 3.89 / 3.59 = 1.08 and 2.3 / 1.84 = 1.25; 1.08 × 1.25 ≈ 1.35, close to 3.52 / 2.42 = 1.45). Efficiency cores ran at 2.59 GHz throughout. The default-class sender got the same faster performance cores under load (3.89 GHz) but spent half its send time off them.
- **Profiling slowed the sender 5–10%** (213k against 236k sends/s unloaded for the default class, **derived** from the campaign's 2,225 Mbit/s), as in the send-cost ticket's recordings; the profiled figures are compared with each other, not used as rates.

## 8. Natural load

(**measured**; no spinners, each run started only when mbp128 itself had at least 7 busy cores in a 1 s sample: GARM runner VMs, `tart`, `mediaanalysisd`)

| Run | Busy cores before | mbp128 load1 | Datagrams Mbit/s | Process CPU on efficiency cores | Send thread on efficiency cores |
| --- | ---: | ---: | --- | ---: | ---: |
| default class | 7.6 | 28.7 | 2,073 | 0.008 | – |
| user-initiated | 11.8 | 50.3 | 2,319 | 0.083 | 0.0000 |
| user-initiated | 9.4 | 48.0 | 2,324 | 0.062 | 0.0003 |

The host's own load came in bursts: three runs met the condition, and four other attempts waited 5–10 minutes each and gave up. In the one default-class run the sender stayed on performance cores (0.8% of its CPU on efficiency cores) and still ran 7% below its unloaded rate (**derived**: 2,073 / 2,225); the two user-initiated runs ran 2.5% below theirs. This load came from other processes in their own coalitions, and so other thread groups, unlike the spinners (see [Limits](#limits)); it displaced the default-class sender less than eight spinners did.

## 9. Where such a change would live

The class has to be set by the send goroutine on its own thread after locking it (section 2), and only when it takes effect (section 4). The fork starts that goroutine itself: `go c.emission.run()` at connection start ([`connection.go` L620-L624](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L620-L624)), which runs `sendQueue.Run` ([`packet_emission.go` L94](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/packet_emission.go#L94), [`send_queue.go` L176](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/send_queue.go#L176)), and again for each new path ([`connection.go` L977-L981](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L977-L981)).

| Where | Mechanism | Fits? |
| --- | --- | --- |
| **The fork, behind a capability wiremux selects** | `sendQueue.Run` calls a hook on entry and its undo on exit. On Darwin the hook locks the goroutine to its thread, raises the class, reads back the thread's base priority (`proc_pidinfo` `PROC_PIDTHREADID64INFO`, public in `libproc.h`) and, if the ceiling squashed it, restores the class and unlocks; the undo restores the class before unlocking, so Go's thread pool never gets a raised thread back. wiremux turns it on with a `Configure…V1` method found by interface assertion, the way it reaches every other fork feature ([`capability.go` L22-L29](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/capability.go#L22-L29)), so stock quic-go still compiles. The libSystem calls need no cgo: the probe makes them with a `//go:cgo_import_dynamic` symbol, an arm64 trampoline and `syscall.syscall`, the way `golang.org/x/sys/unix` calls libc on Darwin, which the compiler allows outside cgo ([`noder.go` L315-L327](https://github.com/golang/go/blob/go1.27.2/src/cmd/compile/internal/noder/noder.go#L315-L327)) and the runtime keeps linkable for x/sys ([`syscall_darwin.go` L380-L386](https://github.com/golang/go/blob/go1.27.2/src/syscall/syscall_darwin.go#L380-L386)). An amd64 trampoline is the same few lines. | yes: the only code that owns the goroutine. A fork slice plus a wiremux switch |
| wiremux alone | wiremux runs on the send goroutine only inside the batch-send callback. Locking from there would lock the fork's goroutine behind the fork's back, for whichever candidate's goroutine called first, and the goroutine would stay locked until it exits | no: fragile, and it depends on how the fork calls its callback |
| the consumer, process-wide | nothing raises a class process-wide (section 2) | no |
| the Go runtime | an API to set a thread's class, or a per-thread policy | out of reach and unneeded: no proposal exists, and only the fork's one goroutine needs it |

The policy choice belongs to wiremux, or to the consumer through wiremux: user-initiated is the class Apple describes for work the user is waiting on, which a transfer the user started is, and it is also the most a daemon can have. Raising every native connection by default would also raise idle Wires' send threads, which only matters while they send.

## Method

**Rig additions** (`codex/native-gap-rig`, this ticket's commit; documented in PROTOCOL.md): `-threads` (any arm, macOS: the process's thread count, CPU seconds per thread base priority, the share of thread CPU on efficiency cores, and the busiest threads' CPU on each core type, energy and highest base priority, from `PROC_PIDTHREADID64INFO` and the private `PROC_PIDTHREADCOUNTS`, read at the start and end of the run and every 200 ms for priorities); `-qos CLASS` for a locked raw `udp` sender; and `proc` gains the process's energy (`energy_j`, `p_energy_j`) and its CPU seconds per effective QoS class (`qos_s`), all from `rusage_info_v6`.

**Builds** (`bin/<name>/` with recipe and applied diff in the evidence directory; never pushed): `conn` = the connected-socket probe `dc7cb39a` with `cmd/nativerig` replaced by this ticket's rig, stock fork; `connqos` = the same against a fork copy (v0.62.1-fast.7 plus `send_qos_probe1853*.go/.s` and one line at the top of `sendQueue.Run`), with `WIREMUX_PROBE_SENDQOS=lock|user-initiated|user-interactive` read once per process; the probe prints the class `qos_class_self` reports before and after (`before=default after=user-initiated errno=0` or `after=user-interactive` in every raised run; in one focal-app run the goroutine started on the main thread, already user-interactive there) and restores the class before unlocking. go1.27.2.

**Load.** `tools/spin/spin1853.c`: one thread, a xorshift loop, no QoS call, at default priority; it checks the clock every 2^20 iterations, exits after its lifetime (the pair plus 12 s) with `alarm` as a hard stop, and writes its iterations per second, its share of user time on performance cores and its energy. Each run started N spinners 2 s before the receiver and ended them right after the pair, with a `trap` that kills them on any exit and a `ps` check that none survived (none ever did). Loaded wall-clock was 27 minutes in all (**derived**: the sum over every loaded run of spinner start to sender exit).

**Launch contexts.** `tools/spawnctx` starts the sender with `posix_spawn` and the private `spawn_private.h` attributes `posix_spawnattr_setprocesstype_np` (`DAEMON_STANDARD` or `APP_DEFAULT`) and `posix_spawnattr_set_darwin_role_np` (`UI_FOCAL`), which need no entitlement for these values ([`kern_exec.c` L3151-L3163](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/kern_exec.c#L3151-L3163)). The receiver on m4mini always ran under sshd, a daemon context, with no class change.

**Campaign** (`M1/`, `scripts/seq.sh`): 41 cells, build × arm × load step; every repetition visits the load steps in a rotated order and, within a step, the cells in a rotated order, so the builds interleave within each step. Three repetitions at 0, 12 and 24 spinners and one at 8 and 16 (103 runs, 10 s each), 2026-10-16 05:35–10:16 UTC. No run was flagged by PROTOCOL.md's rules (rate within 0.8–1.2× of its cell's median; unloaded runs started with both load1 at most 8; loaded runs with at most 6 busy cores on mbp128 before the spinners started). The fine interleaving stands in for PROTOCOL.md's A, B, A, B campaigns; with one binary for every probe mode the modes share every byte of code.

**Natural load** (`N1/`): the same pair with no spinners, started only when mbp128 had at least 7 busy cores by itself.

**Profiled pairs** (`X1/`, `scripts/seq.sh` with `XPROF=1`): 21 pairs, seven cells × three rotated recordings, 10 s sends, 2026-10-16 10:16–11:19 UTC, never inside the campaign; each records one system-wide Time Profiler session on mbp128 that starts before the sender and outlives it ([the send-cost ticket's procedure](https://github.com/GridSwarm/wiremux/blob/2689dce8921ede4970c34a856bcd583ac56f290c/docs/research/issue-1841-native-send-cost.md#method)). `xsend.py` (that ticket's script, adapted to take the call count from the probe's connected-send counter) sums the sender's send leaf, splits it by core type and counts threads and cores; it ran at background QoS after the last pair.

**Sharing the pair.** [Does Darwin recvmsg_x save receiver CPU when the queue is full?](https://github.com/GridSwarm/wiremux/issues/1815) ran three campaigns and profiled pairs on `tb` through most of the window, and [What makes up the 1.1–1.5 µs the native macOS send costs beyond its closest raw reproduction?](https://github.com/GridSwarm/wiremux/issues/1851) ran pairs from 07:58. Every run here claimed the pair (a placeholder process named like the rig on m4mini) at the first moment no other session's sender, receiver, profiler, claim or hold was running, verified the claim 1 s and 6 s later, and only then checked the load; the claim was held from before the spinners started until they were confirmed gone. After each loaded run, while another session was present, the sequence waited for mbp128's load1 to fall back to 8 before yielding 35 s, because the spinners otherwise kept the sibling gates' load condition false. A 2 s logger recorded every other session's running work; no run window overlapped it. The main campaign was paused twice so as not to stretch the other sessions' campaigns (interleaved, both ran at about half speed). Incidents are in the evidence README.

## Limits

- **The spinners share the sender's thread group.** Every process started from the same app is in one coalition and so one thread group (`tools/coal`: the shell, the spinners, the sender and the other sessions' processes share coalition 116261; the GARM VMs have their own), and the Edge scheduler's cluster preference and Clutch's bucket groups are per thread group. A consumer competing with other apps' work is in a different situation: the one natural-load default-class run, against other thread groups, stayed on performance cores.
- **Natural load is three runs.**
- **The 8- and 16-spinner cells are one run each.**
- **One host, one load shape.** A pure integer spinner on mbp128 (M4 Max, 12 + 4 cores); other chips, memory-bound load, thermal throttling and battery power were not tried.
- **Contexts are emulated.** The sender got its type and role from spawn attributes, not from launchd or the window server; a real foreground app may also get other treatment (the focal flag on its thread group, App Nap off). The default class ran 10% faster at 24 spinners in the app-child context than as a daemon (1,849 against 1,688 Mbit/s) and 6% slower in the focal context (1,586), unexplained, which is why every class comparison is made within one context.
- **No root:** no kernel stacks, no `taskinfo`, no `powermetrics`; system-wide energy is not measured.
- **The xnu source is 12377.121.6, not the hosts' 13432.1.9**, and CLPC, which sets the per-thread-group preferences and clocks, is closed source.
- **The unloaded 5–7% from the class (a 14% cheaper send call) is unexplained.**
- **Only the sender was loaded.** A loaded receiver, and the receive goroutine's placement, were not measured.

## Implications for the map

- **A macOS lever for hosts that are busy, worth packaging for daemons and foreground apps.** On a busy Mac the class recovers 36–56% over the default class (connected shape, 12–24 spinners), and 5–7% unloaded. It does nothing for a command-line consumer started under an app, and there a lock without the class costs up to 42%; the hook must check that the class took effect.
- **Independent of the connected-socket slice.** It applies to the unconnected path too (not measured with the class), and it stacks with a cheaper send: the send thread is the wall on both shapes ([What would a connected socket per peer do to the native ceiling and to per-datagram admission?](https://github.com/GridSwarm/wiremux/issues/1842#issuecomment-6201882656)).
- **For [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801):** a macOS target measured on an idle Mac overstates a busy one by 19–24% for Datagrams and 30–36% for the stream at the default class (connected shape, 12 and 24 spinners; the stream lost 42% in the one run at 16); with user-initiated on the send thread the busy and idle rates agree within 6%.
- **For [How much would batched connected sends add to the native macOS sender?](https://github.com/GridSwarm/wiremux/issues/1856):** on a busy host 48–60% of a default-class send call's time ran on efficiency cores (section 7), so a cheaper send gains less there unless the send thread is raised; its gate should run on an idle host, or with the class.
- **For [What makes up the 1.1–1.5 µs the native macOS send costs beyond its closest raw reproduction?](https://github.com/GridSwarm/wiremux/issues/1851):** on an idle host the connected send call cost 4.09 µs at the default class and 3.52 µs on a user-initiated thread, at the same clock and with no efficiency-core time (section 7). So about 0.6 µs of a default-class send depends on its thread's class, which that ticket's raw reproductions (default class) and the native sender share; comparing them at both classes would say whether the remainder moves.
- **Linux is untouched:** it has no QoS classes, and the shape cell's sender is pinned.

## Open questions

These are candidate tickets.

1. **Should the fork's send goroutine raise its thread to user-initiated on macOS, and who decides?** A fork hook plus a wiremux capability (section 9), on by default for native Wires or per consumer, with the squash check; its gate would be a loaded A/B on `tb` (for example 12 and 24 spinners) plus an unloaded no-regression run.
2. **Does other apps' load, in other thread groups, displace the default-class sender as spinners in its own thread group do?** One natural-load run says less; a spinner started outside the coalition (launchd agent, or `ssh` to the host) would say how much less.
3. **Why is a user-initiated send call 14% cheaper on an idle host?** The clocks were the same; kernel stacks (root on mbp128) of both classes' send calls would show where the 0.6 µs goes.
4. **Do the receive goroutine and the connection run loop need the class too, on a loaded receiver?** Only the sender was loaded here; with the send thread raised, 11–29% of the sender's other CPU still ran on efficiency cores without costing rate.

## Evidence

`native-gap-evidence/1853-ecore-qos/` (README.txt indexes it): `M1/` (the campaign, every run with its `cmd`, gate, spinner lines, both result lines and counters), `N1/` (natural load), `X1/` (profiled pairs, `xsend.jsonl`), `smoke/`, `bin/` (binaries, recipes, applied diffs), `fork-qos/` (the fork copy, a git repository with the probe commit), `tools/` (spinner, `spawnctx`, `qosfacts`, `coal`, claim), `sources/` (the xnu and libpthread files cited), `scripts/` (`run.sh`, `seq.sh`, `claimgate.sh`, `busy.sh`, `claim.sh`, `overlap.sh`, `ovcheck.py`, `sum.py`, `agg.py`, `tables2.py`, `xsend.py`), `coordination.log`, `overlap.log`, `claim.log`.
