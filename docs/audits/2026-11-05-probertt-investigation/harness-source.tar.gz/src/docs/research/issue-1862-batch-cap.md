# Issue #1862: what a fork send batch cap above 8 adds once the macOS receiver is faster

Research for [How much would a fork send batch cap above 8 add once the macOS receiver is faster?](https://github.com/GridSwarm/wiremux/issues/1862) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). The batched-send research ([How much would batched connected sends add to the native macOS sender?](https://github.com/GridSwarm/wiremux/issues/1856)) found that raising the fork's batch cap from 8 to 32 doubled the send groups' fill but added only 1–4%, because the receiver's receive goroutine was the wall. The receiver research ([What makes up the connected macOS receive goroutine's cost per datagram, and what would lower it?](https://github.com/GridSwarm/wiremux/issues/1861)) then found a receiver lever, eight-slot `recvmsg_x`, and with it the sender binds again. This note measures caps 8, 16 and 32 on that shape, finds where the gain comes from, checks the Linux `netns` cell for harm, and says whether a fork slice is worth deciding. Nothing here implements a change.

Sources are wiremux at `origin/main` [870295a4](https://github.com/GridSwarm/wiremux/tree/870295a497ef862fa51f523c5f64d0eaf06dbed8), the receiver research's probe as its input comment names it (local commits `7163036d` and `f417fe0f` on the batched-send probe `84f78eee`, never pushed) with its fork copy (`qgf-1861` at `43c244e`, which keeps the batched-send research's send-queue knobs), the quic-go-fast fork at the version the rig selects (`v0.62.1-fast.7`, [55ea687d](https://github.com/the-sarge/quic-go-fast/tree/55ea687d68c9c6f33785a1875374ec6a0d7570e8)), Go 1.27.2, the rig `cmd/nativerig` from `codex/native-gap-rig`, and measurements taken for this note on 2026-10-17 (UTC). No new probe code was written: the build is byte-identical to the receiver research's headline binary. Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cells.**

- **`tb`:** mbp128 (MacBook Pro M4 Max) sends from `bridge0` over Thunderbolt to m4mini (Mac mini M4 Pro), both macOS 27 arm64, MTU 1500. Every native arm is on the shape the decided levers land on: a connected socket (`-connectpeer`), one `sendmsg_x` per send group (`-nsendx`), the bundle's 32-entry send queue (`-sendq 32`) and 16 packets per acknowledgment (`-ackn 16`). The stand-in for the receiver lever is the receiver research's eight-slot `recvmsg_x` (`-nrecvx 8`). The cap is `-sendbatch 8 | 16 | 32` (the cap can't exceed the queue's depth).
- **`netns`:** two network namespaces on minimax (Linux 7.0), joined by a `veth` pair, sender pinned to CPUs 4–7 and receiver to 12–15, GSO on and GRO off. Unconnected sockets and the stock Linux sender, with the bundle's 32-entry queue and 16 per acknowledgment. This is the no-harm row, because the cap applies to every fork connection.

**Basis.** Rates, CPU per GiB, fill, RTT and loss come from headline campaigns (PROTOCOL.md: `REPS=5 SECS=10`, a warm-up rotation, arm order rotating; `LOADGATE=1` on `tb`), with every cap interleaved on one binary. Two campaigns per cell are reported separately and pooled. Each gain is given two ways: as the ratio of medians, and as the median of paired per-rotation ratios (cap N's run over cap 8's run in the same rotation, which cancels drift between rotations). The sending Mac's speed moved the sender-bound arms 7–16% between the two `tb` campaigns. Per-packet send cost comes from untraced two-Mac Instruments Time Profiler recordings (`X1`) and from Go execution traces on both peers (`G1`). Datagram comparisons run at the GC pin (`-ballast 64 -gc-role both`), with the default-GC row beside them.

## Answer

- **With the faster receiver, a cap of 32 lifts native Datagrams about 12% and the stream about 21% on `tb`.** Pooled over two campaigns (cap 8 → 32, medians of ten runs):
  - Datagrams at the pin: 3,970 → 4,493 Mbit/s (+13.2%; paired +11.7%). Per campaign, +12.0% and +11.5%.
  - Datagrams at the default GC: 3,519 → 3,940 (+12.0%; per campaign +13.2% and +8.5%).
  - The stream: 4,438 → 5,387 (+21.4%; paired +19.6%; per campaign +20.2% and +15.3%).

  Sender CPU per GiB falls 19.9% on the stream and 3.1% on Datagrams at the pin, and rises 0.7% at the default GC. Receiver CPU per GiB falls 2–8%. One Wire then carries 437–505k packets a second, depending on the sending Mac's state (**measured**, `K1`, `K2`; [section 2](#2-rate-cpu-and-loss-on-tb)).
- **A cap of 16 gives a third to three fifths of that.** Datagrams at the pin +4.6% (paired +1.6%), the default GC +7.0% and the stream +8.3%. A fixed cost per group predicts about two thirds of cap 32's gain; the shortfall is unexplained, and the choice doesn't depend on it, because 32 is the most the bundle's 32-entry queue allows and it is the best.
- **With today's receiver, the cap adds +1.3%.** Today's receiver binds first, as the batched-send research found (+1.4% and +1.3% in the two campaigns). So the slice is no harm without the receiver lever and a gain with it.
- **The gain is the send goroutine's work per group, not the kernel's per-call cost.** The list path's own fixed part is small. In the profile, one `sendmsg_x` costs 0.26 + 2.05 µs per datagram for Datagrams, so its per-call part is about 0.26 µs. Raising the cap barely moves the kernel's time per Datagram (2.09 → 2.05 µs). What the cap removes:
  - the Go work each group carries (about 1.0 µs per group, **derived**);
  - Go's system-call entry per call: the system call's time per packet falls 2.19 → 2.10 µs in the Go traces;
  - two thirds of the run loop's wakeups by the send goroutine: 24–25k → 10–11k a second.

  The send goroutine's busy time per packet falls 9% for Datagrams (2.52 → 2.28 µs) and 21% for the stream (2.48 → 1.97 µs). The stream's kernel time per packet also falls 8%, which the profile can't attribute without kernel stacks (**measured**, `X1`, `G1`; [sections 4](#4-what-each-send-costs-at-each-cap) and [5](#5-the-hand-off)).
- **The sender is still the wall at cap 32.** For Datagrams, the send goroutine is 99.5% busy in the Go traces (0.97 cores in the profile), and about 90% of its time is the list path's per-datagram kernel cost, which no larger batch can lower. For the stream it is 90–92% busy, and it waits on the run loop the rest. Next come the sender's transmit thread (76–79%, near 560–595k packets a second) and the receiver's input thread (69–71%, near 635k) (**derived**; [section 6](#6-the-next-wall)).
- **No harm on Linux.** In the `netns` cell, cap 32 lifts the stock Datagram sender +4.3% at the pin (paired +2.2%) and +2.6% at the default GC, and the stream +1.2% (paired +0.4%). CPU per GiB on both peers stays within 1%, and the minimum RTT is unchanged (**measured**, `N1`, `N2`; [section 7](#7-the-netns-no-harm-rows)).
- **The costs are a little queueing and some Datagram loss in the queue the bundle replaces.** Under saturation the mean RTT rises 85 µs on `tb` (200 → 285 µs) and 27 µs in `netns` (137 → 164); the minimum RTT doesn't move. Datagram loss rises by up to 0.1 point on both cells (on `tb` at the pin, 0.15% → 0.24%), mostly packets QUIC accepted whose Datagram the fork's 128-entry received-Datagram queue then dropped. The bundle raises that queue to 1,024 entries. Every one of the 591 million batched datagrams was taken by the kernel, with no errors.
- **A further fork slice is worth deciding** ([section 8](#8-what-a-fork-slice-would-carry)). The change is one constant: the batch cap follows the send queue's depth again (`maxSendBatch = sendQueueCapacity`, the fork's own definition, which the 32-entry-queue decision split apart to keep the cap at 8). It applies to every fork connection, and the fork's own Darwin batch scratch follows it. Its gain exists only once receives are batched, which [Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863#issuecomment-6235627888) adopted while this note was being measured, as the bundle's seventh slice. So the cap would be the eighth.

## 1. What the cap does

The fork's send queue hands queued packets to the socket one group at a time ([`send_queue.go` L239–L276](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/send_queue.go#L239-L276), **source**):

- **Grouping.** The send goroutine takes the first queued packet, then drains whatever else is already queued with the same ECN mark and no GSO segmentation, up to `maxSendBatch` packets. It hands that group to the batch callback, which on wiremux's connected macOS socket is one `sendmsg_x` with this note's probe.
- **Room signal.** The send goroutine signals the run loop that the queue has room only after the whole group has gone ([L267–L276](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/send_queue.go#L267-L276)). The run loop also wakes for each arriving acknowledgment, and then sees room as soon as the group has been drained from the queue ([`connection.go` L702](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/connection.go#L702), [L762](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/connection.go#L762)).
- **The constants.** In the fork, `maxSendBatch` is defined as `sendQueueCapacity` (both 8, [L109–L112](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/send_queue.go#L109-L112)). [Should the fork raise its packet send queue from 8 to 32 entries?](https://github.com/GridSwarm/wiremux/issues/1850#issuecomment-6207580215) raised the queue to 32 and kept the cap at 8 "as its own constant", so in the bundle the two differ for the first time.
- **The fork's own Darwin batch path** (the unconnected `sendmsg_x` that wiremux's external packet I/O never uses) sizes its scratch from `maxSendBatch` and declines a larger group ([`send_conn_sendmsg_x_darwin.go` L41–L46, L214](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/send_conn_sendmsg_x_darwin.go#L214)), so it follows the constant.
- **On Linux,** wiremux's batch callback sends each datagram of a group with its own call. The cap there only sets how many non-GSO packets go per room signal; GSO packets are sent one queue entry at a time whatever the cap.

**Group fill follows the cap on `tb`** (**measured**, pooled medians). With the faster receiver, the queue is full whenever the send goroutine comes back for more:

| Workload | Fill at cap 8 / 16 / 32 | Groups at the cap, cap 32 | `ru_msgsnd` per datagram, cap 32 |
| --- | ---: | ---: | ---: |
| Datagrams at the pin | 8.00 / 15.95 / 30.89 | 92.6% | 0.032 |
| Datagrams at the default GC | 7.99 / 15.47 / 24.11 | 51.9% | 0.041 |
| Stream | 8.00 / 15.97 / 31.32 | 93.9% | 0.032 |
| Datagrams at the pin, today's receiver | 7.08 / – / 16.56 | 4.5% | 0.060 |

At the default GC the sender's other goroutines (garbage collection at Go's 4 MiB heap floor) leave the queue less full, so half the groups fall short of 32. With today's receiver the send goroutine waits on the run loop, and groups average 16.6, as in the batched-send research.

## 2. Rate, CPU and loss on `tb`

Medians of five runs per campaign and ten pooled (**measured**, `K1`, `K2`):

| Workload, cap | `K1` Mbit/s | `K2` Mbit/s | Pooled Mbit/s | Packets/s | CPU/GiB sender | CPU/GiB receiver | Mean RTT µs | Min RTT µs | Datagram loss (after QUIC) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Datagrams at the pin, 8 | 3,715 | 4,317 | 3,970 | 416,680 | 6.45 | 4.98 | 200 | 81 | 0.152% (0.137%) |
| Datagrams at the pin, 16 | 3,821 | 4,247 | 4,151 | 435,690 | 6.60 | 4.90 | 222 | 78 | 0.168% (0.149%) |
| Datagrams at the pin, 32 | 4,162 | 4,814 | 4,493 | 471,538 | 6.25 | 4.68 | 285 | 73 | 0.237% (0.194%) |
| Default GC, 8 | 3,427 | 3,695 | 3,519 | 369,287 | 8.73 | 6.31 | 226 | 72 | 0.209% (0.203%) |
| Default GC, 16 | 3,680 | 3,910 | 3,766 | 395,292 | 8.85 | 6.26 | 239 | 67 | 0.303% (0.285%) |
| Default GC, 32 | 3,879 | 4,010 | 3,940 | 413,495 | 8.79 | 6.17 | 241 | 66 | 0.305% (0.296%) |
| Stream, 8 | 4,178 | 4,771 | 4,438 | 406,421 | 4.20 | 4.26 | 198 | 74 | – |
| Stream, 16 | 4,474 | 5,148 | 4,808 | 440,320 | 3.81 | 4.13 | 223 | 76 | – |
| Stream, 32 | 5,021 | 5,503 | 5,387 | 493,201 | 3.37 | 3.91 | 285 | 76 | – |
| Today's receiver, pin, 8 | 2,963 | 2,970 | 2,967 | 311,431 | 5.80 | 8.10 | 2,378 | 307 | 0.046% (0.002%) |
| Today's receiver, pin, 32 | 3,003 | 3,008 | 3,007 | 315,578 | 5.72 | 7.98 | 2,348 | 296 | 0.041% (0.000%) |

Gains against cap 8 (ratio of medians; paired per-rotation median with its range):

| Workload | Cap 16, `K1` / `K2` / pooled | Cap 32, `K1` / `K2` / pooled | Cap 32 sender CPU/GiB, pooled | Cap 32 receiver CPU/GiB, pooled |
| --- | --- | --- | ---: | ---: |
| Datagrams at the pin | +2.8% / −1.6% / +4.6% (paired +1.6%, −2.5..+13.0%) | +12.0% / +11.5% / +13.2% (paired +11.7%, +4.7..+17.7%) | −3.1% | −6.0% |
| Datagrams at the default GC | +7.4% / +5.8% / +7.0% (paired +6.9%) | +13.2% / +8.5% / +12.0% (paired +11.2%, +2.8..+17.9%) | +0.7% | −2.3% |
| Stream | +7.1% / +7.9% / +8.3% (paired +7.3%) | +20.2% / +15.3% / +21.4% (paired +19.6%, +7.5..+26.6%) | −19.9% | −8.3% |
| Today's receiver, pin | – | +1.4% / +1.3% / +1.3% (paired +1.3%, −0.9..+2.7%) | −1.3% | −1.4% |

- **The gain holds across a sender that changed speed.** The sending Mac ran the sender-bound arms 7–16% faster in `K2` than in `K1` (Datagrams at the pin, cap 8: 3,715 → 4,317 Mbit/s), while today's receiver-bound arms moved under 1%. That is the sending Mac's state, as the receiver research also saw. Cap 32's gain was +12.0% and +11.5% for Datagrams at the pin and +20.2% and +15.3% for the stream across that change. Every paired rotation gained at cap 32 on all three workloads.
- **Sender CPU per GiB falls where the send goroutine is a large share of the sender.** On the stream it falls about 20%, user and system alike. On Datagrams the sender's other goroutines carry each Datagram's copies and hand-offs, which the cap doesn't touch, so the saving is 3% at the pin. At the default GC their garbage collection at a higher rate cancels it (+0.7%; +3.4% in `K2`). Receiver CPU per GiB falls 2–8%, because the receiver reads fuller batches: 5.3 → 6.2 datagrams per `recvmsg_x` call at the pin.
- **RTT under load rises with the burst, not the floor.** The mean RTT sample rises 85 µs on Datagrams and 87 µs on the stream, and bytes in flight at each acknowledgment rise from 131 to 198 KB at the pin. The minimum RTT stays within 8 µs. The receiver's socket queue rises from about 6 to 12 datagrams on average and is still empty 16% of the time (24% at cap 8), so the receiver is busier but not full.
- **Loss.** Datagram loss rises about 0.09 points, almost all of it after QUIC accepted the packet: 0.137% → 0.194% at the pin and 0.203% → 0.296% at the default GC. In this fork only the 128-entry received-Datagram queue drops such packets, and the bundle raises it to 1,024 entries ([How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507)). Losses QUIC declared are 6–21 per 100,000 packets at every cap. The unprocessed-packet queue dropped tens to hundreds of packets a run (about 0.01%) at every cap, which the bundle's 1,024-packet queue covers. At the default GC the receiver's socket buffer dropped 244–364 datagrams a run at caps 16 and 32 against 53 at cap 8; the default-GC receiver is the slower one.
- **No partial sends and no errors.** Over `K1`, `K2`, `X1` and `G1`:
  - The senders made 44.8 million `sendmsg_x` calls carrying 591 million datagrams, and every call took every datagram it was offered. There were no short counts, no `ENOBUFS`, `EMSGSIZE`, `EINTR` or `EAGAIN` returns, and no other errors.
  - The eight-slot receivers made 88.4 million `recvmsg_x` calls carrying 516 million datagrams, with no truncated slot or control area.
  - Two receive calls absorbed an ICMP-driven error, one each in two hand-run stream pairs and none in a campaign.

## 3. A cap of 16

A fixed cost per group would make cap 16 save 1/8 − 1/16 = 0.0625 of that cost per packet against cap 32's 1/8 − 1/32 ≈ 0.094, so cap 16 should give about two thirds of cap 32's gain (**derived**). In the profiled pairs it does: 431k packets a second against 410k at cap 8 and 439k at cap 32, with the send goroutine's Go side per packet halfway between. In the campaigns it gives less:

- 35% of cap 32's gain for Datagrams at the pin (ratio of medians; 14% paired);
- 58% for Datagrams at the default GC;
- 39% for the stream.

Cap 16's paired range for Datagrams at the pin is also the widest (−2.5% to +13.0%). Nothing in the counters separates it: fill is 15.9–16.0, nearly every group reaches the cap, and the queue, RTT and loss sit between caps 8 and 32. It is left unexplained. It doesn't bear on the choice, because the bundle's queue bounds the cap at 32, cap 32 beats cap 16 in every campaign and workload, and the fork's own original definition is cap equals depth.

## 4. What each send costs at each cap

**Measured**, `X1`: untraced, system-wide Time Profiler recordings on both Macs, two 8 s pairs per rung in rotation (the recordings cost a pair about 9% of its rate, so these compare only with each other). The send system call's leaf (Go's `syscall.Syscall6`, from which the probe traps into `sendmsg_x`) is divided by the sender's data packets. The send goroutine is every sample of the fork's `sendQueue.Run`, counted once. Medians, with the leaf's range in brackets:

| Rung | Packets/s | Leaf µs per packet | Leaf µs per `sendmsg_x` | Fill | Send goroutine, cores | Send goroutine µs per packet | Go side µs per packet |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Datagrams, cap 8 | 410,190 | 2.088 (2.05–2.12) | 16.7 | 7.99 | 0.957 | 2.31 / 2.36 | 0.25 / 0.24 |
| Datagrams, cap 16 | 431,004 | 2.053 (2.00–2.11) | 32.6 | 15.89 | 0.973 | 2.32 / 2.20 | 0.21 / 0.20 |
| Datagrams, cap 32 | 439,039 | 2.054 (2.05–2.06) | 63.3 | 30.4–31.2 | 0.968 | 2.21 / 2.20 | 0.16 / 0.14 |
| Stream, cap 8 | 403,010 | 2.056 (2.04–2.08) | 16.4 | 7.94–7.97 | 0.918 | 2.26 / 2.30 | 0.22 / 0.22 |
| Stream, cap 32 | 452,192 | 1.893 (1.88–1.91) | 55.7 | 29.4–29.5 | 0.912 | 2.01 / 2.03 | 0.13 / 0.12 |

(Per-pair values where two are given; Go side = send goroutine µs per packet − leaf µs per packet.)

- **The list path has almost no fixed part per call.** A least-squares fit of the leaf per call against datagrams per call over the six Datagram pairs gives 0.26 + 2.045 × n µs (**derived**). So going from 8 to 32 datagrams per call saves the kernel about 0.02 µs per Datagram (0.26 × (1/8 − 1/31)), and the measured leaf per packet moves 2.09 → 2.05 µs. On the batched-send research's figures, one call of about six datagrams cost 11–17 µs; most of that is per datagram.
- **The stream's kernel time per packet falls 8%** (2.06 → 1.89 µs). Its two cap points fit 1.78 + 1.83 × n µs. Why the stream's per-datagram kernel cost is lower than the Datagrams' and its per-call part higher can't be separated without kernel stacks. Both arms use the same socket shape and acknowledgment rule. Stream packets are full-size and Datagram packets are 1,218 bytes, so packet size alone would point the other way.
- **The Go side is where the cap pays.** The send goroutine's work outside the system call falls from 0.24–0.25 µs per Datagram at cap 8 to 0.14–0.16 at cap 32 (stream 0.22 → 0.12–0.13). Fitted per group from the Datagram rungs, that is about 1.0 µs per group plus 0.12 µs per datagram (**derived**: 8a + b ≈ 1.95 µs and 30.8a + b ≈ 4.6 µs per group). The per-group part is one `runBatched` and `sendBatchEntries` pass, one batch callback into wiremux's `WriteUnicastBatch` (in-flight entry, peer lookup, switching lock, the `msghdr_x` array), one `RawConn.Write` and one room signal. The per-datagram part is the channel receive, each datagram's admission and each buffer's release. Every datagram is still admitted before the call.

**Measured**, `G1`: Go execution traces of both peers, two 6 s pairs per rung.

| Rung | Packets/s | Send goroutine busy (in system calls) | System calls/s | System-call µs per packet | per call | Busy µs per packet | Sender run loop busy / runnable | Run loop woken by the send goroutine, /s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Datagrams, cap 8 | 395,602 | 99.5% (86.4%) | 49,629 | 2.19 | 17.4 | 2.52 | 49.4% / 34.6% | 24,034 |
| Datagrams, cap 32 | 436,058 | 99.5% (91.3%) | 14,301 | 2.10 | 63.9 | 2.28 | 45.8% / 22.8% | 10,060 |
| Stream, cap 8 | 386,405 | 95.9% (82.6%) | 48,978 | 2.14 | 16.9 | 2.48 | 46.1% / 24.6% | 25,320 |
| Stream, cap 32 | 458,723 | 90.3% (83.1%) | 16,154 | 1.81 | 51.5 | 1.97 | 45.8% / 12.2% | 10,937 |

(Wake counts are each rung's first pair; busy µs per packet = busy share ÷ packets per second.)

- **The send goroutine gets 9% cheaper per Datagram and 21% per stream packet.** On this basis the system-call time per packet includes Go's entry and exit around each call. It falls 0.09 µs for Datagrams (a per-call part near 0.9 µs, **derived** from 17.4 and 63.9 µs at 8 and about 30.5 datagrams), and the Go side falls from 13.1% to 8.2% of the goroutine's time: 0.33 → 0.19 µs per packet. Together, 2.52 → 2.28 µs per Datagram and +10% rate, as in the campaigns (**derived**).

## 5. The hand-off

The cap also changes how often the two goroutines wake each other (**measured**, `G1`):

- **The run loop is woken a third as often.** The send goroutine woke the sender's run loop about 24–25k times a second at cap 8 and 10–11k at cap 32. The room signal fires once per group.
- **The run loop waits less for a processor.** Its runnable share falls from 34.6% to 22.8% (Datagrams) and from 24.6% to 12.2% (stream), with its busy share about the same (45–49%). So fewer wakeups mean less scheduler churn, not less run-loop work. The receiver's batching research saw the same pattern: the batched-send probe's first saving came from fewer scheduler wakeups.
- **The send goroutine rarely waits.** At cap 32 it waits on the run loop 67 times a second for Datagrams (essentially never) and 6–7% of the time for the stream. So with the run loop's room signal once per 32 packets, the queue doesn't run dry. The 32-entry queue's other cost, the stock sender's hand-off that [Why do slice A and the fork's ownership APIs cost the stock Datagram sender 3–5% at a consumer-sized heap?](https://github.com/GridSwarm/wiremux/issues/1845#issuecomment-6201012510) found, doesn't appear here, because acknowledgments wake the run loop during a group's call: at about 18–20k acknowledgments a second, one arrives every 50–54 µs, against about 63 µs for a 31-datagram `sendmsg_x` (**derived** from `X1`'s acknowledgment rate and leaf per call).

## 6. The next wall

At cap 32 (**measured**, `X1` utilizations over a steady 5 s window, and `G1`; ceilings **derived** as profiled rate ÷ utilization):

| Rung | Sender: send goroutine | Sender: transmit thread `ifnet_start_en3` | Receiver: receive goroutine | Receiver: input thread `dlil_input_en2` | Receiver: Thunderbolt IP thread |
| --- | ---: | ---: | ---: | ---: | ---: |
| Datagrams, cap 8 | 0.957 cores / 99.5% busy | 83.3% | 0.56 cores / 58.5% busy | 65.2% | 48.0% |
| Datagrams, cap 32 | 0.968 cores / 99.5% busy | 78.6% (near 559k) | 0.60 cores / 65.9% busy | 69.3% (near 633k) | 48.5% |
| Stream, cap 8 | 0.918 cores / 95.9% busy | 81.8% | 0.57 cores / 60.0% busy | 65.7% | 47.0% |
| Stream, cap 32 | 0.912 cores / 90.3% busy | 76.0% (near 595k) | 0.61 cores / 66.4% busy | 71.1% (near 636k) | 49.5% |

- **The Datagram sender's send goroutine stays the wall,** at about 2.2–2.3 µs per packet, of which the list path's per-datagram kernel cost is 2.05 µs. The per-call parts are now spread over 31 datagrams, so no larger cap or deeper queue can lower it much: 32 → 64 would save at most about 0.02 µs per packet in Go and 0.004 µs in the kernel (**derived** from the per-group fit). Only fewer datagrams (larger packets on jumbo links) or more than one sending socket (paths) move this wall, and those are already the map's fog.
- **The stream's send goroutine is 90–92% busy** and waits on the run loop the rest, so the stream is near a balance between the two. The run loop is 46% busy and 12% runnable, so neither is clearly the bound.
- **Behind the send goroutine:** the sender's transmit thread gets cheaper per packet as groups grow (2.03 µs at cap 8, 1.79 at cap 32: utilization ÷ rate) and would fill near 560–595k packets a second. The receiver's input thread would fill near 635k. Its receive goroutine is at 0.60 cores with eight slots.
- **What one Wire carries on `tb` at cap 32:** 4.2–4.8 Gbit/s for Datagrams at the pin and 5.0–5.5 for the stream (437–505k packets a second, `K1`–`K2`), sender-bound, depending on the sending Mac's state.

## 7. The `netns` no-harm rows

Pooled medians of ten runs (**measured**, `N1`, `N2`; stock Linux sender, the bundle's 32-entry queue, 16 per acknowledgment):

| Workload, cap | Pooled Mbit/s | Gain, ratio / paired | CPU/GiB sender / receiver | Mean RTT µs | Min RTT µs | Datagram loss (after QUIC) | Declared lost per 100k |
| --- | ---: | --- | --- | ---: | ---: | --- | ---: |
| Datagrams at the pin, 8 | 4,195 | – | 4.40 / 2.81 | 137 | 15 | 0.083% (0.054%) | 28.3 |
| Datagrams at the pin, 16 | 4,320 | +3.0% / +2.8% | 4.39 / 2.79 | 154 | 14 | 0.094% (0.057%) | 29.9 |
| Datagrams at the pin, 32 | 4,377 | +4.3% / +2.2% | 4.37 / 2.80 | 164 | 16 | 0.130% (0.085%) | 39.7 |
| Default GC, 8 | 3,691 | – | 4.97 / 3.32 | 149 | 16 | 0.038% (0.037%) | 0.1 |
| Default GC, 16 | 3,695 | +0.1% / +0.1% | 5.03 / 3.34 | 157 | 16 | 0.034% (0.035%) | 0.1 |
| Default GC, 32 | 3,789 | +2.6% / +2.6% | 4.95 / 3.32 | 169 | 17 | 0.052% (0.052%) | 0.0 |
| Stream, 8 | 10,853 | – | 1.52 / 1.52 | 154 | 18 | – | 109.5 |
| Stream, 16 | 10,915 | +0.6% / +0.1% | 1.51 / 1.52 | 161 | 18 | – | 113.1 |
| Stream, 32 | 10,986 | +1.2% / +0.4% | 1.51 / 1.52 | 158 | 19 | – | 108.7 |

- **No workload lost more than 0.2% at either cap** in either campaign. Each campaign's cap-32 gain was +3.5% and +4.1% at the pin, +2.5% and +2.9% at the default GC, and +1.1% and +0.2% on the stream. CPU per GiB moved by at most 1.1% on either peer at cap 32 and 1.4% at cap 16. The minimum RTT moved by at most 3 µs.
- **The Datagram gain is the room signal.** wiremux's Linux batch callback sends each datagram with its own call, so the cap saves only the per-group Go work and the room signals, which suits the stock sender's hand-off that the 32-entry queue was adopted to fix. The stream sends GSO packets, one queue entry at a time, so the cap barely touches it.
- **Costs within the 32-entry queue decision's bounds.** The mean RTT rises 20–27 µs on Datagrams and 4 µs on the stream. Datagram loss rises by up to 0.05 points, again after QUIC (0.054% → 0.085% at the pin). [Should the fork raise its packet send queue from 8 to 32 entries?](https://github.com/GridSwarm/wiremux/issues/1850#issuecomment-6207580215)'s gate allows "within 0.1 point" of new loss and no rise in minimum RTT beyond noise.

## 8. What a fork slice would carry

This is input to a grilling, not a decision.

- **The change.** `maxSendBatch` follows `sendQueueCapacity` again, which is 32 in the bundle. That restores the fork's own definition (cap equals depth, [`send_queue.go` L109–L112](https://github.com/the-sarge/quic-go-fast/blob/55ea687d68c9c6f33785a1875374ec6a0d7570e8/send_queue.go#L109-L112)) rather than adding a setting. It applies to every fork connection, as the queue does, and the fork's own Darwin batch scratch follows it (section 1). Nothing else in the fork changes: the room signal stays once per group, and section 5 shows that is enough at 32.
- **Where the gain is.** It shows only on the connected macOS shape with batched receives: +12% for Datagrams and +21% for the stream on `tb`, with 3% and 20% less sender CPU per GiB. With today's receiver it adds +1.3%, and in `netns` +0.4% to +4.3%. So it rides on the receive slice that [Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863#issuecomment-6235627888) adopted, and it adds nothing measurable until that slice lands. On its own it's a +1–4% no-harm change.
- **wiremux's side.** The decided `sendmsg_x` slice ([Should wiremux adopt one sendmsg_x per send group on connected macOS sockets?](https://github.com/GridSwarm/wiremux/issues/1860)) keeps per-binding scratch for the `msghdr_x` array and its iovecs. That scratch must hold the cap's 32 entries, as the probe's does (its histogram runs to 64). Nothing else in wiremux changes.
- **A gate the grilling could start from** (A,B,A,B campaigns at `REPS=3` per PROTOCOL.md, against the bundle at cap 8):
  - **`tb`, with batched receives:** Datagrams at the pin at least +8% and the stream at least +12%; the stream's sender CPU per GiB at least 10% lower and the Datagrams' no higher; the receiver no worse.
  - **`tb`, with today's receive:** no slower.
  - **`netns`:** no workload below −1%; CPU per GiB within 2% on both peers.
  - **Both cells:** the minimum RTT unchanged beyond noise; the mean RTT rise no more than about 100 µs on `tb` and 40 µs in `netns`; Datagram loss within 0.1 point, measured with the bundle's 1,024-entry received-Datagram queue.

  These thresholds are this note's measured gains less the drift between campaigns.
- **Order.** As the eighth slice of the one fork bundle it ships with the others, so wiremux and GridCast repin once. The receive-slot decision gave its own slice a rule never to hold the bundle (if it's the only slice not ready, the bundle ships without it), and the cap could take the same rule. Its gain arrives only with the receive slice, which lands last on macOS, so its speed gate has to be measured on a build that has batched receives (a probe, as this note's was) or after that slice lands.
- **One interaction to recheck.** [Should wiremux adopt one sendmsg_x per send group on connected macOS sockets?](https://github.com/GridSwarm/wiremux/issues/1860#issuecomment-6229119445) set its gate at cap 8. Part of what the cap saves (per-group Go work and room signals) also applies to today's per-datagram connected send, so a cap-32 bundle could narrow that slice's measured gain. If both are adopted, its gate should run on the bundle it lands on.

## Method

**Build.** No new code. A detached worktree `1862-probe` at the receiver research's `f417fe0f`, built with its module file pointing at the fork copy `qgf-1861` at `43c244e`, gives a binary byte-identical (`sha256 08beca9d…`) to the receiver research's headline campaigns' binary. The batch cap and queue depth are the batched-send research's process-wide fork settings (`Research1856SetSendQueue(capacity, batch)`, the rig's `-sendq` and `-sendbatch`). The receive slots are the receiver research's (`-nrecvx`).

**Sets** (2026-10-17 UTC; evidence in `native-gap-evidence/1862-batch-cap/`, `README.txt` there):

| Set | What | Runs or pairs | UTC |
| --- | --- | ---: | --- |
| `S0`, `NS0` | `tb` and `netns` smokes (never evidence) | 7 | 15:04–15:05 |
| `K1` | `tb` headline campaign: standard slate + caps 8, 16 and 32 for Datagrams at the pin, Datagrams at the default GC and the stream, all with eight-slot receives, + today's receive at caps 8 and 32 for Datagrams at the pin | 96 runs | 15:06–15:43 |
| `X1` | `tb` profiled pairs, Time Profiler on both Macs, 5 rungs × 2, 8 s | 10 | 15:43–15:52 |
| `G1` | `tb` Go-traced pairs, both peers, 4 rungs × 2, 6 s | 8 | 15:52–15:56 |
| `K2` | `tb` headline campaign, `K1` repeated | 96 runs | 15:57–16:36 |
| `N1` | `netns` headline campaign: standard slate + caps 8, 16 and 32 for Datagrams at the pin, Datagrams at the default GC and the stream | 84 runs | 15:06–15:28 |
| `N2` | `netns` headline campaign, `N1` repeated | 84 runs | 15:28–15:49 |

Every `tb` campaign held one claim for its whole length, and every hand-run pair held its own claim (a placeholder process on m4mini that other sessions' gates wait for), verified 1 s and 6 s later. That makes 21 claims and no collisions. Every `netns` run waited while any other session's `nativerig` ran on minimax; none did. Another session queued its `tb` work behind this one by message. It reported one build on mbp128 at 15:16Z that may have overlapped three `K1` runs, and each of those runs sits inside its arm's range over the other rotations, so they are kept. `X1` and `G1` were copied to minimax and analyzed there only after both cells' campaigns had ended, on CPUs the `netns` cell doesn't use. Every profiled pair deleted its own Instruments raw kernel traces.

## Limits

- **A stand-in receiver.** The gain depends on the receiver lever. Eight-slot `recvmsg_x` is the receiver research's probe, not a decided slice, and the bundle's 1,024-entry received-Datagram and unprocessed-packet queues aren't in the build. So Datagram loss here is higher than the bundle's would be, and the gate must measure it on the bundle.
- **One macOS cell, and the sending Mac's state moves it.** `tb` is the only macOS cell. Its sender-bound arms moved 7–16% between campaigns with the sending Mac's speed, so each gain is reported per campaign and paired per rotation.
- **No kernel stacks.** Why the stream's per-datagram kernel time falls with the cap while the Datagrams' doesn't (section 4) isn't separated.
- **Cap 16's shortfall** against a per-group cost model is unexplained (section 3).
- **NewReno, saturating senders, one Wire.** An application-limited sender rarely fills a group of 32, so it gains CPU at most. Pacing or a delay-based controller (the fork's BBR map) would change the burst the cap allows.
- **`netns` is a shape cell.** Representative Linux numbers need owned Linux hardware, which the owner has ruled out for now. The cell shows no harm, not a Linux target.

## Implications for the map

- **[Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801).** There is a fifth measured macOS lever, and it is a fork constant: with batched receives, a batch cap equal to the bundle's 32-entry queue adds +12% for Datagrams and +21% for the stream, with 3% and 20% less sender CPU per GiB. One Wire on `tb` then carries 4.2–4.8 Gbit/s for Datagrams at the pin and 5.0–5.5 for the stream (437–505k packets a second), still sender-bound. The send goroutine's remaining cost is about 2.05 µs per datagram of the list path's kernel work, which no batch size lowers, so beyond about 500k packets a second one Wire needs fewer, larger packets or more than one path.
- **New, specifiable:** an adoption grilling, "Should the fork's send batch cap follow its 32-entry send queue?", with section 8 as its input. Its gain exists only with batched receives, which [Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863) has adopted, so it can be grilled now. It feeds [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801).
- **[Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863#issuecomment-6235627888)** (adopted). With the cap at 32, the batched sender pushes the eight-slot receiver harder: its queue doubles to about 12 datagrams, and Datagram loss after QUIC rises from 0.14–0.20% to 0.19–0.30% in the probe's 128-entry received-Datagram queue. The receive slice's loss rule 2 (silent discards at most 0.01% of delivered, with the bundle) is measured on the bundle that slice lands on. If the cap joins the bundle, that bundle is the harder case, and the cap's own gate should carry the same rule.
- **"Not yet specified": several four-tuples.** With batched sends and receives and the cap at 32, one connected four-tuple carries 437–505k packets a second on `tb`, bound by the sender's send goroutine at about 2.2 µs per packet, almost all of it per-datagram kernel work. The receiver's per-interface input thread would fill near 635k (**derived**), and the sender's transmit thread near 560–595k. The patch should record that one Wire's next macOS wall is per-datagram kernel cost on the sending socket, and that several four-tuples would each get their own send goroutine but share the interface threads.
- **"Not yet specified": the standing queue.** At cap 32 the eight-slot receiver's queue rises from about 6 to 12 datagrams and is still empty 16% of the time, and the mean RTT under saturation rises from about 0.20 to 0.29 ms. The receiver still outruns the sender on `tb`, so the patch stays as the receiver research left it.

## Open questions

These are candidate tickets.

1. **Should the fork's send batch cap follow its 32-entry send queue?** The grilling: cap equals depth (32) as the fork's original definition or a separate constant; the gate (section 8); the eighth slice of the one bundle or a later release, and whether it takes the receive slice's never-hold rule. Its blocker, [Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863), adopted batched receives; it feeds [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801).
2. **Why does cap 16 give less than a per-group cost predicts?** Unexplained (section 3). Only worth asking if a cap below the queue's depth is ever proposed.
3. **Why does the stream's per-datagram kernel time in `sendmsg_x` fall with group size while the Datagrams' doesn't?** Needs kernel stacks (root on mbp128). Only worth asking if the send goroutine's kernel cost becomes a lever, which the map's present levers don't make it.
