# v0.1.x compatibility contract inventory

Research note for
[Inventory the v0.1.x compatibility contract](https://github.com/GridSwarm/wiremux/issues/769),
under
[Define the private wiremux v0.1.0 release plan](https://github.com/GridSwarm/wiremux/issues/767).

The observed source snapshot is repository `HEAD`
`a0207b3bb1fd0ca28274267e476a0366e6f2be71` (2026-07-13). The repository
has no tags, so this is an inventory input rather than an immutable release
baseline. The normative baseline must be regenerated from the immutable
`v0.1.0-rc.1` candidate commit used for consumer evidence; final `v0.1.0`
normally tags that same commit.

## Decision answer

The v0.1.x compatibility boundary is the whole released surface, not only the
symbols currently used by known consumers. It comprises:

1. every exported declaration and documented behavior in the eight importable
   public packages: root `wiremux`, `channel`, `connect`, `relay`, `relayurl`,
   `stun`, `transport/quic`, and `wiremuxtest`;
2. exported sentinel identity and documented `errors.Is`/`errors.As` trees;
3. the relay, long-lived proof, channel, upgrade-control, authenticated-probe,
   QUIC, Datagram, endpoint/pin, and STUN profiles described below; and
4. the `wiremux-server serve` flag, default, validation, exit-status, and
   machine-relevant output contract.

Within v0.1.x, existing declarations, signatures, interface method sets,
exported struct fields and field order, constant values, sentinel identities,
and documented semantics cannot be removed or incompatibly changed. A genuinely
source- and wire-compatible addition is permitted, but must pass API and
mixed-version evidence before release and then becomes part of the protected
baseline. Adding methods to consumer-implemented interfaces or adding fields to
externally literalizable structs is not presumed compatible. The accepted
pre-release `UpgradeResult.Datagrams` field addition already demonstrated the
unkeyed-literal hazard
([release status](../RELEASE.md#supported-datagram-surface)).

Arbitrary error prose and exact help whitespace are not compatibility promises.
The stable error contract is sentinel/typed classification and documented tree
composition. Stable string-valued constants, `Disposition.String`, wire text,
flag names and values, exit classes, and documented machine-relevant output
prefixes are protected. The pre-tag change to
`ErrUpgradeTransportNotConverged` kept sentinel classification while changing
display text, illustrating the boundary
([release status](../RELEASE.md#release-facing-status)).

## Exported Go surface

The following is the release-review inventory. Package godoc remains the
behavioral detail; this section identifies every category that the baseline
must capture.

### Root `wiremux`

- `Authenticator`, `AuthenticatorFunc.Authenticate`, and `StaticAuth`
  ([auth.go](../../auth.go#L51-L97)).
- `Dial`; `Wire.Read`, `Write`, `Close`, `Datagrams`, `Direct`, `Info`, and
  `Auth`; and `WireInfo{Path, FallbackReason, SelectedPair, ProbeRTT}`
  ([wiremux.go](../../wiremux.go#L36-L136) and
  [wiremux.go](../../wiremux.go#L344-L393)).
- `Option` and every `With*`/`WithoutSTUN` constructor: relay pin/TLS,
  transport, caller-owned and transferred packet sockets, STUN, candidate
  policy, probe/control/establishment budgets, probe concurrency, relay-only,
  channel options, consume-error observation, and auth-release observation
  ([options.go](../../options.go#L24-L274)).
- `Datagrams.MaxPayload`, `Send`, and `Receive`
  ([datagrams.go](../../datagrams.go#L26-L32),
  [datagrams.go](../../datagrams.go#L99-L110), and
  [datagrams.go](../../datagrams.go#L246-L249)).
- `ErrRendezvous`, `ErrIdentity`, `ErrChannel`, `ErrUpgrade`,
  `ErrNilAuthenticator`, `ErrAuthContextReused`, `ErrOptionConflict`,
  `ErrInvalidEstablishTimeout`, `ErrWireClosed`, and `ErrDatagramTooLarge`
  ([wiremux.go](../../wiremux.go#L22-L34),
  [auth.go](../../auth.go#L12-L18),
  [options.go](../../options.go#L16-L22), and
  [wire_errors.go](../../wire_errors.go#L13-L24)).

The protected behavior includes stage classification, one-shot SessionID
consumption and disposition, auth-context ownership/release, packet-socket
ownership transfer, relay fallback, teardown classification, stable Datagram
discovery, queue/context semantics, and reliable/Datagram shared lifetime.

### `connect`

- Interfaces `AuthContext`, `ChannelUseClaimer`, `AuthContextReleaser`,
  `KeyExporter`, `TransportAuth`, `Transport`, `DatagramCarrier`,
  `DatagramCapable`, `Session`, and `TransportListener`, including their method
  sets and ownership/concurrency obligations
  ([contracts.go](../../connect/contracts.go#L31-L243)).
- `NewHKDFKeyExporter`, `NewReleasingAuthContext`,
  `DirectionalKeyOrientation` and its two values, and `DirectionalKeys` with
  its constructor, accessors, clearing, orientation, and redacted formatting
  ([exporter.go](../../connect/exporter.go#L10-L67),
  [auth_context_release.go](../../connect/auth_context_release.go#L10-L23), and
  [directional_keys.go](../../connect/directional_keys.go#L10-L171)).
- `Disposition` with `DispositionUnknown`, `DispositionSpent`, and
  `DispositionRetryable`; `String`;
  `OneShotRendezvous`; both marker constructors; and
  `RendezvousDisposition`
  ([rendezvous_disposition.go](../../connect/rendezvous_disposition.go#L15-L142)).
- `CandidateKind` and its three values, `Candidate`, `GatherOption`, both gather
  options, and `Gather`
  ([gather.go](../../connect/gather.go#L14-L124)).
- `Negotiator`, both constructors, and `Upgrade`
  ([negotiator.go](../../connect/negotiator.go#L10-L72) and
  [upgrade.go](../../connect/upgrade.go#L83-L96)).
- `UpgradeOption`, `CandidatePair`, `UpgradePath` and its values,
  `UpgradeFallbackReason` and all eight public spellings, `UpgradeResult` in
  exact field order, `CandidatePolicy` with all eight fields, every upgrade
  option, and `ValidateUpgradeOptions`
  ([upgrade_types.go](../../connect/upgrade_types.go#L13-L224)).
- All exported sentinels in the package: Datagram/claim/release errors;
  directional-key errors; exporter errors; nil channel/auth/exporter/context/
  transport errors; candidate-gathering errors; and upgrade option, framing,
  timeout, and post-ownership-convergence errors
  ([contracts.go](../../connect/contracts.go#L10-L29),
  [directional_keys.go](../../connect/directional_keys.go#L24-L33),
  [exporter.go](../../connect/exporter.go#L10-L16),
  [negotiator.go](../../connect/negotiator.go#L22-L30),
  [gather.go](../../connect/gather.go#L35-L47), and
  [upgrade_types.go](../../connect/upgrade_types.go#L107-L121)).

### `channel`

- `MaxPayloadSize`; `Channel`, `NewChannel`, `Send`, `Receive`, and `Close`;
  and `NewStream`, `StreamOption`, and `AllowEmptyDataFrames`
  ([channel.go](../../channel/channel.go#L16-L214) and
  [stream.go](../../channel/stream.go#L10-L60)).
- `ErrNilReadWriter`, `ErrNilAuthContext`, the three identity aliases to
  `connect` directional-key errors, `ErrFrameTooLarge`, `ErrAuthentication`,
  `ErrTruncated`, `ErrClosed`, `ErrNonceExhausted`, and
  `ErrStreamEmptyDataFrame`
  ([channel.go](../../channel/channel.go#L27-L65)).

Frame bounds, directional-key validation/claiming, nonce sequencing,
authentication and truncation behavior, authenticated close, stream chunking,
empty-frame policy, full-duplex concurrency, and close-vs-write behavior are
part of the contract.

### `relay`

- `RendezvousID`, `SessionID`, `PeerID`, and `Mode` with `ModeEphemeral` and
  `ModeLongLived` values ([types.go](../../relay/types.go#L3-L29)).
- `Dial`, `Listen`, `ConsumeSession`, `PeerListener`; the listen and dial option
  types and constructors; `Relay`, `New`, `Serve`, and `ServeContext`
  ([client.go](../../relay/client.go#L20-L249),
  [options.go](../../relay/options.go#L421-L450), and
  [server.go](../../relay/server.go#L31-L118)).
- Every exported `Default*` constant and every relay `Option` constructor for
  TLS, timeouts, expiry, mode/proof selection, resource/rate limits, abuse
  backoff, cleanup, event observation, and shutdown
  ([options.go](../../relay/options.go#L10-L77) and
  [options.go](../../relay/options.go#L142-L414)).
- `LongLivedEd25519KeyHashProofScheme`, the prover/verifier interfaces and
  constructors, `PeerIDFromEd25519PublicKey`, PEM TLS helpers, and
  `ACMEServerTLS{TLSConfig, HTTPHandler}` plus its constructor
  ([proof.go](../../relay/proof.go#L14-L128),
  [tlsconfig.go](../../relay/tlsconfig.go#L14-L57), and
  [acme.go](../../relay/acme.go#L13-L36)).
- `EphemeralAbuseBackoffConfig`, its typed validation error and flag-name
  structure, all backoff defaults, the default constructor and validators;
  `ConnectionRateLimitScope` and both values; and every field of
  `ConnectionRateLimitEvent`
  ([abuse_backoff.go](../../relay/abuse_backoff.go#L10-L143) and
  [rate_limiter.go](../../relay/rate_limiter.go#L10-L47)).
- Every sentinel in
  [errors.go](../../relay/errors.go#L5-L132): TLS/listener/endpoint/mode/ID,
  proof/registration, pair/session, timeout/configuration, resource/rate-limit,
  shutdown/runtime, and protocol classifications.

Dual-mode pairing, TLS 1.3, proof defaults, SessionID consumption and expiry,
long-lived registration/accept lifecycle, full-close relay streams, resource
limits, abuse backoff, event delivery, and bounded shutdown are behavioral
compatibility commitments.

### `relayurl`

- `Endpoint`, `Parse`, `Host`, `Port`, `Addr`, `String`, and
  `ErrInvalidEndpoint`
  ([endpoint.go](../../relayurl/endpoint.go#L14-L193)).
- `Fingerprint`, `Pin`, their parse/format/match/verification helpers,
  `PinVerifier`, `PrivateRelayTLSConfig`, and all pin/certificate sentinels
  ([pin.go](../../relayurl/pin.go#L13-L149)).

### `stun`

- `Client`, `ClientOption`, `NewClient`, `Reflexive`; `Server`, `ServerOption`,
  `NewServer`, and `Serve`
  ([client.go](../../stun/client.go#L22-L76) and
  [server.go](../../stun/server.go#L13-L54)).
- `ErrNilContext`, `ErrUncancellableContext`, `ErrNilPacketConn`,
  `ErrNilServerAddress`, `ErrProtocol`, and `ErrBindingError`
  ([errors.go](../../stun/errors.go#L5-L23)).

Socket ownership, context/deadline requirements, retransmission and transient
write behavior, response-source/transaction validation, stateless server
behavior, and close-to-stop semantics are protected.

### `transport/quic`

- `Transport`, its `Name` and `NewSession` behavior, and
  `ErrTransportListenerSingleUse` and `ErrTransportListenerClosed`
  ([transport.go](../../transport/quic/transport.go#L24-L89)).

The returned concrete types are private, but their observable implementation
of the public `connect` interfaces, listener accept-once/close rules, selected
remote binding, teardown-error normalization, and optional Datagram behavior
are protected.

### `wiremuxtest`

The exact supported inventory is already executable: `Relay`, `RelayOption`,
`StartRelay`, both options; `URL`, `DialOptions`, `PairStreams`, `DialPair`,
`ConsumeSession`, `RequireSessionConsumed`; `StreamPair`, `DialResult`,
`DialPairResult`, both `Close` methods; both Datagram factory types; and all
four Datagram contract runners
([contract_inventory_test.go](../../wiremuxtest/contract_inventory_test.go#L21-L138)).

The protected behavior is the real loopback TLS 1.3 ephemeral relay, fresh
production options, stable Host/Client results, owner-native error trees,
bounded concurrency-safe cleanup, redacted diagnostics, and physical relay
session consumption/observation. Numeric internal cleanup and late-result
budgets are deliberately not compatibility promises
([release status](../RELEASE.md#supported-consumer-test-surface)).

## Wire and encoding profiles

These profiles require exact old/new interoperability within v0.1.x. Their
explicit extension mechanisms may evolve compatibly; core fields, version
numbers, code points, transcript labels, and framing cannot drift silently.

| Profile | Frozen v0.1.x contract | Primary sources |
| --- | --- | --- |
| Endpoint and pin text | Canonical `wiremux://host:port` grammar and rejections; lowercase `sha256:<64 hex>` pins. | [endpoint.go](../../relayurl/endpoint.go#L28-L193), [pin.go](../../relayurl/pin.go#L13-L81) |
| Relay | TLS 1.3; magic `wiremux relay v1\n`; request header, opcodes and mode values; status/error codes; 1024-byte ID/error bounds; 32-byte long-lived token; one-byte keepalive/incoming frames. | [protocol.go](../../relay/protocol.go#L12-L255), [server.go](../../relay/server.go#L14-L18) |
| Long-lived proof | `ed25519-keyhash`; SHA-256 public-key PeerID; domain `wiremux v1 longlived-reg`; exporter `EXPORTER-wiremux-v1-longlived-reg`; 32-byte challenge/binding; u16 length-prefixing; `publicKey || signature`. | [proof.go](../../relay/proof.go#L14-L218), [ADR-0001 DP9](../adr/adr-0001-vision-and-scope.md#dp9-long-lived-registration-requires-proof-of-peerid-possession) |
| Encrypted channel | AES-GCM; directional SHA-256 orientation; u32be ciphertext length; plaintext `frameType || payload`; data `0x01`, close `0x02`; big-endian counter nonce; AAD `direction || u64be(seq) || header`. | [channel.go](../../channel/channel.go#L16-L25), [channel.go](../../channel/channel.go#L171-L208), [channel.go](../../channel/channel.go#L226-L352) |
| Upgrade control | Version 1 Core Deterministic CBOR; u32be payload framing; message types 1–8; closed numeric registries and bounds; candidate encodings; fallback wire codes/phase/precedence; `wiremux.datagram/1: true` only in accepted/converged/confirmed. | [control_codec.go](../../connect/control_codec.go#L85-L179), [fallback_reason.go](../../connect/fallback_reason.go#L10-L77), [ADR-0002](../adr/adr-0002-upgrade-control-cbor.md#decision) |
| Authenticated probe | Exporter label `wiremux v1 probe-hmac`; versioned nonce context; `WMXP`; fixed 63-byte packet; candidate encoding; direction/request/response values; 16-byte token plus full HMAC-SHA-256 transcript. | [probe.go](../../connect/probe.go#L24-L200), [PRD-0001 connect contract](../prd/prd-0001-connectivity-kernel.md#connect) |
| QUIC | Transport name `quic`; 32-byte certificate fingerprint material; TLS 1.3 channel-delivered certificate pin; selected-remote binding; stream prime `0x00`; ALPN preference `wiremux-quic/2`, then `/1`; `/2` requires bidirectional RFC 9221; current lower ceiling 1240. | [transport.go](../../transport/quic/transport.go#L38-L180), [transport.go](../../transport/quic/transport.go#L414-L517), [transport.go](../../transport/quic/transport.go#L678-L738) |
| Datagram envelope | `0x00` application discriminator; reserved/empty lower messages dropped; public maximum equals lower maximum minus one (currently 1239); pairwise/lifetime-stable presence. | [datagrams.go](../../datagrams.go#L13-L16), [datagrams.go](../../datagrams.go#L69-L122), [ADR-0009](../adr/adr-0009-optional-datagram-capability.md#negotiation-and-wire-compatibility) |
| STUN | Minimal RFC Binding subset: cookie `0x2112a442`, Binding request/success/error types, XOR-MAPPED-ADDRESS, IPv4/IPv6 forms, strict length/attribute handling, and no legacy MAPPED-ADDRESS fallback. | [protocol.go](../../stun/protocol.go#L12-L208), [PRD-0001](../prd/prd-0001-connectivity-kernel.md#stun) |

The current QUIC 1240/1239 ceiling is a released observable value if present in
the v0.1.0 candidate. A later dependency or packet-size rebaseline may increase
it compatibly only if mixed-version behavior and the lifetime-fixed exact
admission contract remain true; it cannot shrink for an already established
carrier or silently select `/2` below its policy floor
([ADR-0009](../adr/adr-0009-optional-datagram-capability.md#initial-quic-mapping)).

## `wiremux-server` contract

The only command is `serve`. Help forms exit 0; missing/unknown commands and
flag/configuration errors exit 2; startup, service, or shutdown failures exit 1;
clean signal shutdown exits 0
([main.go](../../cmd/wiremux-server/main.go#L10-L81) and
[serve.go](../../cmd/wiremux-server/serve.go#L261-L281)).

Existing flag names, defaults, repeatability, validation, and interactions are
protected:

- listeners: `--relay-listen=:443`, `--stun-listen=:3478`;
- TLS/ACME: `--tls-cert`, `--tls-key`, `--acme`, repeatable
  `--acme-domain`, `--acme-cache-dir`, `--acme-http-listen=:80`;
- shutdown: `--shutdown-timeout=5s`;
- STUN limits: `--stun-rate-window=1s`,
  `--stun-max-global-per-window=4096`,
  `--stun-max-source-per-window=128`,
  `--stun-rate-ipv6-prefix-bits=64`,
  `--stun-rate-drop-report-interval=0`;
- relay abuse: `--relay-ephemeral-abuse-backoff=false` plus the single-valued
  tuning flags `--relay-ephemeral-abuse-window=1m`,
  `--relay-ephemeral-abuse-threshold=10`,
  `--relay-ephemeral-abuse-initial-backoff=1s`,
  `--relay-ephemeral-abuse-max-backoff=30s`,
  `--relay-ephemeral-abuse-min-pair-duration=3s`, and
  `--relay-ephemeral-abuse-max-tracked-sessions=16384`; later occurrences
  replace earlier ones, every tuning value must be positive, the maximum
  backoff cannot be below the initial backoff, tuning requires backoff to be
  enabled, and the abuse flags cannot be combined with `--no-relay` or
  `--longlived-only`; and
- modes: `--no-stun`, `--no-relay`, `--ephemeral-only`,
  `--longlived-only`, and `--longlived-proof=ed25519-keyhash|none`.

Registration/defaults are defined together in
[serve.go](../../cmd/wiremux-server/serve.go#L109-L141), and interaction rules
in [serve.go](../../cmd/wiremux-server/serve.go#L161-L216). An additive flag is
compatible only when omission preserves all existing behavior. The explicit-
certificate startup prefix `relay TLS fingerprint: sha256:` and documented
STUN aggregate drop-report fields are machine-relevant output; arbitrary help
layout and validation prose are not
([serve.go](../../cmd/wiremux-server/serve.go#L315-L326) and
[deployment guide](../DEPLOYMENT.md#stun-rate-limits)).

## Evidence present today

- Upgrade-control has byte-exact goldens for every message and the Datagram
  extension, plus canonical/bounds/adversarial decoding
  ([control_codec_test.go](../../connect/control_codec_test.go#L13-L150)).
- Probe candidate, token, exporter-context, and complete packet vectors are
  byte-exact ([probe_test.go](../../connect/probe_test.go#L11-L355)).
- Relay error-code symmetry, internal-code opacity, and long-lived control
  bytes are tested
  ([protocol_test.go](../../relay/protocol_test.go#L10-L138)); proof tests pin
  length-prefixing and exporter label/context/length
  ([proof_test.go](../../relay/proof_test.go#L141-L225)).
- Channel tests cover round-trip behavior, nonce ordering, reflection,
  direction-bound AAD, truncation, authenticated close, malformed frames, and
  claims ([channel_test.go](../../channel/channel_test.go#L118-L788)).
- QUIC tests pin the certificate material, ALPN/profile, selected capability,
  stream prime, Datagram ceiling/loss/admission behavior, selected-remote
  filtering, listener accept-once, and teardown errors
  ([transport_test.go](../../transport/quic/transport_test.go#L27-L1200) and
  [errors_test.go](../../transport/quic/errors_test.go#L14-L57)).
- Root and integration suites cover stage/error/ownership behavior and run the
  public Datagram conformance runners against production QUIC, absence, and
  malformed seams
  ([datagram_contract_test.go](../../internal/integration/datagram_contract_test.go#L22-L110)).
- `wiremuxtest` has the only exact declaration-and-field inventory plus public
  black-box fixture coverage
  ([contract_inventory_test.go](../../wiremuxtest/contract_inventory_test.go#L48-L138)).
- The normal gate runs ordinary, focused race, lint, vulnerability, and
  documentation checks; `release-check` adds cross-build/vet and the production
  cleanup-budget contract ([Taskfile.yml](../../Taskfile.yml#L17-L59)).

The ordinary package suite passes at the observed snapshot under local
Go 1.26.5 (`GOTOOLCHAIN=local go test ./...`).

## Gaps for release-blocker disposition

These are facts for
[Set the v0.1.0 release-blocker disposition](https://github.com/GridSwarm/wiremux/issues/773)
to adjudicate; this planning-only research ticket does not implement them.

1. **No immutable baseline exists.** There is no tag, checked-in API manifest,
   or release-candidate snapshot. The first baseline must be generated from the
   exact immutable candidate, not today's mutable pre-RC `HEAD`.
2. **No repository-wide API drift gate exists.** Only `wiremuxtest` pins exact
   exported declarations and fields. The other seven public packages have no
   `apidiff`-style comparison or complete manifest, so ordinary compilation can
   miss removal of an unused released symbol or a source-breaking field/method
   change.
3. **No cross-revision matrix exists.** Current mixed-profile tests build both
   sides from one source tree. There is no candidate-versus-prior-v0.1 client,
   server, relay, upgrade, or transport execution. For the first release, the
   candidate must at least self-freeze as the comparison base; later v0.1.x
   releases need old/new combinations.
4. **Wire-vector coverage is uneven.** Upgrade control and probes are strong.
   Relay requests/status/proof exchange, channel ciphertext framing, and STUN
   lack a complete independent byte-vector suite; current tests are mostly
   round-trip or behavioral. QUIC has profile/configuration tests but no
   cross-revision binary fixture.
5. **The CLI lacks one exact contract inventory.** Tests cover flags and
   interactions piecemeal, but no single flag/default/repeatability/exit/output
   manifest fails on drift.
6. **Error-string scope was not automated.** Tests and docs protect sentinel
   classification, but no gate distinguishes protected enum/output strings from
   non-contract diagnostic prose.
7. **Downstream evidence is separate and incomplete.** Consumers have not all
   adopted the optional Datagram surface, and compilation/behavior against the
   immutable candidate belongs to the named-consumer audit rather than this
   local inventory
   ([release status](../RELEASE.md#downstream-order)).
8. **`release-check` is validation, not compatibility or packaging.** It does
   not create/checksum the required Linux artifacts or compare APIs/protocols
   with a baseline; no tag/release publication automation is present
   ([CI](../CI.md#other-events)).

No new Wayfinder ticket is required from this inventory. The existing
release-blocker-disposition decision is already the sharp next question, and
the final executable release-plan prototype owns whatever approved evidence
tasks it produces.
