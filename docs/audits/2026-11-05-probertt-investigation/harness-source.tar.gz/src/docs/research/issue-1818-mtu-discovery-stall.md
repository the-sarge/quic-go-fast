# Native path MTU discovery does not stall: the reliable Wire under-fills packets

Research for [Why does native path MTU discovery stop near 1,400 bytes?](https://github.com/GridSwarm/wiremux/issues/1818), a ticket on the [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). Measured on 2026-10-08 between mbp128 and m4mini over the Thunderbolt `bridge0` link (MTU 1500, macOS 27 arm64), with the map's rig, the fork at `v0.62.1-fast.7`, and wiremux at `2599a002`.

## Answer

Discovery does not stall. In every run, light or full load, both peers' discoverers climb 1,342 → 1,397 → 1,424 → 1,438 and finish within 16–91 ms of connection start. No probe was lost in any run. Every full-size stream packet after that is 1,438 bytes, the ideal for the fork's search.

The roughly 1,400-byte figure in [How much throughput can larger packets buy the native path?](https://github.com/GridSwarm/wiremux/issues/1797) is a *mean* on-wire size from kernel counters, read as a maximum. The mean is pulled down because the reliable Wire sends two short packets per 64 KiB channel record:

- a 33-byte packet that carries only the record's 4-byte length header;
- the record's tail, about 740–770 bytes of stream data.

That gives 48 packets per record where 46.5 would carry the same bytes. The cause is in wiremux, not in the fork. [`channel.Send`](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/channel/channel.go#L301-L306) writes the header and the ciphertext to the QUIC stream as two separate `Write` calls.

The cost at MTU 1500 is the same ~3% #1797 attributed to the stall: 48.06 against an ideal 46.53 packets per record. The native path is packet-rate bound, so packets map one-to-one onto goodput. The cost grows with packet size, which matters for the jumbo-frame lever (see [Jumbo frames](#what-this-means-for-jumbo-frames)).

## Method

The rig is `cmd/nativerig` from `codex/native-gap-rig`. The research branch [`codex/1818-mtu-stall-research`](https://github.com/GridSwarm/wiremux/tree/codex/1818-mtu-stall-research) adds three things on top:

- a `-pace` stream-send flag;
- a qlog tracer for the native endpoint ([`qlog_research.go`](https://github.com/GridSwarm/wiremux/blob/codex/1818-mtu-stall-research/internal/nativequic/qlog_research.go)). It keeps MTU updates, losses, every PING-bearing packet, every packet under 1,400 bytes, and one in 32 of the rest. The full qlog slowed full-load runs to 0.46–1.1 Gbit/s. The filtered tracer ran at baseline rate: 1.45 Gbit/s against the protocol baseline's ~1.46;
- the one-`Write` A/B patch (commit `a96cad62`).

`run.sh` and `an1818.py` are under `cmd/nativerig/research-1818/` on that branch. Every run is one 4-second stream from mbp128 (client, sender) to m4mini (server, receiver), with qlog on both peers and `netstat -s -p udp` before and after. Evidence is in `mbp128:/Volumes/worktrees/wiremux/native-gap-evidence/1818-mtu-stall/`.

Caveat: these runs were made around midday, at mbp128 load 6–7, while another session ran #1814's Docker A/B on the same host. That lowers absolute throughput (112–120k packets/s in the A/B, against the ~133k baseline). It does not change packet sizes, packet counts per record, or discovery outcomes, which are deterministic.

## Discovery reaches the ideal size

| Run | Load | Mbit/s | Client discovery (ms after start) | Server discovery (ms) | Probes lost |
| --- | --- | --- | --- | --- | --- |
| `local1` (same host, `bridge0` address) | full | 611 | 1,438 done at 25 | 1,438 done at 16 | 0 |
| `tb-light` (`-size 16384 -pace 1ms`) | ~107 Mbit/s | 107 | 1,438 done at 25 | 1,438 done at 23 | 0 |
| `tb-full` (full qlog) | full | 1,101 | 1,438 done at 50 | 1,438 done at 31 | 0 |
| `tb-full-2` (full qlog) | full | 456 | 1,438 done at 68 | 1,438 done at 61 | 0 |
| `tb-filt-1` (filtered) | full | 1,449 | 1,438 done at 80 | 1,438 done at 71 | 0 |
| `tb-filt-2` (filtered) | full | 1,464 | 1,438 done at 82 | 1,438 done at 79 | 0 |
| `tb-sizes` (filtered + short packets) | full | 1,346 | 1,438 done at 91 | 1,438 done at 32 | 0 |

In each run the probe sequence is 1,342, 1,397, 1,424 and 1,438, all acknowledged. The fork's search ([`mtu_discoverer.go`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/mtu_discoverer.go)) runs exactly as the #1797 simulation predicted for a lossless path. The receiver logs `packet_received` for every probe packet number. UDP datagrams out of the sender equal UDP datagrams into the receiver in both filtered runs (530,844 = 530,844 and 536,621 = 536,621).

The 8–21-packet gap #1797 saw between interface counters is therefore not lost probes. Its source was not examined here.

## Where the short packets come from

`tb-sizes` records every 1-RTT packet under 1,400 bytes sent after discovery finished, and samples one in 32 of the rest. All sampled full-size packets (14,765) are 1,438 bytes. Each carries 1,409 bytes of stream data: 1,438 minus 7 bytes of short header, 16 of AEAD tag and 6 of STREAM frame header. The short ones:

| Packet | Count | Content |
| --- | --- | --- |
| 33 bytes (43 or 47 with an ACK) | 10,032 | one STREAM frame of exactly 4 bytes: a record's length header |
| ~740–800 bytes | ~10,160 | one STREAM frame ending exactly at a record boundary: the record's tail |

The run carried 672,661,504 application bytes, i.e. 10,264 records of 64 KiB, so it is almost exactly one header packet and one tail packet per record. Every short frame's offset falls on the same record-relative position.

The mechanism:

1. A reliable Wire's `Write` is cut into records of at most 64 KiB plaintext ([`stream.go` L136](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/channel/stream.go#L136), [`MaxPayloadSize`](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/channel/channel.go#L18)). Each record is 4 + 65,553 = 65,557 stream bytes.
2. `channel.Send` seals the record, then calls `writeFull` twice: once for the 4-byte header and once for the ciphertext ([`channel.go` L301-L306](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/channel/channel.go#L301-L306)).
3. The fork's `SendStream.Write` copies a small write into the pending STREAM frame and returns at once. A large write returns once all but the last ≤ 1,452 bytes are taken by the packer, buffering that remainder ([`send_stream.go` L265-L290](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/send_stream.go#L265-L290), [`canBufferStreamFrame`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/send_stream.go#L343-L351)). Each write wakes the send loop.
4. The send loop is faster than the writer. It packs the buffered tail before the writer has sealed the next 64 KiB record. Then it packs the next record's 4-byte header alone, before the writer's very next call hands it the ciphertext.

So the packet sizes come from how the writer feeds the stream, not from any size limit.

## A/B: one Write per record

Commit `a96cad62` seals each record behind its header in one buffer and hands both to the stream in a single `Write`. The bytes on the wire are identical. One channel test fails with it (`TestStreamCloseFrameFollowsInFlightMultiFrameWrite`), because that test waits to observe the header as a separate write. Alternating runs:

| Variant | Mbit/s | Packets | Packets per record | App bytes per packet | 4-byte header packets |
| --- | --- | --- | --- | --- | --- |
| today, run 1 | 1,230.5 | 450,960 | 48.06 | 1,363.7 | 9,268 |
| one `Write`, run 1 | 1,340.0 | 480,984 | 47.06 | 1,392.5 | 8 |
| today, run 2 | 1,306.5 | 478,851 | 48.06 | 1,363.7 | 9,830 |
| one `Write`, run 2 | 1,308.6 | 469,831 | 47.06 | 1,392.7 | 6 |

One `Write` per record removes the header packet and carries 2.1% more application bytes per packet. Today's 1,363.7 app bytes per packet matches the 1,364–1,365 that #1797 measured. On a packet-rate-bound path that is +2.1% stream goodput (**derived**). The throughput column is too noisy at this host load to show it directly.

The remaining gap to the ideal is the tail: 47.06 against 46.53 packets per record, about 1.1% (**derived**). Removing it needs the next record's bytes queued before the tail is packed. Two ways that stay inside wiremux:

- seal several records into one buffer per `Write`, so there is one tail per batch rather than per record;
- pipeline sealing of the next record with the current `Write`.

A third way is to raise the 64 KiB record size, but that is a wire-format change: the receiver rejects larger records ([`channel.go` L207](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/channel/channel.go#L207)). No fork change is needed for any of these.

## What this means for jumbo frames

The discoverer is not a jumbo blocker. With nothing in the stack dropping large probes, it will climb as far as the ceiling allows. The ceiling and black-hole detection remain the fork work #1797 named.

The per-record short packets matter far more at jumbo size (**derived**, assuming the stream stays packet-rate bound and about 29 bytes of per-packet overhead). At a discovered UDP payload near 8,952 bytes, a packet carries about 8,923 stream bytes:

| Records per `Write` | Packets per record | Against the ideal 7.35 |
| --- | --- | --- |
| today (header + ciphertext as two writes) | 9 (7 full + tail + header) | 22% more packets |
| one `Write` per record | 8 | 9% more |
| four records per `Write` | 7.5 (30 per 4 records) | 2% more |

#1797's 4.1–7.6 Gbit/s jumbo estimate assumes full packets. For the reliable stream, it should be discounted by this overhead unless one of the batching levers lands. Datagrams are unaffected: each Datagram is one packet.

## Corrections to earlier notes

- [`issue-1797-native-packet-size.md`](issue-1797-native-packet-size.md), "Today's packet sizes" says the stream "does not reach the size discovery should find" and that "the loss happens inside the native stack". Both are wrong. Discovery reaches 1,438, and no probe is lost. The 1,397–1,400 figures are means, and the ~3% cost is real but comes from packetisation. The simulation matched because the mean landed near the search's 1,397 step.
- The same note's open question on the discovery root cause is answered here.

## Not examined

- The drift from about 1,397 to 1,400 in the per-run mean that #1797 reported. Stream offset varints and ACK coalescing both shift the mean slightly. It no longer bears on any decision.
- When promotion happens relative to discovery's completion (16–91 ms after connection start here). [How should the native Datagram ceiling follow path MTU discovery?](https://github.com/GridSwarm/wiremux/issues/1819) needs that if it measures the ceiling after discovery.
- Linux. The mechanism is platform-independent, but GSO changes how a short packet costs: a short packet ends a GSO batch.
