# Cross-transport Datagram seams for issue 714

Research note for the cross-transport compatibility question in
[Preserve a multipath-compatible capability boundary](https://github.com/GridSwarm/wiremux/issues/714),
under
[Datagram track: unreliable-unordered message primitive on the transport contract](https://github.com/GridSwarm/wiremux/issues/624).

## Decision answer

The proposed `DatagramCarrier` seam does not foreclose WebRTC,
WebTransport, MASQUE, or a future composite Wire, with one important
definition:

> A `Datagrams` handle is permanently bound to the established
> **carrier/session instance** selected at discovery. It never silently
> retargets to another carrier instance. Network-path migration internal to
> that carrier is permitted while the Datagram contract remains true.

Here, “path” must not mean an immutable candidate pair, IP five-tuple, network
interface, or physical route. WebRTC explicitly allows ICE/UDP to handle an IP
address change without changing the DTLS/SCTP layers, while SCTP retests PMTU
and resets congestion state
([RFC 8831 §5](https://www.rfc-editor.org/rfc/rfc8831.html#section-5)).
QUIC likewise preserves one connection across endpoint-address and network-path
migration
([RFC 9000 §9](https://www.rfc-editor.org/rfc/rfc9000.html#section-9)),
and QUIC DATAGRAM frames belong to the connection rather than to a QUIC stream
or network path
([RFC 9221 §5.1](https://www.rfc-editor.org/rfc/rfc9221.html#section-5.1)).

The main cross-transport pressure point is instead the lifetime-fixed payload
ceiling. It should mean a stable wiremux contract value, not a promise that a
transport's native PMTU or message-size query is itself immutable. An adapter
may publish a conservative fixed cap. If its usable native limit later falls
below that cap, the initial one-carrier Wire must terminate rather than silently
reduce `MaxDatagramPayload()` or retarget the handle. A future composite may
instead retire that child carrier and expose a separately designed replacement.

## Compatibility at a glance

| Candidate | Fits the generic seam? | Adapter condition |
| --- | --- | --- |
| QUIC DATAGRAM / WebTransport over HTTP/3 | Yes | Require unreliable support, translate oversize writes into errors, and freeze a conservative cap; terminate the initial one-carrier Wire if the native limit observably falls below it. |
| WebRTC DataChannel | Yes, as an unreliable **message** carrier | Pin unordered delivery plus zero retransmissions; treat SCTP's negotiated maximum as a message limit, not a one-packet MTU. |
| MASQUE CONNECT-UDP over HTTP/3 | Yes as a packet tunnel; conditionally as the Wire's carrier | Prevent reliable Capsule/HTTP fallback and provide an end-to-end congestion authority, normally by carrying an inner congestion-controlled transport such as QUIC. |
| HTTP/2 WebTransport, HTTP Datagram Capsules, or CONNECT-UDP over a reliable HTTP hop | No for this capability | These preserve message framing but retransmit and order bytes underneath; they may be a separate reliable fallback, not the same `Datagrams` handle. |
| Bare UDP | Not by itself | UDP supplies neither a shared congestion controller nor a session owner; an adapter would have to add both. |

## WebRTC DataChannels

WebRTC's native “unreliable” surface is configurable partial reliability, not
one universal profile. Only the combination of unordered delivery and a
retransmission limit of zero gives the UDP-like rule that each SCTP user message
is sent once, with no sender-order guarantee
([RFC 8831 §6.1](https://www.rfc-editor.org/rfc/rfc8831.html#section-6.1)).
The adapter must pin that profile; a lifetime-based partial-reliability policy
can retransmit before expiry and is not equivalent. A DataChannel is
bidirectional, realized by paired incoming and outgoing SCTP streams with
symmetric negotiated properties
([RFC 8831 §6.4](https://www.rfc-editor.org/rfc/rfc8831.html#section-6.4)).

SCTP preserves application-message boundaries but fragments and reassembles
large messages, and its maximum message size is negotiated
([RFC 8831 §5](https://www.rfc-editor.org/rfc/rfc8831.html#section-5),
[RFC 8841 §6](https://www.rfc-editor.org/rfc/rfc8841.html#section-6)).
Consequently, the generic contract remains portable if “datagram” means one
all-or-nothing application message that may be lost or reordered. Requiring one
API call to equal one network packet would exclude WebRTC unnecessarily.
wiremux can expose a conservative fixed ceiling no larger than the negotiated
receive limits; if renegotiation lowers the limit, the initial one-carrier Wire
must end instead of changing its published ceiling.

SCTP owns congestion control per association, and all SCTP streams in that
association share one congestion window
([RFC 8831 §5](https://www.rfc-editor.org/rfc/rfc8831.html#section-5)).
Thus a WebRTC Wire can satisfy the shared-authority rule when its reliable and
unreliable carriers are DataChannels in the same association. Association
shutdown closes every DataChannel, while an individual channel can close by
stream reset
([RFC 8831 §6.2](https://www.rfc-editor.org/rfc/rfc8831.html#section-6.2),
[§6.7](https://www.rfc-editor.org/rfc/rfc8831.html#section-6.7)); this fits an
aggregate owner with a subordinate path-bound handle.

## WebTransport

The 6 July 2026 WebTransport Working Draft exposes one duplex datagram surface
per WebTransport session, which is a direct match for an aggregate-owned
`Datagrams` handle
([W3C WebTransport §5](https://www.w3.org/TR/2026/WD-webtransport-20260706/#webtransportdatagramduplexstream),
[§6.3](https://www.w3.org/TR/2026/WD-webtransport-20260706/#dom-webtransport-datagrams)).
The draft distinguishes HTTP/3 transport that `supports-unreliable` from
HTTP/2 `reliable-only` fallback and offers `requireUnreliable` to reject that
fallback
([W3C WebTransport §6](https://www.w3.org/TR/2026/WD-webtransport-20260706/#webtransport-interface),
[§6.9](https://www.w3.org/TR/2026/WD-webtransport-20260706/#dom-webtransportoptions-requireunreliable)).
wiremux must expose the capability only after the unreliable mode is known; the
existence of WebTransport's native `datagrams` object alone is insufficient.

For HTTP/3, QUIC DATAGRAM provides the required no-retransmission, no-
fragmentation, and shared-QUIC-congestion semantics
([RFC 9221 §5](https://www.rfc-editor.org/rfc/rfc9221.html#section-5),
[§5.4](https://www.rfc-editor.org/rfc/rfc9221.html#section-5.4)). The W3C write
algorithm, however, resolves and discards an oversized datagram rather than
reporting an error
([W3C WebTransport §4.3](https://www.w3.org/TR/2026/WD-webtransport-20260706/#webtransportdatagramswritable-procedures)).
An adapter therefore needs its own size check to uphold `Send`'s error contract.

The draft also says the HTTP/3 maximum is related to estimated PMTU and may be
updated while the session is connected
([W3C WebTransport §5.1](https://www.w3.org/TR/2026/WD-webtransport-20260706/#webtransportdatagramduplexstream-internal-slots)).
This does not require a mutable wiremux API, but it does rule out blindly
forwarding the native value as a lifetime guarantee. The adapter must use the
conservative-cap-or-retirement rule above.

## MASQUE CONNECT-UDP and HTTP Datagrams

CONNECT-UDP associates one bidirectional UDP tunnel with one HTTP request
stream. The proxy's UDP socket lifetime is tied to that stream, including close
on socket failure or inactivity
([RFC 9298 §3](https://www.rfc-editor.org/rfc/rfc9298.html#section-3)). This is
compatible with an aggregate owner and a subordinate carrier handle.

The unreliable property is path-sensitive. HTTP/3 can carry HTTP Datagrams in
QUIC DATAGRAM frames, but the Capsule encoding is reliably delivered in order,
and an intermediary may re-encode between the two forms
([RFC 9297 §3.5](https://www.rfc-editor.org/rfc/rfc9297.html#section-3.5)).
A strict wiremux adapter therefore needs assurance that every controlled HTTP
hop uses the unreliable encoding; it cannot silently accept Capsule, HTTP/2, or
HTTP/1.1 fallback. This is an internal capability gate, not necessarily new
public observability.

CONNECT-UDP prohibits proxy-introduced IP fragmentation and silently drops
oversized datagrams. The HTTP/3 limit depends on QUIC configuration and PMTU
([RFC 9298 §3.1](https://www.rfc-editor.org/rfc/rfc9298.html#section-3.1),
[§6.1](https://www.rfc-editor.org/rfc/rfc9298.html#section-6.1)). A fixed
`MaxDatagramPayload()` can consequently describe the largest payload wiremux
will admit, but never a delivery guarantee; downstream size loss remains an
ordinary unreliable loss site.

MASQUE also sharpens the congestion boundary. The HTTP connection has its own
controller, the proxy-to-target UDP leg has no transport controller, and a
congestion-controlled inner protocol produces nested controllers
([RFC 9298 §6](https://www.rfc-editor.org/rfc/rfc9298.html#section-6)). Raw
CONNECT-UDP therefore does not by itself prove that reliable and unreliable
Wire traffic share one end-to-end authority. The natural conforming design is
an inner transport such as QUIC over CONNECT-UDP; then the Wire and its
`Datagrams` handle bind to that inner session, while MASQUE is an internal path
mechanism.

## Future congestion-policy selection

High-throughput transfer systems confirm that congestion safety and workload
policy are separate concerns. Resilio's public documentation identifies ZGT as
uTP3 and describes a proprietary UDP transport that observes packet loss, RTT,
and throughput to choose a send rate; its published 100 ms WAN measurements
show 934 Mbps for uTP3 versus 125 Mbps for TCP on one 5,120 MB file
([Resilio profiles](https://www.resilio.com/documentation/content/advanced-configuration/profiles-and-configuration-parameters/profiles/),
[service-traffic measurements](https://www.resilio.com/documentation/content/agents/service_traffic_between_resilio_agents/)).
Those are product-level claims, not a public uTP3 protocol or congestion-
algorithm specification, so they establish the use case but not an API model.

IBM makes the policy model explicit. It says FASP continues to use available
bandwidth as latency and loss rise, while its per-transfer configuration offers
a bandwidth target and `fixed`, `fair`, `high`, and `low` policies. `fixed`
attempts the target rate regardless of actual capacity and is discouraged for
most transfers; `high` receives twice a `fair` session's rate during congestion
([Using FASP](https://www.ibm.com/docs/en/connect-direct/6.2.0?topic=v62-using-fasp),
[Configuring FASP](https://www.ibm.com/docs/en/connect-direct/6.2.0?topic=fasp-configuring)).
This is direct precedent for choosing throughput/fairness policy when creating
a transfer, without exposing controller internals on each send operation.

Open transports leave the same room. QUIC's congestion signals are deliberately
generic, and a sender may unilaterally choose another conforming algorithm
([RFC 9002 §7](https://www.rfc-editor.org/rfc/rfc9002.html#section-7)). The
WebTransport Working Draft goes further: its session-construction options carry
a `default`, `throughput`, or `low-latency` congestion-control preference, with
a read-back of whether the user agent satisfied it. The preference is only a
hint, and the low-latency option is currently marked at risk for lack of browser
implementations
([WebTransport §6.9](https://www.w3.org/TR/2026/WD-webtransport-20260706/#dom-webtransportoptions-congestioncontrol)).

Therefore, the shared-authority invariant does **not** select NewReno, CUBIC,
BBR, or one universal latency/throughput objective. It says only that reliable
and Datagram traffic on an established carrier compete under whichever
conforming authority that carrier selected. Keeping congestion controls off the
`Datagrams` handle does not foreclose future GridCast or GrainBin throughput
profiles versus a tapmux low-latency profile: `wiremux.WithTransport` already
accepts a transport instance per Dial, so a future configured transport can
capture a carrier-level semantic preference and apply it in `NewSession`.
The built-in `quic.Transport` has no such option today; adding a constructor or
transport option later is additive and does not require changing the Datagram
data plane.

The intentional limit is that one Wire cannot simultaneously run incompatible
congestion algorithms for different consumers while claiming one shared
authority. A future composite design must either choose one carrier-wide
profile, add scheduling/priority hints within that authority, or create separate
Wires/carriers. Preserve that construction-time extension point; do not freeze
an algorithm in the Datagram contract or promise dynamic per-message controller
selection.

## Cross-cutting contract guardrails

1. **Bind identity to the carrier instance, not the route.** Internal QUIC
   migration, ICE candidate changes, NAT rebinding, and PMTU retesting may occur
   without changing handle identity. Switching to another transport session or
   another composite-Wire child requires another handle.
2. **Specify message semantics, not packet layout.** One `Send` is one
   application message, delivered whole or not; the contract must not promise
   that every implementation emits exactly one UDP packet.
3. **Make the fixed ceiling wiremux-owned.** It is a stable admission cap after
   wiremux overhead, not a live PMTU gauge. A carrier that can no longer uphold
   it ends; it does not mutate the value or silently retarget.
4. **Keep context cancellation narrow.** WebRTC and WebTransport both queue
   sends. `Send(ctx)` can cancel waiting before wiremux hands the message to the
   carrier, but cannot promise to retract a message already accepted by the
   native transport. Success means accepted/queued, never delivered.
5. **Require shared congestion authority as an adapter invariant.** The small
   interface cannot prove this structurally. Bare UDP applications are expected
   to add aggregate congestion control themselves
   ([RFC 8085 §3.1](https://www.rfc-editor.org/rfc/rfc8085.html#section-3.1)); a
   transport adapter is eligible only when it can identify the authority shared
   with the Wire's reliable traffic.
6. **Synchronize exposure above local optional-interface discovery.** Native
   transport negotiation decides whether each local carrier is valid, but a
   pairwise post-establishment agreement must intersect those observations so
   mixed-version or one-sided adapters yield absence on both Wires.
7. **Minimal public observability remains sufficient.** `Wire.Info()` plus the
   fixed payload ceiling need not expose ICE candidates, QUIC migration,
   Capsule use, native retransmission settings, or proxy hops. The adapter must
   gate discovery on the promised semantic profile and end the handle if that
   profile ceases to hold. Future composite-path enumeration can be additive.

These guardrails preserve the one-established-carrier model now without
claiming that a carrier is one forever-fixed network route, and they leave a
future Wire free to own multiple transport/path handles or a separate logical
aggregate.
