# Issue #1844: what bounds the Linux GSO Datagram pair after slice A

Research for [After slice A, what bounds the Linux GSO Datagram pair at a consumer-sized heap?](https://github.com/GridSwarm/wiremux/issues/1844) on the wayfinder map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). [What bounds the native Datagram send feed once Go's garbage collector is off its floor?](https://github.com/GridSwarm/wiremux/issues/1834#issuecomment-6183364936) found that slice A lifts the equal-size Datagram GSO probe sender to 8.8 Gbit/s at the pin (9.3 offered), that the receiver then discards about 5% at its 128-entry received-DATAGRAM queue, and that the sender is congestion-limited 18% of the window. This note measures the three receive-side levers the map has adopted (slice B, the 1,024-entry received-DATAGRAM queue, and receiver coalescing with the copy-at-read fork fix) alone and in every combination, on slice A's sender and on slice A plus the fork's ownership APIs, at the pin and with the default-GC and pointer-bearing-receiver rows. It separates the sender's stages from the receiver's drain with occupancy counters, execution traces and hardware counters, and then tests the sender's congestion response with two probe knobs. Nothing here is implemented. Every build is a throwaway probe, and none is merged or pushed.

Sources are wiremux at `origin/main` [2599a002](https://github.com/GridSwarm/wiremux/tree/2599a00292c70c9871794ce62a1266741d71d42a) (the base of #1834's probe commits; this note's branch is cut from [d30c3689](https://github.com/GridSwarm/wiremux/tree/d30c3689454c0db2b008562d276d991fe642354f)), the quic-go-fast fork at [`v0.62.1-fast.7`](https://github.com/the-sarge/quic-go-fast/tree/v0.62.1-fast.7), Go [go1.27.1](https://github.com/golang/go/tree/go1.27.1), the rig at [`codex/native-gap-rig` 5142d0a7](https://github.com/GridSwarm/wiremux/tree/5142d0a744d3255f395ef033b0fa0e70f462c0b8/cmd/nativerig) (unchanged), and measurements in the minimax `netns` cell on 2026-10-15 (UTC). Every number is marked **measured**, **derived** or **inferred**; tables are **measured** unless a column says otherwise.

## Answer

- **After slice A, the Linux GSO Datagram pair is bound by its receiver, not by the fork's sending stages.** At the pin with today's receiver, slice A's pair delivers 8,731 Mbit/s of 9,209 offered, and slice A plus the ownership APIs 8,712 of 9,147 (**measured**). Delivery is held about 5% below the offer by the receiver's application goroutine, which cannot drain the 128-entry received-DATAGRAM queue at about 680 ns per Datagram. The offer is held by the sender's congestion controller, which cuts its window 70–90 times per 10-second window in answer to real packet losses at the receiver's 256-packet unprocessed-packet queue, in front of the receiver's run loop. 93–99% of those loss bursts start while that run loop has been waiting for a processor for about the 240 µs the queue holds. No sending stage is saturated: the sender's run loop is busy 56–57%, its packet writer 69–74%, and 1.9–2.3 of its 4 CPUs are idle.
- **Each lever alone, at the pin (delivered and offered; A, then own):**
  - The 1,024-entry queue: +3.3% and +4.2% delivered; loss falls from 5.2% to 0.08% and from 4.8% to 0.09%; the offer does not move (−1.9%, −0.6%). It lets delivery reach the offer, nothing more.
  - Slice B (approximated): +18.0% and +16.0% delivered, +13.6% and +12.2% offered, receiver CPU −22%. It is the largest single lever: it cuts the receiver application's work per Datagram by two-thirds and halves the sender's cutbacks.
  - Receiver coalescing (copy-at-read): +5.1% and +13.8% delivered, +5.6% and +14.5% offered, receiver CPU −21–23%. It takes about 0.47 CPUs of segmentation softirq off the sender's processors and halves the unprocessed-packet drops.
- **All three together, the expected receiver:** A 10,188 Mbit/s (+16.7%, offer +10.6%) and own 10,878 (+24.9%, offer +18.9%), with loss 0.01–0.02% and no received-DATAGRAM discards; receiver CPU per GiB −43–44%, sender −24–27% (all **measured**). On A, coalescing costs 2.2% on top of the queue and slice B (A's best pair is those two, 10,412). Every pairwise value is in section 2.
- **The fork's ownership APIs add 6.8% on the expected receiver and take 23% off the sender's CPU** (1.25 against 1.62 CPU-s/GiB). Without coalescing they add nothing (−1.9% to +0.6%); with it, 7–8% in every combination.
- **What bounds the expected receiver's pair is still the congestion response to those losses, now mostly from the receiver's garbage collector.** 61–69% of the remaining loss bursts start inside a mark phase (about 0.5 ms each), which covers under 1% of the run. A probe that deepens the unprocessed-packet queue to 1,024 packets removes the bursts and is worth +15.4% to A (11,855 Mbit/s) and +6.2% to own (11,691), with loss still 0.01%; letting the sender ignore the losses instead gains the same but loses 0.7–0.85%. Behind that, at about 1.24 million Datagrams a second, both peers' run loops (about 600 ns per Datagram each, busy or runnable 88–93% of the window in traces) and the hand-offs around them are next.
- **Default GC and a pointer-bearing receiver heap.** With all three levers, Go's default GC is 22% (A) and 12% (own) below the pin. A pointer-bearing receiver heap costs the plain receiver 17–19% (loss 7.2–7.5%) and the expected receiver 7–8%: the levers remove its loss (0.01–0.02%), but its 8 ms mark phases cause 98% of the remaining loss bursts.

## 1. What was measured

**The receive path.** On the receiver, the fork's reader goroutine reads packets with `recvmmsg` (or, when the receiver coalesces, coalesced reads that the copy-at-read fix splits into one buffer per datagram) and hands each to the connection's unprocessed-packet queue. That queue drops a packet when 256 are already waiting for the run loop ([`connection.go` L2010-L2016](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2010-L2016), [`params.go` L43](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/protocol/params.go#L43)). These drops are real QUIC packet losses: the sender's loss detection sees them, and its NewReno congestion controller (the fork's `cubicSender`, constructed in Reno mode: [`sent_packet_handler.go` L150-L157](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/sent_packet_handler.go#L150-L157)) cuts its window once per loss event ([`cubic_sender.go` L199-L224](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/congestion/cubic_sender.go#L199-L224)). The connection's run loop decrypts each packet and hands each DATAGRAM frame to the received-DATAGRAM queue, copying the payload into a fresh allocation (receiver copy 1) unless 128 are already queued, in which case it discards the frame ([`datagram_queue.go` L14, L93-L101](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/datagram_queue.go#L93-L101)). Those discards come after the packet is acknowledged, so congestion control never sees them. The application goroutine's `Datagrams.Receive` builds a merged context for each call ([`datagrams.go` L183-L188](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/datagrams.go#L183-L188)) and copies the payload out of its one-byte envelope into a second fresh allocation (copy 2, [L225-L226](https://github.com/GridSwarm/wiremux/blob/2599a00292c70c9871794ce62a1266741d71d42a/datagrams.go#L225-L226)).

**Senders.** Both are #1834's probes on the equal-size Datagram GSO probe sender, rebuilt unchanged except for the knobs below: **A**, slice A's one-queue, one-copy native send (#1823's `s3b-rootpumpless`), and **own**, A plus the fork's ownership APIs (`SendDatagramOwned` with release after packing, and a 64-buffer free list in the carrier). Today's send (**base**) runs at the pin with a plain receiver as the anchor to #1834. The stock sender is out of scope ([Why do slice A and the fork's ownership APIs cost the stock Datagram sender 3–5% at a consumer-sized heap?](https://github.com/GridSwarm/wiremux/issues/1845)).

**Receiver levers.** Each is a runtime knob, off unless a flag sets it, so all of them rotate as arms inside one build per sender variant:

| Lever | Flag | What it changes | Where it differs from what the map adopted |
| --- | --- | --- | --- |
| 1,024-entry received-DATAGRAM queue | `-rq 1024` | The fork copy's `maxDatagramRcvQueueLen` (128) becomes a variable the rig sets before any connection exists | None in behavior. The adopted slice also counts discards for wiremux to read; the probe counts them only in its own counters. |
| Slice B | `-r1844b` | #1823's `r1-nocopy` (return the carrier's caller-owned slice without the envelope instead of copying it) and `r2-ctxcache` (reuse the merged receive context while the caller passes the same context), applied unchanged, then wrapped in a package flag | The probe drops the copy for every carrier, not only native carriers behind an internal marker. It compares contexts with `!=`, which panics on a non-comparable context type; the adopted slice must not. It also leaves the cached context's `AfterFunc` registered until the next receive with a different context. The rig's receiver passes one context throughout, so the reuse always hits. |
| Receiver coalescing with copy-at-read | `-gro -gro-role recv -fix-cr` | The receiver's `UDP_GRO` with #1829's fix: the fork's Linux reader copies each coalesced datagram out at read time | As adopted by [Should native receives adopt coalescing once the fork copies coalesced datagrams at read time?](https://github.com/GridSwarm/wiremux/issues/1835#issuecomment-6196268143), in #1829's and #1834's fork copies. |
| Pointer-bearing receiver heap | `-ballast 64 -gc-role both -ballast-ptr 64 -ptr-role recv` | The sender keeps the pin's 64 MiB pointer-free heap; the receiver's 64 MiB is 64-byte pointer-linked objects instead (82–84 MiB live with their index) | `-ptr-role` is a probe flag. [How much native Datagram throughput does Go's garbage collector take?](https://github.com/GridSwarm/wiremux/issues/1833#issuecomment-6158306566) put the pointer heap on both peers. |

The probe's fork copies also count, only in mechanism runs (`-q1834`), each received-DATAGRAM enqueue's queue length, its discards, its deepest length, and the `Receive` calls that found the queue empty.

**Arms and campaigns.** On each of A and own: the plain receiver, each lever alone, each pair, all three, all three at Go's default GC, and the plain and all-three receivers with a pointer-bearing receiver heap; plus base at the pin and the standard slate. That is 30 arms. Two campaigns, C1 (2026-10-15 16:08–17:06Z) and C2 (17:06–18:40Z), each `REPS=3 WARMUP=1 SECS=10`, so six 10-second runs per row. Pooled medians; spread is min..max. CPU is CPU-seconds per delivered GiB, whole process. "Offered" is the sender's own rate. The two campaigns agree within 1.4% on every Datagram row. The anchors reproduce #1834: base at the pin 5,473 Mbit/s (#1834: 5,493), A 8,731 (8,848), own 8,712 (8,844), and with coalescing A 9,176 (9,186) and own 9,913 (10,019).

## 2. Each lever alone and together

At the pin (pooled C1 and C2, six runs per row except A with slice B, five):

| Sender | Receiver | Mbit/s | Spread | Change against plain | Offered Mbit/s | Offer change | Loss | Received-DATAGRAM discards per run | Sender CPU | Receiver CPU | Receiver user CPU | Sender CPUs in softirq |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| base | plain | 5,473 | 5,394..5,546 | — | 5,488 | — | 0.28% | 15,632 | 3.23 | 2.45 | 1.74 | 0.40 |
| A | plain | 8,731 | 8,521..8,885 | — | 9,209 | — | 5.24% | 500,108 | 2.14 | 2.23 | 1.69 | 0.57 |
| A | 1,024 queue | 9,021 | 8,840..9,262 | +3.3% | 9,031 | −1.9% | 0.08% | 3,610 | 2.03 | 2.17 | 1.66 | 0.57 |
| A | slice B | 10,305 | 10,171..10,414 | +18.0% | 10,462 | +13.6% | 1.64% | 177,714 | 2.04 | 1.73 | 1.20 | 0.66 |
| A | coalescing | 9,176 | 9,097..9,358 | +5.1% | 9,724 | +5.6% | 5.55% | 569,210 | 1.71 | 1.76 | 1.56 | 0.10 |
| A | queue + slice B | 10,412 | 10,253..10,635 | +19.3% | 10,417 | +13.1% | 0.03% | 186 | 2.01 | 1.71 | 1.19 | 0.66 |
| A | queue + coalescing | 9,634 | 9,578..9,777 | +10.3% | 9,637 | +4.6% | 0.03% | 1,420 | 1.62 | 1.72 | 1.53 | 0.10 |
| A | slice B + coalescing | 9,922 | 9,871..9,991 | +13.6% | 10,186 | +10.6% | 2.67% | 284,440 | 1.66 | 1.29 | 1.08 | 0.11 |
| A | all three | 10,188 | 10,173..10,261 | +16.7% | 10,189 | +10.6% | 0.02% | 0 | 1.62 | 1.27 | 1.06 | 0.11 |
| own | plain | 8,712 | 8,631..9,068 | — | 9,147 | — | 4.83% | 464,252 | 1.72 | 2.24 | 1.65 | 0.54 |
| own | 1,024 queue | 9,079 | 9,024..9,141 | +4.2% | 9,090 | −0.6% | 0.09% | 6,036 | 1.65 | 2.18 | 1.62 | 0.54 |
| own | slice B | 10,107 | 7,912..10,237 | +16.0% | 10,260 | +12.2% | 1.61% | 171,060 | 1.66 | 1.74 | 1.18 | 0.62 |
| own | coalescing | 9,913 | 9,804..10,047 | +13.8% | 10,471 | +14.5% | 5.45% | 600,780 | 1.31 | 1.73 | 1.54 | 0.08 |
| own | queue + slice B | 10,400 | 10,151..10,499 | +19.4% | 10,403 | +13.7% | 0.02% | 7 | 1.62 | 1.72 | 1.16 | 0.62 |
| own | queue + coalescing | 10,413 | 10,300..10,500 | +19.5% | 10,420 | +13.9% | 0.07% | 6,534 | 1.23 | 1.69 | 1.51 | 0.08 |
| own | slice B + coalescing | 10,718 | 10,326..10,763 | +23.0% | 10,939 | +19.6% | 2.12% | 244,044 | 1.27 | 1.27 | 1.06 | 0.09 |
| own | all three | 10,878 | 10,751..11,001 | +24.9% | 10,879 | +18.9% | 0.01% | 0 | 1.25 | 1.25 | 1.04 | 0.09 |

"Coalescing" is receiver coalescing with copy-at-read throughout. The one low run in own with slice B (7,912 Mbit/s, C2 r1) had 4.8 CPUs of other work on minimax during its stat window; it is kept, and the median is unaffected.

What each lever adds to the other two (**derived** from the table: all three against the pair without that lever):

| Lever | A | own |
| --- | --- | --- |
| 1,024 queue | +2.7% (9,922 → 10,188) | +1.5% (10,718 → 10,878) |
| Slice B | +5.8% (9,634 → 10,188) | +4.5% (10,413 → 10,878) |
| Coalescing | −2.2% (10,412 → 10,188) | +4.6% (10,400 → 10,878) |

- **The 1,024 queue removes the loss but not the limit.** Alone it takes loss from 5.2% to 0.08% (A) and from 4.8% to 0.09% (own), and delivery rises to the offer (+3.3%, +4.2%). The offer itself does not move (−1.9%, −0.6%). So the receiver's drain held delivery about 5% below the offer, and something else holds the offer near 9.1–9.2 Gbit/s (section 3).
- **Slice B is the largest single lever, and it raises the offer.** Alone it adds 18.0% (A) and 16.0% (own) delivered and 13.6% and 12.2% offered, and cuts receiver CPU per GiB by 22%. It cuts what the receiver's application goroutine does per Datagram by almost two-thirds (section 4) and halves the receiver's bytes allocated per Datagram (3,104 → 1,587) and its collections (46 → 28 a second); the sender's congestion cutbacks halve with them (section 3). Its 1.6% loss is the 128-entry queue still overflowing in bursts; with the 1,024 queue that goes to 0.02–0.03%.
- **Coalescing pays on own and much less on A.** Alone it adds 5.1% (A) and 13.8% (own). It takes 0.47 CPUs of the receiver's segmentation softirq off the sender's processors (0.57 → 0.10), which cuts the time the fork's packet writer spends in `sendmsg` by more than half (section 4), and it halves the unprocessed-packet drops (section 3). On top of the queue and slice B it is worth +4.6% to own and costs A 2.2%, so A's best receiver here is the queue plus slice B (10,412 Mbit/s).
- **All three together** (the expected receiver): A 10,188 Mbit/s (+16.7% delivered, +10.6% offered) and own 10,878 (+24.9%, +18.9%), with loss 0.01–0.02% and no received-DATAGRAM discards. The receiver's CPU per GiB falls 43–44% (2.23 → 1.27 and 2.24 → 1.25) and the sender's 24–27% (2.14 → 1.62 and 1.72 → 1.25), the sender's mostly through coalescing.
- **The ownership APIs add 6.8% on the expected receiver** (10,878 against 10,188) **and take 23% off the sender's CPU** (1.25 against 1.62 CPU-s/GiB). Without coalescing they add nothing (−1.9% to +0.6% in the four arms without it); with coalescing they add 7–8% in every combination (+8.0%, +8.1%, +8.0%, +6.8%; **derived**), as #1834 found.

## 3. What holds the offer: losses before the receiver's run loop

| Sender | Receiver | Offered Mbit/s | Unprocessed-packet drops per run | Sender cutbacks per window | Receiver GC cycles/s | Mean congestion window KiB | Smoothed RTT µs | Congestion-limited | Run loop finds nothing to send | Sender run loop busy | Emit busy | Sender CPUs idle |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| base | plain | 5,488 | 655 | 6 | 29 | 430 | 38 | 0.00 | 0.66 | 0.41 | 0.54 | 2.01 |
| A | plain | 9,209 | 3,244 | 90 | 46 | 322 | 136 | 0.18 | 0.25 | 0.56 | 0.74 | 1.88 |
| A | 1,024 queue | 9,031 | 3,667 | 92 | 47 | 310 | 144 | 0.19 | 0.25 | 0.56 | 0.72 | 1.87 |
| A | slice B | 10,462 | 3,194 | 46 | 28 | 400 | 137 | 0.09 | 0.27 | 0.64 | 0.85 | 1.59 |
| A | coalescing | 9,724 | 1,210 | 78 | 46 | 294 | 74 | 0.14 | 0.30 | 0.60 | 0.29 | 2.21 |
| A | queue + slice B | 10,417 | 3,222 | 46 | 28 | 396 | 166 | 0.09 | 0.26 | 0.63 | 0.84 | 1.59 |
| A | all three | 10,189 | 1,338 | 54 | 25 | 322 | 115 | 0.10 | 0.31 | 0.63 | 0.32 | 2.13 |
| own | plain | 9,147 | 2,250 | 70 | 46 | 307 | 97 | 0.14 | 0.32 | 0.57 | 0.69 | 2.29 |
| own | 1,024 queue | 9,090 | 2,536 | 73 | 48 | 299 | 116 | 0.15 | 0.31 | 0.57 | 0.68 | 2.33 |
| own | slice B | 10,260 | 2,270 | 35 | 28 | 370 | 122 | 0.06 | 0.32 | 0.64 | 0.78 | 2.12 |
| own | coalescing | 10,471 | 969 | 72 | 50 | 289 | 81 | 0.10 | 0.28 | 0.65 | 0.27 | 2.58 |
| own | queue + slice B | 10,403 | 2,261 | 30 | 28 | 389 | 105 | 0.06 | 0.32 | 0.65 | 0.79 | 2.11 |
| own | all three | 10,879 | 799 | 42 | 27 | 312 | 90 | 0.05 | 0.30 | 0.68 | 0.30 | 2.49 |

Shares are of the transfer window; "cutbacks" are NewReno's loss responses in the window (about 10 s); unprocessed-packet drops are the receiver's count over the run.

- **Every QUIC packet the sender loses is one the receiver dropped at its 256-packet unprocessed-packet queue**, ahead of its run loop: in 205 of the 207 Datagram runs the sender's lost-packet count equals the receiver's unprocessed-packet drops exactly (for example 2,999 and 2,999 in one A run), and in the other two (own at Go's default, C1) the difference is the receiver's socket-buffer drops (833 and 1,964), the only ones in either campaign (all **measured**). At slice A's rate that queue holds about 240 µs of arrivals (**derived**: 256 packets at about 1.07 million a second), so any stall of the receiver's run loop longer than that drops a burst.
- **The sender's congestion controller answers each burst with a cutback**, 70–90 per window with a plain receiver, and is congestion-limited 14–18% of the window while 1.9–2.3 of its 4 CPUs sit idle and no stage is busier than 74%. That holds the offer near 9.1–9.2 Gbit/s whatever the received-DATAGRAM queue does (section 5 removes the drops and measures what that is worth).
- **The deeper received-DATAGRAM queue lowers the offer by 0.6–1.9%**: the receiver's application now copies every Datagram instead of discarding 5%, and the unprocessed-packet drops rise 13% (3,244 → 3,667 and 2,250 → 2,536). The effect is small, and both campaigns show it for A.
- **Slice B halves the cutbacks without reducing the drops.** The drops stay at 2,250–3,244 per run, but they come in half as many bursts (next table) and half as many loss events (46 and 35 cutbacks against 90 and 70), so the sender is congestion-limited half as often (9% and 6%) and its window averages 370–400 KiB instead of 307–322.
- **Coalescing cuts the drops by more than half** (3,244 → 1,210 and 2,250 → 969), because the reader spends half as long per Datagram (section 4), but the cutbacks barely move (90 → 78 and 70 → 72): the bursts remain, only shallower.

**When the bursts start.** The probe-x fork copies (section 5) log the start of each drop burst (a drop at least 500 µs after the previous one) into the execution trace, so each burst can be placed against the receiver's run loop and its garbage collector. Receiver traces, two runs per case at the pin (5-second sends; each receiver trace spans about 10 seconds), outside the campaigns:

| Sender | Receiver | Drop bursts per traced run | Started inside a GC mark phase or pause | Share of the run those phases cover | Started while the run loop was runnable | Median time runnable by then µs | Median mark phase µs |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A | plain | 31, 37 | 1% | 1.4% | 99% | 226, 219 | 523, 520 |
| A | slice B | 18, 13 | 6% | 0.8% | 65% | 226, 233 | 498, 496 |
| A | all three | 9, 9 | 61% | 0.7% | 50% | 81, 56 | 512, 556 |
| A | all three, pointer-bearing receiver heap | 25, 20 | 98% | 7.1% | 53% | 34, 88 | 7,962, 7,829 |
| own | plain | 36, 38 | 5% | 1.6% | 93% | 226, 220 | 564, 534 |
| own | all three | 36, 34 | 69% | 0.9% | 67% | 57, 52 | 558, 499 |

- **With a plain receiver the bursts are the run loop waiting for a processor.** 93–99% of them start while the receiver's run loop is runnable, after a median 219–226 µs of waiting: about the time 256 arriving packets take at this rate (230–240 µs, **derived**), so the queue overflows just as the wait outlasts it. The run loop is woken almost only by the reader (37,627 of 37,906 wake-ups in one trace) and waits 20 µs per wake-up on average, so these are the tail of an ordinary wait, not a stall. Only 1–5% of these bursts fall in a GC phase, about what chance gives. Why the run loop waits while the receiver's CPUs are 1.8 idle is the same pattern as section 4's sender (a goroutine woken into its waker's processor slot); the run queues are not traced, so that part is **inferred**.
- **Slice B removes about half of those waits** (18 and 13 bursts against 31 and 37), presumably because the application, which the run loop wakes and which then shares its processor, now gives the processor back after 243 ns per Datagram instead of 681 (**inferred**).
- **With all three levers, what is left is mostly the receiver's garbage collector.** 61–69% of the remaining bursts start inside a mark phase or pause, which cover under 1% of the run (70–90 times chance, **derived**). Each mark phase lasts about 0.5 ms, twice what the queue holds, while Go's background marking takes one of the receiver's four processors ([`mgcpacer.go` L39](https://github.com/golang/go/blob/go1.27.1/src/runtime/mgcpacer.go#L39)). A pointer-bearing receiver heap makes each mark 16 times longer (7.8–8.0 ms), and 98% of its bursts fall inside one (section 6).

## 4. Where each peer's time goes

Execution traces of both peers (two 5-second runs per case, summarized over the middle 3 seconds; shares of the window; "ns per Datagram" is running plus system-call time per traced Datagram, **derived** from the traced rate, which tracing lowers by about 5–10%):

**Receiver:**

| Sender | Receiver | Traced Datagrams/s | Application running | Application runnable | Application ns per Datagram | Run loop running | Run loop runnable | Run loop ns per Datagram | Reader running + in system calls | Reader ns per Datagram |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | plain | 843,568 | 0.57 | 0.27 | 681 | 0.57 | 0.25 | 676 | 0.71 | 843 |
| A | 1,024 queue | 883,715 | 0.60 | 0.26 | 682 | 0.58 | 0.24 | 657 | 0.73 | 817 |
| A | slice B | 965,757 | 0.24 | 0.46 | 243 | 0.61 | 0.24 | 636 | 0.78 | 806 |
| A | coalescing | 888,925 | 0.61 | 0.26 | 684 | 0.58 | 0.16 | 656 | 0.31 | 354 |
| A | all three | 887,138 | 0.19 | 0.51 | 212 | 0.57 | 0.16 | 641 | 0.33 | 374 |
| own | plain | 893,658 | 0.60 | 0.25 | 676 | 0.59 | 0.25 | 658 | 0.77 | 854 |
| own | slice B | 1,044,263 | 0.27 | 0.46 | 257 | 0.65 | 0.25 | 625 | 0.86 | 823 |
| own | coalescing | 974,222 | 0.68 | 0.23 | 700 | 0.65 | 0.15 | 663 | 0.32 | 327 |
| own | all three | 1,126,780 | 0.29 | 0.46 | 261 | 0.69 | 0.15 | 612 | 0.35 | 311 |

**Sender:**

| Sender | Receiver | Traced Datagrams/s | Application running | Application runnable | Carrier's sender (`pumpN`) running | `pumpN` runnable | Run loop running | Run loop runnable | Run loop ns per Datagram | `emit` in system calls | `emit` runnable | `emit` ns per Datagram |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | plain | 875,538 | 0.32 | 0.46 | 0.33 | 0.38 | 0.57 | 0.21 | 648 | 0.66 | 0.13 | 818 |
| A | slice B | 977,260 | 0.35 | 0.49 | 0.36 | 0.39 | 0.64 | 0.21 | 656 | 0.75 | 0.11 | 834 |
| A | coalescing | 915,279 | 0.33 | 0.52 | 0.34 | 0.35 | 0.59 | 0.20 | 649 | 0.25 | 0.30 | 342 |
| A | all three | 887,199 | 0.32 | 0.60 | 0.33 | 0.32 | 0.61 | 0.18 | 687 | 0.29 | 0.27 | 410 |
| own | plain | 941,534 | 0.17 | 0.15 | 0.16 | 0.63 | 0.57 | 0.20 | 607 | 0.63 | 0.15 | 717 |
| own | slice B | 1,063,790 | 0.19 | 0.17 | 0.18 | 0.69 | 0.65 | 0.22 | 612 | 0.73 | 0.13 | 731 |
| own | coalescing | 1,058,674 | 0.19 | 0.17 | 0.18 | 0.59 | 0.63 | 0.17 | 598 | 0.22 | 0.38 | 253 |
| own | all three | 1,126,977 | 0.21 | 0.18 | 0.19 | 0.64 | 0.68 | 0.18 | 604 | 0.26 | 0.40 | 275 |

**The receiver's received-DATAGRAM queue** (occupancy counters, two 10-second runs per case; depth found at each enqueue, in power-of-two buckets):

| Sender | Receiver | Queue depth | Discards | Application found it empty | Median depth | 90th percentile | 99th percentile | Enqueues at 128 or deeper | Deepest |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | plain | 128 | 4.62% | 0.5% | 32–63 | 64–127 | 64–127 | — | 127 |
| A | 1,024 queue | 1,024 | 0.02% | 0.5% | 64–127 | 128–255 | 256–1,023 | 18.9% | 1,023 |
| A | slice B | 128 | 1.59% | 1.3% | 32–63 | 64–127 | 64–127 | — | 127 |
| A | all three | 1,024 | 0 | 1.4% | 32–63 | 64–127 | 128–255 | 2.4% | 1,023 |
| own | plain | 128 | 4.40% | 0.6% | 32–63 | 64–127 | 64–127 | — | 127 |
| own | 1,024 queue | 1,024 | 0.03% | 0.5% | 32–127 | 128–255 | 256–511 | 14.3% | 1,023 |
| own | all three | 1,024 | 0 | 1.2% | 32–63 | 64–127 | 128–255 | 3.1% | 479 |

**Hardware counters** (`perf stat` counting mode, both peers, two 10-second runs with each of two event sets; per Datagram the peer moved; process-wide, so the receive softirq that runs on the sender's CPUs counts on the sender, as the coalescing rows show (**inferred**)):

| Sender | Receiver | Receiver cycles per Datagram | Receiver instructions per Datagram | Receiver demand fills from DRAM per Datagram | Sender cycles per Datagram | Sender demand fills from DRAM per Datagram |
| --- | --- | --- | --- | --- | --- | --- |
| A | plain | 12,187 | 23,547 | 12.4 | 11,315 | 20.5 |
| A | 1,024 queue | 11,920 | 22,872 | 12.7 | 11,347 | 20.5 |
| A | slice B | 9,531 | 18,236 | 5.5 | 11,342 | 21.0 |
| A | coalescing | 9,559 | 19,166 | 12.4 | 9,003 | 15.2 |
| A | all three | 7,077 | 13,881 | 5.9 | 9,403 | 15.5 |
| own | plain | 12,228 | 23,600 | 11.8 | 9,112 | 6.5 |
| own | slice B | 9,562 | 18,284 | 5.1 | 9,199 | 7.1 |
| own | coalescing | 9,423 | 18,943 | 12.3 | 6,958 | 1.4 |
| own | all three | 6,760 | 13,669 | 4.9 | 7,006 | 1.3 |

- **With a plain receiver, the receiver's application goroutine is what discards.** It spends 676–681 ns per Datagram (its copy into a fresh allocation, the merged context and the meter), is busy or runnable 84–85% of the window, and finds the received-DATAGRAM queue empty on only 0.5% of its receives: the queue is almost never drained, and at 128 entries it overflows. The 1,024 queue only lets it fall further behind (19% of enqueues find 128 or more waiting) without discarding.
- **Slice B cuts the application's work per Datagram by 64%** (681 → 243 ns, A; 676 → 257, own), the receiver's instructions per Datagram by 23% and its demand fills from DRAM by 56% (12.4 → 5.5), because the second copy into cold memory is gone. The application then spends half the window runnable rather than running (46%): the run loop wakes it, and it waits for a processor, the pattern #1834 found on the sender's feed (**inferred**).
- **Coalescing halves the receiver's reader** (843 → 354 ns per Datagram, its system-call share 0.40 → 0.10) and takes about 2,300 cycles per Datagram off the sender (11,315 → 9,003), the segmentation softirq the receiver no longer needs. The fork's packet writer `emit` then spends 0.25 of the window in `sendmsg` instead of 0.66. On A that freed time does not become rate: A's application goroutine is runnable 52–60% of the window with coalescing (46–49% without), the sender's processors are idler (2.1–2.2 CPUs idle against 1.6–1.9), and the run loop finds nothing to send 30–31% of the window against 25–27%. That is #1829's and #1834's "idler processors, longer hand-offs" pattern, and it is why coalescing costs A 2.2% on top of the queue and slice B. own's feed has slack (its application is blocked 61–69% of the window waiting for room), so own keeps the gain.
- **With all three levers the run loops are the busiest stages on both peers.** The receiver's run loop runs 57–69% of the window and is runnable another 15–16%, at 612–641 ns per Datagram; the sender's runs 61–68% and is runnable 18%, at 604–687 ns. Neither is saturated. On own the carrier's sender goroutine (`pumpN`) is runnable 64% of the window and `emit` 40%: each is woken by another goroutine (`pumpN` by the application and by the run loop, `emit` by the run loop) and waits 4.4 and 19 µs per wake-up while 2.5 of the sender's 4 CPUs are idle, the pattern #1834 traced to Go running a woken goroutine in its waker's processor slot (**inferred** here; the run queues are not traced). On A the application goroutine is runnable 60% and running 32%.

## 5. The congestion response: probe x

Two probe knobs, in further copies of the fork that are otherwise the campaigns' copies, measure what the congestion response costs. Neither is a proposal. `-unproc 1024` raises the connection's unprocessed-packet queue from 256 to 1,024 packets, and `-nocut` makes the congestion controller (`cubicSender` in Reno mode) count each loss event but keep its window. They rotated as arms in three more campaigns of 18 arms each (`REPS=3 WARMUP=1 SECS=10`): X1 (2026-10-15 19:46–20:11Z), X2 (20:11–20:50Z) and X3 (20:55–21:19Z). Other work on minimax took 1–7.5 CPUs during 34 of X2's 72 runs, including every run of A with all three levers and the deeper unprocessed queue, so X2 is reported as noisy and was repeated in full as X3. The table pools X1 and X3, which agree within 1.0% on every Datagram row; X2's medians are in the evidence.

| Sender | Receiver levers | Probe knob | Mbit/s | Spread | Change | Offered Mbit/s | Offer change | Loss | Unprocessed-packet drops per run | Cutbacks per window | Mean congestion window KiB | Congestion-limited | Run loop finds nothing to send | Sender run loop busy | Receiver run loop busy | Sender CPUs idle |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| base | plain | — | 5,508 | 5,483..5,536 | — | 5,524 | — | 0.29% | 534 | 5 | 340 | 0.00 | 0.65 | 0.42 | 0.39 | 2.02 |
| A | plain | — | 8,925 | 8,851..9,048 | — | 9,411 | — | 5.29% | 4,036 | 82 | 340 | 0.18 | 0.23 | 0.58 | 0.61 | 1.82 |
| A | plain | unprocessed queue 1,024 | 10,183 | 10,082..10,310 | +14.1% | 11,364 | +20.8% | 10.29% | 5,470 | 6 | 1,285 | 0.02 | 0.25 | 0.70 | 0.74 | 1.41 |
| A | queue + slice B | — | 10,673 | 10,541..10,779 | — | 10,677 | — | 0.03% | 3,544 | 40 | 431 | 0.09 | 0.24 | 0.65 | 0.67 | 1.55 |
| A | queue + slice B | unprocessed queue 1,024 | 11,549 | 11,455..11,592 | +8.2% | 11,557 | +8.2% | 0.05% | 5,185 | 6 | 1,574 | 0.01 | 0.24 | 0.71 | 0.73 | 1.38 |
| A | all three | — | 10,274 | 10,184..10,372 | — | 10,276 | — | 0.02% | 1,864 | 64 | 324 | 0.13 | 0.27 | 0.64 | 0.63 | 2.15 |
| A | all three | unprocessed queue 1,024 | 11,855 | 11,673..11,939 | +15.4% | 11,859 | +15.4% | 0.01% | 760 | 4 | 1,185 | 0.00 | 0.30 | 0.73 | 0.73 | 1.89 |
| A | all three | no cutback | 11,904 | 11,822..12,007 | +15.9% | 12,011 | +16.9% | 0.85% | 107,638 | 852 | 3,896 | 0.00 | 0.29 | 0.74 | 0.74 | 1.89 |
| own | plain | — | 8,785 | 8,622..9,076 | — | 9,238 | — | 4.93% | 2,562 | 72 | 305 | 0.14 | 0.32 | 0.57 | 0.60 | 2.32 |
| own | plain | unprocessed queue 1,024 | 10,138 | 10,049..10,380 | +15.4% | 11,297 | +22.3% | 10.17% | 1,484 | 4 | 1,097 | 0.02 | 0.31 | 0.69 | 0.73 | 2.00 |
| own | all three | — | 11,008 | 10,834..11,049 | — | 11,008 | — | 0.01% | 762 | 46 | 312 | 0.06 | 0.30 | 0.67 | 0.68 | 2.51 |
| own | all three | unprocessed queue 1,024 | 11,691 | 11,527..11,814 | +6.2% | 11,692 | +6.2% | 0.01% | 517 | 3 | 1,087 | 0.00 | 0.31 | 0.70 | 0.73 | 2.42 |
| own | all three | no cutback | 11,571 | 11,344..11,620 | +5.1% | 11,653 | +5.9% | 0.69% | 83,939 | 530 | 3,946 | 0.00 | 0.31 | 0.71 | 0.72 | 2.42 |

"Change" is against the same sender and receiver levers without the knob. The probe builds' anchors agree with the main campaigns: A with all three 10,274 against 10,188, own 11,008 against 10,878, base 5,508 against 5,473.

- **The congestion response to those drops is what holds the offer.** With a plain receiver, the deeper unprocessed queue takes the sender's cutbacks from 72–82 to 4–6 per window and lifts its offer by 21–22% (9,411 → 11,364 and 9,238 → 11,297), its congestion window from about 300–340 KiB to 1.1–1.3 MiB. Delivery then rises only 14–15%, because the 128-entry received-DATAGRAM queue now discards 10% instead of 5%.
- **On the expected receiver it is worth 15.4% to A and 6.2% to own**, to 11,855 and 11,691 Mbit/s with loss at 0.01%. The cutbacks fall to 3–4 per window, and the congestion-limited share to zero. A and own are then within 1.4% of each other: on the expected receiver, most of what separates them is that A's sender takes more cutbacks (64 against 46 per window; its receiver drops 1,864 packets per run against 762, **measured**, cause not separated).
- **Ignoring the losses gets no further and keeps them.** With the congestion controller keeping its window, the rates are the same within 1–2% (11,904 and 11,571), but the window grows to about 3.9 MiB and the receiver's unprocessed queue drops 84,000–108,000 packets a run (loss 0.7–0.85%). So the response itself is not excess: the excess is the drops, and a deeper queue removes them without the loss. With the deeper queue the drop bursts in the window disappear: 0 in the middle 3 seconds of all four traced runs, against 3–20 at 256 (section 3's traces).
- **The deeper queue costs about one millisecond of queueing in the worst case** (1,024 packets at about 1.2 million a second, **derived**). The smoothed RTT the sender saw at the end of each run was 62–188 µs with all three levers and the deeper queue (78–82 µs median, against 80–93 at 256), but 141–586 µs with the queue and slice B or a plain receiver, where the deeper queue fills more. The receiver's memory for it is at most about 1.5 MB per connection while its run loop lags (**derived**: 1,024 packets of up to 1,452 bytes).

## 6. Default GC and a pointer-bearing receiver heap

| Sender | Heap | Receiver | Mbit/s | Spread | Change against the pin, same receiver | Offered Mbit/s | Loss | Received-DATAGRAM discards per run | Sender cutbacks per window | Receiver GC CPU (CPUs) | Receiver GC cycles/s | Receiver CPU |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | Go default | plain | 6,503 | 6,403..6,543 | −25.5% | 6,850 | 5.03% | 359,112 | 92 | 0.420 | 1,106 | 2.79 |
| A | Go default | all three | 7,945 | 7,486..7,999 | −22.0% | 7,946 | 0.01% | 0 | 75 | 0.267 | 627 | 1.50 |
| A | pin, receiver pointer-bearing | plain | 7,073 | 7,040..7,134 | −19.0% | 7,651 | 7.53% | 601,840 | 116 | 0.551 | 35 | 3.17 |
| A | pin, receiver pointer-bearing | all three | 9,330 | 9,197..9,429 | −8.4% | 9,333 | 0.02% | 0 | 95 | 0.330 | 21 | 1.66 |
| own | Go default | plain | 7,058 | 6,971..7,081 | −19.0% | 7,591 | 6.97% | 546,182 | 122 | 0.443 | 1,171 | 2.79 |
| own | Go default | all three | 9,613 | 9,476..9,668 | −11.6% | 9,614 | 0.02% | 461 | 92 | 0.327 | 738 | 1.46 |
| own | pin, receiver pointer-bearing | plain | 7,250 | 7,141..7,359 | −16.8% | 7,829 | 7.20% | 590,532 | 96 | 0.553 | 35 | 3.17 |
| own | pin, receiver pointer-bearing | all three | 10,070 | 10,033..10,164 | −7.4% | 10,072 | 0.01% | 0 | 82 | 0.359 | 23 | 1.65 |

- **At Go's default the levers gain more and land lower.** All three add 22.2% (A) and 36.2% (own) over the plain receiver at the default (**derived**), against 16.7% and 24.9% at the pin, because slice B also halves the receiver's collections at the 4 MiB floor (1,106 → 627 a second). Delivered rates are still 22% (A) and 12% (own) below the pin. That part is GC a consumer would not see.
- **A pointer-bearing receiver heap costs the plain receiver 17–19% and the expected receiver 7–8%.** With a plain receiver it loses 7.2–7.5% (about 600,000 discards per run, against 460,000–500,000 at the pin), and its marking takes 0.55 CPUs. With all three levers the loss is gone (0.01–0.02%, no discards), but the run is 7.4–8.4% slower: marking still takes 0.33–0.36 CPUs, and the sender takes 82–95 cutbacks per window instead of 42–54. In the occupancy runs the 1,024 queue reached its limit (deepest 1,023) with 4.1% of enqueues finding 128 or more waiting, so it held, with little to spare.

## 7. What bounds the pair next, and by how much

| Sender | Receiver | Delivered Mbit/s | Offered Mbit/s | What holds delivery | What holds the offer |
| --- | --- | --- | --- | --- | --- |
| A | plain | 8,731 | 9,209 | The receiver's application: the 128-entry received-DATAGRAM queue discards 5.2% | NewReno's cutbacks (90 per window) on the receiver's unprocessed-packet drops, nearly all while its run loop waits for a processor |
| A | all three | 10,188 | 10,189 | The offer | NewReno's cutbacks (54–64 per window) on the same drops, now mostly during the receiver's GC mark phases: worth 15.4% |
| A | all three, unprocessed queue 1,024 (probe) | 11,855 | 11,859 | The offer | No saturated stage: both run loops 73% busy, the sender's finds nothing to send 30% of the window |
| own | plain | 8,712 | 9,147 | As A (4.8%) | As A (70 cutbacks per window) |
| own | all three | 10,878 | 10,879 | The offer | As A (42–46 cutbacks per window): worth 6.2% |
| own | all three, unprocessed queue 1,024 (probe) | 11,691 | 11,692 | The offer | The run loops: in traces the sender's is running 75% and runnable 18% of the window, the receiver's 75% and 13%, about 600 ns per Datagram each |

(Rates from sections 2 and 5; the probe rows are from X1 and X3, the others from C1 and C2. Traced shares from the probe's own-sender traces at its rate, 1.24 million Datagrams a second.)

- **The fork's sending stages are not what bounds the pair after slice A; the receiver is.** For delivery it is the receiver's application, which cannot drain the received-DATAGRAM queue at slice A's rate (section 4). For the offer it is the receiver's run loop, through the sender's congestion controller: whenever the run loop goes about 240 µs without running, the 256-packet unprocessed queue in front of it drops a burst of packets, and NewReno cuts its window (sections 3 and 5). The sender's congestion window is the mechanism, but the receiver sets it. With a plain receiver the sender's run loop is busy 56–57%, its packet writer 69–74%, and 1.9–2.3 of its 4 CPUs are idle.
- **Each receiver lever loosens a different part of that.** The 1,024 queue removes the discards and nothing else. Slice B shortens the application's work by two-thirds, which cuts the discards from 5.2% to 1.6% and removes about half of the run loop's long waits. Coalescing halves the reader's work and the drops in each burst, and removes the segmentation softirq from the sender's processors, which own turns into rate and A does not.
- **With all three, the remaining bound is still the congestion response, worth 15.4% to A and 6.2% to own** (probe x), and the stalls behind it are now mostly the receiver's GC mark phases (61–69% of bursts start inside one), each about 0.5 ms against the queue's 240 µs. A deeper unprocessed queue removes them; so, presumably, would a receiver that marks less often or more briefly (**inferred**; not measured).
- **Behind that, at about 11.7–11.9 Gbit/s** (about 1.23–1.24 million Datagrams a second, **derived**), **the next bound is the two run loops and the hand-offs around them.** On own, the sender's run loop is busy or runnable 93% of the window and the receiver's 88%; each spends about 600 ns per Datagram running; the carrier's sender and `emit` are runnable 68% and 44%, woken by another goroutine and waiting for a processor while 2.4 of the sender's CPUs are idle. If the sender's run loop ran all the time at that cost it would carry about 1.67 million Datagrams a second (15.9 Gbit/s, +34%), an upper bound, not a forecast (**derived**). A reaches the same rate as own once the cutbacks are gone (11,855 against 11,691), so the ownership APIs' rate value on this pair is through fewer cutbacks, and their CPU value (1.22 against 1.58 sender CPU-s/GiB) remains.

## What this means for the map

1. **(input, [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825))** With slice A and the expected receiver (the 1,024 queue, slice B and coalescing), the GSO pair delivers 10.2 Gbit/s (A) and 10.9 (A plus the ownership APIs) at the pin in this cell, with 0.01–0.02% loss, none of it after acknowledgment: every lost packet is one congestion control saw. That answers the ticket's concern about loss above the receiver's socket, provided the queue is in: without it, slice B's pair still loses 1.6–2.7%. Against #1834's stock sender at the pin (3.6–3.8 Gbit/s, other campaigns, its receiver levers unmeasured), that is about 2.7–3.0 times (**derived**). The receive levers are worth +17% (A) and +25% (own) on top of slice A, so the GSO decision's value is slice A plus these, and its gate should run with them.
2. **(input, [Which per-Datagram cost reductions should native Datagrams adopt?](https://github.com/GridSwarm/wiremux/issues/1826))** Slice B is the largest receive-side lever on the GSO pair at the pin: +16–18% alone, the only lever that raises the sender's offer on its own, and −22% receiver CPU. Its rig A/B gate should include the GSO sender with slice A at the pin. On the stock sender it is not measured here. The approximation drops the copy for every carrier and compares contexts with `!=`; the adopted slice must keep the native-carrier marker and handle non-comparable contexts.
3. **(input, [How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828))** 1,024 removes the faster sender's after-acknowledgment loss in every combination (5% → 0.01–0.09%), but alone it only lets delivery reach the offer (+3–4%). How much of it is used depends on the receive path: with today's receive, 14–19% of enqueues find 128 or more waiting and the queue reaches 1,023; with all three levers, 2.4–3.1% and a deepest of 479–1,023; with all three and a pointer-bearing receiver heap, 4.1% and 1,023. So the decided depth holds on this pair with slice B and coalescing, and is at its edge without slice B or under a pointer-heavy consumer heap; the discard counter is what will show a consumer crossing it.
4. **(input, [Should native receives adopt coalescing once the fork copies coalesced datagrams at read time?](https://github.com/GridSwarm/wiremux/issues/1835))** On the GSO pair with slice A at the pin, coalescing is +5.1% (A) and +13.8% (own) alone, cuts receiver CPU 21–23%, and on the expected receiver is +4.6% for own and −2.2% for A. Its gate's "receiver CPU at least 20% lower" holds here; a gate on slice A's GSO sender without the ownership APIs should expect a small cost once slice B is in.
5. **(input, [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801))** Linux Datagram rates at a consumer-sized heap in this shape cell: the GSO probe sender with slice A and the expected receiver 10.2 Gbit/s, with the ownership APIs 10.9; with a 1,024-packet unprocessed queue (a probe) 11.7–11.9; at Go's default GC 7.9 and 9.6. Behind them the fork's run loops on both peers are 70–75% busy at about 600 ns per Datagram each.
6. **(input, the held fork ownership APIs, which wait on the GSO decision)** On the expected receiver they add 6.8% and cut sender CPU 23% (1.62 → 1.25 CPU-s/GiB). That clears the throughput test of their adoption rule (a gain beyond noise over the wiremux-only send slice); the CPU saving, 0.37 CPU-s/GiB, sits just under the rule's 0.4 line (**derived**). Their rate value comes through fewer congestion cutbacks: with the deeper unprocessed queue, A and own are within 1.4%, while the CPU saving stays (1.58 against 1.22).
7. **(note for [Why do slice A and the fork's ownership APIs cost the stock Datagram sender 3–5% at a consumer-sized heap?](https://github.com/GridSwarm/wiremux/issues/1845))** Nothing here measures the stock sender. The receiver traces show the same pattern #1834 saw on the sender, now on the receiver's run loop: a goroutine woken by another waits a median 220–226 µs for a processor at each loss burst while 1.8 of the receiver's CPUs are idle. If that ticket separates scheduler wake-up latency on idle processors, the same separation applies here.
8. **(new question, fork; grilling) Should native connections get a deeper unprocessed-packet queue than the fork's 256 packets?** At slice A's GSO rate 256 packets are about 240 µs of arrivals, so any longer stall of the receiver's run loop, a processor wait or a GC mark phase, drops a burst of real packets and the sender backs off. A 1,024-packet queue (probe) is worth +21–22% offered with today's receiver and +6–15% delivered with the expected one, for at most about 1 ms of queueing and 1.5 MB per lagging connection. Upstream quic-go has the same 256. It needs an owner's call on memory and latency per connection, whether it applies to every connection or native ones only, and whether the fork should count those drops for wiremux the way #1828's discards are counted.
9. **(new question, research) What holds both run loops at about 600 ns per Datagram once the congestion response is gone?** At about 1.24 million Datagrams a second neither peer's run loop is CPU-saturated (75% running), but each is runnable 13–18% and the goroutines around the sender's are runnable 44–68%. Whether that is per-packet work in the run loop or the hand-offs, and what a batch hand-off or a cheaper per-packet path would buy, is the next bound's question. It only matters once the unprocessed-queue question is decided.
10. **(fog)** Whether a consumer's receiver, whose heap is larger and partly pointer-bearing, marks often and long enough to make GC the dominant cause of loss bursts at these rates; the pointer-ballast arm says it can (8 ms marks, 98% of bursts), but how a real GridCast receiver marks is unmeasured.

## Evidence

All runs are in the rig's `netns` cell: namespaces `nr-send` and `nr-recv` on minimax (Ubuntu 26.04, Linux `7.0.0-30-generic`, Ryzen AI MAX+ 395), joined by `veth` at MTU 1500, veth GRO off (the default) throughout and recorded per run, sender pinned to CPUs 4–7 and receiver to 12–15 (`GOMAXPROCS` 4 each). It is a shape cell: no real NIC, both peers on one host, and the receive path's softirq runs on the sender's CPUs, so a receiver-side saving such as coalescing shows partly as sender CPU and can raise the sender's offer (the "sender CPUs in softirq" column separates it). Its absolute numbers are not Linux numbers.

- **Builds** (throwaway, never pushed): three probe worktrees from #1834's probe commits (`base` 9a949cf1, `A` f8f8aa3c, `own` 458f9377), each with the same added commits. The first adds slice B's approximation behind `-r1844b` (#1823's `r1-nocopy.diff` and `r2-ctxcache.diff`, which applied cleanly to all three with offsets only, then wrapped in a package flag so that with it off the receive path is today's), the fork's received-DATAGRAM queue depth behind `-rq`, the received-queue occupancy counters, `-ptr-role`, and modfiles for the #1844 fork copies; the second reports the queue depth gauges correctly (before the campaigns). The third, committed after C2 had built, adds the probe-x knobs `-unproc` and `-nocut`, built only by the X campaigns and the drop-burst traces. Fork copies: #1834's `qgf-1834b` (the equal-size Datagram GSO probe sender with #1829's fix knobs and #1834's counters) and `qgf-1834b-own`, each with the queue-depth variable and the received-queue counters; the probe-x copies add the unprocessed-queue variable, the no-cutback switch, a drop-burst counter and a trace log at each burst's start. #1829's and #1834's copies were not modified. The rig branch was not changed: the driver is #1834's `rig1834.sh`, unchanged, which builds the three variants once per campaign and rotates them with the arms; the slate arms run on `base`.
- **Campaigns** (each `REPS=3 WARMUP=1 SECS=10`; standard slate plus the ticket's arms; pooled medians over the six non-warm-up runs of each pair): C1 (2026-10-15 16:08–17:06Z) and C2 (17:06–18:40Z), 30 arms each; X1 (19:46–20:11Z), X2 (20:11–20:50Z) and X3 (20:55–21:19Z), 18 arms each. Every run first waited until minimax had no other `nativerig` running and other work used at most 1.5 CPUs: 45 waits in C1 (1,050 s), 73 in C2 (2,590 s), none in X1, 13 in X2 (710 s) and 1 in X3 (10 s). Other sessions ran their own campaigns on minimax through C1, C2 and the mechanism runs, and CI jobs came and went. Runs with more than 1.0 CPU of other work during the 5-second stat window are listed per campaign in the evidence and kept: none in C1 or X1, 11 in C2 (one of them, own with slice B, is the 7,912 Mbit/s outlier), 34 of X2's 72, and 3 warm-up runs in X3. X2 is reported as noisy (more than a third of several arms' runs flagged) and was repeated in full as X3; it is not pooled. C1 and C2 agree within 1.4% on every Datagram row, X1 and X3 within 1.0%.
- **Failed runs** (kept and listed, never re-run): C1 `r2-a-b64-b` and the mechanism run `perf own-b64-all-t1` each started in the same second as another session's run (#1845's mechanism runs at 16:30:14Z, #1842's campaign at 19:20:32Z), whose receiver held the port, so this ticket's receiver could not bind and its sender timed out. A with slice B therefore has five runs in the pool.
- **Mechanism runs** (outside the campaigns; never throughput evidence), with C2's binaries, all at the pin: occupancy counters (18:40–18:50Z, two 10-second runs per case), execution traces (18:50–18:55Z, two 5-second runs per case, both peers), and hardware counters (18:55–19:46Z; `perf stat -x,` counting mode, run as root through the rig's `sudo ip netns exec`, two 10-second runs with each of #1834's two event sets). With the X builds, traces of both peers for the drop bursts (20:50–20:54Z, two 5-second sends per case; the receiver's trace spans about 10 seconds). Traced runs are 5–10% slower than untraced ones (A's sender more), and per-Datagram trace numbers are per traced Datagram.
- **Caveats:**
  - Slice B is #1823's approximation: it drops the receive copy for every carrier, compares contexts with `!=` (panics on a non-comparable context) and leaves the cached context's `AfterFunc` registered until the context changes; the rig's receiver passes one context, so the reuse always hits.
  - The 1,024-entry queue is a probe variable; the adopted slice also exposes its discard count to wiremux.
  - The pointer-bearing arm puts the pointer heap on the receiver only, unlike #1833's arms.
  - `A` is #1823's approximation of slice A, and `own`'s fork never releases a frame it discards unsent (as in #1834).
  - The probe-x knobs measure the congestion response; they are not candidate changes, and `-nocut` in particular is unsafe on any real path.
  - The link between slice B and the run loop's shorter waits, and between the waits and Go's scheduling of woken goroutines, is inferred from traces; the run queues are not traced.
  - The ballast is untouched memory, so a real consumer's heap also competes for cache and its marks are longer: the GC share of the loss bursts here is a lower bound for it.
  - The stock sender is not measured.

Directory: `/Volumes/worktrees/wiremux/native-gap-evidence/1844-gso-pair-bound/` on mbp128 (README.txt; `campaign1844.sh`, `campaignx1844.sh`, `campaignx3_1844.sh`, `mech1844.sh`, `mechx1844.sh`, `smoke1844.sh`, `busy1844.sh`; `an1844.py`, `tables1844.py`, `tablesx1844.py` → `an-*.txt`, `tables-*.md`, `runs-*.csv`; `q1844.py`, `perf1844.py`, `trace1844.sh`, `traceshares1844.py`, `tools/tracegs34`, `tools/gcdrops44` → the summaries under `mech/` and `mechx/`; `wiremux-probe-1844.diff`, `probe-x.py`, `fork-1844*.diff`; the fork copies; campaign directories C1 C2 X1 X2 X3 with every per-run result).
