# Issue #1800: where the macOS native ceiling comes from

Research for [Where does the macOS ~1 Gbit/s native ceiling actually come from?](https://github.com/GridSwarm/wiremux/issues/1800) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). It names the resource that holds native Datagrams and the native stream at about 130k packets/s on the Thunderbolt pair, says what the ceiling becomes with several sockets, larger datagrams and connected sockets, localizes the "wire" loss, and measures read-time receive-queue depth, system calls per packet, garbage collection and per-byte cost. Nothing here implements a change.

Sources are wiremux at `origin/main` [2599a002](https://github.com/GridSwarm/wiremux/tree/2599a00292c70c9871794ce62a1266741d71d42a), the quic-go-fast fork at the version the rig selects (`v0.62.1-fast.7`), Go 1.27.1, the rig `cmd/nativerig` from `codex/native-gap-rig` [d404687d](https://github.com/GridSwarm/wiremux/tree/d404687de69752a98da7ccd003755ca7140afedb/cmd/nativerig) (this ticket's additions: a `tcp` arm, receiver `-rconnect`, `-qdepth`, GC counters and per-run Thunderbolt loss counters), the xnu source closest to the hosts' kernel that Apple publishes ([xnu-12377.121.6](https://github.com/apple-oss-distributions/xnu/tree/xnu-12377.121.6); both Macs run xnu-13432.1.9), and measurements taken for this note on 2026-10-13 and 14. Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cell.** `tb` only: mbp128 (MacBook Pro M4 Max, 16 cores) sends from `bridge0` over Thunderbolt to m4mini (Mac mini M4 Pro, 12 cores), both macOS 27 arm64, MTU 1500. All runs are wiremux's unconnected, interface-bound sockets unless an arm says otherwise. Both Macs host live GARM runner VMs, and Spotlight and media-analysis daemons were busy for part of the window; the protocol's load gate and flags handle that (see [Method](#method)).

## Answer

**Native Datagrams and the native stream are held by the sender's single send goroutine, not by the receiver.** The fork sends every packet of a connection from one goroutine (the connection's send queue), one `sendmsg` system call per packet on an unconnected socket. In a Go execution trace that goroutine is busy 97.6% (Datagrams) and 99.0% (stream) of the time, and 90–91% of the time it is inside `sendmsg`, about 7.5 µs per packet on mbp128 (**measured**). The receiver has headroom: its receive goroutine is busy 68–74% and waits for the network 24–31% of the time, the receiving kernel's input thread is 61% busy, and neither Mac is short of cores. Garbage collection is not part of it: `GOGC=400` cut collections about 6× on both peers and did not raise throughput.

**The next walls are 20–40% higher, on the receiver, and the hard one is a per-datagram kernel cost of unconnected sockets.** On m4mini one kernel thread, the Thunderbolt member's input thread `dlil_input_en2`, runs the bridge, IP, UDP and socket-append work for every received frame. For an unconnected socket it spends 6.0–6.7 µs per datagram and saturates at about 160–163k packets/s (**measured**). That is the raw-UDP receive ceiling for 1, 2, 4 or 8 sockets alike, and for 1,232- and 1,452-byte payloads alike: more sockets do not raise it, because they share that thread. With the native arms' traffic it would saturate near 190k packets/s, and the receiver's receive goroutine near 160k (**derived** from their load at 119k under tracing). For a connected socket the same thread spends 1.7–1.8 µs per datagram, and the receiver carried 563k packets/s on 4 connected sockets and 610k on 8 (7.1 Gbit/s, 0.3% loss) (**measured**). xnu evaluates its network policy (NECP) afresh for every datagram on an unconnected socket and reuses a cached result on a connected one (**source**), which is the likely cause; kernel call stacks were not available without root to confirm it.

**"Wire" loss is not on the wire.** Every packet the rig counted as lost between the sender's interface and the receiver's is a receive-buffer refill the receiver's Thunderbolt driver could not make: 16 KB ("jumbo") cluster allocation failures equal the loss to within 1% in every run of every unconnected arm, usually within 0.01% (**measured**). Each received datagram is charged about 68.5 KB of buffer memory, consistent with four 16 KB clusters, so the host's 5,461-cluster jumbo pool holds only about 1,365 received frames (**derived**). When the input thread falls behind, its backlog drains the pool and the driver drops frames before `bridge0` counts them. The sender's interface queue never dropped a packet of an unconnected sender.

**Connecting raises both ceilings, independently.** A connected receiving socket lifts the receiving kernel's ceiling about 3.7× (above). A connected sending socket lifts a raw sender from 185k to 304k packets/s, and it gets `ENOBUFS` backpressure from the interface queue that an unconnected sender never sees (**measured**).

**Jumbo frames multiply the native stream about 5× and keep the same bottleneck.** At MTU 9000, with a throwaway one-constant fork change (packet ceiling 1,452 → 8,972 bytes), the native stream went from 1.33 to 6.65 Gbit/s (6.4–7.2, **measured**), inside the 4.1–7.6 Gbit/s that [How much throughput can larger packets buy the native path?](https://github.com/GridSwarm/wiremux/issues/1797) derived. The sender's send goroutine is still 99.9% busy, now about 9.6 µs per 8.9 KB `sendmsg`. Raw UDP reached 10.1 Gbit/s on one unconnected socket (sender-bound) and 13.3 Gbit/s on a connected pair. Above about 13–14.6 Gbit/s (TCP's ceiling in the same window) the Thunderbolt driver or link drops frames, and four senders offering 22–33 Gbit/s collapsed delivery to 4–8 Gbit/s. Native Datagrams don't benefit until wiremux's fixed 1,192-byte Datagram ceiling follows discovery. See [Phase 2](#phase-2-mtu-9000).

**TCP is not a like-for-like reference.** The rig's new `tcp` arm puts 129–134k frames/s of 35–36 KB through `bridge0` at 37.4 Gbit/s (Thunderbolt carries the segmentation-offload frames whole), and its limit there is the Thunderbolt driver's receive thread, 92% busy (**measured**). TCP's frame rate is about UDP's packet rate; its advantage is 25–30× more bytes per frame. In a later window the same arm ran at exactly 14.6 Gbit/s (59k frames/s of 31 KB, the map's original figure) with no thread saturated on either Mac, so the TCP reference itself depends on a link or driver state.

| What runs (tb, MTU 1500) | Delivered | What holds it | Evidence |
| --- | --- | --- | --- |
| native `dgram` (1,191-byte Datagrams) | 134.5k pkt/s, 1.28 Gbit/s | sender's send goroutine: 98% busy, 90% in `sendmsg` | Go trace; C1 |
| native `stream` | 133.9k frames/s, 1.46 Gbit/s | sender's send goroutine: 99% busy, 91% in `sendmsg` | Go trace; C1 |
| raw UDP, 1–8 unconnected sockets, 1,232 or 1,452 B | 153–163k pkt/s, 1.6–1.9 Gbit/s (a single socket is bimodal: about 115k or 160k per run) | receiver's `dlil_input_en2` kernel thread at 100%, 6.0–6.7 µs per datagram | xctrace; C1 |
| raw UDP, unconnected sender, connected receiver | 184k pkt/s, 2.1 Gbit/s, no loss | the unconnected sender (one thread, 100%) | C1, diag |
| raw UDP, 1 connected pair | 304k pkt/s, 3.5 Gbit/s, no loss | the sender's one thread (100%) | C1, xctrace |
| raw UDP, 4 / 8 connected pairs | 563k / 610k pkt/s, 6.5 / 7.1 Gbit/s | receiver's `dlil_input_en2` near saturation (89% at 488k), 1.7–1.8 µs per datagram | C1, xctrace |
| `binding` (wiremux admission, no QUIC) | 89k pkt/s, 1.04 Gbit/s, 51% loss | the binding reader: its socket holds only 92 datagrams | C1, `netstat -anv` |
| kernel TCP | 37.4 Gbit/s at 132k frames/s of 35.6 KB (C1); 14.6 Gbit/s at 59k frames/s of 31 KB (C2, phase 2) | Thunderbolt driver receive thread, 92% (C1); no thread saturated (C2) | C1, C2, xctrace |
| MTU 9000: native `stream`, fork packet ceiling 8,972 | 6.65 Gbit/s, 102k frames/s of 8.2 KB | sender's send goroutine: 99.9% busy, 93% in `sendmsg` | P2B, Go trace |
| MTU 9000: raw UDP 8,972 B, 1 unconnected / 1 connected / 4 senders | 10.1 / 13.3 / 4.4–8.0 Gbit/s | the unconnected sender / the Thunderbolt path / driver receive thread at 90–99% | P2A, xctrace |

All delivered figures are C1 medians of 5 runs (**measured**). C1 was reported noisy by the protocol's rule (two single-socket arms had 2 of 5 runs flagged) and was repeated in full as C2, which confirmed every row except TCP's absolute rate and found the sender-bound rows 5–12% lower on a busier sender ([Repeat campaign](#repeat-campaign-c2)).

## 1. The native arms: which thread saturates

Go's execution tracer records every goroutine's state, so it shows directly whether a goroutine is ever idle. One 10 s pair per arm, traced on both peers (`G/`), window 3–8 s (**measured**; tracing slows the run to 119k packets/s for Datagrams and 115k for the stream):

| Goroutine | Datagram sender | Stream sender | Datagram receiver | Stream receiver |
| --- | ---: | ---: | ---: | ---: |
| send queue (`sendQueue.Run`, the fork's one per-connection sender): busy | **97.6%** | **99.0%** | 58.5% | 55.4% |
| of which inside `sendmsg` | 89.7% | 91.4% | 53.0% | 50.2% |
| `sendmsg` calls/s | 119,338 (data) | 114,838 (data) | 37,739 (acks) | 37,907 (acks) |
| receive goroutine (`Transport.listen`): busy | 27.5% | 27.8% | 73.6% | 68.2% |
| of which inside `recvmsg` | 18.0% | 18.3% | 54.1% | 49.6% |
| receive goroutine waiting for the network | 69.7% | 71.4% | 23.9% | 30.8% |
| connection run loop (`Conn.run` / `doDial`): busy | 19.9% | 19.5% | 31.9% | 28.6% |
| application goroutine (wiremux send pump + carrier, or the receive loop) | 11.5% | 3.4% | 16.9% | 8.0% |
| GC workers | 11.4% of a core | 0.5% | 8.5% | 0.8% |

How to read it:

- A goroutine runs on one thread at a time, so 97.6–99.0% busy with no waiting is saturation. Every packet of a connection leaves through that goroutine and its `sendmsg` ([`send_queue.go` L176](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/send_queue.go#L176); macOS sends one packet per call, [`sys_conn_helper_darwin.go` L22](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/sys_conn_helper_darwin.go#L22)). It is the bottleneck for both arms.
- The per-thread view cannot show this: Go moves the goroutine between threads, so in Instruments and `ps -M` the sender's work is spread over 11–13 threads at about 10–30% each and no thread is at 100% (**measured**). Only the goroutine view finds it.
- One `sendmsg` costs about 7.5 µs on mbp128 (**derived**: 0.897 s of syscall time per s / 119,338 calls; the untraced Time Profiler recording gives 7.46–7.52 µs per packet in the `__sendmsg` leaf). A raw unconnected `sendto` from the rig's `udp` sender costs 5.4 µs and a connected `write` 3.3 µs (**derived**: one thread at 100% sending 185k and 304k packets/s). The native call carries ancillary data (packet info for the source address) on an interface-bound unconnected socket; why it costs 2 µs more than a plain `sendto` is not resolved here.
- The receiver's `sendmsg` for acknowledgments costs about 14 µs per call (**derived**: 0.530 / 37,739), twice the sender's. It shares the socket with the input thread that appends every arriving datagram; contention for the socket is the likely reason (not measured).
- The receiver has slack: its receive goroutine waits for the network a quarter to a third of the time, and the receiving kernel's input thread runs at 61% for these arms ([section 4](#4-the-receiving-kernels-per-datagram-cost)).

Untraced, the same arms run at 134k packets/s (C1). The ceiling is one goroutine doing one system call per packet at about 7.5 µs: 1/7.5 µs = 133k packets/s (**derived**).

## 2. Raw UDP: sockets, sizes and connected sockets

Headline campaign C1 (`REPS=5 SECS=10`, rotation 0 a warm-up, arm order rotating, `LOADGATE=1`), medians of 5 runs (**measured**). "Offered" is the sender's rate; "16k/s" and "rcvbuf/s" are where the lost packets went, per second of delivery.

| Arm | Sockets | Connected | Offered pkt/s | Delivered pkt/s | Mbit/s (min–max) | Loss | 16k/s | rcvbuf/s | Sender cores | Receiver cores |
| --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| `udp` | 1 | no | 185,487 | 153,073 | 1,778 (1,330–1,897) | 16.6% | 23,178 | 7,370 | 1.01 | 1.39 |
| `udp2` | 2 | no | 259,316 | 159,068 | 1,848 (1,839–1,871) | 38.9% | 100,775 | 0 | 2.03 | 1.05 |
| `udp4` | 4 | no | 278,794 | 162,578 | 1,889 (1,868–1,920) | 42.3% | 117,747 | 0 | 4.04 | 0.79 |
| `udp8` | 8 | no | 331,138 | 162,156 | 1,884 (1,847–1,967) | 51.0% | 168,259 | 0 | 8.08 | 0.82 |
| `udp1232` | 1 | no | 194,581 | 113,169 | 1,115 (1,083–1,560) † | 40.0% | 47,623 | 27,918 | 1.01 | 1.56 |
| `udp4-1232` | 4 | no | 271,121 | 160,932 | 1,586 (1,580–1,613) | 40.8% | 110,604 | 0 | 4.05 | 0.81 |
| `udpc` | 1 | sender | 305,833 | 114,720 | 1,333 (1,276–1,973) † | 61.8% | 159,719 | 26,104 | 1.02 | 1.57 |
| `udpr` | 1 | receiver | 183,956 | 183,963 | 2,137 (2,131–2,160) | 0 | 0 | 0 | 1.01 | 0.40 |
| `udpcr` | 1 | both | 304,016 | 304,035 | 3,532 (3,417–3,564) | 0 | 0 | 0 | 1.01 | 0.46 |
| `udp4cr` | 4 | both | 618,563 | 562,978 | 6,540 (5,691–7,019) | 9.0% | 53,672 | 0 | 4.04 | 2.64 |
| `udp8cr` | 8 | both | 611,915 | 610,046 | 7,086 (5,721–7,226) | 0.3% | 674 | 0 | 8.02 | 5.42 |

† Two of five runs flagged (rate 1.34–1.48× the median): the single unconnected socket is bimodal, delivering either about 113–120k or about 150–165k packets/s from run to run, with no matching load difference. With more than a third of an arm flagged, the protocol marks C1 noisy and requires a full repeat (C2, below).

What it shows:

- **Several unconnected sockets don't raise the receive ceiling.** 1, 2, 4 and 8 sockets deliver 153k, 159k, 163k and 162k packets/s. With 4 and 8 sockets the receiving process is nearly idle (0.8 cores; each reader 6–13% busy, and its socket is empty in 82–91% of samples) while 42–51% of the offered packets are lost. The limit sits below the sockets, in one kernel thread ([section 4](#4-the-receiving-kernels-per-datagram-cost)).
- **The ceiling is packets, not bytes.** With 4 sockets, 1,232-byte payloads deliver 160.9k packets/s and 1,452-byte payloads 162.6k, so bytes scale with size (1,586 against 1,889 Mbit/s). The single-socket `udp1232` median is low only because its runs fell in the slow mode.
- **Connecting the receiving socket lifts the receiver; connecting the sending socket lifts the sender.** `udpc` (connected sender) offers 306k but the unconnected receiver still delivers only 115k. `udpr` (connected receiver) delivers everything an unconnected sender offers (184k). `udpcr` delivers 304k, which is the connected sender's one thread at 100%. With 4 and 8 connected pairs the receiver carries 563k and 610k packets/s on 2.6 and 5.4 cores.
- **A connected sender gets backpressure.** In `udp4cr` and `udp8cr` the sender's member queue raised flow control (18 events in one `udp8cr` run) and up to 23,748 sends per run failed with `ENOBUFS`; no unconnected arm ever saw either (**measured**). xnu enables flow advisory only on connected UDP sockets (**source**: [`udp_usrreq.c` L1688](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L1688)).

## 3. Where the "wire" loss happens

The rig's `wire` column is sender `bridge0` out minus receiver `bridge0` in. This ticket added three counters to every `tb` run (rig `d404687d`): the bridge members' output queues on both peers (`netstat -I MEMBER -qq`; the Thunderbolt members `en1`–`en4` keep no `netstat -I` packet counts), byte counters (`netstat -I bridge0 -b`) and the mbuf allocator's per-class failures (`netstat -mmm`). In C1 (medians per run, **measured**):

| Arm | Sender member queue drops | Lost after the sender's member queue | Receiver 16 KB refill failures |
| --- | ---: | ---: | ---: |
| `udp` | 0 | 231,858 | 231,854 |
| `udp4` | 0 | 1,178,503 | 1,178,496 |
| `udp8` | 0 | 1,684,810 | 1,684,448 |
| `udp4cr` | 0 | 551,421 | 536,746 |
| `udp8cr` | 195 | 19,274 | 6,744 |
| `binding` | 0 | 17,759 | 17,743 |
| `dgram` | 0 | 18 | 0 |

- Only one member carries the traffic each way (mbp128 `en3`, m4mini `en2`). The sender's queue (FQ_CODEL, 2,048 packets) dequeued every packet of every unconnected arm.
- Every packet lost after it is a failed allocation of a 16 KB cluster on the receiver (`mbuf_16kcl` failures): per run the two agree to within 0.72% for every unconnected arm, and to within 0.01% in most runs. The Thunderbolt driver refills its receive ring with these clusters, and a frame it cannot refill for is dropped before `bridge0` counts it. For the connected 8-pair arm, whose loss is small, up to two thirds of it is elsewhere (the sender's member queue, or drops these counters don't separate).

**Why the pool runs dry.** Two independent socket buffers fix the memory each received datagram is charged (**derived**, **source**):

- xnu lets a socket buffer hold up to 8× its high-water mark of mbuf storage (`sb_mbmax = cc * sb_efficiency`, [`uipc_socket2.c` L819](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket2.c#L819), [L146](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket2.c#L146)).
- The raw `udp` socket (`rhiwat` 7,340,032, `netstat -anv`) never held more than 856 datagrams (`-qdepth` maximum in every run): 8 × 7,340,032 / 856 = 68,599 bytes per datagram.
- A binding socket keeps the default buffer (`rhiwat` 786,896) and never held more than 92 datagrams (`Recv-Q` 138,736 bytes / 1,508): 8 × 786,896 / 92 = 68,425 bytes per datagram.
- So each received 1,494-byte frame is charged about 68.5 KB, about four 16 KB clusters (4 × 16,896 = 67,584) plus small mbufs. The Thunderbolt link carries frames up to 64 KB (`IOMaxPacketSize` 65,536), and the driver appears to receive every frame into a 64 KB chain.
- The jumbo pool is a third of the cluster memory: `njcl = nmbclusters / 3` ([`uipc_mbuf.c` L1107](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_mbuf.c#L1107), [L1211](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_mbuf.c#L1211)). With `kern.ipc.nmbclusters` 131,072 that is 5,461 clusters, and `netstat -mmm` shows the pool pinned at 5,462 during every lossy run (**measured**). About 5,461 / 4 ≈ 1,365 received frames can be buffered anywhere on the host at once (**derived**).
- The input thread's own queue may hold 8,192 packets for an interface without receive polling (the default [`dlil_sysctl.c` L128-L130](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/dlil_sysctl.c#L128-L130), applied at [`dlil_input.c` L150-L165](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/dlil_input.c#L150-L165)), so when the input thread is the bottleneck the pool empties long before that queue fills. That is why `udp4` and `udp8` lose 1.2–1.7M packets per run with empty sockets and no socket-buffer drops.

So a deep socket buffer is an illusion on this cell: 7 MiB holds 856 datagrams, and a host-wide backlog of about 1,365 frames turns into driver drops. m4mini had logged 23.4M such 16 KB allocation failures since boot when this ticket started (`netstat -mmm`).

## 4. The receiving kernel's per-datagram cost

One system-wide Instruments Time Profiler recording per Mac per arm, recorded separately on each host during a hand-run pair (`X/`, window 6–12 s, **measured**). The Time Profiler template records kernel threads' on-CPU time but not their call stacks (System Trace and CPU Profiler did not either, `K/`), so the attribution is by thread.

| Arm (rate during the recording) | Receiver frames/s | `dlil_input_en2` busy | µs per frame | Thunderbolt receive thread | Sender `ifnet_start_en3` (transmit) |
| --- | ---: | ---: | ---: | ---: | ---: |
| `udp`, 1 unconnected socket | 148,468 / 150,702 | **100.0% / 99.9%** | 6.74 / 6.63 | 39.3% / 36.1% | – / 61.4% |
| `udp4`, 4 unconnected sockets | 163,515 / 163,231 | **100.0% / 100.0%** | 6.12 / 6.13 | 54.4% / 61.7% | – / 63.3% |
| `binding` (unconnected) | 163,955 | **98.8%** | 6.03 | 32.2% | 62.4% |
| `dgram` (native, unconnected) | 119,206 | 61.5% | 5.16 | 38.8% | 49.8% |
| `stream` (native, unconnected) | 116,937 | 60.8% | 5.20 | 38.9% | – |
| `udpcr`, 1 connected pair | 290,531 | 50.2% | 1.73 | 56.0% | 81.1% |
| `udp4cr`, 4 connected pairs | 488,060 | 89.4% | 1.83 | 65.5% | 96.0% |
| `tcp` | 130,991 | 50.9% | 3.89 | **92.2%** | 66.8% |

- The `udp` and `udp4` rows give two recordings each (`X/` and `X2/`; the first pair lost the sender's recording, see the README). The unconnected raw sender's one thread is at 99.5% in both.
- `dlil_input_en2` is the DLIL input thread of m4mini's Thunderbolt member. The bridge hands each received frame up inline (`dlil_input_packet_list`, [`if_bridge.c` L6010](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/if_bridge.c#L6010)), so that one thread runs bridge input, IP, UDP and the socket append for every frame of every socket. It runs on a performance core throughout.
- For unconnected sockets it costs 6.0–6.7 µs per datagram at saturation, so the receiver tops out near 150–165k packets/s (**derived**: 1 / 6.12 µs = 163k). For connected sockets it costs 1.7–1.8 µs, a 3.4–3.9× difference (**derived**), and it would saturate near 550k packets/s (**derived**: 0.894 / 488k → 1.83 µs; C1's 8-pair arm reached 610k because the cost per frame falls further as batches grow).
- The native arms' sockets are unconnected too: at 119k frames/s the input thread is 61% busy, so it would saturate near 190k (**derived**: 119,206 / 0.615).
- **Why unconnected costs more (source).** In `udp_input`, every datagram goes through `necp_socket_is_allowed_to_send_recv_v4` ([`udp_usrreq.c` L846](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L846)). For a connected socket that function reuses the socket's last policy result ([`necp.c` L12932](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/necp.c#L12932)). For an unconnected one it rebuilds the socket's policy information and a flow hash under the policy lock on every datagram ([L12991-L12998](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/net/necp.c#L12991-L12998)); m4mini has 998 socket policies installed (`net.necp.socket_policy_count`). Unconnected datagram sockets also get per-datagram flow tracking (`SOFLOW_ENABLED`, [L862](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/netinet/udp_usrreq.c#L862)). On the reading side, xnu drops and retakes the socket lock to run a MAC policy check on every datagram it hands to an unconnected socket ([`uipc_socket.c` L2832-L2909](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket.c#L2832-L2909)). Which of these dominates was not measured: kernel stacks need root here.
- TCP is bound elsewhere: the Thunderbolt driver's receive thread is 92% busy at 37.4 Gbit/s, while the input thread runs at 51%.

## 5. TCP frames through `bridge0`

The map's TCP reference was 14.6 Gbit/s from an earlier tool; the rig's own `tcp` arm (one connection, 256 KiB writes, autotuned buffers) gave 37.4 Gbit/s in C1 (median 37,383, range 37,149–37,538) and exactly 14.6 Gbit/s in C2 (14,580–14,590) (**measured**; see [Repeat campaign](#repeat-campaign-c2)). Per C1 run:

| Counter | Value |
| --- | --- |
| frames/s leaving mbp128 on `en3` (the only busy member) | 129,295–133,865 |
| bytes per frame on `en3` | 34,913–36,273 |
| frames/s into m4mini's `bridge0` | the same (129,295–133,864) |
| acknowledgment frames/s from m4mini on `en2` | 64,981–69,387, 66 bytes each |
| system calls per frame | sender 0.67, receiver 1.32 (`top`, diag pair) |

So Thunderbolt carries TCP's segmentation-offload frames whole (the members' MTU limit is 65,518), at about 25 MSS per frame. TCP needs only about 132k frames/s for 37 Gbit/s, which is the same packet rate the native path reaches; its frames are 25–30× larger. Of the two outcomes [What are the real UDP ceilings per platform, and what do other QUIC stacks reach?](https://github.com/GridSwarm/wiremux/issues/1796) set out, the MTU-sized one (about 1.26M frames/s, which would have shown the link carrying 8× UDP's packet rate) does not hold. The segmentation-offload one does, at a higher rate than it estimated: frames average 35.6 KB, and at 37.4 Gbit/s that is 132k frames/s rather than the 20k/s it derived from 14.6 Gbit/s. The TCP comparison is not like for like, and [section 2](#2-raw-udp-sockets-sizes-and-connected-sockets) shows separately that the link and input path carry at least 610k frames/s.

## 6. Read-time receive-queue depth

`-qdepth` reads `SO_NUMRCVPKT` immediately before a read. xnu answers it by walking the queued datagrams under the socket lock ([`uipc_socket.c` L5947](https://github.com/apple-oss-distributions/xnu/blob/xnu-12377.121.6/bsd/kern/uipc_socket.c#L5947)), so sampling every read slows a deep-queued reader: `udpq` (every read) delivered 49.5k packets/s against `udp`'s 153k. `-qevery 64` (one sample per 64 reads) did not slow it (`udpq64` 138.5k, within `udp`'s bimodal range). For the native arms a throwaway probe added the same sample before every read inside the binding (`-nqdepth`, reads sit inside wiremux). Time-sampled `Recv-Q` (`netstat -an -p udp` about every 20 ms on m4mini, the active IPv4 socket only) is the non-invasive cross-check. **Measured**:

| Arm | Method | Median (datagrams) | Mean | p90 | Share empty |
| --- | --- | ---: | ---: | ---: | ---: |
| `udp`, 1 socket | read-time, every 64th read (C1, 5 runs) | 178–780 | 233–774 | 594–856 | 0.0–0.1% |
| `udp`, 1 socket | read-time, every 64th read (diag pair) | 93 | 108 | 203 | 0.1% |
| `udp`, 1 socket | `Recv-Q` time samples, same pair | 92 | 113 | – | 5.6% |
| `udp`, 1 socket | read-time, every read (C1; perturbed, rate ÷3) | 832–843 | 817–825 | 856 | 0% |
| `udp4` / `udp8` | `Recv-Q` time samples | 0 / 0 | 0.18 / 0.09 | – | 82% / 91% |
| `udpcr` / `udp4cr` / `udp8cr` | `Recv-Q` time samples | 0 / 1 / 1 | 1.2 / 1.3 / 1.8 | – | 57% / 38% / 30% |
| `binding` | `Recv-Q` time samples | 91 | 85 | – | 0% (at its 92-datagram limit) |
| native `dgram` | read-time, every 64th binding read | **3** | **14.2** | 32 | **16%** |
| native `dgram` | `Recv-Q` time samples, same pair | 2.0 | 9.5 | – | 23% |
| native `stream` | read-time, every 64th binding read | **2** | **11.3** | 20 | **21%** |
| native `stream` | `Recv-Q` time samples, same pair | 2.1 | 5.0 | – | 29% |

- Time-sampled `Recv-Q` counts bytes; datagrams = bytes / bytes per queued datagram (payload + 16-byte address, plus about 40 bytes of control messages on binding and native sockets; **derived**). Where both methods ran on the same pair they agree (`udp` median 93 against 92).
- The single unconnected raw socket is deep (the reader is the slower stage in that arm), and its depth flips with the same bimodal behaviour as its rate. With 4 or 8 sockets the sockets are empty and the backlog sits in the kernel input thread's queue instead.
- The native receive queue is shallow: median 2–3 datagrams, mean 11–14 because of bursts (p99 138–152, maximum 728–846), empty at 16–21% of reads (**measured**). The perturbing every-read probe halved native throughput and is not used.

## 7. System calls per packet

xctrace System Trace attached to each peer's process for about 1.4 s mid-transfer (`S/`, `S2/`); packets are the process's own successful data calls in its window, so the ratios hold even though tracing slows the run (**measured**):

| Peer | Calls per packet | Breakdown per packet |
| --- | ---: | --- |
| native `dgram` sender | 3.26 | `sendmsg` 1.00; `recvmsg` 0.55 (43% `EAGAIN`; acks); `kevent` 0.45; `psynch_cvwait` 0.45; `psynch_cvsignal` 0.45; `semwait_signal` 0.22; `madvise` 0.10 |
| native `dgram` receiver | 3.42 | `recvmsg` 1.15 (13% `EAGAIN`); `kevent` 0.69; `psynch_cvwait` 0.40; `psynch_cvsignal` 0.40; `semwait_signal` 0.35; `sendmsg` 0.32 (acks); `madvise` 0.07 |
| native `stream` sender | 2.91 | `sendmsg` 1.00; `recvmsg` 0.59 (44% `EAGAIN`); `kevent` 0.46; `psynch_cvsignal` 0.39; `psynch_cvwait` 0.39; `semwait_signal` 0.07 |
| native `stream` receiver | 3.47 | `recvmsg` 1.22 (18% `EAGAIN`); `kevent` 0.71; `psynch_cvwait` 0.43; `psynch_cvsignal` 0.43; `sendmsg` 0.33; `semwait_signal` 0.32 |
| raw `udp` sender (unconnected) | 1.03 | `sendto` 1.00 |
| raw `udp` receiver (unconnected, deep queue) | 2.00 | `read` 1.00; `kevent` 0.96 |
| raw `udpcr` sender (connected) | 1.02 | `write` 1.00 |
| raw `udpcr` receiver (connected) | 1.57 | `read` 1.25 (20% `EAGAIN`); `kevent` 0.29 |

- `top`'s per-process BSD system-call counters over a 6 s window of the diag pairs agree: native `dgram` 3.16–3.23 (sender) and 3.16–3.38 (receiver), `stream` 2.85–2.86 and 3.12–3.38, and 1.17–1.24 context switches per packet on the native sender, 1.41–1.54 on the receiver (**measured**).
- About 1.5–2 of the native path's 3–3.5 calls per packet are Go's scheduler, not I/O: netpoller `kevent`, and thread park and wake (`psynch_cv*`, `semwait_signal`). The map's 2026-10-07 probe already found that batched send hand-off saved CPU through fewer scheduler wakeups ([map notes](https://github.com/GridSwarm/wiremux/issues/1794)). These calls cost CPU but run on other threads than the saturated send goroutine.
- `madvise` at 0.07–0.10 per packet on the Datagram peers is the GC's scavenger returning memory (it falls to 0.003 on the stream sender, which allocates little).
- TCP: 0.67 calls per frame on the sender, 1.32 on the receiver (`top`).

## 8. Garbage collection

Every run now records whole-process GC cycles and GC CPU (`runtime/metrics`). C1 medians, with one `GOGC=400` arm each for Datagrams and the stream (**measured**):

| Arm | GC cycles/s sender | receiver | GC share of process CPU, sender | receiver | Delivered Mbit/s (min–max) | Sender user CPU-s/GiB | Receiver |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| `dgram` | 295 | 192 | 10.6% | 5.8% | 1,281 (1,235–1,323) | 5.16 | 6.59 |
| `dgram-g400` | 50 | 30 | 2.2% | 1.1% | 1,237 (1,204–1,277) | 4.48 | 6.10 |
| `stream` | 12.0 | 18.6 | 0.6% | 0.7% | 1,462 (1,356–1,531) | 3.05 | 4.85 |
| `stream-g400` | 1.3 | 2.6 | 0.1% | 0.1% | 1,445 (1,323–1,497) | 2.94 | 4.77 |

GC is not part of the macOS ceiling. `GOGC=400` cut Datagram collections about 6× and saved about 0.7 sender and 0.5 receiver user CPU-s/GiB, but throughput did not rise (the medians differ by less than the runs spread). The bottleneck goroutine spends about 90% of its time in `sendmsg`, and GC work runs on other cores. This answers only that question; the sweep belongs to [How much native Datagram throughput does Go's garbage collector take?](https://github.com/GridSwarm/wiremux/issues/1833).

## 9. Per-byte cost

[How much throughput can larger packets buy the native path?](https://github.com/GridSwarm/wiremux/issues/1797) measured a total-CPU slope of 1.0–1.3 ns per byte, 4–5× its crypto-plus-checksum floor. The prebuilt `base` and `all` binaries of [How much per-Datagram cost can the native Datagram path shed?](https://github.com/GridSwarm/wiremux/issues/1823) (native path unchanged since: `git diff 2599a002 origin/main -- binding internal` is empty) were profiled at the Wire maximum (1,191-byte Datagrams, 1,218-byte packets) and at `-size 600` (627-byte packets), one Time Profiler pair each (`X/b-*`). Slope = (µs per packet at 1,218 − at 627) / 591 bytes (**measured** per-packet costs, **derived** slopes):

| Build, peer | Total ns/B | GC | `mallocgc` | `memmove` + `memclr` | Allocation + copies | AES-GCM | Allocated bytes per packet (1,191 / 600) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `base` sender | 1.17 | 0.61 | 0.11 | 0.15 | **0.87** | 0.48 | 5,324 / 2,757 |
| `base` receiver | 1.56 | 0.32 | 0.32 | 0.11 | **0.75** | 0.21 | 3,164 / 1,879 |
| `all` sender | (noise) | −0.03 | −0.02 | 0.01 | **−0.04** | 0.04 | 177 / 177 |
| `all` receiver | (noise) | 0.15 | 0.17 | 0.08 | **0.39** | 0.19 | 1,624 / 980 |

- In `base`, most of the slope is allocation-proportional work: 0.75–0.87 ns/B of the 1.2–1.6 total, chiefly GC, whose work grows with allocated bytes (5,324 bytes allocated per 1,191-byte Datagram on the sender). AES-GCM is 0.2–0.5 ns/B.
- `all` allocates 177 bytes per sent packet whatever the size, and its sender's allocation slope vanishes. Its receiver keeps half: the fork still copies every received frame into a fresh buffer ([How much per-Datagram cost can the native Datagram path shed?](https://github.com/GridSwarm/wiremux/issues/1823)).
- Kernel copies and software checksums sit inside the `sendmsg`/`recvmsg` leaves (no kernel frames), whose per-packet cost varies by about ±1 µs from run to run. That noise hides the total slope of the `all` build and any kernel per-byte term in single recordings, so those are not resolved.
- So yes: the slope over the floor is mostly per-Datagram allocation (through GC) and copies, not crypto or checksums. At MTU 1500 it is CPU only; it does not move the ceiling, which is per-packet.

## Repeat campaign (C2)

C1 was noisy by the protocol's rule: `udp1232` and `udpc` each had 2 of 5 runs flagged (rate outliers from the single-socket bimodality, no load flags). C2 repeated every C1 arm in full with the same rig commit (2026-10-14 01:28–02:35 UTC, 74 load-gate waits, every scored run's load1 ≤ 8.11). Medians of 5 runs each (**measured**):

| Arm | C1 Mbit/s (min–max) | C1 pkt/s | C2 Mbit/s (min–max) | C2 pkt/s | Change |
| --- | --- | ---: | --- | ---: | ---: |
| `dgram` | 1,281 (1,235–1,323) | 134.5k | 1,125 (1,115–1,172) | 118.1k | −12% |
| `stream` | 1,462 (1,356–1,531) | – | 1,290 (1,263–1,319) | – | −12% |
| `dgram-g400` | 1,237 (1,204–1,277) | 129.9k | 1,087 (1,025–1,112) | 114.1k | −12% |
| `stream-g400` | 1,445 (1,323–1,497) | – | 1,272 (1,257–1,336) | – | −12% |
| `udp` | 1,778 (1,330–1,897) | 153.1k | 1,471 (1,316–1,898) | 126.6k | −17% |
| `udp2` | 1,848 (1,839–1,871) | 159.1k | 1,880 (1,628–1,923) | 161.8k | +2% |
| `udp4` | 1,889 (1,868–1,920) | 162.6k | 1,879 (1,868–1,914) | 161.8k | 0% |
| `udp8` | 1,884 (1,847–1,967) | 162.2k | 1,876 (1,805–1,924) | 161.5k | 0% |
| `udp1232` | 1,115 (1,083–1,560) | 113.2k | 1,226 (1,154–1,372) | 124.4k | +10% |
| `udp4-1232` | 1,586 (1,580–1,613) | 160.9k | 1,601 (1,574–1,620) | 162.4k | +1% |
| `udpc` | 1,333 (1,276–1,973) | 114.7k | 1,464 (1,441–1,744) | 126.0k | +10% |
| `udpr` | 2,137 (2,131–2,160) | 184.0k | 2,120 (2,037–2,144) | 182.5k | −1% |
| `udpcr` | 3,532 (3,417–3,564) | 304.0k | 3,325 (3,288–3,617) | 286.3k | −6% |
| `udp4cr` | 6,540 (5,691–7,019) | 563.0k | 6,220 (6,011–6,779) | 535.5k | −5% |
| `udp8cr` | 7,086 (5,721–7,226) | 610.0k | 7,223 (6,726–7,329) | 621.8k | +2% |
| `binding` | 1,036 (926–1,067) | 89.2k | 1,049 (998–1,107) | 90.3k | +1% |
| `tcp` | 37,383 (37,149–37,538) | – | 14,588 (14,580–14,590) | – | −61% |
| `udpq` | 575 (503–583) | 49.5k | 519 (472–620) | 44.7k | −10% |
| `udpq64` | 1,609 (1,340–1,854) | 138.5k | 1,634 (1,604–1,870) | 140.7k | +2% |

- **The receiving kernel's ceiling did not move.** Every arm held by the receiver's input thread (2, 4 and 8 unconnected sockets, either size) delivered within 2% of C1, at 161.5–162.5k packets/s.
- **The sender-bound arms slowed together.** Native Datagrams and the stream fell 12%, the single connected pair 6%, while the native sender spent 12% more CPU per packet than in C1 (17.81 against 15.89 CPU-s/GiB). mbp128 carried other sessions' work during C2 (a Go test binary near six cores at one check). That is what a sender-bound path should do, and it is a second, independent sign that the native ceiling sits on the sender.
- **TCP fell to 14.6 Gbit/s and stayed there**: 14,580–14,590 Mbit/s in all five C2 runs, at 59k frames/s of 31 KB, and again in a profiled pair after C2 (`X3/tcp`). In that state no thread on either Mac is saturated (receiver Thunderbolt thread 51%, sender's transmit threads 31–50%, the sending process 47%), unlike C1's state, where the driver's receive thread was 92% busy at 37.4 Gbit/s. The map's original 14.6 Gbit/s matches this second state. The cause, a link or driver state outside both hosts' CPUs, is not identified; it does not affect any UDP arm, which all need less than 7.3 Gbit/s.
- **C2 is noisy too**: `udp` had 2 of 5 runs flagged (1.22–1.29× its median), the same single-socket bimodality that flagged `udp1232` and `udpc` in C1, which this time fell the other way. `udpcr` had one load flag (8.11). The protocol asks for another full repeat; it was not run, because the noise is a structural property of the single unconnected raw socket on this cell (open question 4) and no conclusion here rests on that arm's median.
- **GC again**: `GOGC=400` cut Datagram collections from 246 to 44 per second (sender) and from 169 to 27 (receiver), and throughput was again not higher (1,087 against 1,125 Mbit/s, overlapping ranges).

## Method

**Campaigns** (`meta.txt`, `summary.txt` and `can.txt` in each directory):

| Campaign | What for | Runs per arm | Conditions | Noisy? |
| --- | --- | ---: | --- | --- |
| C1 | headline: the standard slate plus 14 arms (sockets, sizes, connected, `tcp`, `-qdepth`, `GOGC=400`) | 5 + warm-up | `LOADGATE=1` (54 waits), every run's load1 ≤ 7.96 | yes: `udp1232`, `udpc` 2/5 flagged |
| C2 | full repeat of C1 | 5 + warm-up | `LOADGATE=1` (74 waits), every run's load1 ≤ 8.11 | yes: `udp` 2/5 flagged; not repeated again (structural, see C2) |
| P2A-aborted | first MTU 9000 headline, gated at load1 8 | stopped after 8 warm-up runs | 37 waits in 20 min | not used |
| P2A | MTU 9000 headline: standard slate plus 8,972-byte raw UDP (1 and 4 sockets, unconnected and connected), `bindingj`, `tcp` | 5 + warm-up | gate and flag at load1 12 (owner-held window), 10 waits | no flags at 12; at the default 8 every arm would be load-noisy |
| P2B-A1, B1, A2, B2 | MTU 9000 native stream: stock fork (A) against a fork packet ceiling of 8,972 (B), standard slate | 3 + warm-up each | gate and flag at 12 | no flags at 12; A1 and B2 would be load-noisy at 8 |

**Hand-run pairs**, never inside a campaign, on the probe build (wiremux 2599a002 + rig d404687d + a read-time binding queue-depth hook, `bin/probe`, `bin/probe2`):

- `D/`: counter snapshots plus a sampler on each peer: socket `Recv-Q` every ~20 ms, the 16 KB cluster pool every 250 ms, `top` system-call and context-switch counters and `ps -M` per-thread CPU at two instants 6 s apart, and `kernel_task` CPU every second.
- `G/`: Go execution traces of both peers (`-trace`), summarized per goroutine by a small tool on `golang.org/x/exp/trace` (`tools/gtrace`).
- `S/`, `S2/`: xctrace System Trace attached to each peer's process for about 1.4 s mid-transfer, syscall tables counted per call and `errno`.
- `X/`, `X2/`: one system-wide xctrace Time Profiler recording per Mac per pair, on m4mini through `DEVELOPER_DIR` as PROTOCOL.md says; Go frames symbolized from each binary's symbol table.
- `B/`: socket high-water marks (`netstat -anv`) for the `udp`, `binding`, `dgram` and `stream` receivers.
- `K/`: System Trace and CPU Profiler recordings to look for kernel call stacks (none recorded).
- `X4/`, `G4/`: at MTU 9000, Time Profiler pairs for `udpj`, `udp4j`, `udp4crj`, the jumbo-ceiling stream and `tcp`, and a Go trace of the jumbo-ceiling stream. The phase 2 guard checks both `bridge0` MTUs, an 8,000-byte don't-fragment ping (macOS `ping` cannot send more than 8,192 bytes) and three 8,972-byte don't-fragment UDP datagrams.

**Limits.**

- No root: kernel call stacks, `netstat -s -p tcp`, NECP and soflow internals were unavailable. Kernel attribution is by thread; the NECP explanation is source reading.
- Instruments and Go tracing slow the traced process by 5–15%; their rates are lower than the campaigns' and are used for ratios and attribution only.
- The single unconnected raw socket is bimodal on this cell (about 115k or about 160k packets/s per run); its medians move with the mix.
- Another session, working on [How much native Datagram throughput does Go's garbage collector take?](https://github.com/GridSwarm/wiremux/issues/1833), ran `tb` campaigns earlier in the window and `netns` campaigns on minimax throughout. This ticket's evidence runs waited until no other `tb` work ran; the overlaps with `netns` work, whose processes run on minimax, are listed in the evidence README.

**Evidence** is in `native-gap-evidence/1800-macos-ceiling/` (README.txt indexes every campaign, pair, recording, binary, probe diff and script).

## Implications for the map

- **Multi-socket and multipath (the "several sockets" fog bullet).** One socket is not the hard limit on macOS, and several unconnected sockets buy nothing: 1, 2, 4 and 8 deliver the same ~160k packets/s because they share the receiving kernel's input thread. Several 4-tuples help only if they are connected: 4 pairs reached 563k and 8 pairs 610k packets/s. Even one connected pair reached 304k (sender-bound). So the bullet should be decided together with the connected-socket bullet, not before it; spreading one QUIC connection over several unconnected sockets is not worth its admission and ordering cost on macOS.
- **A connected socket per peer (the connected-socket fog bullet).** This is the largest MTU-1500 lever found on macOS: it cuts the receiving kernel's per-datagram cost 3.4–3.9× (ceiling ~160k → ~550–610k packets/s), cuts a raw send from 5.4 to 3.3 µs, and gives `ENOBUFS` backpressure. For the native path the receiving kernel is not yet the bottleneck; the sender's goroutine is, at about 7.5 µs per unconnected `sendmsg`. A connected native socket would cut that send cost and lift the next wall together. It changes wiremux's binding and admission model (a connected socket no longer sees other peers' datagrams), so it needs its own decision ticket.
- **recvmsg_x receive batching** ([Does recvmsg_x's retirement still hold when the receiver is the bottleneck?](https://github.com/GridSwarm/wiremux/issues/1798)). The native receiver is not the bottleneck, and its queue holds a median of 2–3 datagrams at read time (mean 11–14, empty 16–21%). A batch of 8 would mostly come back a quarter full. Batching would save receiver CPU (fewer `recvmsg` and wake-ups), not throughput, until the sender is fixed. The reopen condition in that ticket's resolution (queue depth) is now measured and does not favour reopening.
- **The fork's send path is the native ceiling, at both MTUs.** One goroutine and one `sendmsg` per packet per connection: about 7.5 µs per 1.4 KB packet, about 9.6 µs per 8.9 KB packet. Levers, in the order the evidence supports: a cheaper per-packet send (a connected socket; whatever makes the native `sendmsg` 2 µs dearer than a raw `sendto`), batched sends where the kernel builds a packet list (`sendmsg_x` on a connected socket), and less per-packet work on that goroutine. Moving work off the send goroutine (allocation, GC) saves CPU but not throughput at MTU 1500.
- **Jumbo frames are the multiplier, measured.** The native stream gained 5.0× at MTU 9000 (6.65 Gbit/s) from one fork constant, because the receiving kernel and the native send path are both per-packet bound. This sharpens the map's jumbo-frame bullet: if jumbo links are in the targets, the work [How much throughput can larger packets buy the native path?](https://github.com/GridSwarm/wiremux/issues/1797) listed (a configurable fork packet ceiling with black-hole detection, and for Datagrams a wiremux ceiling that follows discovery) buys about 5× on this cell. On this cell the Thunderbolt path itself tops out at about 13–14.6 Gbit/s in its slow state, so a further 2× is all a cheaper send path could add here.
- **Out of the map's scope**: the 16 KB-cluster pool and the Thunderbolt driver's 64 KB-per-frame receive buffers are Apple driver behaviour; nothing in wiremux or the fork changes them, except by keeping the receiving kernel ahead of the link.

## Open questions

These are candidate tickets.

1. **Why does the native `sendmsg` cost about 7.5 µs when a raw unconnected `sendto` costs 5.4 µs and a connected `write` 3.3 µs?** It is the native ceiling's whole cost. Candidates: the per-packet ancillary data (packet info), the interface-bound scope option, the DF option, NECP and MAC checks on every unconnected send. A raw `udp` arm that sends with the same control message on the same kind of socket would isolate it.
2. **Can the native path move to a connected socket per peer without weakening per-datagram admission, and what does the native ceiling become?** The kernel numbers say up to about 3.7× on the receiving side and 2 µs per packet on the sending side. The admission contract ([Native unicast admission re-inspects interfaces and routes on every packet](https://github.com/GridSwarm/wiremux/issues/1784), published in `docs/COMPATIBILITY.md`) and the binding model decide whether it is allowed.
3. **What part of the unconnected per-datagram cost is NECP, soflow tracking and the MAC check?** Needs kernel call stacks (root, or an Instruments template with kernel call stacks recorded) on m4mini. It decides whether anything short of connecting (for example fewer NECP policies, or an entitlement) can recover it.
4. **Why is the single unconnected raw socket bimodal (about 115k or 160k packets/s per run)?** Thread placement of the reader against the input thread is the first suspect. It does not affect the native arms but it makes single-socket raw baselines noisy.
5. **Does `sendmsg_x` on a connected socket (the kernel's list path) raise the native sender's rate where the fork's unconnected per-message loop did not?** Only meaningful after question 2.
6. **Why does the Thunderbolt link carry TCP at 37.4 Gbit/s in one window and exactly 14.6 Gbit/s in another, with no thread saturated in the slow state?** It decides what the TCP reference on this cell is, and the whole MTU 9000 window ran in the slow state, where connected jumbo UDP stopped at 13.3 Gbit/s with loss in the driver or link.
7. **Where do jumbo frames die when several senders overload the receiver?** At 8,972 bytes, 4 senders lost 64–87% of their packets with neither 16 KB refill failures nor DLIL trims, while the Thunderbolt receive thread ran at 90–99% and delivery collapsed. Driver statistics need root or Apple's tooling; it matters only for a multi-path or multi-flow design at jumbo size. `system_profiler SPThunderboltDataType` and the link state before and after each campaign would be the first evidence.

## Phase 2: MTU 9000

The owner set MTU 9000 on both Macs' `bridge0` and Thunderbolt members at 2026-10-14 16:20Z; every phase 2 run happened inside that window, between 16:44 and 17:36Z; MTU 1500 is the configuration outside it. Payloads of 8,972 bytes fill a 9,000-byte IP packet (9,012–9,014-byte frames on `bridge0`). The TCP reference was in its slow state the whole window: 14,573–14,585 Mbit/s in every `tcp` run.

**Campaigns** (**measured**, medians; `P2A` `REPS=5`, the A/B `REPS=3` per build, all with a warm-up rotation):

| Arm | Offered pkt/s | Delivered pkt/s | Mbit/s (min–max) | Loss | Where it is lost | What holds it |
| --- | ---: | ---: | --- | ---: | --- | --- |
| `udpj`, 1 unconnected socket | 144.4k | 140.3k | 10,071 (9,767–10,196) | 2.2% | 16 KB refill failures and socket buffer | the unconnected sender's one thread (95%); the receiver's input thread is at 83% |
| `udp4j`, 4 unconnected sockets | 304.6k | 111.1k | 7,974 (7,548–8,625) | 63.5% | Thunderbolt driver or link: neither refill failures (0.2%) nor DLIL trims | receiver's Thunderbolt receive thread at 89.5% |
| `udpcrj`, 1 connected pair | 216.6k | 185.0k | 13,278 (13,150–14,345) | 14.4% | Thunderbolt driver or link | the link in its slow state, about 13–14.6 Gbit/s |
| `udp4crj`, 4 connected pairs | 453.8k | 60.7k | 4,358 (4,095–4,365) | 86.6% | Thunderbolt driver or link | receiver's Thunderbolt receive thread at 98.6%: overload collapse |
| `bindingj` (wiremux admission, 8,972 B) | 130.4k | 110.9k | 7,959 (7,757–8,214) | 13.1% | socket buffer (the binding's default buffer) | the binding reader |
| `tcp` | – | 60.4k frames/s of 30.3 KB | 14,584 (14,573–14,585) | – | – | the link in its slow state; no thread saturated |
| native `stream`, stock fork | – | 121.5k frames/s of 1,438 B | 1,326 (1,263–1,381) | – | – | sender's send goroutine (as at MTU 1500) |
| native `stream`, jumbo-ceiling fork | – | 102.2k frames/s of 8,200 B | **6,649 (6,449–7,189)** | – | – | **sender's send goroutine: 99.9% busy, 92.8% in `sendmsg`** |
| native `dgram`, either fork | – | 121–123k | 1,160–1,171 | 0% | – | unchanged: wiremux caps a native Datagram at 1,192 bytes |

- The standard slate at MTU 9000 matched C2 within a few percent (`udp4` 162.8k packets/s, `dgram` 1,132 Mbit/s): the MTU changes nothing for 1,500-byte packets.
- **Native stream, stock against jumbo ceiling** (pooled medians of 6 runs each, P2B-A1/A2 against B1/B2): 1,326 → 6,649 Mbit/s, **5.0×**. The throwaway fork change was one constant, `MaxPacketBufferSize` 1,452 → 8,972 (`fork-jumbo/`); discovery climbed to it on its own. CPU per GiB fell from 13.2 to 3.0 on the sender and from 15.9 to 3.1 on the receiver.
- **That is inside the derived estimate.** [How much throughput can larger packets buy the native path?](https://github.com/GridSwarm/wiremux/issues/1797) derived 4.1–7.6 Gbit/s for the native path at MTU 9000; the stream measured 6.4–7.2 Gbit/s, the upper half. Its packet rate fell from 121k to 102k per second because each `sendmsg` now carries 8.9 KB: in a Go trace (`G4/`) the send goroutine is still the bottleneck, 99.9% busy and 92.8% inside `sendmsg`, at about 9.6 µs per call against 7.5 µs at 1,438 bytes (**derived**: 0.928 / 97,011 calls/s). The receiver's receive goroutine was 55% busy and its kernel threads 51–55%, so the receiver still has headroom.
- **Raw UDP at 9 KB is packet-bound the same way.** The receiver's input thread spends 6.2 µs per 9 KB datagram on an unconnected socket (83% at 134.6k frames/s), the same as for 1.5 KB, so the unconnected receive ceiling becomes about 160k × 9 KB ≈ 11.5 Gbit/s (**derived**); one unconnected socket reached 10.1 Gbit/s, held by its sender.
- **Above about 13 Gbit/s the Thunderbolt path itself gives out.** The connected pair delivered 13.3 Gbit/s with 14% loss, close to TCP's 14.6 Gbit/s ceiling in the same state. With 4 senders offering 305–454k packets/s (22–33 Gbit/s), the receiver's Thunderbolt receive thread ran at 89.5–98.6% and delivery collapsed to 111k and 61k packets/s. Those losses are neither 16 KB refill failures nor DLIL queue trims (none logged), so they happen in the driver or on the link, where no unprivileged counter sees them.
- **Conditions.** The first P2A attempt, gated at load1 8, waited 37 times in 20 minutes behind GARM VM jobs on mbp128 and was stopped after 8 warm-up runs (`P2A-aborted/`, reported, not used). P2A and P2B then ran with the load gate and flag at 12 to fit the window (no runs flagged at 12). At the protocol's default of 8, 51 of P2A's 55 scored runs and 25 of P2B's 60 would be load-flagged, so by the standard rule these campaigns are noisy; no rate outlier was flagged in any of them, and no repeat fitted the window.
