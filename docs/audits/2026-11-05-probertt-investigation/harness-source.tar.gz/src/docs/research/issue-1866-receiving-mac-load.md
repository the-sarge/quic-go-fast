# Issue #1866: load on the receiving Mac and the native receiver's goroutines

Research for [Does load on the receiving Mac cost the native pair, and do its receive goroutine and run loop need a raised class?](https://github.com/GridSwarm/wiremux/issues/1866) on the map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794). Until now only the sending Mac had been loaded. [Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6240861645) adopted a raised send goroutine for every native Wire and graduated the receiving side to this ticket. This note loads the receiving Mac with another program's spinners on the two fast shapes. Beside the adopted send goroutine, it tries raising the fork's receive goroutine (`Transport.listen`) and the connection run loop (`Conn.run`) to user-initiated. It also answers from source where such a hook would live. Nothing here implements a change.

Sources: wiremux at [#1857's](https://github.com/GridSwarm/wiremux/issues/1857) probe (`bef05a64`: connected socket, batched sends and receives, the acknowledgment threshold, the send-queue knobs and `-threads`, each switched by a flag) plus one local commit for this note's readouts; wiremux `origin/main` [`870295a4`](https://github.com/GridSwarm/wiremux/tree/870295a497ef862fa51f523c5f64d0eaf06dbed8) for the hook question. The fork is #1857's quic-go-fast copy (`v0.62.1-fast.7` plus #1854–#1861's knobs at their defaults and #1853's send-thread hook), with #1861's drop counters and this note's probe commits added. The pristine fork is cited at its tag [`v0.62.1-fast.7`](https://github.com/the-sarge/quic-go-fast/tree/v0.62.1-fast.7). Also cited: Go [1.27.2](https://github.com/golang/go/tree/go1.27.2)'s runtime, and measurements taken for this note on 2026-10-18 (UTC). Every number is labeled **measured**, **derived** (with its arithmetic) or **source**.

**Cell.** `tb` only: mbp128 (MacBook Pro M4 Max, 12 performance and 4 efficiency cores) sends from `bridge0` over Thunderbolt to m4mini (Mac mini M4 Pro, **8 performance and 4 efficiency cores**, 12 in all), both macOS 27 arm64, MTU 1500. All load is on the receiving Mac. The sender was otherwise idle, with its send thread raised as adopted.

**Load.** 0, 8 and 18 one-thread spinners on m4mini, started from a separate `ssh m4mini` session, so they are another program in their own coalition. The ticket asked for 12 and 24 on a 16-core Mac. Scaled to m4mini, 8 fills every performance core and 18 is 1.5× all cores. Each run recorded both Macs' coalitions, and every one had the intended relationship.

**Launch.** The receiver starts through its own `ssh m4mini` session, a daemon launch context with a ceiling of user-initiated, so raised arms take effect there. Every raised thread's base priority was read back and was 37 at the hook and at the end of every run (**measured**). The sender starts through its own `ssh mbp128` session and #1853's daemon launcher, with the adopted send-thread raise.

**Shapes** (flags on both peers, all with the fork bundle's 1,024-entry received-Datagram and unprocessed-packet queues and a 32-entry send queue with a batch cap of 32):

- **batched sends:** connected socket, one `sendmsg_x` per send group, an acknowledgment every 16 packets. Idle, this pair is receiver-bound ([How much would batched connected sends add to the native macOS sender?](https://github.com/GridSwarm/wiremux/issues/1856#issuecomment-6228278037)).
- **batched receives:** batched sends plus `recvmsg_x` with eight read slots. Idle, this pair is sender-bound ([What makes up the connected macOS receive goroutine's cost per datagram, and what would lower it?](https://github.com/GridSwarm/wiremux/issues/1861#issuecomment-6235012064)).

The kinds are Datagrams at the GC pin (`-ballast 64 -gc-role both`) and the stream.

**Receiver arms** (one binary, switched by environment on m4mini only):

| Arm | Receiver's send goroutine | Receive goroutine (`Transport.listen`) | Run loop (`Conn.run`) |
| --- | --- | --- | --- |
| `rn` | default | default | default |
| `rs` (baseline) | user-initiated | default | default |
| `rl` | user-initiated | user-initiated | default |
| `rlr` | user-initiated | user-initiated | user-initiated |

The baseline is `rs`, not the ticket's "default", because [the adopted send-thread raise](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6240861645) applies to every native Wire, so on `main` the receiving peer's acknowledgment-sending goroutine will be raised too. `rn` is kept as the reference for today's code. Every raised goroutine follows the adopted pattern: lock the goroutine to its thread, raise the class, read the base priority back, stand down below 37, and restore the class before unlocking.

**The receiving Mac was not idle.** m4mini is a working Mac, and its own background ran throughout. It was left alone and recorded per run (section 5). At 0 spinners it used 1.0–3.7 cores (median 1.5) 1 s into each send, mostly Photos' `mediaanalysisd` (median 1.1 cores, about half of its threads at priority 37) (**measured**).

## Answer

**Load on the receiving Mac costs the native pair only on the shape that is sender-bound when idle, and a raised receive goroutine is not a clean lever: it helps when the receiving Mac's performance cores are full and hurts when the Mac is oversubscribed.**

**Does load cost the pair?** (baseline arm `rs`, medians of three, Mbit/s; percentages **derived**)

- **Batched sends, receiver-bound when idle: no.** The pair ran faster under load: Datagrams 3,076 → 3,924 at 8 spinners (+28%) and 3,282 at 18 (+7%); the stream 3,555 → 4,159 (+17%) and 3,769 (+6%). Unraised (`rn`) it gained +23% and +11% (Datagrams) and +20% and +8% (stream).
- **Batched receives, sender-bound when idle: yes, mostly at 18 spinners.** Datagrams 4,697 → 4,631 (−1%) and 3,959 (−16%); the stream 5,662 → 5,151 (−9%) and 4,419 (−22%). Unraised it lost 9% and 17% (Datagrams) and 7% and 13% (stream). Under load this receiver binds: its socket queue holds 220–270 datagrams on average, against 15–19 idle.
- **Why the receiver-bound pair speeds up:** on performance cores, the receive goroutine's work per datagram falls by half when the Mac is busy. Idle it costs 2.97–2.98 µs per datagram at 1.34 instructions per cycle; with 8 spinners, the windows spent only on performance cores cost 1.41–1.46 µs at 2.55–2.64. The cores ran only 4% faster (3.76 → 3.91 GHz). Most of the drop is the receive call's kernel time, which [the receive-goroutine research](https://github.com/GridSwarm/wiremux/issues/1861#issuecomment-6235012064) traced to contention with the kernel's input thread. That contention seems to fade on a busy Mac; this note can't say why without kernel stacks (**measured**; section 1).
- **Datagram loss rises under load.** At 8 spinners the received-Datagram queue discarded 0.43% (batched sends) and 1.95% (batched receives) of the Datagrams sent at the baseline arm, despite 1,024 entries (≤ 0.08% idle). The application's reading goroutine is a default-class goroutine, and it falls behind on efficiency cores (**measured**).

**Where the receiver's threads run** (**measured**; share of each one's CPU on efficiency cores):

- Idle, everything stays on performance cores (≤ 1.6%).
- At 8 spinners, at the default class: the receive goroutine 37–44% (batched sends) and 72–77% (batched receives), the run loop 30–62%, the receiver's send goroutine 49–65% (`rn`), the whole process 40–55%.
- At 18 spinners: the receive goroutine 68–86%, the run loop 5–32%, the send goroutine 19–27% (`rn`), the process 35–41%.
- Every raised thread spent 0.9% or less of its time on efficiency cores, in every cell.

**What a raised class buys** (change against `rs` in the same block; **derived** from medians of three):

| | Idle | 8 spinners (performance cores full) | 18 spinners (1.5× all cores) |
| --- | ---: | ---: | ---: |
| `rl`, batched sends: Datagrams / stream | +13% / +11% | +12% / +24% | −18% / −19% |
| `rl`, batched receives: Datagrams / stream | +0% / +1% | +3% / +9% | −5% / −7% |
| `rlr`, batched sends | +6% / +8% | +11% / +17% | −17% / −24% |
| `rlr`, batched receives | −2% / +2% | +7% / +9% | +4% / −9% |
| `rn` (the receiver's send goroutine back at the default class) | +1% / +0%, +8% / −3% | −3% / +2%, −1% / −1% | +5% / +2%, +6% / +7% |

- **The gain** comes where the Mac's performance cores are full but not oversubscribed, and idle on the receiver-bound shape, where the raised receive call is cheaper (2.66 against 2.98 µs per datagram).
- **The loss** comes when the Mac is oversubscribed. On batched sends the raised receive goroutine then sits idle about half the time (47–64% busy) while its socket still holds 190–320 datagrams on average, and the receiver's context switches per GiB double. The lock alone doesn't cause it: in a mechanism set, the receive goroutine and run loop locked but not raised cost nothing, while either one raised lost 18–20% on batched sends (section 3).
- **The adopted raise on the receiving peer's send goroutine** costs up to 7% at 18 spinners (`rn` against `rs`: +2% to +7%; clear outside the run spread in one of four cells) and is neutral at 8.
- **Cost to other work:** beside `rl` the spinners made 3–5% less progress at 8 spinners and about 1% less at 18; beside `rlr`, 8–9% and 1–7% less (**measured**). One raised thread is one of m4mini's 12 cores, 8% (**derived**).
- **Loss:** with only the receive goroutine raised, the transport outran the application's reader. At 8 spinners `rl` lost 5.4% (batched sends) and 4.4% (batched receives) of its Datagrams in the received-Datagram queue (medians; single runs 2.7–10.1%); `rlr` lost 0.15% and 0.35% (**measured**).

**Where a hook would live** (**source**): one receive goroutine per fork `Transport`, one `Transport` per binding, and one binding per usable address of each selected interface, so a listening endpoint on `bridge0` has two (IPv4 and IPv6 link-local). After promotion a Wire's endpoint carries exactly that Wire, so no receive goroutine is shared between Wires in wiremux. The run loop and send goroutine are per connection. Section 6 sketches the adopted pattern for each.

**Verdict.** A lever shows, but its sign depends on the receiving Mac's load: +3% to +24% when its performance cores are full, and −24% to +4% when the Mac is oversubscribed (seven of eight cells lower). The loss comes with the class on a locked thread, not with the lock alone. A grilling follows (section 7).

## 1. How load meets the receiver

(**measured**; baseline arm `rs` unless stated; medians of three)

| Shape, kind | Spinners | Mbit/s | Receive goroutine busy | Its CPU per datagram, µs (performance-core windows) | Instructions per cycle on performance cores | Its CPU on efficiency cores | Socket queue, mean datagrams | Received-Datagram queue discards |
| --- | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batched sends, Datagrams | 0 | 3,076 | 0.97 | 2.98 (2.98) | 1.34 | 0.002 | 697 | 0 |
| | 8 | 3,924 | 0.86 | 1.98 (1.41) | 2.64 | 0.38 | 452 | 16,359 |
| | 18 | 3,282 | 0.91 | 2.75 (1.40) | 2.58 | 0.69 | 286 | 14,928 |
| batched receives, Datagrams | 0 | 4,697 | 0.49 | 0.97 (0.97) | 1.70 | 0.016 | 15 | 2,390 |
| | 8 | 4,631 | 0.69 | 1.46 (0.66) | 2.48 | 0.72 | 221 | 95,359 |
| | 18 | 3,959 | 0.85 | 2.12 (0.80) | 2.31 | 0.86 | 257 | 13,889 |

- **Receiver-bound idle, faster under load.** Idle, the batched-send receiver's receive goroutine is 97% busy and its socket queue holds about 697 datagrams, near the buffer's 856, as #1856 found. Under 8 spinners its performance-core windows cost half as much per datagram. That more than offsets the 38% of its CPU spent on efficiency cores, which are slower: its whole-window cost is 1.98 µs against 2.98. At 18 spinners 69% of its CPU is on efficiency cores and the pair keeps a 7% gain. The stream behaves the same.
- **Sender-bound idle, receiver-bound under load.** With eight read slots the receive goroutine is half busy when idle, and the sender is the wall. At 8 spinners 72% of its CPU is on efficiency cores and it is 69% busy; at 18 spinners 86% and 85% busy. Its socket queue fills to 220–270, and the rate falls 16% (Datagrams) and 22% (stream).
- **The work gets cheaper per cycle, not faster per cycle.** The performance cores' clock rose 4%, from 3.75–3.77 to 3.91 GHz, and the instructions per datagram stayed about the same. Instructions per cycle doubled, from 1.34 to 2.6 on the batched-send receiver. The receive call's kernel time per datagram fell from 2.04–2.07 to 1.28–1.30 µs at 8 spinners. #1861 measured an idle receive call at 1.1–1.2 µs when nothing else touches the socket and 2.7–3.4 µs while the input thread appends to it. A busy Mac's receive call behaves more like the first. This note can't say whether the input thread and the receive goroutine overlap less, or the socket's cache lines bounce less across clusters, without kernel stacks (root).
- **Datagram discards** at the 1,024-entry queue rise from 0–2,390 per run idle to 14,000–95,000 under load (cell medians, 0.4–2.0% of the Datagrams sent). The fork's unprocessed-packet queue rarely dropped anything (median 0 per run; 8 of 144 runs above 1,000, at most 3,316), and the socket buffer dropped at most 4,422 in any run, idle or loaded.

## 2. Where the receiver's threads run

(**measured**; share of each one's CPU on efficiency cores, medians of three. The receive goroutine's share comes from its own counters every 256 receive batches, the run loop's and send goroutine's from sampled stretches between their blocking points, every 64th, and the process's from `-threads`.)

| Spinners | Arm | Receive goroutine | Run loop | Receiver's send goroutine | Process |
| ---: | --- | --- | --- | --- | --- |
| 0 | every arm | ≤ 0.016 | ≤ 0.004 | ≤ 0.003 | ≤ 0.006 |
| 8 | `rn` | 0.37–0.77 | 0.34–0.62 | 0.49–0.65 | 0.46–0.55 |
| 8 | `rs` | 0.38–0.74 | 0.30–0.54 | 0.004–0.006 | 0.40–0.49 |
| 8 | `rl` | 0.003–0.004 | 0.18–0.60 | 0.000–0.006 | 0.19–0.28 |
| 8 | `rlr` | 0.002–0.005 | 0.001–0.005 | 0.004–0.007 | 0.08–0.14 |
| 18 | `rn` | 0.69–0.86 | 0.06–0.32 | 0.19–0.27 | 0.37–0.41 |
| 18 | `rs` | 0.68–0.86 | 0.05–0.28 | 0.003 | 0.35–0.39 |
| 18 | `rl` | 0.003–0.004 | 0.06–0.53 | 0.002–0.007 | 0.10–0.18 |
| 18 | `rlr` | 0.003–0.004 | 0.002–0.003 | 0.002–0.007 | 0.06–0.08 |

- **The receive goroutine leaves performance cores first.** It is the receiver's busiest goroutine, and at 18 spinners 68–86% of its CPU is on efficiency cores. The run loop, which wakes less often for longer, keeps more of its time on performance cores at 18 spinners (5–32%) than at 8 (30–62%).
- **Raising one goroutine pushes the others out.** With the receive goroutine raised (`rl`), the run loop's share on efficiency cores rises at 18 spinners on the Datagram blocks (0.28 → 0.53 batched sends, 0.19 → 0.46 batched receives). One of m4mini's eight performance cores is now reserved for the raised thread.
- **Raised threads stay put.** Every hooked thread, in every loaded cell, spent at most 0.9% of its time on efficiency cores. The process share falls to 6–14% with all three raised (`rlr`); what remains is the application's reading goroutine, the garbage collector and Go's other threads.

## 3. What the raised class buys, and why it turns

(**measured** rates in Mbit/s, medians of three with min–max; changes **derived**)

| Shape, kind | Spinners | `rn` | `rs` | `rl` | `rlr` |
| --- | ---: | --- | --- | --- | --- |
| batched sends, Datagrams | 0 | 3,102 (3,003–3,103) | 3,076 (3,003–3,083) | 3,479 (3,393–3,507) | 3,266 (3,259–3,279) |
| | 8 | 3,802 (3,739–3,840) | 3,924 (3,849–3,952) | 4,399 (4,378–4,424) | 4,369 (4,248–4,444) |
| | 18 | 3,437 (3,416–3,539) | 3,282 (3,269–3,455) | 2,691 (2,338–2,741) | 2,741 (2,614–2,764) |
| batched sends, stream | 0 | 3,556 (3,553–3,580) | 3,555 (3,547–3,560) | 3,949 (3,922–3,994) | 3,825 (3,744–3,841) |
| | 8 | 4,250 (3,681–4,289) | 4,159 (3,544–4,409) | 5,165 (4,094–5,184) | 4,852 (4,365–4,944) |
| | 18 | 3,843 (3,745–3,850) | 3,769 (3,749–3,778) | 3,070 (3,061–3,079) | 2,858 (2,829–2,869) |
| batched receives, Datagrams | 0 | 5,053 (4,539–5,104) | 4,697 (4,646–5,020) | 4,713 (4,502–5,031) | 4,604 (4,477–5,017) |
| | 8 | 4,593 (4,546–4,682) | 4,631 (4,439–4,671) | 4,785 (4,752–4,841) | 4,938 (4,711–5,218) |
| | 18 | 4,205 (3,958–4,303) | 3,959 (3,879–3,995) | 3,762 (3,445–3,789) | 4,122 (3,868–4,397) |
| batched receives, stream | 0 | 5,475 (5,248–5,664) | 5,662 (5,392–5,888) | 5,731 (5,654–6,044) | 5,754 (5,685–5,780) |
| | 8 | 5,118 (5,068–5,121) | 5,151 (5,143–5,206) | 5,626 (5,447–5,654) | 5,599 (5,590–5,773) |
| | 18 | 4,739 (4,638–4,756) | 4,419 (4,399–4,485) | 4,118 (4,049–4,211) | 4,015 (3,882–4,268) |

- **Idle, on the receiver-bound shape:** the raised receive goroutine never parks, and its receive call is cheaper (2.66 against 2.98 µs per datagram; instructions per cycle 1.46 against 1.34): +13% (Datagrams) and +11% (stream). #1853 saw the same on the sender, a raised send call 14% cheaper idle. On the sender-bound shape the goroutine parks on an empty socket tens of thousands of times a second, and raised and locked it costs more per datagram (1.48 against 0.97 µs; kernel 1.02 against 0.50; 9,741 against 6,190 instructions) and gains nothing.
- **At 8 spinners** the raised receive goroutine keeps performance cores while the spinners fill them, and every shape gains: +12–24% with batched sends, +3–9% with batched receives.
- **At 18 spinners** every raised arm loses on batched sends (−17% to −24%) and `rl` loses on batched receives (−5%, −7%). The raised receive goroutine still costs less per datagram (1.87 against 2.75 µs on batched sends), but there it is busy only 47–64% of the time while its socket holds 190–320 datagrams on average. Each GiB takes 1.9–2.3× the context switches of `rs` (355–479 thousand against 191–210 thousand).
- **The class on a locked thread, not the lock alone** (mechanism set `X1`, 18 spinners, Datagrams, two runs per arm, not gate-grade; **measured**):

  | Arm (all with the receiver's send goroutine raised) | Batched sends | Batched receives | Context switches per GiB (thousands) |
  | --- | --- | --- | --- |
  | `rs` | 3,494 | 4,096 | 205 / 198 |
  | `rk`: receive goroutine locked, class unchanged | 3,566 (+2%) | 4,240 (+4%) | 203 / 205 |
  | `rkr`: receive goroutine and run loop locked, class unchanged | 3,499 (+0%) | 4,173 (+2%) | 199 / 228 |
  | `rl`: receive goroutine raised (as in `M1`) | 2,792 (−20%) | 4,190 (+2%) | 400 / 315 |
  | `rr`: run loop raised only | 2,859 (−18%) | 3,334 (−19%) | 322 / 366 |

  - The lock alone costs nothing measurable. A locked goroutine at the default class stays on efficiency cores 46–72% of its time, runs behind its producer and works in larger batches: the locked default run loop drained 17–24 packets per wake against 9–17 unlocked, and was woken 18,000–21,000 times a second against 38,000–48,000. So it seldom parks.
  - Raising either goroutine on its locked thread loses at 18 spinners. The raised run loop alone lost 18–19% on both shapes. The raised receive goroutine alone lost 20% on batched sends here (18% in `M1`), and on batched receives it was +2% here and −5% in `M1`. The context switches per GiB rose 57–95% with a raised goroutine, against −3% to +15% with the lock alone.
  - **What fits** (**source** for the runtime, the link to the loss not traced): Go runs a locked goroutine only on its own thread, and only once a Go processor is handed to that thread. When the goroutine blocks, its thread gives the processor away (`stoplockedm`, [`proc.go` L3265-L3287](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3265-L3287)). When it is runnable again, whichever thread picks it must hand over its processor and wake the locked thread (`startlockedm`, [L3293-L3308](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L3293-L3308); [`schedule` L4157-L4159, L4238-L4242](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L4238-L4242)). A system call that lost its processor waits the same way on return (`exitsyscallNoP`, [L5106, L5145-L5151](https://github.com/golang/go/blob/go1.27.2/src/runtime/proc.go#L5145-L5151)). Every such wake costs two thread switches, and the threads that hand processors over are Go's default-class threads, which under 18 spinners are time-sliced with the spinners. A raised goroutine runs fast enough to empty its queue and park, then waits on a default-class thread to run again. A locked default-class goroutine rarely gets that far. At 8 spinners the efficiency cores still give Go's other threads time, and the raise wins. A Go execution trace of the receiver would confirm or refute this; this note didn't record one.
- **On the sender side** the `X1` runs met mbp128's own background (Photos' `photolibraryd`, `spotlightknowledged`: 0.25–3.4 cores before each run, median 2.6, against 1.8 in `M1`'s 18-spinner runs). It didn't show in the rates: within a block the same arm ran at the same rate with 0.25 and 2.65 cores of sender background (`rs` 3,498 and 3,491 Mbit/s). The sender's raised send thread stayed on performance cores (median 0.01% on efficiency cores), and the receiver was the wall (socket queue 257 on average) (**measured**).

## 4. The cost to other work

(**measured** spinner progress, billions of iterations per second over the sender's offer window; change against `rs` **derived**)

| Shape, kind | Spinners | `rn` | `rs` | `rl` | `rlr` |
| --- | ---: | ---: | ---: | ---: | ---: |
| batched sends, Datagrams | 8 | 4.37 (+1.2%) | 4.32 | 4.11 (−4.8%) | 3.96 (−8.2%) |
| | 18 | 4.74 (−1.4%) | 4.81 | 4.74 (−1.5%) | 4.48 (−6.8%) |
| batched sends, stream | 8 | 4.37 (+1.3%) | 4.32 | 4.12 (−4.6%) | 3.92 (−9.1%) |
| | 18 | 4.75 (−0.6%) | 4.78 | 4.75 (−0.6%) | 4.74 (−0.9%) |
| batched receives, Datagrams | 8 | 4.31 (+1.0%) | 4.26 | 4.11 (−3.5%) | 3.94 (−7.6%) |
| | 18 | 4.48 (−1.0%) | 4.53 | 4.49 (−0.9%) | 4.28 (−5.5%) |
| batched receives, stream | 8 | 4.36 (+2.0%) | 4.27 | 4.13 (−3.3%) | 3.93 (−8.1%) |
| | 18 | 4.53 (−1.6%) | 4.61 | 4.56 (−1.1%) | 4.46 (−3.2%) |

- The adopted send-goroutine raise on the receiver costs other work nothing measurable (`rn` against `rs`, ±2%).
- Raising the receive goroutine costs 3–5% at 8 spinners, where it holds a performance core the spinners would otherwise use, and about 1% at 18, where it runs less.
- Raising the run loop as well costs 8–9% at 8 spinners and 1–7% at 18: two raised threads hold two of m4mini's eight performance cores.
- The spinners' share of user time on performance cores fell from 0.82–0.84 beside `rs` to 0.74–0.79 beside `rlr` at 8 spinners.

## 5. The receiving Mac's own background

m4mini is a working Mac, and its own processes ran throughout the campaign. They were left alone. Each run recorded the busiest processes before the run, 1 s into the send and after it (**measured**, `ps`):

- **At 0 spinners the background used 1.0–3.7 cores** 1 s into the send (median 1.5), and 1.0–3.0 before the run (median 1.6). In 46 of the 48 counted runs most of it was Photos' `mediaanalysisd` (median 1.1 cores, at most 2.0). [The parent session's samples](#coordination) put about half of its threads at priority 37, user-initiated's own level, and half at 20; its VideoToolbox decoders ran beside it. `fseventsd` or Spotlight's `mds` added 1.1–1.9 cores in 8 of the 142 runs. So "unloaded" means about 1.5 cores of real work, a part of it at the raised arms' own priority.
- **The 0-spinner rate doesn't track it.** Across the 48 counted runs, each run's rate against its cell's median correlates weakly and positively with the background (r = 0.25 at 1 s into the send, 0.17 before it). The busier and quieter halves sit at the same median (**derived**). That fits section 1: on this receiver, a busier Mac means a cheaper receive call.
- **At the 8-spinner step the background tips the performance cores into oversubscription.** Eight spinners fill m4mini's eight performance cores, and the background added 0.7–1.5 cores on top (1 s into the send, cell medians), so this step sits between a clean "performance cores full" case and the 18-spinner one.
- **Early in the campaign the background was different.** Until 03:39:15Z a stuck DEVONthink thread ran at priority 47, the frontmost app's class (above user-initiated's 37), alongside a Screen Sharing session (WindowServer at 79, ScreensharingAgent at 31–37). DEVONthink was then force-quit and restarted idle. In this campaign's samples DEVONthink used 0.6–1.0 core in `r1-l8xs-rs` and 0.4 in `r1-l8xs-rl`, and Screen Sharing 0.6–0.9 core in `r1-l8xs-*` and `r1-l18rb-rn`. The first repetition of the batched-send stream block at 8 spinners ran 10–21% below the later two in every arm. But the arms' order held on both sides of the boundary: `rl` over `rs` +15.5% before, +24.6% and +17.1% after; on the idle batched-send Datagram block, +13.0% before and +14.0% and +12.9% after (**derived**).
- **A user-initiated class can't outrank the frontmost app.** A focal app's user-interactive threads run at base priority 47 ([#1853's ceilings](https://github.com/GridSwarm/wiremux/issues/1853#issuecomment-6214578466)), above user-initiated's 37. So any receiver hook protects against default-class load like these spinners, not against the app the user is working in, nor against `mediaanalysisd`'s user-initiated half. That is a real limit of the lever.
- **A clean control agrees** (`C1`, the baseline arm `rs` only, two runs per cell; **measured**). m4mini's background fell to 0.2–0.4 core at 07:06Z, and the control ran once it had held under 0.5 core for 3 minutes. It ran 16 of its 24 runs before `mediaanalysisd` came back and the per-run gate (1 busy core) stopped it. At 0 spinners, with 0.25–0.92 core of background, its medians were within −2.4% to +5.9% of `M1`'s, which ran beside 1.4–2.6 cores: batched sends 3,029 and 3,471 Mbit/s (Datagrams, stream) against 3,076 and 3,555; batched receives 4,974 and 5,891 against 4,697 and 5,662. At 8 spinners they were within −1.1% to +3.4%. Load moved the clean pair as it moved `M1`'s: +28% and +23% on batched sends, −4% and −12% on batched receives (**derived**).

## 6. Where a hook would live

**How many receive goroutines a native Wire has** (**source**, wiremux [`870295a4`](https://github.com/GridSwarm/wiremux/tree/870295a497ef862fa51f523c5f64d0eaf06dbed8), fork [`v0.62.1-fast.7`](https://github.com/the-sarge/quic-go-fast/tree/v0.62.1-fast.7)):

- **One binding per usable address.** A native endpoint binds every usable unicast address of each selected interface, one socket each ([`unicast.go` L332-L341](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/routeselection/unicast.go#L332-L341)). `bridge0` on both Macs carries an IPv4 address and an IPv6 link-local one, so the rig's endpoints have two bindings each (**measured**, `ifconfig bridge0`).
- **One fork `Transport` per binding.** The endpoint wraps each binding in its own `quic.Transport` ([`endpoint.go` L93, L182-L191, L208-L210](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/endpoint.go#L182-L191); [`native.go` L88-L89](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/native.go#L88-L89)). The extra `Transport` built only to discover the fork's capabilities ([L174](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/endpoint.go#L174)) is never initialized and starts nothing.
- **One receive goroutine per initialized `Transport`.** A `Transport` starts `listen` and its small `runSendQueue` worker the first time it is used ([`transport.go` L441, L496-L504](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/transport.go#L496-L504)), from `Listen` ([L232](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/transport.go#L232)) or a dial ([L271](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/transport.go#L271)). A listening endpoint calls `Listen` on every binding as it is built ([`endpoint.go` L237-L238](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/endpoint.go#L237-L238)), so it has one receive goroutine per binding. A dial-only endpoint initializes only the binding it dials through ([L442-L448](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/endpoint.go#L442-L448)). Measured: every `rl` and `rlr` receiver printed two `probe1866: role=recv` lines. One thread carried the data, and the other used under a millisecond of CPU per run.
- **Shared by candidates, never by Wires.** During setup the receive goroutine serves every candidate on its binding, up to 8 ([`native.go` L100](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/native.go#L100)). Selection closes every other candidate and admits no new one ([`endpoint.go` L482-L489](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/endpoint.go#L482-L489)), and the promoted Wire owns the endpoint ([`native_promotion.go` L237-L239](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/native_promotion.go#L237-L239)). So after promotion the receive goroutine carries exactly one connection, the Wire's, and in wiremux no two Wires ever share a `Transport`.
- **Lifetime: the endpoint's.** Closing the Wire closes the endpoint ([`promote.go` L386-L405](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/promote.go#L386-L405)), which closes every `Transport` ([`endpoint.go` L569-L573](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/endpoint.go#L569-L573)), and `Transport.Close` waits for `listen` to return ([`transport.go` L557-L571](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/transport.go#L557-L571)).
- **The run loop and the send goroutine are per connection.** A dialed connection's `Conn.run` starts in the dial ([`transport.go` L383-L384](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/transport.go#L383-L384)), an accepted one's in the server ([`server.go` L1049](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/server.go#L1049)), and `Conn.run` starts the send goroutine ([`connection.go` L584, L620-L624](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L620-L624)). Both live as long as the connection.

**The adopted pattern for each** (lock, raise, check the base priority, re-check about once a second, stand down, restore before unlocking):

- **Run loop:** the same shape as the adopted send hook, at the top of `Conn.run` ([`connection.go` L584](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L584)). The run loop already computes `now` on every pass, so the one-second re-check of the base priority can ride on it. A stand-down restores the class and unlocks for the rest of the connection, and the deferred undo restores before unlocking. One per Wire.
- **Receive goroutine:** at the top of `Transport.listen` ([`transport.go` L648](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/transport.go#L648)), with four differences:
  1. **It is per binding, not per Wire.** A listening endpoint would lock one thread per binding, idle bindings included. An idle raised thread costs no CPU while parked, but it does hold an OS thread for the endpoint's life.
  2. **It exists before any connection does, and serves the setup candidates.** So a per-connection switch doesn't fit. The switch would be per `Transport` (a `Configure…V1` capability called when `prepareTransport` builds it, [`endpoint.go` L208-L247](https://github.com/GridSwarm/wiremux/blob/870295a497ef862fa51f523c5f64d0eaf06dbed8/internal/nativequic/endpoint.go#L208-L247)). Or the fork could raise only the winning `Transport`'s goroutine at selection: the candidate group's `selectWinner` knows which connection won, and so its `Transport`.
  3. **The re-check runs inside the read loop**, every N packets or on a clock check, while the goroutine is receiving. A parked goroutine needs no check.
  4. **A stand-down lasts for the `Transport`'s life**, and the undo runs before `listen` returns, which `Transport.Close` waits for.
- **The lock is part of the pattern, and with the class it costs under oversubscription** (section 3). A macOS class belongs to a thread, and Go moves goroutines between threads, so a raised goroutine has to be locked. The lock alone was free, because a locked default-class goroutine falls behind and seldom parks. Raised, the run loop was still woken 28,000–37,000 times a second at 18 spinners, each wake a handoff to its locked thread (**measured**, `X1`). Any receiver hook would inherit the two thread switches per wake, each waiting on Go's default-class threads.

## 7. What follows

**Proposed grilling:** *Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?*

Beside the adopted raised send goroutine, raising the receive goroutine to user-initiated on `tb` adds +11–13% idle on the receiver-bound batched-send stack and +3–24% when the receiving Mac's performance cores are full (8 spinners on m4mini). Raising the run loop too adds +6–17%. But both lose when the Mac is oversubscribed (18 spinners): down to −20% for the receive goroutine and −24% with the run loop, and the run loop raised alone loses 18–19% on both stacks. The loss comes with the class on a locked thread; the lock alone is free. With the receive goroutine raised alone, the transport also outruns the application's default-class reader, which loses 4–5% of Datagrams at moderate load. The grilling decides among three options: no receiver class (the receiver closes as not needing one); a receive-goroutine raise with a stand-down when the receiving Mac is oversubscribed (which signal, which gate); or research first (a Go execution trace of the loss, a lock-free design). It also decides whether the adopted send-thread raise should stand down on the receiving peer, where it costs up to 7% at 18 spinners. It blocks [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801).

## Method

- **Build** (one binary for the receiver and the sender, the arm in the receiver's environment; nothing pushed):
  - wiremux: #1857's probe `bef05a64`, plus local commit `3f741c11`. It adds a `probe1866` result object, the fork's snapshot of its queue settings and discards, its hooked threads and its sampled stretches, and the efficiency-core share of #1861's receive windows (`-nlistenwin`).
  - fork: #1857's copy at `d78d71b`, plus #1861's unprocessed-queue drop counter (`6cc41bb`, `1053513`), plus this note's `b912866`:
    - receive-goroutine and run-loop hooks (`WIREMUX_PROBE_RECVQOS`, `WIREMUX_PROBE_RUNQOS`) in the adopted pattern, without the periodic re-check (the sshd context's ceiling never changes);
    - #1853's send hook registering its thread;
    - per-hooked-thread CPU on each core type (`PROC_PIDTHREADCOUNTS`);
    - stretch samplers for the run loop and the send goroutine (`WIREMUX_PROBE1866_SEGS=64`);
    - the bundle's queue depths as settings (`WIREMUX_PROBE1866_DGRAMQ`, `WIREMUX_PROBE1866_UNPROCQ`, both 1,024 here) with a received-Datagram discard counter.
  - The mechanism set's binary added `9bc3434`, a lock-only mode for the two hooks.
  - go1.27.2. Every receiver ran `-threads -schedlat -nlistenwin 256 -nqdepth 256`, the same in every arm.
- **Campaign `M1`:** 48 cells (4 arms × 2 shapes × 2 kinds × 3 load steps), three 10 s runs each. Each block (one load step, shape and kind) runs its four arms back to back in an order that rotates each repetition, and the repetitions rotate the block order. 15 s of settling followed each loaded run.
  - One claim, 03:34:47–06:57:06Z, including two YIELD pauses for a peer's review job (03:58:24–04:31:15Z and 04:49:47–05:48:40Z).
  - The quiet gate before each run required mbp128 at 4 or fewer busy cores and m4mini at 3 or fewer (1 s `top` samples). From 04:33Z it also required no foreign heavy work on mbp128 (Go builds and tests, the compiler and linker, linters, and RAS review jobs and their reviewer agents). A RAS-only tree under 10% of a core over 5 s counted as quiet.
- **Quarantine and re-runs (`M1R`):**
  - Eight of `M1`'s 142 completed runs overlapped foreign heavy work on mbp128: another session's `go test`, `go build` and compile from 03:50Z, and reviewer agents.
  - Two runs never ran. Their gate processes were stopped before any load started, when the gate rules changed under them.
  - Each of those ten cells was re-run once, in its original order, at the end (`M1R`, 06:57–07:06Z), and the re-run replaced the original in the medians. The quarantined originals are reported in the evidence, not pooled. Five other `M1R` re-runs, of runs that overlapped only an idle RAS process, are reported but not pooled.
  - Every cell has three counted runs. One counted run fell outside 0.8–1.2× its cell's median: `r1-l8xs-rl`, during the DEVONthink period (section 5).
- **Checks on every counted run:** both coalition checks passed. Each arm's expected threads were raised to base priority 37 and stayed there, with no unexpected hook. Every spinner was gone at the run's end. Both peers ran 1,024-entry queues.
- **Mechanism set `X1`** (not gate-grade): the two 18-spinner Datagram blocks, five arms (`rs`, `rl`, `rk`, `rr`, `rkr`), two runs each (the parent session trimmed it from three, for time), 07:29:31–08:07:15Z, with a YIELD 07:33:36–07:49:37Z. Binary `bin/q1866x` (fork `9bc3434`, which adds only the lock-only mode; built at 05:49Z while `M1`'s gate held). The gate was `M1`'s. No run overlapped foreign heavy work, and every arm's hooks checked out (`rk`/`rkr`: locked at base priority 31).
- **Clean control `C1`** (the parent session's request): the `rs` arm, both shapes and kinds, 0 and 8 spinners, three repetitions planned, run only after m4mini's non-rig background stayed at or under 0.5 core for 3 minutes (`settle.sh`, `ps` every 20 s; settled at 07:09:38Z), with a per-run receiver gate of 1 busy core that stops the set after 30 waits. It ran 07:09:52–07:29:16Z: 16 runs (two full repetitions), then `mediaanalysisd` returned and the gate stopped it.

## Limits

- **One receiving Mac, and a working one.** m4mini's own background (about 1.5 cores, part of it at user-initiated) ran under every step. The step-0 rates don't track it, but no step was truly idle (section 5).
- **Synthetic load.** The spinners are one program's busy threads at the default class. A real receiving Mac's load blocks and wakes, and some of it outranks user-initiated (a frontmost app).
- **Medians of three.** Arm differences of a few percent sit inside the runs' spread in most cells. The signs that matter (gains at 8 spinners, losses on batched sends at 18) hold in every repetition.
- **The faster receive call under load is unexplained.** It needs kernel stacks, which need root.
- **Placement from counters, not a profiler.** The receive goroutine's share comes from its own windows; the run loop's and send goroutine's from 1-in-64 sampled stretches; Go's other threads only from `-threads`, which lists the eight busiest.
- **No periodic re-check in the probe hooks.** A daemon context never loses its ceiling, so the gate-relevant stand-down paths weren't exercised.
- **The receiver's application reader is the rig's.** It is one default-class goroutine reading Datagrams. A consumer that reads more slowly or more quickly would see different discard rates.

## Implications for the map

- **For [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801):**
  - A busy receiving Mac doesn't slow the batched-send stack. It runs 6–28% faster. It costs the batched-receive stack 1–9% when its performance cores are full and 13–22% when the Mac is oversubscribed. A macOS target measured with an idle receiver therefore overstates a heavily loaded one only on the fastest shape.
  - Under receiver load the 1,024-entry received-Datagram queue discards 0.3–2.4% of Datagrams with the receive goroutine at the default class (`rn`, `rs`). The receive slice's loss rule 2 (≤ 0.01%, [Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863#issuecomment-6235627888)) holds only on an idle receiver. That rule's gate should say so, or the consumer's reader has to keep up.
- **For [Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858):** the adopted raise also applies to the receiving peer's send goroutine, which sends acknowledgments. There it costs other work nothing (±2%), is neutral at 8 spinners, and costs 2–7% at 18 (clear in one of four cells). Its gate measured the sender only, so a receiver-side row (18 spinners on the receiving Mac) is worth adding.
- **For the receiver itself:** the lever isn't safe to adopt as the send hook was. Its gain at moderate load (+3% to +24%) has a matching loss under oversubscription (down to −24%, seven of eight cells lower). With only the receive goroutine raised, the application's reader loses 4–5% of Datagrams at moderate load. The receiver does not close as needing no class, but it isn't ready for a decision either: the grilling below decides between those and a load-aware stand-down.

## Open questions

These are candidate tickets.

1. **Why does a busy Mac's receive call cost half as much per datagram?** On performance cores, instructions per cycle double while the clock rises 4%. Kernel stacks (root) would show whether the socket lock's contention with the input thread fades. If an idle receiver could get the same, that would be a lever.
2. **Why does a raised, locked receiver goroutine lose when the Mac is oversubscribed?** A Go execution trace of the receiver at 18 spinners (`-trace`, `rs` against `rl` and `rr`) would show whether the raised goroutine waits for a processor handoff, as section 3 suggests. A design that never parks the raised thread, such as a blocking receive call on a locked thread, which [How many busy goroutines can a consumer run before its native Wire stalls, and what restores it?](https://github.com/GridSwarm/wiremux/issues/1865#issuecomment-6244783748) sized at its cliff, would avoid the handoff.
3. **Should the received-Datagram queue's discards under receiver load be a consumer requirement** (read fast enough), a wiremux signal, or a larger queue?

## Evidence

`native-gap-evidence/1866-receiving-mac-load/` (README.txt indexes it):

- `M1/`: the campaign (142 runs, two cells never ran). Each run has `cmd`, `gate`, both result lines, coalitions, spinner lines, both Macs' process snapshots (`top.*`, `recv.top.*`, `recv.mid`), `foreign.before/after` and interface counters. Also `rows.jsonl`, `tables.md`, `specs.txt` and `waits.log`.
- `M1R/`: the re-runs. `M1.pooled.jsonl` and `M1.quarantined.jsonl` hold the counted and quarantined rows; `M1.pool.txt` and `M1.overlaps.txt` record the decisions.
- `X1/`: the mechanism set (20 runs). `C1/`: the clean control (16 runs; `settle.log`).
- `S0/`: the smoke runs, never evidence.
- `bin/q1866/` and `bin/q1866x/`: the binaries and their recipes. `qgf-1866/`: the fork copy, a git repository with the probe commits.
- `tools/`, `scripts/` (`campaign.sh`, `run.sh`, `chain.sh`, `sum.py`, `agg.py`, `pool.py`, `overlaps.py` and the rest), `specs/`.
- Logs: `coordination.log`, `overlap.log`, `foreign.log`, `hostlog.txt`, `claim.log`, `chain.log`.

## Coordination

Peers shared the hosts, and the parent session coordinated with them. A quic-go-fast session ran two RAS consider jobs on mbp128 through the YIELD protocol (the campaign paused between runs). A GridCast session's tests and review overlapped eight early runs, which were quarantined and re-run. A second GridCast session waited for the pair. The parent session relayed m4mini's background facts (DEVONthink at 47, Screen Sharing, `mediaanalysisd` at 37/20) from two read-only `ps` samples. Every wait and decision is in `coordination.log`.
