# PRD-0001: wiremux v1 Connectivity Kernel

## Status

Accepted.

## Context

ADR-0001 establishes wiremux as the GridSwarm connectivity primitive:
relay + STUN + hole-punch + transport upgrade, identity-agnostic, dual-
mode rendezvous, deployable as a server kit. This PRD specifies the v1
public API surface, the auth-context interface that identity layers plug
into, and the package boundaries.

wiremux v1 is a fresh design. Downstream consumers are still unreleased,
but codemux and tapmux have already exercised the consumer shape: codemux
produces PAKE-derived auth material, while tapmux carried its own relay to
channel to upgrade assembly before the root wire dialer existed. Existing
tapmux source under `internal/relay`, `internal/relayurl`,
`internal/holepunch`, `internal/natdisco`, and `internal/quicutil` remains
**reference material**, alongside iroh's connectivity stack and Syncthing's
relay protocol; it is no longer the normative blueprint.

## Goals

- Define wiremux's v1 public API surface at the package level.
- Specify the `AuthContext` interface (with HKDF-style `KeyExporter`)
  that codemux's `pake` and (future) keymux's `noise` packages
  implement.
- Specify the dual-mode rendezvous protocol (ephemeral and long-lived).
- Specify the transport interface so consumers can plug in transports
  beyond the default QUIC.
- Specify the relay endpoint URL grammar (`wiremux://host:port`, no
  fingerprint) and the client-config pinning mechanism.

## Non-Goals

- Identity (PAKE handshake, Noise handshake, peer-key formats).
- Mesh-coordination concerns (peer directory, ACLs, mesh routing,
  federation between relays).
- Application protocol DTOs.
- Polyglot bindings beyond Go.

## Reference Material

The following are reference shapes the implementation may draw on. None
are normative blueprints.

- **tapmux's `internal/relay`, `internal/relayurl`,
  `internal/holepunch`, `internal/natdisco`, and `internal/quicutil`.**
  The unreleased prior implementation. Useful for "how was this
  problem solved before," not for byte-for-byte compatibility.
- **iroh's connectivity stack.** Long-lived node keys, NAT traversal
  via STUN + hole-punch, QUIC transport, relay fallback. The closest
  existing library shape for wiremux at production maturity.
- **Syncthing's `relay.syncthing.net` protocol and global discovery
  service.** Mature reference for long-lived peer-rendezvous design.
- **TLS 1.3's `ExportKeyingMaterial` and Noise's `CipherState.Export`.**
  The canonical exporter pattern that `connect.AuthContext.Exporter()`
  follows.

## Package Layout

```
wiremux/
├── wiremux                 # Consumer entry point: Dial, Wire, Authenticator
├── wiremuxtest/            # Supported consumer-importable connectivity test fixtures
├── relay/                  # Relay client + server, dual-mode
├── relayurl/               # Endpoint URL parsing, fingerprints
├── stun/                   # STUN client + responder
├── connect/                # Candidate exchange, hole-punch, transport
│                           #   upgrade negotiation, AuthContext +
│                           #   KeyExporter + Transport contracts
├── transport/
│   └── quic/               # Default QUIC transport implementation
├── channel/                # Encrypted byte-stream over AuthContext
└── cmd/
    └── wiremux-server/     # Relay + STUN server binary
```

## Public API Surface

### `wiremux`

The root package is the consumer entry point for one outbound wire:

```go
type Authenticator interface {
    Authenticate(ctx context.Context, relayConn io.ReadWriteCloser) (connect.AuthContext, error)
}

type AuthenticatorFunc func(context.Context, io.ReadWriteCloser) (connect.AuthContext, error)

func StaticAuth(auth connect.AuthContext) Authenticator

func Dial(ctx context.Context, relayURL string, id relay.RendezvousID, auth Authenticator, opts ...Option) (*Wire, error)

func WithAuthContextReleaseErrorHandler(func(error)) Option
```

`Dial` owns the formerly consumer-assembled sequence: parse the relay URL,
infer ephemeral or long-lived rendezvous from the concrete identifier type,
dial the relay, invoke the identity handshake on the paired relay stream,
construct the encrypted channel, run `connect.Negotiator.Upgrade`, and return
an application-ready `Wire`. For ephemeral `relay.SessionID` rendezvous, `Dial`
starts a bounded, best-effort, non-fatal `relay.ConsumeSession` call after local
upgrade success, after eligible identity failure once relay pairing has
occurred, or after one-shot post-success failure when the authenticator has
declared that success spends the rendezvous. This consume attempt is unilateral:
no lower-level peer capability is negotiated. When both peers use
`wiremux.Dial`, direct success keeps the
obsolete relay path open in the background for that consume attempt; relay-path
success starts consume before returning and `Wire.Close` waits for the consume
attempt, not the optional error handler. Unmarked terminal identity-failure
return may wait up to the lesser of the default consume timeout and the
remaining `Dial` deadline while consume runs, and the counterpart may not
observe the failure until that bounded consume window completes. Identity layers
may also declare rendezvous disposition with `connect.MarkRendezvousSpent`,
`connect.MarkRendezvousRetryable`, `connect.RendezvousDisposition`, and the
optional `connect.OneShotRendezvous` capability. Marked-spent identity failures
consume with the without-cancel default budget and may wait after `Dial` context
cancellation or deadline, overriding context cancellation and relay-I/O
heuristics; marked-retryable identity failures never consume; and unknown
disposition keeps the existing heuristic. Context cancellation, deadline
identity failures, and relay I/O closure during unmarked identity leave the
SessionID retryable when the error tree is purely retryable, including
contextual wrappers or joins whose leaves are all relay I/O. Malformed, cyclic,
or traversal-truncated unmarked trees are consumed only when a non-I/O
domain/authentication leaf is confirmed; relay-only or ambiguous malformed trees
remain retryable. Unmarked terminal identity/authentication errors consume after
pairing when that non-I/O domain/authentication leaf is confirmed; marked-spent
errors consume regardless of cancellation or relay-I/O wrappers, and
marked-retryable errors never consume. If unmarked terminal errors also carry
relay I/O, they must include the non-I/O domain/authentication error, for example
`errors.Join(domainErr, ioErr)`.
Downstream identity layers should return wrong-secret failures as
domain/authentication errors, not bare relay I/O. For authenticators that
implement `connect.OneShotRendezvous`, post-success auth-context validation,
channel, upgrade, and nil-stream failures attempt bounded consume with the
without-cancel default budget before `Dial` returns. A nil error from an
authenticator requires a non-nil auth context; a one-shot authenticator that
returns `(nil, nil)` is treated as a spent post-success `ErrNilAuthContext`
failure and attempts the same bounded consume. If context cancellation or
deadline expiry is observed after a non-one-shot authenticator returns
`(nil, nil)`, the error tree retains both the context error and
`ErrNilAuthContext`; disposition remains unknown and the ephemeral SessionID
remains reusable. The nil auth context remains discoverable because its
`(nil, nil)` result violates the authenticator contract independently of
context termination; cancellation or deadline expiry does not by itself prove
that the rendezvous was spent. The same dual-error classification applies to
long-lived PeerID rendezvous, which has no ephemeral consume coordinator, while
one-shot authenticators retain their separate post-success policy. A mixed
lower-level
`connect.Negotiator` peer can close the relay path before consume reaches the
relay, leaving the SessionID reusable until normal expiry. Failed best-effort
consume can also leave the SessionID reusable until normal expiry. Consume
failures remain non-fatal and are ignored by default; callers can install
`WithConsumeSessionErrorHandler` for logging or metrics. For unmarked heuristic
terminal identity failure after relay pairing, `Dial` waits for the deadline-capped
bounded consume attempt, then invokes that handler asynchronously and returns
without waiting for the handler. Marked-spent identity failures and one-shot
post-success failures use the without-cancel default budget before `Dial`
returns. The handler may be invoked concurrently across peers and should return
promptly. Relay fallback is a
successful `Dial` result, not an error.

Every non-nil `Authenticator.Authenticate` result transfers exclusively to its
direct caller, including a partial context returned with an error. Root `Dial`
therefore owns and defensively releases `(auth, err)` results, owns `(auth,
nil)` through all later establishment failures, and transfers successful
ownership to the returned `Wire`. Failed-Dial release errors remain non-fatal
telemetry through `WithAuthContextReleaseErrorHandler`; they do not change
failure stage or rendezvous disposition. Aggregate `Wire` teardown logically
revokes auth access before carrier cleanup and joins immediate release failures
into `Wire.Close`.

`StaticAuth` is the BYO-auth adapter for callers that already hold a complete
`connect.AuthContext`. Each returned authenticator is single-use: it returns that
auth context at most once and then fails with `ErrAuthContextReused`, preventing
accidental reuse through a repeated `Dial` with the same authenticator. Callers
must not create multiple `StaticAuth` wrappers for the same `AuthContext` or key
material, because channel nonces start at zero.
Constructing `StaticAuth` does not itself transfer ownership. Once its
`Authenticate` returns a non-nil context, callers must stop using or cleaning
up that context; when the caller is `Dial`, cleanup belongs to `Dial` or the
resulting `Wire`.

`Wire` implements `io.ReadWriteCloser` and exposes the common path question
plus diagnostics:

```go
func (*Wire) Direct() bool
func (*Wire) Info() WireInfo
func (*Wire) Auth() connect.AuthContext

type WireInfo struct {
    Path           connect.UpgradePath
    FallbackReason connect.UpgradeFallbackReason
    SelectedPair   *connect.CandidatePair
    ProbeRTT       time.Duration
}
```

`Wire.Auth` returns a stable non-owning wiremux view, not the producer-native
dynamic value. It deliberately hides `connect.AuthContextReleaser`, preserves
`connect.ChannelUseClaimer` when supported, and revokes access at aggregate
teardown. After revocation, key and binding accessors return nil and retained or
new exporters return `connect.ErrAuthContextReleased` from `Derive`.

Per [ADR-0009](../adr/adr-0009-optional-datagram-capability.md), `Wire`
optionally exposes a carrier-bound Datagram plane without changing its reliable
`io.ReadWriteCloser` behavior:

```go
func (*Wire) Datagrams() (*Datagrams, bool)

func (*Datagrams) MaxPayload() int
func (*Datagrams) Send(ctx context.Context, payload []byte) error
func (*Datagrams) Receive(ctx context.Context) ([]byte, error)

var ErrDatagramTooLarge error
```

`Datagrams` returns `(nil, false)` when the established carrier does not
support the capability. Absence is not an error and does not affect reliable
I/O, path selection, relay fallback, or teardown. The returned handle is a
concrete borrowed view with no `Close`; `Wire.Close` remains the only lifetime
owner.

Discovery is a lifetime-stable snapshot. Repeated successful calls return the
same non-nil pointer, including after local or peer teardown, and `MaxPayload`
keeps its frozen value. Teardown never changes prior presence into absence;
`Send` and `Receive` on the stable handle return `ErrWireClosed`.

For `Datagrams` methods, `ErrWireClosed` means that the borrowed Datagram view
is closed. It includes aggregate Wire close or peer teardown and a classified
reliable-read outcome that closes only the bidirectional Datagram gate while
reliable writes remain usable. It does not by itself assert that every reliable
direction is closed. The implementing PR updates the root sentinel's godoc to
state this plane-specific meaning without changing existing reliable-I/O
classification.

`newWire` snapshots `UpgradeResult.Datagrams` during construction, creates and
stores that one stable root handle, and starts its lifetime monitor. It never
rediscovers support by asserting `connect.DatagramCapable` on
`UpgradeResult.Stream`; both upgrade roles intentionally strip optional stream
interfaces after extraction and expose only the explicit result field.

`MaxPayload` is the lifetime-fixed exact local-outbound ceiling for the complete
consumer payload after wiremux framing. It governs this peer's send admission,
not inbound delivery, and is not an MTU or delivery promise. `Send`
rejects a larger payload locally and synchronously with an error satisfying
`errors.Is(err, ErrDatagramTooLarge)`, before queue admission and without
fragmenting or perturbing the Wire. The error text includes the supplied and
maximum sizes; no exported structured detail type is required. Empty consumer
payloads are valid.

`Send` and `Receive` preserve atomic message boundaries and are safe for
concurrent use by multiple goroutines. A send yields at most one complete
receive or no receive; partial payloads are never exposed. No delivery-order
promise exists, including for sequential sends from one goroutine or among
concurrent calls. Every delivered payload reaches exactly one `Receive` caller
as a fresh caller-owned slice.

`Send` copies a payload when it admits it to a small bounded wiremux-owned
queue. When that queue is full, the call blocks until admission or context
completion. Success means only accepted for possible transmission; it does not
prove socket transmission or delivery and cannot be revoked. A context that
ends before admission returns its context error and the payload was not
accepted. Concurrent receives are serialized internally so at most one call
waits in the carrier; wiremux adds no second receive queue. Inbound overflow is
an ordinary silent loss at the carrier's bounded receive buffer.

Nil contexts are treated as `context.Background()`. A receive returns either a
payload or an error, never both. A payload already committed to a caller wins a
context race; an error return consumed nothing. Context errors satisfy the
standard context sentinels and do not satisfy `ErrWireClosed`.

`Wire.Close` closes the Datagram gate before today's stream-first aggregate
teardown. Pending and future calls return `ErrWireClosed`; admitted unsent
messages are discarded without flush or linger. Graceful and abrupt peer
teardown also surface as `ErrWireClosed` on this plane while preserving the
underlying cause. Buffered inbound messages at peer teardown may be delivered
or discarded. There is no Datagram EOF or drain promise. Send checks use the
precedence closed Wire, oversize payload, then context/admission; receive checks
closed Wire, then context. `ErrDatagramTooLarge` and context cancellation are
non-terminal. Aggregate teardown occurs when the carrier `Lifetime` terminates.
A lower send that explicitly rejects a payload at or below the frozen ceiling
as too large is an observed carrier contract breach, so the adapter terminates
that lifetime. An invalid lower receive result likewise initiates aggregate
teardown. Other reliable-read outcomes may close the optional Datagram
gate as described below without initiating aggregate teardown.
Other unclassified per-call errors are returned without aggregate teardown
unless the adapter also terminates `Lifetime`. An admitted frame later dropped
silently during transport packing or in the network is ordinary permitted loss
and does not by itself signal a ceiling breach.

The preceding return rule applies only while a caller is still active. Public
`Send` returns after root-queue admission, before the pump's later lower
`SendDatagram` call. A pump-observed at-or-below-ceiling size rejection is the
terminal contract breach above. Any other later lower send error while
`Lifetime` remains active is silent permitted Datagram loss: it cannot revoke
the successful public call, is not latched, and is not returned by a later
call. A direct lower `connect.Upgrade` caller still receives the error from its
own active `SendDatagram` call.

Every supporting lower carrier supplies one cause-bearing lifetime context.
Root wiremux monitors it even when no send, receive, or reliable read is
pending. On cancellation, root preserves `context.Cause`, closes the Datagram
gate under the same admission authority used by `Send`, and starts aggregate
Wire teardown. Once root has observed that terminal signal, no later send may
return successful admission. Per-call cancellation, oversize rejection, and
ordinary Datagram loss do not end the lifetime.

For direct QUIC reliable reads, native EOF remains EOF. A normal remote parent close is classified as EOF only after coherent final-offset publication and complete caller delivery through that offset; if parent teardown wins with unknown final state or unread payload, or the close is a reset, nonzero application close, deadline, or cancellation, the underlying non-EOF error identity is preserved.

Reliable-read outcomes classified as Datagram-gate terminal act after any
returned bytes are reported: authenticated peer close (`io.EOF` from
`Wire.Read`), `ErrWireClosed`, channel authentication or truncation failure,
and transport stream-reset/closure identities. Root closes only the Datagram
gate, preserves the cause, and releases Datagram workers while carrier
`Lifetime` remains active. It does not initiate aggregate teardown or close the
independent reliable write direction; a subsequent reliable `Write` retains
today's behavior. Other direction-local or per-call errors keep their existing
meaning: `channel.ErrStreamEmptyDataFrame` remains a latched
read-side error that does not poison reliable writes or Datagrams. Other
unclassified errors are returned without Datagram-gate closure or aggregate
teardown unless the adapter also terminates `Lifetime`; future gate
classifications must be explicit.

`Wire` I/O callers should handle teardown as a decision ladder:

1. `errors.Is(err, io.EOF)` from `Wire.Read` means clean peer close.
2. Otherwise, preserved channel integrity failures such as
   `channel.ErrAuthentication` or `channel.ErrTruncated` mean authentication
   failure, truncation, or another integrity failure and should be handled
   before treating closure as benign.
3. Otherwise, `errors.Is(err, ErrWireClosed)` means the wire is closed or torn
   down. Post-local-`Close` non-EOF errors on either path may classify here. On
   the relay path, a `Wire.Write` after local `Wire.Close` may preserve
   `channel.ErrClosed` under `ErrWireClosed`. An unclean peer close may instead
   produce `channel.ErrTruncated`, the higher-priority integrity result described
   above, or preserve an underlying network or syscall closure identity under
   `ErrWireClosed`. Direct-path teardown may preserve `net.ErrClosed` or a
   transport-specific cause under `ErrWireClosed`. Other stdlib `net`/`syscall`,
   channel, or transport identities may also remain reachable through
   `errors.Is` and `errors.As`. Returned teardown errors may be wrappers;
   consumers must use `errors.Is`/`errors.As` rather than error equality for
   migration safety.
4. Otherwise, handle the result as another `Read`, `Write`, or `Close`
   failure.

`ErrWireClosed` does not prove clean authenticated shutdown.

Preflight option validation can return configuration sentinels that are not
stage-wrapped: `ErrOptionConflict` may be joined with detail, and
`ErrInvalidEstablishTimeout` is returned bare. Public establishment sentinels
classify Dial-stage errors without hiding underlying package sentinels:
`ErrRendezvous`, `ErrIdentity`, `ErrChannel`, and `ErrUpgrade`. `ErrWireClosed`
is a post-establishment `Wire` I/O sentinel, not a Dial-stage wrapper.
`errors.Is` must keep working for both the wiremux sentinel and the underlying
`relay`, `relayurl`, `channel`, `connect`, stdlib, or transport error.
Sanitization of malformed or typed-nil error trees preserves `errors.Is`
classification but may omit `errors.As` exposure of unsafe concrete wrappers
such as `*net.OpError` or `*os.SyscallError`.

Wrapper options keep ownership-sensitive configuration inspectable:
`WithRelayPin`, `WithRelayTLSConfig`, `WithTransport`, `WithPacketConn`,
`WithTransferredPacketConn`, `WithSTUNServer`, `WithoutSTUN`,
`WithCandidatePolicy`, `WithProbeTimeout`, `WithControlTimeout`,
`WithProbeConcurrency`, `WithRelayOnly`, `WithChannelOptions`,
`WithEstablishTimeout`, and `WithConsumeSessionErrorHandler`. Direct upgrade
defaults to `transport/quic` and an internally owned UDP packet socket.
`WithPacketConn` preserves the `connect.WithUpgradePacketConn` contract.
`WithTransferredPacketConn` selects one packet socket and transfers exclusive
lifecycle responsibility when `Dial` applies it as the effective final
packet-connection option; constructing the option alone does not transfer,
and an overridden socket stays with its prior owner. The caller must not close,
reuse, read from, or write to the effective single-use socket after transfer,
including while `Dial` is running. Retries and concurrent dials require fresh
sockets.

For an effective transferred socket, `Dial` closes synchronously before returning from option or input validation; setup or other error before local commit and before any non-nil transport Dial/Accept stream; and relay fallback in that same window. Close failure does not replace or wrap the original error and cannot turn relay fallback into failure. Local commit or any non-nil Session Dial/TransportListener Accept stream transfers the exact packet claim, including a stream returned together with an error. Later failure uses the stream's synchronous Close as the sole physical disposer; direct success transfers that same claim into the returned Wire. Root settlement reads only this monotonic transfer fact: false applies the configured packet lifecycle and true relinquishes. Error-tree traversal may preserve error classification, sanitization, and retryability, but malformed or traversal-truncated trees never decide packet ownership or Close.
The exact socket reaches `connect` and custom transports unchanged; lower-level
`connect.Upgrade`, gathering, STUN, wire format, and transport negotiation are
unchanged. Unless the caller sets `WithSTUNServer` or `WithoutSTUN`, root
`Dial` treats `relay_host:3478` as a best-effort STUN server. DNS lookup
failure, address-family mismatch, or an invalid default-derived STUN address
skips default STUN and continues with host candidates. Split relay/STUN
deployments must pass the real STUN address explicitly or disable reflexive
gathering to avoid the default probe and its gather-timeout cost when no STUN
responder is present at the relay host.

### `wiremuxtest`

`wiremuxtest` is the supported, consumer-importable test-support package for
identity and application layers built on wiremux. It starts a real TLS 1.3
relay on an OS-selected loopback port, reasserts fixture-owned TLS,
ephemeral-only rendezvous, shutdown, and listener boundaries after caller relay
options, and exposes fixture-scoped `Relay`, `RelayOption`, `StreamPair`,
`DialResult`, and `DialPairResult` APIs. `PairStreams` provides raw paired relay
streams; `DialPair` concurrently calls production `wiremux.Dial` for stable Host
and Client test positions while preserving both owner-native Wire/error
outcomes.

`WithOperationTimeout` is the absolute bound on each fixture operation's active
orchestration; caller `WithEstablishTimeout` options may shorten but not extend
`DialPair`'s concurrent Dial phase. Separate finite late-result observation and
cleanup budgets may extend failure reporting after orchestration times out.
Successful resources remain owned by the returned pair until explicit,
concurrency-safe, idempotent `Close` or registered `testing.TB` cleanup.
Partial, abandoned, late, and successful Wires and raw streams use finite
fixture-owned cleanup; a blocked close reports a coarse failure and force-stops
the fixture relay so remaining cleanup can continue. Production `wiremux.Dial`
does not currently return a non-nil `*Wire` together with a non-nil error. The
canonical specification records an explicit proof exception in
[codemux issue #260](https://github.com/GridSwarm/codemux/issues/260#accepted-partial-wire-proof-exception-2026-07-11)
and [codemux issue #263](https://github.com/GridSwarm/codemux/issues/263#accepted-partial-wire-proof-exception-2026-07-11):
external-package tests cover every reachable production outcome, while the
package-internal `runWiremuxDial` seam proves the locked partial-Wire ownership
rule. That test preserves the original pointer and error identities while
proving the fixture closes the partial Wire before return; it is intentionally
not claimed as black-box production evidence. Harness
diagnostics expose only allowlisted, redacted categories and never Session IDs,
credentials, certificates, key or exporter material, payloads, or arbitrary
underlying error text.

Physical relay-session consumption and observation remain distinct from
identity-layer spending policy. `wiremuxtest` does not classify identity
outcomes, re-export identity APIs, or replace production clients. The exact
release-facing ownership, compatibility, security, and lifecycle guidance is in
[docs/RELEASE.md](../RELEASE.md).

### `connect`

This package contains the core auth-context contract and the transport-
upgrade machinery.

**Auth-context contract:**

```go
// AuthContext is the seam between identity layers (codemux, keymux,
// BYO-auth) and wiremux's transport upgrade. Identity layers produce;
// wiremux consumes.
type AuthContext interface {
    // SendKey returns the symmetric key for the channel layer's
    // outbound traffic from the local peer. It must be non-empty,
    // distinct from ReceiveKey, and a valid AES key size: 16, 24,
    // or 32 bytes.
    SendKey() []byte

    // ReceiveKey returns the symmetric key for the channel layer's
    // inbound traffic from the remote peer. Across a two-peer
    // session, peer A's SendKey must equal peer B's ReceiveKey,
    // and peer A's ReceiveKey must equal peer B's SendKey.
    ReceiveKey() []byte

    // SessionBinding returns a domain-separated session identifier
    // mixed into every downstream key derivation.
    SessionBinding() []byte

    // Exporter returns an HKDF-style key exporter rooted in the
    // session's master secret. Transport implementations call
    // Exporter() to derive transport-specific AEAD keys, PSKs, or
    // other keying material without the identity layer needing to
    // know which transport is in use.
    Exporter() KeyExporter
}

// ChannelUseClaimer optionally enforces one irreversible encrypted-channel
// initialization for the context's directional keys.
type ChannelUseClaimer interface {
    ClaimChannelUse() error
}

// AuthContextReleaser explicitly opts retained cryptographic state into
// deterministic cleanup after ownership transfer. Incidental io.Closer does
// not satisfy this purpose-specific capability.
type AuthContextReleaser interface {
    ReleaseAuthContext() error
}

// TransportAuth is the least-privilege, revocable view given to transports.
// It cannot expose directional channel keys or initialize a channel.
type TransportAuth interface {
    SessionBinding() ([]byte, error)
    Exporter() KeyExporter
}

// KeyExporter derives keying material from a session's master secret
// using HKDF-Expand-shaped domain separation. Different (label,
// context) pairs produce independent keys.
type KeyExporter interface {
    // Derive returns `length` bytes of keying material bound to
    // (label, context) plus the parent AuthContext's SessionBinding.
    // The implementation must mix in the session binding from the
    // parent AuthContext. Calling Derive with the same (label,
    // context, length) on the same exporter returns identical
    // material; different inputs produce independent material.
    //
    // Implementations should be HKDF-Expand-rooted with the parent's
    // master secret as the PRK and (label || 0x00 || context) as the
    // info input. The session binding is mixed in by the parent
    // AuthContext implementation, not by the caller.
    //
    // Labels are printable-ASCII protocol constants and must not
    // contain 0x00, which would make the info framing ambiguous;
    // Derive fails on labels containing NUL.
    Derive(label string, context []byte, length int) ([]byte, error)
}
```

`ErrChannelUseClaimed`, `ErrAuthContextReleased`, and
`ErrAuthContextReleaseTimeout` provide shared classification across identity,
channel, transport, and root teardown boundaries. `NewReleasingAuthContext`
explicitly adapts legacy cleanup callbacks and preserves `ChannelUseClaimer`
when the source implements it. Wiremux-owned auth and transport views revoke
new access immediately, then share one one-second end-to-end budget across
active-call drain and the producer release call; timeout leaves exactly one
deferred physical release obligation.

`connect.NewDirectionalKeys(auth AuthContext)` snapshots the directional
keys, validates the non-empty/distinct/AES-size contract once, and exposes
the canonical hash orientation consumed by both encrypted channel framing and
direct-upgrade role assignment. The cross-peer mirror invariant is named at
this seam but cannot be proven from one local `AuthContext`; asymmetric peers
fail authentication when channel frames are opened.

Hole-punch and transport-upgrade surface:

- `type Candidate` representing a network-address candidate with a `CandidateKind` and a `netip.AddrPort` value.
- `CandidateKindHost` (`host`) is an address directly assigned to the local peer.
- `CandidateKindReflexive` (`reflexive`) is an externally observed address reported by STUN.
- `CandidateKindRelay` (`relay`) represents relay-assisted connectivity.
- Gathered candidates are offers, not proof of reachability.
- `Gather(ctx, opts ...GatherOption) ([]Candidate, error)` — gathers
  local and reflexive candidates using `wiremux/stun`.
- `Gather` requires a caller-supplied `net.PacketConn` for candidates
  intended for hole-punching. Gathering must not hide a temporary UDP
  socket behind the public API, because NAT mappings are socket-bound
  and the later probe/transport upgrade must reuse the same socket.
  `Gather` does not close caller-supplied sockets. Callers must not
  read from the packet socket concurrently while `Gather` is running.
  The caller keeps lifecycle ownership across gathering, probing, and
  transport upgrade; wiremux may temporarily own reads on that socket
  during each operation, but it must not replace the socket when a NAT
  mapping needs to survive to the next phase.
- `Gather` emits `CandidateKindHost` (`host`) and `CandidateKindReflexive` (`reflexive`) candidates only.
- `CandidateKindRelay` (`relay`) remains representable for later negotiation and fallback work.
- Local candidate gathering does not synthesize a relay candidate from an already-open relay stream.
- `CandidateKindHost` (`host`) candidates come from the supplied socket's local binding.
- For a host candidate, a specific local IP yields that address and port.
- A wildcard binding enumerates usable interface addresses with the socket's port.
- Wildcard gathering excludes loopback and link-local addresses by default.
- Explicitly bound sockets may produce loopback candidates for local testing.
- Explicitly bound sockets may produce IPv6 link-local candidates only for bound-single-interface packet sockets.
- That interface supplies the routing scope for later sends and observed-source validation.
- Link-local scope is local-only and is never encoded or sent.
- Wildcard and ambiguous multi-interface link-local candidates are excluded in v1.
- Candidates are de-duplicated by address.
- Host candidates sort before reflexive candidates, and addresses sort deterministically within each kind.
- A configured STUN server adds a `CandidateKindReflexive` (`reflexive`) candidate when discovery succeeds.
- If reflexive discovery fails while the caller's context is active, `Gather` may still succeed.
- It returns host candidates when at least one host candidate exists.
- `Gather` does not fail the whole gather for that best-effort STUN failure.
- Context cancellation, context deadline expiry, invalid options, and total candidate absence remain errors.
- `type Negotiator`,
  `NewNegotiator(channel io.ReadWriteCloser, auth AuthContext) (*Negotiator, error)`
  — exchanges candidates and transport handshake material, assigns
  deterministic dialer/listener roles, and probes direct connectivity
  over an authenticated channel. Construction fails if the auth
  context's directional keys are empty, equal, or not valid AES key
  sizes; the negotiator boundary enforces this through
  `NewDirectionalKeys` rather than relying on `channel.NewChannel`.
- `NewNegotiatorWithTransportAuth(channel io.ReadWriteCloser, auth AuthContext,
  transportAuth TransportAuth) (*Negotiator, error)` lets root `Dial` supply a
  revocable transport view. Lower-level `NewNegotiator` callers retain auth
  ownership and receive an automatically narrowed legacy transport view.
- `type UpgradeOption` for direct-upgrade inputs, including the
  caller-owned packet socket used for probing and transport upgrade,
  transport implementation, optional STUN server configuration,
  bounded probe timing, and candidate policy.
- `type CandidatePair` containing the public local and remote
  `Candidate` values selected for a direct path.
- `type UpgradePath` identifying the active path returned by
  `Upgrade` (`relay` or `direct`).
- `type UpgradeFallbackReason` identifying the coarse reason a relay-path result was selected.
- Fallback reasons include direct upgrade not requested, candidate policy exhaustion, and no usable candidates.
- They also include transport mismatch, structured protocol incompatibility, probe failure, and transport failure.
- Probe-key derivation failure after both peers offer direct upgrade is reported as `transport_failed`.
- `type UpgradeResult` containing the active stream, optional Datagram carrier,
  selected path,
  optional selected candidate pair, observed probe RTT for the
  selected pair when known, and optional fallback reason for relay-path
  results.
- `(*Negotiator).Upgrade(ctx, opts ...UpgradeOption) (UpgradeResult, error)`
  — attempts a transport upgrade and returns the active stream plus
  path metadata. If no packet socket is supplied, `Upgrade` performs
  no direct-path attempt and returns a relay-path result.

The concrete implemented shape is:

```go
type CandidatePair struct {
    Local  Candidate
    Remote Candidate
}

type UpgradePath string

const (
    UpgradePathRelay  UpgradePath = "relay"
    UpgradePathDirect UpgradePath = "direct"
)

type UpgradeFallbackReason string

const (
    UpgradeFallbackNone              UpgradeFallbackReason = ""
    UpgradeFallbackNotRequested      UpgradeFallbackReason = "not_requested"
    UpgradeFallbackPolicyExcluded    UpgradeFallbackReason = "policy_excluded"
    UpgradeFallbackNoCandidates      UpgradeFallbackReason = "no_candidates"
    UpgradeFallbackTransportMismatch UpgradeFallbackReason = "transport_mismatch"
    UpgradeFallbackProtocolMismatch  UpgradeFallbackReason = "protocol_mismatch"
    UpgradeFallbackProbeFailed       UpgradeFallbackReason = "probe_failed"
    UpgradeFallbackTransportFailed   UpgradeFallbackReason = "transport_failed"
)

type UpgradeResult struct {
    Stream         io.ReadWriteCloser
    Datagrams      DatagramCarrier
    Path           UpgradePath
    SelectedPair   *CandidatePair
    ProbeRTT       time.Duration
    FallbackReason UpgradeFallbackReason
}

func WithTransport(transport Transport) UpgradeOption
func WithUpgradePacketConn(conn net.PacketConn) UpgradeOption
func WithUpgradeSTUNServer(addr net.Addr) UpgradeOption
func WithProbeTimeout(timeout time.Duration) UpgradeOption
func WithUpgradeControlTimeout(timeout time.Duration) UpgradeOption
func WithProbeConcurrency(limit int) UpgradeOption
func WithCandidatePolicy(policy CandidatePolicy) UpgradeOption

type CandidatePolicy struct {
    ExcludeLocalInterfaces       []string
    DeprioritizeLocalInterfaces  []string
    ExcludeLocalPrefixes         []netip.Prefix
    DeprioritizeLocalPrefixes    []netip.Prefix
    ExcludeRemotePrefixes        []netip.Prefix
    DeprioritizeRemotePrefixes   []netip.Prefix
    ExcludeKinds                 []CandidateKind
    DeprioritizeKinds            []CandidateKind
}
```

`CandidateKind` is the existing `Candidate.Kind` API defined in
[`connect/gather.go`](../../connect/gather.go), with constants
`CandidateKindHost` (`"host"`), `CandidateKindReflexive`
(`"reflexive"`), and `CandidateKindRelay` (`"relay"`). The v1 probe
packet encoding below maps only host and reflexive candidates to probe
bytes; relay candidates remain representable in the API but are not
valid direct-probe inputs.

Invariants:

- Candidate exchange happens over the authenticated channel, not the
  relay's opaque-byte path. The relay never sees candidate data.
- Candidate exchange carries transport handshake material (for QUIC,
  certificate fingerprints per ADR-0001:DP8) in addition to address
  candidates. This material travels only over the authenticated
  channel.
- When both peers attempt direct upgrade, candidate exchange uses one
  versioned local offer per peer. The offer carries the transport name,
  transport handshake material, fresh probe nonce material, and the
  gathered local candidates. v1 does not split these fields across
  multiple upgrade-control messages. Offers include an ignore-unknown
  extension field for future optional metadata; v1 does not define
  critical extensions, and unsupported critical behavior requires a
  future version bump.
- Upgrade-control messages use a length-prefixed RFC 8949 Section
  4.2.1 Core Deterministic CBOR envelope, per
  [ADR-0002](../adr/adr-0002-upgrade-control-cbor.md), with a strict
  closed subset: definite lengths only, canonical encodings only, no
  tags, no floats, no duplicate keys, no indefinite-length items, and
  bounded byte-string, text-string, map, and array sizes. Unknown fields
  are rejected in core message maps and ignored only inside the explicit
  extension map. Core protocol maps use small integer keys, not text
  keys; the v1 numeric key registry is normative in this PRD and the
  implementation must mirror it exactly and pin golden encodings.
- Every upgrade-control payload is a CBOR map with common fields:

  | Key | Name | Required | Type and bound |
  | --- | --- | --- | --- |
  | `0` | `type` | yes | unsigned integer message discriminator |
  | `1` | `version` | yes | unsigned integer, exactly `1` for v1 |
  | `2` | `extensions` | no | map capped at 16 pairs, 4 KiB encoded size, and maximum extension-value nesting depth 8 |

  The extension map is the only ignore-unknown area. v1 defines no
  critical extensions, so receivers ignore unknown extension-map
  entries that are well-formed and within the bounds below. All
  extension-map keys and values still use the same strict
  deterministic-CBOR subset and size/depth bounds. Each extension-map
  value may nest arrays or maps at most 8 levels deep, counting the
  value itself when it is an array or map; scalar extension values have
  depth 0.
- v1 registered extension keys are:

  | Key | Messages | Value | Absence and invalid encodings |
  | --- | --- | --- | --- |
  | `"wiremux.datagram/1"` | `accepted`, `converged`, `confirmed` | CBOR boolean `true` only | omit when absent; CBOR `false` or any non-`true` value is forbidden |

  The Datagram key is valid only in the listed post-commit messages. A receiver
  that encounters this registered key in any message other than `accepted`,
  `converged`, or `confirmed` rejects the frame as `protocol_mismatch`; the key
  is not unknown and must not be ignored there. Existing phase rules decide
  whether that mismatch can synchronize relay fallback or must fail with no
  active stream. Unknown extension keys remain governed by the ignore-unknown
  rule above.
- v1 upgrade-control message discriminators are:

  | Value | Message | Valid phase | Direction |
  | --- | --- | --- | --- |
  | `1` | `offer` | first phase only | both peers |
  | `2` | `fallback` | first phase or terminal fallback | both peers |
  | `3` | `selected_pair` | after two valid offers and probing | dialer to listener |
  | `4` | `ready` | after accepted selected pair and prepared listener | listener to dialer |
  | `5` | `commit` | after `ready`, before transport phase | dialer to listener |
  | `6` | `accepted` | after commit and successful transport `Accept` (which may have completed before commit) | listener to dialer |
  | `7` | `converged` | after received `accepted` and successful post-commit transport dial | dialer to listener |
  | `8` | `confirmed` | after received `converged` | listener to dialer |

  A message type outside this table is a complete
  `protocol_mismatch` fallback case when the frame is otherwise
  complete and the relay channel boundary remains synchronized.
- v1 message-specific field keys are:

  | Key | Name | Messages | Required | Type and bound |
  | --- | --- | --- | --- | --- |
  | `10` | `transport_name` | `offer` | yes | ASCII text, 1 to 64 bytes |
  | `11` | `handshake_material` | `offer` | yes | byte string, 0 to 4 KiB |
  | `12` | `probe_nonce` | `offer` | yes | byte string, exactly 32 bytes |
  | `13` | `candidates` | `offer` | yes | array of 1 to 64 candidate maps |
  | `20` | `fallback_reason` | `fallback` | yes | unsigned integer fallback-reason enum |
  | `30` | `dialer_candidate` | `selected_pair` | yes | candidate map byte-equal to a candidate from the dialer's offer |
  | `31` | `listener_candidate` | `selected_pair` | yes | candidate map byte-equal to a candidate from the listener's offer |
  | `32` | `probe_rtt_nanos` | `selected_pair` | no | unsigned integer, 1 to 9,223,372,036,854,775,807; omit when unknown |

  `ready`, `commit`, `accepted`, `converged`, and `confirmed` carry only the common fields. Message-specific fields outside the receiving message's schema are unknown core fields and are rejected. A `selected_pair` whose candidates were not previously offered, are not valid for v1 probing, or do not match the dialer and listener roles is a `protocol_mismatch` fallback case before the direct-upgrade commit point. A `probe_rtt_nanos` value of zero is invalid on the wire; when the selected-pair RTT is unknown, the field is omitted.
- Candidate maps use their own closed numeric registry:

  | Key | Name | Required | Type and bound |
  | --- | --- | --- | --- |
  | `0` | `kind` | yes | unsigned integer: `1` host, `2` reflexive |
  | `1` | `addr_port` | yes | byte string: `addr_family || ip_bytes || u16be(port)` |

  `addr_port` uses the same candidate address encoding as the probe
  transcript below: seven bytes for IPv4 and nineteen bytes for IPv6.
  Relay candidates are representable in the public API but are not
  valid v1 upgrade-control candidates. An offered v1 candidate is valid
  only when `kind` is host or reflexive, `addr_port` decodes to a
  valid unzoned `netip.Addr.Unmap()` address with a nonzero port, and
  the address is neither unspecified nor multicast. Loopback addresses
  are valid on the wire only when explicitly offered as unzoned
  addresses. IPv6 link-local addresses are valid on the wire only as
  unzoned addresses paired with the local bound-single-interface socket
  rule above; zones are never sent, and multi-interface link-local
  disambiguation is out of v1. A peer that cannot supply that local
  scope excludes the link-local candidate before offering or probing it.
  Explicit loopback and link-local candidates can succeed only on paths
  where strict observed-source validation matches the offered address. A
  complete offer or `selected_pair` containing any invalid candidate is a
  deterministic `protocol_mismatch` fallback case once the advertised
  frame has been drained.
- Fallback reason enum values in upgrade-control CBOR are:

  | Value | Public reason |
  | --- | --- |
  | `1` | `not_requested` |
  | `2` | `policy_excluded` |
  | `3` | `no_candidates` |
  | `4` | `transport_mismatch` |
  | `5` | `protocol_mismatch` |
  | `6` | `probe_failed` |
  | `7` | `transport_failed` |

  Conforming first-phase `fallback` messages send only
  `not_requested`, `policy_excluded`, `no_candidates`, or
  `transport_failed`; a receiver may synthesize first-phase
  `protocol_mismatch` for a complete but invalid first-phase frame.
  Terminal `fallback` messages send `protocol_mismatch`,
  `transport_mismatch`, `policy_excluded`, `transport_failed`, or
  `probe_failed`.
- Each upgrade-control frame is byte-exact:
  `u32be(payload_len) || payload_cbor`. The four-octet length prefix
  is not CBOR; it is unsigned big-endian and counts only the CBOR
  payload bytes, excluding the prefix itself. Valid payload lengths are
  1 through 65,536 bytes inclusive. Prefix values greater than 65,536
  bytes must be rejected before allocating a payload buffer or reading
  the advertised payload. A zero-length frame is a complete but invalid
  control frame and is handled under the invalid-CBOR/protocol-mismatch
  rule below. Golden encodings include the four prefix bytes.
- Upgrade-control payloads are capped at 64 KiB before allocation.
  Offers carry at most 64 candidates after local policy filtering and
  deterministic ordering; excess lower-priority local candidates are
  omitted. Transport names are capped at 64 ASCII bytes, transport
  handshake material at 4 KiB, probe nonce material is exactly 32
  random bytes per peer, and the extension map is capped at 16 pairs
  and 4 KiB encoded size.
- The transport session is created before candidate exchange so its
  `HandshakeMaterial()` can be included in the local offer. The same
  session is reused for the final `Dial` or `Listen` after candidate
  selection; it is not recreated after probing. If direct upgrade
  falls back, the unused session is closed.
- After direct success, `Upgrade` may close the `Session` once the
  returned stream/listener path owns all state it needs. By contract,
  `Session.Close` must not close or invalidate a connection returned
  by `Dial` or `Accept`.
- Any non-nil stream returned by Session `Dial` or TransportListener `Accept` owns the exact packet socket even when accompanied by an error. Its existing `Close` returns only after bounded stream/parent/transport/exact-packet disposal completes exactly once. A nil stream does not transfer by result.
- After an owned Dial/Listen context is canceled, concurrent `Session.Close` actively unblocks implementation-owned I/O and those operations return promptly. `Session.Close` remains prompt; the attempt owner, not Close, joins and records the definitive operation result.
- If closing an unused transport session fails during fallback,
  `Upgrade` still returns a relay-path result. Session cleanup failure
  is non-fatal cleanup, suitable for future logging or metrics but not
  for breaking an otherwise valid relay session.
- Both peers send the local first-phase upgrade-control message and
  receive the remote first-phase message concurrently. The authenticated
  relay channel used for `Upgrade` must support full-duplex use for this
  exchange; sequential send-then-receive ordering is not the v1 protocol
  shape.
- `Upgrade` has exclusive use of the authenticated relay channel while
  it runs. Callers must not read from or write to the channel
  concurrently with `Upgrade`; after fallback, both peers have
  consumed all wiremux upgrade-control messages and the relay stream
  in `UpgradeResult.Stream` is again application-usable.
- `Upgrade` validates every supplied option value and option combination
  before entering upgrade-control mode. Invalid options return an error
  before creating a transport session, gathering candidates, probing,
  or writing upgrade-control messages. This validation is unconditional:
  for example, `WithProbeTimeout(0)` is an input error even when no
  packet socket is supplied and no direct attempt would otherwise run.
- Every `Upgrade` call participates in a synchronized authenticated
  upgrade-control exchange before returning a relay stream. After
  validation, `Upgrade` enters control mode by sending exactly one
  first-phase control message while receiving the peer's first-phase
  message: either a direct `offer` or a first-phase `fallback`.
  `fallback` is a complete authenticated upgrade-control message whose
  payload carries the local coarse fallback reason.
- A peer sends first-phase `fallback` instead of `offer` when local
  setup cannot or must not offer a direct path: no packet socket
  (`not_requested`), transport session setup failure
  (`transport_failed`), no usable local candidates (`no_candidates`),
  or local policy exhaustion before any pair is possible
  (`policy_excluded`). A first-phase fallback carries no transport
  handshake material, probe nonce, or candidates for fields that were
  not produced.
- If either peer's first-phase message is `fallback`, both peers return
  a relay-path result only after sending their own first-phase message
  and consuming the peer's first-phase message. No extra acknowledgement
  is required in this phase because both sides know the only
  outstanding upgrade-control frame has been consumed.
- A complete first-phase frame that is zero-length or rejected by the
  strict CBOR/message schema above is treated as the peer's first-phase
  `protocol_mismatch` fallback reason, provided the full advertised
  frame has been drained and the relay boundary remains synchronized.
  The receiver still sends its own first-phase message if it has not
  already done so, consumes the invalid frame, applies first-phase
  fallback precedence, and returns a relay-path result; it does not
  start the later terminal fallback handshake because terminal fallback
  exists only after two valid first-phase offers. If the frame is
  truncated, oversize, or otherwise leaves the channel boundary
  ambiguous, `Upgrade` returns a public error with no active stream.
- If both first-phase messages are direct `offer`s, any later relay
  fallback uses a terminal fallback handshake until the local
  direct-upgrade commit point. The peer that first decides to abandon
  direct upgrade sends a terminal `fallback` control message and keeps
  consuming upgrade-control frames until it receives the peer's terminal
  `fallback` or an internal terminal-fallback budget expires. A peer
  that receives terminal `fallback` before local commit and before any non-nil
  listener `Accept` stream stops probing or transport work, sends its own terminal
  `fallback`, drains the current control frame, and returns a relay-path result.
  Application bytes may
  resume on the relay stream only after the local terminal fallback has
  been sent and the peer's terminal fallback has been received. If the
  reciprocal terminal fallback does not arrive before the internal budget
  expires while the caller context remains active, `Upgrade` returns a
  public error with no active stream and may close the relay channel so
  ambiguous control bytes cannot leak into application traffic.
- Probe-key derivation happens only after both first-phase messages are
  valid direct `offer`s, because the exporter context includes both
  peers' probe nonce material. If `AuthContext.Exporter().Derive`
  returns an error while deriving the probe HMAC key, the peer sends
  terminal `fallback` with reason `transport_failed`, consumes the peer's
  terminal fallback under the synchronized terminal-fallback rule above,
  closes the unused transport session, and returns a relay-path result.
  This is not `probe_failed`, because probe-key derivation fails before
  candidate-pair evaluation or probe setup begins.
- Fallback reason attribution is deterministic but remains coarse.
  Each peer tracks an independent local fallback reason, if it has one,
  and the peer fallback reason received over upgrade control, if any.
  A peer that sends terminal fallback only because it received terminal
  fallback first adopts and echoes the received reason; a peer that has
  already independently decided to fall back sends its own reason. When
  exactly one independent reason exists, both peers report that reason.
  When both peers independently send fallback in the same phase with
  different reasons, both peers select the public
  `UpgradeResult.FallbackReason` by deterministic precedence over the
  two reasons. For first-phase fallback the precedence is
  `protocol_mismatch`, `not_requested`, `policy_excluded`,
  `no_candidates`, `transport_failed`. For terminal fallback the
  precedence is `protocol_mismatch`, `transport_mismatch`,
  `policy_excluded`, `transport_failed`, `probe_failed`. The selected
  reason is result metadata, not fault attribution; receiving
  `policy_excluded` means the selected reason came from a peer's
  caller-side `CandidatePolicy` exclusions, not that policy rules,
  prefixes, or interface names were exchanged.
- Caller cancellation is the only public abort that may skip the
  synchronized fallback handshake. If the caller context ends before
  the peer's required fallback frame is consumed, `Upgrade` returns the
  context error with no active stream and may close the relay channel so
  ambiguous control bytes cannot leak into application traffic.
- Role assignment is deterministic and computed independently by both peers
  from material they already share: `connect.DirectionalKeys` compares
  `SHA-256(SendKey())` to `SHA-256(ReceiveKey())` lexicographically. A peer
  whose send-key hash is greater takes the dialer role; otherwise it listens.
  Mirrored peer key material gives opposite orientations, so exactly one peer
  dials and one listens at the transport layer. Simultaneous open is resolved
  during candidate exchange, before any transport handshake begins.
- `SendKey()` and `ReceiveKey()` must be non-empty, distinct, and valid AES key
  sizes. `NewDirectionalKeys` enforces this once, and both `NewNegotiator` and
  the `channel` constructors consume that validation at their boundaries; BYO
  auth contexts that omit direction keys, supply one symmetric key for both
  directions, or supply non-AES-sized keys are rejected before candidate
  exchange or encryption happens.
- Candidate exchange includes the local transport's `Name()`. If the
  peers name different transports, the upgrade aborts before any
  handshake material is used and `Upgrade` returns a synchronized
  relay-path result as a normal fallback rather than a public
  `Upgrade` error.
- Upgrade attempts have bounded internal timeouts. Direct failure may return a synchronized relay-path result only while neither local commit nor any non-nil Dial/Accept stream has occurred. After either boundary, transport or carrier-validation failure returns `ErrUpgradeTransportNotConverged`, the zero `UpgradeResult`, and no active stream.
- Timeout behavior has one hard public cancellation boundary: the caller's context. If the caller context ends, `Upgrade` returns that context error. Internal gathering, offer exchange, probing, and pre-commit transport-setup sub-budgets are bounded; if one expires while the caller context remains active and neither local commit nor a non-nil Dial/Accept stream has occurred, `Upgrade` falls back to a relay-path result with the appropriate fallback reason. Once commit or a non-nil stream occurs, a transport budget expiry returns `ErrUpgradeTransportNotConverged`, the zero result, and no active stream. The public tuning surface exposes a coarse probe timeout for transport setup and probing, plus a separate upgrade-control exchange timeout for peer-arrival and control-frame skew.
- Caller cancellation is an abort path, not a relay fallback. On
  caller cancellation or deadline expiry, `Upgrade` returns no active
  stream. If cancellation occurs after upgrade-control exchange has
  begun or otherwise leaves channel state ambiguous, `Upgrade` may
  close the relay channel as cleanup rather than returning it.
- `Upgrade` returns public errors for invalid caller inputs and caller cancellation/deadline expiry. Supplying a packet socket without a transport is an invalid caller input. Ordinary direct-path failure, including no usable gathered candidates, STUN failure without a usable direct path, failed probes, transport mismatch, and transport failure while neither local commit nor a non-nil Dial/Accept stream has occurred, falls back to a relay-path result. After local commit or a non-nil stream result, transport or carrier-validation failure returns `ErrUpgradeTransportNotConverged`, the zero result, and no active stream because relay usability or packet-socket ownership is no longer available for fallback.
- On `Upgrade` error, the returned `UpgradeResult` is the zero value
  and contains no active stream. On nil error, `UpgradeResult.Stream`
  is non-nil.
- Relay-path results include a coarse fallback reason. The fallback
  reason is product/debug metadata, not an error; detailed per-probe
  diagnostics remain out of the initial return type and can be added
  later through optional observability hooks.
- Fallback reason attribution remains coarse. `policy_excluded` is a
  candidate-policy outcome for the peer whose fallback reason wins the
  deterministic precedence rule; it does not expose policy rules or
  interface names. `transport_mismatch` and `protocol_mismatch`
  indicate peer incompatibility. `probe_failed` may be network
  behavior, NAT behavior, adversarial traffic, built-in filtering, or
  address-family incompatibility leaving no probeable pair, and must
  not be treated as reliable blame. v1 does not expose
  `RemoteFault`-style attribution.
- Malformed or unsupported remote upgrade-control messages fall back
  to relay only when the message can be parsed as a complete
  authenticated control message and the relay channel remains
  synchronized and usable. Bad versions, future explicit
  critical-extension signaling, and other structured "cannot upgrade"
  messages are fallback cases with a coarse protocol-mismatch fallback
  reason. Well-formed unknown extension-map entries within v1 bounds
  are ignored, not rejected. A fully received length-prefixed frame
  whose payload is rejected by the strict CBOR subset or message
  schema, including duplicate keys, tags, floats, indefinite-length
  items, non-canonical encodings, unknown core fields, malformed or
  over-bound extension-map contents, invalid offered candidates, or
  zero payload length, is also a `protocol_mismatch` fallback case
  because the advertised frame has been drained. During the first
  phase, that complete invalid frame is handled by the first-phase
  `protocol_mismatch` rule above; after two valid offers, the relay
  stream can remain synchronized only through the terminal fallback
  handshake. Bad or missing probe authentication is reported only as
  `probe_failed`. EOF before the four prefix bytes, EOF before the
  advertised payload bytes, prefix values over 65,536 bytes, or other
  framing states that leave the channel boundary ambiguous are public
  `Upgrade` errors because the relay stream cannot safely be returned
  to application traffic.
- `UpgradeResult` reports only the final outcome: active path, active
  stream, optional established Datagram carrier, selected candidate pair and
  RTT for direct success, or a
  coarse fallback reason for relay. It does not include the full set
  of attempted candidate pairs or per-attempt RTT/failure details;
  those details can expose local network topology and belong behind
  explicit opt-in diagnostics.
- `UpgradeResult.Path` is the primary discriminator. For a direct-path
  result, `SelectedPair` is set, `ProbeRTT` is populated when known,
  and `FallbackReason` is the zero value. For a relay-path result,
  `SelectedPair` is nil, `ProbeRTT` is zero, and `FallbackReason` is
  set.
- `UpgradeResult.Datagrams` is nil on relay fallback and on a direct path whose
  established transport reports capability absence on either role. A
  candidate value is extracted and validated separately by each role when
  `Session.Dial` or `TransportListener.Accept` returns, before reliable-only
  wrappers erase the optional interface or that role advances its next control
  transition.
  It becomes non-nil only after the post-commit extension agreement resolves
  true on both roles. The value is a borrowed carrier view lifetime-owned by
  the established connection path
  represented by `Stream`, not an
  independently closeable resource. It is the low-level framed `connect`
  surface, not the root consumer contract: its payloads include the wiremux
  discriminator, and direct callers own envelope validation plus the lower
  queue and error model.
- `UpgradeResult.Stream` is always a reliable-only `ReadWriteCloser` view after
  optional-interface extraction and never satisfies `DatagramCapable`.
  `UpgradeResult.Datagrams` is the exclusive low-level exposure surface, so a
  synchronized absent result cannot be bypassed by reasserting on the stream.
- Adding `UpgradeResult.Datagrams` is an accepted pre-release Go source-
  compatibility exception for external unkeyed composite literals of
  `UpgradeResult`. Keyed literals and field reads remain compatible. The
  implementation migrates repository-local positional literals and inventories
  downstream occurrences for separate follow-up PRs; the required transport
  interface method sets remain unchanged.
- `ProbeRTT` is the dialer's measured authenticated-probe RTT for the
  selected pair. v1 does not exchange or return both peers' RTT
  measurements; listener-side timing can be exposed later through
  optional diagnostics if needed. A zero `ProbeRTT` on a direct-path
  result means the selected pair's RTT is unknown, not that the
  measured RTT was zero.
- On successful direct transport upgrade, `Upgrade` closes the original
  relay channel and returns a direct-path result whose stream is the
  single active stream. v1 does not keep relay and direct streams alive
  as simultaneous data paths; multipath, relay failback, and
  post-upgrade path migration are reserved for future design.
- The selected candidate pair remains the only authorized direct path
  for the lifetime of the returned v1 stream
  ([ADR-0003](../adr/adr-0003-quic-selected-path-binding.md)). A
  transport that supports path migration or rebinding at its underlying
  protocol layer must not use that feature in v1; changing the remote
  source address after selection is future protocol work, not an
  implicit transport behavior.
- If direct upgrade succeeds but closing the obsolete relay channel
  fails, `Upgrade` still returns the direct-path result. Relay close
  failure after direct success is non-fatal cleanup, suitable for
  future logging or metrics but not for discarding the working direct
  path.
- On the listener side, `Upgrade` returns a stream wrapper that retains
  any `TransportListener` resources needed by the accepted connection.
  Closing `UpgradeResult.Stream` closes the accepted connection before
  releasing listener resources, which preserves packet-socket cleanup
  ownership; callers do not receive or manage the `TransportListener`
  separately.
- Direct upgrade is opt-in through `UpgradeOption`: callers that want
  hole-punching pass the same caller-owned `net.PacketConn` used for
  candidate gathering, probing, and transport upgrade. `Upgrade` must
  not open a replacement UDP socket for the direct path, because the
  NAT mapping belongs to the supplied socket.
- If no packet socket is supplied, direct upgrade is not requested:
  after unconditional option validation, `Upgrade` sends a first-phase
  fallback with the local reason `not_requested`, consumes the peer's
  first-phase control message, and returns a relay-path result whose
  public fallback reason is resolved through the normal first-phase
  precedence rule against the peer's received or synthesized reason.
  This is normally `not_requested`, but a complete malformed or
  zero-length peer first-phase frame can still select
  `protocol_mismatch`. This path does not create a transport session,
  gather candidates, probe, or use valid direct-upgrade tuning options
  for behavior; it still consumes the authenticated skip/fallback
  control bytes needed to keep the relay stream synchronized.
- Supplying a packet socket requests direct upgrade and requires a
  non-nil `Transport`. Supplying a transport without a packet socket is
  allowed and still sends local `not_requested`; the public relay-path
  reason is resolved by first-phase precedence. This supports callers
  that build common option sets while deciding per session whether a
  direct socket is available.

Option-validation precedence examples:

| Supplied options | Result |
| --- | --- |
| No packet socket, no transport, valid or absent direct tuning | Synchronized first-phase fallback; relay result resolved by first-phase precedence, normally `not_requested`. |
| No packet socket plus `WithProbeTimeout(0)` | Public invalid-option error before any upgrade-control bytes are written. |
| No packet socket plus `WithUpgradeControlTimeout(0)` | Public invalid-option error before any upgrade-control bytes are written. |
| No packet socket plus `WithProbeConcurrency(17)` | Public invalid-option error before any upgrade-control bytes are written. |
| Packet socket without transport | Public invalid-option error before any upgrade-control bytes are written. |
| Transport without packet socket, valid direct tuning | Synchronized first-phase fallback; relay result resolved by first-phase precedence, normally `not_requested`. |

- For v1, `Upgrade` gathers its own local candidates from the supplied
  packet socket and optional STUN server rather than trusting a
  caller-supplied candidate list. Public `Gather` remains available
  for inspection, tests, and advanced callers, but the direct-upgrade
  path derives candidates from the exact socket it may later pass to
  the transport.
- Candidate-pair probing uses a deterministic default priority:
  host-host first, then host-reflexive/reflexive-host, then
  reflexive-reflexive, with address ordering as already defined by
  `Gather`. Callers may override that default with candidate policy:
  products can exclude or deprioritize local interfaces, local
  address prefixes, remote address prefixes, or candidate kinds (for
  example, avoiding a slow VPN path even when a VPN host candidate
  exists). Excluded candidates are not probed; deprioritized
  candidates are tried after preferred direct candidates but before
  relay fallback.
- Remote candidates arrive inside authenticated upgrade-control offers, but authentication is peer provenance, not an operator egress allowlist. v1 does not default-block otherwise valid unicast private, LAN, VPN, loopback, link-local, ULA, or reflexive ranges because those are legitimate direct paths in closed and local deployments. Built-in remote filtering rejects unsupported candidate kinds, invalid addresses, unspecified addresses, multicast addresses, zero ports, and mixed address-family pairs. Deployments that must avoid probing particular remote ranges set `CandidatePolicy.ExcludeRemotePrefixes`; deployments that only want those ranges tried after preferred paths set `CandidatePolicy.DeprioritizeRemotePrefixes`.
- Host-source pairs validate only when the peer's observed UDP source
  address is the offered host candidate, such as on LAN, VPN, loopback,
  or other non-source-rewriting paths. Endpoint-independent NAT paths
  are expected to validate through reflexive-source pairs. v1 keeps the
  mixed host-reflexive/reflexive-host priority tier but does not add
  ICE-style peer-reflexive candidate discovery.
- v1 direct probing uses only host and reflexive UDP candidates. Relay
  candidates remain representable for future negotiation/fallback
  surfaces, but they are not part of the direct candidate-pair probe
  order; the existing relay channel is the v1 fallback path.
- Within a candidate-kind priority group, selection is still policy
  driven rather than based on hard-coded assumptions such as
  "Ethernet beats Wi-Fi" or "IPv6 beats IPv4." The default ordering
  first honors caller policy, then prefers candidate pairs that appear
  to share a local subnet over arbitrary routed host addresses, then
  uses authenticated probe RTT among successful pairs, with
  deterministic address-order tie-breaking for equivalent results.
  v1 uses bounded probe concurrency with a conservative default of 4
  in-flight candidate pairs. `WithProbeConcurrency` accepts values in
  the range 1 through 16 so products can tune it without changing the
  protocol.
- Peers must converge on one selected candidate pair before transport
  upgrade. After probing, the assigned dialer chooses the winning pair
  from authenticated successes using the documented policy/priority/RTT
  ordering and tells the listener over the upgrade-control channel;
  both sides then run the transport over that same pair. Packets from
  any other source are not part of the selected direct path.
- Selection is acknowledged before dialing. The assigned listener
  validates the selected pair, prepares `Session.Listen` on the selected
  socket and selected remote address, then sends a `ready` control
  message. The assigned dialer calls `Session.Dial` only after receiving
  that `ready` message. If the dialer cannot establish listener
  readiness within the direct-upgrade budget, it initiates terminal
  fallback with reason `transport_failed`.
- After receiving `ready`, the dialer sends a `commit` control message
  before starting the transport handshake. The listener remains
  pre-commit after sending `ready`; it keeps terminal fallback handling
  active while waiting for either the dialer's `commit` message or the
  first authenticated transport packet/accepted authenticated transport
  connection on the selected pair. If terminal fallback arrives in this
  window, the listener closes the prepared transport listener, echoes or
  sends terminal fallback, and returns a relay-path result after the
  reciprocal terminal fallback handshake completes. If neither `commit`
  nor authenticated transport progress arrives before the listener's
  internal ready-confirmation budget while the caller context remains
  active, the listener initiates terminal fallback with reason
  `transport_failed` rather than waiting indefinitely.
- The direct-upgrade commit point is locally decidable. The dialer commits after it has received `ready`, written `commit`, and started `Session.Dial` over the selected pair. The listener commits after it receives `commit` or observes the first authenticated transport progress on the selected pair, whichever happens first. Before local commit, a valid terminal `fallback` control message can still signal relay fallback only while listener `Accept` has not returned a non-nil stream. Any non-nil `Accept` stream is an independent ownership boundary even before observed commit and even with an accompanying error. After either boundary, no relay-path result is returned: peer relay close or relay EOF is cleanup only after the required post-commit convergence control messages complete. During the `accepted`/`converged` window and before a valid `confirmed` has been sent, relay close or EOF is a transport-phase convergence failure, not a success signal. Implementations continue the direct transport dial/accept path until it succeeds, the transport budget expires, or the caller context ends. If direct `Session.Dial`, `TransportListener.Accept`, or the transport handshake fails after local commit or any non-nil Dial/Accept stream while the caller context remains active, `Upgrade` returns a public transport-upgrade error with the zero `UpgradeResult` and no active stream. If both peers commit, one peer closes the relay as cleanup, and direct transport later times out, both sides return that transport-upgrade error rather than a relay-path result.
- After both peers complete transport setup, the listener sends an `accepted` control message, the dialer waits for that frame, the dialer replies with a `converged` control message, and the listener acknowledges it with `confirmed`. The `confirmed` frame is the terminal convergence signal: the dialer does not return direct success until it receives `confirmed`, and the listener does not return direct success until writing `confirmed` succeeds. Relay EOF or an authenticated close frame before this terminal sequence completes is not a convergence signal. If either peer's transport setup fails after commit or any non-nil Dial/Accept stream result, both peers return `ErrUpgradeTransportNotConverged` with no active stream and close the obsolete relay control channel.
- Transport handshakes start only after the dialer announces the
  selected candidate pair, the listener sends `ready`, and the dialer
  sends `commit`. A successful authenticated probe proves reachability
  for that pair, but it does not itself authorize starting QUIC or any
  other transport on multiple probed pairs.
- Probe traffic stops when the transport phase begins. Non-selected
  pairs are abandoned, and the selected pair is kept alive by the
  transport handshake traffic rather than by continuing wiremux probe
  keepalives. Explicit post-selection keepalives or path-management
  probes are out of v1 scope.
- Candidate policy is local-only. A peer applies its own policy to the
  candidates it offers and the remote candidates it is willing to
  probe; v1 does not exchange policy names, rules, interface details,
  or user preferences with the remote peer. The only policy-related
  value that may cross the wire is the coarse `policy_excluded`
  fallback enum, which is result synchronization metadata rather than a
  policy disclosure. Local interface-name policy is applied during
  local gathering/pair selection only; interface names are not included
  in `Candidate`, not sent to the peer, and not included in
  `UpgradeResult`.
- Local candidate exclusions are applied before sending the local
  offer, so paths the caller refuses to expose are not advertised to
  the remote peer. Remote candidate exclusions are applied during
  local candidate-pair selection, so the peer may offer any candidate
  but this side only probes paths allowed by its own policy.
- If `CandidatePolicy` local or remote exclusions remove every otherwise allowed candidate path, direct upgrade falls back to a relay-path result. Local candidate exhaustion before sending an offer uses first-phase `policy_excluded`; remote prefix or kind exclusions after two valid offers use terminal `policy_excluded` only when they remove otherwise compatible probe pairs. Other zero-pair outcomes after valid offers, including address-family mismatch, built-in-invalid remote candidates, and deprioritize-only policy, use `probe_failed`. Policy-based exhaustion is a valid path selection outcome, not a public `Upgrade` error; malformed or impossible policy options supplied by the caller remain input errors.
- Fallback reason `not_requested` means this peer or its peer sent a
  first-phase fallback because no packet socket was supplied. Fallback
  reason `no_candidates` means direct upgrade was requested but the
  selected fallback reason came from local gathering or a peer's
  first-phase `no_candidates` fallback. Fallback reason
  `policy_excluded` means candidates existed, but the selected fallback
  reason came from `CandidatePolicy` local or remote exclusions leaving
  no allowed compatible candidate pair.
  Fallback reason `probe_failed` means no allowed candidate pair proved
  reachable, including cases where built-in remote filtering or address
  family compatibility left no pair to probe.
  Fallback reason `transport_mismatch` means both offers were valid but
  named different transports. Fallback reason `protocol_mismatch` means
  the peer sent a complete, authenticated upgrade-control message that
  this implementation either understood as unsupported for v1 or drained
  as a complete frame rejected by the strict CBOR subset. Fallback reason
  `transport_failed` covers transport session creation failure before an
  offer, probe-key derivation failure after both offers, and listener
  readiness failure before the direct-upgrade commit point and before any
  non-nil listener `Accept` stream while the caller context remains active. After
  commit or a non-nil Dial/Accept stream, dial, accept, transport handshake, and carrier-
  validation failure return `ErrUpgradeTransportNotConverged`, the zero result,
  and no active stream rather than relay fallback reasons.
- When a packet socket is supplied, the negotiator attempts direct
  probing even if candidate gathering finds only host candidates and
  no reflexive candidate. Host-only direct paths are valid for LAN,
  local test, VPN, and otherwise routed environments; absence of a
  reflexive candidate is not by itself a reason to skip the attempt.
- UDP probes are authenticated before a candidate pair is treated as
  reachable. Probe authentication uses exporter-derived, per-upgrade
  material; spoofable plaintext markers or unauthenticated magic
  strings are not sufficient to prove reachability. If the auth
  context cannot derive the probe material after both peers have offered
  direct upgrade, direct upgrade sends terminal `fallback` with reason
  `transport_failed` and fails cleanly back to relay.
- Probe authentication binds to this specific upgrade attempt and this
  specific candidate pair. Each local upgrade offer carries fresh
  random probe nonce material, and each authenticated probe covers the
  wiremux protocol version, both peers' probe nonce material, both
  offered candidate addresses in the probed pair, and the probe
  direction. Probe authentication uses a byte-exact binary transcript
  with a fixed field order rather than the CBOR upgrade-control
  encoding.
- UDP probes are authenticated with HMAC-SHA-256. The probe key is 32
  bytes derived from `AuthContext.Exporter()` using label
  `"wiremux v1 probe-hmac"` and a byte-exact exporter context:
  `probe_context_version || dialer_probe_nonce[32] ||
  listener_probe_nonce[32]`, where `probe_context_version` is the
  single byte `0x01` for the v1 exporter-context format.
  The dialer and listener nonce order is anchored to the deterministic
  role assignment above, not to local/remote perspective or send order.
  CPace-backed integrations map `cpace.Session.Export` into wiremux's
  generic `KeyExporter`; wiremux remains unaware of CPace or any other
  specific identity protocol.
- Probe candidate encoding is byte-exact and independent of CBOR:
  `candidate_kind || candidate_addr_port`. `candidate_kind` is `0x01`
  for host and `0x02` for reflexive; relay candidates are not valid in
  v1 probe transcripts. `candidate_addr_port` is
  `addr_family || ip_bytes || u16be(port)`, where `addr_family` is
  `0x04` for IPv4 and `0x06` for IPv6. IP addresses are encoded from
  `netip.Addr.Unmap()`: IPv4 and IPv4-mapped IPv6 addresses encode as
  four IPv4 octets, native IPv6 addresses encode as 16 octets, zones
  are not encoded, and ports are unsigned 16-bit big-endian values.
  IPv6 link-local scope remains a local packet-socket property under the
  bound-single-interface rule above and never appears in the probe
  transcript.
- The candidate-pair token is a 16-byte routing hint:
  `trunc16(HMAC-SHA-256(probe_key, token_transcript))`, where
  `token_transcript` is
  `probe_token_version || direction || source_candidate ||
  destination_candidate` and `probe_token_version` is the single byte
  `0x01` for the v1 token format. The token is cleartext and is not
  accepted as proof of reachability.
- The HMAC input for every probe packet is exactly
  `probe_transcript_version || msg_type || direction || probe_id[8] ||
  candidate_pair_token[16] || source_candidate ||
  destination_candidate`, where `probe_transcript_version` is the
  single byte `0x01` for the v1 packet-authentication transcript.
  `msg_type` is `0x01` for request and `0x02` for response.
  `direction` is `0x01` for dialer-to-listener packets and `0x02` for
  listener-to-dialer packets. `probe_id` is 8 fresh random bytes chosen
  by the request sender for each candidate-pair request.
  `source_candidate` is the offered candidate for the UDP packet
  sender, and `destination_candidate` is the offered candidate for the
  UDP packet receiver; responses reverse source/destination order and
  echo the request's `probe_id`. Probe packets carry the full 32-byte
  HMAC tag over this fixed transcript.
- Probe datagrams have a fixed v1 wire layout and no trailing bytes:
  `magic[4] || datagram_version[1] || msg_type[1] || direction[1] ||
  probe_id[8] || candidate_pair_token[16] || hmac_tag[32]`. `magic`
  is ASCII `"WMXP"` (`0x57 0x4d 0x58 0x50`), `datagram_version` is
  `0x01`, and the datagram is exactly 63 bytes. Receivers first check
  length, magic, version, message type, and direction for routing and
  discard mismatches silently. The cleartext header is not trusted as
  proof of reachability; the HMAC tag authenticates the fixed
  transcript above. Sensitive material must not appear in the cleartext
  probe header.
- Any change to the probe exporter context, candidate-pair token
  transcript, datagram header, or HMAC transcript requires a wiremux
  upgrade-control protocol version bump and new golden vectors. v1
  implementations reject unknown probe datagram versions silently.
- Probe packets do not repeat full candidate addresses. Candidate
  addresses are already exchanged over the authenticated channel and
  are included in the HMAC transcript; the receiver reconstructs
  expected transcripts from known candidate pairs and the packet's
  observed source address.
- Receivers normalize the UDP packet's observed source with the same
  `netip.Addr.Unmap()` plus `u16be(port)` rules used for candidate
  encoding before matching candidate-pair state. IPv6 zones are stripped
  before comparison; implementations may compare the zoneless encoded
  `addr_port` bytes directly. A packet is accepted only when the
  normalized observed source equals the encoded source candidate for the
  transcript whose HMAC validates; otherwise it is silently dropped as
  wrong-pair or unauthenticated traffic.
- Probing is request/response. A candidate pair is considered
  reachable only after a peer sends an authenticated probe request and
  receives a matching authenticated probe response on the same pair;
  one-way receipt alone is not enough to select a direct path.
- Both peers actively send authenticated probe requests during the
  probing phase so NAT mappings can open on both sides. The assigned
  dialer still chooses the final candidate pair after probing; only
  after that selection does the transport phase use one dialer and one
  listener.
- Probe responses are sent only after the request HMAC validates
  against an expected candidate pair. The cleartext probe header may
  route the packet to candidate-pair state, but unauthenticated or
  unrecognized packets are dropped silently so probing does not become
  a reflection amplifier.
- Probe retries are bounded and jittered. Implementations use a short
  initial interval, a small retry count per active pair, and jitter to
  avoid synchronized bursts, all within the configured probe/upgrade
  timeout. The public tuning surface remains coarse: probe timeout,
  upgrade-control timeout, and concurrency cap, not many low-level
  timer knobs. The default probe timeout and default upgrade-control
  timeout are both 3 seconds; `WithProbeTimeout` and
  `WithUpgradeControlTimeout` accept positive durations and reject zero
  or negative values.
- The packet-socket ownership boundary is role-specific. Local direct-transport commit transfers ownership. Independently, any non-nil stream returned by Session `Dial` or TransportListener `Accept` transfers ownership immediately even with an accompanying error. After either boundary, later failure returns `ErrUpgradeTransportNotConverged` with the zero result, synchronously closes exactly one owning stream or raw-socket path, and cannot return relay fallback. On direct success, the returned upgraded connection path retains packet-socket cleanup.
- On fallback or setup error before the role-specific ownership boundary (before local commit and any non-nil Dial/Accept stream), `Upgrade` stops all probe goroutines, clears socket deadlines it set where possible, and releases read ownership of the supplied packet socket before returning. No background probe reads or writes may continue after a relay-path result is returned. After local commit or a non-nil stream, later validation or transport failure closes under wiremux ownership and never releases the socket or returns relay.
- The negotiator does not assume QUIC; it dispatches via `Transport`.
  `connect` does not provide a default transport and does not import
  `transport/quic`; callers that request direct upgrade must supply a
  transport through `UpgradeOption`.
- `KeyExporter.Derive` must be deterministic for the same
  `(label, context, length)`, produce independent material for
  different inputs, and reject labels containing 0x00 (NUL), which
  would make the recommended `label || 0x00 || context` info framing
  ambiguous.

### `relay`

- `type SessionID [16]byte` — ephemeral rendezvous identifier.
- `type PeerID []byte` — long-lived rendezvous identifier; opaque to
  the relay (typically a hash of a peer's long-lived public key).
- `type Mode` — discriminator for ephemeral vs long-lived rendezvous.
- `type Relay`, `New(opts ...Option) *Relay`,
  `Serve(net.Listener) error`.
- Options for logger, pair timeout, ephemeral-mode expiry, long-lived-
  mode keepalive, rate-limit tuning, waiting-state budget, and
  registration-proof scheme selection.
- An invite/session lifecycle surface that lets the root `wiremux.Dial`
  orchestration attempt to mark a `SessionID` consumed after successful local
  upgrade, marked-spent identity failure, unmarked terminal identity failure
  confirmed by the heuristic, or post-success failures for one-shot rendezvous
  authenticators (ephemeral mode), while marked-retryable failures and unmarked
  purely retryable error trees remain retryable. It also lets a long-lived peer
  deregister (long-lived mode). Exact function names are deferred to
  implementation; the capability is required.
- Client-side dialer:
  `Dial(ctx, endpoint, mode, id, opts ...DialOption) (io.ReadWriteCloser, error)`
  for a single pairing attempt: ephemeral-mode rendezvous (either side) or
  connecting to a registered long-lived peer (connecting side only).
- Client-side listener for long-lived mode:
  `Listen(ctx, endpoint, peerID, opts ...ListenOption) (PeerListener, error)`
  registers the caller under `peerID` and returns a listener whose
  `Accept(ctx) (io.ReadWriteCloser, error)` yields one connection per
  inbound pairing for as long as the registration lasts. Exact names
  are deferred to implementation; the capability — one registration,
  many sequential or concurrent pairings — is required.
- Registration proof per ADR-0001:DP9: a client-side prover and
  relay-side verifier for the default `ed25519-keyhash` scheme, plus
  the pluggable interface both implement. Verifier selection is
  operator configuration; proof is on by default in long-lived mode.
  The signed message is the domain-separated transcript
  `"wiremux v1 longlived-reg" || 0x00 || lp(scheme) || lp(PeerID) ||
  lp(challenge) || lp(tls-exporter-binding)`, where `lp(x)` is
  `u16be(len(x)) || x` — every variable-length field is
  length-prefixed, so no alternate field split produces the same
  bytes. The challenge is exactly 32 random bytes. The binding is
  the 32-byte output of the registrant↔relay TLS connection's
  exporter,
  `ExportKeyingMaterial("EXPORTER-wiremux-v1-longlived-reg", nil, 32)`
  (RFC 9266 style); registration requires TLS 1.3, and if the
  exporter returns an error the registration fails closed. A proof
  transcript is not verifiable on any other TLS connection or relay.
- TLS configuration helpers, including:
  - Implemented ACME-based certificate-provisioning helpers for intended public deployments (Let's Encrypt or another CA-signed certificate); the v0.1.0 validation boundary remains the in-process lifecycle in acceptance criterion 9, with live issuance and hosted validation deferred to [issue #924](https://github.com/GridSwarm/wiremux/issues/924).
  - Self-signed cert + fingerprint-distribution helpers for private
    deployments.

Invariants:

- The relay always serves over TLS. Plain TCP is not supported.
- The relay treats payloads as opaque and never learns auth secrets.
- The relay pairs only peers that present the same rendezvous
  identifier in the same mode.
- Pair waits are bounded.
- Ephemeral mode: the root `wiremux.Dial` orchestration makes a bounded,
  best-effort consume attempt after successful local upgrade, after a
  marked-spent identity failure, after an unmarked terminal identity failure
  once relay pairing has occurred and the heuristic confirms a non-I/O
  domain/authentication leaf, or after post-success failures for authenticators
  that implement `connect.OneShotRendezvous`. Marked-spent failures use the
  without-cancel default budget; marked-retryable failures never consume.
  Context cancellation and deadline identity failures, plus relay I/O closure
  during unmarked identity, leave the `SessionID` retryable when the error tree
  is purely retryable, including contextual wrappers or joins whose leaves are
  all relay I/O. Malformed, cyclic, or traversal-truncated unmarked trees are
  consumed only when a non-I/O domain/authentication leaf is confirmed;
  relay-only or ambiguous malformed trees remain retryable. Unmarked terminal
  identity/authentication errors that carry relay I/O must also carry a non-I/O
  domain/authentication error. When unilateral consume reaches a live paired
  relay session, the `SessionID` rejects later arrivals for the consumed
  session; mixed lower-level peers can close the relay path first, leaving the
  ID reusable until normal expiry.
  Default expiry 15 minutes, configurable maximum 1 hour, matching
  the swarmcast bootstrap requirements (cross-repo:
  `swarmcast:adr-0016` D3).
- Long-lived mode: a `PeerID` registration persists until disconnect, explicit deregistration, operator-configured idle timeout, or its finite absolute lease expires (one hour by default). Keepalives do not extend the lease; clients reacquire lost registrations with `Listen`. Source-bucket admission quotas apply to each acquisition. A single registration accepts multiple inbound pairings over its lifetime; pairing does not consume the registration, and already paired streams survive lease expiry.
- Long-lived registration requires proof of PeerID possession by
  default (`ed25519-keyhash` per ADR-0001:DP9); operators may disable
  proof, accepting the documented squatting risk. Ephemeral mode
  requires no registration proof.
- Guess-limiting is keyed by rendezvous identifier, not source IP.
  The relay additionally enforces coarse resource protection per
  ADR-0001:DP3: a bounded budget of unpaired waiting entries,
  per-source network-bucket and global connection-rate caps, and
  bounded pair-timeouts. Source buckets are pre-auth network
  observations, not user or identity limits; shared egress populations
  share their bucket.
- Operators may disable either mode without affecting the other.

### `relayurl`

- `Parse(raw string) (*Endpoint, error)` accepting only `wiremux://host:port`. DNS hosts use ASCII labels containing letters, digits, and interior hyphens only; underscores, non-ASCII, percent escapes, spaces, and numeric rightmost DNS labels are rejected, and a trailing root dot is accepted but canonicalized away. Bare `host:port`, `wiremuxs://`, `codemuxs://`, `tapmuxs://`, and any other variant are rejected per ADR-0001:DP5.
- `type Endpoint` with host, port, and `Addr()`. The endpoint **does
  not** carry a fingerprint; pinning is a separate config concern.
- `type Pin` representing a pinned-cert fingerprint. Helpers for
  parsing pin material from typical config formats (e.g.,
  `sha256:<hex>` strings) and building pinned private-relay TLS client
  configs.
- `type Fingerprint [32]byte` with helpers for DER and TLS
  certificates.

Invariants:

- The package accepts exactly one URL form: `wiremux://host:port`. No other schemes are accepted. DNS hosts use ASCII DNS label grammar with letters, digits, and interior hyphens only, no underscores, no non-ASCII, no percent escapes, no spaces, no numeric rightmost DNS label, and an optional trailing root dot that is removed during canonicalization.
- TLS is mandatory; the URL grammar does not encode "TLS or not."
- Fingerprints are lowercase SHA-256 over certificate DER bytes.
- TLS pin mismatches fail closed before application bytes are sent.
- A consumer with no `Pin` for an endpoint defaults to Web PKI
  verification (system CA store).

### `stun`

- `type Server`, `NewServer(opts ...ServerOption) *Server`,
  `Serve(net.PacketConn) error` for the STUN responder. The server
  does not close caller-supplied sockets. Closing the socket from
  another goroutine stops `Serve` and returns nil.
- `type Client`, `NewClient(opts ...ClientOption) *Client`,
  `(*Client).Reflexive(ctx, conn net.PacketConn, server net.Addr) (net.Addr, error)`
  for reflexive-address discovery using the supplied packet socket.
  The client does not close caller-supplied sockets. Callers must pass
  a cancellable or deadlined context, and must not read from the packet
  socket concurrently while `Reflexive` is running. `Reflexive` may set
  read deadlines while it owns the read loop and must clear its read
  deadline before returning.
- Implements RFC 5389 (Binding request/response) at minimum;
  extensions beyond v1 require a separate ADR.

Invariants:

- The responder is stateless.
- The client uses `crypto/rand` for transaction IDs.
- The responder answers valid unauthenticated Binding requests with
  `XOR-MAPPED-ADDRESS` derived from the packet source address. It
  silently drops malformed datagrams, non-STUN datagrams, and
  unsupported methods. The minimal v1 responder also silently drops
  Binding requests that carry unsupported comprehension-required
  attributes rather than returning STUN error responses.
- STUN Binding is unauthenticated UDP and can reflect traffic. The
  `stun.Server` remains stateless; public deployment rate limiting,
  source budgets, and abuse controls belong in `cmd/wiremux-server`,
  the socket-owning layer, or surrounding network policy.
- The client accepts only successful Binding responses whose
  transaction ID matches the request it sent, whose packet source
  matches the queried server, and whose attributes include
  `XOR-MAPPED-ADDRESS`. It ignores malformed responses, mismatched
  transaction IDs, and responses from unexpected sources until the
  lookup succeeds or its context expires. IPv4 and IPv6 XOR-mapped
  addresses are supported; legacy `MAPPED-ADDRESS` fallback is not
  required for v1.
- No support for STUN authentication, USERNAME/MESSAGE-INTEGRITY, or
  TURN in v1.

### Transport contract and `transport/quic`

The `Transport`, `Session`, and `TransportListener` interfaces are
defined in `connect` — the package whose negotiator consumes them — so
`transport/<X>` implementations import `connect` and no
`connect` ⇄ `transport` import cycle exists. Implementations live
under `transport/`; v1 ships `transport/quic`.

```go
// Transport is the pluggable surface for direct peer-to-peer
// connectivity after wiremux's hole-punch succeeds.
type Transport interface {
    // Name returns a stable printable-ASCII identifier (e.g., "quic",
    // "dtls") used by exporter labels and by negotiation.
    Name() string

    // NewSession creates per-upgrade transport state bound to auth.
    // Session state exists so that handshake material generated
    // before candidate exchange (e.g., an ephemeral certificate) is
    // the same material used by the subsequent Dial or Listen.
    NewSession(ctx context.Context, auth TransportAuth) (Session, error)
}

// Session is single-upgrade transport state. Exactly one of Dial or
// Listen is called per session, per the negotiator's role assignment.
type Session interface {
    // HandshakeMaterial returns transport-specific authentication
    // material for the negotiator to deliver to the remote peer over
    // the authenticated channel (for QUIC, the SHA-256 fingerprint
    // of an ephemeral self-signed certificate). May be empty for
    // transports that derive handshake keys via the exporter alone.
    HandshakeMaterial() []byte

    // Dial opens an outbound transport connection over the punched
    // path. conn is the local packet socket that performed the
    // successful probe; the NAT mapping is bound to that socket, so
    // the transport must use it as-is — a fresh socket may produce
    // a different mapping and fail where the probe succeeded.
    // remote is the selected remote address and is the only authorized
    // remote endpoint for the returned connection's lifetime. Transport
    // migration or rebinding from any other address must be disabled or
    // filtered. remoteMaterial is the remote peer's HandshakeMaterial
    // as received over the authenticated channel. Any non-nil returned
    // connection owns conn even when returned together with an error.
    // Its Close synchronously attempts bounded stream, parent,
    // transport-resource, and exact-packet cleanup exactly once before
    // returning. A nil connection leaves conn open and caller-owned.
    Dial(ctx context.Context, conn net.PacketConn, remote net.Addr, remoteMaterial []byte) (io.ReadWriteCloser, error)

    // Listen prepares an inbound listener on the punched local
    // socket for the selected remote address. The same socket-reuse
    // requirement applies. Listen and Accept may temporarily own reads
    // on conn, but remote is the only authorized remote endpoint for the
    // returned connection's lifetime. Packets, transport migration, or
    // rebinding from sources other than remote must be disabled or
    // filtered before they can establish or confuse an upgraded
    // connection. Ownership of conn transfers to any non-nil connection
    // returned by Accept, even together with an error. If Accept returns
    // no connection, closing the listener must leave conn open for the caller.
    Listen(ctx context.Context, conn net.PacketConn, remote net.Addr, remoteMaterial []byte) (TransportListener, error)

    // Close remains prompt, actively unblocks implementation-owned Dial
    // and Listen I/O after their contexts are canceled, and does not
    // itself join those operations.
    Close() error
}

type TransportListener interface {
    // Accept waits for the upgraded transport connection. Any non-nil
    // returned connection owns the exact packet socket even when returned
    // with an error. Its Close synchronously completes the same bounded
    // disposal contract as Dial; callers close it before the listener.
    Accept(ctx context.Context) (io.ReadWriteCloser, error)

    // Close releases listener resources and joins an active Accept result.
    // Before a non-nil Accept result, Close leaves the supplied packet
    // socket open; afterward it cannot take cleanup from the returned path.
    Close() error
}
```

Datagram participation is optional and additive. A supporting stream returned
from `Session.Dial` or `TransportListener.Accept` implements
`DatagramCapable`; all three required transport interfaces above remain
unchanged:

```go
// DatagramCarrier is the lower transport view of the established carrier's
// optional unreliable-unordered atomic-message plane.
type DatagramCarrier interface {
    // Lifetime is canceled with a cause when the established carrier becomes
    // terminal. It is stable, non-nil, and has a non-nil Done channel.
    Lifetime() context.Context

    // MaxDatagramPayload is the lifetime-fixed exact local-outbound ceiling
    // for the complete lower payload, including wiremux's one-octet envelope.
    MaxDatagramPayload() int
    SendDatagram(ctx context.Context, payload []byte) error
    // ReceiveDatagram returns either a non-nil payload and nil error,
    // or a nil payload and non-nil error.
    ReceiveDatagram(ctx context.Context) ([]byte, error)
}

// DatagramCapable is optionally implemented by a returned transport stream.
type DatagramCapable interface {
    DatagramCarrier() (DatagramCarrier, bool)
}
```

The only valid results are interface absence, `(nil, false)`, or a non-nil, non-typed-nil carrier with `MaxDatagramPayload() > 1`, a non-nil, non-typed-nil `Lifetime()`, and a non-nil lifetime `Done` channel. Validation must use a typed-nil-safe check before invoking a carrier or context method. The valid present form becomes eligible for the pairwise exposure agreement; every other combination is malformed. Typed-nil carrier or lifetime values must never panic. Malformed optional results are discovered only after `Dial` or `Accept` returns a non-nil connection. That materialized result is independently the packet-socket ownership boundary even when accompanied by an error. Both roles therefore close only the returned connection, whose synchronous Close owns the exact socket, and return `ErrUpgradeTransportNotConverged`, zero result, and no relay fallback. They never create one-sided capability presence or a nil public handle.

There is no shared extraction instant. The dialer validates the result of `Session.Dial` after it has sent `commit`, so malformed dialer results are post-commit failures. The listener validates `TransportListener.Accept` immediately when it completes; any non-nil `Accept` stream transfers packet-socket ownership even with an error, so malformed carrier validation is an accepted-transport failure even if `commit` has not yet been observed. A valid local carrier is retained out of band through the post-commit agreement, then copied into `UpgradeResult.Datagrams` only when the final result is true and before `terminalListenerOwnedStream` wraps the reliable stream.

After extraction, both roles replace the transport-returned stream with a
reliable-only wrapper that forwards exactly `Read`, `Write`, and `Close`.
`UpgradeResult.Datagrams` is the exclusive lower capability surface;
`UpgradeResult.Stream` never satisfies `DatagramCapable`, whether agreement is
present or absent. This prevents direct `connect.Upgrade` callers from bypassing
the synchronized result by reasserting the optional interface.

The existing post-commit phase messages synchronize final exposure through the
bounded `Extensions` map and the normative v1 extension-key registry above.
Key `"wiremux.datagram/1"` has CBOR boolean value `true`. Implementations encode
absence by omitting the key and must never encode CBOR `false`. The listener's
`accepted` reports valid local
presence, the dialer's `converged` reports the intersection with its valid
local result, and the listener's `confirmed` echoes that final value. A
present key with any value other than CBOR `true`, or a contradictory echo, is
`ErrUpgradeTransportNotConverged`. A role copies its
carrier into `UpgradeResult.Datagrams` only after the final value is true.
Unknown extensions remain ignored, so mixed-version or one-sided optional-
interface exposure resolves to absence on both roles while the reliable Wire
succeeds. The extension synchronizes exposure; it does not make an invalid
transport carrier conformant.

`DatagramCapable.DatagramCarrier`, `DatagramCarrier.Lifetime`, and
`MaxDatagramPayload` return promptly without network I/O or unbounded blocking.
`SendDatagram` and `ReceiveDatagram` unblock when their supplied context ends or
the carrier lifetime becomes terminal. Failure to meet these liveness rules is
non-conformance; a transport unable to provide them reports capability absent.

`ReceiveDatagram` returns exactly one result. Success is a non-nil payload and
nil error; a zero-length native Datagram uses a non-nil empty slice and is then
discarded by root framing. Failure is a nil payload and non-nil error.
`(nil, nil)` and a non-nil payload plus error are observed carrier contract
breaches: root delivers no payload, initiates aggregate teardown, and returns
`ErrWireClosed`, preserving the lower error when present or an internal
nonconformance cause for `(nil, nil)`.

Lower `SendDatagram` copies into a bounded unexported admission queue. It blocks
for a slot until the supplied context or carrier lifetime ends; cancellation
before admission returns the context error and accepts nothing. Success means
only accepted for possible lower transmission, never sent or delivered. This
adapter-level queue is separate from the root handle queue so direct
`connect.Upgrade` callers receive the promised cancellable lower contract too;
neither bound is public or configurable.

The lower ceiling is the local-outbound limit for the exact slice passed to
`SendDatagram`, including wiremux's envelope. The public local send ceiling is
its snapshot minus one. Directional outbound ceilings may differ; `Receive`
may return a peer payload larger than the receiver's own local send ceiling. A carrier accepts every lower payload at or below its
ceiling atomically or not at all, locally rejects a larger payload without
connection damage, does not retain a send slice after return without copying,
and returns a receive slice that remains stable after return. Root wiremux
still copies in both directions to make public ownership independent of adapter
quality. A dynamic native limit must be conservatively frozen; if it later
falls below the promised ceiling, the adapter ends the Wire rather than
mutating the value or silently degrading.

`DatagramCarrier` and `UpgradeResult.Datagrams` are advanced lower-level
surfaces. Their send and receive byte slices include the one-octet wiremux
envelope; a direct `connect.Upgrade` caller must prepend `0x00` for application
data, drop empty native and reserved-discriminator messages as specified below,
and accept carrier-native queueing, cancellation, size, and error behavior.
Such callers must not add a second envelope around a root `Datagrams` payload.
Production consumers should prefer `Wire.Datagrams()`, which accepts consumer
bytes only and supplies root framing and lifecycle guarantees.

If a carrier explicitly rejects a lower payload at or below the frozen ceiling
as too large, it has observably stopped upholding the admission contract and
the adapter terminates the Wire. If it accepts that payload and the transport
later silently drops it during packet packing or transmission, the outcome is
ordinary Datagram loss and the Wire remains usable. The ceiling governs
deterministic admission, not delivery.

A supporting carrier is the same authenticated transport/session instance as
the reliable stream. It provides end-to-end confidentiality, integrity, peer
authentication, and duplicate or replay suppression; neither wiremux nor any
selected or controlled protocol layer retransmits an accepted consumer
message; it exposes no partial payload; reliable and Datagram traffic share one
carrier-level congestion authority; and both planes have one aggregate owner.
Carrier-lifetime termination ends both, while a classified reliable-read
outcome may close the optional Datagram gate without closing reliable writes.
Opaque link-layer ARQ/FEC is outside the no-retransmission claim. The lower
carrier supports one send and one receive concurrently plus concurrent close;
root wiremux serializes same-direction calls.

Those security properties come from the established transport carrier. Relay
reliable bytes use wiremux encrypted-channel framing. On a direct QUIC path,
certificate-pinned QUIC TLS and QUIC packet protection secure both reliable
stream bytes and Datagrams. Datagram bytes never pass through wiremux channel
framing: the channel's counter nonces, strict stream sequencing and gap
detection, and authenticated close frame do not apply to them.

`Lifetime` is one stable cause-bearing context canceled exactly once for idle
or active local close, peer teardown, or another terminal transport failure.
`context.Cause` is non-nil after its `Done` channel closes. The root lifetime
monitor serializes its closed-state transition with queue admission and feeds
the aggregate teardown authority. Reliable-read gate closure alone does not
cancel this lifetime or close reliable writes. A carrier that can close without
signaling this context is non-conformant.

Datagram conformance has two independent gates: production-path executable
behavior tests, including the reusable `wiremuxtest` suite, and a
transport-specific evidence record grounded in primary protocol
specifications plus source and configuration audit for path binding, security,
no retransmission, and shared congestion authority. Black-box behavior alone
cannot certify those non-observable invariants. A stream-only transport remains
fully conformant without either optional interface.

Datagram presence is discovered inside the established transport and captured
once after its handshake. It is never inferred from `Transport.Name()`. The
upgrade-control protocol remains version 1 with the same message transitions;
the existing ignore-unknown `Extensions` map carries the post-commit
`"wiremux.datagram/1"` exposure agreement. Extension-free phase frames remain
valid and mean absence. Each lower Datagram begins with
one wiremux octet: `0x00` means the remainder is an application payload, and
`0x01` through `0xFF` are reserved. Empty lower Datagrams and unknown
discriminators are silently dropped. A sender emits a reserved discriminator
only after a future negotiated agreement. This framing is separate from the
reliable stream and can never be decoded as upgrade-control or application
stream bytes. After every discarded empty or reserved-discriminator lower
message, root checks the closed-Wire gate and then the call context before
receiving again. Continuous invalid input cannot starve cancellation or close;
receive precedence remains closed Wire before context.

Capability presence is immutable for the carrier. Mixed-version, asymmetric,
or unsupported negotiation degrades only to capability absence while keeping
the reliable Wire. The failure vocabulary and ownership outcomes are:

| Condition | Classification | Required outcome |
| --- | --- | --- |
| Datagram ALPN not selected; native support absent or negotiated in only one direction; optional interface absent on either role or `(nil, false)` | Normal capability absence | Post-commit extension agreement resolves false on both roles; reliable Wire succeeds and `Wire.Datagrams()` returns `(nil, false)` |
| Invalid native transport-parameter encoding or equivalent handshake-hard defect | Native transport establishment failure | Before any non-nil `Accept` stream and before commit, synchronized `transport_failed` relay fallback is permitted; after commit or a non-nil Dial/Accept stream, return `ErrUpgradeTransportNotConverged`, zero result, and no active stream |
| Other transport handshake or setup error | Existing transport establishment failure | Same existing ownership/commit rule as the preceding row |
| Returned stream reports a malformed `DatagramCapable` result | Carrier-validation failure after transport success | Dialer and listener close the returned connection; return `ErrUpgradeTransportNotConverged`, zero result, and no relay fallback, regardless of whether the listener observed `commit` |

A future relayed or migrated carrier may report presence when it upholds the
same semantics, but the current TLS/TCP relay does not. The handle stays bound
to the carrier/session instance, not a frozen route, and never silently
retargets.

`transport/quic` implements `Transport` over `quic-go`. Authentication
follows ADR-0001:DP8 (channel-bound certificate pinning), because Go's
`crypto/tls` offers no external-PSK API for TLS 1.3 and `quic-go`
inherits that limit:

- `NewSession` generates a per-upgrade Ed25519 self-signed certificate
  with no peer-identity, account-identity, or WebPKI semantics.
  `HandshakeMaterial()` returns exactly the raw 32-byte SHA-256
  fingerprint of the certificate's DER bytes. The `quic` transport
  name means this material shape; a future QUIC authentication scheme
  with different material should use a distinct transport name.
- `Dial` and `Listen` validate peer `remoteMaterial` as exactly one
  raw SHA-256 fingerprint before starting QUIC setup. The negotiator
  treats handshake material as opaque transport bytes and does not
  perform QUIC-specific validation.
- Both sides offer ALPN `wiremux-quic/2` followed by legacy
  `wiremux-quic/1`. ALPN is protocol hygiene and cross-protocol protection; the
  certificate pin remains the authentication mechanism. Both profiles include
  the initial dialer-sent `0x00` stream-establishment prime on the single
  bidirectional stream. `/2` additionally commits each endpoint to RFC 9221
  support and `max_datagram_frame_size >= 1195`, which admits 1192 lower Data
  bytes after length-bearing frame overhead; an endpoint with a smaller
  positive limit must omit `/2` and negotiate stream-only `/1`.
- Pin checks run in `VerifyConnection` — which, unlike
  `VerifyPeerCertificate`, Go invokes on every connection including
  TLS resumptions. The dialing side verifies the server certificate
  against the remote fingerprint; the listening side requires a
  client certificate (`RequireAnyClientCert`) and verifies it the
  same way. Web-PKI chain verification is disabled (in Go:
  `tls.Config{InsecureSkipVerify: true}`, permitted only in
  combination with the `VerifyConnection` pin check) — the pin is
  the authentication.
- Session tickets and client session caches are disabled for
  per-upgrade sessions; resumption cannot bypass the pin check even
  if a TLS config is reused.
- A fingerprint mismatch fails the handshake closed; no application
  data flows on an unpinned connection.
- The exporter is not consumed by the QUIC handshake in v1. The label
  `"wiremux v1 quic-confirm"` is reserved for an optional
  post-handshake confirmation (out of v1 scope, per ADR-0001:DP8).
- The assigned wiremux dialer is the QUIC client and opens exactly one
  bidirectional QUIC stream. The assigned wiremux listener is the QUIC
  server and accepts exactly one bidirectional QUIC stream. The returned
  `io.ReadWriteCloser` wraps that stream and the transport resources
  needed to cleanly close the QUIC connection and transferred packet
  socket ownership.
- Both client and server QUIC configurations enable RFC 9221 unconditionally.
  Datagram presence is reported only after `/2` is selected and
  `ConnectionState().SupportsDatagrams.Local` and `.Remote` are both true;
  transport name and direct-path selection are not evidence. quic-go v0.61.0
  advertises 16,383, above the `/2` floor. Conforming legacy,
  smaller-positive-limit, or one-direction-only peers omit `/2` and select
  `/1`, keeping the reliable stream with capability absent. quic-go does not
  expose the peer's numeric value at runtime, so a peer that nevertheless
  selects `/2` is asserting conformance with the profile floor; an explicit
  at-or-below-ceiling rejection triggers aggregate contract-breach teardown.
- Every lower QUIC Datagram begins with one
  wiremux discriminator octet: `0x00` for an application message and `0x01`
  through `0xFF` reserved. Empty
  native Datagrams and unknown discriminators are silently dropped. A zero-
  length consumer message is encoded as the single `0x00` octet and delivered
  as an empty caller-owned payload.
- Both QUIC configuration constructors set
  `InitialPacketSize: 1232` explicitly — the universal IPv6-safe floor, chosen so
  the class stays valid once the transport honours DF (#1317); the Datagram
  contract does not rely on
  an upstream default. At
  that pinned baseline, quic-go v0.61.0's conservative
  short-header packet-payload estimate is 1195 bytes. A length-bearing
  DATAGRAM frame uses a one-byte type and two-byte length at this size, so the
  audited frame-fit lower Data ceiling is 1192 bytes and the public consumer
  ceiling is 1191 bytes after the wiremux envelope. This is an implementation
  baseline, not a permanent wire constant; dependency or configuration changes
  affecting packet sizing must re-audit and intentionally rebaseline it.
- The QUIC carrier owns a bounded admission queue
  and one lifecycle-owned send worker. It copies before admission, and only
  that worker calls quic-go's
  non-contextual `SendDatagram`. A full adapter queue leaves direct lower callers
  cancellably waiting; carrier termination closes the connection, releases a
  blocked native send, discards admitted unsent work, and joins the worker.
  Root's public queue remains a separate consumer-level boundary.
- QUIC streams and Datagrams use the same
  certificate-pinned connection, selected remote, congestion controller,
  quic-go transport, and punched packet socket. The wiremux admission pump and
  closed gate contain quic-go's
  blocking send, bounded receive/send queues, permitted silent drops, and
  post-close enqueue behavior.
- `DatagramCarrier.Lifetime` forwards the quic-go
  connection's cause-bearing context so idle peer or transport teardown reaches
  the root gate without an
  I/O operation in flight.
- `Session.Close` actively unblocks in-flight QUIC Dial/Listen setup after its context is canceled; the operation must return promptly and its registered owner performs the join. Before commit or a non-nil Dial/Accept stream, cancellation leaves the caller-supplied packet socket open and caller-owned. Any non-nil returned stream owns transport cleanup even with an accompanying error; `Session.Close` must not close or invalidate it.

Invariants:

- Transports are interchangeable from the negotiator's perspective.
- Transport names are non-empty printable-ASCII protocol identifiers
  capped at 64 bytes. Empty names or names outside that token grammar
  are invalid local transport configuration; mismatched valid names
  from peers are normal relay fallback.
- Transports obtain keying material only via `TransportAuth.Exporter()` and
  session bindings via `TransportAuth.SessionBinding`; they never receive
  directional channel keys. Additional authentication bindings arrive via the
  negotiator's channel-delivered handshake material — transports do not read
  transport-specific fields off either auth surface.
- Transports make no identity decisions of their own; they enforce
  exporter-derived material and the bindings delivered over the authenticated
  channel. Retained transport views and exporters fail with
  `ErrAuthContextReleased` after root teardown.
- A `Session`'s listener yields at most one upgraded connection. Once
  a connection is established, subsequent handshakes are refused,
  even when they present the correct pin.
- Transports use the supplied packet socket as-is for the punched
  path; they must not open a fresh socket for it. (quic-go supports
  this directly via a caller-supplied `net.PacketConn`.)
- The listener side receives the same selected remote address as the
  dialer side. Packets or handshakes from non-selected sources must be
  filtered or fail closed before they can establish or confuse a
  returned stream. `transport/quic` enforces this selected remote
  address for the lifetime of the returned stream; QUIC connection
  migration and NAT rebinding are not v1 behavior (see
  [ADR-0003](../adr/adr-0003-quic-selected-path-binding.md)).
- The v1 reliable plane is one byte stream (`io.ReadWriteCloser`), optionally
  accompanied by ADR-0009's single carrier-bound Datagram handle. QUIC's native
  stream multiplexing is not exposed; consumers that need multiple logical
  streams bring their own multiplexing. A `StreamTransport` extension interface
  remains reserved for a future ADR, so multiplexing can be added without
  confusing it with the atomic unreliable-unordered Datagram plane.
- Exporter labels share one wiremux v1 registry. Connect-level labels
  are reserved explicitly; transport labels use
  `wiremux v1 <transport>-<purpose>` (e.g., `wiremux v1 dtls-psk`).
  Transports adding new derivations must use that convention and must
  not register a transport-name/purpose pair whose formatted label
  collides with any reserved connect-level label. `wiremux v1
  probe-hmac` is reserved for authenticated UDP probes; a transport
  named `probe` cannot register purpose `hmac`. `wiremux v1 quic-psk`
  is retired unshipped; `wiremux v1 quic-confirm` is reserved
  (ADR-0001:DP8).

### `channel`

- `NewChannel(rw io.ReadWriter, auth AuthContext) (*Channel, error)`
  — encrypted framed channel over an authenticated stream.
- `(*Channel).Send([]byte) error`,
  `(*Channel).Receive() ([]byte, error)`.
- `(*Channel).Close() error` — sends the authenticated close frame,
  then closes the underlying stream when it is an `io.Closer`.
  `Channel` implements `io.Closer`.
- Optional typed-JSON helpers if useful in v1:
  `(*Channel).SendJSON(v any) error` / `(*Channel).ReceiveJSON(v any) error`.
- `NewStream(rw io.ReadWriter, auth AuthContext, opts ...StreamOption) (io.ReadWriteCloser, error)`
  — encrypted byte-stream adapter for consumers that bring their own
  framing. Applies the same directional-key validation as
  `NewChannel`; its `Close` emits the authenticated close frame.
- `AllowEmptyDataFrames() StreamOption` — opt-in stream mode for
  channel-shaped traffic that skips authenticated empty data frames
  instead of returning `ErrStreamEmptyDataFrame`.
  By default, `Read` treats an authenticated empty data frame as
  `ErrStreamEmptyDataFrame`, a terminal read-side no-progress stream
  error that does not poison the independent write side. With
  `AllowEmptyDataFrames`, `Read` may continue processing empty frames
  without returning while the peer sends only empty frames; callers that
  need cancellation or deadlines must enforce them through the
  underlying transport. `Close` is graceful, waits for any active
  `Write`, and is not an abort path for a `Write` stuck in the
  underlying transport; callers must close or cancel the underlying
  transport out-of-band to unblock it.

Per `codemux/ADR-0002:DP4`, codemux may either re-export this package,
provide its own thin wrapper, or have consumers compose
`pake.AuthContext` with this package directly. Either way, the channel
implementation lives canonically in wiremux.

Invariants:

- Frame size is bounded.
- Each direction encrypts under its own key (`SendKey()` /
  `ReceiveKey()`) with a per-direction monotonic counter nonce —
  never a random nonce. The receiver enforces strict sequence
  ordering: a replayed, reordered, or dropped frame is a fatal
  channel error. This makes replay, reordering, and mid-stream gaps
  detectable by construction and avoids random-nonce birthday
  bounds.
- `NewChannel` and `NewStream` fail if `SendKey()` or `ReceiveKey()`
  is empty, if they are equal, or if either is not a valid AES key
  size. Each frame's AAD carries a direction byte computed locally
  from `connect.DirectionalKeys` orientation — `0x01` when the sender's
  `SHA-256(SendKey())` is lexicographically greater than its
  `SHA-256(ReceiveKey())`, `0x02` otherwise; the receiver expects
  the mirror value. No runtime negotiation is involved, and a
  reflected frame fails AEAD verification, so a BYO auth context
  that supplies one symmetric key for both directions cannot
  silently produce nonce reuse or reflected frames.
- After rejecting nil local inputs, both constructors invoke
  `ChannelUseClaimer.ClaimChannelUse` when the presented auth context opts in.
  A successful claim is irreversible even if subsequent key validation or
  construction fails. Root `Dial` performs key pre-validation without claiming,
  so its one relay-channel construction makes exactly one claim for either a
  relay or eventual direct Wire.
- End-of-stream is authenticated: the channel sends a final sealed
  close frame (a `close_notify` analog) covered by the sequence and
  AEAD. A raw EOF before the close frame is a fatal truncation
  error — sequence counters alone cannot detect a clean cut at a
  frame boundary, and the relay carrying the channel is untrusted.
- The channel terminates before nonce exhaustion; rekeying is out of
  v1 scope.
- The package does not define application protocol DTOs.
- The channel uses `AuthContext.SendKey()` and
  `AuthContext.ReceiveKey()` directly; it does not call `Exporter()`.
  (Exporter is for transport-layer derivation; channel uses the
  identity layer's pre-derived directional keys.)

## `cmd/wiremux-server`

The deployable binary. Subcommands:

- `wiremux-server serve` — runs relay + STUN.
- `wiremux-server serve --no-stun` — relay only.
- `wiremux-server serve --no-relay` — STUN only.
- `wiremux-server serve --ephemeral-only` — relay accepts only
  ephemeral mode rendezvous.
- `wiremux-server serve --longlived-only` — relay accepts only
  long-lived mode rendezvous.

TLS configuration:

- `--acme` — enable ACME (Let's Encrypt) cert provisioning. Requires a domain name resolvable to the binary and reachable TLS-ALPN-01 and/or HTTP-01 challenge endpoints. v0.1.0 validates the in-process ACME listener lifecycle, not live public-CA issuance or a hosted deployment; that operational validation is deferred to [issue #924](https://github.com/GridSwarm/wiremux/issues/924).
- `--tls-cert <path>` / `--tls-key <path>` — explicit cert + key
  paths (for self-signed or operator-provided certs). When used, the
  binary emits the cert's SHA-256 fingerprint at startup for operator
  distribution to clients via their config.

Runtime lifecycle:

- `--shutdown-timeout <duration>` — maximum time the process waits for
  relay, STUN, and ACME HTTP services to stop after SIGINT/SIGTERM or a
  service error. Default `5s`. Clean signal-triggered shutdown exits 0;
  service errors and shutdown timeout exit 1.

Registration proof:

- `--longlived-proof <scheme>` — registration-proof scheme for
  long-lived mode. Default `ed25519-keyhash` (ADR-0001:DP9); `none`
  disables proof and accepts the documented PeerID-squatting risk.

The binary refuses to start without TLS configured. There is no plain-
TCP mode.

## Acceptance Criteria

1. The package set is exactly root `wiremux`, `channel`, `connect`, `relay`, `relayurl`, `stun`, `transport/quic`, `wiremuxtest`, and `cmd/wiremux-server`. The `Transport`, `Session`, and `TransportListener` contracts live in `connect`; no `connect` ⇄ `transport` import cycle exists. The eight importable packages and the server CLI are protected by the [v0.1.x compatibility contract](../COMPATIBILITY.md).
2. The `AuthContext` interface admits PAKE-derived (codemux),
   Noise-IK-derived (keymux when implemented), and externally-supplied
   auth contexts without modification. Optional claim/release capabilities
   preserve legacy contexts while enforcing single channel initialization and
   deterministic cleanup for contexts that opt in; root `Dial` owns every
   non-nil authenticator result and `Wire.Auth` exposes only a revocable,
   non-releasing view.
3. The `KeyExporter` interface produces deterministic output for
   identical `(label, context, length)` inputs and produces
   independent material for different inputs; `Derive` rejects labels
   containing 0x00. Tests pin both behaviors.
4. The relay supports both ephemeral and long-lived rendezvous modes;
   either mode can be disabled at the operator's discretion. A
   long-lived registration accepts multiple inbound pairings without
   re-registration.
5. The transport interface admits at least one non-QUIC implementation through
   the least-privilege `TransportAuth` surface without forking wiremux. (v1 ships only `transport/quic`; the
   acceptance test is that a hand-written `Transport` implementation
   satisfies the interface and integrates with the negotiator.)
6. `transport/quic` authenticates via channel-bound certificate
   pinning per ADR-0001:DP8. Tests prove a handshake fails closed —
   in both directions — when the presented certificate does not match
   the fingerprint delivered over the authenticated channel, and that
   the QUIC handshake consumes no exporter-derived PSK. Pin
   verification runs in `VerifyConnection`, and tests prove TLS
   resumption or a reused TLS config cannot bypass the pin.
7. `relayurl.Parse` accepts only `wiremux://host:port`; for DNS hosts it accepts ASCII labels with letters, digits, and interior hyphens only, removes an optional trailing root dot during canonicalization, and rejects bare `host:port`, `wiremuxs://`, `codemuxs://`, `tapmuxs://`, underscores, non-ASCII, percent escapes, spaces, numeric rightmost DNS labels, and any other variant.
8. The relay always serves over TLS. The binary refuses to start
   without TLS configured.
9. The in-process `wiremux-server` lifecycle covers ACME TLS configuration, listener preparation, service supervision, and bounded shutdown. v0.1.0 does not claim live public-CA certificate issuance, renewal, client validation in a hosted deployment, or end-to-end public-relay operation; those checks are explicitly deferred to [issue #924](https://github.com/GridSwarm/wiremux/issues/924). Private-relay deployment via an operator-provided or self-signed certificate works with client-config pin distribution.
10. The `wiremux-server` binary deploys with relay + STUN co-located
    by default and serves both modes simultaneously.
11. Direct UDP/QUIC upgrade is functional; a tapmux-shaped or file-
    sync-shaped consumer can complete a hole-punch and upgrade end-
    to-end against this surface. `Upgrade` returns `UpgradeResult`
    with the active stream, path discriminator, selected candidate
    pair and probe RTT on direct success, or a coarse fallback reason
    on relay fallback. State-machine tests prove relay fallback remains
    synchronized when one peer has a packet socket and the other does
    not, and when one peer times out or otherwise falls back then
    immediately writes application data; no upgrade-control CBOR bytes
    are delivered as application data and the peer returns a relay-path
    result rather than a framing error or deadlock. Tests also cover
    asymmetric and simultaneous fallback causes and pin the documented
    fallback-reason precedence, including the no-packet-socket case
    where the peer sends a complete malformed or zero-length first-phase
    frame and the public reason resolves to `protocol_mismatch` by the
    first-phase precedence rule. A conformance test covers exporter
    `Derive` failure for probe-key material after both peers have offered
    direct upgrade and proves both peers complete terminal fallback with
    public reason `transport_failed`, not `probe_failed`.
12. Long-lived registration is rejected without a valid
    `ed25519-keyhash` proof when proof is enabled (the default);
    `--longlived-proof=none` admits proof-free registration. Proofs
    are domain-separated and bound to the registrant↔relay TLS
    session; tests prove a recorded proof fails verification on any
    other connection. Tests also pin the transcript framing
    (length-prefixed fields; alternate field splits do not verify)
    and the canonical TLS exporter binding (label, empty context,
    32-byte output, fail-closed on exporter error).
13. The channel uses per-direction counter nonces with strict
    sequence enforcement and an authenticated close frame; tests
    prove injected replay, reordering, mid-stream drops, and
    stream-end truncation (EOF without a close frame) are fatal
    channel errors, and that both `NewChannel` and `NewStream`
    reject an auth context whose send and receive keys are equal.
    `Channel.Close` emits the close frame; a graceful-shutdown test
    proves the receiver observes the sealed close, not a raw EOF.
    Stream tests prove authenticated empty data frames fail with
    `ErrStreamEmptyDataFrame` by default, `AllowEmptyDataFrames` skips
    empty frames for channel-shaped traffic, read-side empty-frame
    failure does not poison writes, `Close` cannot split a multi-frame
    `Write`, and wrong-direction AAD fails authentication.
    Post-establishment `Wire` I/O tests prove relay and direct teardown
    failures classify with `errors.Is(err, wiremux.ErrWireClosed)`, preserve
    underlying identities, and keep graceful peer `Read` as `io.EOF`.
14. Negotiator role assignment follows the documented
    send/receive-key-hash comparison, and transport handshake
    material is exchanged only over the authenticated channel; tests
    pin both.
15. Relay resource protection is enforced and tunable: a bounded
    unpaired waiting-state budget and connection-rate caps reject
    excess load cheaply.
16. The transport upgrade reuses the exact packet socket that
    performed the successful probe: `Session.Dial` / `Session.Listen`
    receive the punched `net.PacketConn` and selected remote address,
    and an end-to-end NAT-traversal test pins that `transport/quic`
    performs its handshake over that socket rather than a freshly opened
    one. Mock transport coverage proves the listener receives or
    enforces the selected remote address; UDP coverage proves packets
    from a non-selected source cannot establish or confuse the returned
    connection.
17. Upgrade-control messages use length-prefixed Core Deterministic
    CBOR per
    [ADR-0002](../adr/adr-0002-upgrade-control-cbor.md), with small
    integer keys matching the v1 registry in this PRD, closed core
    maps, an explicit ignore-unknown extension map, fixed frame/field
    bounds, golden encodings for `offer`, `fallback`, `selected_pair`, `ready`, `commit`, `accepted`, `converged`, and `confirmed`, and negative tests for duplicate keys, indefinite
    lengths, tags, floats, unknown core fields, oversize frames,
    malformed, oversize, or over-depth extension-map contents, invalid
    offered candidates, and non-canonical encodings. Tests prove
    well-formed bounded unknown extension-map entries are accepted and
    ignored. Golden encodings include the
    `u32be(payload_len)` frame prefix, and decoder tests distinguish
    complete invalid-CBOR frames that produce `protocol_mismatch`
    fallback from truncated or oversize framing that produces a public
    `Upgrade` error.
18. UDP probes are authenticated request/response packets using an
    exporter-derived HMAC-SHA-256 key, full 32-byte tags, fixed
    transcript binding to both probe nonces and the candidate pair,
    and silent drop of unauthenticated packets. Golden-vector tests pin
    the exporter context, candidate-pair token transcript including token
    version and direction, request transcript, response transcript, and
    HMAC tags from both peer perspectives, plus full 63-byte probe
    datagrams including magic, version, message type, direction,
    `probe_id`, candidate-pair token, and tag placement, for IPv4, IPv6,
    IPv4-mapped/dual-stack candidate cases, and an explicitly bound
    same-link IPv6 link-local case whose zone is local-only and omitted
    from the wire encoding. Observed-source normalization tests prove an
    observed source such as `fe80::1%en0` matches the same offered
    unzoned candidate encoding. Tests prove spoofed, replayed,
    wrong-direction, wrong-pair, and one-way-only probes do not select a
    direct path.
19. Candidate policy is local-only and can exclude or deprioritize local interfaces, local/remote prefixes, and candidate kinds. Tests prove excluded local candidates are not advertised, excluded remote candidates are not probed, remote-prefix or kind exclusion exhaustion returns a relay-path result with `policy_excluded`, built-in-invalid or address-family-incompatible remote offers with unrelated/deprioritize-only policy return `probe_failed`, and VPN-like paths can be avoided without changing the protocol.
20. Candidate-pair selection uses bounded concurrency, policy and
    topology priority, selected-pair RTT, deterministic tie-breaking,
    dialer-selected pair announcement, listener readiness
    acknowledgement, dialer commit, listener accepted, dialer converged, listener confirmed, and one active returned stream. Tests prove both peers converge on the same selected pair and that direct success closes the obsolete relay path without enabling v1 multipath.
    A state-machine test covers delayed listener `ready`: the listener
    has sent `ready`, the dialer times out before receiving it, the
    caller context has no deadline, and both peers terminate within the
    configured internal budgets with no hang and no dialer-relay-success
    / listener-error split. A state-machine or end-to-end test proves
    that relay close or EOF during `accepted`/`converged` convergence and before valid `confirmed` fails with no stream, while relay closure after convergence is cleanup rather than a direct-upgrade abort. A companion test proves that if both peers commit, one peer closes the relay as cleanup, and direct transport later times out, `Upgrade` returns a public transport-upgrade error with no active stream rather than a relay-path result.

### Datagram acceptance criteria

21. Datagram discovery is path-sensitive and symmetric. New/new direct QUIC
    exposes a handle on both Wires only after `/2`, both RFC 9221 directions,
    and the post-commit `"wiremux.datagram/1"` intersection are negotiated.
    New/legacy, one-direction-only, one-sided `DatagramCapable`, stream-only
    custom transport, and current relay paths preserve reliable Wire success
    with `(nil, false)` in both roles. `Transport.Name()` is never used as
    capability evidence. Extension-free v1 golden frames remain valid;
    Datagram-present accepted/converged/confirmed goldens carry the extension,
    while state transitions and fallback precedence remain unchanged. A
    focused asymmetric-adapter test has both peers use one transport protocol
    with native support but only one returned stream expose `DatagramCapable`;
    both `UpgradeResult.Datagrams` values must be nil, neither
    `UpgradeResult.Stream` may satisfy `DatagramCapable`, and reliable traffic
    must still succeed. Invalid-vector codec and state-machine tests cover
    explicit CBOR `false`, another well-formed non-`true` extension value, and
    contradictory `converged` or `confirmed` echoes. Each returns
    `ErrUpgradeTransportNotConverged`, a zero result, and no active stream; these
    vectors are not valid golden frames. Decision-table tests distinguish
    normal absence, invalid native parameter encoding, generic handshake
    failure, and malformed optional-interface results. Native or generic
    transport failure before any non-nil `Accept` stream and before commit may
    settle on synchronized `transport_failed` relay fallback; failure after
    commit or a non-nil Dial/Accept stream returns
    `ErrUpgradeTransportNotConverged`, zero result, and no active stream. A
    malformed optional result after a non-nil `Dial` or `Accept` always closes
    only the returned connection, whose Close owns the exact socket, and never returns
    relay, including listener completion before observed commit.
22. The public Datagram contract is tested at zero, one, exact maximum, and
    maximum plus one bytes, including a 1191-byte QUIC baseline at the current
    configuration. Tests pin lifetime-stable directional ceilings, local
    `ErrDatagramTooLarge`, one-octet framing, empty-consumer delivery, silent
    empty-native and unknown-discriminator drops, exact message boundaries,
    send-buffer copying, caller-owned receive slices, and acceptance of an
    inbound payload larger than the receiver's own outbound ceiling. Repeated
    discovery returns the same non-nil handle before and after teardown,
    `MaxPayload` stays frozen, and handle I/O then returns `ErrWireClosed`.
    Production-Wire tests prove `newWire` snapshots
    `UpgradeResult.Datagrams`: both dialer and listener retain non-nil stable
    handles while both result streams remain reliable-only and expose no
    optional interface.
23. Datagram concurrency and lifecycle tests prove bounded cancellable send
    admission, serialized concurrent receive with exactly-one delivery,
    concurrent reliable and Datagram traffic, continued usability after
    oversize or cancellation, the documented error precedence, and one shared
    aggregate owner. Local and peer carrier teardown unblock all pending calls
    with `ErrWireClosed`, preserve underlying causes, make no drain promise, leave
    no worker or packet-socket leak, and pass the race detector without relying
    on queue sizes, delivery order, or universal delivery. An idle carrier
    termination with no send or receive pending is observed through `Lifetime`;
    every later send returns `ErrWireClosed`, preserves the cause, and never
    reports successful admission. Graceful read EOF, channel integrity failure,
    and a transport read-reset identity while carrier lifetime is still active
    close only the Datagram gate, preserve the read cause, leave no Datagram
    worker alive, and leave a subsequent reliable `Write` with today's
    independent-direction behavior. Datagram calls return `ErrWireClosed` in
    that state, and sentinel godoc makes clear that this is plane-specific and
    does not assert that reliable writes are closed. A companion
    `channel.ErrStreamEmptyDataFrame` or unclassified per-call case remains
    direction-local and leaves reliable writes plus Datagrams usable.
    Lower-receive tests distinguish a non-nil empty success, nil payload plus
    terminal error, payload plus error, and `(nil, nil)`; invalid combinations
    deliver nothing, return `ErrWireClosed`, preserve the available cause, and
    initiate aggregate teardown.
    A post-root-admission unclassified lower send error with active `Lifetime`
    is silent loss: it does not revoke the successful `Send`, appear on a later
    call, or close the Wire. An at-or-below-ceiling rejection remains terminal.
    Discovery/query methods are prompt, and blocking lower
    send/receive calls unblock on call-context cancellation and carrier
    termination. A direct `connect.Upgrade` caller can fill the QUIC adapter
    queue, cancel one blocked lower send without closing the connection, receive
    the context error promptly, and tear down without a worker leak. Continuous
    empty or reserved-discriminator input cannot starve root `Receive`:
    call-context cancellation and `Wire.Close` both return promptly without
    spinning or leaking.
24. The QUIC transport evidence record and focused tests prove that the
    reliable stream and Datagram frames use one authenticated selected-remote
    connection and congestion controller, that an injected lost marked
    Datagram is not retransmitted while later traffic proceeds, and that wrong
    certificates, handshake tampering, or non-selected sources cannot inject
    traffic. Queue saturation, receive overflow, close during native send, and
    quic-go's post-close enqueue edge stay contained behind root wiremux
    semantics. Tests distinguish an explicit at-or-below-ceiling native size
    rejection, which terminates the Wire as an observed contract breach, from
    a post-acceptance silent packer drop, which is ordinary Datagram loss.
    A lossless 1232-byte-baseline loopback repeatedly delivers 1191-byte public
    messages, while 1192 consumer bytes fail locally. Configuration tests pin
    the effective client and server `InitialPacketSize` to 1232, and a
    handshake completes over a path that rejects more than 1280 bytes on the
    wire. ALPN tests pin
    `/2` preference, `/1` mixed-version fallback, and omission of `/2` when the
    local profile-policy input is below the frame-size floor. The pinned
    quic-go API cannot inject or report a foreign peer's smaller positive
    numeric transport parameter; source audit establishes that limitation and
    the fail-closed behavior for a nonconforming peer that selects `/2`.
    Dependency or packet-sizing changes trigger renewed source and
    configuration audit rather than relying only on old black-box tests.
25. `wiremuxtest` provides a consumer-importable production-Wire Datagram
    contract suite using fresh two-peer transport fixtures. It covers present,
    absent, malformed optional-interface, mixed-peer, relay, stream-only,
    directional-size, ownership, cancellation, concurrency, and teardown
    cases in both roles. Its documentation states that executable conformance
    does not replace the adapter author's evidence obligation for security,
    retransmission, path binding, and shared congestion authority. Internal
    no-panic cases cover typed-nil carrier and lifetime values; listener
    malformed results after non-nil `Accept` are exercised with nil and non-nil
    operation errors both before and after observed commit, and dialer
    malformed results after non-nil `Dial`. An
    asymmetric-ceiling case proves each maximum is local-outbound and a smaller
    receive-side send ceiling does not cap inbound delivery.
