# wiremux v0.2.5

wiremux v0.2.5 updates four selected dependencies, corrects remote measurement result retention, and preserves the v0.2.4 public API, CLI and wire profiles.

## Dependency corrections

- [TURN v5.3.1](https://github.com/the-sarge/turn/releases/tag/v5.3.1) replaces v5.3.0-gs.1. Its required dependency changes bring STUN v3.1.7 and DTLS v3.1.8. TURN reports no direct production client logic changes; its test fixture now requires a live permission even when a channel binding remains live.
- [CBOR v2.9.4](https://github.com/fxamacker/cbor/releases/tag/v2.9.4) replaces v2.9.3 and fixes decoder panics for certain uncomparable map-key configurations. Wiremux's control decoder forbids tags and uses typed scalar map keys or bounded raw-field parsing; this update does not claim demonstrated wiremux exploitability.
- [gRPC v1.84.0](https://github.com/grpc/grpc-go/releases/tag/v1.84.0) replaces v1.83.1 only in the separate development-tools module, including the security correction for requests missing authority/Host headers plus client-idleness, STS redirect and xDS/RBAC fixes. The four pinned tools build with this selection without additional module-version changes. gRPC is not added to wiremux's runtime module, and reachability in installed tools is not claimed.
- [TruffleHog v3.97.8](https://github.com/trufflesecurity/trufflehog/releases/tag/v3.97.8) replaces v3.97.4, with all four platform archive checksums updated from the published checksum file and cross-checked against release asset digests.

## Remote measurement correction

Remote clock calibration now preserves an associated terminal worker result that arrives while a pong is expected, allowing cancellation cleanup to retain the completed warmup evidence. The controller continues rejecting mismatched run IDs, roles and PIDs, and retains the original calibration error. This pre-existing result-loss bug was exposed by the release gate and its narrow correction was approved for v0.2.5; no test or release check is waived.

## Compatibility and publication

No exported API, CLI or wire-vector change, new compatibility exception, toolchain change, or default QUIC change is intended. The [compatibility contract](https://github.com/GridSwarm/wiremux/blob/v0.2.5/docs/COMPATIBILITY.md) remains authoritative. The installed Go floor remains 1.27.1 with the Go 1.27 language baseline. Ordinary builds select upstream quic-go v0.62.0; the application-owned optional quic-go-fast v0.62.1-fast.6 selection and rollback guidance in the [v0.2.4 notes](https://github.com/GridSwarm/wiremux/blob/v0.2.4/docs/release/v0.2.4/notes.md) still apply.

The maintainer selected direct final publication without an RC using the existing release workflow. Release validation, native Linux amd64/arm64 packaged-binary smoke, NAT evidence, compatibility manifests, checksums and independent archive checks remain required. These source notes describe the release scope; verified publication is recorded subsequently in [release status](https://github.com/GridSwarm/wiremux/blob/main/docs/RELEASE.md).

Consumers can adopt the stable tag after their own validation; downstream application updates are separately owned and outside this release task. Inherited private-distribution non-claims remain: no hosted relay/SLA, bundled TURN server, container/package-manager distribution, identity layer, mesh or application protocol; unsigned annotated tags, no SBOM/attestation/cross-run reproducible-binary claim, and live public-CA ACME validation deferred to [#924](https://github.com/GridSwarm/wiremux/issues/924). Only Linux amd64/arm64 server artifacts are published.
