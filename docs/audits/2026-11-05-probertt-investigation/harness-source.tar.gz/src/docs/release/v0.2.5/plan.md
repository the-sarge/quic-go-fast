# v0.2.5 dependency correction contract

The maintainer requested: “let’s update turn, CBOR, gRPC, TruffleHog and release wiremux v0.2.5.” This work is limited to wiremux. Direct final publication through the existing workflow with `skip_candidate=true` is already selected; all validation and independent publication checks remain required.

## Acceptance criteria

- Update `github.com/the-sarge/turn/v5` to v5.3.1 and `github.com/fxamacker/cbor/v2` to v2.9.4, including only necessary module/checksum changes. Inspect TURN's fixture permission change and required STUN/DTLS dependencies against existing integration tests.
- Update only `google.golang.org/grpc` in the separate tools module from v1.83.1 to v1.84.0, following the isolated compatibility check: all four pinned tools build, and no other selected module version changes. Preserve the four direct tool pins and separation from the runtime module.
- Update TruffleHog to v3.97.8 and all four platform checksums from verified published release metadata.
- Preserve wiremux's public API, CLI and wire-vector manifests, Go floor, upstream quic-go v0.62.0 default and application-owned optional fast.6 replacement policy. Introduce no new compatibility exception or exploitability claim.
- Complete the existing local release gate (including `task verify`), focused existing TURN/control-codec regressions, one bounded review and same-head hosted CI before guarded squash merge.
- Publish immutable v0.2.5 from a frozen protected-main commit through `release.yml`; independently verify the annotated tag target, source/module identity, eight assets/checksums, compatibility manifests, four native smoke cells and eleven NAT observations, and the published-archive upstream/fork/rollback checks in `docs/RELEASE.md`. Record verified publication and journal only after their prerequisite events.

## gRPC version choice

After the maintainer requested an assessment of v1.84.0, an isolated copy of the tools module was upgraded and tidied. The only module-version change was gRPC, and `GOTOOLCHAIN=local go install tool` built all four pinned tools successfully. v1.84.0 retains the authority/Host security correction and includes client-idleness, STS redirect and xDS/RBAC fixes. Its telemetry metric renaming and stricter metadata validation do not change wiremux runtime behavior because gRPC remains tools-only. This evidence supports selecting v1.84.0 rather than the initially considered minimal v1.83.2 patch.

## Approved release-blocking correction

The first release run [35947374294](https://github.com/GridSwarm/wiremux/actions/runs/35947374294) failed `TestRemoteControllerRetainsOnlyAssociatedPostArmResults/associated` before packaging or publication. A deterministic reproducer showed that `workerProcess.calibrateRemote` could consume an associated terminal result while expecting a pong, then discard it before cancellation cleanup. This measurement code is unchanged from v0.2.4 and the failing fixture uses plain TCP. The maintainer explicitly approved including the narrow measurement fix in v0.2.5 after reviewing the five-line change and passing focused evidence.

For the correction PR, acceptance criteria are:

- Preserve an already-associated terminal `result` reply that interrupts remote clock calibration so the existing cancellation drain can consume it exactly once. Preserve the original calibration error.
- Keep the existing decoder's run-ID, role and PID association checks authoritative; rejected terminal results must never be retained.
- Cover successful and failed terminal replies plus mismatched run-ID, role and PID cases with deterministic tests at the existing worker-process seam. Keep the existing post-arm cancellation integration test intact and demonstrate its associated and rejected-role cases over 20 repetitions.
- Keep public API, CLI and wire-vector manifests unchanged. No controller redesign, new timing budget, skipped test, validation waiver or unrelated measurement change is authorized.
- Complete one fresh bounded review, local release certification and same-head hosted CI for the correction before guarded merge, then freeze a new protected-main release source and dispatch the existing direct-final workflow. The failed run's source is not a published release and must not be represented as one.

The correction is a shipped measurement-controller fix; regression tests and this receipt are verification and process artifacts. Its representation owner remains `workerProcess.decode` for association and the existing `pending` queue for retaining replies. Evidence is bounded to the named deterministic and integration regressions plus required gates. This explicitly approved exception supersedes the dependency-only runtime-edit restriction below for this terminal-result loss only. The correction PR has its own one-review-plus-at-most-one-replacement budget under the shared protocol.

## Boundaries and terminating evidence

The representation owners are Go's module resolver and checksum verification, upstream release identities, the existing CBOR/TURN implementations, Git/GitHub release identities, and the repository's compatibility generator. Pins affect shipped dependencies and development tools; release notes and receipts are process metadata. Existing tests provide bounded example-level compatibility evidence, not universal network coverage or proof of runtime vulnerability reachability.

The evidence budget is one complete local release gate at the final candidate, existing focused TURN/control-codec tests, generated-manifest comparison against published v0.2.4, the required hosted CI/release workflows and one independent published-archive check. Re-run only for changed inputs or diagnosed failures. Review budget: one fully briefed fresh review, accepted in-scope corrections and at most one replacement review under the [review protocol](../../REVIEW-LOOP.md). No new maintained harness, exhaustive platform campaign or standalone upstream transport/DTLS/QUIC/Coturn/tool-transitive upgrade is required. Runtime edits require a concrete dependency-integration failure and must remain within the existing owners; broader changes stop for a decision.

Downstream repositories and closed consumer PRs remain outside scope. The pre-existing Linux venue investigation [#1667](https://github.com/GridSwarm/wiremux/issues/1667) is separate; no validation waiver is implied. This release uses its preparation PR and tracked publication receipt for evidence, without reopening historical gate #1666 or creating unrelated tracking work.
