# wiremux v0.1.4

wiremux v0.1.4 is a private patch release on the v0.1.x line. It fixes [issue #1134](https://github.com/GridSwarm/wiremux/issues/1134) — the probe engine could record an authenticated success for a viable lower-ranked candidate pair during a repeated scheduling pass, then wait until the attempt deadline because higher-ranked pairs that had not been readmitted were incorrectly treated as unfinished blockers. The [v0.1.0 release narrative](https://github.com/GridSwarm/wiremux/blob/v0.1.0/docs/release/v0.1.0/notes.md) — supported scope, NAT traversal evidence boundary, consumer evidence boundary, candidate/provenance rules, ACME validation boundary, and private access and distribution boundary — continues to apply to this release; this note records only what changed.

## What is fixed

v0.1.3 repeats complete rank-ordered probe scheduling passes until the existing attempt deadline and stops admitting new work after any authenticated success. In the released engine, a lower-ranked pair could succeed during a later pass after only some higher-ranked pairs had been readmitted. The success correctly froze further admission, but readiness still treated never-readmitted higher-ranked pairs as pending. The dialer then reached its deadline and selected synchronized `relay/probe_failed` fallback despite already holding proof of a viable direct path.

v0.1.4 makes readiness wait only for already-active, non-exhausted higher-ranked work. Once that active work settles, the engine selects the best recorded success without admitting additional pairs. Candidate ranking, authenticated response authority, the existing deadline and concurrency bound, listener responder-only behavior, synchronized fallback when no pair succeeds, packet-socket ownership, and transport finality are unchanged.

## Compatibility

v0.1.4 is source-, wire-, and CLI-compatible with v0.1.3. It adds no exported declaration and changes no protected declaration, interface, struct layout, constant, sentinel identity, CLI flag, CLI default, control-frame encoding, probe byte, transport profile, or compatibility vector. The generated API, CLI, and wire-vector manifests are byte-identical to the published v0.1.3 assets.

Invalid `EphemeralAbuseBackoffConfig` diagnostics now include the rejected field name. `errors.Is(err, relay.ErrInvalidEphemeralAbuseBackoff)`, `errors.As` to `*relay.EphemeralAbuseBackoffConfigError`, and the exported `Field` value remain the stable programmatic contract; arbitrary diagnostic prose remains outside the normative compatibility boundary.

Consumers pinning v0.1.3 can adopt v0.1.4 as a version-only module change. The intended observable difference is that a viable authenticated success recorded during a repeated pass no longer becomes a deadline fallback merely because higher-ranked pairs were never readmitted after success froze admission.

## Maintenance hardening

The release centralizes relay-lifetime ephemeral abuse signals behind one internal policy owner while preserving the existing exported relay behavior; makes QUIC Datagram-loss certification causally identify the dropped DATAGRAM-bearing packet; strengthens `wiremuxtest.DialPair` directional half-success cleanup coverage; keeps the Task-free validation fallback synchronized; and updates CI artifact and macOS compile runners. These changes do not enlarge the supported API, CLI, wire, or artifact surface.

## Evidence

The deterministic `TestProbeCandidatePairPlanSettlesPriorPassSuccessWithLaterRanksUnscheduled` regression reproduces the released admission-freeze/readiness deadlock and passes with the active-only readiness predicate. Full `task verify` passed at the correction head and at the final reviewed PR head. A post-correction alternating two-Mac field matrix completed six of six direct/direct attempts: all three asymmetric Tailscale-down attempts selected the viable reflexive/reflexive pair, all three both-up controls selected a Tailscale host/host pair, and all twelve peer traces completed with zero dropped events. The complete trace identities, causal verdict, validation receipt, and field matrix are recorded on [issue #1134](https://github.com/GridSwarm/wiremux/issues/1134#issuecomment-5272398089).

Publication uses the repository's exact-commit release workflow: full release validation, static Linux binary packaging and inspection, the four-cell packaged-binary smoke matrix, the eleven-observation NAT gate, compatibility-manifest generation, and fail-closed immutable publication. The Release carries the established eight-asset shape, with `checksums.txt` verifying the other seven byte-for-byte. The published `wiremux-server_linux_amd64` and `wiremux-server_linux_arm64` artifacts are tested in the automated packaged-binary smoke matrix; no macOS, Windows, container, or package-manager artifact is published or claimed.

## Non-claims

All v0.1.0 non-claims stand unchanged, including: no hosted relay or SLA, no container image or package-manager distribution, no TURN-like unreliable relay, no identity layer or mesh coordination, unsigned annotated tags, no SBOM or artifact attestation, no cross-run reproducible-binary claim, live public-CA ACME issuance deferred, and private repository access as the distribution boundary with no license grant implied.
