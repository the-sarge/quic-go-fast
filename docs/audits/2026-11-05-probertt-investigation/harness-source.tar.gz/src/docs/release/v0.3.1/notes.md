# wiremux v0.3.1

This compatible release closes the QUIC controller-selection integration gap: consumers can explicitly select Reno or the optional fast.9 fork's experimental BBRv3 sender for native endpoints and the built-in upgraded transport, in either dialing/listening orientation. Existing constructors and default Reno behavior are preserved.

## API and behavior

Use `NewNativeEndpointWithQUIC` with `quic.EndpointConfig`, or create an opaque built-in transport with `quic.NewConfiguredTransport`. Initial `Dial` accepts it through `WithTransport`; authenticated establishment and migration accept it through `WithManagedQUICTransport` and `WithMigrationQUICTransport`. Every client/server connection inherits immutable settings. `NativeCandidate.CongestionController` reads the actual local connection's sender. Existing signatures, interface method sets and struct layouts are unchanged; the API inventory is additive, with unchanged CLI and wire inventories.

Explicit unsupported BBR fails before networking with `quic.ErrCongestionControlUnsupported`, detected structurally so ordinary upstream quic-go still builds. Invalid enum values fail construction. Root go.mod remains upstream v0.62.0; applications must explicitly select `github.com/the-sarge/quic-go-fast v0.62.1-fast.9` with a main-module replacement. [Exact configuration, capability errors and rollback](https://github.com/GridSwarm/wiremux/blob/main/docs/QUIC-CONTROLLERS.md) include GridCast initial, Resume and secondary paths. The [fast.9 record](https://github.com/GridSwarm/wiremux/blob/main/docs/research/quic-go-fast-v0.62.1-fast.9-native-adoption.md) retains exact source and support scope.

## ACK policy and support limits

Use `quic.ACKConservative` at **both peers** for BBR or mixed/unknown controllers. ACK policy controls the local receiver, and the local sender does not identify its peer. Conservative leaves ordinary QUIC ACK behavior. Default native Reno retains the existing ACK16 optimization and its known-Reno peer assumption; native BBR defaults to ordinary ACK behavior. Upgraded QUIC retains ordinary ACK behavior for every setting. No peer-controller or ACK-frequency negotiation is added.

BBRv3 remains experimental and unqualified for production performance, fairness, latency or throughput. Functional activation and ACK tests are not throughput qualification, and Reno certification is not BBR evidence. Native capability/platform, CPU-headroom and [throughput limitations](https://github.com/GridSwarm/wiremux/blob/main/docs/NATIVE-THROUGHPUT.md) remain. Reliable relay fallback has no QUIC controller, custom transports own their selection, and GridCast Resume does not imply native TLS resumption or 0-RTT.

## Distribution and validation

Private distribution, unsigned annotated tags, Linux amd64/arm64 server assets, checksums, compatibility inventories, native smoke and restricted NAT evidence retain the existing publisher contract. This release adds no hosted service/SLA, package-manager/container distribution, SBOM, attestation, reproducible-binary promise, identity layer or live public-CA ACME claim. Implementation/release gates, upstream and exact-fast.9 tests, reviewed preparation, required CI and independent publication/consumer verification are tracked in the [release plan](https://github.com/GridSwarm/wiremux/blob/main/docs/release/v0.3.1/plan.md) and [release status](https://github.com/GridSwarm/wiremux/blob/main/docs/RELEASE.md).
