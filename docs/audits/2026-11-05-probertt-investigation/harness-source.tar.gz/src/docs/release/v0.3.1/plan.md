# wiremux v0.3.1: supported controller selection

## Accepted outcome

Implement and publish a final, independently verified release that GridCast can pin, exposing explicit per-endpoint Reno/BBRv3 selection for native endpoints and the built-in upgraded QUIC transport, in both dialing/listening orientations. Preserve default Reno behavior, protected signatures and struct layouts, ordinary upstream builds, and experimental/unqualified BBR support limits. Explicit unsupported BBR fails before networking. Apply selection before initialization and verify actual connections. Provide conservative local ACK policy for BBR and mixed-controller peers, without inferring remote controller from local configuration.

The user's implementation and final-publication directive authorizes this bounded work and its public constructor/session/candidate test seams. No additional approval is needed for these implementation choices.

## Implementation and compatibility

Add a small QUIC endpoint settings value with closed controller (default/Reno/BBRv3) and ACK (default/conservative) enums. Add a native constructor accepting it and an opaque configured built-in transport factory. Preserve NativeConfig, Transport and consumer interface layouts/signatures. Keep immutable settings with their existing endpoint/session owners; no globals, arbitrary callbacks, runtime mutations or new asynchronous handoffs. Extend exact built-in identity gates only for the new module-owned concrete transport, including selected, managed and TURN profiles. BBR requires structural config-setter and connection-readout capability. Validate settings before creating networking resources, then apply to both client/server configs. Default native Reno retains ACK16 only when the existing capabilities allow it; conservative or BBR selection leaves ordinary QUIC ACK behavior. Upgraded QUIC retains ordinary ACK behavior for every combination. Settings apply to every new session/candidate; applications must configure every initial, Resume and secondary-path constructor on both peers.

Adding fields to existing structs violates the closed compatibility contract; reject, revisit only if the maintainer chooses a new incompatible line. Arbitrary config callbacks/global overrides add unbounded mutation/order obligations; reject on merit. Context-carried settings hide ownership and can be lost across retries; reject on merit. A new opaque transport adds bounded exact-identity recognition obligations, discharged at the existing central gates. No dependency, wire framing, CLI or peer-controller negotiation changes.

The current final is v0.3.0. With only additive APIs and preserved existing behavior/layouts, v0.3.1 is the next compatible release. Confirm the generated API delta, and unchanged CLI/wire manifests, against published v0.3.0. Root go.mod remains upstream v0.62.0; consumers explicitly replace it with github.com/the-sarge/quic-go-fast v0.62.1-fast.9.

## Evidence and review boundary

Shipped behavior: the constructors and existing configuration/connection owners. Required safety enforcement: pre-network capability rejection and repository publication gates. Maintained verification aids: focused regression tests and existing manifest/release validators. Process metadata: this plan, adoption/release documentation, review receipts and journals. Test only supported closed enum values, invalid values, capability present/absent/error, client/server orientation, local ACK default/conservative and homogeneous/mixed controllers. Structural Go method sets own capability representation; quic-go owns configuration and immutable connection readout; exact concrete-type gates own built-in eligibility. No universal network/performance claim.

Terminating evidence: test-first constructor rejection/default preservation; actual native and upgraded connection controller readouts for Reno/Reno, BBR/BBR, BBR/Reno and Reno/BBR; conservative/default ACK coverage including on-wire ACK evidence; upstream and exact fast.9 focused/race suites; compatibility inventories; task release-gate; one fully briefed initial RAS review with independent dispositions and at most one replacement after accepted fixes; exact-head local certification and post-ready required CI. No recursive testing of evidence aids or new throughput qualification. Diagnose failures before retrying.

## Delivery sequence

One implementation/release-preparation draft PR, bounded manual RAS review, exact-head validation, ready CI and guarded squash. Append the post-merge journal only after merge. Freeze protected-main source after that journal. Use the established release workflow, normal candidate then same-source final promotion, verifying candidate and final independently. Do not stop at a candidate. Verify tag/source/module, notes, eight assets/checksums and evidence; exercise a separate main module pinned to the published final with explicit fast.9 replacement using public APIs. Record the verified final in a documentation PR and post-merge journal. Track [release gate #2057](https://github.com/GridSwarm/wiremux/issues/2057) separately from preparation so the gate cannot close before verification.

## Non-goals and stops

No downstream repository edits, publisher redesign, BBR throughput guarantee, archived certification changes, reopened #1935 measurement campaign, #2045 diagnosis, GARM changes or VM/disk cleanup. Preserve all retained infrastructure. BBR remains experimental and unqualified for production performance. Stop for an incompatible API delta, an unresolvable in-scope safety issue or a publisher failure requiring scope expansion; preserve evidence and diagnose concrete failures within scope first. Follow ../../REVIEW-LOOP.md and the shared review/closure policies.
