# wiremux v0.1.3

wiremux v0.1.3 is a private patch release on the v0.1.x line. It fixes [issue #1006](https://github.com/GridSwarm/wiremux/issues/1006) — a viable direct candidate pair could receive authenticated traffic only after its single outbound probe burst had ended, leaving one peer direct while the dialer reported `probe_failed` and fell back to relay. The [v0.1.0 release narrative](https://github.com/GridSwarm/wiremux/blob/v0.1.0/docs/release/v0.1.0/notes.md) — supported scope, NAT traversal evidence boundary, consumer evidence boundary, candidate/provenance rules, ACME validation boundary, and private access and distribution boundary — continues to apply to this release; this note records only what changed.

## What is fixed

Through v0.1.2, each eligible candidate pair received one bounded probe burst. A peer could authenticate a request after the other side had exhausted that pair, proving that the return path was viable while leaving no later outbound pass to converge on it. Because the dialer remains the selected-pair authority, that asymmetric terminal state produced a synchronized relay fallback even with most of the attempt budget unused.

v0.1.3 repeats complete rank-ordered scheduling passes until the existing attempt deadline. Each pass preserves candidate priority, the existing three-request burst and retry spacing, settled-success exclusion, and permanent retirement after a recoverable write failure. Once any authenticated success exists, the engine stops admitting new lower-ranked work, settles priority-ready success before reactivation, and keeps listener-side success receive/respond-capable until selected-pair control, fallback control, cancellation, or the existing deadline ends the hold. The attempt timeout, concurrency default, candidate ranking, selected-pair authority, synchronized fallback semantics, and exact packet-socket ownership contract are unchanged.

## Compatibility

v0.1.3 is source-, wire-, and CLI-compatible with v0.1.2. It adds no exported declaration and changes no protected declaration, interface, struct layout, constant, sentinel identity, CLI flag, CLI default, control-frame encoding, probe byte, transport profile, or compatibility vector. The generated API and CLI manifest baselines and the normative [v0.1.x compatibility contract](https://github.com/GridSwarm/wiremux/blob/main/docs/COMPATIBILITY.md) are unchanged; the published wire-vector manifest is expected to remain byte-identical to v0.1.2. Mixed-version peers continue to interoperate because the correction changes only when an endpoint revisits already negotiated candidate pairs within its existing attempt bound.

Consumers pinning v0.1.2 can adopt v0.1.3 as a version-only module change. The intended observable difference is that direct establishment can recover when authenticated probe traffic opens a viable path after the first outbound burst instead of falling back asymmetrically.

## Maintenance hardening

The release also consolidates internal ownership, settlement, Datagram-admission, and error-tree traversal paths; keeps QUIC packet profiles immutable for a connection lifetime; makes accidental-correctness cleanup paths explicit; and hardens validation and release-evidence generation against ambient Go configuration and vacuous fixture passes. These changes preserve the documented v0.1.x contracts and expose no new consumer surface.

## TURN boundary

The tree contains unexported TURN-retry codec and probe primitives plus internal packet-path ownership groundwork for the separately tracked TURN/UDP relay architecture program. v0.1.3 does not activate that path, publish root TURN options, change the wire profile, bundle a TURN server, or claim TURN interoperability. TURN-like unreliable relay remains outside this release.

## Evidence

The exact implementation head passed `task verify`, focused race coverage, the unchanged nine-row deterministic restricted-NAT matrix, and exact-head hosted certification. A repeated four-cell two-Mac field matrix completed 12/12 runs with matching terminal decisions — seven direct/direct and five relay/relay — with zero asymmetric `probe_failed`, exactly one terminal attempt event per trace, zero dropped trace events, successful clock samples, and byte-identical consumer binaries. The complete evidence archive and its SHA-256 receipt are attached to [issue #1006](https://github.com/GridSwarm/wiremux/issues/1006#issuecomment-5229502894).

Publication uses the repository's exact-commit release workflow: full release validation, static Linux binary packaging and inspection, the four-cell packaged-binary smoke matrix, the eleven-observation NAT gate, compatibility-manifest generation, and fail-closed immutable publication. The Release carries the established eight-asset shape, with `checksums.txt` verifying the other seven byte-for-byte.

## Non-claims

All v0.1.0 non-claims stand unchanged, including: no hosted relay or SLA, no container image or package-manager distribution, no TURN-like unreliable relay, no identity layer or mesh coordination, unsigned annotated tags, no SBOM or artifact attestation, no cross-run reproducible-binary claim, live public-CA ACME issuance deferred, and private repository access as the distribution boundary with no license grant implied.
