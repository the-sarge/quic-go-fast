# wiremux v0.1.0

wiremux v0.1.0 is the first private release of GridSwarm's identity-agnostic pairwise connectivity kernel. The manual release workflow validates the selected protected-main commit, attaches exact compatibility, NAT, package, smoke, and checksum evidence from that same run, and publishes only after every gate passes; this checked-in narrative is not itself release evidence.

## Supported scope

The released Go surface consists of root `wiremux`, `channel`, `connect`, `relay`, `relayurl`, `stun`, `transport/quic`, and `wiremuxtest`. The release also includes the `wiremux-server` operator binary. Root `wiremux.Dial` joins relay rendezvous, a consumer-supplied identity handshake, encrypted channel establishment, STUN candidate discovery, authenticated UDP probing, synchronized relay fallback, and direct transport upgrade without assigning peer identity itself.

The reliable byte stream is required on every Wire. Direct QUIC Wires can also expose the optional borrowed Datagram handle; relay and stream-only carriers remain reliable-only. The relay supports ephemeral `SessionID` rendezvous and long-lived `PeerID` registration, with `ed25519-keyhash` proof enabled by default for long-lived mode.

The supported server shape is one `wiremux-server serve` process running TLS relay and STUN together by default, or either service separately. Relay service is TLS 1.3 only. Operators can use an explicit certificate and distribute its SHA-256 pin for private trust, or configure the implemented ACME listener path subject to the validation boundary below. This release does not operate a hosted relay or provide an SLA, container image, package-manager distribution, TURN-like unreliable relay, identity layer, mesh coordination, or application protocol.

## NAT traversal evidence

The v0.1.0 gate exercises nine self-characterizing rows through production STUN, authenticated probes, synchronized fallback, root `wiremux.Dial`, the exact supplied packet socket, real QUIC on direct rows, and bidirectional reliable payload. Mapping and filtering are independent RFC-style axes: EIM is endpoint-independent mapping, ADM is address-dependent mapping, APDM is address-and-port-dependent mapping, EIF is endpoint-independent filtering, ADF is address-dependent filtering, and APDF is address-and-port-dependent filtering.

| Row | Controlled profile | Required v0.1.0 outcome |
| --- | --- | --- |
| 1 | Public/host baseline without translation | Direct |
| 2 | EIM + EIF | Direct |
| 3 | EIM + ADF | Direct |
| 4 | EIM + APDF | Direct; release publication also requires the privileged `nat-smoke-linux` repetition |
| 5 | ADM + EIF | Relay with synchronized `probe_failed` |
| 6 | ADM + APDF | Relay with synchronized `probe_failed` |
| 7 | APDM + APDF | Relay with synchronized `probe_failed`; release publication also requires the privileged `nat-smoke-linux` repetition |
| 8 | Asymmetric EIM/APDF versus APDM/APDF | Relay with synchronized `probe_failed` |
| 9 | UDP blackhole after successful STUN | Relay with synchronized `probe_failed` |

The matrix is representative, not exhaustive. It does not promise universal hole-punch success, a deployed-device success rate, port prediction, peer-reflexive candidate learning, carrier-grade or cascaded NAT coverage, hairpinning, mapping expiry or rebinding, address pooling or port exhaustion, ALG behavior, fragmentation, NAT64, IPv6 firewall behavior, or TURN-like unreliable relay service. A direct result proves the controlled topology and current synchronized probe schedule; a relay result proves safe pairwise fallback for that controlled topology. Each release run retains one schema-valid `nat-evidence.json` containing the nine deterministic observations and the two privileged `nat-smoke-linux` observations at the selected commit; those rows prove only the observed in-process or kernel/socket path, not that deployed NATs universally behave like the selected profiles. No transient network observation becomes a permanent NAT classification. Legacy “cone” and “symmetric” labels are descriptive shorthand only, not the asserted behavior.

## v0.1.x compatibility

The [normative compatibility contract](../../COMPATIBILITY.md) protects every exported declaration and documented behavior in all eight public packages, exported sentinel identity and documented error trees, the endpoint/pin, relay, long-lived proof, encrypted-channel, upgrade-control, authenticated-probe, QUIC, Datagram, and STUN profiles, and the `wiremux-server` CLI contract.

Source- and wire-compatible additions require API and applicable mixed-version evidence before release and then join the protected v0.1.x baseline. Interface methods and fields on externally literalizable structs are not presumed compatible additions. Exact diagnostic prose, private implementation details, and help whitespace are outside the promise unless specifically identified as machine-relevant.

The channel teardown rule is intentionally narrow: `channel.ErrTruncated` is a suppressible teardown artifact only when the local side initiated teardown. Otherwise it remains an integrity signal and must surface. Cooperative close does not guarantee peer-observed clean EOF; clean EOF, a wrapped wire-closed transport error, and truncation can all result from one abrupt teardown.

## Consumer evidence boundary

The release owner evaluates the three buildable private integrations discovered before v0.1.0—codemux, tapmux, and GridCast—against the selected candidate before dispatching the final release. Those downstream records remain useful release evidence, but mutable issue comments and consumer ledgers are not machine authorization inputs to the wiremux publishing workflow.

keymux and SwarmCast have no buildable wiremux integration at this release boundary and receive no v0.1.0 compatibility claim. Their dated repository evidence is an explicit deferral, not a passing consumer row. GridCast use of any unexported `wiremuxtest` detail is point-in-time test evidence only and does not enlarge the public API.

The named consumer gates do not by themselves claim native Linux arm64 application compatibility unless their recorded authoritative jobs actually run there. Linux arm64 coverage for this release is the built, inspected, and smoke-tested server artifact, not a general downstream-application claim.

## Candidate, final build, and provenance

The accepted release candidate and final `v0.1.0` annotated tags peel to the same commit. The manual final-release dispatch names that published candidate, and the workflow verifies the common commit before rebuilding the final-version binaries so their embedded Go module version reports `v0.1.0`. Candidate and final binary digests therefore intentionally differ even though their source commit is identical. Publication accepts only the same-run binaries and evidence, with every asset covered by `checksums.txt`.

The tags are annotated but not cryptographically signed. This release makes no claim of an SBOM, workflow-generated private-repository artifact attestation, or cross-run reproducible binaries. SHA-256 checksums detect accidental corruption and substitution relative to the published checksum set; they do not prove publisher identity or protect against a compromised publisher that replaces both a binary and its checksum.

## ACME validation boundary

The release validates the in-process ACME configuration and listener lifecycle, including listener preparation, service supervision, and bounded shutdown. It does not claim live public-CA issuance or renewal, Web PKI validation by a client without a distributed pin, or behavior in an operator-hosted public topology. Those checks require public DNS and operator-controlled infrastructure and are deferred to [issue #924](https://github.com/GridSwarm/wiremux/issues/924).

## Private access and distribution boundary

The GitHub Release and assets are repository-private. Authenticated read access to the private repository is the access-control boundary; possession or disclosure of an asset URL is not an authorization mechanism. These notes do not make the repository public, grant redistribution rights, or state a software license. Private distribution and any license grant require a separate owner-approved agreement; repository or Release access alone must not be interpreted as either.
