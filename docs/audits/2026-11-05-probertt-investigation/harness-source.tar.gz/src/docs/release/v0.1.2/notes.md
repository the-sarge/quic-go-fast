# wiremux v0.1.2

wiremux v0.1.2 is a private, additive patch release on the v0.1.x line. It fixes [issue #1001](https://github.com/GridSwarm/wiremux/issues/1001) — direct QUIC wires died after 30 seconds of application silence — with one additive public API change and one deliberate default-behavior change in `transport/quic`. The [v0.1.0 release narrative](https://github.com/GridSwarm/wiremux/blob/v0.1.0/docs/release/v0.1.0/notes.md) — supported scope, NAT traversal evidence boundary, consumer evidence boundary, candidate/provenance rules, ACME validation boundary, and private access and distribution boundary — continues to apply to this release; this note records only what changed.

## What is fixed

Through v0.1.1, `transport/quic` configured neither QUIC keepalives nor an explicit idle deadline, so quic-go's 30-second default idle timeout tore down any direct wire whose application traffic went quiet — the canonical victim being an attached-but-idle proxied terminal session, which cannot inject its own keepalive bytes without corrupting the proxied protocol. Relay-path wires were unaffected. v0.1.2 makes the transport own the remedy at the layer that imposed the deadline.

## What is new

`quic.Transport` gains two exported fields and two exported constants:

- `Transport.KeepAlivePeriod` — interval between QUIC keepalive PING frames on wires created by the transport's sessions. Zero applies `DefaultKeepAlivePeriod` (15 seconds, half the default idle deadline and quic-go's cap on the effective interval); a negative value disables keepalives, matching `net.Dialer.KeepAlive` semantics.
- `Transport.MaxIdleTimeout` — the longest network silence the endpoint tolerates before wire teardown; each endpoint's effective deadline is the minimum of its own configured value and the peer's advertised value, with the peer-advertised value subject to the QUIC implementation's minimum remote idle timeout (five seconds in the pinned quic-go). Zero applies `DefaultMaxIdleTimeout` (30 seconds, stating quic-go's default explicitly rather than inheriting it silently); `NewSession` rejects negative values.
- `DefaultKeepAlivePeriod` and `DefaultMaxIdleTimeout` — the protected default constants above.

The zero-value `Transport` — including the default transport used by root `wiremux.Dial` — now keeps established direct wires alive through application-idle periods. Keepalive frames are invisible to the application byte stream. Battery- or network-sensitive consumers can tune both fields or disable keepalives entirely via `wiremux.WithTransport(quic.Transport{...})`.

## Compatibility

v0.1.2 is source- and wire-compatible with v0.1.1. `Transport` previously had no exported fields, so no consumer-held literal can break; the API compatibility manifest differs from v0.1.1 by exactly the two fields and two constants above. The wire profiles are unchanged: keepalives are core RFC 9000 PING frames requiring no negotiation, and mixed-version wires interoperate because either peer's keepalives reset both idle timers while each endpoint's idle deadline stays bounded by its own configured value and the peer's advertised value. Consumers pinning v0.1.1 can adopt v0.1.2 as a version-only module change; the only observable difference is that idle direct wires now survive.

The new declarations join the protected v0.1.x compatibility baseline defined by [COMPATIBILITY.md](https://github.com/GridSwarm/wiremux/blob/main/docs/COMPATIBILITY.md), including the default constant values and the zero/negative field semantics.

## Evidence

This release publishes through the same manual single-run release workflow as v0.1.1: full validation at the selected protected-main commit, static binary packaging and inspection, the four-cell packaged-binary smoke matrix, the eleven-observation NAT gate, and fail-closed immutable publication, with the same eight digest-verified assets — `checksums.txt` verifying the other seven byte-for-byte. The coverage gap that let #1001 survive to human release testing is closed at the transport seam: regression tests hold a real loopback wire idle past its configured `MaxIdleTimeout` and assert post-idle round-trips with keepalives defaulted on, assert idle teardown with keepalives disabled, pin the default constants and zero/negative resolution rules, and reject negative idle deadlines. Consumer migrations to v0.1.2 are owned by the consumer repositories and gated there; no downstream compatibility claim is enlarged by this release.

## Non-claims

All v0.1.0 non-claims stand unchanged, including: no hosted relay or SLA, no container image or package-manager distribution, no TURN-like unreliable relay, no identity layer or mesh coordination, unsigned annotated tags, no SBOM or artifact attestation, no cross-run reproducible-binary claim, live public-CA ACME issuance deferred, and private repository access as the distribution boundary with no license grant implied.
