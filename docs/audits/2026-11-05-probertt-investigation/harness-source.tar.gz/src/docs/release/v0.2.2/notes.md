# wiremux v0.2.2

wiremux v0.2.2 is a private, upstream-compatible release on the v0.2.x line. It publishes the optional packet-I/O integration and managed socket facade qualified by the [assembled support decision](https://github.com/GridSwarm/wiremux/blob/v0.2.2-rc.1/docs/research/e02-support.md). Ordinary builds select upstream `github.com/quic-go/quic-go v0.62.0`. Applications may explicitly select `github.com/the-sarge/quic-go-fast v0.62.1-fast.3`; replacing a dependency in a library does not select it for downstream applications.

## Compatibility and accumulated changes

The API manifest adds the opaque `ManagedPacketEndpoint`, its constructor, packet/deadline/close methods, `WithManagedPacketEndpoint` and `ErrManagedPacketEndpointUnsupported`. It also includes the previously merged post-authentication `EstablishAuthenticated`, `ManagedWire`, `ManagedOption` constructors and `EstablishmentError`; initial `Wire.Abort`; and `Negotiator.UpgradeStrict`, `UpgradeError`, its kind constants and `ErrStrictUpgradeTURNUnsupported`. These are additions to the published v0.2.1 API. Existing exported struct shapes and consumer interface method sets are unchanged. The CLI and wire-vector manifests remain byte-identical to v0.2.1.

The [compatibility contract](https://github.com/GridSwarm/wiremux/blob/v0.2.2-rc.1/docs/COMPATIBILITY.md) owns the behavioral guarantees, including the inherited v0.2.0 wire/operator exceptions and v0.2.1 `channel.Receive` payload lifetime. The [managed establishment guide](https://github.com/GridSwarm/wiremux/blob/v0.2.2-rc.1/docs/MANAGED-ESTABLISHMENT.md) describes the separate owning post-authentication API; it is not the managed packet endpoint. Existing initial `Dial` and graceful `Wire.Close` behavior remain supported. The release also includes intervening lifecycle, auth-release observer, strict-upgrade and Datagram hardening; no new wire grammar or peer migration is introduced by the packet-I/O integration.

The language floor remains `go 1.27`; the approved installed toolchain is now `go1.27.1`. The ordinary QUIC dependency advances from v0.61.0 to v0.62.0, with the [selected-path source audit](https://github.com/GridSwarm/wiremux/blob/v0.2.2-rc.1/docs/research/quic-go-v0.62-source-audit.md). Other dependency updates are recorded in the released module files. Consumers must use the patched installed toolchain before fetching or building. Downstream compatibility and adoption are owned by the named QUIC-IO consumer slices, not claimed by this release.

## Select the optional fork

In the application's main module, after the wiremux release is published:

```sh
go get github.com/GridSwarm/wiremux@v0.2.2
go mod edit -replace=github.com/quic-go/quic-go=github.com/the-sarge/quic-go-fast@v0.62.1-fast.3
go mod tidy
go list -m -json github.com/quic-go/quic-go
```

The final command must show the replacement path and exact version above. Keep QUIC imports under `github.com/quic-go/quic-go`; do not import the fork under a second module identity or select `@latest`. The [fork release](https://github.com/the-sarge/quic-go-fast/releases/tag/v0.62.1-fast.3) records its immutable source and reconciliation to the E02 receipts, including subsequent diagnostic labeling and Linux pre-mutation EPERM fallback corrections. No fork replacement is shipped in wiremux's own module graph.

## Managed reuse and peer policy

The [compiling consumer example](https://github.com/GridSwarm/wiremux/blob/v0.2.2-rc.1/managed_packet_example_test.go) creates a `NewManagedPacketEndpoint`, retains the parent across attempts and supplies it with `WithManagedPacketEndpoint`. Each attempt uses fresh authentication and rendezvous agreement; close its Wire before the next attempt, and close the endpoint after its last use. Preparation acquires the exact exclusive lease; failure, reliable fallback, TURN selection and successful teardown release that lease. Parent packet operations are rejected while leased, and acquisition rejects in-flight parent I/O. The parent owns the native socket and restores saved logical deadlines after lease teardown. The facade exposes no raw descriptor or detach operation.

The constructor returns `ErrManagedPacketEndpointUnsupported` with upstream or an incompatible extension. Required managed capability is never silently emulated. Applications that accept ordinary single-use sockets can handle that sentinel by using ordinary `Dial` without the managed option. Raw socket options retain their existing ownership rules.

Wiremux retains its selected-peer wrapper on direct and managed paths. Exact-resource receive permission is issued only for eligible internally owned or immediately transferred native sockets, or the proven managed lease, after establishment readers join. Borrowed raw sockets retain ordinary receive; opaque wrappers, custom transports and TURN cannot gain permission from promoted methods and are not unwrapped. The fork's independent fixed-peer API does not replace wiremux's wrapper or TLS identity authentication. Raw socket handback after receive coalescing is unsupported; toggling an option does not normalize queued data.

## Support, fallback and rollback

The [support matrix](https://github.com/GridSwarm/wiremux/blob/v0.2.2-rc.1/docs/research/e02-support.md) distinguishes source guarantees from example-level native observations: Linux arm64 guest loopback GSO/GRO and managed normalization; Windows Server 2025 amd64 guest-NIC USO/URO and managed normalization; and qualified Darwin arm64 native batch send with ordinary receive. Managed send capability differs by platform as recorded there. These receipts cover their exact frozen hosts and binaries, not every OS, NIC or workload.

All three assembled performance comparisons terminated unavailable with zero official pairs. This release makes no assembled-Wire speedup, CPU/allocation, p99 latency, resident-memory preservation, physical capacity or multi-gigabit claim. Upstream remains the ordinary default. Selecting the fork enables eligible paths under existing activation rules; there is no new per-Wire offload switch.

Set `QUIC_GO_DISABLE_GSO=true`, `QUIC_GO_DISABLE_GRO=true` or `QUIC_GO_DISABLE_SENDMSG_X=true` before initialization to disable the corresponding fork send, receive or Darwin batch optimization. Darwin retains the `quic_go_no_private_syscalls` build exclusion, iOS exclusion, kernel allowlist, self-check and failure latch. Supported unavailable/disabled optimizations retain ordinary paths; invalid registration, fatal setup, malformed metadata and unknown send progress remain errors. Disable switches do not emulate managed capability under upstream.

To roll back the optional selection, first stop requiring the managed endpoint (handle the unsupported sentinel and use ordinary `Dial`, or remove the managed option) and remove any direct fork-only calls. Then, in the application module:

```sh
go mod edit -dropreplace=github.com/quic-go/quic-go
go get github.com/quic-go/quic-go@v0.62.0
go mod tidy
go list -m -json github.com/quic-go/quic-go
go test ./...
```

Verify that the graph selects upstream v0.62.0 without a replacement. If another dependency requires a higher version, resolve that graph explicitly before claiming this rollback target. Preserve authentication, selected-peer policy and socket disposal during rollback. The wiremux release can remain v0.2.2. Consumer-specific build, failure, idle and teardown receipts remain downstream work.

## Publication and evidence boundary

The [release workflow](https://github.com/GridSwarm/wiremux/blob/v0.2.2-rc.1/.github/workflows/release.yml) owns publication: a candidate and final version must target the same protected-main commit. It runs `task release-gate`, regenerates the three compatibility manifests, builds static Linux amd64/arm64 server binaries, runs four native packaged-binary smoke cells and eleven NAT observations, and publishes the eight-asset checksummed bundle as an immutable Release. Independent post-publication verification, outside that workflow, checks the downloaded source archive with ordinary upstream and the exact optional fork selection using the [publication runbook](https://github.com/GridSwarm/wiremux/blob/v0.2.2-rc.1/docs/RELEASE.md#v022-release-source-and-publication-gate). Review and local/hosted CI certify the source; publication and downloaded-archive receipts belong to the release record, not a forecast in these notes. Authority links use the accepted candidate tag, which is retained and targets the same commit as the final release.

No new performance campaign, maintained diagnostic collector or runtime test framework is introduced. Existing private-distribution non-claims remain: no hosted relay/SLA, bundled TURN server, container/package-manager distribution, identity layer, mesh or application protocol; unsigned annotated tags, no SBOM/attestation/cross-run reproducible-binary claim, and public-CA ACME validation still deferred to [#924](https://github.com/GridSwarm/wiremux/issues/924). Only Linux amd64/arm64 server artifacts are published; other platform evidence has the explicit boundaries in the support matrix.
