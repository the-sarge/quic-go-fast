# wiremux v0.2.3

wiremux v0.2.3 is a private, source- and wire-compatible release on the v0.2.x line. It adds `ManagedWire.Datagrams() (*Datagrams, bool)` so callers of `EstablishAuthenticated` can discover and use the existing optional borrowed Datagram plane on direct QUIC Wires. Reliable-only relay fallback returns `(nil, false)`.

## Compatibility

The API-manifest delta from v0.2.2 is exactly the new concrete method. Repeated discovery returns the same handle, including after close; its operations enforce the owned Wire lifetime. Managed abort and graceful close terminate that handle, while canceling an individual Datagram operation leaves reliable I/O usable. There is no independent Datagram close, raw carrier access, new managed transport option, consumer-interface requirement, public struct layout change, or CLI/wire-vector delta.

The [compatibility contract](https://github.com/GridSwarm/wiremux/blob/v0.2.3/docs/COMPATIBILITY.md) and [managed establishment guide](https://github.com/GridSwarm/wiremux/blob/v0.2.3/docs/MANAGED-ESTABLISHMENT.md) own the behavior. Existing payload, queue, error and teardown contracts remain unchanged. The five managed public-seam cases cover relay absence, direct discovery and exchange, operation cancellation, abort and graceful flush. This release makes no new performance or exhaustive concurrency claim.

## Adoption and publication

After verified final publication, consumers can pin `github.com/GridSwarm/wiremux@v0.2.3`. GridCast D1 owns its dependency adoption and capability forwarding; code merge or candidate publication alone does not unblock it. codemux, keymux and other consumer upgrades remain separate work.

Go 1.27 and the approved installed Go 1.27.1 floor remain unchanged. Ordinary builds retain upstream quic-go v0.62.0; the optional fork selection, support domain and rollback instructions from [v0.2.2](https://github.com/GridSwarm/wiremux/blob/v0.2.2/docs/release/v0.2.2/notes.md) continue to apply. Managed authenticated Datagram use does not require that fork or a managed packet endpoint.

By maintainer instruction, v0.2.3 is published directly without an RC using the release workflow's explicit `skip_candidate=true` input. The protected-main source, release validation, checksummed manifest/server/smoke/NAT bundle and immutable publication checks remain required. The [M-release gate](https://github.com/GridSwarm/wiremux/issues/1581) records independent immutable tag, Release, checksum, manifest and published-source/module verification, including this exported method. Authority links use the final tag at the frozen source commit. These source notes do not claim that publication has occurred.

Inherited private-distribution non-claims remain: no hosted relay/SLA, bundled TURN server, container/package-manager distribution, identity layer, mesh or application protocol; unsigned annotated tags, no SBOM/attestation/cross-run reproducible-binary claim, and public-CA ACME validation deferred to [#924](https://github.com/GridSwarm/wiremux/issues/924). Only Linux amd64/arm64 server artifacts are published.
