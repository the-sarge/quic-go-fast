# v0.2.4 release contract

The maintainer approved qualifying quic-go-fast v0.62.1-fast.6 and releasing wiremux. Updating downstream applications is outside the authorized scope. Prepare one wiremux release PR, complete its bounded review and merge, append its journal, then publish from a frozen protected-main commit through the existing release workflow. The maintainer subsequently selected direct final v0.2.4 publication with `skip_candidate=true`, waiving only the RC; all other validation remains required. Publication receipts belong to the release gate; source merge is not publication completion.

## Acceptance criteria

- Keep upstream quic-go v0.62.0 as the ordinary module selection; advertise fast.6 only as an explicit application-owned replacement.
- Re-audit ADR-0003's selected-peer enforcement against the exact published fast.6 source, including native packet reads/writes, managed ECN correlation and checked sends, DF restoration, and managed lease ownership.
- Record bounded compatibility evidence for fast.6 using the existing wiremux suite, focused race tests, managed reuse/failure/fallback/TURN, selected-interface and authenticated migration cases, Datagram ceilings, mixed upstream/fork peers, and upstream rollback. Require managed capability for fork-specific runs rather than accepting skips.
- Describe the complete v0.2.3-to-v0.2.4 API and behavior delta, including already merged managed migration, selected-interface support, lifetime corrections and allocation improvements. Preserve existing wire profiles and CLI behavior, and compare generated compatibility manifests with the published v0.2.3 assets.
- Complete `task verify`, the existing release gates, bounded RAS review, exact-head hosted CI, and independent published-archive checks before declaring release completion.
- Publish verified immutable v0.2.4 directly from the frozen commit using `release.yml` with `skip_candidate=true` and no `source_candidate`; verify the annotated tag target, eight assets, checksums, manifests, native smoke and NAT records.

## Boundaries and evidence

This PR changes release guidance and evidence (process/traceability metadata). Existing test executables, isolated module files and capture scripts are disposable verification aids, not new maintained product components. Runtime fixes are permitted only when a concrete integration failure demonstrates they are needed for this adoption and the smallest correction preserves the existing owners; a broader ownership or API redesign stops for a decision.

The representation owners remain Go's module resolver and AST-based compatibility generator, Git/GitHub release identities, and existing QUIC/native socket parsers. Evidence is example-level compatibility at recorded source and platform identities, not a universal offload, performance or arbitrary-network guarantee. Preserve selected-peer authority, exact lease binding, transport/lease close separation, direct 1232/1191 and TURN 1200/1159 public packet/Datagram profiles, and opt-in upstream rollback.

The finite evidence budget is one complete local upstream gate, one fast.6 suite and focused race pass, one representative mixed-peer run in each direction, native platform checks where available, and the existing required hosted/release workflows at the final candidate. Native fork receipts supplement source reconciliation; they do not become new wiremux native-platform claims. No new benchmark campaign, exhaustive platform cross-product, repeated stress campaign or mutation harness is required. Additional runs respond only to changed source or diagnosed failures. Review budget: one fully briefed RAS review, accepted corrections and at most one replacement review; apply the documentation-polish exemption from the [review protocol](../../REVIEW-LOOP.md).

Contract closure is not triggered for this metadata-only preparation. The changed dependency behavior is audited at its existing enforcement owners and exercised by bounded existing regressions. If the audit or tests expose a material runtime obligation beyond those owners, revise the contract before implementing it.

## Scope correction after publication

The agent incorrectly included downstream application updates in the original contract. The maintainer clarified that these were never requested. GridCast #1202, tapmux #703 and codemux #621 were closed without merging; no downstream default branch was changed by this work. This correction does not change the immutable v0.2.4 release or its validation evidence.
