# wiremux v0.2.4

wiremux v0.2.4 publishes opt-in authenticated managed migration, selected-interface APIs for Linux, macOS and Windows, and accumulated socket-lifetime and receive-allocation corrections since v0.2.3. Ordinary builds continue selecting upstream quic-go v0.62.0. Applications may explicitly select quic-go-fast v0.62.1-fast.6 after evaluating their workloads.

## Changes and compatibility

`PrepareMigration` accepts an existing module-owned relay Wire and fresh authenticated inputs, prepares an opaque direct candidate, and returns a `MigrationSession` with explicit commit/abort outcomes. The old Wire remains usable before commit; commit retires it through the existing lifetime owner and returns a distinct `ManagedWire`. This is caller-coordinated bilateral migration, not automatic QUIC rebinding or a new wire protocol. The [migration guide](https://github.com/GridSwarm/wiremux/blob/v0.2.4/docs/MANAGED-MIGRATION.md) owns input transfer, cancellation, seal and terminal-outcome semantics.

The new `selection` package resolves opaque interface handles. `relay.WithSelection`, root `WithSelection`, `WithManagedSelection`, and `WithMigrationSelection` constrain their documented construction paths; `Wire.SelectionInfo` and `ManagedWire.SelectionInfo` return copied diagnostics. Managed selected establishment/migration requires the exact provenance-bearing relay carrier and identical handle. Existing sockets retain their native bound lifetime; subsequent constructors use current interface identity and family availability. Selected IPv6 scope remains under native socket/packet-info authority. See [selected relay](https://github.com/GridSwarm/wiremux/blob/v0.2.4/docs/SELECTED-RELAY.md), [selected initial establishment](https://github.com/GridSwarm/wiremux/blob/v0.2.4/docs/SELECTED-INITIAL.md), and [managed establishment](https://github.com/GridSwarm/wiremux/blob/v0.2.4/docs/MANAGED-ESTABLISHMENT.md).

The release also preserves selected post-close error attribution, retires disposed selected UDP enforcement after relay fallback, classifies selected TCP permission failures, and reduces selected batch-receive allocations by reusing bounded scratch storage. The [bounded allocation receipt](https://github.com/GridSwarm/wiremux/blob/v0.2.4/docs/research/batch-receive-cache/README.md) owns that measured result; it is not a general throughput, latency or offload-performance claim. Test and manifest-generator corrections are included.

Compared with published v0.2.3, the API inventory adds the migration types/options/outcomes, selection package, selection options and diagnostics. `Dial` gains named result variables in the generated text; its Go function type is unchanged. The generator now inventories public named-struct aliases' fields and methods, including the new selection aliases. Existing consumer interfaces and protected struct layouts are unchanged. CLI and wire-vector manifests are byte-identical. The [compatibility contract](https://github.com/GridSwarm/wiremux/blob/v0.2.4/docs/COMPATIBILITY.md) and generated release assets remain authoritative. No new compatibility exception is introduced.

## Optional fork adoption and rollback

Keep imports under `github.com/quic-go/quic-go`. The application's main module owns the replacement; a library's replacement does not propagate to its consumers:

```sh
go mod edit -replace=github.com/quic-go/quic-go=github.com/the-sarge/quic-go-fast@v0.62.1-fast.6
go mod tidy
go list -m -json github.com/quic-go/quic-go
```

The result must retain required upstream version v0.62.0 and show replacement path `github.com/the-sarge/quic-go-fast` at exactly `v0.62.1-fast.6`. Wiremux itself ships no replacement. Avoid `@latest`. Fast.5 failed its publication gate and is neither the adoption nor rollback target.

The [fast.6 release](https://github.com/the-sarge/quic-go-fast/releases/tag/v0.62.1-fast.6) adds managed ECN on its qualified Linux, Darwin, FreeBSD and Windows endpoints, managed DF/path-MTU discovery on qualified Linux and Darwin leases, and Darwin 27 arm64 batch-send admission. Its platform limits and unresolved incidents remain applicable. The [wiremux dependency audit and receipts](https://github.com/GridSwarm/wiremux/blob/v0.2.4/docs/release/v0.2.4/qualification.md) distinguish source reconciliation, native examples and inherited fork evidence; they do not extend wiremux platform or performance claims. The selected-peer wrapper remains authoritative. Managed lease release joins I/O and restores owned socket options/deadlines; `Transport.Close` alone does not release the lease. Direct and TURN Datagram admission ceilings remain lifetime-fixed at 1191 and 1159 public bytes respectively; TURN `/3` still disables path-MTU discovery.

For upstream rollback, remove required managed-packet-endpoint usage, remove the application replacement, restore upstream and revalidate the workload:

```sh
go mod edit -dropreplace=github.com/quic-go/quic-go
go get github.com/quic-go/quic-go@v0.62.0
go mod tidy
go list -m -json github.com/quic-go/quic-go
```

The final result must show v0.62.0 with no replacement. `NewManagedPacketEndpoint` then returns its explicit unsupported sentinel; ordinary Wire and managed authenticated establishment remain supported. A consumer reverting only this optional-version update may restore its previously qualified fast.3 replacement. Fast.6's own release recommends fast.4 for its fork-specific rollback; wiremux's prior published assembled qualification was fast.3.

## Publication and adoption

The installed Go 1.27.1 floor and Go 1.27 language baseline remain unchanged. Publication uses the existing workflow: the maintainer explicitly selected direct immutable v0.2.4 publication from a frozen protected-main commit (`skip_candidate=true`, no RC), with release validation, Linux amd64/arm64 packaged-binary smoke, NAT evidence, manifests and checksums. [Release gate #1666](https://github.com/GridSwarm/wiremux/issues/1666) records independent verification. These source notes describe the selected release, not a completed publication receipt.

After final publication, downstream applications can pin `github.com/GridSwarm/wiremux@v0.2.4`; application-owned fork replacements require separate updates. Existing selected-interface pseudo-version consumers can move to the stable tag after their own validation. No implicit application upgrade or new default fork policy is introduced.

Inherited private-distribution non-claims remain: no hosted relay/SLA, bundled TURN server, container/package-manager distribution, identity layer, mesh or application protocol; unsigned annotated wiremux tags, no SBOM/attestation/cross-run reproducible-binary claim, and live public-CA ACME validation deferred to [#924](https://github.com/GridSwarm/wiremux/issues/924). Only Linux amd64/arm64 server artifacts are published.
