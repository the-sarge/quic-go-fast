# v0.2.6 release contract

The maintainer approved preparing and publishing v0.2.6 after the HKDF exporter correction (#1594) completed. This task releases the merged wiremux changes since v0.2.5 through the existing publisher. The maintainer subsequently selected direct final publication without an RC using `skip_candidate=true`; this supersedes the original candidate-to-final sequence. The initial reviewed main is `52774790099728f3c483c80633c5ae0f9ed1eba8`; freeze the final source only after the direct-final notes correction merges.

## Acceptance criteria

- Publish release notes covering present-interface resolution, ordered relay and authenticated establishment, the global ordered namespace-observation classification correction, HKDF exporter diagnostic protection, joined relay proxy completion, and the six internal ownership/validation refactors. Preserve documented support limits and non-claims.
- Verify the generated API manifest against the committed baseline and immutable v0.2.5 assets: exactly the 38 additive inventory lines already merged, with no removal or changed declaration. CLI and wire-vector manifests must remain byte-identical to v0.2.5. Dependencies, toolchain baseline and default/optional QUIC selections remain unchanged.
- Complete one bounded preparation review, the local release gate and exact-head hosted CI before guarded squash merge. No runtime or workflow changes are part of release preparation.
- Publish immutable v0.2.6 directly from a frozen protected-main source through release.yml with `skip_candidate=true` and no `source_candidate`. Recheck live tag and Release state before dispatch; all release gates remain required.
- Independently verify each published version: immutable Release, annotated tag and frozen source identity, all eight asset digests and sizes, checksums, generated compatibility manifests, tracked release notes, both binary identities, four native smoke cells, eleven successful NAT observations, and published-source upstream/fork/rollback checks from docs/RELEASE.md. Include existing ordered-selection and HKDF diagnostic regressions in archive validation.
- Record publication evidence and update current release documentation only after successful publication and verification. Append the development journal only after the corresponding work is merged. Downstream version adoption remains separately owned.

## Added published-archive command

For the extracted final archive, after the installed-toolchain audit and before the optional-fork replacement, run this existing-test selector with ordinary upstream quic-go:

```sh
GOTOOLCHAIN=local GOWORK=off go test -count=1 -run '^(TestDialOrdered|TestNewOrdered|TestResolvePresent|TestHKDFKeyExporter)' . ./relay ./selection ./connect
```

Retain the command and output with the archive receipt. The independent verifier runs on macOS arm64; Linux-only ordered tests and opt-in native fixtures are not claimed by that archive run. The release workflow's Linux full-suite gate and the merged feature PRs retain their separate Linux evidence. The existing required-capability fork and upstream-rollback commands in [release status](../../RELEASE.md) remain unchanged; this added selector runs once under upstream per published version. Update the active archive recipe with this selector in the post-publication record.

## Boundaries and terminating evidence

Git/GitHub own source and immutable publication identity; the repository compatibility generator owns the canonical inventory; existing package implementations own runtime behavior. Release notes, this plan and receipts are process metadata. The guarantee is equality of captured identities/inventories and bounded success of the existing tests, native smoke and NAT observations, not universal network or diagnostic protection.

The evidence budget is one full local release gate on the final preparation head, one initial preparation review with accepted in-scope corrections and at most one replacement under the [review protocol](../../REVIEW-LOOP.md), the required hosted CI and final release workflow, and one independent archive verification per published version. Repeat only for changed inputs or diagnosed failures. Existing ordered/HKDF tests discharge the added archive checks; no new maintained harness, platform campaign, performance study or production refactor is required.

The unresolved Linux venue investigation [#1667](https://github.com/GridSwarm/wiremux/issues/1667) is not a validation waiver. Any concrete release failure must be diagnosed before retry; an outcome requiring broader runtime changes needs its own decision. Do not absorb open dependency PRs or alter previous immutable releases. Publication receipts belong with this release preparation PR and the later tracked release record.

## Direct-final correction

At the maintainer’s instruction, the initial [RC run 36090556697](https://github.com/GridSwarm/wiremux/actions/runs/36090556697) was canceled before publication. No RC tag or Release was observed when the correction began. This documentation-only follow-up changes publication mode and authority links; it adds no runtime change or validation waiver. The preparation review and its independently resolved documentation findings remain recorded in [PR #1729](https://github.com/GridSwarm/wiremux/pull/1729).
