# wiremux v0.2.6

wiremux v0.2.6 adds ordered selected-interface establishment, protects HKDF exporter diagnostics, and corrects relay completion accounting. It also includes internal ownership and validation refactors accumulated since v0.2.5.

## Ordered selected-interface establishment

`selection.ResolvePresent` captures an existing interface even when it is down or lacks usable addresses, preserving its opaque identity for later attempts. Existing `selection.Resolve` still requires a ready interface. Neither API automatically replaces a stale interface by name.

`selection.NewOrdered` accepts 1–4 distinct interface handles and a positive per-candidate connection timeout. `relay.DialOrdered` and root `wiremux.DialOrdered` try those interfaces serially before committing one relay request. Root dialing prepares required selected UDP resources before that commitment, authenticates once, and uses only the chosen handle for direct carriage, safe relay fallback and session consumption. Copied receipts expose bounded attempt outcomes and the successful chosen handle.

Trust rejection and terminal setup failures stop selection. Once a relay request begins, pairing or authentication failure does not advance to another interface. The ordered APIs introduce no automatic authentication retry or default-route fallback. Temporary Linux global namespace-observation failures are classified as `OrderedTerminalSetup`, preserving selection and OS causes; unsupported environments and malformed input retain `OrderedInvalid`.

The [selected-interface contract](https://github.com/GridSwarm/wiremux/blob/v0.2.6/docs/SELECTED-RELAY.md) describes supported Linux, macOS and Windows behavior, system-DNS routing, native identity limits, budgets, receipts and option conflicts. Existing single-selection entry points retain their behavior; no new platform, recovery guarantee or timing SLA is claimed.

## HKDF exporter diagnostic protection

The exporter returned by `connect.NewHKDFKeyExporter` no longer exposes its retained HKDF pseudorandom key through the specified direct, exported/unexported holder, and rejected-verb `fmt` diagnostic matrix. Direct supported formatting is intentionally redacted; fallback diagnostics may contain pointer addresses or formatting error syntax. Protection includes invalid and zero-value states. This fixes [#1594](https://github.com/GridSwarm/wiremux/issues/1594), delivered by [PR #1727](https://github.com/GridSwarm/wiremux/pull/1727).

The `KeyExporter` interface, HKDF outputs, validation behavior, copied-input ownership and raw/revocable exporter lifetime contracts are preserved. This is not a universal reflection, unsafe-memory, third-party serializer, custom logger or memory-erasure guarantee, and no remote exploit or unexamined logging-path exposure is claimed.

## Relay completion and internal maintenance

Relay proxy completion now waits for its owned copy readers, idle monitor and optional allowance worker after the existing drain and close actions. Accounting is released after those joins while short-pair observation remains at the drained phase. Existing timeout policy and runtime abandonment remain; progress still depends on I/O and callbacks returning. See [PR #1711](https://github.com/GridSwarm/wiremux/pull/1711).

Internal refactors centralize settlement-result admission, worker-reply custody, Wire-owned migration transitions, ordered after-choice error classification, static selected-option validation and retained control-decoding facts. These preserve their existing public contracts and make no new performance claim.

## Compatibility and publication

The public API delta from v0.2.5 is additive: ordered selection types, outcomes, receipts and errors; the two `DialOrdered` entry points; and `selection.ResolvePresent`. CLI and wire-vector inventories are unchanged. The [compatibility contract](https://github.com/GridSwarm/wiremux/blob/v0.2.6/docs/COMPATIBILITY.md) remains authoritative; no new compatibility exception is introduced.

Dependencies and the toolchain baseline are unchanged: Go 1.27 with installed Go 1.27.1 or newer, upstream quic-go v0.62.0 by default, and application-owned optional quic-go-fast v0.62.1-fast.6 selection with explicit upstream rollback. The [v0.2.4 notes](https://github.com/GridSwarm/wiremux/blob/v0.2.4/docs/release/v0.2.4/notes.md) retain optional-fork support boundaries. Existing Linux venue investigation [#1667](https://github.com/GridSwarm/wiremux/issues/1667) remains separate and no release gate is waived.

The maintainer selected direct final publication without an RC through the existing workflow with `skip_candidate=true`, from one frozen protected-main commit. Full release validation, native Linux amd64/arm64 packaged-binary smoke, NAT evidence, manifests, checksums and independent published-archive checks remain required. These source notes state release scope; verified publication is recorded subsequently in [release status](https://github.com/GridSwarm/wiremux/blob/main/docs/RELEASE.md).

Consumers adopt the stable tag through their own validation and follow-up PRs. Inherited private-distribution non-claims remain: no hosted relay/SLA, bundled TURN server, container/package-manager distribution, identity layer, mesh or application protocol; unsigned annotated tags, no SBOM/attestation/cross-run reproducible-binary claim, and live public-CA ACME validation deferred to [#924](https://github.com/GridSwarm/wiremux/issues/924). Only Linux amd64/arm64 server artifacts are published.
