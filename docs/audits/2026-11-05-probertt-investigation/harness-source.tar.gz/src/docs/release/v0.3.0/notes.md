# wiremux v0.3.0

wiremux v0.3.0 opens the v0.3.x line with the native connectivity and packet-I/O work merged since v0.2.7, relay admission hardening, and application-owned optional quic-go-fast v0.62.1-fast.9 selection. It carries deliberate source and behavioral changes described below. Upstream quic-go v0.62.0 remains the default dependency; selecting this wiremux version alone does not enable native endpoints.

The [compatibility contract](https://github.com/GridSwarm/wiremux/blob/v0.3.0/docs/COMPATIBILITY.md) is normative. The twelve public packages, existing entry points, CLI inventory and inventoried wire vectors remain; native authentication and promotion retain the same connection, stream, port, channel binding and framing. The inherited [v0.1.0 scope](https://github.com/GridSwarm/wiremux/blob/v0.1.0/docs/release/v0.1.0/notes.md) and subsequent documented additions continue to apply within the changes recorded here.

## Native admission, transport and Datagram changes

Binding admission now caches peer identity/source/route verdicts under OS network-change notifications, with a one-second maximum age and the precise lazy-refresh qualifications in the compatibility contract. Kernel ingress remains checked per datagram; without a working notification channel admission is queried afresh. Linux and Windows coalesced reads admit the shared source/destination metadata once per read. This replaces v0.2.7's per-datagram native query; it is preliminary native admission under the existing trusted-host-configuration guarantee, not atomic kernel enforcement ([#1784](https://github.com/GridSwarm/wiremux/issues/1784), [#1876](https://github.com/GridSwarm/wiremux/issues/1876)).

[ADR-0016](https://github.com/GridSwarm/wiremux/blob/v0.3.0/docs/adr/adr-0016-native-binding-admission-failures.md) distinguishes peer refusal, temporary binding outage and binding loss. Temporary outages and refused receives are discarded without failing the binding. Native sends refused by admission can be reported to QUIC as written, allowing its loss recovery to respond; binding loss still latches staleness and ends the connection. A native Wire that reaches its idle timeout can retain the binding's last admission refusal as a diagnostic hint. Socket errors outside the documented exceptions remain fatal. Discovery retains its separate outage contract.

A native Wire's send ceiling now follows the path-MTU-discovered limit at promotion. `MaxNativeDatagramPayload` rises from 1191 to 1411; a Wire commonly fixes its ceiling at 1191 before discovery or 1397 after discovery reaches 1438-byte packets on an MTU-1500 path. The ceiling stays fixed for that Wire's lifetime and can differ by direction. `MinDatagramPayload` above 1191 requires discovery to have progressed before authentication/promotion. Ordinary upgraded direct `/2` and TURN relay `/3` ceilings are unchanged ([#1917](https://github.com/GridSwarm/wiremux/issues/1917)).

`Wire.Native()` snapshots add `NativeWireInfo.DatagramReceiveDrops` and `DatagramReceiveDropsAvailable`. The count is the native QUIC connection's cumulative received-DATAGRAM full-queue discard count, retained after completed aggregate teardown. Available zero is a measured zero; unavailable zero is a placeholder. The count excludes other packet, kernel, network and application loss and does not promise delivery. **Adding these fields breaks unkeyed `NativeWireInfo` composite literals; use keyed literals** ([#1969](https://github.com/GridSwarm/wiremux/issues/1969)).

The native path uses the admitted batch-capable socket surface, delegates network admission when the fork offers it, and grants native receive coalescing on Linux and Windows. Native Datagram sends share the carrier's bounded queue with one admission copy; native receives avoid the second payload copy while preserving caller ownership. Channel records are submitted in one `Write` with unchanged framing. Stream-parent cleanup now wakes after its close grace ([#1802](https://github.com/GridSwarm/wiremux/pull/1802), [#1805](https://github.com/GridSwarm/wiremux/pull/1805), [#1950](https://github.com/GridSwarm/wiremux/pull/1950), [#1954](https://github.com/GridSwarm/wiremux/pull/1954), [#1967](https://github.com/GridSwarm/wiremux/pull/1967), [#1996](https://github.com/GridSwarm/wiremux/pull/1996), [#2001](https://github.com/GridSwarm/wiremux/pull/2001), [#2010](https://github.com/GridSwarm/wiremux/pull/2010), [#2013](https://github.com/GridSwarm/wiremux/pull/2013)).

Native Reno transports opt into acknowledging every 16 ack-eliciting packets with the fork's one-millisecond group cap; absent capability or another sender retains the default rule. Upgraded QUIC Wires keep their acknowledgment rule. Apple-silicon native transports opt into the fork's send-worker QoS capability where available. Promoted macOS sockets may connect to their selected peer, batch sends with `sendmsg_x` and receive into fork-provided batch slots; failed connect retains the unconnected path. Connected sockets drop the specified ICMP-driven errors and `ENOBUFS` as lost datagrams, and reject a different destination. Darwin receive probes are queued before batch qualification to avoid the corrected startup timing problem. Platform, build, launch-context and kill-switch qualifications remain in the linked adoption and certification records ([#1963](https://github.com/GridSwarm/wiremux/pull/1963), [#2016](https://github.com/GridSwarm/wiremux/pull/2016), [#2020](https://github.com/GridSwarm/wiremux/pull/2020), [#2027](https://github.com/GridSwarm/wiremux/pull/2027), [#2029](https://github.com/GridSwarm/wiremux/pull/2029), [#2037](https://github.com/GridSwarm/wiremux/pull/2037)).

## Relay admission and migration

The relay bounds stalled TLS/request work separately from pairing/registration occupancy: default global pending connections are 256 and default source pending connections are 32, with additive limits and non-blocking limit events in the `relay` package. Pending capacity is released before waiting for a peer. A registered PeerID's pending long-lived dial capacity now reserves room across source buckets: one bucket may use at most `max(1, per-peer cap/4)`, or 32 at the default total of 128. Excess attempts receive the existing resource-limit classification before queue entry or listener notification ([#1881](https://github.com/GridSwarm/wiremux/pull/1881), [#1888](https://github.com/GridSwarm/wiremux/pull/1888)).

Long-lived registrations now have a default source quota of 128, further capped at half the global budget with a minimum of one, and an **absolute one-hour default lease that keepalives do not extend**. Clients must handle `ErrRegistrationLost` by reacquiring with `Listen`; already paired streams continue after expiry. `WithMaxSourceLongLivedRegistrations`, `WithLongLivedRegistrationLease` and `WithLongLivedRegistrationLimitEvents` expose the new package controls. Clients behind one NAT, proxy or IPv6 prefix share a bucket. This deliberately tightens v0.2.7 behavior; see [deployment guidance](https://github.com/GridSwarm/wiremux/blob/v0.3.0/docs/DEPLOYMENT.md#long-lived-registration-admission) for tuning, telemetry and distributed-source limits ([#1889](https://github.com/GridSwarm/wiremux/pull/1889)).

## Optional fast.9 selection and rollback

Native endpoints require the selected QUIC module's versioned native and external packet-I/O capabilities. Ordinary upstream quic-go v0.62.0 reports unsupported, and `NewNativeEndpoint` returns `ErrNativeUnsupported` before socket/network activity. The optional native lane selects the published [v0.62.1-fast.9 prerelease](https://github.com/the-sarge/quic-go-fast/releases/tag/v0.62.1-fast.9), source `0f717339f767df5d2e4091b2515266d61f66e2ac`. It is immutable by fork policy; GitHub-enforced fork immutability is not claimed.

The application owns selection. From its module, after auditing installed Go 1.27.3 or newer:

```sh
export GOTOOLCHAIN=local GOWORK=off
go mod edit -replace=github.com/quic-go/quic-go=github.com/the-sarge/quic-go-fast@v0.62.1-fast.9
go mod tidy
go list -m -json github.com/quic-go/quic-go
go test ./...
```

Require the replacement path/version in the selected-module JSON and check `wiremux.NativeSupported()` before relying on native endpoints. Run the application's native integration tests with capabilities required; wiremux's own qualification uses `WIREMUX_TEST_NATIVE=required` and `WIREMUX_TEST_MANAGED_PACKET_IO=required` so absent capabilities fail instead of skipping. Those environment variables govern wiremux's tests; they do not configure the application's transport. A module dependency's own replacement does not propagate into the application.

Explicit rollback restores ordinary upstream behavior, including unsupported native endpoints:

```sh
go mod edit -dropreplace=github.com/quic-go/quic-go
go get github.com/quic-go/quic-go@v0.62.0
go mod tidy
go list -m -json github.com/quic-go/quic-go
go test ./...
```

Require upstream v0.62.0 and no `Replace` in the rollback JSON. The [fast.9 adoption record](https://github.com/GridSwarm/wiremux/blob/v0.3.0/docs/research/quic-go-fast-v0.62.1-fast.9-native-adoption.md) owns the idle path-MTU probe timer fix and exact source/module identity; the [fast.8 record](https://github.com/GridSwarm/wiremux/blob/v0.3.0/docs/research/quic-go-fast-v0.62.1-fast.8-native-adoption.md) retains bundle decisions, packet-I/O reconciliation and accepted costs. Selecting fast.9 also selects its connection-wide queues, bounds, short-DATAGRAM gluing and managed-reader changes; this is broader than enabling native entry points. The 1024-entry received-DATAGRAM queue, 32-entry send queue/batch cap and recorded RTT/CPU/latency costs remain disclosed. Existing [managed packet-I/O support boundaries](https://github.com/GridSwarm/wiremux/blob/v0.3.0/docs/research/e02-support.md) and selected-peer enforcement remain applicable; raw socket return after receive coalescing remains unsupported.

## Measured native results and limits

[Native throughput](https://github.com/GridSwarm/wiremux/blob/v0.3.0/docs/NATIVE-THROUGHPUT.md) owns the figures, actual measured product/fork revisions, processor-headroom rule and busy-consumer results. Linux met both floors in its netns/veth shape cell using fast.8; macOS met both floors over Thunderbolt Bridge using fast.9. Windows Server 2025/e1000e VM measurements using fast.9 missed three of four floors; the measured misses are accepted outcomes, with [#2045](https://github.com/GridSwarm/wiremux/issues/2045) separately owning diagnosis. Arm remains pending. These records are preserved as measured; Linux fast.8 figures are not measurements of fast.9 or of a physical NIC.

Throughput figures are measured statements, not compatibility promises or universal Windows/QEMU/GCP conclusions. Consumers need processor headroom; default-GC and launch-context rows, virtual-NIC and hardware-offload limits, queue/latency/CPU costs, Windows sender qualification and the Arm guest crash watch remain in the records. The deferred late-read detector [#1924](https://github.com/GridSwarm/wiremux/issues/1924) does not block release. No certification campaign is reopened for publication.

## Compatibility, toolchain and publication

Compared with immutable v0.2.7 assets, the API inventory has 35 new lines and the `MaxNativeDatagramPayload` value replacement (36 added lines, one removed line). Existing declaration names and function signatures remain. CLI and wire-vector inventories are byte-identical; this does not erase the struct-literal and behavioral changes above.

The language floor remains Go 1.27; the installed/base toolchain floor is now **Go 1.27.3**, pinned by both root and tools modules. Root dependencies move `x/crypto` v0.57.0 → v0.58.0, `x/net` v0.59.0 → v0.61.0, `x/sys` v0.48.0 → v0.49.0 and indirect `x/text` v0.42.0 → v0.43.0. The tools-only lint pin moves to golangci-lint v2.14.0. Upstream quic-go v0.62.0 remains unchanged, with no root replacement.

The maintainer selected direct final publication with `skip_candidate=true` and no RC, from one frozen protected-main commit through the existing workflow. Full release validation, Linux amd64/arm64 packaged-server smoke, NAT evidence, inventories, checksums and independent published-source upstream/fork/rollback verification remain required. Verified publication is recorded subsequently in [release status](https://github.com/GridSwarm/wiremux/blob/main/docs/RELEASE.md).

Consumers adopt v0.3.0 in their own follow-up PRs, checking keyed native snapshots, registration reacquisition, shared-source limits and application-owned fork selection. Distribution remains private with Linux amd64/arm64 server artifacts, unsigned annotated tags, no SBOM/attestation/reproducible-binary claim, no hosted relay/SLA, bundled TURN server, container/package-manager distribution, identity layer, mesh or application protocol. Live public-CA ACME validation remains deferred to [#924](https://github.com/GridSwarm/wiremux/issues/924).
