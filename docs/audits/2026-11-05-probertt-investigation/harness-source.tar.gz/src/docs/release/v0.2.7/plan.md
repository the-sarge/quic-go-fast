# v0.2.7 release contract

The maintainer approved preparing and publishing v0.2.7 after the interface-scoped native dial (#1778) merged, selecting direct final publication without an RC using `skip_candidate=true`, and asked for a maintained top-level changelog. This task releases the merged wiremux changes since v0.2.6 through the existing publisher. The initial reviewed main is `61b57e3b779629914ec9ca65d54b559c8ad64b66`; freeze the final source only after release preparation merges.

## Acceptance criteria

- Publish release notes covering scoped unicast bindings, scoped discovery datagram I/O, paired relays and ordered paired relays before authentication, the setup-record codec, native candidates, native authentication and promotion, the native keepalive, bounded-Close, promotion-admission and interface-scoped dial follow-ups, the paired-relay abandon join ordering, and the pion/transport patch update. Preserve documented support limits and non-claims, including that no fork release is qualified for native use.
- Add `CHANGELOG.md` as a thin index of published releases: a few lines per release linking its tracked notes, which remain authoritative. Record v0.2.7 and back-fill v0.1.0 through v0.2.6.
- Verify the generated API manifest against the committed baseline and immutable v0.2.6 assets: exactly the 170 additive inventory lines already merged, including the new `binding` and `discovery` packages, with no removal or changed declaration. CLI and wire-vector manifests must remain byte-identical to v0.2.6. The toolchain baseline and default/optional QUIC selections remain unchanged; the only dependency change is pion/transport v4.1.1.
- Complete one bounded preparation review, the local release gate and exact-head hosted CI before guarded squash merge. No runtime or workflow changes are part of release preparation.
- Publish immutable v0.2.7 directly from a frozen protected-main source through release.yml with `skip_candidate=true` and no `source_candidate`. Recheck live tag and Release state before dispatch; all release gates remain required.
- Independently verify the published version: immutable Release, annotated tag and frozen source identity, all eight asset digests and sizes, checksums, generated compatibility manifests, tracked release notes, both binary identities, four native smoke cells, eleven successful NAT observations, and published-source upstream/fork/rollback checks from docs/RELEASE.md. Include the existing paired-relay, setup-record, native and binding/discovery regressions in archive validation.
- Record publication evidence, update current release documentation and date the changelog entry only after successful publication and verification. Append the development journal only after the corresponding work is merged. Downstream version adoption remains separately owned.

## Added published-archive command

For the extracted final archive, after the installed-toolchain audit and before the optional-fork replacement, run this existing-test selector with ordinary upstream quic-go:

```sh
GOTOOLCHAIN=local GOWORK=off go test -count=1 -run '^(TestPairRelay|TestPairedRelay|TestSetupRecord|TestWriteSetupRecord|TestReadSetupRecord|TestNative|TestListen)' . ./binding ./discovery
```

Retain the command and output with the archive receipt. Under upstream quic-go the native tests that need a capable fork skip; native fixture coverage is not claimed by the archive run. The independent verifier runs on macOS arm64; Linux-only and opt-in native fixtures are not claimed by that run. The release workflow's Linux full-suite gate and the merged feature PRs retain their separate evidence. The existing required-capability fork and upstream-rollback commands in [release status](../../RELEASE.md) remain unchanged; this added selector runs once under upstream. Update the active archive recipe with this selector in the post-publication record.

## Boundaries and terminating evidence

Git/GitHub own source and immutable publication identity; the repository compatibility generator owns the canonical inventory; existing package implementations own runtime behavior. Release notes, the changelog, this plan and receipts are process metadata. The guarantee is equality of captured identities/inventories and bounded success of the existing tests, native smoke and NAT observations, not universal network or native-path qualification.

The evidence budget is one full local release gate on the final preparation head, one initial preparation review with accepted in-scope corrections and at most one replacement under the [review protocol](../../REVIEW-LOOP.md), the required hosted CI and final release workflow, and one independent archive verification. Repeat only for changed inputs or diagnosed failures. Existing tests discharge the added archive checks; no new maintained harness, platform campaign, fork qualification, performance study or production refactor is required.

Any concrete release failure must be diagnosed before retry; an outcome requiring broader runtime changes needs its own decision. Do not absorb open dependency PRs or alter previous immutable releases. Publication receipts belong with this release preparation PR and the later tracked release record.
