# wiremux v0.1.1

wiremux v0.1.1 is a private, additive patch release on the v0.1.x line. It contains exactly one public API addition over [v0.1.0](https://github.com/GridSwarm/wiremux/releases/tag/v0.1.0) and no production behavior change. The [v0.1.0 release narrative](https://github.com/GridSwarm/wiremux/blob/v0.1.0/docs/release/v0.1.0/notes.md) — supported scope, NAT traversal evidence boundary, consumer evidence boundary, candidate/provenance rules, ACME validation boundary, and private access and distribution boundary — continues to apply to this release; this note records only what changed.

## What is new

`wiremuxtest.(*Relay).RequireEphemeralWaiter(testing.TB, relay.SessionID)` joins the supported public surface: a bounded, non-participating assertion that the fixture relay currently has an unpaired ephemeral waiting peer registered for the exact Session ID. It observes waiter state linearized with the relay ledger without dialing, pairing, consuming, or otherwise mutating rendezvous state; its failure diagnostics are redacted, and fixture termination aborts an in-flight assertion promptly. The module-internal plumbing that supplies waiter state to the fixture is not part of the public surface, and no other package exports a new declaration.

The addition ships under the owner-approved commitment in [issue #987](https://github.com/GridSwarm/wiremux/issues/987): it permanently joins the protected v0.1.x compatibility baseline defined by [COMPATIBILITY.md](https://github.com/GridSwarm/wiremux/blob/main/docs/COMPATIBILITY.md), as a maintained contract surface rather than point-in-time test evidence. It exists so consumers that orchestrate multi-process rendezvous tests — first GridCast — can prove a waiting peer is registered before starting its counterpart, replacing weaker consumer-owned readiness markers.

## Compatibility

v0.1.1 is source- and wire-compatible with v0.1.0. The frozen v0.1.0 public surface is unchanged except for the one additive `wiremuxtest` declaration above: the `wiremux-server` CLI contract and every profile frozen by the compatibility contract are unchanged, and the API compatibility manifest differs from v0.1.0 by exactly that declaration. Consumers pinning v0.1.0 can adopt v0.1.1 as a version-only module change.

## Evidence

This release publishes through the same manual single-run release workflow as v0.1.0: full validation at the selected protected-main commit, static binary packaging and inspection, the four-cell packaged-binary smoke matrix, the eleven-observation NAT gate, and fail-closed immutable publication, with the same eight digest-verified assets — `checksums.txt` verifying the other seven byte-for-byte. The NAT matrix remains representative, not exhaustive, exactly as bounded in the v0.1.0 narrative. Consumer migrations to v0.1.1 are owned by the consumer repositories and gated there; no downstream compatibility claim is enlarged by this release.

## Non-claims

All v0.1.0 non-claims stand unchanged, including: no hosted relay or SLA, no container image or package-manager distribution, no TURN-like unreliable relay, no identity layer or mesh coordination, unsigned annotated tags, no SBOM or artifact attestation, no cross-run reproducible-binary claim, live public-CA ACME issuance deferred, and private repository access as the distribution boundary with no license grant implied.
