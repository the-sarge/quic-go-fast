# Native Wire throughput

This document is the one place wiremux publishes native Wire throughput figures: the per-platform targets, the processor headroom they assume, and the measured effects of a busy consumer. These figures are measured statements, not compatibility promises; [COMPATIBILITY.md](COMPATIBILITY.md) holds the contract, and the native entry points' godoc states the consumer rule without figures.

Every figure keeps the label of the ticket it comes from: **measured**, **derived** or **source**. Each table links the decision or research it was copied from.

## What a figure means

- **Unit:** one native Wire at MTU 1500, at the cells' sub-millisecond round trip, packets per second first, with Gbit/s for Datagrams and the stream. Datagrams run at the pin (`-ballast 64 -gc-role both`), with the default-GC row reported beside it ([Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797), section 4).
- **Host state:** Certified with an otherwise idle consumer, under the headroom rule ([Processor headroom](#processor-headroom)).
- **Link types:** stated for MTU-1500 paths (Ethernet, Wi-Fi, Thunderbolt Bridge, the internet). On a slower link the link is the limit (**derived**, not certified). Relay paths aren't native and aren't covered.
- **Long round trips:** Native connections keep quic-go's 6 MiB stream window, about 0.63 Gbit/s at 80 ms (**derived**).
- **A miss:** each slice has its own gate and the target is their sum, so a certification below a floor files a diagnosis issue and reverts nothing.
- No figure here is a compatibility promise.

## Per-platform targets

Each floor below is a target until its platform's certification records a measured figure against it. A certification updates only its platform's Status line and its row in the [certification status](#certification-status) table. A floor that misses keeps its target wording, and its row states the pooled figure, "missed" and the diagnosis issue's link.

### macOS

`tb`: two Apple-silicon Macs over a Thunderbolt Bridge at MTU 1500, macOS 27 arm64 both ends ([Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797), section 2).

| Floor (one native Wire, `tb`, idle consumer) | Packets/s | Gbit/s |
| --- | ---: | ---: |
| Datagrams at the pin | ≥ 420k | ≥ 4.7 at 1,397-byte Datagrams |
| Stream | ≥ 440k | ≥ 4.8 |

Status: certified on 2026-10-25; both floors met: Datagrams at the pin 583,489/s (6.521 Gbit/s) and stream 584,483 packets/s (6.520 Gbit/s), **measured**, wiremux `0c4d112c251e942ea3152e9fb9ace85bff6b1af3`, fork `v0.62.1-fast.9`; [record](research/native-gap-certification-macos.md).

- **Basis:** all adopted macOS levers (connected socket, the bundle's queues, ack every 16 and batch cap 32, batched sends and receives) measured 471k Datagrams/s (4.5 Gbit/s at 1,191 bytes) and 493k stream packets/s (5.4 Gbit/s) pooled, and 437k and 460k in the slower campaign ([How much would a fork send batch cap above 8 add once the macOS receiver is faster?](https://github.com/GridSwarm/wiremux/issues/1862#issuecomment-6236968867), **measured**, probe stand-ins). That is about 3.5× today's 126k packets/s (1.2 / 1.4 Gbit/s).
- **Payload:** Datagrams are certified at the payload in force, 1,397 bytes once the ceiling slice from [How should the native Datagram ceiling follow path MTU discovery?](https://github.com/GridSwarm/wiremux/issues/1819#issuecomment-6064664332) lands. Packets per second are the macOS invariant.
  - The native ceiling in v0.2.7 is 1,191 bytes (`MaxNativeDatagramPayload`). After v0.2.7, [Slice 1.2: Native Datagram ceiling follows path MTU discovery](https://github.com/GridSwarm/wiremux/issues/1917) makes each Wire's ceiling follow path MTU discovery, fixed at promotion from the limit the connection reports then: 1,191 bytes before discovery's first acknowledged probe and 1,397 bytes once it reaches 1,438-byte packets at MTU 1500. `MaxNativeDatagramPayload` becomes 1,411, the largest ceiling any native Wire can publish ([COMPATIBILITY.md, native promotion](COMPATIBILITY.md#native-promotion-introduced-in-v027)).
- **Launch context:** the target is certified with the sender launched over ssh or as a daemon, and a Terminal-launched default-class row is reported beside it ([macOS launch context](#macos-launch-context)).

### Linux

`netns`: two Linux network namespaces joined by a veth pair on one host, MTU 1500, sender and receiver on different CCDs, no NIC offload ([Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797), section 3).

| Floor (one native Wire, `netns` shape cell, idle consumer) | Gbit/s |
| --- | ---: |
| Datagrams at the pin | ≥ 10.0 at 1,397-byte Datagrams (about 895k Datagrams/s) |
| Stream | ≥ 10.5 |

Status: certified on 2026-10-25; both floors met: Datagrams at the pin 15.517 Gbit/s and stream 11.848 Gbit/s (**measured**, wiremux `68da9417d02208906034cfa4f2f231b131b309ef`, fork `v0.62.1-fast.8`; [record](research/native-gap-certification-linux.md)).

- **These are estimates:** a shape cell with no NIC ([Get representative Linux hardware for multi-Gbit/s measurement](https://github.com/GridSwarm/wiremux/issues/1799#issuecomment-6063540031)). minimax's 10 GbE card has no hardware UDP segmentation, so the real-NIC effect is unmeasured.
- **The Linux Datagram floor from [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) stands:** ≥ 10.0 Gbit/s at 1,397-byte Datagrams (about 895k Datagrams/s) in the `netns` cell ([Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084)).
- Packets per second are reported beside the stream's Gbit/s at certification.

### Windows

A Linux host sending to a Windows Server 2025 VM on it, one virtual e1000e NIC with software URO ([Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572), section 7; [research note](research/issue-1869-windows-receive-coalescing.md)).

| Floor (one native Wire, every adopted lever) | Faster queue | Slower queue |
| --- | --- | --- |
| Datagrams at the pin, 1,024 queue | ≥ 300k/s | ≥ 225k/s |
| Stream at the pin | ≥ 350k packets/s (≥ 3.8 Gbit/s) | ≥ 260k packets/s (≥ 2.85 Gbit/s) |

Status: certified measurements on 2026-10-27; 3 of four floors missed: Datagrams faster/q0 30,352.282 Datagrams/s (0.339 Gbit/s; floor 300,000/s, missed); Datagrams slower/q1 305,637.830 Datagrams/s (3.416 Gbit/s; floor 225,000/s, met); stream slower/q0 90,983.472 packets/s (1.016 Gbit/s; floor 260,000 packets/s, missed); stream faster/q1 304,581.177 packets/s (3.398 Gbit/s; floor 350,000 packets/s, missed), **measured** from the ten-run pool, wiremux `ff86096fa354eef4a1b3533696bc89e892deee9c`, fork `v0.62.1-fast.9`; [record](research/native-gap-certification-windows.md); [diagnosis #2045](https://github.com/GridSwarm/wiremux/issues/2045). Earlier measurements below describe older builds; noisy UDP and reverse binding controls do not establish a stable cell-wide baseline.

- The guest hashes flows onto two receive queues that run 25–33% apart, so a real flow lands on either.
- **Datagram size:** certified at the Datagram ceiling that ships by then (1,397 bytes after the ceiling change, so about 3.35 and 2.5 Gbit/s), plus one 1,191-byte row for continuity. The packet rate at 1,397 bytes is unmeasured.
- **Reported, never floors:**
  - the default-GC Datagram row (177k/s with URO and copy-at-read; GC-bound at Go's heap floor);
  - a Windows sender (12k → 41k Datagrams/s with gluing, 44k stream packets/s);
  - the Arm cell.
- **Limit:** all evidence is one virtual NIC without hardware URO. The size of the gain on a physical Windows machine is unknown.

### Certification status

| Platform | Status | Certified figures | Reported only | Date | wiremux commit | Fork release | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| macOS | Certified; both floors met | Datagrams at the pin 583,489/s (6.521 Gbit/s); stream 584,483 packets/s (6.520 Gbit/s), **measured** | Default-GC Datagrams 500,711/s (5.596 Gbit/s); Terminal: default-GC Datagrams 484,888/s (5.419 Gbit/s), pinned Datagrams 513,791/s (5.742 Gbit/s), stream 547,943 packets/s (6.112 Gbit/s), **measured** | 2026-10-25 | `0c4d112c251e942ea3152e9fb9ace85bff6b1af3` | `v0.62.1-fast.9` | [Record](research/native-gap-certification-macos.md) |
| Linux | Certified; both floors met | Datagrams at the pin 15.517 Gbit/s (1,388,392/s); stream 11.848 Gbit/s (1,062,150 packets/s), **measured** | Default-GC Datagrams 9.926 Gbit/s (888,174/s), **measured** | 2026-10-25 | `68da9417d02208906034cfa4f2f231b131b309ef` | `v0.62.1-fast.8` | [Record](research/native-gap-certification-linux.md) |
| Windows | 3 of four floors missed; [diagnosis #2045](https://github.com/GridSwarm/wiremux/issues/2045) | Datagrams faster/q0 30,352.282 Datagrams/s (0.339 Gbit/s; floor 300,000/s, missed); Datagrams slower/q1 305,637.830 Datagrams/s (3.416 Gbit/s; floor 225,000/s, met); stream slower/q0 90,983.472 packets/s (1.016 Gbit/s; floor 260,000 packets/s, missed); stream faster/q1 304,581.177 packets/s (3.398 Gbit/s; floor 350,000 packets/s, missed); **measured**, pooled | Default-GC q0 170,907/s (1.910 Gbit/s); default-GC q1 294,685/s (3.293 Gbit/s); 1191-byte continuity q0 30,390/s (0.290 Gbit/s); continuity q1 313,493/s (2.987 Gbit/s); Windows sender pinned Datagrams 48,046/s (0.537 Gbit/s); Windows sender pinned stream 49,011/s (0.546 Gbit/s); Arm pending | 2026-10-27 | `ff86096fa354eef4a1b3533696bc89e892deee9c` | `v0.62.1-fast.9` | [Record](research/native-gap-certification-windows.md) |

## Processor headroom

Every target above assumes processor headroom ([Should native throughput targets require consumer headroom, or should wiremux pursue a scheduler fix?](https://github.com/GridSwarm/wiremux/issues/1867#issuecomment-6245076072), decisions 2 and 3; the terms are defined in [CONTEXT.md](../CONTEXT.md)).

In each peer's process, goroutines that never wait on a channel, lock, timer, system call or network I/O stay below `GOMAXPROCS`. For example, a CPU-bound worker pool is sized at `runtime.GOMAXPROCS(0) - 1` or fewer. Stated against `GOMAXPROCS`, the rule follows a Linux container's CPU limit or a pinned process automatically, since Go lowers `GOMAXPROCS` to match.

The per-platform targets are stated as measured with an otherwise idle consumer and are published with the busy-consumer table below, its default-GC row included.

Decision 3 scopes the rule:

> **Scope: measured for native Wires, with a note for the others.** The rule is stated for native Wires, where it was measured. One sentence beside it says the cause is Go's scheduler, so other QUIC-carried Wires (the upgraded direct `transport/quic` path, QUIC over TURN) very likely stall the same way: they run the same quic-go read loop, parked on Go's network poller (**source**, unmeasured). Nothing is measured for them on this map. The reliable relay fallback rides kernel TCP, which acknowledges without the application, and no claim is made for it.

wiremux never sets `GOMAXPROCS`: "The library setting `GOMAXPROCS` is rejected: it is process-wide and the cliff moves with it." ([the headroom ticket](https://github.com/GridSwarm/wiremux/issues/1867)).

**Why a busy process stalls its Wire** (**source**, Go 1.27.2 `runtime/proc.go`; [How many busy goroutines can a consumer run before its native Wire stalls, and what restores it?](https://github.com/GridSwarm/wiremux/issues/1865#issuecomment-6244783748)): a Go processor polls the network only when its run queues are empty. With a busy goroutine always queued that never happens, so the fork's read loop waits for the runtime's 10 ms background poll, and preempted goroutines and network wakeups share one global queue.

**Limits:**

- `GOMAXPROCS` raised above the core count with never-blocking goroutines one below it (say 23 at `GOMAXPROCS` 24 on 16 cores) satisfies the rule but wasn't measured.
- Load in the receiving peer's process wasn't measured. The rule covers it by **source**, because its read loop parks on the same poller.

## Busy consumers

These rows are taken from the existing measurements, each labelled with the shape it was measured on. They are not targets. They are not re-measured on the final stack: "Re-measuring those rows on the final stack would cost more than certifying the floors and wouldn't change what a consumer is told." ([Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797), section 4).

### Busy goroutines in the sender's process

(**measured** in [How many busy goroutines can a consumer run before its native Wire stalls, and what restores it?](https://github.com/GridSwarm/wiremux/issues/1865#issuecomment-6244783748); `tb` at `GOMAXPROCS` 16 unless noted, medians of three; the consumer's work is relative to the collapsed 16-goroutine run). Run conditions: `tb`, macOS 27, default class, in-process load only; every sender in its own ssh session, daemon context; medians of three 10 s runs; percentages **derived** ([research note](research/issue-1865-goroutine-headroom.md)).

| Load in the sender's process | Native Wire's rate kept | Consumer's work kept |
| --- | --- | --- |
| 16 never-blocking goroutines (none free) | about 0.2% (4–7 Mbit/s) | – |
| 15 never-blocking | 35–64% | 82–86% |
| 12 never-blocking | 63–80% | 74–76% |
| 12–15 never-blocking at Go's default GC (Datagrams) | 23–49% | – |
| 16 goroutines busy half of each millisecond | no loss | – |
| 16 goroutines busy 80% / 95% of each millisecond | 65–73% / 52–57% | – |
| `GOMAXPROCS` 24–32 with 16 never-blocking | 44–58% | 78–82% |
| Linux `netns`, `GOMAXPROCS` 4: 3 never-blocking / 4 | 55–58% / collapsed | – |

**Limit:** Every number is #1865's: integer-loop and timer-sleep load on one sending Mac and one Linux shape cell. A real pipeline blocks on channels and I/O, and allocates.

### Other programs on the sending Mac

`tb`, macOS 27, connected shape unless stated; every sender in its own ssh session, daemon context; medians of three 10 s runs; percentages **derived** ([Which realistic loads push the default-class native sender onto macOS efficiency cores?](https://github.com/GridSwarm/wiremux/issues/1857#issuecomment-6238637284); [research note](research/issue-1857-realistic-load-placement.md)).

| Load on the sending Mac | Shape | Effect on the native Wire's rate | Source |
| --- | --- | --- | --- |
| 12–24 spinners in another coalition, default-class sender | connected | costs "11–22% (Datagrams at the pin) and 35–38% (stream)" | [1857](https://github.com/GridSwarm/wiremux/issues/1857#issuecomment-6238637284) |
| 12–24 spinners in another coalition, default-class sender | batched-send and batched-receive | costs "15–34%" | [1801 input](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6238631145) |
| 12–24 spinners in another coalition, user-initiated send thread | connected, batched-send and batched-receive | "busy and idle rates agree within −5% to +25%" | [1801 input](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6238631145) |

**Limits:** The loads are pure integer loops; a real pipeline blocks and allocates. Only the sender's Mac was loaded.

### A busy receiving Mac

`tb`, macOS 27; m4mini receiving, loaded with 0, 8 and 18 one-thread spinners in a separate ssh session's coalition; the sender idle with its send thread raised as adopted; every receiver in its own ssh session, daemon context; medians of three 10 s runs; percentages **derived** ([Does load on the receiving Mac cost the native pair, and do its receive goroutine and run loop need a raised class?](https://github.com/GridSwarm/wiremux/issues/1866#issuecomment-6247562292); [research note](research/issue-1866-receiving-mac-load.md)).

Mbit/s at 0 → 8 → 18 spinners:

| Stack | Datagrams at the pin | Stream | Note |
| --- | --- | --- | --- |
| Batched sends (receiver-bound idle) | 3,076 → 3,924 → 3,282 (+28%, +7%) | 3,555 → 4,159 → 3,769 (+17%, +6%) | ran faster under load (unexplained) |
| Batched receives (sender-bound idle) | 4,697 → 4,631 → 3,959 (−1%, −16%) | 5,662 → 5,151 → 4,419 (−9%, −22%) | "the receiver becomes the wall" |

Under that load the 1,024-entry received-Datagram queue discards 0.3–2.4% of Datagrams with the receiver's goroutines at the default class, against ≤ 0.08% idle: the consumer's reader falls behind ([the receiving-Mac input](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6247569062)).

No target is stated for a loaded receiving Mac.

## macOS launch context

On Apple-silicon Macs, every native Wire's send thread tries the user-initiated class ([Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6240861645), sections 1 and 4). The fork owns the raise, its launch-context check and restoration before the thread returns to Go's pool. Other platforms keep their ordinary class.

- **Who gets it:** a launchd daemon or agent, an `ssh` session, or the frontmost app. A command started from Terminal or an IDE, or an off-screen app, cannot raise its class.
- A Terminal- or IDE-started process therefore runs at the default class. A consumer's only remedy is how it launches.
- An operator can disable the raise with the fork's `QUIC_GO_DISABLE_SEND_QOS=true` environment kill switch. Later macOS acknowledgment, batched-send and batched-receive gate campaigns set it on both Thunderbolt peers to preserve their decided floors.
- Intel Macs and Linux get no raise.
- The macOS target is certified with the sender launched over ssh or as a daemon, the raise's context, and a Terminal-launched default-class row is reported beside it.

## Not covered

- Jumbo frames ([Future effort: jumbo frames for native Wires](https://github.com/GridSwarm/wiremux/issues/1872)).
- Several paths per Wire ([Future effort: several paths per native Wire](https://github.com/GridSwarm/wiremux/issues/1873)).
- The macOS sender past the batched-send list path ([Future effort: the macOS native sender past the batched-send list path](https://github.com/GridSwarm/wiremux/issues/1874)).
- Long round trips ([Future effort: native Wires at long round trips](https://github.com/GridSwarm/wiremux/issues/1875)).
- Relay paths.
- A real Linux NIC ([Get representative Linux hardware for multi-Gbit/s measurement](https://github.com/GridSwarm/wiremux/issues/1799)).
- A physical Windows NIC.
- Windows connected sockets and batched calls.
- A loaded consumer or loaded receiving Mac as a target.
- Other QUIC-carried Wires (upgraded `transport/quic`, QUIC over TURN), which are unmeasured.
- Slower links: no 1 GbE row is published.
