# Continuous integration

wiremux uses one draft-gated pull-request workflow with three independent required jobs. The workflow has no `push`, `pull_request_target`, schedule, manual-dispatch, path-filter, matrix, aggregation, or post-merge validation route.

## Required pull-request jobs

The required jobs run only when the pull request is not a draft and its head belongs to `GridSwarm/wiremux`. Opening a draft creates no runner work; marking it ready authorizes all required lanes for that exact head.

| Check | Runner | Taskfile target | Responsibility |
|---|---|---|---|
| `ci-required` | `wiremux-garm-linux-amd64` | `task ci` | Documentation and diff-range secret checks for docs-only changes; the complete non-race merge gate for every other change |
| `ci-race` | `wiremux-garm-linux-amd64-xlarge` | `task ci-race` | Required race tests for non-docs changes; docs-only success without starting the race body |
| `ci-coturn` | `wiremux-garm-linux-arm64-small` | `task ci-coturn` | Independent coturn interoperability for non-docs changes; docs-only success without starting Docker |

Each job checks out full history, sets up the Go version from [`go.mod`](../go.mod), installs Task 3.53.1 to match the pin in [`tools/go.mod`](../tools/go.mod), reports `task --version`, and invokes exactly one Taskfile target. The existing `audit-go` prerequisite reports the installed Go version and environment before Go validation or tool installation. The Taskfile owns all classification and validation logic.

`ci-coturn` depends on the `wiremux-garm-linux-arm64-small` route using the operator-owned `docker-ci` profile. Docker is guest-local inside an ephemeral GARM VM, the runner user can access that daemon, and no host Docker socket or host mount is exposed. The daemon must also be able to create an `--ipv6` user-defined bridge network with an explicit subnet and publish a UDP port on `[::1]`, because the IPv6 leg of the coturn lane creates a fixture-owned dual-stack network; a daemon that cannot do so fails the lane rather than skipping the leg. The route must be provisioned and proven before this pull request is marked ready.

## Change classification

[`scripts/ci-classify.sh`](../scripts/ci-classify.sh) compares the pull request base and head using the event SHAs when available and otherwise a trusted local base. Unknown, empty, or indeterminate pull-request diffs fail closed as non-documentation changes.

`CI_DOCS_GLOBS` in [`Taskfile.yml`](../Taskfile.yml) is the explicit documentation-only allowlist. It includes `memory/*`, preserving the repository's memory classification, and intentionally excludes release evidence under `docs/release/*`.

`task ci` routes documentation-only changes to `task docs-check` and every other change to `task check` followed by `task vuln`. `task ci-race` and `task ci-coturn` return success immediately for documentation-only changes and otherwise run only their focused bodies.

## Validation targets

[`Taskfile.yml`](../Taskfile.yml) owns the repository validation graph:

- `task docs-check` installs or reuses the pinned TruffleHog binary, scans the exact diff range for secrets, and validates whitespace, Markdown links, and memory frontmatter.

- `task check` runs `docs-check`, the ordinary Go gate, and change-routed CI contracts, cross-platform checks, and production-budget checks. Vulnerability analysis remains outside this local merge gate so `task check` works without network after its tools have been downloaded; non-documentation `task ci` adds the required `task vuln` step.

- `task ordinary-check` runs the Go toolchain audit, formatting, module verification, ordinary tests, and lint. Lint is part of `task check`; it does not consume the xlarge runner.

- `task ci-race` owns the required race body on the xlarge runner. Only the race tests justify that runner size.

- `task ci-coturn` owns the focused independent coturn integration on the arm64-small Docker route.

- `task verify` remains the complete developer gate by combining CI fixtures, documentation and diff-secret checks, ordinary checks, race checks, and vulnerability analysis.

- `task release-gate` is the non-publishing release gate. It preserves the previous release validation body: `task verify`, `task cross-check`, and `task test-production-budget`.

The CI and release-contract classifiers fail closed. A change that is not provably outside a conditional class runs that class's validation.

## Secret scanning

Diff-range TruffleHog scanning is merge-blocking for every pull request. Both `task docs-check` and therefore `task check` scan the range, so Markdown and memory changes receive the same secret protection as source changes.

[`tools/trufflehog.env`](../tools/trufflehog.env) is the single edit point for the pinned TruffleHog version and the SHA-256 checksums of the supported release archives. [`scripts/install-trufflehog.sh`](../scripts/install-trufflehog.sh) reuses a matching cached binary first. Managed Linux selects the exact image-installed version through `infra-ensure-tool` and fails if unavailable; the image build verifies the vendor checksum. Local and hosted bootstrap retain archive checksum verification before installing into `.cache/tools/bin`.

[Scheduled Security Monitor](../.github/workflows/gosec.yml) retains the weekly and manual full-history scan as a non-required backstop. It invokes `task secrets-full-history`, so required diff scanning and scheduled full-history scanning share the same pin and installer.

## Coturn integration boundary

`task coturn-integration` runs the opt-in Linux-container interoperability lane against `coturn/coturn:4.16.0-r0@sha256:01fc8655e7c262fa4ccfb8dca74ff80fb372b0ee021e80370a4d3e3dd01a951e`. The task proves the public root client carries authenticated `wiremux-quic/3` reliable bytes plus the Datagram contract in both directions, retains reliable fallback for bad credentials, forbidden peer permission, and an unavailable server, forces cleanup, and rejects label-scoped container and network residue. An IPv6 leg runs the same authenticated stream and Datagram certification over `udp6` against a `[::1]`-published listener and asserts that both relayed addresses are non-loopback IPv6: the fixture attaches coturn to a fixture-owned dual-stack Docker network on a global-scope subnet from the `2001:db8::/32` documentation prefix because coturn 4.16 refuses loopback, link-local, and unique-local relay peers, and only the client leg crosses the host boundary.

The required runner proof is broader than the test itself: the Actions runner user must successfully run `docker version`, the exact draft head must pass `task coturn-integration`, and post-job inspection must show no runner VM, provider instance, GitHub registration, host-admission lease, autoscaler reservation, or matching container residue. Only the stopped reusable source image may remain.

## Ruleset migration and bootstrap

The target default-branch control is one active squash-only ruleset for `main` with no bypass actors. It requires pull requests, one approval, dismissal of stale approvals, conversation resolution, strict up-to-date branches, linear history, and the three exact required contexts `ci-required`, `ci-race`, and `ci-coturn`.

The migration pull request starts under legacy branch protection, which still requires `Verify`. Because this branch deletes that context, an administrator must swap the legacy-required `Verify` check for the new `ci-*` contexts before the migration pull request can merge. Apply the controls in this order after the runner-route proof succeeds: create and read back the new ruleset, remove and read back legacy branch protection, then obtain explicit authorization to mark the pull request ready.

Creating the ruleset, removing legacy branch protection, and marking the pull request ready are separate external mutations. Each requires its own explicit approval immediately before execution.

Strict up-to-date required checks make a default-branch `push` rerun redundant: the squash of an up-to-date pull-request branch produces the tree that the required jobs tested. The required workflow therefore has no post-merge `main` validation job or push trigger.

## Review and exact-head merge

Follow [the review-loop policy](REVIEW-LOOP.md) while the pull request remains a draft. Before asking to make it ready, confirm the live pull request head and base, confirm the base equals the current `main` tip, and confirm the runner-route proof is complete.

After the user authorizes Ready, inspect all three required jobs for the exact head. Record the live runner and ruleset observations in the migration record, then squash-merge only that exact green head. Any new commit invalidates the observation set and requires a fresh ready-gated run.

## Other workflows

[Native Platform Coverage](../.github/workflows/cross-platform.yml) runs on a weekly schedule and manual dispatch. Its macOS, Windows, Linux ARM64 container, and Linux ARM64 VM coverage remains non-required and must not gain a pull-request trigger. The macOS lane also runs the focused batched-binding send and receive tests without the fork. The Windows lane also runs the focused selected-routing tests so native interface binding, metadata admission, and end-to-end loopback QUIC remain exercised on the platform that owns those APIs.

[Weekly Kernel NAT Smoke](../.github/workflows/nat-smoke.yml) runs the exact `nat-smoke-linux` and dry-run `nat-evidence` targets on a weekly schedule and manual dispatch, then retains the combined eleven-observation artifact.

[Release wiremux](../.github/workflows/release.yml) is the only release workflow. Manual dispatch from protected `main` runs `task release-gate`, builds and inspects the two static Linux binaries, generates compatibility manifests, executes native packaged-binary smoke and the NAT evidence gate, assembles the fixed release bundle, and permits only the publication job to mutate tags and Releases.

## GitHub settings boundary

Repository files do not create rulesets, remove branch protection, change required checks, mark pull requests ready, alter runner infrastructure, or change security-product licensing. Those live controls require separate administrator application and API read-back.

The paid GitHub Code Security and Secret Protection capabilities remain disabled. Required diff-range TruffleHog, required gosec linting, and scheduled gosec, `govulncheck`, and full-history TruffleHog are compensating controls, not equivalents to GitHub-managed code scanning, native secret alerts, validity metadata, or pre-receive push blocking.

Required core and race CI run in native amd64 Podman containers on minimax.
Core CI has 4 CPU/16 GiB; race CI has 12 CPU/48 GiB. Both use the
repository-isolated Go cache. Cross-platform native ARM64 coverage retains the
mbp128 warm-container route; coturn retains its Docker-capable ARM64 VM.
