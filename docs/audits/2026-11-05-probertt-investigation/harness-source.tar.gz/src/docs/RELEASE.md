# Release-facing status

## v0.3.1 preparation

Supported BBRv3 selection and conservative ACK policy are being prepared under [release gate #2057](https://github.com/GridSwarm/wiremux/issues/2057), the [bounded plan](release/v0.3.1/plan.md) and [notes](release/v0.3.1/notes.md). [Adoption instructions](QUIC-CONTROLLERS.md) cover native and upgraded paths. v0.3.0 remains the latest verified final until the existing publisher completes candidate/promotion and independent final verification; preparation is not publication.

## v0.3.0 release record

The private, immutable [v0.3.0 release](https://github.com/GridSwarm/wiremux/releases/tag/v0.3.0) was published at `2026-10-28T02:03:19Z` (2026-10-27 in America/New_York) and independently verified. Its [notes](release/v0.3.0/notes.md) record native packet-I/O/admission improvements, path-MTU-derived native Datagram ceilings, native receive-drop snapshots, relay admission/lease migration and application-owned optional fast.9 selection. The [release contract](release/v0.3.0/plan.md) retains accepted scope and finite evidence requirements; the [compatibility contract](COMPATIBILITY.md) records the new v0.3.x line and its source/behavioral changes. Upstream quic-go v0.62.0 remains the root default without a replacement, and native endpoints remain explicitly unsupported there.

By explicit maintainer instruction, [release run 40617060793](https://github.com/GridSwarm/wiremux/actions/runs/40617060793) published directly with `skip_candidate=true`, no RC and no source candidate from frozen protected-main source `ad0eb746e5673b4d224702fe244e2d9dbcbbbe6d`; all seven jobs passed. Unsigned annotated tag object `9b9f1f6b751a6b1872e115cf934c59085b46020c` peels to that source. [Preparation PR #2053](https://github.com/GridSwarm/wiremux/pull/2053) and [journal #2054](https://github.com/GridSwarm/wiremux/pull/2054) merged before the source freeze. The [preparation receipt](https://github.com/GridSwarm/wiremux/pull/2053#issuecomment-6458334572) records full local release validation, capability-required fast.9 race tests and independent dispositions of two corrected RAS documentation findings; [post-ready preparation CI](https://github.com/GridSwarm/wiremux/actions/runs/40616230203) and [journal CI](https://github.com/GridSwarm/wiremux/actions/runs/40616851413) passed on their exact respective heads.

Independent verification matched every downloaded asset's size and SHA-256 digest to GitHub metadata, verified all seven checksum entries, matched the release body to tracked notes and resolved its GitHub authority links. Both Linux binaries report Go 1.27.3, v0.3.0 and the frozen revision with `vcs.modified=false` and CGO disabled. The smoke record contains four native amd64/arm64 × glibc/musl cells, every outcome true and artifact digests matching the binaries. NAT evidence contains eleven successful bidirectional observations tied to the same source and workflow. Both records passed the published source's JSON schema and semantic validators.

| Published asset | SHA-256 |
| --- | --- |
| `api-manifest.txt` | `b9ca8a6e231f8ae796b8db96e256aae0edc30940a6ea80d87a32feb96e60004a` |
| `checksums.txt` | `6b7a9dbfb81c1691327ce24c862ff49f8b9f72438353008b16abac831cc3495c` |
| `cli-manifest.txt` | `59708184acf7fe4318126f0c8d99f23055f62234d736e4b6b6e66e1f03259547` |
| `nat-evidence.json` | `765a972b6958cbca294cf7c358f5970e0914925fc23e2bf52a17b25d3eb46b0a` |
| `smoke-record.json` | `f166e7ef9f7d839a187ca1551c1e0783d345726b6de1389e8a784f3ca1ac1a6d` |
| `wire-vectors-manifest.txt` | `f88f445577c0c72a478cd4d94715a99392aa9f76f3991196290afa69147d2437` |
| `wiremux-server_linux_amd64` | `1417a42d5ddf3077e867ddbc6a188f364a1d8e64d0477709db872a410d8cb44f` |
| `wiremux-server_linux_arm64` | `8e41dbb382fe8e033b02a3d5f75b5f058656f1e59f1acbb86a895e689d3b1f2a` |

The independently downloaded source archive has SHA-256 `9064e01625f5eacbd145316a8f579182f4fcf346a12b5bcd4af9b8f0078b2215`. Regenerated manifests match the published assets and committed baselines. Against immutable v0.2.7 assets, the API inventory adds 35 lines and replaces the native maximum value (36 additions, one removal); CLI and wire inventories are byte-identical. Fresh-cache private Go module resolution identifies v0.3.0 at the frozen source and `refs/tags/v0.3.0`, module sum `h1:jscaPCploLgYDrUANnTnQMHvNrvA8W8RVFRK8CuzPB0=` and go.mod sum `h1:NeO8Bn6Cp6/q4pEc53yzEqzWReUoavKDPgo18mxCieg=`; module go.mod matches the archive.

After the installed Go 1.27.3 audit, the archive passed the retained paired-relay/setup-record/native/binding/discovery, ordered-selection/HKDF and ordinary managed/QUIC regressions, the example compile check, required native/managed capability tests with optional fast.9 and explicit upstream rollback with no replacement. The explicit `TestNewNativeEndpointUnsupportedBeforeSockets` assertion ran and passed in the ordinary upstream and rollback sequences; native-capability tests may skip there, but were required with fast.9. The [independent verification receipt](https://github.com/GridSwarm/wiremux/issues/2052#issuecomment-6458719355) retains identities and checksums, with the [exact operator script](https://github.com/GridSwarm/wiremux/issues/2052#issuecomment-6458734878) and [complete transcript](https://github.com/GridSwarm/wiremux/issues/2052#issuecomment-6458735149); raw downloaded evidence and selected-module JSON remain in the referenced owned worktree.

The independent archive venue was macOS arm64. It is functional archive validation, not new Linux/Windows execution or a throughput campaign. The [fast.9 maintenance record](research/quic-go-fast-v0.62.1-fast.9-native-adoption.md) owns exact fork identity; the [fast.8 record](research/quic-go-fast-v0.62.1-fast.8-native-adoption.md) retains bundle and packet-I/O reconciliation. [Native throughput](NATIVE-THROUGHPUT.md) preserves Linux fast.8 shape-cell and macOS fast.9 passes, Windows fast.9 three floor misses, Arm pending, processor-headroom requirements and accepted costs. Publication reopens none of those measurements or separately owned investigations. Consumers explicitly select and qualify fast.9 in their own modules; downstream stable-version adoption remains separately owned.

## v0.2.7 release record

The private, immutable [v0.2.7 release](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.7) was published at `2026-10-05T15:38:08Z` and independently verified. Its [notes](release/v0.2.7/notes.md) record the additive `binding` and `discovery` packages, paired relays held before authentication with the setup-record codec, and native QUIC candidates with authentication and promotion. The [release contract](release/v0.2.7/plan.md) retains scope and bounded evidence requirements, and [`CHANGELOG.md`](../CHANGELOG.md) indexes each release's notes. Upstream quic-go v0.62.0 remains the default and the Go floor is unchanged; the only dependency change is pion/transport v4.1.1. Native endpoints report unsupported under upstream quic-go and the advertised optional fast.6, and no fork release is qualified for native use.

By explicit maintainer instruction, [release run 37332009763](https://github.com/GridSwarm/wiremux/actions/runs/37332009763) published directly with `skip_candidate=true` and no RC from frozen protected-main source `98ad3567de17e6d2d2b64619fd34e322cd0db350`, which differs from the initially reviewed main `61b57e3b779629914ec9ca65d54b559c8ad64b66` only by the preparation documents; all seven jobs passed. Unsigned annotated tag object `67ac405011a1c4bf8c2321326d7cccd032c8563e` peels to that source. [Preparation PR #1780](https://github.com/GridSwarm/wiremux/pull/1780) retains the local release-gate, review and exact-head hosted CI receipts; its preparation review (RAS run `20261005T145634-3a37b2e754e9c58532c5067f`) reported no `Fix First` cluster, and its two low-severity observations were independently rejected.

Independent verification downloaded all eight assets and matched every SHA-256 value and size to GitHub metadata, verified all seven entries in `checksums.txt`, matched the release body to tracked notes and resolved all 22 of its links. Both Linux binaries report Go 1.27.1, v0.2.7 and the frozen revision with `vcs.modified=false`. The smoke record contains four native architecture/environment cells (amd64 and arm64, glibc and musl), all outcomes true with matching binary hashes. NAT evidence contains eleven successful bidirectional observations tied to the same run and source; both records also passed the published source's schema and semantic validators.

| Published asset | SHA-256 |
| --- | --- |
| `api-manifest.txt` | `d7bec448d2bea4e2d93070452fd38bbf8813606c2f55ec393454364a7fc033d7` |
| `checksums.txt` | `5cee2f10daca7c8c5be93bf30ed24ced958572ddfe45064704b1c8cbe1636df5` |
| `cli-manifest.txt` | `59708184acf7fe4318126f0c8d99f23055f62234d736e4b6b6e66e1f03259547` |
| `nat-evidence.json` | `cdbfb7f21ef4f03b97ff1922cdce0591459c4d14617a9e33e523de3e1822fa3b` |
| `smoke-record.json` | `faaa3c82ac74da93c427c1b2c56e9cbe34dbef52235f7e7e1dd4e5bef4156a56` |
| `wire-vectors-manifest.txt` | `f88f445577c0c72a478cd4d94715a99392aa9f76f3991196290afa69147d2437` |
| `wiremux-server_linux_amd64` | `00bc4fbed9c4163809d7f3e020e38498ef4e8aec310fbefc58eef935453cf825` |
| `wiremux-server_linux_arm64` | `3ad429134a2b32e37df1206f5492f98e3648627a39e2aba00bffa9e524f82d5e` |

The independently downloaded source archive has SHA-256 `9ebcc38bd4c2b30d1f61a0f5e6f7b55f3722a18298eb1eeeb399b90d4011337d`. Regenerated manifests match the published assets and committed baselines. Compared with immutable v0.2.6 assets, the API inventory has exactly 170 additions and no removals; CLI and wire inventories are byte-identical. Fresh-cache Go module resolution selected v0.2.7 at the frozen source and `refs/tags/v0.2.7`, with module sum `h1:U3+kPajnbeQ6UW6O1IS7m1PIFuAuMj62c2Jw7MOjIS8=` and go.mod sum `h1:nw+tj/PyDO5Vlgrt/okemu1cx0B3YsaNShHc0bWo7/4=`.

After auditing installed Go 1.27.1, the published archive passed the paired-relay, setup-record, native and binding/discovery regressions, the retained ordered-selection, present-interface and HKDF regressions, ordinary upstream compatibility checks, the managed-endpoint example compile check, required-capability tests with optional quic-go-fast v0.62.1-fast.6 and explicit rollback to upstream v0.62.0 without a replacement. The exact archive commands are below; the [archive receipt](https://github.com/GridSwarm/wiremux/pull/1782#issuecomment-5998042819) retains the script, full transcript and the selected upstream, fork and rollback module JSON. The independent archive venue was macOS arm64; under upstream quic-go the native tests that need a capable fork skip, so native fixture coverage and Linux-only tests are not claimed by that run. Hosted Linux validation and the merged feature PRs retain their separate evidence. No new performance claim, fork qualification, downstream repository update or validation waiver is implied.

## v0.2.6 release record

The private, immutable [v0.2.6 release](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.6) was published at `2026-09-25T03:57:21Z` and independently verified. Its [notes](release/v0.2.6/notes.md) record ordered selected-interface establishment, present-interface resolution, HKDF exporter diagnostic protection, joined relay completion and internal ownership/validation refactors. The [release contract](release/v0.2.6/plan.md) retains scope and bounded evidence requirements. Upstream quic-go v0.62.0 remains the default; dependencies, Go floor, CLI and wire profiles are unchanged.

By explicit maintainer instruction, [release run 36091600991](https://github.com/GridSwarm/wiremux/actions/runs/36091600991) published directly with `skip_candidate=true` and no RC from frozen protected-main source `15050b4a2b775004220a7d6ee67c96084f75d2a1`; all seven jobs passed. Unsigned annotated tag object `aae734c432882f261b427f6dca16875c801ccdaa` peels to that source. The earlier [RC run 36090556697](https://github.com/GridSwarm/wiremux/actions/runs/36090556697) was canceled before publication; no RC tag or Release was created. [Preparation PR #1729](https://github.com/GridSwarm/wiremux/pull/1729) and [direct-final correction #1731](https://github.com/GridSwarm/wiremux/pull/1731) retain the local release-gate, review and exact-head hosted CI receipts. The preparation review completed five reviewers and five adjudicators, with three documentation correction groups independently resolved; RAS synthesis failed on structured-delivery plan drift, so no synthesized verdict is claimed.

Independent verification downloaded all eight assets and matched every SHA-256 value and size to GitHub metadata, verified all seven entries in `checksums.txt`, matched the release body to tracked notes and resolved its authority links. Both Linux binaries report Go 1.27.1, v0.2.6 and the frozen revision with `vcs.modified=false`. The smoke record contains four native architecture/environment cells (amd64 and arm64, glibc and musl), all outcomes true with matching binary hashes. NAT evidence contains eleven successful bidirectional observations tied to the same run and source; both records also passed the published source's schema and semantic validators.

| Published asset | SHA-256 |
| --- | --- |
| `api-manifest.txt` | `5703ec24e89733b32b365c5e76ecb19a2c29e3de130634c2dc73d04073a4de74` |
| `checksums.txt` | `19c6155f39bf9331fecb219bcb0116c86c95a8384b2ae91fe0ea60db4ed05a23` |
| `cli-manifest.txt` | `59708184acf7fe4318126f0c8d99f23055f62234d736e4b6b6e66e1f03259547` |
| `nat-evidence.json` | `b380c7c96ac919d5d612e992899c03cba224034ebb85345b9b011cb1eeb87e70` |
| `smoke-record.json` | `a0839038ac042a2a062be01e0e7593ae5f159fef6a70a71b064fb98d7bc007d8` |
| `wire-vectors-manifest.txt` | `f88f445577c0c72a478cd4d94715a99392aa9f76f3991196290afa69147d2437` |
| `wiremux-server_linux_amd64` | `3331ab2aeff0fffa07b1ab3ba3c235f180545bfb48324ee1fbfcfba014c7e439` |
| `wiremux-server_linux_arm64` | `fd46235aa62136ce19c83a369453b421a8ea55eb5f25b387536adecd32c5f406` |

The independently downloaded source archive has SHA-256 `4479d6b46f3869e1d4039066ec14841963bfb17106c135000759eeb422e57888`. Regenerated manifests match the published assets and committed baselines. Compared with immutable v0.2.5 assets, the API inventory has exactly 38 additions and no removals; CLI and wire inventories are byte-identical. Fresh-cache Go module resolution selected v0.2.6 at the frozen source and `refs/tags/v0.2.6`, with module sum `h1:KrySaqDfARra3/cmhbAyskTvXXTNZhD3+GUct7h2+MM=` and go.mod sum `h1:ued8HRWQD8WHohGC6T2VnELHzIH2aMtg+eZUqoR+J0g=`.

After auditing installed Go 1.27.1, the published archive passed the ordered-selection, present-interface and HKDF regressions, ordinary upstream compatibility checks, the managed-endpoint example compile check, required-capability tests with optional quic-go-fast v0.62.1-fast.6 and explicit rollback to upstream v0.62.0 without a replacement. The exact archive commands are below. The independent archive venue was macOS arm64; Linux-only ordered tests and opt-in native fixtures are not claimed by that run. Hosted Linux validation and the merged feature PRs retain their separate Linux evidence. No new performance claim, downstream repository update or validation waiver is implied; [Linux venue investigation #1667](https://github.com/GridSwarm/wiremux/issues/1667) remains open.

## v0.2.5 release record

The private, immutable [v0.2.5 release](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.5) was published at `2026-09-24T03:19:21Z`. The [release contract](release/v0.2.5/plan.md) and [notes](release/v0.2.5/notes.md) record TURN v5.3.1, CBOR v2.9.4, tools-only gRPC v1.84.0 and TruffleHog v3.97.8, plus the explicitly approved calibration-result custody correction. TURN requires the accompanying STUN v3.1.7 and DTLS v3.1.8 updates. Upstream quic-go v0.62.0 remains the default, the Go floor is unchanged, and no public API, CLI or wire-profile change is introduced.

By explicit maintainer instruction, [release run 35949417379](https://github.com/GridSwarm/wiremux/actions/runs/35949417379) published directly with `skip_candidate=true` and no RC from frozen protected-main source `353bf18edb14cb54f829ae6526b4b591e7d315f6`; all seven jobs passed. Unsigned annotated tag object `65910a66e6fbcaabd56c70568fae76b1f41b600d` peels to that source. The earlier [run 35947374294](https://github.com/GridSwarm/wiremux/actions/runs/35947374294) failed before publication at source `3e76e7a7ffe75c4eeebeae0469bda76d38aa7b59`: calibration consumed a validated terminal result, leaving cancellation cleanup with EOF. [PR #1675](https://github.com/GridSwarm/wiremux/pull/1675) preserves that result for the cleanup drain. The maintainer approved this narrow scope expansion; no gate was waived and the old run was not rerun.

[Dependency PR #1673](https://github.com/GridSwarm/wiremux/pull/1673) passed `task release-gate`, five-reviewer RAS run `20260924T021345-77fc490b708eaa8da833e25c` with zero findings, and [same-head CI 35946894164](https://github.com/GridSwarm/wiremux/actions/runs/35946894164). The calibration correction passed deterministic before/after regressions, focused race checks, twenty repetitions of the existing controller-result fixture, `task release-gate`, five-reviewer RAS run `20260924T024340-a1e39e5a2da72c3253e3ab39` with zero findings, and [same-head CI 35949030635](https://github.com/GridSwarm/wiremux/actions/runs/35949030635). Both PRs were guarded squash merges; the final release workflow validated the resulting frozen source again.

The [independent verification receipt](https://github.com/GridSwarm/wiremux/pull/1676) retains the full commands, output and selected module JSON. Verification downloaded all eight assets and matched their SHA-256 values and sizes to GitHub's metadata, verified all seven entries in `checksums.txt`, and matched the release body to the tracked notes. Both Linux binaries report Go 1.27.1, v0.2.5 and revision `353bf18edb14cb54f829ae6526b4b591e7d315f6`, with `vcs.modified=false`. The smoke record contains four native architecture/environment cells (amd64 and arm64, glibc and musl), with every outcome true and matching binary hashes. NAT evidence contains eleven successful bidirectional observations associated with the same release run and source.

| Published asset | SHA-256 |
| --- | --- |
| `api-manifest.txt` | `959e995b43bcb956dcf3c07945e7d43f63703878e4b0bc8ce54d05aa9f95762c` |
| `checksums.txt` | `2817392c0ee64ae964092268e85dc03520e06c5d0619ee28ca800e6751a8bb91` |
| `cli-manifest.txt` | `59708184acf7fe4318126f0c8d99f23055f62234d736e4b6b6e66e1f03259547` |
| `nat-evidence.json` | `54f756705ac001f31efb4b5ce1823e4740cebfcc49b9ceba209b4dffeff25f29` |
| `smoke-record.json` | `ebb1d8ff4932a4d25e62989b5a77cccf11c318ad85ef0a59808a328176a5103f` |
| `wire-vectors-manifest.txt` | `f88f445577c0c72a478cd4d94715a99392aa9f76f3991196290afa69147d2437` |
| `wiremux-server_linux_amd64` | `5f293265f858ecfb1db64ec17dcaac54f934056cd6fe8eb192f2a4ecf3a11c28` |
| `wiremux-server_linux_arm64` | `4747e713439b229d94ef7d7bf996ea3c12c330557a801142f19eb9ee9c79ebba` |

The independently downloaded source archive has SHA-256 `d846032db92fe3a8a8b79cf98ddc9ce5241fea8a05e0465c81b564a245f81bbe`. Regenerating its API, CLI and wire-vector manifests produced byte-identical files to both the v0.2.5 assets and immutable v0.2.4 assets. Independent Go module resolution selected v0.2.5 at the frozen source and `refs/tags/v0.2.5`, with module sum `h1:+BT6OoQYVPs7hyZM7HQ8MbT+YtaGynsX7Nn+Pnvc3f4=` and go.mod sum `h1:ued8HRWQD8WHohGC6T2VnELHzIH2aMtg+eZUqoR+J0g=`.

From the published archive after the installed-toolchain audit, the measurement regressions and existing controller-result fixture passed. The archive procedure below passed ordinary upstream v0.62.0 checks, the existing managed-endpoint example compile check, required-capability tests with replacement `github.com/the-sarge/quic-go-fast@v0.62.1-fast.6`, and explicit rollback to upstream v0.62.0 with no replacement. This is compatibility evidence, not a new performance claim. Publication and independent verification are complete; v0.2.4 was not changed and no downstream repository update was performed.

Tools-only gRPC v1.84.0 was selected after all four pinned tools built successfully without any additional tools-module version changes. GitHub marked the previous Dependabot alert #16 fixed, then opened [alert #17](https://github.com/GridSwarm/wiremux/security/dependabot/17) for the same [GHSA-2v4p-qf9q-27wj](https://github.com/advisories/GHSA-2v4p-qf9q-27wj): the central range includes v1.84.0, while the [maintainer advisory](https://github.com/grpc/grpc-go/security/advisories/GHSA-2v4p-qf9q-27wj) describes affected versions through v1.83.1 and patches v1.83.2/v1.82.2. The exact [v1.84.0 source](https://github.com/grpc/grpc-go/blob/v1.84.0/internal/transport/http2_server.go#L525-L530), resolved at `e84aa5ab15d1d2b29d54f838312ad490cb7551a8`, contains the early rejection for requests missing both authority and host. Its upstream `Test/HeadersHTTPStatusGRPCStatus/Missing_authority_and_host_header_grpc` regression passed with `-mod=readonly -count=1`. This evidence indicates an advisory-range mismatch; alert #17 remains open and was not dismissed. It does not establish exploitability of the pinned tooling or claim that all advisories are clear.

## v0.2.4 release record

The private, immutable [v0.2.4 release](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.4) was published 2026-09-24. Its [notes](release/v0.2.4/notes.md) record the additive managed migration and selected-interface APIs, lifetime and allocation improvements, and optional quic-go-fast v0.62.1-fast.6 qualification. Upstream quic-go v0.62.0 remains the ordinary module default. The [release contract](release/v0.2.4/plan.md) and [qualification receipt](release/v0.2.4/qualification.md) preserve the bounded compatibility evidence and non-claims.

By explicit maintainer instruction, [release run 35940526072](https://github.com/GridSwarm/wiremux/actions/runs/35940526072) published directly with `skip_candidate=true` and no RC from frozen protected-main source `13f52dbbd0bff4f8b06bac98698e22cef993ad30`; all seven jobs passed. The unsigned annotated tag object `700f649118dea7aeba507ffe8f021a2fd88ecf86` peels to that source. The initial RC run was canceled before publication and no RC tag or Release exists.

The [independent publication receipt](https://github.com/GridSwarm/wiremux/issues/1666#issuecomment-5805709235) verifies immutability, eight downloaded assets and all checksums, matching generated manifests and release notes, both Linux binary identities, four native smoke cells and eleven successful NAT observations. The published source passed upstream v0.62.0, required-capability fast.6 and explicit upstream-rollback tests; independent Go module resolution returned v0.2.4 at the frozen source. CLI and wire inventories remain byte-identical to v0.2.3; the additive API delta is retained with the qualification evidence.

Publication verification is complete. [Gate #1666](https://github.com/GridSwarm/wiremux/issues/1666) covers wiremux qualification and publication only. Downstream updates were not authorized; the mistakenly opened consumer PRs were closed without merging. The existing pre-QUIC Linux venue failure remains [investigation #1667](https://github.com/GridSwarm/wiremux/issues/1667); no required release gate was waived for it. The archive commands below use the current final version and fast.6 selection.

## v0.2.3 managed Datagram release record

The private, immutable [v0.2.3 release](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.3) was published 2026-09-17. The [v0.2.3 notes](release/v0.2.3/notes.md) record the additive `ManagedWire.Datagrams` API over v0.2.2. [M-release #1581](https://github.com/GridSwarm/wiremux/issues/1581) is complete: its [independent publication verification receipt](https://github.com/GridSwarm/wiremux/issues/1581#issuecomment-5719959815) confirms immutable final tag and Release identity, all eight assets and checksums, unchanged CLI/wire inventories, and the API delta containing exactly `ManagedWire.Datagrams` relative to v0.2.2. The published archive passed the five `TestManagedDatagrams` cases, and independent module inspection confirmed the exported method. The publication prerequisite for [GridCast D1](https://github.com/GridCastIO/gridcast/issues/1083) is satisfied; dependency adoption, capability forwarding and consumer validation are separately owned by GridCast D1.

By maintainer instruction, v0.2.3 was published directly from frozen protected-main source `73c0552088b6973ed01b675643f4ce1942114737` through [release run 35262329796](https://github.com/GridSwarm/wiremux/actions/runs/35262329796), with `skip_candidate=true` and no RC. The direct-final procedure remains an explicit opt-in: publish from the frozen protected-main source through `release.yml`, with `skip_candidate=true` and no `source_candidate`. This skips only RC publication; all release validation, packaging, native smoke, NAT, checksums and immutable-publication gates remain required. Ordinary final promotion still requires a matching same-commit RC; `skip_candidate` is rejected for RC versions or together with `source_candidate`. The operator must recheck live tags before dispatch.

For a direct final release, verify immutable final tag and Release identity, all checksums and the expected compatibility-manifest delta. For v0.2.3, independent published-source/module inspection and the five `TestManagedDatagrams` cases after the toolchain audit were also required; the linked receipt discharges those checks. The existing archive checks below remain applicable with the actual candidate/final version. Record publication and verification receipts in the owning release-gate issue; source merge and journal completion do not satisfy that gate.

## Published baseline and earlier release preparation

wiremux's current release is the private, immutable [v0.3.0](https://github.com/GridSwarm/wiremux/releases/tag/v0.3.0), published 2026-10-27 (America/New_York); its [notes](release/v0.3.0/notes.md) record native improvements, explicit compatibility/migration changes, relay hardening and optional fast.9 selection. The v0.2.7 [notes](release/v0.2.7/notes.md) record scoped bindings and discovery, paired relays with setup records, and native candidates with promotion. The [v0.2.6 notes](release/v0.2.6/notes.md) record the preceding ordered selection, HKDF diagnostic protection, joined relay completion and internal refactors. The [v0.2.5 notes](release/v0.2.5/notes.md) record the preceding dependency updates and calibration-result custody correction. The [v0.2.4 notes](release/v0.2.4/notes.md) record the preceding migration, selection and optional-fork delta. The [v0.2.3 notes](release/v0.2.3/notes.md) record the preceding additive managed Datagram capability. The [v0.2.2 notes](release/v0.2.2/notes.md) record its additive managed and packet-I/O APIs, optional fork selection, support boundaries and rollback. The [v0.2.1 narrative](release/v0.2.1/notes.md) records the opt-in loopback pprof endpoint, allocation reductions, architecture and test hardening, the `channel.Receive` payload-lifetime exception, and inherited v0.2.0 non-claims; the [v0.2.0 narrative](release/v0.2.0/notes.md) records the `0x02` assist-withheld pairing reply, the 1232-byte direct packet class, the relay shaping knobs, the ACME directory-URL and EAB support, the OOB-capable adapter, and the channel send-failure drain correction; the [v0.1.6 narrative](release/v0.1.6/notes.md) records the relay proxy drain correction, the TURN retry listener fixes, the two-helper API reduction, and the error-prefix folds; the [v0.1.5 narrative](release/v0.1.5/notes.md) records the opt-in client-side TURN/UDP relay fallback, the probe-settlement corrections, the additive compatibility delta, and the narrowed TURN non-claim; the [v0.1.4 narrative](release/v0.1.4/notes.md) records the prior-pass probe-success settlement fix; the [v0.1.3 narrative](release/v0.1.3/notes.md) records the bounded probe-rerace fix; the [v0.1.2 narrative](release/v0.1.2/notes.md) records the direct-wire idle-liveness fix; the [v0.1.1 narrative](release/v0.1.1/notes.md) records that release's one additive change; the [v0.1.0 narrative](release/v0.1.0/notes.md) remains the authoritative statement of supported scope and non-claims, and [`COMPATIBILITY.md`](COMPATIBILITY.md) is the normative compatibility contract for the released v0.1.x, v0.2.x and v0.3.x lines. This file records release status and downstream sequencing without defining a second compatibility boundary.

## v0.2.2 release source and publication gate

The [v0.2.2 notes](release/v0.2.2/notes.md) define that published release's additive compatibility delta, exact optional fork selection, managed endpoint example, retained peer policy and upstream rollback. Ordinary selection remains upstream quic-go v0.62.0; the optional release is [v0.62.1-fast.3](https://github.com/the-sarge/quic-go-fast/releases/tag/v0.62.1-fast.3). Public API baselines already include the new facade; generation must match all three committed baselines before publication. No runtime change or new performance claim is introduced by this release preparation.

L02 preparation and publication are complete: the immutable [v0.2.2 final](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.2) and [v0.2.2-rc.1 candidate](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.2-rc.1) share the frozen release-source commit. The [L02 verification receipt](https://github.com/GridSwarm/wiremux/issues/1533#issuecomment-5706947357) and [program tracker](https://github.com/GridSwarm/wiremux/issues/1540) record verification receipts. The v0.2.2 publication prerequisite for C01-C is satisfied; consumer adoption remains separately owned. The archive-check procedure below is retained for candidate/final verification, using the actual version and its owning release-gate issue. The workflow remains the only publisher; after an ambiguous mutation, inspect tag/Release state before retrying.

For each published candidate and final tag, run the following independent archive check from a scratch directory, after the installed-toolchain audit in [AGENTS.md](../AGENTS.md) confirms Go 1.27.3 or newer. These are operator commands, not steps implemented by `release.yml`. Keep the archive digest, selected module JSON and complete command outputs with the owning publication record (the v0.3.0 record above and its [verification receipt](https://github.com/GridSwarm/wiremux/issues/2052#issuecomment-6458719355); the v0.2.7 record above and its [archive receipt](https://github.com/GridSwarm/wiremux/pull/1782#issuecomment-5998042819); the v0.2.6 record above; [receipt PR #1676](https://github.com/GridSwarm/wiremux/pull/1676) for v0.2.5; #1666 for v0.2.4; #1581 for v0.2.3; #1533/#1540 hold the completed v0.2.2 receipts). Use the exact published tag for `VERSION`; every published tag must peel to the frozen release-source commit. For direct final publication, there is no candidate to check.

```sh
set -eu
VERSION=v0.3.0 # Verified direct final publication; no RC was requested.
FORK_VERSION=v0.62.1-fast.9 # Historical receipts retain their actual fork versions.
ARCHIVE_DIR="$(mktemp -d)"
export GOTOOLCHAIN=local GOWORK=off
gh api "repos/GridSwarm/wiremux/tarball/$VERSION" > "$ARCHIVE_DIR/source.tar.gz"
shasum -a 256 "$ARCHIVE_DIR/source.tar.gz"
mkdir "$ARCHIVE_DIR/source"
tar -xzf "$ARCHIVE_DIR/source.tar.gz" --strip-components=1 -C "$ARCHIVE_DIR/source"
cd "$ARCHIVE_DIR/source"
go list -m -json github.com/quic-go/quic-go > "$ARCHIVE_DIR/upstream.json"
jq -e '.Path == "github.com/quic-go/quic-go" and .Version == "v0.62.0" and .Replace == null' "$ARCHIVE_DIR/upstream.json"
go test -count=1 -run '^(TestPairRelay|TestPairedRelay|TestSetupRecord|TestWriteSetupRecord|TestReadSetupRecord|TestNewNativeEndpointUnsupportedBeforeSockets|TestNative|TestListen)' . ./binding ./discovery
go test -count=1 -run '^(TestDialOrdered|TestNewOrdered|TestResolvePresent|TestHKDFKeyExporter)' . ./relay ./selection ./connect
go test -count=1 -run 'TestNewNativeEndpointUnsupportedBeforeSockets|TestManagedPacketEndpointOrdinaryIOOrExplicitUnsupported|TestQUICProductionWireDatagramContract|TestQUICSessionDialListenDistinctSocketCrossConnect' . ./internal/integration
go test . -run '^ExampleNewManagedPacketEndpoint$'
go mod edit "-replace=github.com/quic-go/quic-go=github.com/the-sarge/quic-go-fast@$FORK_VERSION"
go mod tidy
go list -m -json github.com/quic-go/quic-go > "$ARCHIVE_DIR/fork.json"
jq -e --arg fork "$FORK_VERSION" '.Path == "github.com/quic-go/quic-go" and .Version == "v0.62.0" and .Replace.Path == "github.com/the-sarge/quic-go-fast" and .Replace.Version == $fork' "$ARCHIVE_DIR/fork.json"
WIREMUX_TEST_NATIVE=required WIREMUX_TEST_MANAGED_PACKET_IO=required go test -count=1 -run 'Native|Datagram|MaxDatagramPayload|Managed|Migration|Selected|PacketPermission|TURN|TurnRetry' . ./internal/nativequic ./internal/integration ./transport/internal/adapter ./transport/quic
go mod edit -dropreplace=github.com/quic-go/quic-go
go get github.com/quic-go/quic-go@v0.62.0
go mod tidy
go list -m -json github.com/quic-go/quic-go > "$ARCHIVE_DIR/rollback.json"
jq -e '.Path == "github.com/quic-go/quic-go" and .Version == "v0.62.0" and .Replace == null' "$ARCHIVE_DIR/rollback.json"
go test -count=1 -run 'TestNewNativeEndpointUnsupportedBeforeSockets|TestManagedPacketEndpointOrdinaryIOOrExplicitUnsupported|TestQUICProductionWireDatagramContract|TestQUICSessionDialListenDistinctSocketCrossConnect' . ./internal/integration
```

Every command and graph assertion must succeed. `WIREMUX_TEST_NATIVE=required` and `WIREMUX_TEST_MANAGED_PACKET_IO=required` make missing native/managed capabilities fail instead of allowing the existing optional integration tests to skip. The native selectors include receive-drop lifecycle, path-MTU/Datagram capacity, admission and queue coverage; ordinary upstream and rollback retain unsupported-native behavior. The named existing suites cover ordinary unsupported behavior, full-Wire reuse/failure/fallback/TURN, selected-peer permissions, original lease binding and Datagram delivery; the existing example is compile evidence, not an additional network experiment. Independently verify immutable release state, annotated tag/commit identity, all eight assets and checksums, generated manifest equality, native smoke/NAT workflow success and the rendered release body's authority links. Any failed check holds the owning release gate open and its dependent consumer blocked. Link receipts for every published version before completing that gate; no downstream adoption or performance qualification is implied.

## v0.2.1 release record

| Field | Value |
| --- | --- |
| Release | <https://github.com/GridSwarm/wiremux/releases/tag/v0.2.1> — private, immutable, non-prerelease; repository `latest` at publication, since superseded by v0.2.2 |
| Final tag object | `4cf4d088ed9966a5826b7210d45919a0d6762fe9`, unsigned annotated, peels to the released commit |
| Released commit | `3f5dfcfa0e9edd94be83b318fe58816604c4f39f`, shared by candidate and final |
| Accepted candidate | [`v0.2.1-rc.1`](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.1-rc.1) — private, immutable prerelease; tag object `158e740cd0f9f77d7a969d24bac1805c67e1ca9f` peeling to the same commit, published by [run 33237600355](https://github.com/GridSwarm/wiremux/actions/runs/33237600355) |
| Final publication run | <https://github.com/GridSwarm/wiremux/actions/runs/33238114411> — all seven jobs success |
| Change | Opt-in loopback-only `wiremux-server serve --debug-pprof-listen` ([PR #1402](https://github.com/GridSwarm/wiremux/pull/1402)); zero-allocation steady-state channel framing ([PR #1408](https://github.com/GridSwarm/wiremux/pull/1408)) and allowed source-rate-limit decisions ([PR #1414](https://github.com/GridSwarm/wiremux/pull/1414)); lower-allocation error-tree classification ([PR #1388](https://github.com/GridSwarm/wiremux/pull/1388), [PR #1392](https://github.com/GridSwarm/wiremux/pull/1392), [PR #1394](https://github.com/GridSwarm/wiremux/pull/1394)); repeatable hot-path baselines ([PR #1403](https://github.com/GridSwarm/wiremux/pull/1403)); architecture, resource-ownership, relay-shaping, and test-fixture hardening accumulated since v0.2.0 |
| Compatibility | API and wire-vector manifests byte-identical to v0.2.0; CLI manifest adds exactly `--debug-pprof-listen` and its loopback IP host:port validation rule; module and tool dependency files unchanged. One recorded v0.2.x exception narrows `(*channel.Channel).Receive`: the returned slice is valid only until the next `Receive` or `Close`, so callers retaining it across either call must copy. The exported signature and authenticated wire bytes are unchanged |
| Downstream | Existing v0.2.0 consumers can repin without a coordinated wire migration; consumers that retain a `channel.Receive` payload across the next receive or close must add a copy. Consumer-repository migrations remain owned by codemux, keymux, GridCast, and other downstream repositories |
| Artifact boundary | The Linux amd64 and arm64 server artifacts are tested in the native per-architecture packaged-binary smoke matrix; no other platform artifact is published or claimed; no TURN server is shipped |

The v0.2.1 Release carries eight digest-verified assets:

| Asset | SHA-256 |
| --- | --- |
| `api-manifest.txt` | `ec4c365e3533fd2bf72e040cd2e3a633e9c4f645410b30edd20c21413ad1fb97` |
| `checksums.txt` | `80f0390d92465dd783e6a71ff150847ef01e7f5a35fde5de5821e5dd45d0d11c` |
| `cli-manifest.txt` | `59708184acf7fe4318126f0c8d99f23055f62234d736e4b6b6e66e1f03259547` |
| `nat-evidence.json` | `24fbff62d2ca9e63153081b4a4c90774e8ac1301ec2a9ff09cf3fa619d6489bc` |
| `smoke-record.json` | `990c430a6bad06201b4131fb49c8e3d00a11ecbb74ad9c2feeceaeb1ace6104d` |
| `wire-vectors-manifest.txt` | `f88f445577c0c72a478cd4d94715a99392aa9f76f3991196290afa69147d2437` |
| `wiremux-server_linux_amd64` | `59f9bf94b1be993931e45f2d4cddef8d2e243c1941171a1d088217ac56ad2ffb` |
| `wiremux-server_linux_arm64` | `339cf0ba79a3127d2ee7b099131c9a149f5e2c9b401b304706c60650511a2b88` |

`checksums.txt` verifies the other seven assets; both binaries report stable `v0.2.1`, Go 1.27.0, and exact revision `3f5dfcfa0e9edd94be83b318fe58816604c4f39f`; the same-run smoke record contains four successful natively executed cells; and the same-run NAT record contains eleven successful bidirectional observations. The Release body is byte-identical to the tracked [v0.2.1 notes](release/v0.2.1/notes.md), the API and wire-vector manifests are byte-identical to v0.2.0, the CLI delta is exactly the pprof flag and validation rule, and the final tag and accepted candidate both resolve to the exact frozen commit.

## v0.2.0 release record

| Field | Value |
| --- | --- |
| Release | <https://github.com/GridSwarm/wiremux/releases/tag/v0.2.0> — private, immutable; repository `latest` at publication, since superseded by v0.2.1 |
| Final tag object | `5f460231fdd5fa01a2423d609325fdd44d8bda31`, unsigned annotated, peels to the released commit |
| Released commit | `f835a3f6b31a803bab6f79b6f1b048e51bcfcf5f`, shared by candidate and final |
| Accepted candidate | [`v0.2.0-rc.1`](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.0-rc.1), tag object `966212b8707347d5837d51e66c8a04fed3b33657` peeling to the same commit, published by [run 32889728527](https://github.com/GridSwarm/wiremux/actions/runs/32889728527) |
| Final publication run | <https://github.com/GridSwarm/wiremux/actions/runs/32891722921> — all seven jobs success |
| Change | The [#1290](https://github.com/GridSwarm/wiremux/issues/1290) channel send-failure drain correction ([PR #1300](https://github.com/GridSwarm/wiremux/pull/1300)); the [#1251](https://github.com/GridSwarm/wiremux/issues/1251) ACME directory-URL, External Account Binding, and optional HTTP-01 listener ([PR #1304](https://github.com/GridSwarm/wiremux/pull/1304), [PR #1307](https://github.com/GridSwarm/wiremux/pull/1307)); the [#1255](https://github.com/GridSwarm/wiremux/issues/1255) free-tier relay shaping knob set ([PR #1309](https://github.com/GridSwarm/wiremux/pull/1309), [PR #1311](https://github.com/GridSwarm/wiremux/pull/1311), [PR #1313](https://github.com/GridSwarm/wiremux/pull/1313), [PR #1315](https://github.com/GridSwarm/wiremux/pull/1315)) with the `relay.ShapingEvent` schema confirmation ([PR #1324](https://github.com/GridSwarm/wiremux/pull/1324)); the [#1317](https://github.com/GridSwarm/wiremux/issues/1317) direct packet-class rebaseline to 1232 bytes ([PR #1319](https://github.com/GridSwarm/wiremux/pull/1319)) and OOB-capable selected-remote adapter ([PR #1318](https://github.com/GridSwarm/wiremux/pull/1318)); the [#1283](https://github.com/GridSwarm/wiremux/issues/1283) and [#1280](https://github.com/GridSwarm/wiremux/issues/1280) `connect` corrections ([PR #1298](https://github.com/GridSwarm/wiremux/pull/1298), [PR #1296](https://github.com/GridSwarm/wiremux/pull/1296)); and the [#1294](https://github.com/GridSwarm/wiremux/issues/1294) documentation follow-up ([PR #1302](https://github.com/GridSwarm/wiremux/pull/1302)) accumulated since v0.1.6 |
| Compatibility | Verified against the published v0.1.6 assets and the local regeneration at the released commit. Three recorded exceptions break a v0.1.6 peer or operator expectation: the relay pairing reply `0x02` "paired, relay assist withheld" (a v0.1.x client meeting a shedding v0.2.0 relay decodes it as `ErrProtocol`), the direct QUIC packet class 1280 → 1232 with Datagram ceilings 1240/1239 → 1192/1191, and `serve` owning `SIGHUP` instead of terminating on it. Generated API manifest delta over v0.1.6 is confined to `relay` and otherwise additive (`ACMEServerTLSConfig` changes type by gaining a variadic `...ACMEOption` parameter — existing two-argument calls compile unchanged, values of its old function type must update; new ACME options, shaping options, `ShapingEvent` types, `ReloadShaping`, and six sentinels; nothing removed); CLI manifest adds exactly eight `serve` flags and nine validation rules; wire-vector manifest adds exactly `status assist-withheld = 0x02` and `vector status-assist-withheld = 02`. Go floor unchanged at `go 1.27`/`go1.27.0`; `quic-go` v0.61.0 and `the-sarge/turn/v5@v5.3.0-gs.1` pins unchanged; `x/net` promoted to direct, `pebble/v2` and `miekg/dns` added as test-only direct requirements. Every downstream consumer (codemux, keymux, GridCast) must repin in lockstep |
| Downstream | Every consumer must repin in lockstep before talking to a v0.2.0 relay under shedding: codemux, keymux, and GridCast; [GridCast #673](https://github.com/GridCastIO/gridcast/issues/673) was closed by the v0.1.6 repin ([GridCast #674](https://github.com/GridCastIO/gridcast/pull/674)); the v0.2.0 repin delivers the [#1290](https://github.com/GridSwarm/wiremux/issues/1290) residual that repin left outstanding and is the prerequisite for re-measuring [GridCast #689](https://github.com/GridCastIO/gridcast/issues/689) |
| Artifact boundary | The Linux amd64 and arm64 server artifacts are tested in the native per-architecture packaged-binary smoke matrix; no other platform artifact is published or claimed; no TURN server is shipped |

The v0.2.0 Release carries eight digest-verified assets. `checksums.txt` verifies the other seven assets; both binaries report stable `v0.2.0`, Go 1.27.0, and exact revision `f835a3f6b31a803bab6f79b6f1b048e51bcfcf5f`; the same-run smoke record contains four successful natively executed cells; and the same-run NAT record contains eleven successful bidirectional observations. The Release body matches the tracked [v0.2.0 notes](release/v0.2.0/notes.md) modulo trailing-newline normalization, and the final tag and accepted candidate both resolve to the exact frozen commit.

## v0.1.6 release record

| Field | Value |
| --- | --- |
| Release | <https://github.com/GridSwarm/wiremux/releases/tag/v0.1.6> — private, immutable; repository `latest` at publication, since superseded by v0.2.0 |
| Final tag object | `1d9f73b91ababa37c8b4540487bcb802c8cfe432`, unsigned annotated, peels to the released commit |
| Released commit | `9f049b26146f34418deaa696bf4372851b0516e6`, shared by candidate and final |
| Accepted candidate | [`v0.1.6-rc.1`](https://github.com/GridSwarm/wiremux/releases/tag/v0.1.6-rc.1), tag object `f40d5e4fdba181156e57944cf333c5960460f3cc` peeling to the same commit, published by [run 32788079758](https://github.com/GridSwarm/wiremux/actions/runs/32788079758) |
| Final publication run | <https://github.com/GridSwarm/wiremux/actions/runs/32789372265> — all seven jobs success |
| Change | The [#1286](https://github.com/GridSwarm/wiremux/issues/1286) relay proxy correction ([PR #1288](https://github.com/GridSwarm/wiremux/pull/1288)): a write failure toward one paired leg no longer closes the pair before the opposite direction has forwarded that leg's queued final bytes; the [#1218](https://github.com/GridSwarm/wiremux/issues/1218) listener Selected-frame adoption ([PR #1227](https://github.com/GridSwarm/wiremux/pull/1227)) and the [#1271](https://github.com/GridSwarm/wiremux/issues/1271) probe-writer join liveness correction ([PR #1282](https://github.com/GridSwarm/wiremux/pull/1282)); the [#1273](https://github.com/GridSwarm/wiremux/issues/1273) relay `context.DeadlineExceeded` normalization ([PR #1277](https://github.com/GridSwarm/wiremux/pull/1277)); stage-labeled TURN retry failures ([PR #1225](https://github.com/GridSwarm/wiremux/pull/1225), [PR #1279](https://github.com/GridSwarm/wiremux/pull/1279)); the [#1091](https://github.com/GridSwarm/wiremux/issues/1091)/[#1087](https://github.com/GridSwarm/wiremux/issues/1087) conventions sweeps; and contract-preserving refactoring, test-harness consolidation, CI, and dependency updates accumulated since v0.1.5 |
| Compatibility | Generated API manifest delta over the published v0.1.5 asset is exactly the removal of `relay.EphemeralAbuseBackoffConfigFlagNames` and `relay.ValidateEphemeralAbuseBackoffConfigForFlags` under the recorded [#1091](https://github.com/GridSwarm/wiremux/issues/1091) exception ([PR #1248](https://github.com/GridSwarm/wiremux/pull/1248)); CLI and wire-vector manifests byte-identical to v0.1.5; `connect` error prefixes `upgradecontrol:`/`turnretry:` fold to `connect:` with sentinel identity unchanged; a paired relay write failing by timeout can keep the pair alive for up to two more blocked-write intervals; Go floor unchanged at `go 1.27`/`go1.27.0`; `the-sarge/turn/v5@v5.3.0-gs.1` pin unchanged, `cbor/v2` and `jsonschema/v6` patch bumps, `x/crypto` v0.54.0 → v0.55.0; consumers on v0.1.5 that do not reference the two removed helpers adopt as a version-only module change |
| Residual | A peer whose own concurrent `Wire.Write` fails after the counterpart closed still observes that send failure on `Read` before relay-delivered bytes ([#1290](https://github.com/GridSwarm/wiremux/issues/1290)); unchanged by this release |
| Artifact boundary | The Linux amd64 and arm64 server artifacts are tested in the native per-architecture packaged-binary smoke matrix; no other platform artifact is published or claimed; no TURN server is shipped |

The v0.1.6 Release carries eight digest-verified assets. `checksums.txt` verifies the other seven assets; both binaries report stable `v0.1.6`, Go 1.27.0, and exact revision `9f049b26146f34418deaa696bf4372851b0516e6`; the same-run smoke record contains four successful natively executed cells; and the same-run NAT record contains eleven successful bidirectional observations. The Release body matches the tracked [v0.1.6 notes](release/v0.1.6/notes.md) modulo trailing-newline normalization, and the final tag and accepted candidate both resolve to the exact frozen commit.

## v0.1.5 release record

| Field | Value |
| --- | --- |
| Release | <https://github.com/GridSwarm/wiremux/releases/tag/v0.1.5> — private, immutable; repository `latest` at publication, since superseded by v0.1.6 |
| Final tag object | `9fbbd3e4248f7f52cd1425644f4ffc77ddcef891`, unsigned annotated, peels to the released commit |
| Released commit | `8b23d9362bb7173afcc1a349bfb392dd88d0a23e`, shared by candidate and final |
| Accepted candidate | [`v0.1.5-rc.1`](https://github.com/GridSwarm/wiremux/releases/tag/v0.1.5-rc.1), tag object `2c73b1265847a2ac38238e70d6c0d076e7fe282d` peeling to the same commit, published by [run 32432856447](https://github.com/GridSwarm/wiremux/actions/runs/32432856447) |
| Final publication run | <https://github.com/GridSwarm/wiremux/actions/runs/32434143538> — all seven jobs success |
| Change | The client-side TURN/UDP relay fallback from the TURN/UDP program (Tracks [#1049](https://github.com/GridSwarm/wiremux/issues/1049) and [#1051](https://github.com/GridSwarm/wiremux/issues/1051)), the [#1146](https://github.com/GridSwarm/wiremux/issues/1146) selected-pair probe-settlement correction ([PR #1151](https://github.com/GridSwarm/wiremux/pull/1151)), the [#1145](https://github.com/GridSwarm/wiremux/issues/1145) consume-family collapse ([PR #1149](https://github.com/GridSwarm/wiremux/pull/1149)), the `github.com/the-sarge/turn/v5@v5.3.0-gs.1` pin ([#1213](https://github.com/GridSwarm/wiremux/issues/1213)), and contract-preserving hardening, CI, lint, and Go 1.27.0 toolchain changes accumulated since v0.1.4 |
| Compatibility | API manifest delta over v0.1.4 is exactly the additive TURN, topology, settlement, `connect/pionturn`, and `transport/quic.Transport.WiremuxRelayTransportProfile` declarations recorded in the [v0.1.5 notes](release/v0.1.5/notes.md) plus the seven `relay.WithMax*` `max`→`limit` parameter renames; CLI manifest byte-identical to v0.1.4; wire-vector manifest adds only the three turn-retry golden references; module Go floor `go 1.27`/`go1.27.0`; consumers on Go 1.27 can adopt v0.1.5 as a version-only module change |
| Dependency | `connect/pionturn` pins `github.com/the-sarge/turn/v5@v5.3.0-gs.1` ([#1213](https://github.com/GridSwarm/wiremux/issues/1213)); because `WithTURN` lives in the root package, that module and its pion transitive dependencies join every root-package consumer's Go build and dependency closure whether or not TURN is configured |
| Artifact boundary | The Linux amd64 and arm64 server artifacts are tested in the native per-architecture packaged-binary smoke matrix; no other platform artifact is published or claimed; no TURN server is shipped |

The v0.1.5 Release carries eight digest-verified assets. `checksums.txt` verifies the other seven assets; both binaries report stable `v0.1.5`, Go 1.27.0, and exact revision `8b23d9362bb7173afcc1a349bfb392dd88d0a23e`; the same-run smoke record contains four successful natively executed cells; and the same-run NAT record contains eleven successful bidirectional observations. The Release body matches the tracked [v0.1.5 notes](release/v0.1.5/notes.md) modulo trailing-newline normalization, and the final tag and accepted candidate both resolve to the exact frozen commit.

## v0.1.4 release record

| Field | Value |
| --- | --- |
| Release | <https://github.com/GridSwarm/wiremux/releases/tag/v0.1.4> — private, immutable; repository `latest` at publication, since superseded by v0.1.5 |
| Final tag object | `8124753658974ca1c59926310c7f163f9c664a60`, unsigned annotated, peels to the released commit |
| Released commit | `a45b6307567fc5ca64be11416c9865e38a8f056c`, shared by candidate and final |
| Accepted candidate | [`v0.1.4-rc.1`](https://github.com/GridSwarm/wiremux/releases/tag/v0.1.4-rc.1), tag object `99becf551e02934dcda54b203a3db312bbf72361` peeling to the same commit, published by [run 31641072777](https://github.com/GridSwarm/wiremux/actions/runs/31641072777) |
| Final publication run | <https://github.com/GridSwarm/wiremux/actions/runs/31642104551> — all five jobs success |
| Change | The [#1134](https://github.com/GridSwarm/wiremux/issues/1134) prior-pass probe-success settlement fix, landed by [PR #1137](https://github.com/GridSwarm/wiremux/pull/1137), plus contract-preserving relay, test, CI, and release-evidence hardening accumulated since v0.1.3 |
| Compatibility | API, CLI, and wire-vector manifests are byte-identical to v0.1.3 and the accepted candidate; invalid `EphemeralAbuseBackoffConfig` diagnostics now identify the rejected field while preserving sentinel and typed-error identity; consumers can adopt v0.1.4 as a version-only module change |
| Artifact boundary | The Linux amd64 and arm64 server artifacts are tested in the packaged-binary smoke matrix; no other platform artifact is published or claimed |

The v0.1.4 Release carries eight digest-verified assets. `checksums.txt` verifies the other seven assets; both binaries report stable `v0.1.4`, Go 1.26.5, and exact revision `a45b6307567fc5ca64be11416c9865e38a8f056c`; the same-run smoke record contains four successful cells; and the same-run NAT record contains eleven successful bidirectional observations. The Release body is byte-identical to the tracked [v0.1.4 notes](release/v0.1.4/notes.md), and the final tag and accepted candidate both resolve to the exact frozen commit.

## v0.1.3 release record

| Field | Value |
| --- | --- |
| Release | <https://github.com/GridSwarm/wiremux/releases/tag/v0.1.3> — private, immutable; repository `latest` at publication, since superseded by v0.1.4 |
| Final tag object | `6b39b5095efb7efe4e418dbaa0bd8aa1f4940305`, unsigned annotated, peels to the released commit |
| Released commit | `acf8529719de9d20ee5be7a0aa2bcc434da51581`, shared by candidate and final |
| Accepted candidate | [`v0.1.3-rc.1`](https://github.com/GridSwarm/wiremux/releases/tag/v0.1.3-rc.1), tag object `b4e13acac4126b82d64484e0fdff7ff0aae2d2d4` peeling to the same commit, published by [run 31543336962](https://github.com/GridSwarm/wiremux/actions/runs/31543336962) |
| Final publication run | <https://github.com/GridSwarm/wiremux/actions/runs/31547512024> — all five jobs success |
| Change | The [#1006](https://github.com/GridSwarm/wiremux/issues/1006) bounded probe-rerace fix, landed by [PR #1044](https://github.com/GridSwarm/wiremux/pull/1044), plus contract-preserving internal and release-evidence hardening accumulated since v0.1.2 |
| Compatibility | No exported API, CLI-manifest baseline, wire-vector baseline, or normative `COMPATIBILITY.md` delta from v0.1.2; consumers can adopt v0.1.3 as a version-only module change |
| Explicit non-claim | Unexported TURN-retry groundwork is present but inactive; v0.1.3 does not ship or claim TURN/UDP relay capability |

The v0.1.3 Release carries eight digest-verified assets. Its API, CLI, and wire-vector manifests are byte-identical to the accepted candidate's; `checksums.txt` verifies the other seven assets; the same-run smoke record contains four successful cells; and the same-run NAT record contains eleven successful bidirectional observations. The Release body matches the tracked [v0.1.3 notes](release/v0.1.3/notes.md), and the final tag and accepted candidate both resolve to the exact frozen commit.

## v0.1.2 release record

| Field | Value |
| --- | --- |
| Release | <https://github.com/GridSwarm/wiremux/releases/tag/v0.1.2> — private, immutable; repository `latest` at publication, since superseded by v0.1.3 |
| Final tag object | `e22e318e9915ed2f4fcc9b7e82cf5720fd613edc`, unsigned annotated, peels to the released commit |
| Released commit | `e9a3770e4749c81297349a2f8a55c92ba2ca1cca`, shared by candidate and final |
| Accepted candidate | [`v0.1.2-rc.1`](https://github.com/GridSwarm/wiremux/releases/tag/v0.1.2-rc.1), tag object `552f92d382f5dcd4b1612b0ce3c5964632136874` peeling to the same commit, published by [run 31071243184](https://github.com/GridSwarm/wiremux/actions/runs/31071243184) |
| Final publication run | <https://github.com/GridSwarm/wiremux/actions/runs/31071794529> — single dispatch with `source_candidate=v0.1.2-rc.1`, all five jobs success; publication record on [#1001](https://github.com/GridSwarm/wiremux/issues/1001#issuecomment-5200516287) |
| Change | The [#1001](https://github.com/GridSwarm/wiremux/issues/1001) direct-wire idle-liveness fix, landed by [PR #1002](https://github.com/GridSwarm/wiremux/pull/1002): `transport/quic` keepalives default on with the idle deadline stated explicitly; published API-manifest delta vs v0.1.1 verified to be exactly `DefaultKeepAlivePeriod`, `DefaultMaxIdleTimeout`, and the `Transport.KeepAlivePeriod`/`Transport.MaxIdleTimeout` fields |

The v0.1.2 Release carries the same eight-asset evidence shape as v0.1.1 (manifests byte-identical to its candidate's, same-run NAT and smoke evidence, `checksums.txt` verifying the other seven); the Release body matches the tracked [v0.1.2 notes](release/v0.1.2/notes.md) at the released commit modulo trailing-newline normalization. Unlike v0.1.1, this release changes production default behavior deliberately: idle direct wires now survive, and battery- or network-sensitive consumers can tune or disable keepalives per the notes.

## v0.1.1 release record

| Field | Value |
| --- | --- |
| Release | <https://github.com/GridSwarm/wiremux/releases/tag/v0.1.1> — private, immutable; repository `latest` at publication, since superseded by v0.1.2 |
| Final tag object | `78a753ade42a04bf69376896d981efc4d4a0383a`, unsigned annotated, peels to the released commit |
| Released commit | `65bfb80668f6accbb5c954e68d41c191208c5d77`, shared by candidate and final |
| Accepted candidate | [`v0.1.1-rc.1`](https://github.com/GridSwarm/wiremux/releases/tag/v0.1.1-rc.1), tag object `32fcdf28bc51dd57324b8c71f5e6164231e3ba0f` peeling to the same commit, published by [run 31035690496](https://github.com/GridSwarm/wiremux/actions/runs/31035690496) |
| Final publication run | <https://github.com/GridSwarm/wiremux/actions/runs/31036850561> — owner GO, single dispatch, all five jobs success |
| Change | Exactly one public addition, `wiremuxtest.(*Relay).RequireEphemeralWaiter` ([#987](https://github.com/GridSwarm/wiremux/issues/987), landed by [PR #996](https://github.com/GridSwarm/wiremux/pull/996)); published API-manifest delta vs v0.1.0 verified to be exactly that declaration |

The v0.1.1 Release carries the same eight-asset evidence shape as v0.1.0 (manifests byte-identical to its candidate's, same-run NAT and smoke evidence, `checksums.txt` verifying the other seven); the Release body matches the tracked [v0.1.1 notes](release/v0.1.1/notes.md) at the released commit modulo the API's trailing-newline normalization.

## v0.1.0 release record

| Field | Value |
| --- | --- |
| Release | <https://github.com/GridSwarm/wiremux/releases/tag/v0.1.0> — private, immutable; repository `latest` at publication, since superseded by v0.1.1 |
| Final tag object | `387ab09341267fdbfcfec00097680c90e36ca58e`, unsigned annotated, peels to commit `C` |
| Commit `C` | `0bbb76b381d0ef8bd2b676ff9c93276726b6e40a`, shared by candidate and final |
| Accepted candidate | [`v0.1.0-rc.3`](https://github.com/GridSwarm/wiremux/releases/tag/v0.1.0-rc.3), tag object `79b42c084f09b37a4c084e122e171164acaba0c6` |
| Publication run | <https://github.com/GridSwarm/wiremux/actions/runs/30975618732> — one `workflow_dispatch` by the frozen approver, attempt 1, success |
| Preparation record | [#921 comment](https://github.com/GridSwarm/wiremux/issues/921#issuecomment-5187540816), digest `sha256:ee5e1cf8050dff73778c49f1356f3905fe7427d230f38053d863532976ad5189` |
| GO verdict | [#921 comment](https://github.com/GridSwarm/wiremux/issues/921#issuecomment-5187545116), digest-bound to the preparation record |
| Terminal publication record | [#922 comment](https://github.com/GridSwarm/wiremux/issues/922#issuecomment-5187676702), with every identity, URL, and asset digest |

The Release carries eight digest-verified assets: the [API](https://github.com/GridSwarm/wiremux/releases/download/v0.1.0/api-manifest.txt), [CLI](https://github.com/GridSwarm/wiremux/releases/download/v0.1.0/cli-manifest.txt), and [wire-vector](https://github.com/GridSwarm/wiremux/releases/download/v0.1.0/wire-vectors-manifest.txt) compatibility manifests (byte-identical to the published candidate assets), the same-run eleven-observation [`nat-evidence.json`](https://github.com/GridSwarm/wiremux/releases/download/v0.1.0/nat-evidence.json) and four-cell [`smoke-record.json`](https://github.com/GridSwarm/wiremux/releases/download/v0.1.0/smoke-record.json), the `wiremux-server` linux [amd64](https://github.com/GridSwarm/wiremux/releases/download/v0.1.0/wiremux-server_linux_amd64) and [arm64](https://github.com/GridSwarm/wiremux/releases/download/v0.1.0/wiremux-server_linux_arm64) binaries, and [`checksums.txt`](https://github.com/GridSwarm/wiremux/releases/download/v0.1.0/checksums.txt), which verifies the other seven byte-for-byte. Asset access requires authenticated read access to the private repository. The Release body is byte-identical to [`release/v0.1.0/notes.md`](release/v0.1.0/notes.md) at `C`.

Consumer evidence for the accepted candidate — the same commit `C` — lives in the gate evidence rows: [codemux #916](https://github.com/GridSwarm/wiremux/issues/916#issuecomment-5186241122), [tapmux #917](https://github.com/GridSwarm/wiremux/issues/917#issuecomment-5186558435), and [GridCast #918](https://github.com/GridSwarm/wiremux/issues/918#issuecomment-5187379394), consolidated by the [Phase 4 exit ledger](https://github.com/GridSwarm/wiremux/issues/920#issuecomment-5187425954). keymux and SwarmCast have dated negative-evidence deferrals only and receive no v0.1.0 compatibility claim.

The release's non-claims are normative in the [release notes](release/v0.1.0/notes.md): no hosted relay or SLA, container image, package-manager distribution, TURN-like unreliable relay, identity layer, mesh coordination, or application protocol; unsigned annotated tags with no SBOM, artifact-attestation, or cross-run reproducible-binary claim; live public-CA ACME issuance deferred to [#924](https://github.com/GridSwarm/wiremux/issues/924); private repository access as the distribution boundary with no license grant implied.

Before the first tag, the display text of
`connect.ErrUpgradeTransportNotConverged` changed from “post-commit direct
transport did not converge” to “direct transport did not converge after
ownership transfer” so it also describes listener `Accept`-before-commit
failure. Sentinel identity and `errors.Is` classification are unchanged;
literal error-string and telemetry matchers must update.

## Datagram migration context

The optional carrier-bound Datagram plane was added before the first tag. Its authoritative public declarations, ownership rules, error classification, and wire profile are defined only by the root `wiremux`, `connect`, and wire-profile sections of [`COMPATIBILITY.md`](COMPATIBILITY.md); this section records pre-release migration context.

`connect.UpgradeResult.Datagrams` was added as the second exported field,
between `Stream` and `Path`. External unkeyed `UpgradeResult` literals written
for the earlier five-field shape no longer compile and must migrate to keyed
literals. The GridSwarm consumer inventory found no affected literals.

`wiremuxtest` protects the production contract with `RunDatagramContract`,
`RunDatagramAbsenceContract`, `RunDatagramMalformedContract`, and
`RunDatagramPostCommitMalformedContract`, together with their public factory
types. Downstream consumers have not yet migrated to this optional surface;
those migrations remain separately owned follow-up work and must pin an
immutable wiremux revision.

## `wiremuxtest` consumer context

`github.com/GridSwarm/wiremux/wiremuxtest` is now part of the supported public surface. It is test-only in intent and receives normal compatibility protection. Its authoritative declaration inventory and behavioral contract are defined only by the `wiremuxtest` section of [`COMPATIBILITY.md`](COMPATIBILITY.md); this section records consumer-test intent and migration context.

The package is not an alternate production client, an identity fixture, or an
application-test framework. It does not expose reusable insecure TLS trust,
translate relay or wiremux errors, or equate physical relay-session consumption
with identity-layer muxcode spending.

Production `wiremux.Dial` has no reachable outcome containing both a non-nil
`*Wire` and a non-nil error. The canonical codemux specification therefore
records an explicit partial-Wire proof exception in
[codemux issue #260](https://github.com/GridSwarm/codemux/issues/260#accepted-partial-wire-proof-exception-2026-07-11)
and its wiremux slice in
[codemux issue #263](https://github.com/GridSwarm/codemux/issues/263#accepted-partial-wire-proof-exception-2026-07-11).
External `wiremuxtest_test` coverage proves every reachable rendezvous,
identity, channel, upgrade, asymmetric, and whole-success outcome. Under that
accepted exception, a package-internal injected Dial result proves the locked
partial-Wire ownership rule without presenting it as a production black-box
case.

Explicit consumption requires the relay session to remain live-paired unless a
retained consumed tombstone exists, so consumers call it before closing either
paired resource. Repeated consumption succeeds only while that tombstone
remains within its configured ephemeral-expiry window. Consumed-session
observation uses one real rendezvous Dial and must not race another dialer using
the same Session ID.

`RequireEphemeralWaiter` is a bounded, exact-Session-ID assertion that observes a current ephemeral ledger waiter without dialing, pairing, consuming, or otherwise probing the rendezvous. Its redacted failure terminates orchestration before a counterpart is started, and fixture termination aborts an in-flight assertion promptly. The module-internal constructor bridge that supplies this state to `wiremuxtest` is not a consumer telemetry surface.

The canonical ownership decision is
[codemux ADR-0006](https://github.com/GridSwarm/codemux/blob/main/docs/adr/adr-0006-public-test-support-ownership.md).
It assigns generic connectivity support to `wiremuxtest` and muxcode/PAKE
composition to codemux's later `codemuxtest` package without changing existing
production declarations or dependency direction.

### v0.1.0 successful-transfer requirement admission

By maintainer decision on 2026-07-30, v0.1.0 Phase 1A admits the additive test-only `wiremuxtest.RequireStreamTransfer` and `wiremuxtest.RequireChannelTransfer` declarations before candidate commit `C` is selected. Architecture slice `ADP-2026-07-30-T1-S1` owns their implementation, bounded redacted behavior, owner-package caller migration, and exact contract evidence. Both declarations must join the v0.1.x compatibility baseline, exported-declaration inventory, and active API evidence before `C`; this disposition does not itself select a candidate commit, create a tag, or publish a release. This admission is discharged: both declarations are in the protected [`COMPATIBILITY.md`](COMPATIBILITY.md) inventory at published commit `C`.

## Downstream order

Consumer evidence must use immutable revisions; no branch-only dependency, temporary `replace`, copied fixture, or shim is release evidence. For v0.1.0 that order was executed: wiremux landed `wiremuxtest`, codemux gated first against the accepted candidate ([#916](https://github.com/GridSwarm/wiremux/issues/916)), then tapmux as the live canary ([#917](https://github.com/GridSwarm/wiremux/issues/917)) and GridCast as the primary acceptance gate ([#918](https://github.com/GridSwarm/wiremux/issues/918)), each on a retained gate branch. swarmcast adoption still follows when its binding spike is implemented.

Stable-version migrations are handed to their owning repositories and are not wiremux release work:

- [codemux #413](https://github.com/GridSwarm/codemux/issues/413) (complete — codemux `v0.2.1` pins wiremux `v0.1.0`) was the first stable-version migration handoff. By owner decision on 2026-08-05, downstream followers skip the v0.1.0/v0.2.1 stack: [codemux #418](https://github.com/GridSwarm/codemux/issues/418) (complete — codemux `v0.2.2` pins wiremux `v0.1.1`) repinned to wiremux `v0.1.1` and tagged `v0.2.2`.
- The [#1001](https://github.com/GridSwarm/wiremux/issues/1001) idle-liveness fix supersedes the v0.1.1 target for consumers that had not yet migrated: codemux repins to `v0.1.2` on its own cadence, and [tapmux #426](https://github.com/SwarmCast/tapmux/issues/426) and [GridCast #285](https://github.com/GridCastIO/gridcast/issues/285) — both paused on #1001 — migrate once, directly to the v0.1.2 stack (wiremux `v0.1.2` plus codemux's next tag repinning it, not yet cut); each carries its adjudicated gate-branch changes forward. tapmux's v2.0.0 release-readiness tracker ([tapmux #428](https://github.com/SwarmCast/tapmux/issues/428)) resumes with its repin and an explicit held-idle direct-path check.
- v0.1.3 supersedes v0.1.2 for consumers that have not completed that migration. Because the patch adds no public, CLI, or wire delta, those consumers can target v0.1.3 with the same version-only adoption shape while gaining the bounded probe-rerace correction.
- v0.1.4 supersedes v0.1.3 for consumers that have not completed that migration. Its generated compatibility manifests are byte-identical to v0.1.3, so consumers can target v0.1.4 with the same version-only adoption shape while gaining the prior-pass probe-success settlement correction.
- v0.1.5 supersedes v0.1.4 for consumers that have not completed that migration. Its API delta is additive (opt-in TURN), its CLI manifest is byte-identical to v0.1.4, and its Go floor is 1.27, so consumers building with Go 1.27 can target v0.1.5 as a version-only module change; TURN stays inactive until a consumer configures `WithTURN`, but `github.com/the-sarge/turn/v5@v5.3.0-gs.1` and its pion transitive modules enter every root-package consumer's dependency closure regardless.
- v0.1.6 supersedes v0.1.5 for consumers that have not completed that migration. Its API delta is the removal of two `relay` CLI flag-presentation helpers no released consumer referenced, and its CLI and wire-vector manifests are byte-identical to v0.1.5, so consumers can target v0.1.6 as a version-only module change while gaining the relay proxy drain correction and the TURN retry listener fixes. GridCast's repin to v0.1.6 is the acceptance evidence for [GridCast #673](https://github.com/GridCastIO/gridcast/issues/673); the aggregate-Wire residual [#1290](https://github.com/GridSwarm/wiremux/issues/1290) may limit what that evidence can prove.
- v0.2.0 supersedes v0.1.6 and is not a version-only adoption: its `0x02` assist-withheld pairing reply is decoded as `ErrProtocol` by any v0.1.x client that meets a shedding v0.2.0 relay, so codemux, keymux, and GridCast repin in lockstep (wiremux tags first, per the coordinated-tag rule below); ordinary consumer code compiles unchanged, values of `relay.ACMEServerTLSConfig`'s old function type must update, and Datagram callers must accept the 1191-byte ceiling. [GridCast #673](https://github.com/GridCastIO/gridcast/issues/673) was already closed by the v0.1.6 repin; GridCast's v0.2.0 repin delivers the [#1290](https://github.com/GridSwarm/wiremux/issues/1290) residual that repin left outstanding and is the prerequisite for re-measuring [GridCast #689](https://github.com/GridCastIO/gridcast/issues/689), which only realises the OOB adapter's syscall win once GridCast batches Symbol writes.
- v0.2.1 supersedes v0.2.0 for consumers that have not completed that migration. Its API and wire-vector manifests are byte-identical to v0.2.0, the CLI delta is additive, and dependency pins are unchanged, so v0.2.0 consumers can repin without coordinated wire migration; callers that retain a `channel.Receive` payload across the next receive or close must copy it first.
- GridCast's test-observation sequencing is complete on the wiremux side: v0.1.1 ships the waiter-observation seam ([#987](https://github.com/GridSwarm/wiremux/issues/987), closed at publication), and [GridCast #282](https://github.com/GridCastIO/gridcast/issues/282) restores the strong observation path in the [#285](https://github.com/GridCastIO/gridcast/issues/285) migration; the `compat/gridcast-v0.1` branch is deleted only after that migration merges, because GridCast `main` pins the compat pseudo-version until then.
- keymux and SwarmCast retain no v0.1.0 compatibility claim; their migrations begin only when a buildable integration exists.

If coordinated tags are cut, wiremux tags first. Codemux updates to that immutable revision and reruns its gates before codemux tags.
