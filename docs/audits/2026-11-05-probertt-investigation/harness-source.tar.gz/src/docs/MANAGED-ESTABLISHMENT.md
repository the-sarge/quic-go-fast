# Managed authenticated establishment

`wiremux.EstablishAuthenticated(ctx, raw, auth, relayURL, opts...)` establishes a reliable wire after the caller has paired and freshly authenticated two peers. The caller owns admission and authentication; wiremux owns channel construction, default UDP/discovery setup, strict transport negotiation, path metadata, and cleanup. The relay URL supplies only the default discovery host. There is no rendezvous identifier or consumption capability in this API.

Ownership of every non-nil raw carrier and auth context transfers at invocation, including when validation fails. The caller must stop using or releasing these inputs. The raw carrier must support full-duplex I/O and a `Close` that interrupts I/O. Auth material must be fresh and single-use for this attempt; wiremux neither authenticates again nor caches keys. The returned `ManagedWire` exposes reliable `Read`/`Write`, borrowed `Auth` and optional `Datagrams`, `Info`, `Direct`, `CarrierTopology`, and selected diagnostics when applicable. No raw carrier, packet socket, or independent resource lifetime escapes the managed result.

On Linux, macOS, and Windows, `WithManagedSelection(handle)` makes managed establishment strict about routing provenance. The raw carrier must be the exact final paired carrier minted by `relay.Dial(..., relay.WithSelection(handle))`, and the managed option must receive the identical opaque handle. Missing provenance, caller wrappers, and independently resolved equal-looking handles are rejected before channel negotiation or UDP creation; transferred raw/auth inputs are still disposed by the existing settlement owner. A structurally valid handle and exact already-bound relay-only carrier remain admissible after construction staleness. If a fresh UDP socket is needed, its constructor still validates and fails through the existing cleanup owner. Bound I/O follows the [selected socket lifetime](SELECTED-INITIAL.md) without live inventory checks. Unselected managed establishment continues to accept arbitrary full-duplex raw carriers.

```go
// Each peer resolves its own process-local handle, then reuses that exact local
// handle for both relay pairing and managed establishment.
raw, err := relay.Dial(ctx, endpoint, relay.ModeEphemeral, sessionID,
    relay.WithSelection(handle),
    relay.WithDialTLSConfig(tlsConfig),
)
if err != nil {
    return err
}
managed, err := wiremux.EstablishAuthenticated(ctx, raw, freshAuth, endpoint.String(),
    wiremux.WithManagedSelection(handle),
)
```

Selected managed establishment reuses the root selected native UDP, candidate, STUN/probe, QUIC metadata, fallback, and lifetime enforcement. `ManagedWire.SelectionInfo()` returns the same copied diagnostics as `Wire.SelectionInfo()`; a relay-only selected result has no packet address. Selected direct failure may retain only the already-proven relay carrier. It adds no rendezvous consumption, caller routing callback, custom transport, TURN, saved identity, or implicit migration inheritance. A separate `PrepareMigration` operation remains unselected unless `WithMigrationSelection` explicitly supplies and validates its fresh carrier/handle pair.

```go
// raw and freshAuth come from the caller's completed authentication/admission.
managed, err := wiremux.EstablishAuthenticated(commandCtx, raw, freshAuth, relayURL,
    wiremux.WithManagedEstablishTimeout(10*time.Second),
)
if err != nil {
    // wiremux has already settled the transferred inputs.
    return err
}
defer managed.Close() // abort on an unsuccessful application operation
if err := transfer(managed); err != nil {
    return err
}
return managed.CloseGracefully()
```

`Close` interrupts the owned reliable carrier before joining cleanup. It also escalates a concurrent `CloseGracefully` that is waiting on an active write. `CloseGracefully` permits the reliable stream to flush before disposal; it can wait on a peer that does not read, so callers may abort it with `Close`. Both use the existing Wire lifetime, auth revocation, and resource disposal owner. Initial `Dial` and its `Wire.Close` behavior remain unchanged.

`ManagedWire.Datagrams()` delegates to the owned Wire and returns its existing borrowed handle, or `(nil, false)` on reliable-only relay fallback. Repeated discovery returns the same handle, including after close; operations on an ended handle report `ErrWireClosed`. Both managed close paths terminate its lifetime. Canceling one Datagram operation leaves the Wire and its reliable stream usable. Direct QUIC supports this optional plane; managed establishment still exposes no TURN or custom transport options. Existing Datagram payload, queue, cancellation and error contracts apply unchanged.

The shared defaults are the built-in QUIC transport, internally owned UDP setup, best-effort STUN at the relay host on port 3478, and separate three-second probe and control-step budgets. Managed default DNS resolution may wait up to half the control-step budget before negotiation, leaving an exchange margin for an already-ready peer with the same budget; lookup failure or expiry retains best-effort discovery, while caller cancellation remains terminal. Initial Dial keeps its existing opportunistic DNS overlap with pairing and authentication. Those budgets are not a total establishment deadline. `WithManagedProbeTimeout`, `WithManagedControlTimeout`, and `WithManagedEstablishTimeout` override the respective budgets. `WithManagedRelayOnly` disables direct setup while retaining strict control synchronization; it accepts control and establishment timeout options but conflicts with a probe timeout. `WithManagedChannelOptions` forwards channel stream options. No TURN, custom transport, caller packet socket, rendezvous, or authenticator options are exposed. Nil contexts mean `context.Background`; nil options are ignored.

Every failure exposes `*wiremux.EstablishmentError`; `Kind()` uses `connect.UpgradeErrorKind`. Preflight, invalid auth/channel state, and preparation failures are terminal local failures. Non-authentication preflight failures preserve their validation cause without adding `ErrIdentity`; genuine auth-context validation retains identity classification. Strict negotiation preserves its current operation's classification and the underlying `*connect.UpgradeError`: malformed authenticated control is terminal protocol failure, safe fallback succeeds, and only `UpgradeErrorTransientTransport` permits considering transport retry. Caller cancellation/deadline remain distinct and preserve `errors.Is`. Classification never comes from fallback labels, a generic `net.Error`, or an auth error wrapping another attempt's failure. Consumers must still apply their own admission, command-lifetime, and retry rules.

The W3 evidence covers eleven bounded semantic scenarios: relay success with overridden control policy (including real-relay non-consumption), direct success, safe relay after asymmetric discovery expiry, relay/direct graceful delivery, relay/direct blocked-write abort escalation, invalid input/preflight cleanup, preparation failure, strict protocol failure, and caller context termination. Initial Dial consumption, ownership, compatibility, TURN, and Datagram preservation use the existing repository suites. Repeated Resume admission across different outcomes and real-machine transfer evidence belong to the downstream [G2 contract](https://github.com/GridCastIO/gridcast/blob/main/docs/adr/2026-09-10-direct-resume-gridcast-plan.md). Consumer adoption and any release are separate work.

The M1 evidence adds five public-seam cases through real managed establishment: relay absence with reliable exchange, stable direct discovery and bilateral Datagram/reliable exchange, Receive cancellation followed by continued use, abort of a blocked Receive with closed-operation classification, and graceful reliable flush with Datagram revocation by completion. These are bounded preservation examples, not exhaustive transport or concurrency claims.

The selected-routing W3 evidence is bounded to four families from the [accepted routing-foundation contract](https://github.com/GridCastIO/gridcast/blob/90d06caa174d270d91a6e58a8e48ee621f0f1cce/docs/adr/2026-09-21-routing-foundation-plan.md#w3--selected-managed-establishment): exact selected direct and forced-fallback establishment; absent/wrapped/mismatched provenance rejection; stale-handle rejection when fresh UDP construction is required (an exact already-bound relay-only carrier remains admissible); and validation/cancellation with exactly-once raw/auth disposal before network work. The real Linux composition is example-level native evidence. The exact receipt classes are the finite canonical subset owned by the selection module; tests are verification aids, not a maintained harness.

## Configured built-in QUIC

`WithManagedQUICTransport(transport)` selects the module-owned `*quic.ConfiguredTransport` returned by `quic.NewConfiguredTransport`. It retains built-in selected-interface eligibility and applies the immutable local sender/ACK settings to either session role. It does not admit arbitrary custom transports. Nil fails preflight, disposing transferred raw/auth inputs through the existing settlement owner. Configure both peers and every Resume attempt explicitly; existing Wires retain their settings. [Exact controller and conservative ACK configuration](QUIC-CONTROLLERS.md) covers fast.9 selection, capability failures, default preservation and experimental BBR limits.
