# Code Conventions

Normative house conventions for `GridSwarm/wiremux`, codified from the 2026-08-11 code-smell audit ([#1086](https://github.com/GridSwarm/wiremux/issues/1086)). New and modified code follows these rules immediately; the consistency sweeps (#1087, #1088, #1089, #1090, #1091, #1093) converge existing code toward them. Sanctioned exceptions are listed with their rule and are not precedents for new code.

## Error messages

Prefix error strings with the bare package name and a colon: `connect: ...`, `relay: ...`, `channel: ...`. Wrap underlying errors with `%w` and keep the prefix on the wrapping message.

Sanctioned exception: the transport layer keeps its spaced prose prefixes `wiremux quic transport:` and `wiremux transport adapter:`. A bare `quic:` prefix would read as the QUIC protocol or the quic-go library in logs that interleave both; the prose prefixes disambiguate. Do not extend this exception to new packages.

The remaining spaced prose prefix, `wiremux datagram admission:` in `internal/datagramadmission`, is not sanctioned: it is a #1091 sweep target that converges to the bare package prefix.

## Panic text

Panic messages are prefixed invariant strings describing the violated invariant, for example `panic("wiremux: invalid establishment failure kind")` or `panic("connect: Accept operation is not registered")`. Never call bare `panic(err)`.

The rule applies to production and test code alike. The known bare `panic(err)` sites in production files (`internal/compatmanifest/channel.go`, `internal/nettest/packet_conn.go`, `connect/control_codec.go`) are #1091 sweep targets; the one test-file site (`connect/turn_retry_engine_test.go`) converges when the test-harness sweeps touch it. None are sanctioned exceptions.

## Test assertion grammar

Assertion messages use got/want ordering: `t.Errorf("...: got %v, want %v", got, want)`. The value the code produced is `got`; the value the test requires is `want`.

Existing `expected ...` messages converge when a sweep or ordinary edit touches them; no wholesale rewrite is mandated.

## Shell dialect

Scripts are POSIX `sh`: `#!/bin/sh` with `set -eu`, indented with tabs.

Bash is admitted for a new script only when a bash-only construct is load-bearing — `set -o pipefail` on a pipeline whose non-terminal failure must fail the script, or NUL-delimited `read -r -d ''` — spelled `#!/usr/bin/env bash` with `set -euo pipefail`. Prefer restructuring to POSIX `sh` first. The two existing bash scripts, `scripts/ci-classify.sh` (which depends on NUL-delimited `read -r -d ''`) and `scripts/test-docs-check.sh`, are retained sanctioned exceptions.

## Production test seams

Test hooks in production types are unexported `test`-prefixed fields or variables (for example `testBeforeReceiveDelivery`, `testWaiters`) that stay nil or zero in production paths.

Test-only symbols carry a `ForTest` suffix and use one of two forms. When the consumers are the package's own external tests, the symbol lives in an `export_test.go` file (for example `WithDefaultListenPacketForTest`). When another package's tests must import it — a case `export_test.go` cannot serve under Go's compilation model — the sanctioned form is an exported `ForTest`-suffixed symbol in a production file that panics unless `testing.Testing()` reports a test binary (for example `relayprofile.TURNQUIC3TransportForTest`). Production files do not export unguarded test-only API.

## Receiver names

Method receivers are one or two letters, consistent across all methods of a type. This deliberately follows upstream Go guidance ("short, often one or two letters") rather than mandating a single letter; do not churn compliant two-letter receivers to one letter or vice versa.

## Goroutine ownership

Every launched goroutine needs a terminating ownership path. Use buffered one-shot result channels when a worker reports once and its receiver may stop waiting. An unbuffered send must select on a cancellation or shutdown escape. Cancel owned work before joining it, and join every watcher or pump before its owner returns; WaitGroup-tracked pumps also need an explicit drain or disposal action that wakes blocked I/O. When more than one consumer must observe a one-shot outcome, re-buffer the result instead of making consumers compete for one receive.

Goroutine census tests and the native `goroutineleak` profile answer different questions and remain complementary. A name-based `runtime.Stack` census can detect in-flight work on channels, synchronization primitives, network I/O, or file I/O, but needs a bounded poll while legitimate work finishes and an explicit name filter. A `goroutineleak` assertion performs one process-global leak-detection GC and reports goroutines proven unable to resume through channels or `sync.Mutex`, `sync.RWMutex`, `sync.WaitGroup`, or `sync.Cond`; it does not report network or file I/O blockers and can be masked when a global or running goroutine retains a primitive that could wake the blocked goroutine. Run the assertion only at process end or a known-serial seam after all owned cleanup, never inside a parallel subtest.

Three production blocker classes may remain indefinitely by design when an external contract is violated, and a production leak profile should expose rather than suppress them. The late auth-context watcher in `auth_context_lifecycle.go` waits for a consumer's outstanding key or exporter call to release the idle gate; relay shutdown observers in `relay/runtime.go` and `relay/server.go` wait on an abandoned runtime after shutdown has already returned `relay.ErrShutdownTimeout`; and the `orderedAuthContextReleaseObserver` chain waits for an earlier consumer release-error handler to return. These are bounded at the public operation by timeout or error reporting, but the observer goroutine itself can terminate only when the responsible consumer or abandoned work honors its contract.
