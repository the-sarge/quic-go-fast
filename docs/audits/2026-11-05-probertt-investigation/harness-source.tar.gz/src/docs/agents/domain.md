# Domain Docs

wiremux is a single-context repository.

Before exploring or changing the project:

- Read the root `CONTEXT.md`; its `Language` section is the project glossary.
- Read the ADRs in `docs/adr/` that concern the area being investigated.
- Use the glossary's canonical vocabulary in issues, plans, code, and tests.
- Surface conflicts with existing ADRs explicitly rather than silently
  overriding them.

Missing domain documentation is not itself a reason to create files. Use
domain modeling to add terms to the `CONTEXT.md` glossary or add ADRs only when
a real decision requires them.
