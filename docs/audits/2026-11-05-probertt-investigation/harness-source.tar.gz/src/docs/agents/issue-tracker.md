# Issue Tracker: GitHub

Work items, Wayfinder maps and tickets, and specifications published by agent
skills live as GitHub issues. Canonical repository PRDs live under
[`docs/prd/`](../prd/) and may have tracking issues. Use the `gh` CLI for all
tracker operations.

## Conventions

- Use `gh issue` for ordinary issue creation, reads, updates, comments, labels,
  assignments, and closure. Use `gh api` for relationship operations that
  `gh issue` does not expose.
- Infer the repository from the current checkout and its GitHub remote.
- GitHub shares one number space across issues and PRs; resolve ambiguous
  numbers before acting by trying `gh pr view <number>` and then
  `gh issue view <number>` when the number is not a PR.
- External PRs are not a triage request surface.

## When a skill says “publish to the issue tracker”

Create a GitHub issue.

## When a skill says “fetch the relevant ticket”

Read the GitHub issue and its comments.

## Wayfinding Operations

The map is one issue labelled `wayfinder:map`. Its tickets are GitHub
sub-issues labelled with one of `wayfinder:research`, `wayfinder:prototype`,
`wayfinder:grilling`, or `wayfinder:task`.

Create every issue before wiring relationships. The REST relationship APIs use
an issue's numeric database `id`, not its issue number or GraphQL node ID. Set
`MAP`, `CHILD`, `BLOCKED`, and `BLOCKER` to issue numbers as applicable:

```bash
repo="$(gh repo view --json nameWithOwner --jq .nameWithOwner)"

child_id="$(gh api "repos/$repo/issues/$CHILD" --jq .id)"
gh api --method POST "repos/$repo/issues/$MAP/sub_issues" \
  -F sub_issue_id="$child_id"

blocker_id="$(gh api "repos/$repo/issues/$BLOCKER" --jq .id)"
gh api --method POST \
  "repos/$repo/issues/$BLOCKED/dependencies/blocked_by" \
  -F issue_id="$blocker_id"
```

If native sub-issues are unavailable, use a task list on the map and a `Part of`
pointer in the ticket. If native dependencies are unavailable, record
`Blocked by` in the ticket body.

The frontier consists of the map's open, unassigned child issues with no open
blockers. The REST summary's `blocked_by` field is the open-blocker count;
`total_blocked_by` also counts closed blockers. Query the native frontier with:

```bash
repo="$(gh repo view --json nameWithOwner --jq .nameWithOwner)"
gh api --paginate "repos/$repo/issues/$MAP/sub_issues?per_page=100" \
  --slurp | jq '
    add
    | map(select(
        .state == "open"
        and (.assignees | length) == 0
        and .issue_dependencies_summary.blocked_by == 0
      ))
    | .[] | {number, title}
  '
```

Claim a frontier ticket before doing any work:

```bash
gh issue edit "$TICKET" --add-assignee @me
```

Resolve exactly one ticket by posting its answer, closing it, and updating a
freshly fetched map body with a linked one-line gist under `Decisions so far`:

```bash
gh issue comment "$TICKET" --body-file resolution.md
gh issue close "$TICKET"
gh issue edit "$MAP" --body-file updated-map.md
```

Re-fetch the map immediately before editing it so concurrent Wayfinder sessions
are not overwritten.
