# Managed authenticated Wire Datagram exposure implementation plan

**Date:** 2026-09-17
**Status:** M1 complete; M-release ready for the existing release workflow; GridCast D1 remains blocked on verified publication
**Track:** M of the cross-repository `repair-767` program
**Parent issue:** [#1579](https://github.com/GridSwarm/wiremux/issues/1579)
**Program index:** [GridCast repair and datagram program](https://github.com/GridCastIO/gridcast/blob/main/docs/adr/2026-09-16-repair-program.md)
**Depends on:** No implementation prerequisite
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers and stop conditions
**Audit history:** [GridCast D1 boundary-stop receipt](https://github.com/GridCastIO/gridcast/pull/1112#issuecomment-5717527430)

## Goal and current shape

Expose the existing borrowed Datagram plane through the managed authenticated Wire returned to consumers after authentication. This closes GridCast's Resume capability gap without adding transport behavior or another resource owner.

Verified on wiremux `365856bd9d85511b2c930e5a7fd99d65dca74163`: `managed_establishment.go:70` holds a private Wire and forwards reliable I/O, auth and lifecycle operations; `wiremux.go:403` exposes `Wire.Datagrams`; `datagrams.go:24` defines a borrowed handle with no independent Close, `:72` fixes MaxPayload for its lifetime, and `:80` defines Send success as admission only. `docs/MANAGED-ESTABLISHMENT.md:5` explicitly excludes a Datagram handle from the managed result. That exclusion must be deliberately narrowed, not bypassed by exposing the private Wire. Managed options at `managed_establishment.go:15` exclude TURN, custom transport and caller sockets. `managed_establishment_test.go:42` already owns a bilateral authenticated establishment fixture.

GridCast's initial `attemptWire` wrapper also hides optional discovery (`internal/transfer/sender_attempt.go:165` on GridCast `e199d2b760165507fa47b35a4e89e59f68185f5b`); GridCast D1 owns that local forwarding and the released dependency adoption. The unmerged GridCast draft is not a baseline or blocker for M1. Existing wiremux Datagram performance issues and completed QUIC-I/O work impose no new M1 prerequisite.

## Decision

Add `func (w *ManagedWire) Datagrams() (*Datagrams, bool)` as direct delegation to its owned Wire's existing discovery method. Repeated discovery returns the same existing optional handle, or `(nil, false)` when absent. The forwarding method neither constructs nor owns a plane. Managed `Close` and `CloseGracefully` retain their existing abort/flush semantics and terminate the borrowed handle through Wire teardown. Caller cancellation of one Datagram operation does not close the Wire.

The supported domain is successfully constructed ManagedWires using current built-in direct QUIC or reliable-only relay fallback. Method behavior follows the established Wire contract, including post-close discovery; the borrowed handle's operations enforce ended lifetime. Nil/zero-value ManagedWire support is not added. Keep the mandatory consumer interfaces, option set, public struct layouts, authentication, negotiation and wire bytes unchanged. Existing native payload, queue, cancellation and error contracts remain authoritative.

Update facade godoc, managed establishment documentation, compatibility inventory and the maintained generated API-manifest golden. Narrow the managed-doc exclusion to permit the borrowed Datagram view while retaining the bans on raw carrier/socket access and independent lifetime. No new domain term or standalone ADR is needed: Wire, ManagedWire and Datagrams already have these meanings; this plan records the access-policy decision.

**Rejected alternatives (do not do this):** Do not expose `.wire`, create a second Wire/Datagrams instance, add a Close to Datagrams, duplicate queues, re-authenticate, or bypass managed establishment. Do not gate this on Datagram performance qualification or migrate unrelated consumers. Do not claim TURN support for managed establishment or add Datagrams to a reliable-only carrier.

**Non-goals:** New transport/relay support, path scheduling, payload or queue-policy changes, performance claims, packet formats, release-pipeline standardization, GridCast code, and codemux/keymux upgrades. The additive method leaves existing consumers source-compatible; D1 is the consumer adoption PR.

## Slice graph

| Slice or gate | State/disposition | Delivers | Blocked by | Temporary seam removed |
| --- | --- | --- | --- | --- |
| M1 | Complete | Supported borrowed Datagram discovery and use through real managed establishment | None | Managed facade capability omission |
| M-release | Ready for release operator; no implementation slice or new PR | Verified immutable final module containing M1 | M1 merged | Published module lacks M1 |
| GridCast D1 | Existing downstream child retained for rework | Dependency adoption and initial/Resume production integration | M-release and completed R4 | Downstream capability-hiding wrappers |

M1 is parallel-safe with Wellspring W1. M-release follows the repository's existing release workflow; it is a separately tracked administrative blocker, never dispatched through `$implement-architecture-slice`. Code merge closes M1; release verification alone closes M-release and unlocks D1. This separates code certification from external publication without inventing a second product slice.

## Implementation slices

### M1 — Expose borrowed Datagrams on managed authenticated Wires

**What it delivers:** One additive concrete-type method, real managed-establishment use and preservation evidence, and the corresponding public documentation/API inventory update in one independently green wiremux PR.

**Existing-work disposition:** New upstream slice. Retain the merged Wire/Datagrams implementation unchanged; no unmerged product work is a dependency. GridCast PR #1112 remains in its own repository for D1 rework.

**Blocked by:** None. Publication follows this slice; downstream readiness waits for publication.

**Single owner after merge:** Wire remains the aggregate lifetime owner and Datagrams the existing operation/queue owner; ManagedWire delegates discovery and its existing close paths. Authentication and establishment settlement keep their existing owners.

**Authority completeness:** No persisted fact, authentication authority or new lifecycle transition. Constructor success supplies the existing Wire; discovery borrows its view and existing teardown revokes its use. No restart contract is added.

**Transitional-seam budget:** No duplicate representation, state machine, lifetime or temporary adapter. The additive facade method is permanent shipped API. A merged-but-unreleased interval is coherent because consumers remain on their old pin until M-release; it is removed operationally by that release, not by more runtime code.

**Blast radius:** Public concrete-type method set and its compatibility manifest, facade docs and owner-package tests. Reliable I/O and graceful flush, auth, concurrent cancellation/close and closed-operation classifications must be preserved. No shared/global state, interface requirement, public struct layout, wire schema, transport policy, payload allocation or performance change. No untraced effect is accepted; unexpected additional source changes trigger a scope check.

**Artifact classification:** Forwarding API is shipped behavior. Existing Wire lifetime enforcement remains required safety enforcement. Focused tests and the existing API golden are verification aids; no new maintained verification deliverable or recursively complete harness is approved. Plan, compatibility narrative, issue/task pointers and release receipts are process/traceability metadata.

**Representation contract:** Successfully constructed ManagedWires over current supported direct QUIC and reliable-only relay outcomes; typed public Go API and existing Wire/Datagrams own representation and lifecycle. The finite optional-result forwarding relation is universal by direct delegation; preservation tests are example-level evidence, not exhaustive transport or concurrency proofs. No external grammar is parsed.

**Contract closure:** Not newly triggered for the access method: one delegation introduces no new lifecycle guard or independent transition, and focused public-seam tests cover the material changed behavior. Existing underlying lifetime enforcement retains its accepted contract and tests; do not recursively reopen it. The source defect at ManagedWire and GridCast's initial wrapper have distinct concrete enforcement seams; no repeated-root conclusion is made.

**Evidence budget:** Five semantic cases below, reusing the existing establishment pair. One focused normal run and one focused race run of the new cases, then the repository's existing required gates. No new mutation, fuzz, repetition, timing deadline, platform cross-product, operational benchmark or TURN campaign. One initial independent review plus at most one replacement after accepted fixes. Evidence terminates when the named cases, API delta and existing required gates pass on the reviewed head.

**TDD and preservation evidence:** Write public ManagedWire tests first, calling `EstablishAuthenticated` and never extracting `.wire`: (1) reliable-only absence plus working stream; (2) direct stable repeated handle discovery on both peers, Datagram exchange and reliable exchange on the same pair; (3) cancel one Datagram Receive, then show the plane and reliable stream remain usable; (4) managed abort interrupts a blocked Datagram Receive and rejects subsequent operations with existing closed classification; (5) graceful close preserves reliable flush and revokes Datagram use by completion. Reuse existing managed graceful/abort fixtures and keep assertions/fixture construction on the parent test goroutine. Existing Datagram tests own payload/queue/framing/fault details. The API-manifest delta is exactly the new concrete method, with unchanged CLI/wire inventories.

**Dispatch context budget:** At most 12k input tokens: this M1 slice and decision, relevant managed-establishment/compatibility/publication paragraphs, facade and underlying discovery/lifecycle methods, existing managed pair/tests and API golden instructions. Include the bounded governing diff if the contract advances. Do not load old architecture programs or GridCast's entire draft/history. A single facade and five focused cases fit implementation, review fixes and verification in one fresh context.

**Slice decision audit:** Splitting docs/tests from the method leaves an undocumented/unverified public capability; keep them in the same PR. Publication has different operational authority but adds no independently green code behavior: track it as M-release, not a second implementation slice. Combining M1 with GridCast D1 crosses repository/release boundaries and makes the downstream build depend on unpublished code; reject. No code prerequisite is necessary because the underlying plane and bilateral fixture already exist. M-release is a genuine downstream blocker because the pinned published module lacks the method.

**Stop conditions:** Exposure requires a second handle/owner, changed negotiation/options, raw carrier access, altered underlying Datagram semantics, or widening supported managed transports. A version/release failure keeps the release gate blocked and does not justify a pseudo-version, local replace, or consumer bypass.

## Acceptance criteria

- [x] `ManagedWire.Datagrams` returns the underlying borrowed optional handle through the supported public API; no new lifetime is introduced.
- [x] The five named public-seam cases preserve reliable transport and cancellation/teardown behavior.
- [x] Godoc, managed documentation and compatibility/API inventory agree on exactly the additive method; no mandatory interface or wire-format change.
- [x] M1 completion leaves GridCast D1 blocked on M-release until actual publication verification.

The first and third criteria quantify only over the finite owned forwarding relation and declared API delta. Wire/Datagrams own the semantics, and the five cases plus manifest diff terminate evidence. They do not claim universal network delivery, exhaustive races or new transport support.

## Release gate

Follow `docs/RELEASE.md` and the existing `release.yml` source preparation and publication workflow. Select the next available compatible version from live tags/releases; the live latest release was v0.2.2 at handoff, despite older introductory release text. Do not reuse a published tag or redesign release infrastructure. Any release-source preparation required by the existing workflow belongs in the M1 PR, bounded to this additive release. For v0.2.3 the maintainer explicitly requested direct final publication without an RC. The workflow's opt-in `skip_candidate=true` waives only the candidate requirement; all final-release validation and evidence remain required.

After M1's reviewed merge and journal, the release operator freezes the release source commit containing M1, publishes v0.2.3 directly from that commit without an RC, and verifies immutable Release/tag identity, checksums, compatibility manifests and published source/module contents through the existing workflow. The exported method must be present in the final module. Record final version, source commit and successful workflow/verification receipts in the release-gate issue. An open source PR, source merge, candidate-only release or closed M1 issue does not satisfy this gate. After ambiguous publication, inspect tag/Release state before retry; do not overwrite or republish blindly. This handoff does not dispatch publication.

On release verification, refresh the M parent/program tracker and D1's blocker/readiness mirrors. D1 owns the GridCast dependency pin and production-wrapper evidence. The program index records this conditional frontier; no routine status-only product PR is required.

## Validation and operating discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with wiremux's existing `docs/REVIEW-LOOP.md` overlay. No repository contract-closure overlay is required or created. Observe AGENTS.md's toolchain audit before Go commands, run the five focused cases normally and with race, run `task verify` and the existing change-appropriate `task ci` gates on the exact pushed head, then require successful same-head post-ready `ci-*` jobs and guarded squash merge. Diagnose failures before rerunning. Only after merge append the development journal and update pointer-based tracking. Implementation and release have distinct completion states; M1 merge does not claim publication or downstream readiness.
