# AH-20260924 handoff audit

**Status:** Slice audit passed; docs publication pending

## Source and existing-work census

Reviewed clean default-branch source `a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3`. The six accepted changes and independent relay characterization were self-grilled before this handoff. The temporary HTML was used as input; its complete technical decisions are now split into the current plans and no-code ledger. No implementation or runtime experiment was performed during that review.

Open-PR census found only dependency PRs #1674 and #1484; neither implements an accepted track. No open parent/slice for this program or prior OmniFocus children existed. Retain merged code as current behavior; no historical or unmerged worktree is adopted as a baseline. PR [#1675](https://github.com/GridSwarm/wiremux/pull/1675) is merged and fixed remote-calibration terminal retention; track B does not claim that historical defect remains. Adjacent [#1477](https://github.com/GridSwarm/wiremux/issues/1477) owns v2 terminal/EOF interpretation and [#1480](https://github.com/GridSwarm/wiremux/issues/1480) owns comparison setup error context; their bodies/comments were read and their outcomes are excluded from B1. [#1685](https://github.com/GridSwarm/wiremux/issues/1685) concerns pre-choice native observation, outside D1/E1. Existing older architecture programs are not being rebaselined.

## Proposed slice graph

| Slice | Owner | Proposed blockers | Input-context ceiling |
| --- | --- | --- | --- |
| A1 | Settlement result admission | None | 26000 tokens |
| B1 | Worker reply custody | None | 34000 tokens |
| C1 | Wire-owned migration transitions | None | 30000 tokens |
| D1 | Ordered after-choice classification | None | 18000 tokens |
| E1 | Static selected-option validation | None | 16000 tokens |
| F1 | Retained control-decoding facts | None | 36000 tokens |
| R1 | Relay completion characterization | None | 22000 tokens |

The current plans carry each slice’s strongest split/merge alternatives, domain, single owner, transitional budget and evidence. Root-file overlap is scheduling guidance only. R1 has no repair successor because characterization cannot yet support a repair contract. No unmerged work is a prerequisite.

## Independent audit

Three read-only audit assignments reviewed the draft plans against the pinned source and shared baselines before the first commit. The primary agent independently accepted the final seven one-PR slices and absence of blocking edges.

| Slices | Audit result | Accepted corrections before publication |
| --- | --- | --- |
| A1 / C1 | PASS | Clarified relay-assisted old Wire eligibility versus direct candidate, and that migration cannot preserve an old carrier independently closed by another actor. |
| B1 / R1 | PASS | Scoped opening custody guarantee to versions >=2; preserved v1 and incidental snapshots. Removed implementation/interface-migration template language from evidence-only R1 and made repair constraints prospective. |
| D1 / E1 / F1 | PASS after bounded correction | F1 now includes non-strict phase callers, selected-pair probe peek/raw replay, eight framing-only test helpers and mechanical decoder test consumers. Helpers explicitly discard payloadCause. Closure is not triggered for the ordinary focused codec coverage; its table is a preservation census. Final recheck passed. |

All corrections were `fix-now` documentation scope corrections, not changes to accepted outcomes or evidence budgets. No repeated-root conclusion was made. The F1 revisions addressed one caller-census obligation and one independent closure-trigger obligation; sharing the codec plan does not make those one precise root. No implementation, test execution or model benchmark was performed by the audit agents.

The strongest split/merge alternatives are recorded in each current plan. No two adjacent slices require one another to deliver a coherent independently green result. No persisted-authority migration, temporary dual owner, maintained analyzer or speculative relay repair was introduced. The primary agent confirms that the finite evidence and context bounds are plausible for the current scoped functions/test excerpts; implementers must re-audit any newly overlapping work at preflight.

Domain-model check: existing glossary concepts and public/private type names suffice; no new product-domain term or glossary change is required. Plans reference shared policy directly; no copied or strengthened repository overlay was created. Older programs and their evidence obligations remain untouched.

## Documentation publication contract

- The seven current plans and no-code ledger retain the accepted grilled technical decisions; the program index contains identity, pointers, frontier and scheduling only.
- Each slice names its owner, input domain, guarantee, evidence/context budgets, artifact classes, preservation criteria and approach stops.
- This PR changes documentation only. It does not implement or dispatch any candidate, create runtime fixtures, change public behavior or require implementation results to be green now.
- Local documentation/link/whitespace and diff-secret checks, a fully briefed fresh review with at most one replacement, and same-head successful hosted CI terminate this docs PR. No new parser, evidence harness, native matrix or proof obligation is introduced.
- Child issues and OmniFocus pointers are published only after the accepted docs are reachable on the remote default branch. Their exact default-branch plan commit is administrative provenance, not product code-head certification.

Review run IDs, final-head receipts and merge/publication mappings belong in PR discussion and the live tracker. This audit file does not claim results that have not yet run.
