# Probe Runtime and Deterministic Restricted-NAT Evidence — Implementation Plan

**Date:** 2026-07-29
**Status:** Accepted (grilled 2026-07-29); all four original slices landed; issue-#1006 scheduling amendment accepted 2026-08-08; issue-#1134 active-only success-settlement amendment accepted 2026-08-12
**Track:** 4 of 4 in the 2026-07-29 architecture deepening program
**Depends on:** all original slices and the issue-#1006 scheduling amendment complete
**Related:** current release validation in `docs/CI.md`; the superseded controller plan tombstone at `docs/work-items/issue-772-v0.1.0-release-plan.md`; `docs/research/issue-775-restricted-nat-release-environment.md`; the 2026-07-05 third program's triggered probe-run deepening
**Normative scope:** Deterministic nine-row B2 evidence, its enabling runtime, the issue-#1006 probe-scheduling amendment, and the issue-#1134 active-only success-settlement amendment; kernel smoke, evidence aggregation/schema, and release workflow remain in the release program
**Audit history:** Independent slice audit 2026-07-29 — PASS WITH AMENDMENTS A1–A9; applicable A5–A9 folded into this plan. Scoped slice audit 2026-08-01 split the former direct-evidence slice into one EIM+EIF production-path tracer and one direct-subset completion slice because the combined scheduler, NAT-policy, characterization, and four-row review surface no longer fit one fresh implementation context. Maintainer direction on 2026-08-08 accepted the issue-#1006 bounded repeated-schedule-pass amendment below. The issue-#1134 correction on 2026-08-12 accepted the active-only success-settlement amendment D16.

## Goal

Create one attempt-bound probe runtime that combines packet I/O and time, then use it to make the approved nine-row restricted-NAT matrix deterministic without bypassing production behavior. The probe engine continues to own authentication, encoding, retry/jitter, ranking, selection, RTT, and fallback; the runtime supplies only opaque datagram transport and logical time on the exact packet socket. The matrix proves representative success and safe synchronized fallback through root `wiremux.Dial`, production STUN, authenticated probes, and real QUIC.

## Current Shape (verified 2026-08-08 on `main`)

- Slice 1 landed through #884. `internal/proberuntime` owns the attempt-bound opaque datagram/time contract and exact-socket provider selection; `connect/probe_engine.go` consumes one runtime and derives one logical deadline per attempt; production cancellation/release and stage-handoff contracts are maintained; raw `wakePacketRead` and the bespoke scheduling socket fakes are gone.
- Slices 2–4 landed through #888, #890, and #892. The maintained integration fabric independently models EIM/ADM/APDM mapping and EIF/ADF/APDF filtering, and the exact nine-row table runs through root `wiremux.Dial`, production STUN and authenticated probes, exact sockets, real QUIC for direct rows, and synchronized usable relay fallback for the remaining rows.
- The current release gate retains those nine deterministic rows under `go test ./internal/integration` with no test-level retry/rerun, three-observer self-characterization, bidirectional payload, and the original per-pass three-request retry cadence.
- Issue #1006 exposes the remaining production-scheduler risk addressed by the amendment below: a viable pair can exhaust one short burst while most of the attempt budget remains and is never revisited.

## Decision

- **D1 — one combined runtime seam.** A top-level internal package defines an attempt-bound runtime with semantic operations: current logical time; send one complete opaque datagram; receive an opaque datagram until a logical deadline with timeout distinct from error; and idempotently release probe read ownership, clear deadlines, and join any helper work. The attempt deadline is expressed in the runtime clock domain: reaching it returns the existing non-error probe exhaustion even if a test fabric's wall-clock context has not fired, while explicit caller cancellation still returns the context error. Production maps the runtime clock to wall time.
- **D2 — exact packet socket.** An internal provider capability may be implemented by the exact supplied `net.PacketConn`; the in-repo NAT adapter uses it to return a runtime bound to the same NAT fabric socket and clock. Otherwise production creates a runtime around that exact connection. The connection passed to STUN, transport, and QUIC is never replaced or wrapped.
- **D3 — engine retains protocol intelligence.** Keys/HMAC, codec, candidate identities, probe IDs/randomness, retries/jitter, concurrency, RTT/ranking, fallback reason, and selected-pair binding remain in `connect`. The runtime sees only bytes, addresses, context/deadline, timeout, and time.
- **D4 — production semantics are exact.** The production adapter preserves `net.PacketConn` errors, address identity, short-write detection, and deadline behavior. Cancellation unblocks receive, joins helper work, and releases/clears the read deadline before returning. `wakePacketRead` and competing raw deadline coordination are deleted.
- **D5 — tests use scenarios, not socket impersonations.** Probe scheduling/error scenarios use one scripted runtime. Legitimate codec, candidate-planning, token, ranking, and selection tests remain at their current pure seams.
- **D6 — NAT mapping and filtering are independent.** The deterministic fabric models mapping keys EIM/ADM/APDM separately from inbound permission keys EIF/ADF/APDF. It records network observations only; it never decides authentication, selection, or fallback.
- **D7 — self-characterization precedes every Wire row with a declared NAT profile on isolated state.** Mapping proof uses a fresh NAT/socket to send to three public destinations: two ports on one IP and one port on another IP. Filtering proof uses a different fresh NAT/socket, opens only one baseline destination, then injects from the baseline tuple, same-IP/different-port, and different-IP observers. The Wire run uses a third fresh NAT state so neither proof opens permissions for the measured attempt. Public row 1 instead uses its own fresh fabric/socket state and proves no translation; it performs no artificial NAT characterization.
- **D8 — production path end to end.** Every row uses two isolated private realms where applicable, production relay and STUN behavior, root `wiremux.Dial`, reflexive-only candidates for NAT rows, authenticated probe engine, real QUIC, the exact supplied socket, and bidirectional reliable payload.
- **D9 — exact matrix, representative claim.** The maintained deterministic matrix is exactly the nine approved rows below. It proves those controlled profiles only; it does not claim universal traversal.
- **D10 — stage ownership stays explicit.** The exact socket's read ownership remains sequential: production STUN → probe runtime → bounded raw packet drain → transport/QUIC. Slice 1 deletes only raw probe wake coordination. `drainPacketConn` retains its bounded raw read/deadline role, and tests prove it never overlaps the runtime or transport.

| Row | Declared behavior | Required result |
| --- | --- | --- |
| 1 | Public/host, no translation | Direct |
| 2 | EIM + EIF | Direct |
| 3 | EIM + ADF | Direct |
| 4 | EIM + APDF | Direct |
| 5 | ADM + EIF | Relay with synchronized `probe_failed` |
| 6 | ADM + APDF | Relay with synchronized `probe_failed` |
| 7 | APDM + APDF | Relay with synchronized `probe_failed` |
| 8 | Asymmetric EIM/APDF versus APDM/APDF | Relay with synchronized `probe_failed` |
| 9 | EIM + EIF, then UDP blackhole after successful STUN | Relay with synchronized `probe_failed` |

**Frozen behaviors:**

- Probe wire bytes, authentication/token validation, direction binding, per-pass request retry count/jitter distribution, concurrency, priority selection, RTT semantics, recoverable error classification, fallback reasons, and public API. The number of rank-ordered schedule passes is amended below.
- Timeout remains a non-error probe exhaustion result; caller cancellation and non-timeout I/O errors retain their identities.
- STUN and transport receive the exact supplied packet connection; successful direct rows expose real QUIC, not a simulated stream.
- Fallback rows synchronize `probe_failed`, expose no selected pair/direct transport, and preserve usable relay payload in both directions.

**Rejected alternatives:** separate clock and I/O interfaces; global clock/test hooks; a public Upgrade option; wrapping/replacing the packet socket; teaching the fabric probe authentication or selection; importing a large external NAT lab; treating live-network observations as permanent NAT classification.

**Non-goals:** kernel namespace/veth/nftables rows 4/7; `task nat-smoke-linux`; evidence JSON/schema/aggregation; weekly/release workflow wiring; TURN/UDP relay; peer-reflexive learning or port prediction; every mapping/filter cross-product; IPv6/NAT64/CGNAT/hairpin/expiry; protocol changes.

## Amendment (2026-08-08, issue #1006) — bounded repeated schedule passes

**Status:** Accepted by the maintainer direction recorded on issue #1006 after the instrumented field rerun.

Decisions D11–D15 supersede every earlier statement that freezes or preserves the production within-attempt retry schedule. The three-request count and 20–25 ms jitter distribution remain frozen per schedule pass; complete passes now repeat within the existing attempt deadline. Earlier slice prose remains as a historical record of the behavior and evidence required when those slices landed.

The original plan froze one three-request burst per candidate pair. Deterministic reproduction and the instrumented Comcast-to-cellular field run proved that a peer can answer an authenticated request on an exhausted viable pair while retaining nearly the entire attempt budget, yet still report `probe_failed` because the engine never sends another request. Tunnel candidates delayed the viable pair but were neither necessary nor sufficient for failure, so candidate-policy hygiene is not the primary correction.

- **D11 — keep the existing probe-engine seam.** `probeCandidatePairPlan` and `probePairs` remain the only production interface for candidate-pair probing. The schedule-pass state is private to `connect`; `proberuntime.Runtime` remains the local-substitutable opaque datagram/time adapter used by production and deterministic fabrics. No scheduling policy, pass count, or retry knob becomes public.
- **D12 — repeat complete rank-ordered schedule passes.** One schedule pass admits every eligible candidate pair once in the existing rank order and under the existing concurrency limit. Each admitted pair retains the existing burst of up to three requests and 20–25 ms retry distribution, ending early on authenticated success, write error, cancellation, or deadline. A later pass cannot start until every still-eligible pair has completed the current pass. Completing three sends without success is pass-local exhaustion. A recoverable request- or response-write error permanently retires that pair from later outbound admissions in the attempt, while inbound packet processing, response attempts, and validation of already-generated probe IDs remain active. Passes repeat while the existing attempt deadline has not been reached.
- **D13 — settle success before reactivation.** At pass completion the engine evaluates the existing priority-authoritative ready result before reactivating any higher-ranked pair. Within a pass, a lower-ranked success remains withheld until every higher-ranked pair has completed that pass. A recorded success is never hidden by starting a later pass. This completed-pass rollover guarantee does not change deadline semantics: a lower-ranked success first recorded while a higher-ranked pair remains incomplete is still discarded if the existing attempt deadline arrives before that pass settles.
- **D14 — preserve bounded ownership and traffic.** The existing deadline, concurrency, retry interval, cancellation, and runtime release remain the only lifetime and peak-send-rate bounds. Repeated passes add no goroutine, timer owner, public option, packet socket, or wire message. For each pair, the first request in a later pass cannot precede the `nextSend` time established by its final request in the prior pass, preserving the existing 20–25 ms per-pair spacing across the boundary. Probe IDs remain attempt-bound so a valid late response can still establish RTT and success. If every pair is permanently retired by recoverable send errors, the engine remains receive-capable until the existing deadline and preserves synchronized fallback behavior.
- **D15 — preserve protocol authority.** Candidate-pair success still requires an authenticated response matching a locally generated probe ID; an inbound request is never promoted to proof. Ranking, selected-pair synchronization, RTT semantics, coarse fallback reasons, exact-socket stage ownership, and transport handoff remain unchanged.

**Consequences:** Small candidate sets may send for more of the configured attempt budget instead of becoming silent after one pass, but peak request rate remains bounded by the already-approved concurrency and 20–25 ms per-pair cadence. Complete-pass ordering prevents repeats from overtaking a pair that has not yet received its first burst. This amendment fixes the single-burst punch-window miss demonstrated by #1009 and the field rerun; it does not solve candidate pairs that the first pass never reaches before the deadline, changed observed source ports, peer-reflexive learning, port prediction, or a declared UDP blackhole.

**Rejected alternatives:** A one-shot authenticated-inbound-triggered confirmation was rejected because UDP can reorder or drop it behind the ordinary response, after which the successful peer may release its probe runtime before answering confirmation. Independently paced revisits were rejected because they add a second timing policy and can leave the same peer-lifetime gap. Default tunnel/CGNAT exclusion was rejected as the primary fix because the field failure reproduced with both tunnels down and exclusion would regress symmetric-tailnet reachability.

**Required re-certification:** The implementation must first turn the #1009 skew and late-punch characterizations into failing desired-outcome tests at the real probe-engine seam, add a deterministic run-4-shaped delayed-permission scenario, prove pass ordering/priority/error/deadline bounds, and then pass the exact nine-row restricted-NAT matrix without changing its expected direct or synchronized-relay outcomes. A patched consumer build must complete the four-cell field matrix, including both role directions, before the temporary instrumentation branch is retired. The agent-ready execution brief is [`docs/work-items/issue-1006-bounded-probe-rerace.md`](../work-items/issue-1006-bounded-probe-rerace.md).

## Amendment (2026-08-12, issue #1134) — active-only success settlement

**Status:** Accepted by the issue #1134 correction and its deterministic production-seam regression.

Decision D16 supersedes D13's statement that every higher-ranked pair must complete the pass before a lower-ranked success settles. D13 remains above as the historical rule established by issue #1006.

- **D16 — only active higher-ranked work delays settlement.** After any candidate pair records authenticated success, the scheduler freezes new admissions. A lower-ranked recorded success remains withheld only while an already-active, non-exhausted higher-ranked attempt finishes its current burst. An inactive higher-ranked attempt that was not admitted in the current pass cannot resume after the admission freeze and therefore cannot delay selection. Authentication, priority among recorded successes, existing deadline semantics, and synchronized fallback when no viable path succeeds remain unchanged.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | landed via #884 | Probe runtime, production adapter, cancellation/read release, probe test migration | None | Raw `wakePacketRead` and eight bespoke packet-connection fakes |
| 2 | landed via #888; child #832 closed | Cooperative scheduler, EIM+EIF fabric/provider, isolated self-characterization, root-Dial row 2 | Slice 1 | Production-only runtime selection; bounded legacy single-profile preservation tests remain |
| 3 | landed via #890; child #887 closed | Direct-subset completion: public row 1 plus EIM+ADF/APDF rows 3-4 | Slice 2 | Single-profile direct evidence and incomplete filtering-policy representation |
| 4 | landed via #892; child #833 closed | Fallback rows 5-9 and complete deterministic matrix contract | Slice 3 | Partial direct-only evidence matrix |

**Rebaseline identity and dispatch outcome:** The reconciled graph `#832 → #887 → #833` landed sequentially through #888, #890, and #892. The original dispatch freeze is discharged; all four slices and the exact nine-row deterministic matrix are complete.

## Implementation Slices

### Slice 1 — Attempt-bound probe runtime and production adapter

**What it delivers:** The internal runtime/provider contract, production `net.PacketConn` adapter, one runtime per probe attempt, cancellation-safe receive release/join, deletion of `wakePacketRead`, scenario-based migration of scheduling/error tests away from eight packet-connection fake types and the terminal-fallback `wakeableProbePacketConn`, and a historical-program update recording that the deferred trigger has landed.

**Existing-work disposition:** landed through #884 as the triggered implementation of the explicitly deferred probe-run candidate from the 2026-07-05 third program. Pure probe tests and observable behavior were preserved, the peer-terminal-fallback cancellation case moved with the runtime scenarios, and the third-program index records the trigger as landed.

**Blocked by:** none — complete via #884.

**Single owner after merge:** one runtime owns probe-time reads, writes, logical deadlines, and cleanup for one attempt. The probe engine alone owns protocol/auth/scheduling decisions. The exact `net.PacketConn` remains the shared physical socket later handed to transport, but probe read ownership is released and joined before that handoff.

**Authority completeness:** runtime lifecycle: create from exact connection at probe-attempt start; receive/send/Now mutations during the attempt; cancellation or completion calls idempotent release; release clears deadlines and joins helpers before return; bounded drain starts only after release and transport starts only after drain; no serialization/cache/recovery; object becomes unreachable after probe completion. Engine facts never enter the runtime.

**Transitional-seam budget:** production adapter and scripted verification adapter are the only implementations in this slice. The optional provider path exists but has no production test-fabric provider until slice 2, which owns that addition. Raw probe wake/deadline coordination is gone; the existing bounded `drainPacketConn` raw stage remains deliberately between released runtime and transport and is not a competing owner.

**Blast radius:** internal runtime package, `connect` probe engine/race wiring/tests. Concurrency and leak risk are material; race gates and deterministic cancellation tests are required. Performance must avoid per-datagram goroutines; one attempt helper is acceptable if joined. Security boundary improves because the runtime cannot inspect keys or decoded protocol. No public/wire change.

**Artifact classification:** runtime/production adapter = shipped interior; scripted runtime and scenario tests = maintained verification aid; deleted fakes = retired test scaffolding; third-program update = durable architecture history.

**Representation contract:** runtime domain = opaque datagram `(bytes,address)` plus logical time, an attempt deadline in that same clock domain, and outcomes `{packet, timeout, error, canceled}`. Owner = internal runtime. Universal guarantee over runtime calls: full send or short-write error; reaching the logical attempt deadline yields timeout/non-error exhaustion; explicit context cancellation yields the context error; receive never conflates timeout with I/O error; release is idempotent and leaves no reader/helper/deadline ownership. It cannot create candidate, auth, fallback, or selection facts.

**Contract closure:** triggered by authenticated network behavior and multiple cancellation/error paths. Semantic classes: matching response with production retry and ID validation; delayed response before deadline; higher-priority pair wins over earlier lower-priority response; recoverable request-write error exhausts only that pair; fatal request write; request short write; fatal response write; response short write; fatal non-timeout read; `SetReadDeadline` failure in the production adapter; timeout/exhaustion; caller cancellation while blocked, including peer terminal fallback; normal completion/release clears read ownership and deadline before drain/transport. Enforcement = runtime contract plus engine and explicit stage handoff. Terminating evidence = one scripted-runtime or production-adapter scenario per class, helper-leak/deadline-clear assertions, and a no-overlap stage-order sentinel.

**Evidence budget:** thirteen runtime/engine/production-adapter classes above; existing pure codec/ranking/candidate tests; the migrated peer-fallback cancellation sentinel; one goroutine/read-release/stage-order sentinel; focused race gate; standard suite; one review plus at most one replacement review. No wall-clock sleeps beyond bounded production-adapter deadline/unblock sentinels; scripted tests use logical time.

**TDD and preservation evidence:** introduce the scripted runtime and production-adapter scenarios first against the new contract, wire production second, then delete fake socket types only after a one-to-one scenario map covers both `connect/probe_engine_test.go` and the terminal-fallback wakeable fake/test. Golden probe vectors and pure tests remain untouched.

**Dispatch context budget:** this plan slice; `connect/probe_engine.go`; `connect/probe_engine_test.go`; `connect/upgrade.go:350-389,715+`; `connect/upgrade_terminal_fallback_test.go`; bounded drain code/tests; probe codec/types; relevant context/error tests; `docs/adr/2026-07-05-third-deepening-program.md`. Estimated diff: 300-500 production lines and net test reduction plus one historical-doc correction. One fresh context.

**Slice decision audit:** strongest split — interface then adapter/test migration; rejected because an unused interface is horizontal and would retain raw wake ownership. Strongest merge — include NAT fabric; rejected because runtime cancellation and generalized mapping/filter behavior are separate review risks. No incoming blockers.

**Stop conditions:** stop if the seam needs keys/decoded probes/candidate identity, if exact packet-connection identity must change, if cancellation cannot join and release before return, if production errors/deadlines change, or if a second read owner remains.

### Slice 2 — Cooperative NAT scheduler and EIM+EIF production tracer

**What it delivers:** A deterministic EIM+EIF NAT fabric, shared logical clock and probe-runtime provider on the exact socket, three-observer mapping and filtering self-characterization on isolated state, and approved matrix row 2 end to end through root `wiremux.Dial`, production STUN and authenticated probes, and real QUIC.

**Existing-work disposition:** rebaseline the former four-row direct slice into one hard-mechanism tracer and one policy/table completion slice. Generalize the underlying `endpointIndependentNATHarness` primitives into the new fabric, but retain its existing single-profile tests and the connect-level reflexive QUIC test as a bounded, non-normative preservation seam through this slice. Map every assertion already covered by row 2 without claiming final retirement; Slice 3 owns the final checklist-backed deletion after rows 1, 3, and 4 close the remaining direct classes. Slice 1's landed runtime/provider contract is the implementation baseline; no unmerged implementation exists for this slice.

**Blocked by:** slice 1, complete via #884 — frontier.

**Single owner after merge:** the NAT fabric owns only EIM mapping, EIF permissions, network observations, and logical delivery time. The cooperative scheduler is the sole probe-time advance owner. Production STUN owns reflexive discovery; the probe engine owns authenticated reachability/selection; root Dial and QUIC own establishment. No fabric method declares a wiremux result.

**Authority completeness:** the row creates separate fresh mapping-characterization, filtering-characterization, and Wire-run fabrics/socket state. Mapping and permission tables are created, mutated, observed, and removed solely by the fabric; observations are append-only evidence. Both peer probe runtimes register before logical time advances; runnable work executes without time movement; only when no participant is runnable may the scheduler advance to the earliest registered delivery, receive deadline, or attempt deadline. Logical attempt expiry yields non-error exhaustion; explicit cancellation wakes and deregisters its waiter and returns the context error. One integration sentinel proves exact-socket stage order `production STUN → logical probe runtime → released runtime → bounded wall-clock drain → real QUIC`, no overlapping read owner, and no scheduler control outside probing. No cross-run cache or recovery exists.

**Transitional-seam budget:** the maintained table contains only row 2 and must be named as an EIM+EIF tracer, not the direct subset or completed B2 matrix. Slice 3 extends the same fabric/table with public, ADF, and APDF direct classes and removes this single-profile limitation. Existing harness/reflexive tests may remain only as frozen preservation scaffolding: they are not release evidence, gain no new cases, and cannot own scheduler or NAT outcome authority. Slice 3 owns their final assertion map and deletion.

**Blast radius:** `internal/integration` NAT helpers/tests and the in-repo implementation of the already-landed internal runtime provider. Scheduler liveness, hybrid logical/wall-clock stage handoff, and QUIC integration are material. No production behavior or public/wire surface changes are allowed. Test cost is one finite Wire execution plus bounded characterization and scheduler contracts; no test-level retry is permitted, while the frozen production within-attempt probe retries remain active. The fabric cannot inspect or bypass authentication. No untraced effect is accepted.

**Artifact classification:** in-repo runtime-provider support = maintained verification adapter over shipped internal capability; deterministic EIM+EIF fabric/scheduler = maintained verification infrastructure and approved release-gate aid; row 2 = maintained release-evidence test; retained legacy single-profile tests = temporary preservation scaffolding owned for retirement by slice 3.

**Representation contract:** domain = modeled IPv4 EIM outbound mapping, EIF inbound permission, explicit address/port tuple keys, append-only observations, and a cooperative logical-time event queue shared by exactly the two probe runtimes in one Wire attempt. Owner = fabric/scheduler. Guarantee = universal only for the declared EIM+EIF profile: three outbound observers prove one stable mapping on fresh state; baseline, same-IP/different-port, and different-IP inbound observers prove EIF on independently fresh state; a third fresh state proves the production Wire path. Both runtimes rendezvous before advance; time never advances while work is runnable; expiry and cancellation retain the runtime contract. This slice makes no ADF, APDF, ADM, APDM, public-host, or wall-clock-stage simulation claim.

**Contract closure:** triggered because the scheduler controls authenticated release-gate evidence. Semantic classes are EIM stability across the three outbound observer tuples; EIF admission from the baseline, same-IP/different-port, and different-IP observer tuples after only the baseline outbound opening; two-participant rendezvous before advance; queued delivery before receive deadline; receive/attempt deadline expiry as timeout/non-error; explicit cancellation as context error with waiter deregistration; exact-socket stage order from wall-clock STUN through logical probing/release and wall-clock drain into real QUIC with no overlap; and row 2 direct success through the full production path. Enforcement = fabric-owned tables/event queue plus the existing opaque runtime and production protocol owners. Terminating evidence = one finite characterization set, focused scheduler contract cases for the four timing/cancellation classes, one stage-order/no-overlap sentinel, and one root-Dial execution with no test-level retry.

**Evidence budget:** exactly one mapping proof, one independently fresh filtering proof, four scheduler semantic cases, one exact-socket `STUN → runtime → release → drain → QUIC` stage-order/no-overlap sentinel, and one fresh Wire execution for row 2. The Wire assertions cover scheduler rendezvous/advance, exact socket identity through STUN/probes/QUIC, selected pair on both roles, positive RTT, direct metadata, relay retirement after confirmation, bidirectional QUIC payload, and accounted drops. Existing standard/race gates; one review plus at most one replacement review.

**TDD and preservation evidence:** write the scheduler timing/cancellation and stage-order contracts plus EIM/EIF characterization first, then root-Dial row 2. Record which legacy assertions row 2 covers, but retain the frozen legacy tests for Slice 3's final checklist and retirement. Production probe retry tests and slice 1 runtime contracts remain unchanged.

**Dispatch context budget:** this slice only; `internal/proberuntime/runtime.go`; current NAT harness/helper and reflexive QUIC test; root integration Dial helpers; production STUN/relay helpers; exact-socket recording transport; release-plan row 2 and the NAT research limits. Estimated diff: 400-650 integration lines with deletion. One fresh context.

**Slice decision audit:** strongest further split — scheduler/provider first, NAT/Wire row later; rejected because it would merge an unvalidated simulator without a production consumer and leave the old harness authoritative. Strongest merge — include public/ADF/APDF rows; rejected because scheduler correctness, NAT semantics, isolated characterization, and four end-to-end executions exceed one review/context budget. Slice 1 is a genuine blocker because the exact socket must supply shared logical probe time without wrapping STUN or QUIC.

**Stop conditions:** stop if the scheduler cannot be proven independently and consumed by row 2 in the same PR, if mapping and filtering proofs share state, if either proof contaminates the Wire run, if time advances before both runtimes participate or while work is runnable, if the exact-socket stage-order/no-overlap sentinel cannot prove scheduler release before drain and wall-clock ownership outside probing, if a substituted socket or simulated transport appears, if fabric code authenticates/decodes/selects, if a useful legacy assertion neither maps to row 2 nor remains safely bounded for Slice 3 retirement, if test-level rerun is needed, or if production code must change beyond consuming the already-landed provider contract.

### Slice 3 — Direct filtering completion for rows 1, 3, and 4

**What it delivers:** Public/host row 1 plus EIM+ADF and EIM+APDF rows 3-4 through the same root-Dial/real-QUIC table, independent filtering-policy extensions and self-characterization, explicit full-isolation assertions, fresh state for every proof and Wire run, the complete four-row direct subset, and final checklist-backed retirement of the legacy single-profile harness/reflexive tests.

**Existing-work disposition:** extend the landed slice 2 fabric/table rather than creating another harness, scheduler, or row runner. Retain row 2 unchanged. Add only the public path and ADF/APDF permission semantics required by rows 1, 3, and 4; do not reopen scheduler ownership or the runtime/provider contract. Complete the assertion map for the frozen legacy tests, then delete those tests and any compatibility-only names/helpers in the same PR.

**Blocked by:** slice 2.

**Single owner after merge:** the existing fabric remains the sole owner of modeled mapping/filter tables, observations, and logical delivery time; the existing scheduler remains the sole probe-time advance owner. Production STUN, authenticated probes, root Dial, and QUIC retain their authorities. The table owns direct-subset evidence, never outcomes.

**Authority completeness:** each NAT row independently repeats mapping characterization, filtering characterization, and the Wire run on three mutually isolated states. ADF permissions key by source address and APDF permissions key by source address+port; only the fabric constructs and consults those keys. Public row 1 bypasses NAT translation but uses its own fresh fabric/socket state with the same production relay, root Dial, authenticated probes, exact sockets, real QUIC, and payload assertions. No mapping, permission, observation, clock, delivery, or socket state survives a proof or row.

**Transitional-seam budget:** rows 1-4 form the named direct subset, not the completed B2 matrix. Slice 4 extends this same table with rows 5-9 and performs the final matrix rename. This slice consumes the bounded legacy preservation seam: its checklist maps or deliberately retires every remaining assertion, then deletes the legacy single-profile tests and compatibility-only helpers. No single-profile, alternate scheduler, legacy harness, or duplicate direct table remains.

**Blast radius:** integration fabric policies, characterization tables, and the direct row table only. Scheduler behavior is preservation scope, not an implementation target. Three finite Wire executions add CI cost but no test-level retry. No production/public/wire change is allowed; any such need is a stop. Security remains production-owned because the fabric records opaque traffic only. No untraced effect is accepted.

**Artifact classification:** ADF/APDF policy support and characterization = maintained verification infrastructure; rows 1, 3, and 4 plus retained row 2 = maintained release-evidence direct subset; deleted legacy harness/reflexive tests and compatibility-only helpers = retired test scaffolding after checklist mapping; the partial table is an approved maintained aid removed as partial authority by slice 4.

**Representation contract:** domain = public IPv4 host behavior plus EIM mapping combined independently with `{EIF, ADF, APDF}` filtering, explicit tuple keys, the unchanged cooperative scheduler, and rows 1-4 of D9. Owner = fabric/scheduler and direct-subset table. Guarantee = universal only over those four controlled declarations: every NAT row proves its mapping and filtering on isolated state before a third-state Wire execution; public row proves no translation; all four use the production path and exact socket. It does not claim ADM/APDM, fallback, or universal NAT behavior.

**Contract closure:** direct semantic classes are public/no translation, EIM+ADF, and EIM+APDF, with retained EIM+EIF as preservation. ADF admits baseline and same-IP/different-port but rejects different-IP; APDF admits only the baseline tuple. Each NAT row separately proves EIM mapping, its filter class, and direct Wire success. The isolation class proves pairwise-distinct mapping/filter/Wire state for every NAT row, fresh fabric/socket state for public row 1, and no mapping, permission, observation, clock, delivery, or socket carry-over between rows. Terminating evidence = one root-Dial execution for each of the three new rows, the retained row 2 gate, one table-driven full-isolation sentinel covering all four rows, and the legacy assertion/deletion checklist, with no test-level retry.

**Evidence budget:** exactly three new Wire executions, two new independently fresh filter proofs using the three observer tuples, a fresh EIM mapping proof for each new NAT row, one table-driven full-isolation sentinel covering rows 1-4, one bounded legacy assertion/deletion checklist, and retained row 2/scheduler contracts. Every direct row asserts exact socket, selected pair on both roles, positive RTT, direct metadata, relay retirement, bidirectional QUIC payload, and accounted fabric drops. Existing standard/race gates; one review plus at most one replacement review.

**TDD and preservation evidence:** add ADF characterization red/green, then row 3; add APDF characterization red/green, then row 4; add public row 1 through the shared runner; add the full-isolation sentinel; finish by running row 2 and scheduler contracts unchanged, completing the legacy assertion map, and deleting the legacy tests/helpers. Do not modify production expectations to make a fabric row pass.

**Dispatch context budget:** this slice only; completed slice 2 fabric/table and its profile-neutral row-runner seams; release-plan rows 1, 3, and 4; NAT filtering research limits; existing direct-result/payload assertions; the bounded legacy assertion map and retirement targets. Estimated diff: 250-450 integration lines with deletion. One fresh context.

**Slice decision audit:** strongest further split — one PR per filter class; rejected because each is a small extension of the same permission-key table and row runner, and none changes scheduler ownership. Strongest merge — fold back into slice 2; rejected because the scheduler/provider tracer already consumes the hard-mechanism context and review budget. Slice 2 is a genuine blocker because these rows extend its sole fabric/scheduler/table rather than creating another authority.

**Stop conditions:** stop if a second scheduler/table is needed, if ADF/APDF cannot be represented as independent permission keys, if any characterization shares state with another proof or Wire run, if public row 1 reuses another row's fabric/socket state or performs artificial NAT characterization, if any legacy assertion cannot be mapped or deliberately retired within the bounded checklist, if scheduler/runtime/production behavior must change, if a row uses a substituted socket or simulated transport, or if any row needs a test-level rerun.

### Slice 4 — Synchronized fallback rows 5-9 and complete the matrix

**What it delivers:** ADM+EIF, ADM+APDF, APDM+APDF, asymmetric EIM/APDF vs APDM/APDF, and post-STUN UDP-blackhole rows; synchronized `probe_failed` and usable relay assertions; the final exact nine-row deterministic B2 test table.

**Existing-work disposition:** completes the partial matrix from slice 3. Reuse the same fabric/table and production path; no separate fallback harness or test-only fallback decision is added. During the required post-merge mirror reconciliation, existing child #833 retains this stable fallback identity, moves from old Slice 3 to new Slice 4, and is reblocked on the new direct-subset completion child.

**Blocked by:** slice 3.

**Single owner after merge:** one nine-row integration table owns deterministic B2 semantic evidence. Fabric still owns observations only; wiremux production code owns outcome and synchronization.

**Authority completeness:** adds ADM/APDM mapping state, asymmetric peer profiles, and an EIM+EIF post-STUN blackhole network action to the same row representation. Every declared row independently characterizes mapping and filtering on separate fresh state, executes on third fresh state, records observations, and terminates with asserted wire/payload outcome. No duplicate EIM/fallback table remains.

**Transitional-seam budget:** none. The direct-subset test becomes the complete named matrix; no partial, legacy, or alternate NAT evidence authority remains.

**Blast radius:** integration fabric/table/tests only unless a production defect is exposed. Five bounded rows add CI time but no test-level retry; the normal within-attempt probe retries remain active. Failure synchronization is protocol-sensitive; existing terminal-fallback behavior must remain. No shipped API/wire behavior is intentionally changed, and no untraced effect is accepted.

**Artifact classification:** rows 5-9 and completed table = maintained verification infrastructure and approved release-gate aid. Any discovered production fix is outside this slice and triggers stop/replanning rather than being smuggled into the evidence PR.

**Representation contract:** exact nine-row closed table in D9. Owner = integration matrix. Guarantee = universal only over those nine controlled row declarations; each NAT declaration is proven, not trusted by name. Retirement condition: only when the v0.1.0 release contract is explicitly replaced by equivalent-or-stronger maintained evidence.

**Contract closure:** triggered by release go/no-go consequence and five independently reachable fallback paths. Classes and required results: ADM+EIF, ADM+APDF, APDM+APDF, asymmetric hard peer, EIM+EIF blackhole after successful STUN → both Wires relay, same `probe_failed`, no selected pair/direct transport, bounded production probe exhaustion, deadlines/read ownership released, bidirectional relay payload. Mapping/filter mismatch and dropped packets are observed evidence, never injected result decisions. Terminating evidence = exactly one execution per row after independent characterization, with no test-level retry.

**Evidence budget:** five fallback rows plus the four retained direct rows; three observers per applicable profile; assertions named above; zero unexplained overflow/unrouted drops except declared filter/blackhole observations; standard integration/race/full gates; one review plus at most one replacement review.

**TDD and preservation evidence:** add rows one at a time with expected red where the fabric lacks a policy; implement only fabric semantics needed for the declared row. Treat any production behavior red as a stop condition, not a test expectation change.

**Dispatch context budget:** this plan slice; completed slice 3 fabric/table; terminal fallback and probe-failure public contracts; release B2 table; NAT research evidence/limits. Estimated diff: 350-600 integration test lines. One fresh context.

**Slice decision audit:** strongest split — mapping-dependent rows, asymmetric row, blackhole row; rejected because all are small additions to one table and splitting would leave partial release evidence. Strongest merge — include kernel smoke/JSON/workflows; rejected because this architecture track is the deterministic sub-contract only and those artifacts have different owners/platforms. Slice 3 is a genuine blocker because this is a table completion, not an independent harness.

**Stop conditions:** stop if any failure row selects direct unexpectedly, reports asymmetric reasons, cannot preserve relay payload, needs a test-level rerun beyond the frozen within-attempt probe retries, or reveals a production defect; file/replan the defect separately. Stop if completing the row requires peer-reflexive learning, port prediction, a protocol change, or fabric-owned outcome decisions.

## Acceptance Criteria

- [ ] One attempt-bound runtime owns probe I/O/time and releases reads/deadlines/helpers before return; `wakePacketRead` and bespoke packet-connection scheduler fakes are gone.
- [ ] Probe engine retains all authentication, codec, retry/jitter, ranking, RTT, selection, and fallback authority; public/wire behavior is unchanged.
- [ ] Mapping and filtering are independent, and every declared NAT profile self-characterizes mapping and filtering with three observers on mutually isolated state that is also separate from the Wire run.
- [ ] The fabric scheduler is the sole probe logical-time owner, rendezvous both peers before advancing, advances only to the earliest event/receive/attempt deadline when no work is runnable, returns non-error exhaustion at logical attempt expiry, and returns the context error on explicit cancellation; STUN/drain/QUIC retain wall-clock socket semantics.
- [ ] Exactly nine deterministic rows run once without test-level retry through root Dial, production STUN/probes/fallback, real QUIC where direct, exact socket, and bidirectional payload; production within-attempt probe retries remain unchanged.
- [ ] Direct rows prove selected-pair/RTT/socket/QUIC invariants; fallback rows prove synchronized `probe_failed`, no direct exposure, released probe ownership, and usable relay.
- [ ] The plan makes no kernel-smoke, JSON evidence, or universal NAT claim.

## Validation Gates

```bash
GOTOOLCHAIN=local go test ./connect/... ./internal/integration -count=1
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestProbe|TestNegotiatorUpgrade)' -count=1 ./connect
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(Test.*NAT|Test.*Reflexive|Test.*QUIC)' -count=1 ./internal/integration
task verify
```

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice` for every slice/PR, composed with the repository-specific `docs/REVIEW-LOOP.md` overlay; this repository has no separate contract-closure overlay. Merge and journal slices in order. This track satisfies only the deterministic portion of release-plan B2; its completion must update the release tracker but must not close kernel-smoke, aggregation/schema, or workflow obligations.
