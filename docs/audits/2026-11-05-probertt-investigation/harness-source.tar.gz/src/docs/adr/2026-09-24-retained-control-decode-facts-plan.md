# Retained control-decoding facts Implementation Plan

**Date:** 2026-09-24
**Status:** Complete
**Track:** F of seven in program AH-20260924
**Depends on:** Nothing — independent frontier
**Program:** [2026-09-24-architecture-deepening-program.md](2026-09-24-architecture-deepening-program.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers and stop conditions
**Audit history:** [2026-09-24-architecture-handoff-audit.md](2026-09-24-architecture-handoff-audit.md)
**Parent issue:** pending

## Goal

Retained control-decoding facts: deepen the existing module at its private interface, concentrating the caller knowledge identified below. The scope is one independently green PR, not a framework or public-interface redesign.

## Current Shape (verified 2026-09-24)

[connect/control_codec.go:473](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/control_codec.go#L473) · [connect/control_codec.go:999](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/control_codec.go#L999) · [connect/upgrade_protocol_engine.go:122](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/upgrade_protocol_engine.go#L122) · [connect/upgrade_strict.go:158](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/upgrade_strict.go#L158) · [connect/upgrade_protocol_engine_listener.go:764](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/upgrade_protocol_engine_listener.go#L764)

**Governing source surface:** control_codec.go typed decoding functions; strictControlCause callers in upgrade.go, upgrade_protocol_classify.go, upgrade_protocol_engine.go, upgrade_protocol_engine_listener.go and upgrade_strict.go; focused codec/strict tests, probe selected-pair peek and direct decoder test/helper callers listed below. No transition-table, direct/TURN or source-policy redesign.

## Decision

### What does the result look like?

Keep the existing Offer, selected-pair, control-phase and fallback domain shapes. Return `(existingResult, payloadCause error)`, with cause either nil or the exact private malformed-control sentinel. The fact means expected message or a valid phase-permitted fallback. No tagged union or new generic codec module.

### Does malformed input get an empty result?

Not when that would change legacy behavior. Preserve existing HasFallback, WireFallback and coarse ProtocolMismatch fields on malformed fallback-looking payloads while also returning the malformed cause. A valid peer protocol_mismatch fallback has nil payload cause. Known-but-phase-forbidden and unknown reasons remain malformed for strict interpretation.

### How many decodes can actually be removed?

There are six syntactic strictControlCause call sites, but their runtime paths differ. Reuse validity where semantic decode already occurred. The listener accept-first branch has not decoded the payload: it still validates fallback once after joining Accept at the current point. Valid postcommit expected frames already decode once. Do not mechanically delete every validation call.

### Who classifies the resulting failure?

The existing phase/attempt owner. Valid postcommit fallback remains transport/not-converged; malformed payload remains protocol failure. Framing errors and exact-attempt provenance stay with the sequencer and attempt resources. The codec never acquires context-cancellation or transport-source authority.

### What should remain explicitly separate?

Selected-pair policy validation, reason-phase allowlists, framing limits, extension placement, TURN profile rules, source tokens, and first-cause retention before cleanup cancellation. A decoder’s validity fact is not proof of connection eligibility or successful negotiation.

### Complete caller migration

The six strictControlCause uses are not the complete signature-change census. Include the underlying phase/fallback consumers in upgrade_protocol_classify.go:124,164,169 and the postcommit decode in upgrade_protocol_engine.go:419; retain their existing phase authority. Include the selected-pair peek in [upgrade.go:497](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/upgrade.go#L497): it inspects the legacy domain result, joins the probe, and unreads the same raw frame for later phase validation. Do not consume or reclassify that frame early using the new validity fact. Include the eight framed read helpers in [upgrade_control_helpers_test.go:50](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/upgrade_control_helpers_test.go#L50); they historically return framing errors and legacy decoded results, so explicitly discard payloadCause there rather than forwarding it as a new helper error. Mechanically adapt direct decoder assertions in control_codec_test.go, datagram_capability_test.go, upgrade_protocol_engine_test.go, upgrade_protocol_listener_test.go, upgrade_handoff_test.go, upgrade_protocol_test.go, selected_pair_test.go, upgrade_terminal_fallback_test.go and turn_retry_capability_test.go. Preserve their asserted legacy result behavior. Census references to the four changed decoder symbols before editing and again before deletion; no new public compatibility wrapper or parallel legacy decoder is needed.

### Settled decisions and non-goals

The [no-code decisions](2026-09-24-architecture-no-code-decisions.md) close adjacent directions; they are not successor slices. Preserve the existing [ADR-0010 auth-release](adr-0010-auth-context-lifecycle-ownership.md), [ADR-0011 transport disposal](adr-0011-transport-stream-disposal-capability.md), [settlement D7](2026-07-29-establishment-settlement-plan.md), [selected-I/O ownership](2026-09-22-selected-io-plan.md) and [managed-migration contract](../MANAGED-MIGRATION.md) where touched. Broader deferred upgrade directions remain governed by the [August 26 program](2026-08-26-architecture-deepening-program.md). No new domain terms are introduced: this uses the existing Wire, MigrationSession, establishment settlement, ordered choice and reply concepts. Do not expand the scope to improve neighboring behavior, uniformize intentional error projections, or create new public interfaces. Keep current successful behavior except the explicitly accepted version>=2 custody retention improvement in track B.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| F1 | Complete | Retained control-decoding facts | None | None introduced; completes its own interface migration |

## Implementation Slices

### Slice F1 — retained-control-decode-facts

**What it delivers:** Retained control-decoding facts through the real owner and relevant callers, with the acceptance criteria below; one intended PR.

**Existing-work disposition:** New slice. No open implementation PR for this contract was found. Retain existing merged behavior; no unmerged branch is an established dependency. [Audit history](2026-09-24-architecture-handoff-audit.md) records the checked open work and adjacent issues. Recheck related PRs at execution preflight; audit any new overlapping work rather than adopting it silently.

**Blocked by:** None. Recommended sequencing is not a blocking edge.

**Single owner after merge:** Existing typed control decoders own semantic payload validity. Existing phase/attempt owners retain strict-versus-legacy consequence, framing, source-token and first-cause authority.

**Authority completeness:** No newly authoritative persisted fact or schema. Existing constructors, validation and affected destructive consumers are within the scoped source surface; restart round-trip is not applicable. If implementation adds persisted authority or a new constructor family, stop and re-audit before proceeding.

**Transitional-seam budget:** None introduced. Migrate the listed callers in this PR and remove obsolete caller-owned recipes. Existing representations with distinct authority remain intentional, not temporary duplicate owners. There is no unmerged removal slice or widened seam.

**Blast radius:** control_codec.go typed decoding functions; strictControlCause callers in upgrade.go, upgrade_protocol_classify.go, upgrade_protocol_engine.go, upgrade_protocol_engine_listener.go and upgrade_strict.go; focused codec/strict tests, probe selected-pair peek and direct decoder test/helper callers listed below. No transition-table, direct/TURN or source-policy redesign. Trace touched shared state and ordering through the named owner and preservation tests. Public APIs, wire/JSON schemas, dependencies, native routing, security/auth authority and performance guarantees remain unchanged. No benchmark or optimization claim. No intended runtime behavior change. No known untraced effect is accepted; discovering one requires scoped re-audit or an approach stop.

**Artifact classification:** Runtime changes are shipped behavior; lifecycle/validity guards are required safety enforcement. Focused tests and existing test adapters are verification aids, not separately approved maintained verification products. This plan, review receipts, issues and task mirrors are process/traceability metadata. No new analyzer, harness, CI lane or maintained-aid exception.

**Representation contract:** Existing bounded upgrade-control payloads and authoritative current codec schemas/reason-phase validators. Existing CBOR decoding owns representation; supported typed Offer, selected pair, phase and fallback results retain their schemas. Canonical-subset semantic guarantee under current codec admission, with example-level malformed-payload regression coverage; no universal CBOR conformance or single-scan claim.

**Contract closure:** Not triggered. Failure classification is material, but the existing typed codec validators own representation and the bounded behavior can be covered with ordinary focused codec/caller tests; six call sites alone do not meet the shared multi-path trigger. The following is a finite preservation census, not a proof or a broadened closure obligation. No repeated-root conclusion is asserted; any later recurrence must pass the shared precise invariant/central-owner comparison.

| Semantic class | Disposition | Enforcement owner | Budgeted evidence | Status |
| --- | --- | --- | --- | --- |
| Expected typed message | Return legacy domain result and nil payload cause | typed codec | One valid case for each of four shapes | Covered by the named codec and strict-preservation tests |
| Malformed fallback-looking payload | Retain legacy HasFallback/WireFallback/coarse reason plus malformed cause | typed codec | Malformed fallback case | Covered by the named codec and strict-preservation tests |
| Valid protocol_mismatch peer fallback | Nil payload cause; existing phase consequences | typed codec + existing phase classifier | Legitimate peer fallback case | Covered by the named codec and strict-preservation tests |
| Unknown/phase-forbidden reason | Strict malformed; unchanged legacy fields | reason-phase validator | Unknown and forbidden reason cases | Covered by the named codec and strict-preservation tests |
| Postcommit versus precommit | Valid postcommit fallback not-converged; malformed protocol | phase owner consuming retained cause | Existing strict peer phase tests | Covered by the named codec and strict-preservation tests |
| Accept-first raw frame and framing failure | After joining Accept validate once if no read error; source ownership unchanged | listener owner / sequencer | Existing AcceptFirstValidFallback, framing and stale-cause cases | Covered by the named codec and strict-preservation tests |

**Evidence budget:** At most 8 new representative semantic cases plus the named existing regressions and mandatory repository gate. Count table subcases as cases. One normal and one focused race invocation on a successful final candidate; reruns only after diagnosed failure or relevant code changes. Zero required guard mutations; at most one central guard-bypass experiment if needed to show inherited coverage exercises its owner, with no syntax-variant campaign. No new operational/platform/repetition scope. One fully briefed fresh review, at most one replacement after accepted fixes; verification remains scoped to accepted findings. Terminate after this evidence passes with no unresolved stop-for-decision. This budget does not limit existing repository-required gates; it prevents optional evidence inflation.

**TDD and preservation evidence:** First add at most eight codec cases: four valid typed shapes, malformed fallback preserving legacy fields, valid protocol_mismatch fallback, unknown reason and forbidden-phase reason. Existing TestNegotiatorUpgradeStrictPeerPhases, TestNegotiatorUpgradeStrictPeerProtocolFallback, TestNegotiatorUpgradeStrictCleanupPreservesWinner, TestNegotiatorUpgradeStrictRejectsStaleClassification, TestNegotiatorUpgradeStrictMissingFallbackReason and TestNegotiatorUpgradeStrictAcceptFirstValidFallback provide caller preservation. Do not multiply each case across six call sites.

**Dispatch context budget:** Target at most 36,000 input tokens: this current plan and exact slice; current governing invariants from relevant ADR sections; the scoped source functions and named test bodies; current repository review/CI overlays and shared baselines; relevant unresolved findings only. No entire prior report history, duplicate historical plans or full engine dumps. No governing diff is needed for a new slice; later amendments supply a bounded current-contract diff. One owner-level change and this finite test surface must leave room for implementation, local fixes and verification in one fresh agent context. If the required context exceeds this bound or the change no longer fits one PR, re-audit before editing.

**Slice decision audit:** Splitting typed results from their real consumers would leave dual decode interfaces and no completed behavior; splitting pre/postcommit migration would retain a validity reconstruction protocol. The four-decoder caller census, including the six strict sites, probe peek and mechanical test/helper callers, is finite and the context includes only relevant decoder/classifier excerpts, not the entire upgrade engine. If that bounded change cannot fit, re-audit the child before coding instead of widening it. The strongest adjacent merge case is shared files or convenient scheduling, which is insufficient: adjacent tracks can each deliver a coherent result independently. No blocker is needed for convenience. A later real dependency must be demonstrated and re-audited.

**Stop conditions:** Stop for representation/ownership change, new public authority or schema, changed protocol/timing/error policy outside this contract, inability to preserve the named outcomes, untraced shared-state effects, evidence needs beyond this budget, or a one-PR/context boundary failure. Apply the shared precise-root/representation stops to review and verification; do not expand the latest checklist. Same-child re-audit is allowed only within the accepted representation, outcome and one-PR boundary; otherwise return for decision or scoped architecture-handoff.

## Acceptance Criteria

- [x] Typed private decoding returns the existing domain result and nil/exact malformed payload cause; legacy fields remain intact for the declared malformed fallback case.
- [x] Callers reuse retained validity only after an actual semantic decode; accept-first fallback still validates at the current post-Accept-join point.
- [x] The declared pre/postcommit semantic classes preserve strict/legacy results, framing provenance, reason allowlists and exact-attempt source identity.

The representation contract above scopes quantifiers such as “one,” “unchanged,” and “once” to the named supported constructors, consumers and semantic classes; finite named tests and source-owner inspection terminate acceptance. No exhaustive schedule or external-language proof is claimed.

## Validation Gates

Before any Go build/test command, perform the installed/base Go audit in AGENTS.md and stop below the approved floor. Write the named characterization/regression cases first. Run `go test -count=1 ./connect` and a focused race invocation through `./scripts/run-go-test-require-match.sh -race -run '^(Test.*Control.*|TestNegotiatorUpgradeStrict)' -count=1 ./connect` with `GOMAXPROCS=1 GOTOOLCHAIN=local`. Then run `task verify` for the exact final pushed head; retain head/base and results. Existing repository gates are not replaced by these focused cases. No added native-platform matrix, repetitions, fuzzing or hosted experiment. Required CI must report success (not skipped) on that same head before squash merge.

## Operating Discipline

Follow the shared `_shared/REVIEW-LOOP.md` and `_shared/CONTRACT-CLOSURE.md` baselines supplied by `$implement-architecture-slice` (reachable as `../_shared/` from its skill directory), composed with the repository [review overlay](../REVIEW-LOOP.md), [CI policy](../CI.md), [conventions](../CONVENTIONS.md), and root [AGENTS.md](../../AGENTS.md). No repository contract-closure overlay exists; use the shared baseline directly. The baselines govern artifact/representation gates, finite evidence, semantic-family closure, review and verification-aware approach stops, exact-head local certification, same-head hosted CI, merge, journal and pointer-only tracking. Do not copy or strengthen them in this plan.

After exact-head certification and same-head CI, merge, run `$append-dev-journal`, reconcile the parent/tracker frontier and complete only this slice’s OmniFocus task. Parent and OmniFocus notes carry state and pointers, not substantive contracts or certification SHAs. Dispatch is an operator action; this handoff does not launch implementation.
