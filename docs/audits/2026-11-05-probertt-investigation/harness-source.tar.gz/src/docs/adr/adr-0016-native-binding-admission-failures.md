# ADR-0016: Native Binding Admission Failures Drop and Recheck

## Status

Accepted 2026-10-18. The decisions were grilled in [#1880](https://github.com/GridSwarm/wiremux/issues/1880), which owns implementation, and refined after a multi-agent consideration (run `20261018T213043-7748c0bcdced7a1087867246`) and the review of the PR that added this record. The cached-verdict maximum age that bounds stale admits is a separate decision in [#1876](https://github.com/GridSwarm/wiremux/issues/1876). Also on 2026-10-18, [#1884](https://github.com/GridSwarm/wiremux/issues/1884) widened the binding outage to an IPv6 source address that is listed but not yet usable; that issue holds the platform evidence. Amended 2026-10-18 for discovery bindings, decided in the triage of [#1882](https://github.com/GridSwarm/wiremux/issues/1882); see [the amendment](#amendment-2026-10-18-discovery-bindings). Amended 2026-10-20 for connected macOS sockets, decided in [Should the native path use a connected socket per peer?](https://github.com/GridSwarm/wiremux/issues/1843#issuecomment-6207453285); see [the amendment](#amendment-2026-10-20-connected-macos-sockets).

## Context

A native binding admits every send and every received datagram against the binding's current interface identity, source address and an interface-restricted route lookup (see the `binding` section of [the compatibility contract](../COMPATIBILITY.md)). Admission currently has two outcomes besides success:

- A peer-level result is discarded on receive but returned as an error on send. This covers a policy refusal, a packet-local screening refusal and a failed route lookup. On macOS and Linux, "no route to this peer through the selected interface" also arrives as a failed lookup (`ESRCH`, netlink unreachable).
- A binding-level failure is returned as an error in both directions. This covers interface identity loss, an interface that is down, an unassigned source address and a failed interface inspection.

On a native connection both outcomes are terminal. quic-go-fast treats any send error other than its own fence and message-size results as terminal, and its emission loop destroys the connection ([`send_queue.go`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/send_queue.go#L225-L231), [`connection.go`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L620-L624) at `v0.62.1-fast.7`). A non-temporary read error closes the binding's whole QUIC transport, ending every connection on it: the native candidates still in setup, or the one Wire promoted from the endpoint's selected candidate. So a two-second Wi-Fi disconnect, during which macOS removes the interface's IPv4 address and then returns it, ends the Wire even though nothing about the selected interface has changed.

An IPv6 address that comes back is not always usable at once. Until duplicate-address detection finishes, Linux marks it tentative, for about a second with default settings, and refuses an explicit-source send from it with `EINVAL`. macOS refuses one from a tentative or duplicated address with `EHOSTUNREACH`. By default, though, macOS marks returning link-local, autoconfigured and DHCPv6 addresses optimistic, and those it sends from. Go's address listing, which admission reads, includes the address in every one of these states.

GridCast is the consumer that requires per-datagram admission. Its native transport design says a rejection must not be routed through an error that tears down the winning connection ([g30-native-transport-design L74](https://github.com/GridCastIO/gridcast/blob/40950e1b65affc0e0f06affd307319ce17316f42/docs/g30-native-transport-design.md#L74)). On 2026-10-18 the GridCast owner confirmed drop-and-recheck rules, relayed in #1876's comments. GridCast's routing foundation distinguishes an unavailable fact, which fails only the current operation, from positive identity loss, which is stale ([routing-foundation plan L26](https://github.com/GridCastIO/gridcast/blob/40950e1b65affc0e0f06affd307319ce17316f42/docs/adr/2026-09-21-routing-foundation-plan.md#L26)). Its ADRs rule out continuity polling, watchers and teardown on interface changes ([ADR 0044 L7](https://github.com/GridCastIO/gridcast/blob/40950e1b65affc0e0f06affd307319ce17316f42/docs/adr/0044-constrain-establishment-to-selected-interfaces.md#L7), [ADR 0047 L12](https://github.com/GridCastIO/gridcast/blob/40950e1b65affc0e0f06affd307319ce17316f42/docs/adr/0047-discover-attachment-readiness-through-construction.md#L12)).

## Decision

**Scope.** These rules apply to unicast bindings: the public `binding` package and the native endpoint's bindings. Discovery bindings share the admission code; [the 2026-10-18 amendment](#amendment-2026-10-18-discovery-bindings) gives their dispositions, which take effect with [#1882](https://github.com/GridSwarm/wiremux/issues/1882). Until then they keep their existing contract, including treating a binding-level failure as terminal.

Packet-metadata validation stays outside these rules:
- A received datagram whose kernel ingress or source metadata is missing, foreign or malformed is discarded silently before peer admission, as today. It is not counted, sets no idle-cause hint and does not reset the hint's window.
- A send whose caller metadata fails the binding's validation keeps its existing recorded failure, and is never reported as written.

**Three failure classes, owned by admission.** The binding's single admission owner sorts every admission failure into a **peer refusal**, a **binding outage** or a **binding loss**, as named in [CONTEXT.md](../../CONTEXT.md):

| Admission result | Class | Recheck | Verdict cache |
| --- | --- | --- | --- |
| Packet-local screening refuses the peer: invalid, unspecified or multicast address, wrong family, foreign IPv6 zone | Peer refusal | Next datagram; needs no native facts | Not consulted; screening runs every time |
| Route facts refuse the peer: directed or limited broadcast, a route leaving the interface, a non-unicast route, or in Local mode a gateway or default route | Peer refusal | Under the verdict rules | Cacheable |
| The route lookup for the peer fails, including "no route through this interface" | Peer refusal | Single-flight per peer, at most once every 100 ms; a change notification ends the wait | Never cached as a verdict |
| The interface is down, or inspecting it or reading its addresses fails (unavailable, permission, unsupported) without establishing identity loss | Binding outage | Single-flight per binding, at most once every 100 ms | Never cached; clears every verdict |
| The interface is up, its addresses were read, and the binding's source address is absent | Binding outage | Next datagram | Never cached; clears every verdict |
| The interface is up and the binding's IPv6 source address is listed but not yet usable (see **Source readiness**) | Binding outage | Next datagram | Never cached; clears every verdict |
| Interface identity is lost, whether observed now or already latched | Binding loss | None; permanent | Clears every verdict; latches the handle stale |

- **Datagrams during a wait.** Inside a 100 ms wait, datagrams for that peer or binding are dropped as the same refusal or outage, without a native query.
- **Windows.** An adapter snapshot that can't be obtained is a failed inspection wherever it occurs, including inside a route lookup. It is a binding outage, not a peer refusal, and not proof that the source is absent.
- **Source readiness.** A listed IPv6 source is usable only when the platform's kernel would accept it as the explicit source of a send:
  - Linux: a tentative address is not usable unless it is also optimistic. An address whose duplicate-address check failed stays tentative, so it is not usable.
  - macOS: a tentative or duplicated address is not usable. An optimistic address is usable.
  - A deprecated address is usable on both.
  - Windows follows the same rule once a Windows host establishes which address states its kernel refuses as a send source. Until then, Windows admission is unchanged.
  - IPv4 sources have no such state and are unchanged. Discovery bindings don't gain this check; see [the amendment](#amendment-2026-10-18-discovery-bindings).
- **Address-not-available send errors.** An `EADDRNOTAVAIL` or `WSAEADDRNOTAVAIL` send error is classified by a fresh observation:
  - identity loss, newly observed or already latched, is a binding loss;
  - an interface that is down, or a failed inspection that doesn't establish identity loss, is a binding outage under the 100 ms wait;
  - an interface that is up with the source absent, or listed but not usable, is a binding outage, rechecked on the next datagram;
  - an interface that is up with the source assigned and usable leaves an ordinary socket error.
- **Binding loss always wins.** Identity loss found in any observation (regular admission, send-error confirmation or route lookup) is binding loss, never an outage.
- **Other socket errors.** Socket errors that aren't admission results keep their existing handling, including message-size feedback and Linux's first-send permission fallback in batches. All others remain fatal. On a promoted native Wire's connected macOS socket, [the connected-socket amendment](#amendment-2026-10-20-connected-macos-sockets) drops the ICMP-driven errors and `ENOBUFS` instead.

**Drop and recheck.**
- A peer refusal or binding outage never latches the handle stale.
- On receive, it discards the datagram and the read continues.
- On a send through `binding.Binding` (single, message and batch owners), it is returned to the caller as an error. A batch send that meets one returns the accepted prefix with no error, as a peer refusal does today.
- The refusal keeps its existing error kind and detail: `binding.ErrPolicy` for a route-facts refusal, and selection's `ErrUnavailable`, `ErrPermission` or `ErrUnsupported` for failed lookups, failed inspections and a missing source. A listed source that isn't yet usable has no existing detail: it is refused with `ErrUnavailable` and a detail that says the source is not yet usable, distinct from one that is no longer assigned. The class itself is internal to admission and the native adapter, because kinds alone don't separate a failed route lookup from a binding outage.
- **Verdict invalidation is unchanged by the connection staying up.** Observing a binding outage clears every cached verdict on the binding, and fences admissions already in flight, exactly as a binding-level failure does today. Every datagram still receives an admission decision. That decision may reuse a valid cached verdict and does not require a fresh OS query.

**Native connections report dropped sends as written.** The native QUIC adapter reports a send refused by a peer refusal or binding outage to QUIC as written. QUIC therefore counts the datagram lost, and its loss recovery and congestion control respond as they would to any loss. There is no pause and no fatal error. Binding loss and fatal socket errors are still returned.

The adapter serves every connection on the binding's QUIC transport, so this covers native candidates in setup as well as the promoted Wire. Dialing is unchanged: the endpoint still admits the destination before choosing a binding, and fails with no admitting binding when none admits it. A dial or candidate whose sends are dropped after that ends no later than its absolute setup deadline. QUIC's handshake timeouts can end it sooner.

**Counts are internal.** Each binding counts dropped datagrams by class and direction. A dropped send counts once, when the adapter reports it as written. A batch entry that falls back to the per-packet path is counted there, not twice. The counts serve tests and cause naming; no public API exposes them until a consumer asks for one.

**The idle timeout names the routing cause.** A condition that never clears ends the native Wire at QUIC's idle timeout (the effective value both peers negotiate; native endpoints configure 30 s). The teardown error still matches QUIC's idle-timeout error and the Wire's existing error classification. It also wraps the refusal from the most recent qualifying drop for the Wire's remote endpoint on that binding:

- **The remote endpoint** means address, port and IPv6 scope. The scope is the binding's interface, so equivalent zone spellings (empty, numeric index or name) match.
- **What qualifies:** a drop in either direction made after the last datagram from that endpoint that admission accepted and handed to QUIC.
- **What doesn't reset the window:** received datagrams that admission dropped. They are themselves drops.
- **No qualifying drop:** the error is unchanged.
- **Setup traffic:** candidate traffic to the same remote endpoint before promotion feeds the same hint as the Wire promoted from it.

The cause is a diagnostic hint, not proof that routing caused the silence.

**Relationship to ADR-0015.** [ADR-0015](adr-0015-selected-interface-continuity.md) decided that, for selected Wires, source-address changes, inspection errors and interface removal must not by themselves terminate an established Wire. Native bindings now follow that intent for source-address changes, a down interface and inspection errors that admission observes. They deliberately depart from it for binding loss, which stays fatal: GridCast requires native admission against the interface's current identity for every datagram, and ADR-0015's ordinary-binding policy provides no such check. Selected Wires are unchanged.

## Considered Options

- **Leave `binding` unchanged and reinterpret errors in the native adapter.** Rejected: one policy would be split across two owners, and the adapter would pattern-match errors, retry failed reads and keep its own backoff state.
- **Hold a refused send until admission passes.** Rejected: that is the pause GridCast's rules forbid, and a stalled send goroutine would delay connection close.
- **Return a temporary error from the send.** Rejected: the fork's send path ignores temporariness and destroys the connection anyway.
- **A public drop counter now.** Rejected for now: no consumer reads one. A binding's counts also include its candidates' setup traffic, so a per-Wire counter would need bookkeeping of its own.
- **A dedicated outage sentinel.** Rejected: the refusal's existing kind and detail describe it, and the native adapter, which needs the class, reads it inside admission.
- **Recheck a failed route lookup on every datagram, as today.** Rejected: a refused peer that keeps sending would cost one route lookup per arriving datagram, up to about 4,700 per second on macOS. That would reintroduce the per-datagram OS queries #1784 removed.
- **Cache a definite "no route" as an ordinary refusal and throttle only genuine lookup failures.** Rejected: it is more precise, but it needs each platform's no-route error codes identified and tested. The single 100 ms throttle costs at most 10 lookups per second per refused peer.
- **Leave source readiness out of admission.** Rejected: on Linux, a native IPv6 Wire that survives its source address being removed would still end within about a second of the address returning, while the address is tentative.
- **Confirm an `EINVAL` or `EHOSTUNREACH` send error with a fresh observation, as for address-not-available.** Rejected: Linux returns `EINVAL` for many unrelated explicit-source faults, so the error alone says little, and the observation would need the readiness fact anyway. Checking readiness during admission stops the send before the kernel refuses it.
- **A growing backoff.** Rejected: a fixed 100 ms bounds a stuck inspection or lookup at 10 attempts per second per binding or peer, at most 0.2 % of a core (#1784's macOS cap of about 4,700 full admissions per second bounds one at about 213 µs). A longer backoff would delay recovery after the fault clears.

## Consequences

**Released behavior changes.** This changes released v0.2.7 behavior: a direct `binding.Binding` reader no longer sees an unassigned source address or a down interface as an error, however long it lasts. A direct send from a listed IPv6 source that isn't yet usable now fails admission with `ErrUnavailable` instead of reaching the kernel and returning its error. The `binding` section of the compatibility contract says the fatal versus peer-level split is unchanged; that sentence came with the #1784 exception after v0.2.7, and must be rewritten. No consumer exercises the changed behavior: GridCast (`main` at f0ef8102) uses only `binding.Config`, `Facts`, `Failure` and `Error`, never `Binding`'s reads or writes.

**Survival is limited to what admission classifies.** A send can reach the socket after a cached admit, or between a successful observation and the write, while the source or link changes underneath it. The kernel may then report an error other than address-not-available, and that error stays fatal. On Linux, an explicit IPv6 source that is absent also fails with `EINVAL`, not `EADDRNOTAVAIL`, so the address-not-available rule never applies to Linux IPv6 sends, and that race stays fatal there. Source readiness needs each platform's duplicate-address state, which Go's address listing drops, so admission reads that state natively. So outages that admission observes no longer end a connection, but not every source or link transition is survivable. [The connected-socket amendment](#amendment-2026-10-20-connected-macos-sockets) narrows this for a promoted native Wire's connected macOS socket.

**Recovery is not time-bounded.** How quickly a native Wire resumes after the fault clears depends on QUIC's loss-probe schedule, which backs off exponentially during the outage. A long outage can therefore leave little of the idle timeout to recover in, and wiremux adds no recovery timer, watcher or pause to shorten it. If the connection survives, its reliable stream retransmits once admission passes. Datagrams sent during the outage are lost, as their contract already allows.

## Amendment (2026-10-18, discovery bindings)

Decided in the triage of [#1882](https://github.com/GridSwarm/wiremux/issues/1882), which owns the implementation and lands after [#1880](https://github.com/GridSwarm/wiremux/issues/1880). Until it lands, discovery bindings keep the terminal behavior the Scope paragraph describes.

**Context.** A discovery binding (the `discovery` package) runs the same admission, and today any binding-level failure is permanent: the binding records it and refuses later operations, and its receive worker leaves the group and closes the socket. Peer admission re-reads the binding's own addresses for every received datagram that passes packet-local screening, so during a binding outage the first such datagram ends the binding, multicast included. So does the next `SendMulticast` or `Reply.Send`. GridCast keeps one discovery endpoint open for a whole peer search: up to its 15-minute pairing window ([`invitation.go` L31–L37](https://github.com/GridCastIO/gridcast/blob/b1cc37c0542c73d29e2c2a51d3a7ed3bf38cca6a/internal/invitation/invitation.go#L31-L37)) or, for a local Resume without `--wait`, until the Resume expires ([`resume_wait.go` L36–L46](https://github.com/GridCastIO/gridcast/blob/b1cc37c0542c73d29e2c2a51d3a7ed3bf38cca6a/internal/transfer/resume_wait.go#L36-L46)), 24 hours by default ([`main.go` L429](https://github.com/GridCastIO/gridcast/blob/b1cc37c0542c73d29e2c2a51d3a7ed3bf38cca6a/cmd/gridcast/main.go#L429)). It does not reopen the endpoint during that wait, and it discards send errors on the expectation that the next timer retries them ([`service.go` L388–L397](https://github.com/GridCastIO/gridcast/blob/b1cc37c0542c73d29e2c2a51d3a7ed3bf38cca6a/internal/discovery/service.go#L388-L397)). A two-second Wi-Fi disconnect can therefore silence discovery on that interface and address family for the rest of the search, with no error reported.

**Decision.** Discovery bindings use the classes in the table above, except the source-readiness row, with these dispositions:

- **A binding outage is never terminal.**
  - A received datagram is discarded and the worker keeps reading.
  - `SendMulticast` and `Reply.Send` send nothing and return the refusal with its existing kind and detail. The binding stays usable.
  - A down interface or a failed inspection is retried single-flight per binding at most once every 100 ms, and datagrams inside that wait are dropped without a native query. An absent source is rechecked on the next datagram.
- **Binding loss stays terminal**, as today: the binding records the failure, refuses later operations, leaves its group and closes its socket.
- **Peer refusals keep discovery's existing disposition.** A refused received datagram is discarded, and a refused reply is returned as an error. Discovery gains neither the per-peer route-lookup throttle nor the verdict cache. The per-binding outage wait above still applies.
- **Socket errors keep their handling.** A read error that isn't discardable stops the binding, and a write error is returned without stopping it.
- **No source-readiness check.** A listed IPv6 source is admitted whether or not it is yet usable. If the kernel refuses a send from it (`EINVAL` on Linux, `EHOSTUNREACH` on macOS), that is an ordinary write error, which doesn't stop the binding. Readiness exists to keep that refusal from ending a native connection, and a discovery binding already survives it; skipping the check also keeps group traffic arriving while the address is tentative.
- **Reporting.**
  - `Binding.Err` reports only what stopped the binding (binding loss or a read error), never an outage.
  - `Endpoint.Receive` returns the bindings' failures only once every binding has stopped, so an outage that never clears leaves `Receive` waiting for its context or `Close`.
  - `Dropped` still counts only queue overflow, and no public outage count is added.

**Group membership.** A binding keeps the group membership it joined at construction; it doesn't leave or rejoin around an outage.
- **Joins are by index.** Every platform joins by interface index, not address: `MCAST_JOIN_GROUP` on Linux and macOS, and the index forms of `IP_ADD_MEMBERSHIP` and `IPV6_JOIN_GROUP` on Windows.
- **macOS.** xnu's IPv4 address-removal path (`SIOCDIFADDR`) drops only the kernel's own all-hosts membership when an interface's last IPv4 address goes, and touches no membership a socket holds ([`bsd/netinet/in.c` L701–L815](https://github.com/apple-oss-distributions/xnu/blob/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/netinet/in.c#L701-L815) at `f6217f89`).
- **The network side.** 224.0.0.251 lies in the 224.0.0.x range that snooping switches must flood without IGMP state ([RFC 4541 §2.1.2](https://www.rfc-editor.org/rfc/rfc4541#section-2.1.2)), so IPv4 needs no new report either.
- **Linux, Windows and IPv6** are expected to keep the membership too, but that is unverified.

**Evidence.** The implementation proves recovery in process (an outage, then recovery, then a delivered group datagram and a sent announcement). It also proves it on one real Linux host that removes and restores the address of a dedicated fixture interface. macOS IPv4 address removal rests on the kernel source above, and Windows is unverified; both are stated non-claims. If a platform does drop the membership, the binding survives the outage but may stop receiving group datagrams, which leaves the search no worse off than today's terminal failure.

**Considered options.**
- **Keep the terminal outage and signal GridCast to reopen.** Rejected: GridCast would have to reopen discovery mid-search, and its ADRs rule out watchers and teardown on interface changes.
- **Leave and rejoin the group after every outage.** Rejected: it adds recovery state and a leave-and-join that can fail or drop datagrams, guarding against a failure that macOS's IPv4 address-removal path shows doesn't happen.

**Consequences.** This changes released v0.2.7 `discovery` behavior: a binding outage no longer stops a binding or shows in `Binding.Err`. GridCast at `b1cc37c0` acts on discovery failure only when `Receive` reports that every binding has failed, and it already discards per-send errors. No consumer relies on the terminal outage. The `discovery` sections of the compatibility contract and the package documentation change with the implementation, not with this amendment.

## Amendment (2026-10-20, connected macOS sockets)

Decided in [Should the native path use a connected socket per peer?](https://github.com/GridSwarm/wiremux/issues/1843#issuecomment-6207453285) and implemented with it.

**Scope.** One socket: a promoted native Wire's binding socket on macOS, once promotion has connected it to its peer. Unconnected sockets (macOS candidates before promotion, a binding whose connect failed, every Linux and Windows socket), `binding.Binding` and discovery bindings keep the rules above.

**Context.** A connected socket is told about errors an unconnected one never sees. ICMP port, protocol, host and network unreachable and fragmentation-needed messages for its four-tuple arrive as `ECONNREFUSED`, `EHOSTUNREACH`, `ENETUNREACH`, `EHOSTDOWN`, `EMSGSIZE`, `EPROTO` or `ENOPROTOOPT`, each returned once by the next receive or send, and macOS flow control returns `ENOBUFS` on sends. Under **Other socket errors** each would end the Wire, or on receive the binding's whole QUIC transport. An off-path sender that knows the four-tuple can forge the ICMP, and fragmentation-needed replies are routine during path MTU probing.

**Decision.**

- **Dropped, whatever raised them.** On that socket those eight errors are dropped datagrams in both directions, whether ICMP or a local route, link or source change raised them. They are never reclassified as a binding outage or binding loss, so on that socket this narrows **Survival is limited to what admission classifies**. Every other socket error keeps its existing handling. `EMSGSIZE` is dropped there instead of being returned as message-size feedback: once the handshake is confirmed, QUIC treats a message-size result as a lost send, so the outcome is the same.
- **Receive.** The error is discarded and the read continues.
- **Send.** The send is reported to QUIC as written, as a dropped send is above, and QUIC counts it lost. A batch that meets one returns the accepted prefix with no error, and QUIC's per-packet path retries that datagram, which normally succeeds because the kernel reported the error once.
- **Not an admission result.** These drops are none of peer refusal, binding outage or binding loss. They latch nothing stale, clear no verdict, start no wait and change no error kind.
- **Counts.** Each binding counts them by direction in a class of their own, one per absorbed error where it is absorbed, in a batch or on the per-packet path. The counts are internal, as above.
- **Not a routing cause.** They never qualify for the idle-timeout cause, and because they are not datagrams admission accepted, they don't reset its window. The 30 s idle timeout stays the only way an unreachable peer ends the Wire.
- **Other destinations.** A send on that socket to any destination but the connected peer is a packet-local peer refusal, `binding.ErrPolicy` with the detail "destination is not the connected peer", refused before any kernel call and dropped as a peer refusal is above. The destination is compared as `CheckSend` compares it: the normalized peer address (unmapped on IPv4, a zone only where `CheckSend` accepts one) and the port, so an equivalent spelling of the connected peer takes the connected path.

**Considered options.**

- **Fail fast on "port unreachable".** Rejected: a forged ICMP message from off the path would then end Wires, and routine fragmentation-needed replies during path MTU probing must not end them either.
- **Absorb the errors in the native adapter.** Rejected for the reason the adapter option above was: one policy would be split across two owners.

**Consequences.** A peer whose address or port changes after promotion is refused by the kernel, and the Wire ends at its idle timeout. On that socket, a local route or link transition that raises one of the eight errors no longer ends the Wire before its idle timeout. A binding whose connect failed keeps today's behaviour and counts the failure internally.
