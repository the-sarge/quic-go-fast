# Native observability and published targets Implementation Plan

**Date:** 2026-10-19
**Status:** Slices 3.1, 3.2 and 3.4 complete; slice 3.3 deferred by the owner on 2026-10-23; no active Track 3 implementation frontier
**Track:** 3 of 7 in program NG-20261019
**Depends on:** Slice 3.4 depends on completed slice 5.1 ([#1925](https://github.com/GridSwarm/wiremux/issues/1925), merged through [#1999](https://github.com/GridSwarm/wiremux/pull/1999)); it does not depend on 3.3 or its timing gate. For the original slices: nothing outside this track except the named ADR-0016 implementation. Slices 3.1 and 3.2 can start immediately; slice 3.3 waits for 3.2 and for [Native Wire: a route refusal or a briefly unassigned source address ends the connection instead of dropping the datagram](https://github.com/GridSwarm/wiremux/issues/1880) to close. Downstream edges: 3.1 → task 4.R ([Track 4](2026-10-19-fork-bundle-plan.md)) and slice 5.1 ([Track 5](2026-10-19-bundle-adoption-plan.md)), which read through it; 3.2 → 3.3, 6.2 ([Track 6](2026-10-19-macos-native-stack-plan.md)) and every certification slice 7.1–7.3 ([Track 7](2026-10-19-native-certification-plan.md)), which fill the document 3.2 creates.
**Program:** [2026-10-19-native-gap-program.md](2026-10-19-native-gap-program.md)
**Related:** [ADR-0003](adr-0003-quic-selected-path-binding.md), [ADR-0014](adr-0014-optional-quic-fork-integration.md), [ADR-0016](adr-0016-native-binding-admission-failures.md); [Track 2](2026-10-19-native-binding-receive-plan.md) (shares the binding read path with 3.3); [Track 6](2026-10-19-macos-native-stack-plan.md) (6.2 ships the send-thread raise the targets doc describes; 6.4 keeps 3.3's receive timestamps)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers and stop conditions
**Audit history:** [Original handoff](2026-10-19-native-gap-handoff-audit.md); [Slice 3.4 amendment audit](2026-10-23-native-discard-count-audit.md)
**Parent issue:** [#1911](https://github.com/GridSwarm/wiremux/issues/1911)
**Decided by:** [Should native throughput targets require consumer headroom, or should wiremux pursue a scheduler fix?](https://github.com/GridSwarm/wiremux/issues/1867#issuecomment-6245076072); [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) (sections 2–5); [Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572) (section 7); [How many busy goroutines can a consumer run before its native Wire stalls, and what restores it?](https://github.com/GridSwarm/wiremux/issues/1865#issuecomment-6244783748); [Which realistic loads push the default-class native sender onto macOS efficiency cores?](https://github.com/GridSwarm/wiremux/issues/1857#issuecomment-6238637284); [Does load on the receiving Mac cost the native pair, and do its receive goroutine and run loop need a raised class?](https://github.com/GridSwarm/wiremux/issues/1866#issuecomment-6247562292); [Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6240861645) (sections 1 and 4); [How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507) and [Should native connections get a deeper unprocessed-packet queue than the fork's 256 packets?](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120) (decision 3 of each); [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084) (the Linux floor); [Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?](https://github.com/GridSwarm/wiremux/issues/1868#issuecomment-6251637328) (reopen triggers); handoff decisions [H4](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H22](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions) and [H24](2026-10-19-native-gap-handoff-audit.md#handoff-decisions) in the [handoff audit](2026-10-19-native-gap-handoff-audit.md#handoff-decisions).

## Goal

The track defines four outcomes through the modules that own their facts. Slices 3.1, 3.2 and 3.4 are complete; the third outcome is deferred under the decision below.

First, `internal/nativequic`, which owns every native QUIC connection, gains one internal, off-by-default readout seam. The measurement rig and the bundle repin's dependency evidence record then read a promoted native Wire's QUIC facts (round trips, packet and loss counts, the fork's drop counts, PTO expiries and spurious losses) through that one owner, with no public API and no probe worktree. Every bundle consumer gate (4.G1–4.G6), the repin's record (5.1) and the later macOS gates read the same seam.

Second, the consumer rule every native target assumes, processor headroom, is stated where consumers meet it: the godoc of the native entry points and the domain glossary. `docs/NATIVE-THROUGHPUT.md` becomes the one place wiremux publishes native throughput figures: per-platform floors marked "target, not yet certified", the busy-consumer measurements labelled with the shapes they were measured on, and what the figures cover and what they don't. Each certification slice later fills its platform's row there and touches nothing else.

Third, the deferred Slice 3.3 would help a consumer diagnose whether its process starved a native Wire. A public running count, `NativeWireInfo.LateReads`, is read live from `Wire.Native()` and owned by the binding's receive path, which already parses every kernel control record. It ships only if its gate shows it separates a starved Wire from a healthy one at no throughput cost.

Fourth, a consumer can read the native connection's cumulative received-DATAGRAM full-queue discard count through `NativeWireInfo.DatagramReceiveDrops` and `DatagramReceiveDropsAvailable`. Slice 3.4 implements the [owner-approved #1969 design](https://github.com/GridSwarm/wiremux/issues/1969#issuecomment-6370249114), independently of 3.3. This supersedes #1828 decision 3 and H4's internal-only visibility for this one counter; other readouts remain internal. GridCast uses it for regression assertions and benchmark statistics. It must ship in the bundle-adoption wiremux tag GridCast consumes; this track does not publish that tag.

## Current Shape (verified 2026-10-19)

Code is cited at wiremux `467fc555`, the rig at `codex/native-gap-rig` `b47a253a`, the fork at release `v0.62.1-fast.7` (the program's fork lane, [H3](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)) and at fork `main` `5b05133d`.

**What reaches a native Wire's connection today.**

- A promoted native Wire's facts are a static copy. [`NativeWireInfo`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native_promotion.go#L77-L91) has Topology, Binding, Local, Remote and Dialer. [`Wire.Native`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native_promotion.go#L94-L103) returns `*w.native`, which is filled once at [L344–L350](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native_promotion.go#L344-L350) from the candidate's info (`Local: info.Binding.Local`, `Remote: info.Remote`). Nothing in it is live.
- The connection is [`Candidate.conn`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/candidate.go#L64-L106). The candidate keeps the binding only as copied facts ([`newCandidate` L112–L122](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/candidate.go#L112-L122)), not as a pointer to the `UnicastBinding`.
- After commit, [`Promotion`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/promote.go#L175-L197) owns the connection. [`Commit`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/promote.go#L307-L338) creates the Datagram carrier, and [`Close`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/promote.go#L383-L408) closes the connection and the endpoint. The carrier sees the connection only through [`datagramConn`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/promote.go#L420-L425). Nothing exports the connection, its statistics or a tracer.
- The native QUIC configurations ([`serverQUICConfig`/`clientQUICConfig` L638–L660](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/endpoint.go#L638-L660)) set no `Tracer`.
- Optional fork capabilities are found by interface assertion on ordinary upstream types ([`capability.go` L21–L58](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/capability.go#L21-L58)). A new optional method needs its own interface: adding it to `transportV1` or `connV1` would make `Supported` false on any fork without it.
- Test-only hooks refuse to run outside a test binary ([`SetCloseBoundHookForTest`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/promote.go#L370-L381)).

**The rig and `internal/measurement`.**

- The rig builds native Wires through the public API only. [`runNative`](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/main.go#L1163-L1204) runs `NewNativeEndpoint` → `Dial`/`Accept` → `Select` → `Authenticate` → `Promote`, with one endpoint and one Wire per process.
- The rig already imports module-internal packages ([L47–L48](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/main.go#L47-L48)).
- The rig has no RTT, PTO, spurious-loss, fork drop-count or stream-packet readout. Its stream receiver counts bytes only.
- [PROTOCOL.md L5–L15](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/PROTOCOL.md?plain=1#L5-L15) says the rig is never merged and measures a lever by being applied onto the lever's branch and onto its base. `rig.mod` selects fast.7.
- `internal/measurement` is the engine of `wiremux-measure` ([MEASUREMENT.md](../MEASUREMENT.md)), not of the native Wire. Its raw-QUIC layer builds its own transport with ALPN `wiremux-quic/2` and installs its own qlog profile tracer ([`transport.go` L291–L303](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/measurement/transport.go#L291-L303), [`profile.go` L45–L80](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/measurement/profile.go#L45-L80)). It never touches `internal/nativequic`. The queue decisions' "`internal/measurement` reads the count when the method exists" stays decided for those raw-QUIC layers ([H24](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)) and is delivered by slice 5.1; it cannot reach a native Wire.

**What the fork exposes.**

- [`Conn.ConnectionStats()`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L836-L889) returns MinRTT, LatestRTT, SmoothedRTT, MeanDeviation, BytesSent, PacketsSent, BytesReceived, PacketsReceived ("including packets that were not processable"), BytesLost and PacketsLost.
  - Every field is an atomic load ([`rtt_stats.go` L21–L30](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/utils/rtt_stats.go#L21-L30), [`connstats.go` L7–L14](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/utils/connstats.go#L7-L14)), so it is safe to call from any goroutine.
  - The method is the same on fork main ([L857–L910](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L857-L910)) and in upstream v0.62.0 ([L829](https://github.com/quic-go/quic-go/blob/v0.62.0/connection.go#L829)).
  - PacketsReceived is counted once per received packet ([`sent_packet_handler.go` L255–L256](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/sent_packet_handler.go#L255-L256)). PacketsLost is counted only by the Reno/Cubic sender ([`cubic_sender.go` L199–L201](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/congestion/cubic_sender.go#L199-L201)), which native connections use.
- [`DatagramReceiveDropsV1() uint64`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2996-L3006) exists on fork main from quic-go-fast's "Deepen the received-DATAGRAM queue and count its discards" (`42b9b5de`).
  - It counts full-queue discards only, is safe to call concurrently and keeps its value after close.
  - It is absent at fast.7 and in upstream.
  - No unprocessed-queue drop count exists on fork main yet; fork slice 5 names it.
- PTO counts and spurious losses exist only as qlog events.
  - [`qlog.PTOCountUpdated`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/qlog/event.go#L510-L525) is recorded with the incremented count on each PTO expiry ([`sent_packet_handler.go` L983–L994](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/sent_packet_handler.go#L983-L994)) and with 0 on each reset ([L237–L240](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/sent_packet_handler.go#L237-L240)).
  - [`qlog.SpuriousLoss`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/qlog/event.go#L547-L569) is recorded once per packet that was declared lost and then acknowledged ([L565–L572](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/sent_packet_handler.go#L565-L572)).
  - The fork's anti-deadlock PTO, before the peer has validated the client's address, increments the PTO count with no event ([L962–L973](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/sent_packet_handler.go#L962-L973)); it happens only during the handshake.
  - [`qlog.MetricsUpdated`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/qlog/event.go#L463-L471) carries `LatestRTT` and is recorded after an acknowledgment updates any metric, with each field set only when it changed since the previous event ([`qlogMetricsUpdated` L344–L389](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/internal/ackhandler/sent_packet_handler.go#L344-L389), `LatestRTT` at L358–L362). Upstream v0.62.0 has the same type ([L463](https://github.com/quic-go/quic-go/blob/v0.62.0/qlog/event.go#L463)).
  - The PTO and spurious-loss types exist at the same lines in upstream v0.62.0 ([L512](https://github.com/quic-go/quic-go/blob/v0.62.0/qlog/event.go#L512), [L547](https://github.com/quic-go/quic-go/blob/v0.62.0/qlog/event.go#L547)), so code that names them compiles on the ordinary graph.
- How a tracer is installed:
  - [`Config.Tracer`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/interface.go#L187) is called once per connection ([`server.go` L989–L997](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/server.go#L989-L997), [`transport.go` L336–L339](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/transport.go#L336-L339)).
  - The connection creates its recorder only when the returned trace is non-nil ([`connection.go` L300–L302](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L300-L302), [L426–L428](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L426-L428)), and every emission is guarded by `qlogger != nil`.
  - [`Conn.QlogTrace()`](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/connection.go#L2998-L3000) returns the trace.
  - A `qlogwriter.Recorder` "is safe for concurrent use by multiple goroutines" ([`writer.go` L15–L37](https://github.com/the-sarge/quic-go-fast/blob/v0.62.1-fast.7/qlogwriter/writer.go#L15-L37)).

**The read path a late-read count would use.**

- [`packetConn.ReadMsgUDP`/`ReadBatch`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/packetconn.go#L80-L96) call [`ReadUnicastBatch`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/unicast.go#L874-L925).
  - It loops [`receive`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/unicast.go#L927-L956) until one datagram is admitted. Linux reads in batches; other systems read one datagram per call.
  - It reads control data into private scratch sized `len(ms[0].OOB)+ScopeControlSize` ([L894](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/unicast.go#L894)) and admits through [`admitReceived`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/unicast.go#L958-L991).
- [`ScopeControlSize`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/packet.go#L244-L246) is 256. [`CopyReceivedControl`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/packet.go#L257-L265) copies every control byte the kernel returned into QUIC's buffer.
- The packet-info parser skips records of other types ([Unix L100–L130](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/unicast_unix.go#L100-L130), [Windows L204–L215](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/unicast_windows.go#L204-L215)).
- No socket requests a kernel receive timestamp, and no late-read code exists.
- Existing pins:
  - [`TestUnicastMessagePathAllocations`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/unicast_alloc_test.go#L32) is an allocation pin on the test-receive path.
  - [`TestUnicastReceiveIngressAndReturnRoute`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/unicast_test.go#L249) and [`TestUnicastBatchProvenance`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/routeselection/unicast_test.go#L283) cover admission.
- ADR-0016 keeps per-binding drop counts internal ([L67](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/docs/adr/adr-0016-native-binding-admission-failures.md?plain=1#L67)). It rejected a public drop counter partly because "A binding's counts also include its candidates' setup traffic, so a per-Wire counter would need bookkeeping of its own" ([L86](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/docs/adr/adr-0016-native-binding-admission-failures.md?plain=1#L86)).
- Two pieces of work touch the same functions. [Native Wire: a route refusal or a briefly unassigned source address ends the connection instead of dropping the datagram](https://github.com/GridSwarm/wiremux/issues/1880) (the ADR-0016 implementation) lands in two PRs:
  - [fix(binding): drop and recheck admission outages instead of failing](https://github.com/GridSwarm/wiremux/pull/1896) (merged, `cb355462`) rewrote `ReadUnicastBatch` and `admitReceived`; the `internal/routeselection` anchors here are at `467fc555`, before it.
  - [fix(native): report dropped sends as written and name idle causes](https://github.com/GridSwarm/wiremux/pull/1906) carries the native adapter's report-as-written sends, send counts and idle-timeout cause. It changes `promote.go` (`Commit`, the Datagram carrier), `candidate.go` (a new `unicast` binding reference, set from `nt.binding` in `newCandidate`), `endpoint.go`, `packetconn.go`, the `Promote` godoc in `native_promotion.go`, `unicast.go` and COMPATIBILITY.
- Slice 2.1 adds exact allocation pins on this path.
- [`native_promotion_test.go` L271–L274](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native_promotion_test.go#L271-L274) compares `NativeWireInfo` values with `!=`.
- The API inventory lists `NativeWireInfo`'s five fields ([`api-manifest.txt` L145–L150](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/compatmanifest/testdata/api-manifest.txt#L145-L150)). It is regenerated with `go test ./internal/compatmanifest -run Baseline -update` ([`manifest_test.go` L14–L15](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/compatmanifest/manifest_test.go#L14-L15)).

**Docs.**

- No performance, throughput or targets document exists.
- `COMPATIBILITY.md` makes package godoc part of the behavioral contract ([L7](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/docs/COMPATIBILITY.md?plain=1#L7)) and says "internal timing budgets, and implementation choices are not compatibility promises" ([L9](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/docs/COMPATIBILITY.md?plain=1#L9)).
- Its compatible change rule says adding a field to a struct "that consumers can construct with an unkeyed literal is not presumed compatible", with deviations "recorded as explicit exceptions in the affected package section" ([L13–L15](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/docs/COMPATIBILITY.md?plain=1#L13-L15)).
- Its native sections carry contract sentences only ([L119–L125](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/docs/COMPATIBILITY.md?plain=1#L119-L125)).
- README "Start Here" ([L90–L101](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/README.md?plain=1#L90-L101)) indexes the topic docs kept at the `docs/` root.
- The native terms in `CONTEXT.md` ([L227–L253](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/CONTEXT.md?plain=1#L227-L253)) include none of the three headroom terms.
- Native godoc sits on [`NativeEndpoint`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native.go#L86-L106), [`NewNativeEndpoint`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native.go#L113-L119) and [`NativeCandidate.Promote`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native_promotion.go#L217-L254).
- [`CI_DOCS_GLOBS`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/Taskfile.yml#L15) lists some `docs/` root docs (`ARCHITECTURE.md`, `CI.md`, `COMPATIBILITY.md`, `DEPLOYMENT.md`, `DEV-JOURNAL.md`, `RELEASE.md`, `REVIEW-LOOP.md`) but not the topic docs `SELECTED-RELAY.md`, `SELECTED-INITIAL.md`, `MANAGED-ESTABLISHMENT.md`, `MANAGED-MIGRATION.md` or `MEASUREMENT.md`.
- Research notes are on main for the busy-goroutine ([issue-1865](../research/issue-1865-goroutine-headroom.md)), other-program ([issue-1857](../research/issue-1857-realistic-load-placement.md)), receiving-Mac ([issue-1866](../research/issue-1866-receiving-mac-load.md)) and Windows ([issue-1869](../research/issue-1869-windows-receive-coalescing.md)) measurements.

## Decision

### What the readout seam exposes, and to whom (3.1)

Section 5 of [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) (the targets decision below) requires: "The rig gains RTT, PTO and spurious-loss readouts before those gates run". The original 3.1 decision kept the fork's drop counts internal; Slice 3.4 supersedes that visibility only for the received-DATAGRAM full-queue count. The quote below records the original decision. From [How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507) (the received-Datagram queue decision), decision 3:

> **Visibility: the fork counts every discard, and wiremux reads the count only internally.** The count is exposed through a versioned connection method, detected by interface assertion like the fork's other wiremux hooks. Wiremux uses it for measurement and diagnosis only. A public count on `Datagrams` is not added. It stays available later as a purely additive change, if a consumer would act on it.

[Should native connections get a deeper unprocessed-packet queue than the fork's 256 packets?](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120), decision 3, says the same: "There's no public API and no contract text."

The seam lives in `internal/nativequic` ([H4](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). It is a verification aid with no public API. Its contract:

- **Enabling.** A process calls `nativequic.EnableReadouts(nativequic.ReadoutOptions{Recorder: bool})` before it creates native endpoints. Each endpoint captures the setting once, in `New`. An endpoint created before the call behaves exactly as if readouts were never enabled. Nothing else switches the seam on: no environment variable, no `NativeConfig` field, no build tag. Only module code can call it. Tests reset the setting through a test-only function that panics outside a test binary, as `SetCloseBoundHookForTest` does.
- **Registration.** An endpoint with readouts on registers each committed promotion at the end of `Promotion.Commit`, under the connection's `(Local, Remote)`: the same two `Candidate.info` values the root copies into `NativeWireInfo.Local` and `.Remote`. The entry is removed when `Promotion.Close` begins. A key that is already registered is not replaced. Candidates that never commit are never registered.
- **Lookup.** `nativequic.ReadoutFor(local, remote netip.AddrPort) (Readout, bool)` returns a copy, or `false` when no committed, unclosed promotion has that key. The rig gets the key from the public `Wire.Native()`. The seam never returns the connection, a stream or any method that can mutate them.
- **The `Readout` copy:**
  - `Stats`: the connection's `ConnectionStats()`. RTT for the gates comes from `MinRTT`, `SmoothedRTT` and `LatestRTT`; stream packets per second from deltas of `PacketsReceived`; losses from `PacketsLost`.
  - `DatagramReceiveDrops`: the fork's `DatagramReceiveDropsV1()`, found by its own interface assertion.
  - `UnprocessedDrops`: the fork's unprocessed-queue drop count, read the same way, only if the fork has named that method on fork main by this slice's preflight.
  - `PTOs` and `SpuriousLosses`: present only when the recorder option was set.
  - `RTTSum` (nanoseconds) and `RTTSamples`: present only with the recorder. They are the sum and count of non-zero `LatestRTT` values in the connection's `qlog.MetricsUpdated` events, so a gate computes the mean RTT over a window from the deltas of two readouts.
  - Every optional count is a `Count{Value uint64; Present bool}`. An absent method reads as `Present: false`, never as zero. The received-Datagram queue decision says why: "A public count would also have to mean "unknown", not 0, on plain upstream quic-go."
- **Later counters ([H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).** A later counter is added under this same contract by the product slice that first needs it on main, as one more `Count` field:
  - Fork counters, each by its own interface assertion on the connection:
    - slice 5.1 adds the unprocessed-queue drop count, unless fork slice 5 named it before this slice's preflight (then this slice reads it);
    - slice 5.4 adds the Windows guard-trip count (fork slice 11);
    - slice 6.2 adds the send-hook outcome (fork slice 9).
  - wiremux-owned binding counters are reached through the promoted Wire's candidate binding reference:
    - slices 6.3 and 6.4 add the fallback reason, list-path calls, absorbed ICMP drops and truncated-slot counts;
    - slice 2.2 adds the connect-failure count.
    - That reference is the ADR-0016 implementation's `Candidate.unicast` when it has landed; otherwise the first slice that needs it adds the one reference.
  - A consumer gate task that needs a counter before its product slice lands uses a never-merged scratch build carrying the seam addition: 4.G1 (unprocessed-queue drops), 4.G5 (its gate-build packer-discard count) and 4.G6 (guard trips).
  - ADR-0016's per-binding drop counts are not read by this slice; they join by the same rule only if a later slice needs them.
- **The counting recorder.** When the option is set, both native QUIC configurations install a `Tracer`. It returns one small counting trace per connection, which the readout finds through `Conn.QlogTrace()`.
  - `AddProducer` returns a recorder that shares the trace's counters.
  - `SupportsSchemas` reports true for `qlog.EventSchema` only.
  - `RecordEvent` counts a PTO expiry for each `qlog.PTOCountUpdated` whose `PTOCount` is above zero (zero records are resets) and a spurious loss for each `qlog.SpuriousLoss`. For each `qlog.MetricsUpdated` with a non-zero `LatestRTT`, it adds that value to `RTTSum` and one to `RTTSamples`. It ignores every other event, using only atomic adds: no lock, no allocation, no blocking, no goroutine.
  - Because `MetricsUpdated` sets `LatestRTT` only when it changed, an RTT sample equal to its predecessor is not counted, and the mean is over changed samples (**source**).
  - The counts cover the connection's whole life, including setup before promotion. The exception is the fork's anti-deadlock PTO during the handshake, which records no event.
  - The recorder makes the fork build and pass every qlog event on every guarded site. Rows taken with it are comparable only with rows taken under the same setting, so both A/B arms enable it identically ([H4](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
- **Consumers.** Task 4.R makes the rig import the seam in rig-branch commits, which never go into a main PR. It shows both drop counts, each absent when not present, and computes mean RTT from `RTTSum`/`RTTSamples` deltas. Slice 5.1's dependency evidence record reads both drop counts through it. This slice makes no rig commit.

**Zero cost when not enabled, and the evidence.** In a process that never enables readouts, the slice adds no per-packet, per-datagram or per-read work:

- (a) Both QUIC configurations keep `Tracer` nil. The fork then creates no recorder (`connection.go` L300–L302, L426–L428), and every qlog emission site is skipped by its `qlogger != nil` guard (for example `sent_packet_handler.go` L565–L572 and L983–L994).
- (b) `Commit` makes one branch on a field captured at `New` and registers nothing.
- (c) The PR changes no file on the packet or Datagram path: `internal/nativequic/packetconn.go`, `internal/routeselection`, `internal/datagramadmission`, and the carrier's send and receive methods. The PR's diff stat shows this.
- (d) Statistics and counts are read only when `ReadoutFor` is called, as atomic loads in the fork.

Tests pin (a) and (b). No rig A/B is run, because no hot-path code changes. A hot-path change found in review is a stop condition, not a reason to add a campaign.

### Where the rule lives and what it says (3.2)

Decision 2 of [Should native throughput targets require consumer headroom, or should wiremux pursue a scheduler fix?](https://github.com/GridSwarm/wiremux/issues/1867#issuecomment-6245076072) (the headroom decision below), verbatim:

> 2. **The rule's form: one free processor, as the stall guard only.** In each peer's process, goroutines that never wait on a channel, lock, timer, system call or network I/O stay below `GOMAXPROCS`. For example, a CPU-bound worker pool is sized at `runtime.GOMAXPROCS(0) - 1` or fewer. Stated against `GOMAXPROCS`, the rule follows a Linux container's CPU limit or a pinned process automatically, since Go lowers `GOMAXPROCS` to match. The per-platform targets are stated as measured with an otherwise idle consumer and are published with the busy-consumer table below, its default-GC row included. A stricter rule (about four free processors, with targets certified under that load) was rejected. No headroom short of an idle consumer gives the target rate, and the trade between the consumer's own work and the Wire's rate is the consumer's to make.

Decision 3, verbatim:

> 3. **Scope: measured for native Wires, with a note for the others.** The rule is stated for native Wires, where it was measured. One sentence beside it says the cause is Go's scheduler, so other QUIC-carried Wires (the upgraded direct `transport/quic` path, QUIC over TURN) very likely stall the same way: they run the same quic-go read loop, parked on Go's network poller (**source**, unmeasured). Nothing is measured for them on this map. The reliable relay fallback rides kernel TCP, which acknowledges without the application, and no claim is made for it.

"Where it lands", verbatim: "The rule goes in the Go doc comments for the native entry points and for the count. `COMPATIBILITY.md` records the count as an additive API, as it does every API, with no throughput promise." and "The table travels with the targets that [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801) publishes."

How this program places it ([H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)):

- **Godoc.** The rule's two sentences and the scope sentence go on `NewNativeEndpoint` and `NativeCandidate.Promote` in 3.2, and on the count in 3.3. Godoc carries no figures, because godoc is contract (COMPATIBILITY L7) and the figures are not.
- **Glossary.** Two of the headroom decision's three terms (Never-blocking goroutine, Processor headroom) go into `CONTEXT.md` with its wording in 3.2. The third, Late read, ships with the count in 3.3 ([H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
- **Figures.** Every figure lives only in `docs/NATIVE-THROUGHPUT.md`. One sentence in COMPATIBILITY's native section says those figures are measured statements, not compatibility promises.
- **Where the count is mentioned.** 3.2's godoc, glossary and targets doc do not name the late-read count, so they stay true if 3.3's gate fails. 3.3 adds the count's godoc, the Late read term and one pointer sentence in the targets doc.

### What the targets doc publishes (3.2)

The method is the one the targets decision's section 4 sets:

- **Unit:** "one native Wire at MTU 1500, at the cells' sub-millisecond round trip, packets per second first, with Gbit/s for Datagrams and the stream. Datagrams run at the pin (`-ballast 64 -gc-role both`), with the default-GC row reported beside it."
- **Host state:** "Certified with an otherwise idle consumer, under the headroom rule". The busy-consumer table is "taken from the existing measurements, each row labelled with the shape it was measured on, not re-measured".

Each platform's floor is published verbatim, marked "target, not yet certified". The certification slices ([H17](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)) change only their platform's per-table Status line and its row in the certification-status table. A floor that misses keeps its target wording, and its row states the pooled figure, "missed" and the diagnosis issue's link. Nothing is reverted ("each slice has its own gate and the target is their sum, so a certification below a floor files a diagnosis issue and reverts nothing").

No target is stated for a loaded consumer or a loaded receiving Mac. The receiving-Mac row is a measured statement in the busy-consumer table: the receiver-class ticket ([Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?](https://github.com/GridSwarm/wiremux/issues/1868#issuecomment-6251637328)) reopens when "[Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801) needs a busy receiving Mac's rate. That means a macOS target stated for a loaded receiver, or the busy-consumer table's receiving-Mac row being the one that misses." The full content is in slice 3.2 below.

### What a late read is and how `Wire.Native()` reports it (3.3)

**Deferred:** The definition and design below are retained for reference. The [2026-10-23 deferral](#slice-33--late-read-count-on-wirenative) suspends execution; this section is not a dispatch instruction.

The headroom decision's decision 4, verbatim:

> 4. **A starvation signal ships, publicly.** It is an additive running count of late reads on the native Wire's copied info snapshot (`Wire.Native()`), documented next to the rule, with no events, goroutines or logging. A late read is a read on the native binding whose datagrams waited in the kernel past a threshold because the read loop wasn't scheduled. At the cliff the sender read acknowledgments 65 times a second instead of 47,800, with about 51 gaps of 8 ms or more each second (**measured**, #1865). Telling that apart from an idle Wire is **derived** and not built. Gate: the count climbs at the cliff (`GOMAXPROCS` never-blocking goroutines, on `tb` and in `netns`) and stays flat on an idle Wire and under the 12-of-16 load; the packaging sets the threshold. The received-Datagram discard count ([…](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507)) is internal because it serves wiremux's own tuning. This one is public because only the consumer can act on it.

The packaging sets the open points ([H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)):

- **The field.** `NativeWireInfo.LateReads uint64`, appended after `Dialer`. `Wire.Native()` reads it live when called; the other fields stay the copy made at promotion.
- **The definition.** A late read is a read on the promoted Wire's binding whose oldest datagram's **kernel receive timestamp** is at least **5 ms** older than the read's return, and which returns at least **5 ms** after the binding's previous returning read. The threshold is a constant, not a setting, and both comparisons use it.
  - "Read" means one return of the binding's receive owner (`ReadUnicastBatch`) that hands datagrams to QUIC.
  - "Oldest datagram" means the oldest of the datagrams that read returns.
  - "Previous returning read" means the last earlier read on that binding that handed datagrams to QUIC; the first read after arming has none, so only its datagram's wait decides it.
  - A read counts at most once.
  - Why both conditions (operator decision, 2026-10-20, from slice 3.3's smoke check): a datagram's wait alone also counts a healthy Wire receiving at its full rate, whose datagrams wait in the socket's receive queue while its read loop runs back to back. The `tb` smoke counted 139–17,252 such reads a second on idle-consumer receivers at 1.2–1.4 Gbit/s. A starved read loop is absent, so its read both returns late and returns long after the previous one; a backlog read returns right after the previous one; an idle Wire's datagram does not wait. With both conditions, a throwaway prototype counted 0 on every healthy and idle run and 14–28 a second on both peers at the cliff ([evidence](https://github.com/GridSwarm/wiremux/issues/1924#issuecomment-6283847083)).
- **When counting starts.** Reads before promotion don't count. The binding is armed at `Promotion.Commit`, which also answers ADR-0016's per-Wire bookkeeping concern. A read that overlaps arming may or may not count.
- **Platforms.** A platform whose binding socket gives no kernel receive timestamp reports zero, and the godoc says so. Preflight checks Windows.
- **Behavior after close.** The count never decreases and keeps its final value after the Wire closes.
- **What the detector must not change.** It adds no events, goroutines, timers, logging or settings. It changes neither admission verdicts nor the control bytes QUIC receives.
- **COMPATIBILITY.** `LateReads` is recorded as an additive API with no throughput promise. Because `NativeWireInfo` is an exported struct a consumer can write as an unkeyed literal, the field is also recorded as that section's explicit exception to the compatible change rule (COMPATIBILITY L13–L15). The API manifest is regenerated.

**The gate**, all on the PR head unless marked A/B:

- **Climb and flat rows**, verbatim from the headroom decision: the count "climbs at the cliff (`GOMAXPROCS` never-blocking goroutines, on `tb` and in `netns`) and stays flat on an idle Wire and under the 12-of-16 load".
- **No-harm row (handoff decision [H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions))**, A/B: "receiver throughput no worse than −1% and receiver CPU per GiB no more than +2% with the detector against without, on `tb` and `netns`".
- **If the gate fails:** "If 3.3's gate fails, it does not merge; 3.2 already shipped; file a diagnosis issue."

### Rejected directions

**Rejected alternative (do not do this):** fix the starved read loop instead of documenting a rule: a read loop locked to its thread, busy polling, fewer goroutines per packet, or a Go runtime that polls the network from the scheduler. The headroom decision, decision 1: "A read loop locked to its thread would lift a collapsed Wire from a few Mbit/s to tens … Busy polling and fewer goroutines per packet don't help at the cliff. The only fix found, a Go runtime that polls the network from the scheduler ([golang/go#51651](https://github.com/golang/go/pull/51651)), is upstream Go work that wiremux can't ship to consumers." **Revisit if:** someone proposes the runtime change ("the evidence stays in the note for anyone who proposes it"), or, as a handoff decision, upstream Go merges network polling from the scheduler.

**Rejected alternative (do not do this):** a stricter rule of about four free processors, with targets certified under that load. "No headroom short of an idle consumer gives the target rate, and the trade between the consumer's own work and the Wire's rate is the consumer's to make." **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** have the library set `GOMAXPROCS`. The headroom ticket's [issue body](https://github.com/GridSwarm/wiremux/issues/1867): "The library setting `GOMAXPROCS` is rejected: it is process-wide and the cliff moves with it." **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** expose a general public readout API, `ConnectionStats`, or other drop counts. Slice 3.4 exercises #1828's consumer-action trigger for the received-DATAGRAM full-queue count alone, superseding the internal-only decision only for that count. H4's measurement registry and recorder retain their internal contract. **Revisit if:** a consumer would act on another count, through a separately approved amendment.

**Rejected alternative (do not do this):** read the counts *only* in `internal/measurement`, instead of a native-Wire seam. That package is the `wiremux-measure` engine: its raw-QUIC layer owns its own transport and tracer and never holds a native Wire, so a reading there alone cannot serve the rig or the repin record. Its own reading of both drop counts, absent rather than zero on upstream, stays as the queue decisions decided ([H24](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)) and is delivered by slice 5.1. **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** probe worktrees per gate (one-line fork or wiremux patches that print counters), as earlier research used. Every bundle gate needs the same readouts, and unreviewed probes drift between gates. **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** a fork counter for PTOs and spurious losses instead of the qlog recorder. A counter needs a fork method that no decided bundle slice carries, while the qlog events already exist in every QUIC module wiremux builds against. **Revisit if** (handoff decision): a gate's PR shows that the recorder's own cost, with both arms enabled identically, hides the effect the gate measures.

**Rejected alternative (do not do this):** an environment variable or a `NativeConfig` field to switch the readouts on. Either becomes a consumer-visible knob, which is public behavior in all but name. **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** detect starvation from gaps between read-loop wakeups alone. "Telling that apart from an idle Wire is **derived** and not built": a gap can't tell a scheduler stall from a Wire with no traffic, while a kernel receive timestamp measures the datagram's own wait. The adopted definition uses the gap only together with the datagram's wait, which an idle Wire never meets. **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** make the late-read threshold a setting, count reads before promotion, or report late reads through events, goroutines or logging. [H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions) fixes the threshold as a constant and arms counting at promotion. The headroom decision says "with no events, goroutines or logging". **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** publish the targets in `COMPATIBILITY.md` (they would read as promises, which the headroom decision avoids) or in `docs/MEASUREMENT.md` (the `wiremux-measure` tool guide). **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** re-measure the busy-consumer rows on the final stack. "Re-measuring those rows on the final stack would cost more than certifying the floors and wouldn't change what a consumer is told." **Revisit if:** the receiver-class ticket's own trigger fires, quoted from [Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?](https://github.com/GridSwarm/wiremux/issues/1868#issuecomment-6251637328): "[Decide what closing the gap means on each platform] needs a busy receiving Mac's rate. That means a macOS target stated for a loaded receiver, or the busy-consumer table's receiving-Mac row being the one that misses."

**Rejected alternative (do not do this):** ship the count and the docs as one slice, as the headroom decision's "Execution is one wiremux-only slice" first framed it. "The late-read detector isn't built; its gate decides whether it ships", while the rule and targets ship regardless, so one PR would make the docs wait on the detector's gate ([H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). **Revisit if:** none: rejected on merit.

### Owner's design

**Owner's design:** Slice 3.1 is a contained design: a side registry and a tracer installed beside the promotion. The state owner of the native connection is `internal/nativequic.Promotion`, reached from the root `Wire` through its carriers. If the public interface were open, the owner would hand readouts out through the Wire itself, for example as live fields on `NativeWireInfo` or a diagnostics method on `Wire`. That needs no enable switch, no address-keyed registry and no lifetime of its own. For the general measurement readouts this design is not adopted, because [H4](2026-10-19-native-gap-handoff-audit.md#handoff-decisions) and the two queue decisions keep these readouts internal (no public API), and that remains outside this program's boundary except for 3.4's narrowly approved count. Relative to it, the contained design adds three obligations:

- **Enable before create.** A borrowed ordering: readouts cover only endpoints created after `EnableReadouts`. A test pins it, and a comment records it.
- **A mirrored association.** The registry maps `(Local, Remote)` to a committed connection from `Commit` until `Close`. It copies the same `Candidate.info` facts the root copies into `NativeWireInfo`, so the two agree by construction. A lookup that races `Close` returns either a readout or `false`, and both are acceptable for a verification aid.
- **A tracer on fork goroutines.** With the recorder option, the counting trace runs on the fork's goroutines and must stay non-blocking and allocation-free.

Slice 3.3 changes the owner itself: the binding's receive owner counts, and the root reads it. Slice 3.2 is documentation. Neither has an owner's-design question.

### Non-goals

- No general public readout API, no public drop counts beyond 3.4's two fields, and no public PTO or RTT figures.
- No change to `internal/measurement` in this track; its own reading of both drop counts is slice 5.1's ([H24](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
- No fork change and no fork release ([H3](2026-10-19-native-gap-handoff-audit.md#handoff-decisions): Phase-1 slices need none; 3.1's presence check runs against fork main through a throwaway module file only).
- No rig change in 3.1 (task 4.R makes the rig commits). 3.3's rig prep step is one rig-branch commit, never merged.
- No `GOMAXPROCS` setting and no consumer-side scheduling help.
- No re-measurement of busy-consumer rows, and no target for a loaded consumer or receiving Mac.
- No figures in godoc or COMPATIBILITY, and no COMPATIBILITY promise about throughput.
- No `CI_DOCS_GLOBS` change: the targets doc stays out of the glob, like the `docs/` root topic docs the glob omits (`SELECTED-RELAY.md`, `MANAGED-MIGRATION.md`, `MEASUREMENT.md`). No new CI lane ([H20](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
- No late-read events, goroutines, timers, logging or settings, and no change to admission.
- No change to the received control bytes QUIC or `binding` callers see, and no timestamps requested on public `binding` sets.
- No optional counter in 3.1 beyond `DatagramReceiveDropsV1`, plus the unprocessed-queue count only if the fork named it before 3.1's preflight ([H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
  - Slices 5.1, 5.4 and 6.2 add the unprocessed-queue, guard-trip and send-hook counts on main.
  - Slices 6.3, 6.4 and 2.2 add their wiremux-owned binding counters.
  - Gate tasks 4.G1, 4.G5 and 4.G6 use unmerged scratch builds carrying the addition.
- ADR-0016's counts are not read by 3.1.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 3.1 | Complete | Internal, off-by-default readouts of a promoted native Wire's QUIC facts (stats, the fork's optional drop counts, PTO and spurious-loss counts) for the rig and the dependency evidence record | None | n/a (a maintained verification aid with a retirement policy) |
| 3.2 | Complete | Headroom rule in native godoc, two `CONTEXT.md` terms (Never-blocking goroutine, Processor headroom), `docs/NATIVE-THROUGHPUT.md` with targets marked "target, not yet certified" and the busy-consumer table, README and COMPATIBILITY pointers | None | n/a (introduces the conditional macOS launch-context wording, which 6.2 removes) |
| 3.3 | Deferred; [revisit conditions](#slice-33--late-read-count-on-wirenative) | Public `NativeWireInfo.LateReads` read live at `Wire.Native()`, counted by the binding from kernel receive timestamps after promotion, with the Late read `CONTEXT.md` term, gated on climb/flat and no-harm rows | 3.2; [#1880](https://github.com/GridSwarm/wiremux/issues/1880) closing | n/a |
| 3.4 | Complete in [#2006](https://github.com/GridSwarm/wiremux/pull/2006) | Public cumulative received-DATAGRAM full-queue discard count and availability on `Wire.Native()` | 5.1 / [#1925](https://github.com/GridSwarm/wiremux/issues/1925) (complete) | n/a |

3.1, 3.2 and 3.4 are complete. Slice 3.4 / #1969 merged in [#2006](https://github.com/GridSwarm/wiremux/pull/2006), with [journal #2007](https://github.com/GridSwarm/wiremux/pull/2007). Slice 3.3 / #1924 is deferred, not an active frontier or a release/certification blocker. If revived, shared edits to `Wire.Native()` and `NativeWireInfo` require rebase/review coordination with the completed discard count, not a dependency on reimplementing it.

- 3.1 and 3.3 both touch `internal/nativequic/promote.go`. 3.3 shares `native_promotion.go` with Track 1 and the binding read path with Track 2 and [Native Wire: a route refusal or a briefly unassigned source address ends the connection instead of dropping the datagram](https://github.com/GridSwarm/wiremux/issues/1880) (the ADR-0016 implementation).
- 3.1 and 3.2 land before or after that implementation's second PR, in either order, re-anchoring by function at preflight. 3.3 waits for the issue to close.
- Otherwise there is no blocking edge, but the ruleset forces up-to-date branches, so these merges happen one after another.

## Implementation Slices

### Slice 3.1 — Internal native connection readouts for the rig and the evidence record

**Current state:** Complete. [Child #1922](https://github.com/GridSwarm/wiremux/issues/1922) delivers the readout seam, and [Task 4.R](https://github.com/GridSwarm/wiremux/issues/1936) is ready. Fork `main` named no unprocessed-queue drop method by this slice's preflight, so the seam reads only `DatagramReceiveDropsV1`, and slice 5.1 adds the unprocessed-queue count.

**What it delivers:** The readout seam in `internal/nativequic`, exactly as "What the readout seam exposes, and to whom" defines it:

- The process-wide enable with its recorder option, captured per endpoint at `New`, plus the test-only reset.
- Registration at the end of `Promotion.Commit` and removal when `Promotion.Close` begins, keyed by `(Local, Remote)`.
- `ReadoutFor`, returning a copied `Readout`: the connection's `ConnectionStats()`, and as `Count{Value, Present}` the fork's `DatagramReceiveDropsV1` and, if the fork has named it on fork main at preflight, the unprocessed-queue drop count.
- The counting qlog trace, installed as `Tracer` in both native QUIC configurations only when the recorder option is set. It counts PTO expiries (`PTOCountUpdated` with a count above zero) and spurious losses (`SpuriousLoss`).

The seam compiles and its unit tests run on the ordinary upstream graph; native cases run in the fork lane. A sketch of the contract (names may change, semantics may not):

```go
type ReadoutOptions struct{ Recorder bool }
func EnableReadouts(ReadoutOptions)                       // before creating endpoints
type Count struct{ Value uint64; Present bool }            // absent is never zero
type Readout struct {
	Stats                        quicgo.ConnectionStats
	DatagramReceiveDrops, UnprocessedDrops Count
	PTOs, SpuriousLosses         Count // Present only with Recorder
	RTTSum, RTTSamples           Count // ns and samples; Present only with Recorder
}
func ReadoutFor(local, remote netip.AddrPort) (Readout, bool) // key from Wire.Native()
```

**Existing-work disposition:** New slice.

- No branch or PR implements it.
- Earlier research read counters through never-pushed probe worktrees (for example the Windows coalescing research's probe fork copy and binding counters). Those probes are not adopted.
- `internal/measurement`'s gated qlog trace ([`profile.go` L45–L80](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/measurement/profile.go#L45-L80)) is a house-style reference for wrapping `qlogwriter.Trace`, not a dependency.
- Recheck at preflight for any overlapping PR.

**Blocked by:** None.

**Single owner after merge:**

- `internal/nativequic` owns the enable state (captured per endpoint), the readout registry (`Promotion.Commit` registers, `Promotion.Close` removes), the counting trace and the optional-counter detection.
- The selected QUIC module owns every value read: `ConnectionStats` atomics, `DatagramReceiveDropsV1`, the qlog events and their meaning.
- The rig (through task 4.R) and slice 5.1's record are consumers only.

**Authority completeness:**

- No persisted fact and no authority; every readout is a copy.
- Constructors: `New` captures the setting; the two config builders consult the endpoint's captured setting; `Commit` registers; `Close` removes.
- Restart round trip: not applicable.
- Destructive consumers: none. The seam exposes no connection, stream or mutating method, so a consumer cannot close, send on or reconfigure a Wire through it.

**Transitional-seam budget:** None retained by this slice. The registry and recorder are a maintained verification aid, retired as stated under Artifact classification, and no adapter, duplicate representation or temporary path is introduced for later removal. The seam's later additions are owned elsewhere ([H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)):

- fork counters by interface assertion:
  - slice 5.1 adds the unprocessed-queue drop count, unless fork slice 5 named it before this slice's preflight;
  - slice 5.4 adds the Windows guard-trip count;
  - slice 6.2 adds the send-hook outcome;
- wiremux-owned binding counters, reached through the promoted Wire's candidate binding reference:
  - slices 6.3 and 6.4 add the fallback reason, list-path calls, absorbed ICMP drops and truncated-slot counts;
  - slice 2.2 adds the connect-failure count.

Gate tasks 4.G1 (unprocessed drops), 4.G5 (its gate-build packer-discard count) and 4.G6 (guard trips) need a counter before its product slice. They use a scratch build carrying that seam addition, never merged. Each addition keeps this slice's contract: a `Count` that is absent rather than zero, no connection or binding handed out, and no public API.

**Blast radius:**

- **Obligations added.**
  - (1) The enable-before-create ordering, a borrowed fact: endpoints capture the setting at `New`, so a later `EnableReadouts` does not reach them. A comment records it, and a test pins it.
  - (2) The registry's `(Local, Remote)` → connection association, valid from commit until close. It copies facts the root also copies, and they agree by construction from `Candidate.info`. A lookup racing `Close` returns a readout or `false`.
  - (3) The counting trace's counters: atomic adds on fork goroutines, which must never lock, allocate or block.
- **Obligations removed:** none.
- **Shared state:** one process-wide setting read only at `New`, and one registry under its own mutex.
- **Concurrency:** no new goroutine. `RecordEvent` runs on the fork's connection goroutines, as `qlogwriter.Recorder` permits.
- **Interfaces and schema:** none public. The API manifest is unchanged. The `qlog` and `qlogwriter` imports are already in the module graph (`internal/measurement/profile.go` L13–L15).
- **Failure handling:** "not found" is an ordinary result, never an error that ends a Wire.
- **Performance:**
  - Disabled: zero per-packet, per-datagram and per-read cost (see "Zero cost when not enabled" in Decision).
  - Enabled without the recorder: one registration per promotion.
  - With the recorder: the fork's qlog event construction on every guarded site, so rows are comparable only under the same recorder setting.
- **Security:** no consumer-reachable switch.
- **Dependencies:** none new.
- **Files shared with other slices:** `promote.go` and `endpoint.go` with slices 1.2 and 1.3; merges happen one after another, with no edge.
- **Untraced effect, flagged:** whether this branch builds and runs against fork main `5b05133d` for the presence check (see Stop conditions).

**Artifact classification:**

- The seam is a **verification aid approved as a blocking maintained deliverable**: it blocks task 4.R and slice 5.1.
  - The owner's approval is section 5 of [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797): "The rig gains RTT, PTO and spurious-loss readouts before those gates run". [H4](2026-10-19-native-gap-handoff-audit.md#handoff-decisions) is the packaging step that places the readouts in `internal/nativequic`.
  - Payoff: the bundle consumer gates' RTT (including the mean over a window), PTO, spurious-loss, drop-count and stream-packet readouts, and the repin record's reading of both drop counts on real native Wires.
  - Supported domain: committed promotions of native endpoints created after `EnableReadouts` in a fork-lane test or rig process.
  - Owner: `internal/nativequic`.
  - Retirement: Track 7's last reconciliation, after the last of 7.1–7.3 merges, files the removal issue. The seam is removed once no gate task, evidence record, certification or open plan reads it, or it is replaced by a public diagnostics API if one is ever decided.
- Its tests are ordinary verification aids with no recursive completeness obligation.
- The journal entry and tracking updates are process and traceability metadata.

**Representation contract:**

- **Supported input domain:** promotions committed by endpoints created after `EnableReadouts`, on any QUIC module wiremux builds against (later binding counters, [H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), read the promoted Wire's own binding):
  - upstream v0.62.0: stats present, optional counts absent;
  - fork `v0.62.1-fast.7`: the same;
  - fork main `5b05133d`: `DatagramReceiveDrops` present.
- **Representation owner:** the selected QUIC module's `ConnectionStats` struct, its optional methods and its qlog event types. wiremux copies values and never derives or rescales them.
- **Guarantee:**
  - Universal for the seam's own invariants, each enforced in one place:
    - an absent optional count is `Present: false`, never zero (the `Count` type);
    - nothing is registered or traced on an endpoint created without readouts (the capture at `New`);
    - no entry outlives `Close` (removal in `Close`).
  - Example-level for the fork's values, whose meaning the fork owns.

**Contract closure:** Not triggered. A wrong or missing readout misleads a gate, which is a verification aid. It carries none of the material consequences that trigger closure: no security boundary, data loss, irreversible state, public compatibility break or shipped lifecycle obligation. The seam has one registration point, one removal point and one lookup. Ordinary focused tests cover them.

**Evidence budget:**

- At most eight new test cases:
  - (1) With readouts never enabled, both QUIC configurations have a nil `Tracer`, and a committed promotion is not found. Ordinary graph and fork lane.
  - (2) With the recorder off: the `Tracer` is nil, and a promotion is found with stats present and `PTOs`/`SpuriousLosses`/`RTTSum`/`RTTSamples` absent.
  - (3) The counting trace counts `PTOCountUpdated` records above zero, ignores zero records and every other event, counts `SpuriousLoss`, and sums non-zero `MetricsUpdated.LatestRTT` values into `RTTSum`/`RTTSamples` while ignoring zero ones. Ordinary graph, synthetic events.
  - (4) Optional-count detection reports present-with-value and absent through an internal helper over fakes. Ordinary graph.
  - (5) Fork lane at fast.7: a loopback pair promoted through the public API, with readouts and the recorder enabled, after a stream write and a Datagram exchange, is found under the dialer's and the listener's `Wire.Native()` keys. `PacketsReceived` is above zero, `SmoothedRTT` is above zero, `DatagramReceiveDrops` is absent, and `PTOs` and `RTTSamples` are present with `RTTSamples` above zero.
  - (6) After `Close`, the same key is not found.
  - (7) An endpoint created before `EnableReadouts` registers nothing and installs no tracer.
  - (8) One presence run against fork main `5b05133d`: `DatagramReceiveDrops` is present, with its value recorded in the PR.
- Runs:
  - the ordinary-graph package tests, once with `-race`;
  - the fork lane at fast.7 once on macOS (mbp128 or m4mini) and once on Linux (minimax or the Linux CI image);
  - the fork-main presence run once, on either platform.
- No rig campaign, no Windows run (the seam has no platform code) and no guard mutation.
- One review plus at most one replacement after accepted fixes. Terminate when these pass with no open stop condition. This budget does not limit the repository's required gates.

**TDD and preservation evidence:**

- Write cases (1)–(4) first, on the ordinary graph, then (5)–(7) in the fork lane and (8) last.
- Preservation, each run unchanged:
  - the existing `internal/nativequic` and root native suites in the fork lane under `-race`, including [`TestNativePromotionRoundTrip`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native_promotion_test.go#L240) and [`TestDatagramCarrierAdmissionCancellable`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/promote_test.go#L33);
  - `go test ./internal/compatmanifest -run Baseline`, which proves no public declaration changed;
  - the ordinary-graph test that native construction refuses before any socket exists.

**Dispatch context budget:** Target at most 38,000 input tokens:

- this plan's Current Shape and Decision, and this slice;
- `internal/nativequic/endpoint.go` L141–L245 and L638–L677, `promote.go` L175–L338 and L370–L425, `candidate.go` L54–L122, `capability.go`;
- root `native_promotion.go` L77–L103 and L330–L351, and `native_promotion_test.go` L29–L240 (helpers);
- the fork's `connection.go` L836–L889 and L2998–L3000 at fast.7 and L2996–L3006 at main, `qlog/event.go` L463–L569, `qlogwriter/writer.go` L15–L46, and the emission sites in `sent_packet_handler.go` (L344–L389, L565–L572, L962–L994);
- `internal/measurement/profile.go` L45–L80 as style;
- the repository review and CI overlays.

No governing diff is needed for a new slice. One owner-level change with this test surface fits implementation, fixes and verification in one fresh context. Re-audit if it does not.

**Slice decision audit:**

- **Strongest split:** statistics and counters in one PR and the qlog recorder in another. Rejected: both serve the same gates and share the registry, and a second PR would add a second registration path for no independent value.
- **Strongest merges:**
  - Into task 4.R. Rejected: rig commits never go into a main PR (PROTOCOL.md L5–L15), and 4.R needs a merged seam to import.
  - Into slice 5.1. Rejected: the bundle consumer gates need the readouts before the release exists.
  - Into 3.3. Rejected: 3.3 is a public, gated binding change in another owner.
- **Owner's design:** recorded above and rejected by scope (no public API). The obligations the contained design adds are listed.
- **Blocking edges:** none come in. 4.R and 5.1 depend on this slice because they read through it. The later counter additions ([H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)) depend on it only in the slices that make them.

**Stop conditions:** Stop and return for a decision if:

- the rig cannot reach a readout using only `Wire.Native()`'s public facts and the internal import;
- any readout would require handing out the connection or a mutating method;
- the disabled path would need any per-packet, per-datagram or per-read code;
- the fork's event sequence no longer lets PTO expiries be told apart from resets;
- a public declaration or the API manifest would change;
- the fork's unprocessed-queue method exists at preflight but is not a no-argument method returning `uint64`. In that case leave it for its own later entry, and stop only if a consumer needs it now.

If this branch does not build against fork main for reasons outside this slice, record the failure in the PR, rely on case (4) for presence and do not patch the fork or wiremux to make it build. 4.R's first fork-main gate build then shows presence on a real connection.

### Slice 3.2 — Processor headroom rule docs, glossary terms and the published targets doc

**Current state:** Complete. [Child #1923](https://github.com/GridSwarm/wiremux/issues/1923) delivers the headroom godoc, the two `CONTEXT.md` terms and [`docs/NATIVE-THROUGHPUT.md`](../NATIVE-THROUGHPUT.md) with every platform at "target, not yet certified", and [Slice 3.3](https://github.com/GridSwarm/wiremux/issues/1924) is deferred. Slice 1.2 merged first, so the macOS payload note states its shipped ceiling.

**What it delivers:** Documentation and doc comments only. No behavior or declaration change.

- **Godoc.** [`NewNativeEndpoint`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native.go#L113-L119) and [`NativeCandidate.Promote`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/native_promotion.go#L217-L254) each gain one paragraph:
  - the headroom decision's rule sentences (decision 2: "In each peer's process, goroutines that never wait on a channel, lock, timer, system call or network I/O stay below `GOMAXPROCS`. For example, a CPU-bound worker pool is sized at `runtime.GOMAXPROCS(0) - 1` or fewer.");
  - the container/pinning sentence;
  - decision 3's scope sentence (other QUIC-carried Wires very likely stall the same way, unmeasured; no claim for the relay fallback);
  - a pointer to `docs/NATIVE-THROUGHPUT.md` in the wiremux repository.
  - The paragraph carries no figures and does not name the late-read count.
- **Glossary.** `CONTEXT.md` gains two terms with the headroom decision's definitions verbatim, placed with the native terms after **Binding loss** ([L251–L253](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/CONTEXT.md?plain=1#L251-L253)). `_Avoid_` lines may be added in house style:
  - **Never-blocking goroutine**: "a goroutine that runs without ever waiting on a channel, lock, timer, system call or network I/O. One that waits even briefly in each period is not one."
  - **Processor headroom**: "at least one of a process's Go processors (`GOMAXPROCS`) not held by a never-blocking goroutine. A native Wire's rate assumes it."
- **The targets doc.** A new `docs/NATIVE-THROUGHPUT.md` with exactly the content below.
- **README.** One "Start Here" bullet (README L90–L101): "`docs/NATIVE-THROUGHPUT.md` states native Wire throughput targets, the processor headroom they assume and measured effects of a busy consumer.", with the file name as a link to the new document.
- **COMPATIBILITY.** One pointer sentence as its own paragraph at the end of `COMPATIBILITY.md`'s "Native promotion" section ([L123–L125](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/docs/COMPATIBILITY.md?plain=1#L123-L125)): "Native throughput figures in `NATIVE-THROUGHPUT.md` are measured statements, not compatibility promises.", with the file name as a link to the new document.

**Targets doc content (normative).** Each figure keeps its **measured**/**derived**/**source** label and links its source comment or research note. Tables marked verbatim are copied exactly.

1. **What a figure means.**
   - The unit sentence (the targets decision's section 4, verbatim, as in Decision).
   - "Certified with an otherwise idle consumer, under the headroom rule" (section 3 of this doc).
   - **Link types**, verbatim: "stated for MTU-1500 paths (Ethernet, Wi-Fi, Thunderbolt Bridge, the internet). On a slower link the link is the limit (**derived**, not certified). Relay paths aren't native and aren't covered."
   - **Long round trips**, verbatim: "Native connections keep quic-go's 6 MiB stream window, about 0.63 Gbit/s at 80 ms (**derived**)."
   - The miss rule, verbatim: "each slice has its own gate and the target is their sum, so a certification below a floor files a diagnosis issue and reverts nothing."
   - One sentence: the figures are measured statements, not compatibility promises.
2. **Per-platform targets.** Each table verbatim, each followed by "Status: target, not yet certified." (its certification slice updates this line) and its notes.
   - **macOS** (`tb`: two Apple-silicon Macs over a Thunderbolt Bridge at MTU 1500, macOS 27 arm64 both ends), from [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) section 2:

     | Floor (one native Wire, `tb`, idle consumer) | Packets/s | Gbit/s |
     | --- | ---: | ---: |
     | Datagrams at the pin | ≥ 420k | ≥ 4.7 at 1,397-byte Datagrams |
     | Stream | ≥ 440k | ≥ 4.8 |

     - Notes, verbatim: "Datagrams are certified at the payload in force, 1,397 bytes once the ceiling slice … lands. Packets per second are the macOS invariant." Add that the native ceiling in v0.2.7 is 1,191 bytes (`MaxNativeDatagramPayload`) and that Slice 1.2 raises it to the value path MTU discovery gives (1,397 bytes at MTU 1500). If 1.2 has merged before this slice, state the shipped value instead; if this slice merges first, 1.2 updates the sentence.
     - The basis sentence: "all adopted macOS levers … measured 471k Datagrams/s … and 493k stream packets/s … pooled, and 437k and 460k in the slower campaign" (**measured**, probe stand-ins). "That is about 3.5× today's 126k packets/s (1.2 / 1.4 Gbit/s)."
     - The certification launch context, per the macOS launch-context section below.
   - **Linux** (`netns`: two Linux network namespaces joined by a veth pair on one host, MTU 1500, sender and receiver on different CCDs, no NIC offload), from section 3:

     | Floor (one native Wire, `netns` shape cell, idle consumer) | Gbit/s |
     | --- | ---: |
     | Datagrams at the pin | ≥ 10.0 at 1,397-byte Datagrams (about 895k Datagrams/s) |
     | Stream | ≥ 10.5 |

     - Notes, verbatim: "**These are estimates:** a shape cell with no NIC", and "minimax's 10 GbE card has no hardware UDP segmentation, so the real-NIC effect is unmeasured."
     - The floor's standing after the Linux Datagram lever decision, verbatim: "The Linux Datagram floor from [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) stands: ≥ 10.0 Gbit/s at 1,397-byte Datagrams (about 895k Datagrams/s) in the `netns` cell."
     - Packets per second are reported beside the stream's Gbit/s at certification.
   - **Windows** (a Linux host sending to a Windows Server 2025 VM on it, one virtual e1000e NIC with software URO), from [Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572) section 7:

     | Floor (one native Wire, every adopted lever) | Faster queue | Slower queue |
     | --- | --- | --- |
     | Datagrams at the pin, 1,024 queue | ≥ 300k/s | ≥ 225k/s |
     | Stream at the pin | ≥ 350k packets/s (≥ 3.8 Gbit/s) | ≥ 260k packets/s (≥ 2.85 Gbit/s) |

     - Notes, verbatim:
       - "The guest hashes flows onto two receive queues that run 25–33% apart, so a real flow lands on either."
       - "certified at the Datagram ceiling that ships by then (1,397 bytes after the ceiling change, so about 3.35 and 2.5 Gbit/s), plus one 1,191-byte row for continuity. The packet rate at 1,397 bytes is unmeasured."
       - The reported-only list: "the default-GC Datagram row (177k/s with URO and copy-at-read; GC-bound at Go's heap floor); a Windows sender (12k → 41k Datagrams/s with gluing, 44k stream packets/s); the Arm cell."
       - "**Limit:** all evidence is one virtual NIC without hardware URO. The size of the gain on a physical Windows machine is unknown."
   - **Certification status table.** One row per platform with columns Platform, Status, Certified figures, Reported only, Date, wiremux commit, Fork release, Evidence. Each row's Status reads "target, not yet certified" and its other cells read "–".
     - A certification slice updates only its platform's Status line and its row: certified figure per floor, reported-only cells, date, wiremux commit, fork release and a link to its record.
     - A missed floor's cell states the pooled figure, "missed" and the diagnosis issue's link, and the floor's target wording stays.
3. **Processor headroom.**
   - The headroom decision's rule sentences and container/pinning sentence (decision 2), verbatim.
   - "The per-platform targets are stated as measured with an otherwise idle consumer".
   - Decision 3's scope paragraph, verbatim.
   - wiremux never sets `GOMAXPROCS`, because "The library setting `GOMAXPROCS` is rejected: it is process-wide and the cliff moves with it." (the headroom ticket's issue body).
   - The measured mechanism in one sentence, from the busy-goroutine research: "a Go processor polls the network only when its run queues are empty … so the fork's read loop waits for the runtime's 10 ms background poll" (**source**, Go 1.27.2 `runtime/proc.go`).
   - The limits, verbatim from the headroom decision:
     - "`GOMAXPROCS` raised above the core count with never-blocking goroutines one below it (say 23 at `GOMAXPROCS` 24 on 16 cores) satisfies the rule but wasn't measured."
     - "Load in the receiving peer's process wasn't measured. The rule covers it by **source**, because its read loop parks on the same poller."
4. **Busy-consumer table.** Each group opens with its shape line verbatim from its source and links the source comment and research note.
   - **Busy goroutines in the sender's process.**
     - Shape, verbatim from the headroom decision: "(**measured** in [How many busy goroutines can a consumer run before its native Wire stalls, and what restores it?](https://github.com/GridSwarm/wiremux/issues/1865#issuecomment-6244783748); `tb` at `GOMAXPROCS` 16 unless noted, medians of three; the consumer's work is relative to the collapsed 16-goroutine run)".
     - The busy-goroutine research's run conditions, verbatim: "`tb`, macOS 27, default class, in-process load only; every sender in its own ssh session, daemon context; medians of three 10 s runs; percentages **derived**".
     - The table, verbatim. Its default-GC row is the "default-GC row" the targets decision's section 4 names:

       | Load in the sender's process | Native Wire's rate kept | Consumer's work kept |
       | --- | --- | --- |
       | 16 never-blocking goroutines (none free) | about 0.2% (4–7 Mbit/s) | – |
       | 15 never-blocking | 35–64% | 82–86% |
       | 12 never-blocking | 63–80% | 74–76% |
       | 12–15 never-blocking at Go's default GC (Datagrams) | 23–49% | – |
       | 16 goroutines busy half of each millisecond | no loss | – |
       | 16 goroutines busy 80% / 95% of each millisecond | 65–73% / 52–57% | – |
       | `GOMAXPROCS` 24–32 with 16 never-blocking | 44–58% | 78–82% |
       | Linux `netns`, `GOMAXPROCS` 4: 3 never-blocking / 4 | 55–58% / collapsed | – |

     - The table's limit, verbatim: "Every number is #1865's: integer-loop and timer-sleep load on one sending Mac and one Linux shape cell. A real pipeline blocks on channels and I/O, and allocates."
   - **Other programs on the sending Mac.**
     - Shape, verbatim from [Which realistic loads push the default-class native sender onto macOS efficiency cores?](https://github.com/GridSwarm/wiremux/issues/1857#issuecomment-6238637284): "`tb`, macOS 27, connected shape unless stated; every sender in its own ssh session, daemon context; medians of three 10 s runs; percentages **derived**".
     - Rows, figures verbatim:

       | Load on the sending Mac | Shape | Effect on the native Wire's rate | Source |
       | --- | --- | --- | --- |
       | 12–24 spinners in another coalition, default-class sender | connected | costs "11–22% (Datagrams at the pin) and 35–38% (stream)" | [1857](https://github.com/GridSwarm/wiremux/issues/1857#issuecomment-6238637284) |
       | 12–24 spinners in another coalition, default-class sender | batched-send and batched-receive | costs "15–34%" | [1801 input](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6238631145) |
       | 12–24 spinners in another coalition, user-initiated send thread (applies once the send-thread raise ships) | connected, batched-send and batched-receive | "busy and idle rates agree within −5% to +25%" | [1801 input](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6238631145) |

     - The limits, verbatim: "The loads are pure integer loops; a real pipeline blocks and allocates." and "Only the sender's Mac was loaded."
   - **A busy receiving Mac.**
     - Shape, verbatim from [Does load on the receiving Mac cost the native pair, and do its receive goroutine and run loop need a raised class?](https://github.com/GridSwarm/wiremux/issues/1866#issuecomment-6247562292): "`tb`, macOS 27; m4mini receiving, loaded with 0, 8 and 18 one-thread spinners in a separate ssh session's coalition; the sender idle with its send thread raised as adopted; every receiver in its own ssh session, daemon context; medians of three 10 s runs; percentages **derived**".
     - Rows, figures verbatim (Mbit/s at 0 → 8 → 18 spinners):

       | Stack | Datagrams at the pin | Stream | Note |
       | --- | --- | --- | --- |
       | Batched sends (receiver-bound idle) | 3,076 → 3,924 → 3,282 (+28%, +7%) | 3,555 → 4,159 → 3,769 (+17%, +6%) | ran faster under load (unexplained) |
       | Batched receives (sender-bound idle) | 4,697 → 4,631 → 3,959 (−1%, −16%) | 5,662 → 5,151 → 4,419 (−9%, −22%) | "the receiver becomes the wall" |

     - The discard sentence, verbatim from [the receiving-Mac input](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6247569062): "Under that load the 1,024-entry received-Datagram queue discards 0.3–2.4% of Datagrams with the receiver's goroutines at the default class, against ≤ 0.08% idle: the consumer's reader falls behind."
     - The sentence: no target is stated for a loaded receiving Mac.
   - The busy-consumer rows are not re-measured on the final stack, with the targets decision's reason quoted.
5. **macOS launch context**, from [Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6240861645) sections 1 and 4:
   - On Apple-silicon Macs, once wiremux adopts the fork's send-thread raise, every native Wire's send thread tries the user-initiated class.
   - "Who gets it", verbatim: "a launchd daemon or agent, an `ssh` session, or the frontmost app. A command started from Terminal or an IDE, or an off-screen app, cannot raise its class".
   - A Terminal- or IDE-started process therefore runs at the default class, and "A consumer's only remedy is how it launches".
   - Intel Macs and Linux get no raise.
   - Until the raise ships, every launch context runs at the default class.
   - The macOS target is certified with the sender launched over ssh or as a daemon (the raise's context), and a Terminal-launched default-class row is reported beside it.
6. **Not covered.**
   - Jumbo frames ([Future effort: jumbo frames for native Wires](https://github.com/GridSwarm/wiremux/issues/1872)).
   - Several paths per Wire ([Future effort: several paths per native Wire](https://github.com/GridSwarm/wiremux/issues/1873)).
   - The macOS sender past the batched-send list path ([Future effort: the macOS native sender past the batched-send list path](https://github.com/GridSwarm/wiremux/issues/1874)).
   - Long round trips ([Future effort: native Wires at long round trips](https://github.com/GridSwarm/wiremux/issues/1875)).
   - Relay paths.
   - A real Linux NIC ([Get representative Linux hardware for multi-Gbit/s measurement](https://github.com/GridSwarm/wiremux/issues/1799)).
   - A physical Windows NIC.
   - Windows connected sockets and batched calls.
   - A loaded consumer or loaded receiving Mac as a target.
   - Other QUIC-carried Wires (upgraded `transport/quic`, QUIC over TURN), which are unmeasured.
   - Slower links: no 1 GbE row is published.

**Existing-work disposition:** New slice. No targets document, branch or PR exists. The file name is the one [H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions) fixes, and the doc follows the `docs/` root topic-doc precedent indexed from README "Start Here".

**Blocked by:** None.

**Single owner after merge:**

- `docs/NATIVE-THROUGHPUT.md` owns every native throughput figure wiremux publishes: targets, busy-consumer rows and certification rows. Certification slices 7.1–7.3 each own only their platform's Status line and row.
- Editors after merge:
  - 3.3 adds one pointer sentence to the processor-headroom section;
  - 6.2 rewrites the macOS launch-context section in the present tense, removing this slice's conditional wording;
  - 7.1–7.3 update their platform's Status line and row.
- The godoc on the two entry points owns the rule's statement in the API.
- `CONTEXT.md` owns the vocabulary.
- `COMPATIBILITY.md` keeps contract only and carries the pointer sentence.

**Authority completeness:** No runtime authority. Single-source rule: figures appear only in the targets doc. Godoc, README, `CONTEXT.md` and `COMPATIBILITY.md` carry none, so no second copy can drift.

**Transitional-seam budget:**

- Each platform's "target, not yet certified" status is transitional by design; its certification slice replaces it.
- The macOS launch-context section speaks of the send-thread raise conditionally. Slice 6.2, which is blocked by this slice, removes that wording when it ships the raise.
- Nothing else is temporary.

**Blast radius:**

- **Obligations added:**
  - every future native throughput figure goes into this one doc with its source and shape;
  - the conditional launch-context wording must become present tense when the raise ships.
- **Obligations removed:** none.
- **Contract:** the godoc rule becomes part of the documented behavioral contract as a consumer requirement (COMPATIBILITY L7) and makes no promise.
- **API manifest:** no change. Comments are not declarations, which `-run Baseline` confirms.
- **CI:** because `.go` files change, hosted CI runs the full lanes. The targets doc is not in `CI_DOCS_GLOBS`, which lists some `docs/` root docs but omits topic docs such as `SELECTED-RELAY.md` and `MEASUREMENT.md`. The glob stays unchanged, so the 7.x PRs also run the full lanes.
- **Risk:** a figure copied wrong. The review checks every table cell against its source link.
- **Untraced effects:** none.

**Artifact classification:**

- The godoc paragraphs and the targets doc are shipped behavior: consumer-facing documentation. The doc is explicitly not a compatibility promise.
- The README and COMPATIBILITY pointers are shipped documentation.
- The `CONTEXT.md` terms are process and traceability metadata (contributor vocabulary).
- No verification aid is added.

**Representation contract:**

- **Supported domain:** the figures and statements in the named deciding comments.
- **Representation owner:** those comments. Every table cites its source, nothing is recomputed, and **derived** and **source** labels are kept.
- **Guarantee:** example-level copy fidelity, checked by review cell by cell.
- **Canonical status vocabulary:** "target, not yet certified" until a certification slice writes its row.

**Contract closure:** Not triggered. The slice changes documentation and comments only, with no material-consequence class and no independently reachable runtime path.

**Evidence budget:**

- `task docs-check` (repository-local links and whitespace).
- A `go doc` render of `NewNativeEndpoint` and `NativeCandidate.Promote` to confirm the paragraphs read as written.
- `go test -count=1 ./internal/compatmanifest -run Baseline` unchanged.
- `task verify` on the exact head.
- No measurement, no fork lane and no platform runs.
- One review plus at most one replacement. The review checks each verbatim table against its source comment and each figure's label.
- Terminate when these pass.

**TDD and preservation evidence:** Not applicable to prose; no test is written first. Preservation:

- the manifest baseline is unchanged;
- `gofmt` and lint are clean on the two edited Go files;
- no test changes;
- COMPATIBILITY gains exactly one sentence;
- README gains exactly one bullet.

**Dispatch context budget:** Target at most 32,000 input tokens:

- this plan's Decision and this slice, which carries every table the doc needs;
- the deciding comments for spot-checking (the headroom decision; the targets decision's sections 2–4 and its two inputs from the other-program and receiving-Mac research; the Windows target decision's section 7; the Linux Datagram lever decision's floor line; the send-thread decision's sections 1 and 4; the key-numbers headers of the busy-goroutine, other-program and receiving-Mac resolutions);
- README L84–L103, COMPATIBILITY L1–L15 and L119–L125, `CONTEXT.md` L220–L260, `native.go` L54–L119 and `native_promotion.go` L217–L254;
- the repository review overlay.

Research notes are linked, not read whole.

**Slice decision audit:**

- **Strongest split:** the targets doc in one PR and the godoc and glossary in another. Rejected: the godoc points at the doc, so a split ships either a dangling pointer or an unreferenced doc.
- **Strongest merge:** with 3.3, as the headroom decision first framed it. Rejected per [H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions): the count's gate decides whether it ships, and the rule and targets ship regardless.
- **Owner's design:** n/a (documentation).
- **Blocking edges:** none come in. Three slices depend on this one:
  - 3.3: the count's godoc and pointer refer to this rule and doc;
  - 6.2: it rewrites the launch-context section;
  - 7.1–7.3: they fill the doc.

**Stop conditions:** Stop and ask if:

- two deciding comments disagree on a figure the doc must publish;
- a sentence would state a throughput promise, or a target for a loaded consumer or loaded receiving Mac;
- the doc would need a figure absent from the sources (a new measurement);
- COMPATIBILITY would need more than the one pointer sentence;
- the godoc would need a figure to make sense.

### Slice 3.3 — Late-read count on `Wire.Native()`

**Current state: deferred by owner decision, 2026-10-23.** Keep [#1924](https://github.com/GridSwarm/wiremux/issues/1924) open as a deferred enhancement and [PR #1958](https://github.com/GridSwarm/wiremux/pull/1958) draft and unmerged. Preserve the branch, original gates and [diagnosis report](../research/issue-1962-native-late-read-diagnosis.md) as research. This decision supersedes the prior next action to prepare/approve a bounded follow-up plan: there is no active experiment, implementation, re-audit or dispatch obligation. No other slice, release or certification waits for 3.3.

**Why defer.** The detector could help diagnose a slow native transfer even when no received-DATAGRAM queue discards occur, including delayed acknowledgements on a reliable stream. It is diagnostic, not a performance fix. The [completed diagnosis](https://github.com/GridSwarm/wiremux/issues/1962#issuecomment-6344049780) found exactly one zero-count peer in six of twelve scored bilateral accepted-detector pairs under heavy load, with the exact cause still unresolved. Its symmetric-observer comparisons retained receiver CPU/GiB penalties of +3.126% for pinned Datagram and +3.388% for stream; the diagnosis did not measure a semantics-preserving remedy. Those measured limitations do not justify further work on an always-on public diagnostic without a concrete consumer need.

**What is available now.** The processor-headroom guidance from 3.2 remains shipped. The independent public discard count from 3.4 / [#1969](https://github.com/GridSwarm/wiremux/issues/1969) is implemented through #2006 and addresses GridCast's concrete regression-test and benchmark need. A discard count identifies full-queue loss; it does not replace a starvation detector or prove the cause of a slowdown. The bundle-adoption tag and GridCast adoption remain separate work and must include #1969; they do not wait for #1924.

**When to revisit.** Revisit only for a reproducible native-transfer slowdown in GridCast or another actual consumer that remains unexplained after using the available measurements (including #1969 where the carrier and selected fork provide it) and checking the documented processor-headroom guidance. The report must identify the affected workload/platform, measurable user impact, evidence suggesting delayed network reads, and the concrete consumer action this additional signal would enable. A zero discard count alone is not that evidence. There is no calendar-based retry or automatic restart after another slice merges.

**How a revisit proceeds.** First assess that consumer evidence against the retained research and current code/fork. Only an explicit owner decision to resume authorizes a new bounded investigation or implementation plan. That plan must re-audit the current read paths, address both missed detection and measurement cost, and preserve the two 5 ms conditions, existing healthy/idle controls, -1% throughput / +2% receiver CPU/GiB limits, and admission/control-byte/allocation/lifetime obligations unless the owner explicitly approves a contract change. Do not merge the old PR, weaken the gates, or ship a platform-specific alternative merely because the revisit trigger is met. No new public API or runtime behavior is authorized by this deferral.

**Retained design below:** The remaining Slice 3.3 contract, tests, evidence budgets and acceptance checks are historical resume material, not active execution requirements. Revalidate them before any resumed dispatch.

**What it delivers:**

- **The public field.** `NativeWireInfo.LateReads uint64`, appended after `Dialer` and documented next to the rule. Its godoc states:
  - the definition (a read on the promoted Wire's binding whose oldest datagram's kernel receive timestamp is at least 5 ms older than the read's return, and which returns at least 5 ms after the binding's previous returning read);
  - that it counts from promotion, never decreases, keeps its final value after close and is read when `Native` is called while the other fields are copied at promotion;
  - that "A climbing count means the process lacks processor headroom", with the rule;
  - the platforms where it is always zero.
- **`Wire.Native`'s godoc** says the count is read at call time.
- **The binding.** The binding's receive owner in `internal/routeselection`:
  - requests the platform's software kernel receive timestamp on sockets of bindings a native endpoint owns (Linux `SO_TIMESTAMPNS` or `SO_TIMESTAMP`, macOS `SO_TIMESTAMP` or its monotonic variant, Windows if preflight finds per-datagram support through the binding's `WSARecvMsg` control data);
  - parses that record in the single control-record parser and consumes it, so QUIC's received control bytes are byte-identical to today's;
  - reads the clock at most once per read call, on every returning read of an armed binding, and keeps that reading as the binding's previous return;
  - compares on the kernel timestamp's own clock;
  - counts at most one late read per returning read on a binding armed for counting, only when both conditions of the definition hold.
- **Arming.** `internal/nativequic` arms the promoted Wire's binding at the end of `Promotion.Commit`. It reaches the binding through the candidate's binding reference, which the ADR-0016 implementation adds as `Candidate.unicast`. 3.3 reuses that reference so the association has one owner, and adds it only if that implementation closed without it. `internal/nativequic` exposes the live count, and root `Wire.Native()` fills `LateReads` from it.
- **Unexported mechanics.** Arming, the count read and the timestamp request are package-level functions or unexported methods in `internal/routeselection`. Precedents: `ReadUnicastBatch`, and the ADR-0016 implementation's `UnicastIdleCause(b, remote)`. None of them is an exported method on `UnicastBinding` or a field on `UnicastConfig`, because `binding.Binding` and `binding.Config` alias those types and the API manifest lists their methods and fields.
- **Batched macOS reads.** If slice 6.4 (`recvmsg_x` into read slots on the connected macOS socket) has merged first, the count also covers that batched read. The timestamp is requested and parsed per slot, with two batched cases in the evidence.
- **Fixed.** The 5 ms threshold is an unexported constant. Public `binding` sets request no timestamps and behave exactly as today.
- **COMPATIBILITY.** The "Native promotion" section records `LateReads` as an additive API with no throughput promise, following the section's convention for unreleased additions. Because an unkeyed `NativeWireInfo` literal no longer compiles, it also records the field as this section's explicit exception to the compatible change rule.
- **API inventory.** Regenerated: exactly one added line, `field LateReads uint64`, under `NativeWireInfo`.
- **Targets doc.** `docs/NATIVE-THROUGHPUT.md`'s processor-headroom section gains one sentence pointing at `NativeWireInfo.LateReads`.
- **Glossary.** `CONTEXT.md` gains the third headroom term, verbatim from the headroom decision, placed after 3.2's two terms (`_Avoid_` line in house style): **Late read**: "a native network read that finds datagrams waiting longer than the late-read threshold because the read loop wasn't scheduled. A climbing count means the process lacks processor headroom."
- **Rig prep step, before the gate.** After the fork-lane tests pass and before any gate campaign, this slice makes one commit on `codex/native-gap-rig`, never merged. That commit:
  - reports the sender's and receiver's `LateReads` at the start and end of the send window in each result line, with `summarize.py` carrying the fields;
  - adds a way to hold a promoted Wire idle for the run;
  - still builds on the base commit, for example by reading the field by reflection.
  - One smoke check (`REPS=2 SECS=5`, never evidence) confirms the prep step before the campaigns.

**Existing-work disposition:** New slice. No branch or PR exists, and no late-read code exists on main. The ADR-0016 implementation ([Native Wire: a route refusal or a briefly unassigned source address ends the connection instead of dropping the datagram](https://github.com/GridSwarm/wiremux/issues/1880)) and slice 2.1 change the same read path and `Candidate`; re-anchor by function at preflight.

**Blocked by:**

- 3.2: the count's godoc and the targets doc pointer refer to the rule and the document 3.2 creates.
- [Native Wire: a route refusal or a briefly unassigned source address ends the connection instead of dropping the datagram](https://github.com/GridSwarm/wiremux/issues/1880) closing: its second PR rewrites `Candidate`, `Commit` and the receive path this slice changes, and a forced rebase would invalidate this slice's exact-head gate. No slice depends on 3.3, so the edge costs nothing downstream.

**Single owner after merge:**

- The binding's receive owner (`ReadUnicastBatch` and the control-record parser in `internal/routeselection`) owns timestamp parsing and the count for an armed binding.
- `internal/nativequic` owns arming at `Promotion.Commit` and exposing the count.
- Root `Wire.Native()` owns reading it live.
- The other `NativeWireInfo` fields remain the static copy (L344–L350).

**Authority completeness:**

- The count is diagnostic, not authority.
- Constructors: native endpoint binding setup requests timestamps, and `Commit` arms the binding once. A binding is never disarmed.
- Restart: not applicable.
- No destructive or security-sensitive consumer reads the count. Admission never consults it.

**Transitional-seam budget:** None.

**Blast radius:**

- **Obligations added:**
  - every later receive-path change must keep the timestamp request, its consumption and the count: slice 2.1's pins if 3.3 lands first, the connected macOS socket 2.2, the Linux and Windows coalescing switches 5.3 and 5.4, and macOS batched receives 6.4, which "Preserves 3.3's receive timestamps if 3.3 has landed". If 6.4 lands first, this slice covers its batched read;
  - a read in flight while arming may or may not count;
  - one clock read per read call, kept as the previous return;
  - one consumed control record;
  - one public field and its COMPATIBILITY exception.
- **Obligations removed:** none.
- **Shared state:** one atomic arm flag, one atomic counter and one atomic previous-return time per binding. No new goroutine, timer, event or log line.
- **Interfaces:** one public field. The API manifest gains one line. The COMPATIBILITY text changes. `native_promotion_test.go` L271–L274 changes its comparison.
- **Failures:** a missing, truncated or malformed timestamp record never changes admission and never counts. The added record never pushes packet-info out of the private scratch: 256 bytes of headroom hold it.
- **Performance:** the no-harm row gates it.
- **Security:** admission is unchanged (closure table below).
- **Files shared:**
  - `native_promotion.go` with slices 1.2 and 1.3;
  - `internal/routeselection` read path with the ADR-0016 implementation and slices 2.1 and 2.2;
  - `promote.go` and `candidate.go` with slices 1.3 and 3.1.
  - These merges happen one after another. If 2.1's exact allocation pins exist, they stay exact.
- **Untraced effects, flagged:**
  - Windows timestamp support (preflight).
  - A wall-clock step on platforms whose timestamp is wall-clock based, which can add or hide at most the reads around that step.

**Artifact classification:**

- The count, its timestamp parsing and arming are shipped behavior.
- Its godoc, COMPATIBILITY text and targets-doc sentence are shipped documentation. The Late read `CONTEXT.md` term is process and traceability metadata (contributor vocabulary).
- The rig commit, the gate campaigns and the evidence directory are verification aids. They are not maintained deliverables: the rig branch is never merged.
- The diagnosis issue on a failed gate is process and traceability metadata.

**Representation contract:**

- **Supported domain:** kernel receive timestamp control records on native endpoint bindings on Linux and macOS, and on Windows if preflight confirms support. Every other platform reports zero.
- **Representation owner:** the binding's single control-record parser, which walks records with `x/sys/unix.ParseOneSocketControlMessage` on Unix and the `WSACMSGHDR` walk on Windows. This is the same parser that admits packet info today.
- **Guarantee:**
  - Example-level for the count's value, a diagnostic.
  - Universal within the supported domain for preservation: admission verdicts and the control bytes QUIC receives are unchanged. The single parser enforces this, with the evidence below.

**Contract closure:** Triggered for the preservation invariant only.

- **The invariant:** "the detector changes neither any admission verdict nor the control bytes QUIC receives, on any native read path".
- **Why it triggers:** a broken verdict is a security-boundary failure, and a truncated packet-info record refuses every datagram. The read paths are independently reachable (Linux batch reads, single reads on macOS and Windows, IPv4 and IPv6, pre- and post-promotion), so focused happy-path tests alone do not cover it.
- **Enforcement owner:** the binding's control-record parser and its receive owner.

| Semantic class | Expected disposition | Enforcement owner | Evidence | Guard mutation | Status |
| --- | --- | --- | --- | --- | --- |
| Linux batch read, IPv4 and IPv6 | verdicts unchanged; timestamp record consumed; QUIC control bytes byte-identical | binding receive owner | existing admission tests plus a new real-socket control-identity case (timestamps requested against not) | delete the record's consumption → control-identity case fails | covered |
| macOS single read, IPv4 and IPv6 | same | same | same cases on darwin in the fork lane | n/a | covered |
| macOS batched read (`recvmsg_x`), only if 6.4 merged first | same, per slot | same | two batched cases on darwin | n/a | covered when applicable |
| Windows single read | same with timestamps, or none requested and count zero | same | existing Windows binding tests plus one count case, one-off on the Windows GARM pool | n/a | covered |
| Timestamp record missing, truncated or malformed | not counted; verdict from packet info alone | control-record parser | synthetic-control case | n/a | covered |
| Control capacity with QUIC's full buffer size | packet info never truncated by the added record | private scratch (`ScopeControlSize`) | case with QUIC's configured OOB length | n/a | covered |
| Reads before promotion (candidates, losing candidates) | never counted | arming at `Commit` | stale datagram read on an unarmed binding counts zero | n/a | covered |
| Public `binding` sets | no timestamp requested; reads unchanged | native endpoint binding setup | `binding.Listen` read case unchanged | n/a | covered |
| `testReceive` seam | not a production path | — | — | n/a | non-goal |

**Evidence budget:**

- At most twelve new test cases, plus two batched-read cases if 6.4 merged first:
  - Binding level, ordinary graph, real loopback sockets on linux and darwin:
    - (1) An armed binding, with a datagram left in the kernel 20 ms before the read, counts one late read.
    - (2) A read already blocked when the datagram arrives counts zero.
    - (3) An unarmed binding with a stale datagram counts zero.
    - (4) The control-identity case.
    - (5) Missing or truncated timestamp record.
    - (6) Full-size QUIC control buffer.
    - (7) Public `binding` read unchanged.
    - (12) A backlog: two stale datagrams read back to back on an armed binding count one late read, not two.
  - (8) Root, fork lane: `Wire.Native().LateReads` reads the binding's live count after promotion while the other fields equal the promotion copy, and it is zero on an idle promoted pair.
  - (9) The updated `TestNativePromotionRoundTrip` comparison.
  - (10) The Windows case.
  - (11) One real-socket allocation case per platform (linux, darwin) on an armed, timestamp-requesting binding. It asserts the same exact count as the unarmed path, or slice 2.1's count if 2.1 has landed.
  - (B1, B2) Only if 6.4 merged first: a stale batched read on an armed connected macOS binding counts one, and a prompt one counts zero.
- Plus the regenerated manifest, and the review's check that the Late read term matches the headroom decision verbatim.
- Runs:
  - ordinary-graph `internal/routeselection` on linux and darwin, once each with `-race`;
  - the fork lane at fast.7 once on macOS and once on Linux;
  - one Windows one-off on the GARM pool `wiremux-garm-windows-amd64`, recorded in the PR;
  - at most one guard mutation (the control-identity row).
- The gate, with the rig applied onto the PR head (B) and onto its base commit (A) per PROTOCOL.md L5–L15, `rig.mod` at fast.7, `SECS=10`:
  - **Climb and flat rows, on B only.** One campaign per row at `REPS=3`, each run counting the sender's `LateReads` over the send window, the receiver's reported.
    - `tb` (sender on mbp128, `GOMAXPROCS` 16): idle Wire, held at least two keepalive periods (35 s); `-goload 12` with `dgram` at the pin and `stream`; `-goload 16` (the cliff) with `dgram` at the pin and `stream`.
    - `netns` (sender pinned by `SCPUS` 4-7, so `GOMAXPROCS` 4): idle Wire, 35 s; `-goload 4` (the cliff) with `dgram` at the pin and `stream`.
    - 24 runs in all.
  - **No-harm row.** A, B, A, B at `REPS=3` with pooled medians ([PROTOCOL.md L124](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/PROTOCOL.md?plain=1#L124)), on `tb` and on `netns`, idle consumer.
    - Arms: `dgram` at the pin (`-ballast 64 -gc-role both`) and `stream` are judged; the default-GC `dgram` row is reported.
    - Both arms run with 3.1's readouts and recorder off.
    - 72 runs in all.
  - No reruns except under PROTOCOL.md's outlier rule.
  - Shared-host rules on every run:
    - `tb`: hold the pair claim for the whole window; announce CPU-heavy mbp128 work to any session holding the `tb` pair; `LOADGATE=1` with `GATE` for mbp128's GARM Tart VMs ([L180](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/PROTOCOL.md?plain=1#L180)).
    - `netns`: `GATE` on no other `nativerig` running, before every run, and the slice's own `PORT` ([L45](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/PROTOCOL.md?plain=1#L45)).
- **Pass:**
  - "climbs at the cliff" (handoff decision [H22](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)): every cliff run ends with a sender count above zero.
  - "stays flat" (handoff decision [H22](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)): no idle or 12-of-16 run's sender rate (late reads per second over the window) reaches the lowest cliff run's rate in that cell.
  - The no-harm thresholds hold, verbatim as in Decision.
- **Record:** the PR records `meta.txt` and `summary.txt` and keeps `OUTDIR` under the map's evidence directory (`native-gap-evidence/`), never a session scratchpad.
- One review plus at most one replacement. Terminate when the tests and the gate pass.
- **If the gate fails:**
  - the PR does not merge;
  - the results are posted on the slice's child issue;
  - a diagnosis issue is filed with the campaigns linked and mirrored to OmniFocus;
  - 3.2 stays shipped and unchanged;
  - nothing else is blocked, because no other slice depends on 3.3.

**TDD and preservation evidence:**

- Write binding cases (1)–(7) and (11) first; they fail before the parser and count exist. Then write (8) and update (9). Then regenerate the manifest and review its diff.
- After the fork-lane and Windows runs pass, do the rig prep step and its smoke check, then the gate campaigns.
- Preservation:
  - `TestUnicastReceiveIngressAndReturnRoute`, `TestUnicastBatchProvenance` and the other admission suites unchanged;
  - `TestUnicastMessagePathAllocations` exact, and 2.1's pins exact if present;
  - the root and `internal/nativequic` native suites in the fork lane under `-race`;
  - ADR-0016's drop-and-recheck tests unchanged if its implementation has landed.

**Dispatch context budget:** Target at most 62,000 input tokens. This is above the usual range because the rig prep step lives in this slice. The list:

- this plan's Decision and this slice;
- `internal/routeselection/unicast.go`'s current `ReadUnicastBatch`, `receive` and `admitReceived` and their scratch;
- `packet.go` L240–L270;
- `unicast_unix.go` L84–L140, `unicast_windows.go`'s receive parser, and the darwin packet file;
- the unicast binding construction used by `ListenUnicast`;
- `internal/nativequic/packetconn.go`, `candidate.go` L54–L122 and `promote.go` L300–L338;
- root `native_promotion.go` L77–L103 and L330–L351;
- COMPATIBILITY L11–L15 and L123–L125, and `CONTEXT.md`'s native terms with 3.2's two additions;
- `manifest_test.go`;
- the admission tests' table headers;
- `binding/binding.go`, whose aliases expose `UnicastBinding` and `UnicastConfig`;
- for the rig prep step at the `codex/native-gap-rig` head: `cmd/nativerig/main.go` (about 1,400 lines, the result struct, flags, `runNative`, `nativeReceive` and `nativeSend`), `summarize.py` and `rig.sh`;
- PROTOCOL.md's A/B, `-goload`, cell and host-rule paragraphs;
- the repository review and CI overlays;
- any diff from the ADR-0016 implementation or slice 2.1 that landed on these functions since `467fc555`.

**Slice decision audit:**

- **Strongest split:** binding timestamp parsing and arming in one PR and the public field in another. Rejected: the parsing has no consumer without the field, and the gate needs the public readout.
- **Strongest split, by platform:** Linux first, macOS second. Rejected: the gate's climb rows require both cells together.
- **Strongest merges:**
  - With 3.2. Rejected per [H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions): the docs ship regardless of the gate.
  - With slice 2.1, which owns the same read path. Rejected: 2.1 waits for the ADR-0016 implementation and has its own allocation gate, and 3.3 has no reason to wait for either.
- **Owner's design:** n/a; the count lives in its owner.
- **Blocking edges:** both are necessary.
  - 3.2: the field's godoc and the targets doc pointer refer to the rule paragraph and the document 3.2 creates.
  - The ADR-0016 implementation: it rewrites `Candidate`, `Commit` and the receive path under this slice, and a rebase after the 96-run gate would invalidate it.

**Stop conditions:** Stop and return for a decision if:

- the binding's socket cannot get a per-datagram kernel receive timestamp on Linux or macOS;
- the record cannot be consumed without changing QUIC-visible control bytes;
- any admission verdict changes;
- any existing allocation pin changes;
- the detector would need more than one clock read per read call, a goroutine, a timer, an event or a log line;
- the 5 ms comparison cannot be made on the kernel timestamp's own clock on a supported platform;
- a flat row's late reads come from socket queueing on a saturated but healthy Wire rather than from scheduling;
- the ADR-0016 implementation or slice 2.1 changed the read path so that the count's owner would have to move outside the binding's receive owner;
- the timestamp request, arming or count would surface on `binding` (an exported method, field or manifest line beyond `NativeWireInfo.LateReads`).

Two outcomes are not stops:

- **Windows without per-datagram timestamps:** Windows reports zero and the godoc says so.
- **A failed gate:** handled as stated in the evidence budget.

### Slice 3.4 — Public received-DATAGRAM full-queue discard count

**Current state:** Complete through [#2006](https://github.com/GridSwarm/wiremux/pull/2006), with [journal #2007](https://github.com/GridSwarm/wiremux/pull/2007). The contract below records the delivered behavior.

**Issue:** [#1969](https://github.com/GridSwarm/wiremux/issues/1969). **One implementation PR.** The [decision record](https://github.com/GridSwarm/wiremux/issues/1969#issuecomment-6370249114) supplies the behavior; this section is the normative execution contract. Blocked only by completed 5.1 / #1925 and publication of this amendment audit. Slice 3.3 / #1924 is independent.

**Current shape:** At wiremux `3cb67e8f61525b7d57d021b2e802e58713ed5f3e`, root `Wire.native` holds copied `NativeWireInfo` facts and `Wire.Native()` returns that copy. `internal/nativequic.Promotion` retains `Candidate.conn` through teardown. Its opt-in readout registry already detects the optional `DatagramReceiveDropsV1() uint64` method, but unregisters when `Promotion.Close` begins. Fast.8 (`8095c72244755f0c1e24f4158253bf09cfbe6e17`) supplies a concurrent-safe atomic count retained after connection close. `connV1` and `Supported` do not require the count method. Re-anchor these functions at pickup.

**Outcome and representation contract:** One promoted native Wire exposes one local fork-owned `uint64` count plus fixed availability. The supported domain is native promotions using the selected QUIC connection's optional Go method set, and nil/non-native Wires. The fork owns count values, lifetime, and full-queue semantics; wiremux's native promotion owner owns the instance association and optional method assertion. Availability, isolation and no reset are universal by construction in that domain; tests give example-level value and interleaving evidence. No external grammar is parsed. Ordinary focused tests reasonably cover this narrow read-through surface, so the material-risk closure protocol is not triggered and no closure or mutation harness is required.

**Implementation:**

1. Append `DatagramReceiveDrops uint64` and `DatagramReceiveDropsAvailable bool` to `NativeWireInfo`, preserving existing field order and any independently landed `LateReads` behavior.
2. Add a read-only method at the existing native promotion owner, using an optional interface assertion on its retained connection. An absent method returns zero and unavailable. Keep the optional interface independent of the measurement registry and required native capabilities; share the method-set declaration with the internal readout where appropriate.
3. Bind the reader to this Wire during native construction. Keep stored provenance immutable. Each `Wire.Native()` call copies the facts and samples the count into the returned value. Do not mutate a shared cached `NativeWireInfo`, reset the source, or subtract a promotion/first-read baseline.
4. Preserve existing Close/Abort ownership and order. The retained connection supplies reads during and after close without a registry lookup or cached final accumulator. A shutdown-racing read can precede the last increment; once aggregate teardown completes the final value and availability are retained and stable, even if teardown returned an unrelated error. Peer termination eventually has the same result.
5. Update field/type/method godoc, COMPATIBILITY's native section and explicit unkeyed-`NativeWireInfo`-literal exception. Regenerate the API inventory; relative to the pickup base its only new public declarations are these two fields. No dependency repin belongs here.

**Meaning:** Count received DATAGRAM payloads refused because the local connection's receive queue was full, not bytes, packets or application messages. Include the connection's existing counting lifetime after its receive phase opens, including the remainder of successful promotion. Exclude receive-phase discards, protocol violations, unprocessed-packet drops, kernel/socket drops, network loss and wiremux/application rejection after delivery. A positive count locates loss at the queue without attributing it to a particular consumer bug; zero does not claim zero end-to-end loss. An unavailable counter uses numeric zero only as a placeholder. The existing outer bool still reports native identity. Samples do not update themselves or reset the source; interval deltas use two available samples from the same Wire.

**Preservation and approved blast radius:** Root native info/construction, the promotion's read-only adapter, focused tests, godoc, compatibility text and inventory. Older native-capable forks without the method remain supported; ordinary upstream quic-go keeps compiling and reporting native unsupported. Measurement readouts and qlog may stay disabled, and registry removal cannot erase public results. Existing provenance, Datagram queues, admission, wire bytes, error behavior, teardown ordering and lifetime remain unchanged. The new synchronous read adds an interface call and atomic source load, with no steady-state allocation and no per-Datagram work.

**Design-cost decision:** Read directly through the existing state owner. Reject the endpoint-keyed measurement registry because it adds enable-before-create, key identity and unregister-lifetime obligations. Reject a copied accumulator or final-value cache because it creates synchronization and final-increment ordering obligations. No execution-context hand-off, side channel, global retention table, background task, new counter owner or second shutdown state machine is introduced. The owner design and the implementation are the same; no temporary seam needs retirement. The intentional public API addition carries the documented unkeyed-literal exception. No remaining untraced effect is accepted: discovering a need to change the fork or lifecycle is a stop.

**Artifact classes:** Runtime reader, fields and their public semantic documentation are shipped behavior. Existing lifecycle enforcement is preserved; no new safety-enforcement subsystem is introduced. Tests, fixtures and API inventory are verification aids within their existing repository role, not new independently maintained tooling deliverables. Plans, audit receipts, issue/task mirrors and journals are process metadata. No new verification aid is approved to enlarge or independently block shipped scope.

**Acceptance criteria and terminating evidence:**

| ID | Criterion | Finite evidence |
| --- | --- | --- |
| D1 | A native Wire reports unavailable/zero when the method is absent, available/zero when present at zero, and the exact positive source value when present. Native capability admission is unchanged. | Deterministic absent/zero/positive optional-reader tests; existing capability tests; unchanged required method sets. |
| D2 | Each call samples live; earlier values and provenance remain unchanged; reads do not reset or subtract the source. Two Wires cannot read or accumulate one another's counts. | Atomic fixture updated between reads, initial positive count, repeated reads, saved snapshot and two distinct instance readers. |
| D3 | Nil/non-native behavior and the outer native bool are preserved. Public reads work without measurement registration or qlog and survive registry removal. | Root nil/non-native and native-unavailable cases; real promoted pair with readouts off; existing registry integration extended to verify public results after unregister. |
| D4 | Reads racing increments, graceful Close, Abort and peer termination are race-free. After aggregate teardown completes, availability and final total remain readable and stable, including an unrelated teardown error after connection closure. | Deterministic positive-count adapter and lifecycle fixtures plus real fork Close/Abort/peer cases under `-race`; wait on existing completion owners, not sleeps as evidence of finality. |
| D5 | Real native pairs on adopted fast.8 expose the capability through the public API, and public and underlying values agree when traffic is quiescent. | One integration case per relevant readout mode using the existing test access to the owner or registry; exact positive/live assertions remain deterministic fixtures. |
| D6 | Steady-state public reads allocate zero memory and add no work to the packet path. Existing native behavior is preserved. | `testing.AllocsPerRun` for available and unavailable readers, diff review of production send/receive methods, existing native suites and required validation. |
| D7 | Godoc, COMPATIBILITY and generated API inventory agree on availability, lifetime, meaning and the additive API exception. | Documentation review, docs check and regenerated baseline with exactly the two added fields relative to the pickup base. |

These criteria's universal terms range only over the typed per-instance reader and existing supported native lifecycle, not arbitrary third-party counter implementations or exhaustive schedules. The fork's source contract and existing queue tests own overflow and exclusion semantics; do not reproduce its queue algorithm or force a scheduling-dependent overflow in wiremux tests.

**Evidence budget and commands:** First perform AGENTS.md's installed/base Go audit; stop below its floor before any other Go subcommand. Use `GOTOOLCHAIN=local GOWORK=off`. Write focused regressions before implementation where practical, then run:

- `go test -count=1 ./internal/nativequic .` and the same with `-race` on the ordinary graph.
- In an isolated ignored module file copied from `go.mod`, replace `github.com/quic-go/quic-go` with `github.com/the-sarge/quic-go-fast v0.62.1-fast.8`, following the adopted release record. Run `WIREMUX_TEST_NATIVE=required go test -modfile=.cache/fast8/fork.mod -race -count=1 ./internal/nativequic .` once on macOS and once on Linux. Do not edit tracked module files.
- `go test -count=1 ./internal/compatmanifest -run Baseline -update`, inspecting the two-field diff; rerun without `-update`.
- `task docs-check` and `task verify` on the exact final pushed head, retaining head/base receipts; required hosted CI must succeed on that same head before squash merge.

One representative case per semantic behavior/failure mode is sufficient. There is no mutation, fuzz, throughput, timing-boundary, Windows-specific campaign or repeated-run gate. No #1924 gate is inherited. One fully briefed fresh RAS review and at most one replacement after accepted fixes; use scoped verification for accepted findings. Review findings do not authorize scope expansion.

**Dispatch context budget:** At most 24,000 input tokens: this section, the linked current decision record, relevant unresolved amendment audit dispositions, `NativeWireInfo`/`Wire.Native`/native construction, `Wire` native state and Close/Abort, `Promotion` retention/Close/Abort, optional-count/readout and capability declarations, focused native tests, native COMPATIBILITY paragraphs, manifest generator, and repository review/validation overlays. Include a governing diff if this contract changes; do not require all historical Track 3 plan versions or unrelated throughput evidence.

**Slice audit:** The strongest split separates internal reader from public fields; reject because it creates an unused intermediate seam and splits the same acceptance contract. The strongest merge is with 3.3; reject because its detector, binding changes and failed timing gate have unrelated owners and evidence. Completed 5.1 is the only product prerequisite: it establishes the adopted fork containing the counter. Shared files require ordinary sequential rebase/review coordination only.

**Non-goals and stop conditions:** No other carrier statistics, general diagnostics API, throughput/delivery promise, queue sizing, sender pacing/credits, automatic tuning, late-read detector, packet-path instrumentation, timer, goroutine, logging, new dependency, fork change or teardown redesign. Stop for a decision if accepted behavior requires any of those, if the retained connection cannot supply a stable post-teardown count, if the optional method becomes required for admission, or if the accepted outcome cannot fit this one PR and evidence budget. Preserve the requirement to include this in GridCast's bundle-adoption tag; publishing that tag and changing GridCast are separate work.

## Acceptance Criteria

Slice 3.4 uses D1–D7 in its normative section above; the original slices retain their criteria below.

- [ ] **3.1.** With readouts never enabled, every native QUIC configuration has a nil `Tracer` and no promotion is registered.
  - Domain: endpoints created in a process that never called `EnableReadouts`, or created before it was called.
  - Representation owner: the endpoint's capture at `New`.
  - Guarantee: universal by construction, since the capture is the single place either effect is decided.
  - Terminating evidence: tests (1), (2) and (7) plus the PR's diff stat showing no packet-path file changed.
- [ ] **3.1.** With readouts enabled before an endpoint is created, each committed promotion of that endpoint is found by `Wire.Native()`'s `(Local, Remote)` until `Close` and not after.
  - The readout copies `ConnectionStats()` and reports each optional count as present with the fork's value or absent, never as zero for an absent method.
  - With the recorder option, PTO expiries and spurious losses are counted from the connection's qlog events.
  - Domain: promotions of such endpoints on upstream v0.62.0, fork fast.7 and fork main `5b05133d`.
  - Representation owner: the QUIC module's types.
  - Guarantee: universal for absent-versus-zero and registration lifetime, example-level for values.
  - Terminating evidence: tests (3)–(6) and (8).
- [ ] **3.1.** No public declaration changes, and the seam exposes no connection, stream or mutating method.
  - Domain: the twelve public packages' declarations, and the seam's exported identifiers in `internal/nativequic`.
  - Representation owner: the API manifest generator, and the seam's own type definitions.
  - Guarantee: universal for public declarations (the generator enumerates them), canonical-subset for the seam (its identifiers are the sketch's).
  - Terminating evidence: `go test ./internal/compatmanifest -run Baseline` unchanged, and review of the seam's exported identifiers against the sketch.
- [ ] **3.2.** `docs/NATIVE-THROUGHPUT.md` exists with the six sections above.
  - Every platform's floor table is verbatim and marked "target, not yet certified".
  - The certification status table has one row per platform.
  - Every busy-consumer row is verbatim with its shape line and source.
  - The macOS launch-context section and the not-covered list are present.
  - No target is stated for a loaded consumer or a loaded receiving Mac.
  - Domain: the named deciding comments.
  - Representation owner: those comments.
  - Guarantee: example-level copy fidelity.
  - Terminating evidence: the review's cell-by-cell check and `task docs-check`.
- [ ] **3.2.** The godoc of `NewNativeEndpoint` and `NativeCandidate.Promote` states the rule and its scope with no figures, and does not name the late-read count. `CONTEXT.md` has the two terms (Never-blocking goroutine, Processor headroom) verbatim and no Late read term. README "Start Here" links the doc. COMPATIBILITY gains exactly the one pointer sentence and no figure.
  - Domain: the PR's diff to `native.go`, `native_promotion.go`, `CONTEXT.md`, `README.md` and `docs/COMPATIBILITY.md`.
  - Representation owner: git's diff of those files.
  - Guarantee: universal within that diff.
  - Terminating evidence: review of the diff stat and hunks (one paragraph per godoc, two glossary entries, one README bullet, one COMPATIBILITY sentence, no digits followed by a unit in the godoc).
- [ ] **3.3.** `Wire.Native().LateReads` reports the promoted Wire's binding's live count of reads whose oldest datagram's kernel receive timestamp is at least 5 ms older than the read's return and which return at least 5 ms after the binding's previous returning read, counted only after promotion. It is zero where no timestamp exists, and the godoc names those platforms.
  - Domain: native endpoint bindings on Linux, macOS and Windows (if supported), including macOS batched reads if 6.4 merged first.
  - Representation owner: the binding's control-record parser.
  - Guarantee: example-level for values.
  - Terminating evidence: binding cases (1)–(3), (5) and (12), and root case (8).
- [ ] **3.3.** Admission verdicts and the control bytes QUIC receives are unchanged on every native read path, and public `binding` sets request no timestamps.
  - Domain: the closure table's classes.
  - Representation owner: the binding's single parser.
  - Guarantee: universal within that domain.
  - Terminating evidence: the closure table's evidence and its one guard mutation.
- [ ] **3.3.** The gate passed (climb and flat rows under [H22](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)'s readings, and the no-harm row on `tb` and `netns`) and is recorded in the PR. Otherwise the PR is unmerged and a diagnosis issue exists.
- [ ] **3.3.** No setting, event, goroutine, timer or log line was added for late reads.
  - Domain: the PR's diff.
  - Representation owner: git's diff.
  - Guarantee: universal within the diff.
  - Terminating evidence: review of every added `go`/`time.AfterFunc`/`time.NewTimer`/`log`/`slog` call and exported identifier in the diff.
- [ ] **3.3.** Reads before promotion never count.
  - Domain: reads on a native endpoint binding before `Promotion.Commit` arms it.
  - Representation owner: the arm flag, set only in `Commit`.
  - Guarantee: universal by construction (one arming site).
  - Terminating evidence: binding case (3) plus review that `Commit` is the only arming call.
- [ ] **3.3.** The manifest diff is exactly one added line (`field LateReads uint64` under `NativeWireInfo`).
  - Domain: the API manifest.
  - Representation owner: its generator.
  - Guarantee: universal.
  - Terminating evidence: the regenerated baseline's diff.
- [ ] **3.3.** COMPATIBILITY records the field as additive with no throughput promise, plus the unkeyed-literal exception. `CONTEXT.md` gains the Late read term verbatim, and a failed gate ships no Late read term (the PR does not merge).

The representation contracts above bound every universal quantifier ("every", "never", "each", "no") to the named domains, owners and finite evidence. No exhaustive schedule, platform or external-grammar proof is claimed.

## Validation Gates

**Before any Go command:**

- Perform the installed/base Go audit in AGENTS.md and stop below the approved floor.
- Use `GOTOOLCHAIN=local GOWORK=off`.
- The fork lane is an isolated module file copied from `go.mod` with one `replace`, as in the [fast.6 qualification](../release/v0.2.4/qualification.md): for example `.cache/fast7/fork.mod` replacing `github.com/quic-go/quic-go` by `github.com/the-sarge/quic-go-fast@v0.62.1-fast.7`. Run it with `WIREMUX_TEST_NATIVE=required` and `-race`. The tracked `go.mod` is never changed ([H3](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). Hosted CI skips native tests, so the fork-lane runs below are named in each PR.

**3.1:**

- `go test -count=1 ./internal/nativequic .` and the same with `-race` on the ordinary graph.
- `WIREMUX_TEST_NATIVE=required go test -modfile=.cache/fast7/fork.mod -race -count=1 ./internal/nativequic .` once on macOS (mbp128 or m4mini) and once on Linux (minimax or the Linux CI image).
- One `-run` of the presence case with a throwaway module file whose `replace` points at fork main `5b05133dcc878d847123d9485206b77d42426453`.
- `go test -count=1 ./internal/compatmanifest -run Baseline`.
- `task verify` on the exact final head.

**3.2:**

- `task docs-check`.
- `go doc github.com/GridSwarm/wiremux NewNativeEndpoint` and `go doc github.com/GridSwarm/wiremux NativeCandidate.Promote`.
- `go test -count=1 ./internal/compatmanifest -run Baseline`.
- `task verify` on the exact final head.

**3.3:**

- `go test -count=1 -race ./internal/routeselection ./internal/nativequic .` on linux and on darwin on the ordinary graph.
- The fork lane as for 3.1 on macOS and Linux.
- The Windows one-off on `wiremux-garm-windows-amd64` (ordinary graph for `./internal/routeselection`, and the fork lane for the native packages), recorded in the PR.
- `go test ./internal/compatmanifest -run Baseline -update`, reviewing that the diff is exactly one line.
- The rig gate as budgeted, recorded in the PR.
- `task verify` on the exact final head.

**Every slice:** required hosted CI reports success, not skipped, on the same head before squash merge. No new CI lane, repetition, fuzzing or hosted experiment is added.

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with the repository [review overlay](../REVIEW-LOOP.md), [CI policy](../CI.md), [conventions](../CONVENTIONS.md) and root [AGENTS.md](../../AGENTS.md). Weigh any replacement design in a scoped re-audit with the shared design-cost reference.

The original slices recorded their fork lane at `v0.62.1-fast.7`; since completed 5.1 the adopted lane is `v0.62.1-fast.8`, as recorded in the [adoption evidence](../research/quic-go-fast-v0.62.1-fast.8-native-adoption.md). Slice 3.4 uses fast.8. Each PR names its local fork-lane runs: Linux on minimax or the Linux CI image, macOS on mbp128 or m4mini, and for 3.3 the Windows one-off on the Windows GARM pool.

Measured gates follow PROTOCOL.md's A/B rule, with the shared-host rules given in 3.3's evidence budget. Hold each PR as a draft until its review loop settles.

Post-merge ritual for each slice:

1. Run the review loop.
2. Certify the exact head and confirm same-head hosted CI.
3. Merge.
4. Run `$append-dev-journal`.
5. Complete the slice's OmniFocus task.
6. Reconcile the tracking issue and the frontier:
   - 3.3 is deferred under its explicit revisit conditions; 3.4 is complete; Track 3 has no active implementation frontier;
   - 4.R's and 5.1's 3.1 edges clear when 3.1 merges;
   - 6.2's and 7.x's 3.2 edges clear when 3.2 merges;
   - after the last of 7.1–7.3, Track 7's reconciliation files 3.1's removal issue.

Vocabulary reminders: Never-blocking goroutine and Processor headroom, as 3.2 defines them, and Late read, as 3.3 defines it. The seam is "readouts", internal; the count is "late reads", public. Do not call the readouts a public diagnostics API, and do not call the targets promises.

Track-specific approach stops: any public readout beyond 3.3's approved `LateReads` and 3.4's approved discard-count/availability fields, any fork change, any figure outside the targets doc, any target for a loaded consumer, or any change to admission. Each returns to the operator for a decision.
