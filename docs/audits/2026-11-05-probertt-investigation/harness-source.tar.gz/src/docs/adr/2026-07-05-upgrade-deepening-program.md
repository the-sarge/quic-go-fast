# Upgrade Deepening Program — 2026-07-05

**Status:** Complete; original program finished 2026-07-06 (`e12dd1f`), with ADR-0006 D3 final conformance completed by issues #825, #828, and #829

## What this is

Historical index for the completed second wiremux architecture deepening
program, produced by the 2026-07-05 architecture review and a delegated design
walkthrough (grilling) of its top three candidates. The agreed shape is recorded in
[ADR-0006](adr-0006-upgrade-module-single-type-family.md); each track's
plan doc below carries the full grilled design — verified facts, rejected
alternatives, PR slicing, and frozen contracts — so no implementing agent
re-derives decisions from the conversation that produced them.

The first program (2026-07-03 review; issues #411–#417) is complete. Its historical post-ready transition table (#412) supplied the table shape that Track 3 generalized and the later #829 listener slice fully subsumed.

## Outcomes that require no implementation

- ADR-0006 is committed and is the design authority for all three tracks,
  including the explicit "no internal subpackages for single-consumer
  modules in connect" rule (D4) and the rejected alternatives (type
  aliases, thinner bridge, mega-table).
- No CONTEXT.md changes: the grilling created no new domain terms —
  everything new is architecture vocabulary, and CONTEXT.md stays a pure
  domain glossary.
- The later [third deepening program](2026-07-05-third-deepening-program.md)
  revisited the remaining review space after this program landed and records
  the resulting accepted tracks and no-code outcomes. In particular, candidate
  E's probe-run deepening is deferred to restricted-NAT hole-punch coverage as
  that effort's enabling first slice.

## Completed tracks

| # | Track | Plan doc | Depends on | Size |
|---|-------|----------|------------|------|
| 1 | Upgrade-control codec speaks domain types (ADR-0006 D1) | [2026-07-05-upgrade-codec-domain-types-plan.md](2026-07-05-upgrade-codec-domain-types-plan.md) | nothing | 2 PRs |
| 2 | One fallback-reason authority (ADR-0006 D2) | [2026-07-05-fallback-reason-authority-plan.md](2026-07-05-fallback-reason-authority-plan.md) | Track 1 PR 2 | 1 PR |
| 3 | One transition authority for direct upgrade (ADR-0006 D3) | [2026-07-05-upgrade-transition-authority-plan.md](2026-07-05-upgrade-transition-authority-plan.md) | Track 1 PR 2; Track 2 recommended first | 5 PRs |

The program ran **strictly sequentially** (1 → 2 → 3). Track 2 and Track
3 PR 1 were technically parallel-safe after Track 1, but all three tracks
edited `connect` and the merge-conflict cost outweighed the parallelism.
Track 3 completed in PR #486 at main commit `e12dd1f`.

The original Track 3 completion still left role-specific imperative authorities. The later conformance sequence made the intended boundary literal: #825 established `attemptResources` as the persistent lifecycle/result/disposal owner, #828 moved all 43 dialer rows onto `directUpgradeProtocolEngine`, and #829 moved all 82 listener rows onto the same table, cursor, action representation, and post-commit loop. `terminalFallbackExchange` and `controlFrameSequencer` remain separate narrow modules by design.

## Rules that bound every track

- **Behavior preservation is the hard gate.** Wire format frozen (golden
  frame bytes identical, including the 4-byte prefix); package `connect`
  exported API frozen; error identities and wrapping shapes frozen —
  including the packet-socket ownership contract. ADR-0008 supersedes the
  historical pre/post-commit shorthand here: bare errors leave the socket
  caller-owned before the applicable local boundary, while
  `ErrUpgradeTransportNotConverged` closes it after that boundary.
- Follow `docs/REVIEW-LOOP.md` for every PR; `task verify` (including the
  race gate) is the acceptance bar for every slice.
- Do not re-litigate settled ADRs: ADR-0002 (CBOR profile and registry
  discipline), ADR-0003 (selected-pair binding), ADR-0004 (ledger owns
  pair resolution), ADR-0005 (shutdown supervision), ADR-0006 (this
  program's design, including its rejected alternatives).
- Replace, don't layer: superseded tests are deleted with their modules —
  but only after the deleting PR's scenario-mapping checklist names a
  replacement for every covered scenario.
- Vocabulary discipline: CONTEXT.md domain terms in all code, comments,
  PRs, and issues.
- Post-merge ritual per PR: review loop clean → merge → append-dev-journal
  → complete the OmniFocus subtask and file any review follow-ups.
