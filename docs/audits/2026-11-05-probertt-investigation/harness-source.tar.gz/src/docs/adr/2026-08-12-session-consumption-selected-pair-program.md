# Architecture Deepening Program — 2026-08-12 Session Consumption and Selected Pair

**Status:** Track 1 implemented by PR #1149; Track 2 implemented by PR #1151

## What this is

This is the dispatch index for the 2026-08-12 grok architecture review's two grilled candidates: residual Session-consumption trigger ownership, and selected-candidate-pair handoff currency. The linked track plans are the normative source of truth. This index records stable identity, true dependencies, the parallel-safe frontier, and outcomes deliberately closed without production changes.

## Outcomes that require no implementation in this program

- Do not absorb success-side Session consumption (`decorateRelay` / `gateRelayWin`) into establishment settlement. Settlement D8 remains binding.
- Do not expand `finish()` into a second full settlement. Settlement D7 remains binding.
- Do not move failure-kind declaration or the nil-auth ladder into settlement. Settlement D9 remains binding.
- Do not move the identity-failure consume heuristic into settlement, and do not extract a shared hostile-error walker with `connect.RendezvousDisposition`.
- Do not require the listener to finish a local probe before accepting the dialer's selected pair.
- Do not fold `turnRetrySelected` into v1 `selectedPair`, and do not implement `CarrierTopology()` here. Those belong to the TURN/UDP program.
- The 2026-08-12 review's other candidates (control-classify collapse, candidate-kind locality, waiting-peer ledger I/O, serve-flag descriptor table, wiremuxtest fixture-operation envelope, terminal-executor disposal sequenced against TURN Slice 2.3) are not packaged here.
- The same-day relay abuse-signals program ([`2026-08-12-relay-abuse-signals-program.md`](2026-08-12-relay-abuse-signals-program.md)) is a separate completed handoff and is not recreated.
- ADR-0003, ADR-0006, ADR-0008, ADR-0010, and ADR-0012 remain settled.

## Tracks, dependencies, and frontier

| # | Track | Plan | Parent issue | Blocked by | Slices | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Session-consumption trigger | [`2026-08-12-session-consumption-trigger-plan.md`](2026-08-12-session-consumption-trigger-plan.md) | #1142 | None | 1 | COMPLETE |
| 2 | Selected-pair owner | [`2026-08-12-selected-pair-owner-plan.md`](2026-08-12-selected-pair-owner-plan.md) | #1143 | None | 1 | COMPLETE |

Track 1 is implemented by PR #1149. Track 2 is implemented by PR #1151. This program has no remaining dispatchable frontier.

## Rules that bind every track

- Preserve the v0.1.x public interface, wire protocol, documented error identities, Session-consumption outcomes, upgrade-control bytes, packet-socket ownership, and ADR-0006 transition tables unless a track plan explicitly says otherwise; neither does.
- Each production fact or transition touched by a slice has one owner after merge. Derived snapshots may remain only when named in the plan.
- No slice retains a temporary compatibility path, generic role, double mutation path, or shadow owner. These one-slice tracks budget no such seam.
- Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) and the certification lanes in [`docs/CI.md`](../CI.md).
- Public-interface changes are stop conditions. If a plan assumption fails outside the accepted one-PR boundary, stop for a decision rather than broadening the slice.
- Post-merge ritual for each production slice: review → exact-head certification/same-head CI → merge → append-dev-journal → complete its OmniFocus task → update the tracker and frontier.
