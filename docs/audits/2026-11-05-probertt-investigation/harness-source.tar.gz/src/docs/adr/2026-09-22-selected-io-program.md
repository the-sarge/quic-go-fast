# Selected I/O policy program — 2026-09-22

**Program:** SIO-2026-09-22
**Status:** Complete; all six audited slices delivered, with no implementation frontier

## What this is

This program packages the accepted [socket-lifetime decision](adr-0015-selected-interface-continuity.md). The [SIO plan](2026-09-22-selected-io-plan.md) is the normative implementation contract. Issues and OmniFocus contain live state and pointers; the [audit artifact](../research/selected-io-handoff/audit.md) contains review history. The original #1610 performance investigation is complete and remains historical evidence.

## Outcomes that require no implementation

Do not pursue a background event monitor, continuous deletion history, MAC-based identity, silent replacement selection, or a maintained benchmark framework. No implementation agent is dispatched by this handoff. See the decision and plan for accepted scope and limits.

## Tracks, dependencies, and frontier

| Track | Plan | Parent issue | External blockers | Slices | State |
| --- | --- | --- | --- | --- | --- |
| SIO — selected socket construction and lifetime | [SIO plan](2026-09-22-selected-io-plan.md) | [#1636](https://github.com/GridSwarm/wiremux/issues/1636) | None | Six, each one PR/fresh context | All six complete; no frontier |

The slice graph is {SIO-1, SIO-2A} → SIO-2 → {SIO-3, SIO-4}, with SIO-3 → SIO-5. [SIO-2A (#1649)](https://github.com/GridSwarm/wiremux/issues/1649) is complete. There are no cross-track edges. SIO-1, SIO-2A and [SIO-2 (#1638)](https://github.com/GridSwarm/wiremux/issues/1638) are complete. [PR #1646](https://github.com/GridSwarm/wiremux/pull/1646) delivers root and UDP bound-socket lifetime against the merged packet-scope boundary. [SIO-3 (#1639)](https://github.com/GridSwarm/wiremux/issues/1639) delivers Unix constructor identity. [SIO-4 (#1640)](https://github.com/GridSwarm/wiremux/issues/1640) delivers Windows constructor identity in [PR #1657](https://github.com/GridSwarm/wiremux/pull/1657). [SIO-5 (#1641)](https://github.com/GridSwarm/wiremux/issues/1641) delivers the [bounded Linux report](../research/selected-io-result/README.md); no audited slice remains. Deferred fixture maintenance [#1656](https://github.com/GridSwarm/wiremux/issues/1656) is outside the completed slice graph. SIO-3 and SIO-4 are parallel-safe in separate worktrees after SIO-2; SIO-5 can overlap SIO-4 after SIO-3. Shared documentation conflicts require normal merge resolution, not invented dependency edges. Context targets are 24k (SIO-1), 36k (SIO-2A), 32k (SIO-2), 28k (SIO-3/4) and 20k (SIO-5) supplied tokens respectively; the plan owns the exact bounded context and contract for each.

Tracking issue: [#1642](https://github.com/GridSwarm/wiremux/issues/1642). OmniFocus program parent: `omnifocus:///task/k_9k2qBkFsk`. Live trackers own the issue/task mapping and mirror this committed frontier.

## Binding rules

Follow the plan's single-owner, representation, artifact, evidence, transition and behavioral-preservation rules. The shared review-loop/contract-closure baselines plus the repository [review overlay](../REVIEW-LOOP.md) apply. Per child: fresh-context `$implement-architecture-slice` → bounded review/verification → exact-head local and hosted certification → merge → append-dev-journal → update parent/tracker and complete its OmniFocus slice task. Only unblocked children receive the ready label. The track and program parent stay open until their children are complete. A plan commit is dispatch authority; it is not implementation certification.
