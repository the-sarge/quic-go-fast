# Consume Coordinator Implementation Plan

**Date:** 2026-07-05
**Status:** Accepted; implemented by PRs #562 and #566
**Track:** 4 of 4 in the 2026-07-05 third architecture deepening program
**Depends on:** PR #492 merged (hard dependency); Track 3 recommended first (both edit `dialPaired`)
**Related:** ADR-0006 frozen contracts; CONTEXT.md **Session consumption** (term added with this program)

## Goal

One deep module owns session consumption for an ephemeral wire — trigger
policy, once/done invariants, handler timing, and the bounded consume
budget — behind a ~3-method interface. It replaces two stream decorators
with opposite blocking semantics plus four scattered call sites, and
creates a substitutable consumer seam so tests stop provoking consume
failures by counting TLS handshakes.

## Current Shape (verified 2026-07-05 at PR #492 head `d03a143` — this track REQUIRES #492 merged; anchors will shift)

- `ephemeralSessionConsumer` (`wiremux.go:535-551`) mints a
  consume/report closure pair right after rendezvous pairing;
  `consumeAfterIdentityFailure` (`:553-560`) is called at four
  `dialPaired` sites; `consumeOnDirectUpgradeSuccessStream`
  (`:245-274`; async, fire-and-forget) and `consumeBeforeCloseStream`
  (`:276-299`; `Wire.Close` blocks on `consumeDone`) split the trigger by
  which path won.
- Cross-package trigger: connect's
  `attemptResources.closeDirectUpgradeRelay`
  (`connect/upgrade_resources.go:42-48`) type-asserts the private
  `directUpgradeSuccessCloser` interface (`:132-137`) and calls
  `CloseAfterDirectUpgradeSuccess` instead of `Close`.
- No substitutable consumer seam: root tests provoke consume
  failure/delay by counting TLS handshakes
  (`testServerTLSConfigWithDelayedConsumes` /
  `...WithFailingConsumes`, `wiremux_test.go` — pre-#492 numbering
  ~:2078-2118).
- **Grilling correction vs the 2026-07-05 review:** the review cited open
  bugs #441/#443 as this candidate's evidence; both are fixed by PR #492.
  The structural case stands — #492 fixes by adding a fourth scattered
  consume strand — but bug urgency is gone, which is why this track runs
  last.

## Decision

- New unexported `consumeCoordinator` in the root package, constructed in
  `dialPaired` immediately after `pair()` succeeds when the rendezvous
  identifier is a `relay.SessionID`. It owns: the session ID, relay
  endpoint and dial options, the error handler, the bounded consume
  budget, once-semantics, the done-channel invariant (deferred close —
  frozen), and panic-recovering handler dispatch.
- The constructor takes the consume function injected (production:
  `relay.ConsumeSession` via the bounded best-effort wrapper). This is
  the substitutable seam; two adapters justify it — the production relay
  consumer and a test fake.
- Interface (~3 methods):
  - `onIdentityFailure(cause error)` — skips `context.Canceled` /
    `context.DeadlineExceeded`, per #492 behavior.
  - `decorateRelay(stream) io.ReadWriteCloser` — returns a thin shell
    implementing `CloseAfterDirectUpgradeSuccess` that delegates to the
    coordinator.
  - `gateRelayWin(stream) io.ReadWriteCloser` — relay-path close gate
    delegating to the coordinator's done invariant.
- Frozen behaviors: `Wire.Close` waits for the bounded consume attempt
  and never for the user handler (PR #442/#492 semantics); the
  `relay.ErrSessionConsumed` suppression semantics of the handler are
  unchanged; direct-path consumption must not block `Dial` success; a
  mixed lower-level `connect.Negotiator` peer calling plain `Close` still
  skips consumption (documented caveat stands).

**Rejected alternative (do not do this):** replacing the duck-typed
`CloseAfterDirectUpgradeSuccess` hook with a connect public API (a result
field or option callback). That widens connect's exported interface for a
single consumer and breaks the frozen exported-API gate. Keep the hook;
point it at the coordinator.

**Rejected alternative (do not do this):** constructing the coordinator
before pairing or inside the upgrade-option path. Session consumption's
lifecycle begins when the rendezvous pairing burns the session — the
coordinator is born at that moment, not earlier or later.

**Non-goals:** no relay protocol change; no consumption concept for
long-lived (`PeerID`) rendezvous; #444's documentation improvements may
ride along but timing semantics do not change.

## Implementation Slices

**PR 1 (behavior-identical consolidation).** Introduce the coordinator;
the two decorators become delegating shells; the four
`consumeAfterIdentityFailure` sites become `onIdentityFailure` calls.
TDD: before touching code, pin the consume e2e tests named in issue
#443's verification list and keep them green throughout.

**PR 2 (test seam).** Inject a fake consumer in root tests; rewrite
consume failure/delay/panic coverage as unit tests at the coordinator
interface; retire the TLS-handshake-counting fixtures, keeping at least
one full e2e consume test against a live in-process relay.
Scenario-mapping checklist required for every retired fixture-driven
test.

## Acceptance Criteria

- Exactly one production call path into `relay.ConsumeSession` (inside the coordinator).
- The consume behavior matrix (direct win / relay win / identity failure / context-canceled skip) is covered at the coordinator interface with a fake consumer.
- TLS-handshake-counting fixtures are gone except any retained e2e test.
- `Wire.Close` ordering semantics unchanged (the #443 verification test list passes).

## Validation Gates

```bash
GOTOOLCHAIN=local go test . -run 'Consume' -count=1
GOTOOLCHAIN=local go test ./...
task verify
```

## Operating Discipline

Follow `docs/REVIEW-LOOP.md` for every PR. STOP condition: if preserving
"`Wire.Close` waits for the consume attempt but not the handler" requires
changing any observable close ordering, stop and check with the operator —
approach-level finding.
