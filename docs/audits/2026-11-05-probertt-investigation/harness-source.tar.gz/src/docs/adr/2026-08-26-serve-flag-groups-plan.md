# Serve-Flag Group Declaration Implementation Plan

**Date:** 2026-08-26
**Status:** Accepted; implemented (Slice 1 complete)
**Track:** 6 of 7 in the 2026-08-26 architecture deepening program
**Depends on:** nothing — safe to start first
**Related:** ADR-0005, ADR-0013, [`2026-08-08-architecture-deepening-program.md`](2026-08-08-architecture-deepening-program.md), [`2026-08-12-relay-abuse-signals-program.md`](2026-08-12-relay-abuse-signals-program.md), issue #1255 (slice 4 added the `relay-shaping-file` special case), `docs/COMPATIBILITY.md`
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** none

## Goal

Make "which serve flags belong to a relay-only group" a fact declared on each `serveFlagSpec` row, derived by one function from the parsed flag set, so `parseServeFlags` stops inferring group membership from how a flag's name is spelled and a table-driven test can walk every grouped row and prove `--no-relay` rejects it. The usage table already claims to be the single declaration of the serve flag surface; this slice makes that claim true for group membership, deletes the two prefix sniffs and the two derived booleans, and leaves flag names, defaults, rule strings, diagnostics, validation order, and the option-mapping ladder byte-identical. It is a locality slice with a newly possible test, not a deletion slice.

## Current Shape (verified 2026-08-26 at `543f9c32f5ac754ccf8a85292ded10372777d7dd`)

- `cmd/wiremux-server/usage.go:11-16` states that "The serve flag surface is declared exactly once, in serveFlagSpecs below" and that registration, serve usage, and root usage derive from it; `serveFlagSpec` (`:17-28`) carries `name`, `arg`, `usage`, and `add` — no group. `newServeFlagSet` (`cmd/wiremux-server/serve.go:80-91`) registers every row; `usage.go:254-261` renders both usage blocks from the same rows; `TestServeUsageCoversRegisteredFlagsExactly` (`cmd/wiremux-server/usage_test.go:18`) guards that derivation.
- Group membership is spelling-derived: `parseServeFlags` (`cmd/wiremux-server/serve.go:93-115`) runs `fs.Visit` at `:105-112` with two prefix sniffs at `:106-111` — `HasPrefix(f.Name, "relay-ephemeral-abuse-") && f.Name != "relay-ephemeral-abuse-backoff"` sets `cfg.relayEphemeralAbuseTuning`, and `HasPrefix(f.Name, "relay-assist-") || f.Name == "relay-shaping-file"` sets `cfg.relayAssistShaping`. The `|| f.Name == "relay-shaping-file"` special case landed in #1255 slice 4 and is the proof the sniff already leaked once.
- The two derived booleans live on `serveConfig` at `cmd/wiremux-server/serve.go:62` (`relayEphemeralAbuseTuning`) and `:64` (`relayAssistShaping`) and are consumed by `validateServeConfig` at `:123` (abuse flags with `--no-relay`), `:125` (shaping flags with `--no-relay`), `:129` (abuse flags with `--longlived-only`), and `:195-197` (tuning requires `--relay-ephemeral-abuse-backoff`).
- The rows those groups cover at HEAD: relay-assist shaping — `relay-assist-stream-rate`, `relay-assist-global-rate`, `relay-assist-egress-budget`, `relay-assist-egress-state`, `relay-shaping-file` (`cmd/wiremux-server/usage.go:187-215`); abuse tuning — the six rows spelled through the `flagRelayEphemeralAbuse*` constants (`usage.go:32-39,151-181`); abuse enable — `relay-ephemeral-abuse-backoff` (`usage.go:145`); relay mode — `ephemeral-only`, `longlived-only` (`usage.go:229-235`); ACME — `usage.go:97-133`; STUN — `usage.go:49-83`.
- The other cross-flag requirements in `validateServeConfig` are heterogeneous and each has its own diagnostic: egress budget requires the state path (`serve.go:183-184`), tuning requires backoff (`:195-197`), the three `--acme-*` flags require `--acme` (`:141-146`), EAB kid and key file set together (`:149-150`). None is a group-membership fact.
- The CLI manifest freezes the rule strings at `internal/compatmanifest/cli.go:98-128` and renders them byte-for-byte into the manifest at `:163-166`; flag names and defaults are frozen by `docs/COMPATIBILITY.md:141` and `TestServeFlagSetMatchesCompatibilityManifest` (`cmd/wiremux-server/compat_manifest_test.go:16-46`).
- `TestServeValidationRulesMatchCompatibilityManifest` (`cmd/wiremux-server/compat_manifest_test.go:68` onward) requires one probe per frozen rule string and pins each branch's exact diagnostic through `requireValidateBranches` (`:88-109`, "The prose itself stays non-contractual"). The rule "relay-assist shaping flags require the relay" has two hand probes at `:120-123` (`--relay-assist-stream-rate` and `--relay-shaping-file` under `--no-relay`, both expecting "relay-assist shaping flags cannot be used with --no-relay"); a new flag adds no obligation to this test.
- Would the tests catch a misgrouped future flag? No. The manifest test forces a manifest row (name/default) only; `cmd/wiremux-server/serve_test.go` `--no-relay` cases (`:222`, `:323-330`, `:547-633`) exercise specific flags; `TestShapingFileReachesTheRelayAndSelectsTheReload` (`serve_test.go:1514`) pins option propagation, not grouping. A flag spelled outside both prefixes (for example a hypothetical `--relay-withheld-allowance-bytes`, which Track 5 Decision D2 declined to create) would be accepted under `--no-relay` and silently ignored.

## Decision

- Add `serveFlagGroup` (an unexported `uint8` enum: `groupNone`, `groupRelayMode`, `groupRelayAbuse`, `groupRelayAbuseTuning`, `groupRelayAssistShaping`, `groupACME`, `groupSTUN`) and a `group serveFlagGroup` field on `serveFlagSpec`; every row in `serveFlagSpecs` declares its group (about thirty one-token edits).
- Add `serveFlagGroups(fs *flag.FlagSet) map[serveFlagGroup]bool`, derived from `fs.Visit` plus spec lookup by name, so the set of groups an invocation touched is computed from row facts, never from spellings. `parseServeFlags` uses it in place of the two sniffs; the parsed configuration carries the derived set where the two booleans were, and the four consumers at `serve.go:123,125,129,195` read the group facts instead.
- Delete the two prefix sniffs at `cmd/wiremux-server/serve.go:106-111` and the two `serveConfig` booleans at `:62,64`.
- Rescoped out: the card's `requires` column. The cross-flag requirements at HEAD (egress budget → state path; tuning → backoff; `--acme-*` → `--acme`; EAB pair set together) are heterogeneous (requires / set-together / conditional) and each has a diagnostic pinned by `requireValidateBranches`; a generic `requires` either changes diagnostics or needs per-row messages and deletes nothing. They stay as `validateServeConfig` cases. The option-mapping ladder (`relayOptionsForServe`, `serve.go:211` onward) is untouched.
- Manifest rule strings (`internal/compatmanifest/cli.go:98-128`) and every validation diagnostic stay byte-identical; flag names, defaults, and repeatability stay frozen.
- Add one table-driven test in `cmd/wiremux-server` that, for every row whose group is `groupRelayAssistShaping`, `groupRelayAbuse`, or `groupRelayAbuseTuning`, parses `--no-relay <flag> <value>` and requires the group's diagnostic ("relay-assist shaping flags cannot be used with --no-relay" or "relay ephemeral abuse flags cannot be used with --no-relay"). The two hand probes at `compat_manifest_test.go:121-122` fold into it; the rule "relay-assist shaping flags require the relay" keeps a verifier so the one-to-one rule/verifier correspondence the manifest test enforces is preserved.
- Binding bullets this slice sits beside, quoted: 2026-08-12 abuse-signals program — "Do not change the exported ephemeral abuse configuration or flag surface (`relay/abuse_backoff.go:10-184`); the serve-flag mirror candidate owns that territory if and when it is packaged." and "the serve-flag descriptor-table and wiremuxtest fixture-operation candidates await their own grillings and scoped handoffs." — this is that grilling, and it changes no exported abuse configuration or flag surface. 2026-08-08 program — "Do not introduce a startup transaction around `cmd/wiremux-server.serve`." — unaffected; this slice touches parsing and validation only. ADR-0005 D2's supervisor and shutdown phase are untouched.
- Sequencing note carried from the record: if Track 5's Decision D2 were ever reversed into a knob, this slice must land first so the new flag is grouped at declaration.

**Rejected alternative (do not do this):** A `requires` column or any generic cross-flag rule engine on the rows. It would change or duplicate pinned diagnostics and delete nothing.

**Rejected alternative (do not do this):** Keeping the sniffs and adding a test that enumerates spellings. That pins the leak instead of removing it; the next differently spelled flag still escapes.

**Rejected alternative (do not do this):** Exporting the group enum or moving grouping into `internal/compatmanifest`. Grouping is `cmd/wiremux-server` implementation vocabulary; the manifest freezes names, defaults, and rule strings, not groups.

**Non-goals:** no flag name, default, repeatability, rule string, diagnostic text, validation order, exit class, usage layout, option-mapping, or `relay` package change; no CONTEXT.md term (implementation vocabulary); no startup transaction; no change to the abuse flag surface or `relay/abuse_backoff.go`.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | complete (#1357) | Group membership declared on every `serveFlagSpec` row, derived by `serveFlagGroups`, consumed by validation; the two sniffs and two booleans deleted; a table-driven `--no-relay` rejection test over every relay-only grouped row | None | n/a — no temporary seam introduced |

## Implementation Slices

### Slice 1 — Declare serve-flag groups on the spec rows

**What it delivers:** A behaviour-identical `wiremux-server serve` in which each flag's group is a row fact, `serveFlagGroups(fs)` is the only derivation of which groups an invocation touched, `validateServeConfig` consumes those facts for its four group-based cases with unchanged diagnostics and order, and a table-driven test proves every relay-only grouped row is rejected under `--no-relay` with its group's diagnostic.

**Existing-work disposition:** new slice. The 2026-08-12 abuse-signals program explicitly left the serve-flag descriptor-table candidate awaiting its own grilling; no open PR, branch, or issue owns it.

**Blocked by:** None.

**Single owner after merge:** `serveFlagSpecs` rows own group membership. `serveFlagGroups` owns the derivation from a parsed flag set. `validateServeConfig` owns every cross-flag rule and its diagnostic, unchanged. `internal/compatmanifest` owns the frozen names, defaults, and rule strings.

**Authority completeness:** No persisted fact. The reference census must find no remaining `strings.HasPrefix` or literal-name comparison for group purposes in `parseServeFlags`, every row carrying a group, `serveFlagGroups` as the sole producer of the group set, and the four former boolean readers (`serve.go:123,125,129,195`) reading group facts. Constructors: `newServeFlagSet` unchanged apart from the row field. Restart round trip: none.

**Transitional-seam budget:** None. The sniffs and booleans delete in the same PR as the rows gain groups.

**Blast radius:** Production files: `cmd/wiremux-server/usage.go` (row field and enum) and `cmd/wiremux-server/serve.go` (derivation, deleted sniffs and booleans, consumer reads). Concurrency/ordering: none; parse-time only. Interfaces/schema: none exported; manifest byte-identical. Failures: the biggest risk is a diagnostic string drift, which `requireValidateBranches` pins exactly; the second is a misdeclared row, which the new table test catches at PR time. Performance, security, dependencies: none. No `relay` or downstream effect. Untraced effects: none after the census.

**Artifact classification:** The enum, row field, derivation, and consumer reads are shipped behaviour with intentionally unchanged observation. The table-driven rejection test is a verification aid and the point of the slice; it does not become a maintained product deliverable beyond the existing in-package test suite. This plan, issues, review receipts, and task mirrors are process/traceability metadata.

**Representation contract:** Supported input domain = every row in `serveFlagSpecs` (the finite registered flag set, which `TestServeFlagSetMatchesCompatibilityManifest` proves equals the manifest's flag set). Authoritative validator = `validateServeConfig`, unchanged. Representation owner = the row's `group` field for membership; `serveFlagGroups` for derivation. Guarantee = universal over the registered flag set because the table test iterates the rows themselves, not a hand list; a row with the wrong group fails the test, and a row with no group is `groupNone` and is outside the relay-only domain by declaration. Terminating evidence = the table test over every relay-only grouped row plus the existing manifest, usage, and validation tests.

**Contract closure:** Not triggered. A misgrouped flag has a material operator consequence (silently ignored under `--no-relay`), but the domain is the finite row list and the table test covers every row directly; there is one path (parse → derive → validate). The record judged closure not triggered.

**Evidence budget:** Positive: all of `cmd/wiremux-server/compat_manifest_test.go`, `usage_test.go`, and the `serve_test.go` `--no-relay` cases (`:222`, `:323-330`, `:547-633`); the new table test over every `groupRelayAssistShaping`, `groupRelayAbuse`, and `groupRelayAbuseTuning` row under `--no-relay`. Negative, one per failure mode: the table test's rejection is itself the negative case for grouping; a diagnostic drift is caught by `requireValidateBranches`; the `--longlived-only` abuse case (`compat_manifest_test.go:119`) and the tuning-requires-backoff case remain as the other consumers' negatives. Guard mutation: none named by the record. No race lane (no concurrency); no new platforms, repetitions, or fuzzing. Review budget = one initial review plus at most one replacement. Terminate when `go test ./cmd/wiremux-server/... ./internal/compatmanifest/...` passes, the census finds the sniffs and booleans absent and every row grouped, the rendered CLI manifest is byte-identical, and `task verify` passes at the exact head.

**TDD and preservation evidence:** Write the table-driven `--no-relay` rejection test first against the row groups (it cannot compile until the field exists, so add the enum and field, then the test, then watch the test fail for any row left `groupNone` that belongs to a relay-only group); then add `serveFlagGroups`, switch the four consumers, and delete the sniffs and booleans while `TestServeValidationRulesMatchCompatibilityManifest`, `TestServeFlagSetMatchesCompatibilityManifest`, `TestServeUsageCoversRegisteredFlagsExactly`, and every `serve_test.go` case stay green. Fold the two hand probes at `compat_manifest_test.go:121-122` into the table test while keeping a verifier entry for the rule string. No test may be weakened; no test deletes.

**Dispatch context budget:** This exact slice contract; the quoted 2026-08-12 and 2026-08-08 bullets; `cmd/wiremux-server/usage.go`, `cmd/wiremux-server/serve.go:50-199`, `cmd/wiremux-server/compat_manifest_test.go`, `cmd/wiremux-server/usage_test.go`, the `--no-relay` cases of `cmd/wiremux-server/serve_test.go`; `internal/compatmanifest/cli.go:90-170` read-only; `docs/COMPATIBILITY.md:138-146` read-only. This bounded context fits implementation, one review/fix cycle, and verification in one fresh agent context.

**Slice decision audit:** Strongest further split — add the enum and row field in one PR and the derivation plus deletions in another. Rejected: the interim state would carry both a row fact and a spelling sniff for the same membership, a duplicate representation with no owner. Strongest adjacent merge — fold into Track 5 Slice 2 because the record ties them ("if c7 ever produces a knob, c8 must land first"). Rejected: Track 5 Decision D2 produces no knob, the lanes are file-disjoint (`cmd/wiremux-server` versus `relay`), and merging would put a CLI test slice under a relay review budget. No blocking edge exists; the track is independent of every other track.

**Stop conditions:** Stop if (i) any rule string in `internal/compatmanifest/cli.go:98-128` would have to change; (ii) any diagnostic pinned by `requireValidateBranches` would change; (iii) the rendered CLI manifest differs by a byte; (iv) a flag name, default, or repeatability would change; (v) the change would require touching `relay/abuse_backoff.go` or any exported abuse configuration, contradicting the quoted 2026-08-12 bullet; or (vi) the rows cannot express a group without a `requires`-style column.

## Acceptance Criteria

- [x] Every `serveFlagSpecs` row declares a `serveFlagGroup`; `serveFlagGroups(fs)` is the only derivation of touched groups, and `parseServeFlags` contains no `strings.HasPrefix` or literal-name comparison for group membership.
- [x] `serveConfig` has no `relayEphemeralAbuseTuning` or `relayAssistShaping` field; the four validation cases formerly reading them read group facts and emit the same diagnostics in the same order.
- [x] A table-driven test iterates every row grouped `groupRelayAssistShaping`, `groupRelayAbuse`, or `groupRelayAbuseTuning` and proves `--no-relay <flag>` is rejected with that group's diagnostic; the two former hand probes are absent from `compat_manifest_test.go`, and the rule "relay-assist shaping flags require the relay" still has a verifier.
- [x] The rendered CLI manifest, every rule string, every flag name and default, and every validation diagnostic are byte-identical to HEAD; `TestServeFlagSetMatchesCompatibilityManifest`, `TestServeValidationRulesMatchCompatibilityManifest`, and `TestServeUsageCoversRegisteredFlagsExactly` pass unchanged in intent.
- [x] No `requires` column exists on `serveFlagSpec`; `relayOptionsForServe` and the `relay` package are unchanged.

Universal-criterion representation note: "every row" ranges over the finite `serveFlagSpecs` slice, owned by `cmd/wiremux-server/usage.go`, whose equality with the frozen manifest flag set is proved by `TestServeFlagSetMatchesCompatibilityManifest` (guarantee: universal by iteration over the slice itself; evidence: the table test plus the manifest test); "no `strings.HasPrefix`" ranges over `parseServeFlags` at the exact head (guarantee: universal by grep); "byte-identical" ranges over the rendered CLI manifest, owned by `internal/compatmanifest` and pinned by its manifest fixture tests.

## Validation Gates

The new table-driven `--no-relay` rejection test; `go test ./cmd/wiremux-server/... ./internal/compatmanifest/...` (including `TestServeFlagSetMatchesCompatibilityManifest`, `TestServeValidationRulesMatchCompatibilityManifest`, `TestServeUsageCoversRegisteredFlagsExactly`, and the `serve_test.go` `--no-relay` cases); `./scripts/check-gofmt.sh`; `task docs-check`; exact-head `task verify` plus same-head hosted CI. No race lane is justified for this parse-time change; the repository race gates run inside `task verify` regardless. Follow the repository Go toolchain supply-chain audit before any Go command.

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) and the certification lanes in [`docs/CI.md`](../CI.md). Treat a changed rule string, diagnostic, flag name, default, or manifest byte, a `requires` column, or any touch of the exported abuse flag surface as an approach stop rather than refactor latitude; grouping is implementation vocabulary — do not coin a domain term for it.
