# Wire Teardown-Error Normalization Implementation Plan

**Date:** 2026-07-07
**Status:** Accepted; implemented by #597 and #612
**Program:** Track W1 of the consumer contract program
(`org-docs/docs/decisions/2026-07-07-consumer-contract-program.md`)

## Goal

Errors surfaced by `Wire` reads/writes during and after teardown are
classifiable via wiremux-owned identities on both the relay and direct
(QUIC) paths, so consumers stop matching transport-internal error types
and strings. The contract: benign-teardown noise is distinguishable from
real failure using `errors.Is` against stdlib/wiremux identities only.

## Current Shape (verified 2026-07-09 after #612)

- Root `Wire` I/O classifies local close and peer teardown with
  `wiremux.ErrWireClosed` while preserving underlying error identities.
  Graceful peer-close reads remain `io.EOF`, and channel authentication or
  truncation errors take precedence over ordinary teardown classification.
- Root classification knows only shared channel, stdlib, and syscall
  identities: `channel.ErrClosed`, `net.ErrClosed`, `io.ErrClosedPipe`, and
  connection-reset/broken-pipe errnos. It has no quic-go vocabulary and does
  not recognize raw quic-go artifact strings or types by itself.
- `transport/quic` owns the quic-go mapping. Its stream adapter tags
  `*quic.StreamError`, `"write on closed stream "`, and
  `"close called for canceled stream "` artifacts with a message-transparent
  `net.ErrClosed` identity while retaining the original cause. Live transport
  tests pin those upstream artifact shapes against quic-go upgrades.
- Custom `connect.Transport` implementations conventionally surface
  `net.ErrClosed` or `io.ErrClosedPipe` from stream teardown. Root `Wire` also
  recognizes channel and syscall identities contributed by other layers; that
  broader root vocabulary is not an obligation for transport authors to
  synthesize.

## Decision

- Post-close and peer-teardown read/write errors on a `Wire` are
  normalized at the `Wire` boundary: consumers see `io.EOF`,
  `net.ErrClosed`, or the wiremux-owned `wiremux.ErrWireClosed` sentinel,
  never a quic-go type or message as the only
  classification handle. The underlying error remains wrapped
  (`errors.As` still reaches it) — normalization adds an identity, it
  does not destroy information.
- The contract is documented on `Wire` godoc and pinned by tests on both
  paths (relay stream teardown; QUIC stream teardown post-close and
  peer-initiated), including a test that exercises the exact cases
  tapmux's `close_artifact.go` enumerates.
- Placement is settled: transport-specific artifact recognition belongs in
  the transport adapter, and root `Wire` classification consumes only shared
  closed-wire identities. The default implementation lives in
  `transport/quic`; future transports inherit the documented
  `connect.Transport` obligation without adding their private vocabulary to
  root wiremux.

**Rejected alternative (do not do this):** exporting a
`wiremux.IsTeardownNoise(err)` classifier over raw transport errors —
that ratifies the leak instead of sealing it; consumers would still see
transport-specific errors in logs and tests.

**Non-goals:** no change to error identities already exported
(`channel.ErrClosed`/`ErrTruncated` semantics unchanged); no consume or
upgrade behavior change; no relay protocol change.

## Implementation Slices

**PR 1 (#597).** Added the sentinel and root normalization contract, pinned
relay and direct teardown behavior, and documented `Wire` and
`connect.Transport` expectations.

**PR 2 (#612).** Moved quic-go artifact recognition into the
`transport/quic` stream adapter, removed quic-go vocabulary from root
classification, and retained live artifact canaries at the owning layer.

## Acceptance Criteria

- A consumer test can classify every teardown case in tapmux's
  `close_artifact.go` using only stdlib + wiremux identities.
- No production wiremux path returns a quic-go error without a wiremux
  or stdlib identity attached.
- Existing consumers relying on `channel.ErrClosed`/`ErrTruncated` are
  unaffected (`go test ./...` green with no test edits outside new
  coverage).

## Validation Gates

```bash
GOTOOLCHAIN=local go test ./transport/... ./channel/... . -count=1
GOTOOLCHAIN=local go test ./...
task verify
```

## Operating Discipline

Follow `docs/REVIEW-LOOP.md`. STOP condition: if normalization would
change an error identity an existing test pins (beyond adding wrapping),
stop — frozen-identity adjudication.
