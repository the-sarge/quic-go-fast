# Settlement result admission Implementation Plan

**Date:** 2026-09-24
**Status:** Complete; A1 delivers settlement-owned result admission
**Track:** A of seven in program AH-20260924
**Depends on:** Nothing — independent frontier
**Program:** [2026-09-24-architecture-deepening-program.md](2026-09-24-architecture-deepening-program.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers and stop conditions
**Audit history:** [2026-09-24-architecture-handoff-audit.md](2026-09-24-architecture-handoff-audit.md)
**Parent issue:** pending

## Goal

Settlement result admission: deepen the existing module at its private interface, concentrating the caller knowledge identified below. The scope is one independently green PR, not a framework or public-interface redesign.

## Current Shape (verified 2026-09-24)

[establishment.go:99](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/establishment.go#L99) · [establishment_settlement.go:168](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/establishment_settlement.go#L168) · [establishment_settlement.go:194](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/establishment_settlement.go#L194) · [establishment_settlement.go:253](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/establishment_settlement.go#L253)

**Governing source surface:** establishment.go, establishment_settlement.go, their focused tests; relevant Wire construction and upgrade-plan registration/packet settlement excerpts read-only. No selected setup, negotiation engine, preflight, or public interface rewrite.

## Decision

### Exactly what enters the interface?

The actual `UpgradeResult` and existing concrete carrier inputs. A private `admitUpgrade(result, rawRelay, managedCarrier)` operation is sufficient; the managed carrier is present only for the existing managed mode. The registered channel carrier already supplies the relay-alias identity, so do not pass a second independently chosen alias or topology. Names are illustrative.

### What ordering is mandatory?

Register the result and settle packet ownership first; observe selected failure next; then reject a nil stream, validate canonical topology, derive close behavior, and publish through existing settlement success. Registration conditionally retires selected packet authority only for the existing canonical, untransferred relay result. Moving validation ahead of registration would change ownership behavior.

### Who closes a rejected stream?

Settlement applies the existing alias rule: close a distinct rejected stream through its own Close; leave the exact registered relay alias to settlement failure cleanup. A non-nil transport stream owns packet disposal under ADR-0011. Do not independently close its raw socket.

### Can initial and managed close behavior become identical?

No. Initial direct transport can lack optional Abort, and a forwarding Abort returning `ErrUnsupported` must not cause an extra Close. Managed direct transport must provide Abort. Managed relay retains its separate abort and graceful operations. Preserve these fixed policies inside admission; do not introduce an extensible policy framework.

### What stays in the caller?

Pairing, selected setup timing, authentication/channel construction, negotiation, and negotiation-error presentation stay where they are. The existing `defer settlement.finish()` remains in the establishment frame, including panic coverage. Consumption gating and auth transfer remain in settlement success.

### How much state should the change add?

No new owner, registry, independently closable result, repeated-result identity mechanism, or separate “admitted but not published” lifetime. A one-operation interface should remove caller sequencing rather than add a new protocol.

### Alternatives rejected

Do not introduce an extensible lifetime-policy interface or an opaque admitted-result followed by publish. The former adds policy authority for two fixed modes; the latter creates an unused two-step publication protocol. Existing concrete carriers are sufficient.

### Settled decisions and non-goals

The [no-code decisions](2026-09-24-architecture-no-code-decisions.md) close adjacent directions; they are not successor slices. Preserve the existing [ADR-0010 auth-release](adr-0010-auth-context-lifecycle-ownership.md), [ADR-0011 transport disposal](adr-0011-transport-stream-disposal-capability.md), [settlement D7](2026-07-29-establishment-settlement-plan.md), [selected-I/O ownership](2026-09-22-selected-io-plan.md) and [managed-migration contract](../MANAGED-MIGRATION.md) where touched. Broader deferred upgrade directions remain governed by the [August 26 program](2026-08-26-architecture-deepening-program.md). No new domain terms are introduced: this uses the existing Wire, MigrationSession, establishment settlement, ordered choice and reply concepts. Do not expand the scope to improve neighboring behavior, uniformize intentional error projections, or create new public interfaces. Keep current successful behavior except the explicitly accepted version>=2 custody retention improvement in track B.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| A1 | Complete | Settlement result admission | None | None introduced; completes its own interface migration |

## Implementation Slices

### Slice A1 — settlement-result-admission

**What it delivers:** Settlement result admission through the real owner and relevant callers, with the acceptance criteria below; one intended PR.

**Existing-work disposition:** New slice. No open implementation PR for this contract was found. Retain existing merged behavior; no unmerged branch is an established dependency. [Audit history](2026-09-24-architecture-handoff-audit.md) records the checked open work and adjacent issues. Recheck related PRs at execution preflight; audit any new overlapping work rather than adopting it silently.

**Blocked by:** None. Recommended sequencing is not a blocking edge.

**Single owner after merge:** establishmentSettlement owns result admission, rejection consequences, and publication. Existing upgrade resources own packet transfer; auth owner and consume coordinator keep their present authority.

**Authority completeness:** No newly authoritative persisted fact or schema. Existing constructors, validation and affected destructive consumers are within the scoped source surface; restart round-trip is not applicable. If implementation adds persisted authority or a new constructor family, stop and re-audit before proceeding.

**Transitional-seam budget:** None introduced. Migrate the listed callers in this PR and remove obsolete caller-owned recipes. Existing representations with distinct authority remain intentional, not temporary duplicate owners. There is no unmerged removal slice or widened seam.

**Blast radius:** establishment.go, establishment_settlement.go, their focused tests; relevant Wire construction and upgrade-plan registration/packet settlement excerpts read-only. No selected setup, negotiation engine, preflight, or public interface rewrite. Trace touched shared state and ordering through the named owner and preservation tests. Public APIs, wire/JSON schemas, dependencies, native routing, security/auth authority and performance guarantees remain unchanged. No benchmark or optimization claim. No intended runtime behavior change. No known untraced effect is accepted; discovering one requires scoped re-audit or an approach stop.

**Artifact classification:** Runtime changes are shipped behavior; lifecycle/validity guards are required safety enforcement. Focused tests and existing test adapters are verification aids, not separately approved maintained verification products. This plan, review receipts, issues and task mirrors are process/traceability metadata. No new analyzer, harness, CI lane or maintained-aid exception.

**Representation contract:** Supported initial Dial and managed establishment UpgradeResult values, including canonical relay/direct outcomes and the already-handled nil, invalid-topology, alias, selected-failure and Abort-capability rejections. UpgradeResult.CarrierTopology and existing settlement/packet transfer types own representation. Canonical-subset guarantee for these constructors and rejected shapes; no claim about arbitrary forged transport implementations.

**Contract closure:** Triggered for this accepted bounded invariant: establishmentSettlement owns result admission, rejection consequences, and publication. Existing upgrade resources own packet transfer; auth owner and consume coordinator keep their present authority. Material consequences include incorrect resource disposal or publication. Independently reachable semantic states below require more than a happy-path/failure pair; the compact census covers the accepted family without crossing unrelated axes. No repeated-root conclusion is asserted; any later recurrence must pass the shared exact invariant/central-owner side-by-side comparison.

| Semantic class | Disposition | Enforcement owner | Budgeted evidence | Status |
| --- | --- | --- | --- | --- |
| Canonical relay/direct and packet transfer | Register and settle before acceptance; only eligible relay retirement | admitUpgrade / existing packet owner | Existing reachable matrix plus canonical relay/direct admission cases | Covered by admission and preservation tests |
| Selected failure with bad result | Selected cause precedes nil/topology rejection | admitUpgrade | Combined selected failure + bad result case | Covered by admission and preservation tests |
| Nil or invalid topology, alias versus distinct stream | Existing failure kind; close only distinct rejected stream | admitUpgrade | Nil, invalid topology and alias disposal cases | Covered by admission and preservation tests |
| Initial versus managed direct Abort | Optional/suppressed unsupported versus required; unchanged Close authority | admitUpgrade | Initial optional/unsupported and managed missing Abort cases | Covered by admission and preservation tests |
| Panic, release and consumption publication | Frame defer and success barriers retain authority | finish / succeed / auth owner | Existing panic, release-before-finish and consume tests | Covered by admission and preservation tests |

**Evidence budget:** At most 9 new representative semantic cases plus the named existing regressions and mandatory repository gate. Count table subcases as cases. One normal and one focused race invocation on a successful final candidate; reruns only after diagnosed failure or relevant code changes. Zero required guard mutations; at most one central guard-bypass experiment if needed to show inherited coverage exercises its owner, with no syntax-variant campaign. No new operational/platform/repetition scope. One fully briefed fresh review, at most one replacement after accepted fixes; verification remains scoped to accepted findings. Terminate after this evidence passes with no unresolved stop-for-decision. This budget does not limit existing repository-required gates; it prevents optional evidence inflation.

**TDD and preservation evidence:** First add TestEstablishmentSettlementAdmission with canonical relay/direct, selected-failure precedence, nil/topology, alias/distinct, and initial/managed Abort cases (at most nine table cases). Characterization assertions can pass before the refactor; then route the real establishment caller through admission. Preserve TestEstablishmentSettlementReachableMatrix, TestEstablishmentSettlementSuccessConstructionPanicReleasesAuth and TestEstablishmentSettlementWithholdsCompletedReleaseUntilFinish, plus managed establishment and auth/consume tests.

**Dispatch context budget:** Target at most 26,000 input tokens: this current plan and exact slice; current governing invariants from relevant ADR sections; the scoped source functions and named test bodies; current repository review/CI overlays and shared baselines; relevant unresolved findings only. No entire prior report history, duplicate historical plans or full engine dumps. No governing diff is needed for a new slice; later amendments supply a bounded current-contract diff. One owner-level change and this finite test surface must leave room for implementation, local fixes and verification in one fresh agent context. If the required context exceeds this bound or the change no longer fits one PR, re-audit before editing.

**Slice decision audit:** Splitting validation from publication would leave caller sequencing or an admitted-but-unpublished lifetime. Splitting initial/managed adoption would retain two mutation recipes. One narrow post-upgrade operation and both real callers fit the declared context. The strongest adjacent merge case is shared files or convenient scheduling, which is insufficient: adjacent tracks can each deliver a coherent result independently. No blocker is needed for convenience. A later real dependency must be demonstrated and re-audited.

**Stop conditions:** Stop for representation/ownership change, new public authority or schema, changed protocol/timing/error policy outside this contract, inability to preserve the named outcomes, untraced shared-state effects, evidence needs beyond this budget, or a one-PR/context boundary failure. Apply the shared precise-root/representation stops to review and verification; do not expand the latest checklist. Same-child re-audit is allowed only within the accepted representation, outcome and one-PR boundary; otherwise return for decision or scoped architecture-handoff.

## Acceptance Criteria

- [x] The real establishment caller supplies the actual result to one settlement operation and no longer orchestrates result registration, topology rejection/disposal or close-policy assignments.
- [x] Admission preserves the ordered dispositions in the closure table for the declared result domain, including registered relay alias and packet transfer authority.
- [x] Initial and managed Close/Abort behavior, the frame defer, release observation and consumption publication remain unchanged under the named tests.

The representation contract above scopes quantifiers such as “one,” “unchanged,” and “once” to the named supported constructors, consumers and semantic classes; finite named tests and source-owner inspection terminate acceptance. No exhaustive schedule or external-language proof is claimed.

## Validation Gates

Before any Go build/test command, perform the installed/base Go audit in AGENTS.md and stop below the approved floor. Write the named characterization/regression cases first. Run `go test -count=1 .` and a focused race invocation through `./scripts/run-go-test-require-match.sh -race -run '^(TestEstablishmentSettlement|TestManagedEstablishment|TestDial.*Auth|TestAuthContext|TestTransportAuth)' -count=1 .` with `GOMAXPROCS=1 GOTOOLCHAIN=local`. Then run `task verify` for the exact final pushed head; retain head/base and results. Existing repository gates are not replaced by these focused cases. No added native-platform matrix, repetitions, fuzzing or hosted experiment. Required CI must report success (not skipped) on that same head before squash merge.

## Operating Discipline

Follow the shared `_shared/REVIEW-LOOP.md` and `_shared/CONTRACT-CLOSURE.md` baselines supplied by `$implement-architecture-slice` (reachable as `../_shared/` from its skill directory), composed with the repository [review overlay](../REVIEW-LOOP.md), [CI policy](../CI.md), [conventions](../CONVENTIONS.md), and root [AGENTS.md](../../AGENTS.md). No repository contract-closure overlay exists; use the shared baseline directly. The baselines govern artifact/representation gates, finite evidence, semantic-family closure, review and verification-aware approach stops, exact-head local certification, same-head hosted CI, merge, journal and pointer-only tracking. Do not copy or strengthen them in this plan.

After exact-head certification and same-head CI, merge, run `$append-dev-journal`, reconcile the parent/tracker frontier and complete only this slice’s OmniFocus task. Parent and OmniFocus notes carry state and pointers, not substantive contracts or certification SHAs. Dispatch is an operator action; this handoff does not launch implementation.
