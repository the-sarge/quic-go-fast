# Rendezvous Disposition Seam Implementation Plan

**Date:** 2026-07-07
**Status:** Accepted; implemented by #604 and #611 for #550.
**Program:** Track W2 of the consumer contract program
(`org-docs/docs/decisions/2026-07-07-consumer-contract-program.md`)
**Depends on:** `docs/adr/2026-07-05-consume-coordinator-plan.md` implemented
**Related:** codemux C1 companion plan
(`codemux/docs/adr/2026-07-07-handshake-disposition-marking-plan.md`);
codemux DEV-JOURNAL open item T2 (identity↔relay lifecycle seam) — this
plan resolves it

## Goal

Identity layers declare ephemeral rendezvous-ID disposition — spent or
retryable — across the `Authenticator` seam, and wiremux enforces
consumption accordingly. Before #604/#611, wiremux inferred disposition from
failure stage even though only the identity layer knew its scheme's truth. The
concrete gap was that a scheme whose successful handshake spends the rendezvous
ID (codemux's one-shot muxcode) could not tell wiremux, so a dial that passed
identity but failed at a post-success auth-context, channel, or upgrade stage
left the session un-consumed and every consumer hand-rolled the burn (tapmux
`internal/tunnel/wiretunnel/dialer.go:305-306`). #611 closes that gap with
`connect.OneShotRendezvous`.

## Current Shape (verified 2026-07-09 after PR 2)

- `dialPaired` routes identity-stage failure consumption through
  `consumeCoordinator.onIdentityFailure`; the coordinator consults
  `connect.RendezvousDisposition` before falling back to the
  default identity-failure heuristic.
- `DispositionSpent` consumes with the without-cancel default budget,
  overriding context cancellation, deadline, and relay-I/O heuristic skips.
  `DispositionRetryable` never consumes. `DispositionUnknown` keeps the
  existing heuristic: skip when the cause tree contains
  `context.Canceled`/`context.DeadlineExceeded` or is pure relay-I/O closure.
- Channel-construction failure deliberately leaves the SessionID
  retryable by default (the `channel.NewStream` failure branch); upgrade
  failure does not consume by default. Authenticators that implement
  `connect.OneShotRendezvous` consume after post-success auth-context
  validation, channel, upgrade, or nil-stream failure.
- Success paths consume through `consumeCoordinator`.
- **PR 1 adjudication:** codemux `ErrHandshakeIO`-class pre-verdict
  failures are retryable and must be marked with
  `connect.MarkRendezvousRetryable` by the identity layer. Leaving them
  `DispositionUnknown` keeps today's heuristic and can over-consume
  non-closure-shaped pre-verdict I/O. PR 1 added and preserved the vocabulary;
  #611 enforced it.
- Consumer evidence: tapmux re-encodes codemux's spent truth table
  (`classify.go:78-85`), tombstones proactively on terminal PAKE verdicts
  (`dialer.go:290-293`, now redundant with #492 except the
  cancellation-joined edge), and tombstones on post-success dial failure. #611
  makes that post-success spend expressible through `connect.OneShotRendezvous`;
  downstream hand-rolled tombstones are follow-up migration cleanup.

## Downstream typed-nil marker audit (verified 2026-07-10)

The audit for wiremux#640 checked the current remote default-branch heads for
direct marker use, direct `Unwrap` assumptions, typed-nil fixtures, and related
`errors.Is` / `errors.As` assertions:

- **codemux** at `de971a7966e90c4b270974dd4d2ed0492b8af48c` applies
  `connect.MarkRendezvousSpent` and `connect.MarkRendezvousRetryable` to a
  non-nil `*classifiedHandshakeError` (`pake/errors.go:128-145`) and uses
  `connect.RendezvousDisposition` as the lifecycle authority throughout PAKE
  and wiremux integration tests. Its direct topology assertion
  (`pake/handshake_test.go:310-329`) uses an ordinary non-nil cause. The
  typed-nil characterization (`pake/handshake_test.go:419-441`) exercises a
  typed-nil transport error below the non-nil classified wrapper, while
  `pake/wiremux_integration_test.go:322-378` expects root `wiremux.Dial` to
  preserve retryable disposition and sanitize unsafe `errors.As` exposure.
  No test or call site requires a disposition marker to unwrap directly to a
  typed-nil child.
- **keymux** at `cda9e1126b590284e391129fa36e593f927d8e88` remains a
  documentation-only repository with deferred implementation. It has no Go
  module, marker call site, typed-nil fixture, or error-tree assertion.
- **tapmux** at `5b9670f5cca51b79e84929f0cb7e4fdbfcaae9ec` adapts PAKE
  results through `wiremux.AuthenticatorFunc`
  (`internal/tunnel/wiretunnel/dialer.go:274-306`) and classifies failures with
  `errors.Is` against wiremux stage and codemux PAKE sentinels
  (`internal/tunnel/wiretunnel/classify.go:43-94`). It does not call the
  disposition markers or `connect.RendezvousDisposition`, has no typed-nil
  marker fixture, and does not directly unwrap a disposition marker. Its local
  `Unwrap` methods belong to unrelated tapmux error wrappers.

No audited consumer encodes the pre-hardening behavior where a marker exposed a
typed-nil child. The marker change therefore requires no downstream source PR;
the existing tapmux hand-rolled tombstone cleanup remains a separate migration
from #611 rather than a typed-nil compatibility issue.

## Decision

Grilled and settled 2026-07-07 (operator: sarge).

### DP1: identity declares, wiremux enforces

The identity layer gains a way to declare disposition; wiremux keeps
owning consume mechanics (once-semantics, bounded budgets, handler
dispatch — the coordinator). Wiremux's stage heuristics remain the
default when no declaration is present.

### DP2: failure path — transparent error markers in `connect`

`connect` exports marker wrappers, e.g.:

- `connect.MarkRendezvousSpent(err error) error`
- `connect.MarkRendezvousRetryable(err error) error`
- `connect.RendezvousDisposition(err error) Disposition` with
  `Disposition ∈ {DispositionUnknown, DispositionSpent, DispositionRetryable}`

For causes that are neither nil nor typed-nil, markers are
message-transparent (`Error()` delegates to the wrapped error; `Unwrap()`
preserves `errors.Is`/`As` chains) so downstream byte-identical error-string
guarantees survive. They live in `connect` because it is the seam package both
identity layers and the root already import.

**2026-07-10 typed-nil amendment.** Passing a typed-nil cause returns a
non-nil marker that retains its declared disposition but has an empty message
and terminates child traversal; it does not expose the typed-nil cause through
`Unwrap`, `errors.Is`, or `errors.As`. Passing nil still returns nil. The
`MarkRendezvousSpent` and `MarkRendezvousRetryable` godoc is authoritative for
these defensive boundary cases.

### DP3: success path — optional capability interface on Authenticator

An optional interface (working name `connect.OneShotRendezvous` /
`SuccessSpendsRendezvous() bool`) that an `Authenticator` implements when
a successful handshake spends the rendezvous ID. Scheme-static, declared
by the identity layer that vends the authenticator; consumers inherit it.
`AuthContext` is not widened (frozen minimal seam; exists only on
success; would tax every BYO implementer).

### DP4: enforcement in the consume coordinator

- Identity failure: coordinator consults `RendezvousDisposition(cause)`
  first. `DispositionSpent` → consume, **overriding the
  skip-on-cancellation heuristic** (an explicit marker means the verdict
  was reached; use the without-cancel budget). `DispositionRetryable` →
  never consume. `DispositionUnknown` → today's #492 heuristic exactly.
- Post-identity-success failure (auth-context validation, channel, upgrade,
  nil-stream): if the authenticator declared success-spends, consume
  (without-cancel budget). Otherwise today's behavior (channel failure stays
  retryable by default).

### DP5: predicates, not a typed DialError

No new error type from `Dial`; wrapping shapes and error identities stay
frozen. Consumers classify with existing stage sentinels plus
`connect.RendezvousDisposition(err)` (dispositions survive `Dial`'s stage
wrapping via `Unwrap`). A transient-vs-permanent axis is explicitly
YAGNI'd until a consumer demonstrates a decision it cannot derive.

### DP6: ephemeral-only; long-lived is keymux-PRD territory

The mechanism applies to `relay.SessionID` rendezvous only. Long-lived
`PeerID` deregistration is a different lifecycle; keymux's PRD takes the
*pattern* (identity declares, transport enforces) as input and designs
its own surface. Naming stays mode-agnostic ("rendezvous disposition") to
keep that door open.

**Rejected alternative (do not do this):** widening `AuthContext` with a
disposition method — frozen seam, success-only existence, BYO burden.

**Rejected alternative (do not do this):** a new `Authenticate` signature
returning disposition — needless breakage; the optional interface and
markers compose without it.

**Rejected alternative (do not do this):** wiremux never consuming
(identity layer owns all burning) — reverts #492, breaks frozen behavior,
duplicates consume machinery into every identity layer.

**Non-goals:** no relay protocol change; no long-lived consumption
concept (Track 4 non-goal stands); no change to upgrade choreography or
`connect.ValidateUpgradeOptions`; teardown-error normalization is W1,
socket ownership is W3.

## Implementation Slices

**PR 1 (connect vocabulary).** Markers, `Disposition`, predicate, godoc
contract, unit tests including marker transparency (message, `errors.Is`
through `fmt.Errorf %w` wrapping). The `ErrHandshakeIO` adjudication is
recorded above: codemux pre-verdict handshake I/O is
`MarkRendezvousRetryable`; enforcement landed in #611 for #550.

**PR 2 (coordinator enforcement).** Landed in #611. Disposition consultation in
the coordinator per DP4, including the post-success trigger and the
marker-overrides-cancellation-skip rule. Behavior matrix covered at the
coordinator interface with a fake consumer (the Track 4 seam). Unmarked /
capability-free paths pinned to today's behavior.

## Acceptance Criteria

- Unmarked errors and capability-free authenticators produce byte-for-byte
  today's consume behavior (existing consume e2e tests pass unchanged).
- A marked-spent identity failure consumes even when joined with
  `context.DeadlineExceeded`.
- A marked-retryable identity failure never consumes.
- With a success-spends authenticator, channel-stage and upgrade-stage
  failures consume the session.
- `connect.RendezvousDisposition` returns the declared disposition
  through `Dial`'s stage wrapping.

## Validation Gates

```bash
GOTOOLCHAIN=local go test . -run 'Consume|Disposition' -count=1
GOTOOLCHAIN=local go test ./...
task verify
```

## Operating Discipline

Follow `docs/REVIEW-LOOP.md` for every PR. STOP condition: if pinning
"unmarked = today's behavior" surfaces a case where the #492 heuristic
and a reasonable identity-layer intent disagree beyond the documented
`ErrHandshakeIO` mismatch, stop and surface it — that is an adjudication,
not a silent choice.
