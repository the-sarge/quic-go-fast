# Wire-owned migration transitions Implementation Plan

**Date:** 2026-09-24
**Status:** Complete
**Track:** C of seven in program AH-20260924
**Depends on:** Nothing — independent frontier
**Program:** [2026-09-24-architecture-deepening-program.md](2026-09-24-architecture-deepening-program.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers and stop conditions
**Audit history:** [2026-09-24-architecture-handoff-audit.md](2026-09-24-architecture-handoff-audit.md)
**Parent issue:** pending

## Goal

Wire-owned migration transitions: deepen the existing module at its private interface, concentrating the caller knowledge identified below. The scope is one independently green PR, not a framework or public-interface redesign.

## Current Shape (verified 2026-09-24)

[migration.go:183](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/migration.go#L183) · [migration.go:244](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/migration.go#L244) · [migration.go:297](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/migration.go#L297) · [wiremux.go:604](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/wiremux.go#L604) · [managed_establishment.go:117](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/managed_establishment.go#L117)

**Governing source surface:** migration.go, wiremux.go migration/close sections, managed_establishment.go Close facade, migration/managed/selected-lifetime tests. Keep establishment, auth release executor, transport negotiation and public migration semantics unchanged.

## Decision

### Which operations belong on Wire?

Private reserve, identity-checked release, seal-and-retire, and managed-close operations. Reservation checks closed before busy under the existing lock. Release clears only its own session slot. Read-only diagnostic queries need not all be wrapped; the goal is to remove external writes and lock choreography, not hide every field mechanically.

### What makes seal-and-retire deep enough?

It checks session context, old-Wire close/slot identity, and candidate close in the current order under the old owner’s lock. On success it seals, publishes close admission, detaches the session, unlocks, and then runs the old Wire’s existing Abort. No carrier I/O while holding that lock. The caller never has to remember detach-before-abort.

### How does the session interpret the result?

Return an explicit sealed/not-sealed outcome plus the existing error/retirement diagnostics; a nonnil error alone must not mean cutover failed. Before seal, this migration does not retire the old carrier and the session closes the candidate; an independent concurrent old close retains its own outcome. After seal, context expiry is diagnostic; actual candidate closure can make the outcome interrupted. The session keeps final outcome publication.

### Can a failed candidate cause rollback after seal?

No. The old carrier has been retired. Preserve current committed/interrupted semantics and the documented absence of bilateral atomic cutover. Keep the actual post-retirement candidate check. Do not claim to prevent every concurrent candidate close or add cross-Wire locking.

### Can ManagedWire.Close simply call Wire.Abort?

No. Managed Close currently marks close admission, invokes abort while discarding its returned error, and then calls Wire.Close. Wire.Abort starts aggregate teardown first and includes its abort error in the result. Move the entire existing managed-close recipe into a Wire method without normalizing these differences.

### Who handles old-Wire teardown and auth?

Wire remains the sole aggregate owner. Teardown still cancels and joins an attached session; the committing session detaches before retirement so it cannot join itself. Auth release starts independently of a possibly blocked stream Close. The selected teardown decision is not reducible to the closeCalled flag.

### Does this need a registry, new lock, or settlement prerequisite?

No. Keep the existing lock and state. Several Wire methods may legitimately write close admission. Do not add a generic attachment registry, retire ManagedWire, merge fresh-input disposal with settlement, or make admission/selected setup a prerequisite.

### Settled decisions and non-goals

The [no-code decisions](2026-09-24-architecture-no-code-decisions.md) close adjacent directions; they are not successor slices. Preserve the existing [ADR-0010 auth-release](adr-0010-auth-context-lifecycle-ownership.md), [ADR-0011 transport disposal](adr-0011-transport-stream-disposal-capability.md), [settlement D7](2026-07-29-establishment-settlement-plan.md), [selected-I/O ownership](2026-09-22-selected-io-plan.md) and [managed-migration contract](../MANAGED-MIGRATION.md) where touched. Broader deferred upgrade directions remain governed by the [August 26 program](2026-08-26-architecture-deepening-program.md). No new domain terms are introduced: this uses the existing Wire, MigrationSession, establishment settlement, ordered choice and reply concepts. Do not expand the scope to improve neighboring behavior, uniformize intentional error projections, or create new public interfaces. Keep current successful behavior except the explicitly accepted version>=2 custody retention improvement in track B.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| C1 | Complete | Wire-owned migration transitions | None | None introduced; completes its own interface migration |

## Implementation Slices

### Slice C1 — wire-migration-transitions

**What it delivers:** Wire-owned migration transitions through the real owner and relevant callers, with the acceptance criteria below; one intended PR.

**Existing-work disposition:** New slice. No open implementation PR for this contract was found. Retain existing merged behavior; no unmerged branch is an established dependency. [Audit history](2026-09-24-architecture-handoff-audit.md) records the checked open work and adjacent issues. Recheck related PRs at execution preflight; audit any new overlapping work rather than adopting it silently.

**Blocked by:** None. Recommended sequencing is not a blocking edge.

**Single owner after merge:** Wire owns its migration lock, slot reservation/release, seal, close admission and managed-close transition. MigrationSession owns candidate preparation, terminal requests and outcome publication. Existing Wire teardown owns carrier/auth aggregation.

**Authority completeness:** No newly authoritative persisted fact or schema. Existing constructors, validation and affected destructive consumers are within the scoped source surface; restart round-trip is not applicable. If implementation adds persisted authority or a new constructor family, stop and re-audit before proceeding.

**Transitional-seam budget:** None introduced. Migrate the listed callers in this PR and remove obsolete caller-owned recipes. Existing representations with distinct authority remain intentional, not temporary duplicate owners. There is no unmerged removal slice or widened seam.

**Blast radius:** migration.go, wiremux.go migration/close sections, managed_establishment.go Close facade, migration/managed/selected-lifetime tests. Keep establishment, auth release executor, transport negotiation and public migration semantics unchanged. Trace touched shared state and ordering through the named owner and preservation tests. Public APIs, wire/JSON schemas, dependencies, native routing, security/auth authority and performance guarantees remain unchanged. No benchmark or optimization claim. No intended runtime behavior change. No known untraced effect is accepted; discovering one requires scoped re-audit or an approach stop.

**Artifact classification:** Runtime changes are shipped behavior; lifecycle/validity guards are required safety enforcement. Focused tests and existing test adapters are verification aids, not separately approved maintained verification products. This plan, review receipts, issues and task mirrors are process/traceability metadata. No new analyzer, harness, CI lane or maintained-aid exception.

**Representation contract:** Supported MigrationSession and ManagedWire construction, eligible relay-assisted old Wires and direct-topology candidates; an already-direct old Wire remains ineligible. Private typed session identity and the existing Wire mutex/atomics own representation and arbitration; no external serialized state. Canonical-subset guarantee for supported close/commit/cancel histories; race tests are representative evidence, not exhaustive schedule proof.

**Contract closure:** Triggered for this accepted bounded invariant: Wire owns its migration lock, slot reservation/release, seal, close admission and managed-close transition. MigrationSession owns candidate preparation, terminal requests and outcome publication. Existing Wire teardown owns carrier/auth aggregation. Material consequences include irreversible cutover, self-join or competing close authority. Independently reachable semantic states below require more than a happy-path/failure pair; the compact census covers the accepted family without crossing unrelated axes. No repeated-root conclusion is asserted; any later recurrence must pass the shared exact invariant/central-owner side-by-side comparison.

| Semantic class | Disposition | Enforcement owner | Budgeted evidence | Status |
| --- | --- | --- | --- | --- |
| Reserve against closed/busy old Wire | Closed precedes busy; one current slot | Wire reserve operation | Existing invalid/duplicate/ready-deadline cases | Covered |
| Stale session release | Only matching session clears slot | Wire release operation | TestMigrationStaleReleasePreservesCurrentSlot | Covered |
| Cancel/old close/candidate close before seal | Existing precedence; do not retire old on this migration’s behalf; preserve concurrent old-close outcome; dispose candidate | Wire seal-and-retire admission | Existing terminal-race cases and TestMigrationPresealContextPrecedesClosedWires | Covered |
| Seal and retirement | Detach under lock before Abort outside lock | Wire seal-and-retire | Old-close join and committed case | Covered |
| Context/candidate failure after seal | Late context diagnostic; candidate failure interrupted; no rollback | Wire seal; session result publication | TestMigrationPostSealPublicationBoundary | Covered |
| Managed abortive/graceful close and selected teardown | Exact old ordering/error projection; completed I/O retained | Wire managed-close / aggregate teardown | TestManagedEstablishmentClosePreservesAbortProjection, managed close escalation, selected-lifetime and completed-I/O tests | Covered |

**Evidence budget:** At most 4 new representative semantic cases plus the named existing regressions and mandatory repository gate. Count table subcases as cases. One normal and one focused race invocation on a successful final candidate; reruns only after diagnosed failure or relevant code changes. Zero required guard mutations; at most one central guard-bypass experiment if needed to show inherited coverage exercises its owner, with no syntax-variant campaign. No new operational/platform/repetition scope. One fully briefed fresh review, at most one replacement after accepted fixes; verification remains scoped to accepted findings. Terminate after this evidence passes with no unresolved stop-for-decision. This budget does not limit existing repository-required gates; it prevents optional evidence inflation.

**TDD and preservation evidence:** First characterize the private-transition consumer contract using existing TestMigrationTerminalRaces, TestMigrationPostSealPublicationBoundary, TestMigrationOldCloseJoinsPreparation, TestMigrationReadyDeadlineReleasesSlot and TestMigrationSealPreservesCompletedIO. Add at most four missing cases for stale slot release, preseal precedence and ManagedWire.Close versus Wire.Abort ordering/error projection. Retain TestManagedEstablishmentAbortEscalatesGracefulWrite and selected-lifetime close/observer tests. Do not expand into a schedule stress campaign.

**Dispatch context budget:** Target at most 30,000 input tokens: this current plan and exact slice; current governing invariants from relevant ADR sections; the scoped source functions and named test bodies; current repository review/CI overlays and shared baselines; relevant unresolved findings only. No entire prior report history, duplicate historical plans or full engine dumps. No governing diff is needed for a new slice; later amendments supply a bounded current-contract diff. One owner-level change and this finite test surface must leave room for implementation, local fixes and verification in one fresh agent context. If the required context exceeds this bound or the change no longer fits one PR, re-audit before editing.

**Slice decision audit:** Reserve/release alone can be moved independently, but the accepted value is removing external Wire synchronization choreography; that prefactor would leave the dangerous seal/close authority external and add a temporary interface. A single small transition extraction with existing race coverage fits. Combining with admission would mix distinct lifecycle protocols and increase review cost. The strongest adjacent merge case is shared files or convenient scheduling, which is insufficient: adjacent tracks can each deliver a coherent result independently. No blocker is needed for convenience. A later real dependency must be demonstrated and re-audited.

**Stop conditions:** Stop for representation/ownership change, new public authority or schema, changed protocol/timing/error policy outside this contract, inability to preserve the named outcomes, untraced shared-state effects, evidence needs beyond this budget, or a one-PR/context boundary failure. Apply the shared precise-root/representation stops to review and verification; do not expand the latest checklist. Same-child re-audit is allowed only within the accepted representation, outcome and one-PR boundary; otherwise return for decision or scoped architecture-handoff.

## Acceptance Criteria

- [x] MigrationSession and ManagedWire stop writing Wire migration slot/seal/close-admission state or acquiring its migration lock; complete invariant-bearing operations reside on Wire.
- [x] The supported transition classes preserve preseal rejection, detach-before-retirement, postseal diagnostic/failure behavior and session outcome ownership.
- [x] ManagedWire.Close preserves its existing abort-before-Close operation and abort-error suppression rather than forwarding to Wire.Abort.
- [x] Auth release overlap, selected teardown cause authority and completed I/O counts retain their current behavior.

The representation contract above scopes quantifiers such as “one,” “unchanged,” and “once” to the named supported constructors, consumers and semantic classes; finite named tests and source-owner inspection terminate acceptance. No exhaustive schedule or external-language proof is claimed.

## Validation Gates

Before any Go build/test command, perform the installed/base Go audit in AGENTS.md and stop below the approved floor. Write the named characterization/regression cases first. Run `go test -count=1 .` and a focused race invocation through `./scripts/run-go-test-require-match.sh -race -run '^(TestMigration|TestManagedEstablishment|TestSelected.*|TestWireClose|TestExplicitWireClose)' -count=1 .` with `GOMAXPROCS=1 GOTOOLCHAIN=local`. Then run `task verify` for the exact final pushed head; retain head/base and results. Existing repository gates are not replaced by these focused cases. No added native-platform matrix, repetitions, fuzzing or hosted experiment. Required CI must report success (not skipped) on that same head before squash merge.

## Operating Discipline

Follow the shared `_shared/REVIEW-LOOP.md` and `_shared/CONTRACT-CLOSURE.md` baselines supplied by `$implement-architecture-slice` (reachable as `../_shared/` from its skill directory), composed with the repository [review overlay](../REVIEW-LOOP.md), [CI policy](../CI.md), [conventions](../CONVENTIONS.md), and root [AGENTS.md](../../AGENTS.md). No repository contract-closure overlay exists; use the shared baseline directly. The baselines govern artifact/representation gates, finite evidence, semantic-family closure, review and verification-aware approach stops, exact-head local certification, same-head hosted CI, merge, journal and pointer-only tracking. Do not copy or strengthen them in this plan.

After exact-head certification and same-head CI, merge, run `$append-dev-journal`, reconcile the parent/tracker frontier and complete only this slice’s OmniFocus task. Parent and OmniFocus notes carry state and pointers, not substantive contracts or certification SHAs. Dispatch is an operator action; this handoff does not launch implementation.
