# Upgrade-Control Codec Speaks Domain Types — Implementation Plan

**Date:** 2026-07-05
**Status:** Accepted; implemented by PR #460 and PR #463
**Track:** 1 of 3 in the 2026-07-05 upgrade deepening program
**Depends on:** nothing — safe to start first
**Related:** ADR-0006 D1/D4 (this track implements them); ADR-0002 (settled — do not re-litigate the CBOR profile, bounds, or registry discipline)

**Completion note:** PR #460 completed the mechanical package move. PR #463
completed the codec retype onto domain types and deleted the bridge. The
remaining 2026-07-05 upgrade deepening tracks are outside this plan.

## Goal

Deepen the upgrade-control codec: one small interface (encode/decode
functions on `connect`'s own domain types) hiding the entire wire
representation — CBOR field tags, uint64 enums, framing, hostile-input
bounds. Today a candidate, offer, or selected candidate pair crosses the
seam through three parallel type families kept in lockstep by hand; after
this track there is exactly one type family and the translation module
(the bridge) is deleted. Leverage: every control message is reachable
through one interface. Locality: wire-mapping bugs can only live in the
codec.

## Current Shape (verified 2026-07-05)

Three parallel type families for the same concepts:

1. **Domain:** `Candidate` (`connect/gather.go:30`, string
   `CandidateKind`), `selectedPair` (`connect/selected_pair.go:5`),
   `localUpgradeOffer` (`connect/upgrade.go:38`), `UpgradeFallbackReason`
   (`connect/upgrade_types.go:32`).
2. **Wire:** `upgradecontrol.Candidate` (uint64 `Kind`), `Offer`,
   `SelectedPair`, `FallbackReason`, and five per-phase structs —
   `connect/internal/upgradecontrol/codec.go:25-119`.
3. **Mirror:** `upgradeControlOfferMessage`,
   `upgradeControlFirstPhaseMessage`,
   `upgradeControlSelectedPairPhaseMessage`,
   `upgradeControlPhaseMessage`, `upgradeControlFallbackMessage` —
   `connect/upgrade_control_bridge.go:15-56`.

The bridge (`connect/upgrade_control_bridge.go`, 389 lines) holds ~25
`map*/encode*/decode*/read*` functions that copy fields between families.
`upgradeControlPhase` (`upgrade_control_bridge.go:41-49`) duplicates the
codec's message discriminators (`codec.go:124-131`) value-for-value.

Verified: `connect/internal/upgradecontrol` has **no importer outside
`connect`** (production importers: `upgrade.go`, `probe.go`,
`candidate_plan.go`, `upgrade_control_bridge.go`). The Go package boundary
is a hypothetical seam — one consumer, no substitution — and it is what
forces the duplication.

Load-bearing behaviors in the bridge that must survive relocation:

- Framing-error classification: `ErrFrameOversize`/`ErrFrameTruncated`
  wrap into the public sentinel `ErrUpgradeControlFramingFailed`
  (`upgrade_control_bridge.go:140-145`; sentinel at
  `upgrade_types.go:95`).
- Unknown wire fallback reason decodes to
  `UpgradeFallbackProtocolMismatch`, never an error
  (`upgrade_control_bridge.go:382-388`).
- Unknown phase payload decodes to a protocol-mismatch fallback message
  (`upgrade_control_bridge.go:172-177`).
- RTT bounds: zero/over-max rejected on decode
  (`upgrade_control_bridge.go:323-328`), negative rejected on encode
  (`upgrade_control_bridge.go:229-231`).

Codec tests: `connect/internal/upgradecontrol/codec_test.go` and
`roundtrip_test.go` (~846 lines) include golden frame encodings
(byte-exact, including the 4-byte length prefix per ADR-0002) and
hostile-input decode cases. Bridge tests:
`connect/upgrade_control_bridge_test.go` (~480 lines) — deleted with the
bridge, not ported.

## Decision

Dissolve `connect/internal/upgradecontrol` into package `connect`:

- Codec and CBOR scanner move to `connect` files (suggested:
  `control_codec.go` for schema/encode/decode/framing,
  `control_cbor_scan.go` for the bounded canonical-CBOR scanner).
- Encode/decode functions take and return **domain types** directly:
  `Candidate`, `selectedPair`, offer/phase message types,
  `UpgradeFallbackReason`. The mirror family and the bridge are deleted.
- Wire enums (uint64 candidate kinds, field keys, message discriminators)
  become unexported constants co-located with the codec, still mirroring
  the PRD-0001 registry exactly. One message-kind enum serves as both
  discriminator and phase identity (deletes the `upgradeControlPhase`
  duplicate).
- The codec returns `ErrUpgradeControlFramingFailed` directly for
  truncated/oversize frames (deletes the classify shim).
- Wire format is **frozen**: golden frame bytes are byte-identical before
  and after.
- Public API of `connect` is **frozen**: no exported identifiers added,
  removed, or changed.

**Rejected alternative (do not do this):** type-alias the domain types to
the internal package's types (`type Candidate = upgradecontrol.Candidate`).
It removes the copying but leaks an internal package into the public API
surface and keeps the hypothetical package seam.

**Rejected alternative (do not do this):** keep the wire structs and only
delete the mirror family ("thinner bridge"). Two families and most mappers
survive; fails the point of the track.

**Rejected alternative (do not do this):** move the domain types into a
new leaf package both could import. Adds a package boundary with no second
consumer (ADR-0006 D4 forbids this).

Non-goals: any wire-format change; any change to bounds or the
deterministic-CBOR profile (ADR-0002); touching the fallback-reason
representation beyond what compilation requires (that is Track 2); state
machine changes (Track 3).

## Implementation Slices

### PR 1 — Mechanical package move (complete in PR #460)

Move `codec.go`, `codec_test.go`, `roundtrip_test.go` into `connect`
(renamed files, `package connect`), delete the
`connect/internal/upgradecontrol` directory, rewrite intra-`connect`
references (`upgradecontrol.X` → local). Keep the wire structs and the
bridge temporarily — this PR is import surgery only. Exported identifiers
of the old internal package become unexported or stay as-is where names
collide (`Candidate` collides with the domain type: temporarily rename the
wire struct, e.g. `wireCandidate` — it dies in PR 2).

TDD/preservation gate: zero test-behavior change; golden tests pass
unmodified except for package/identifier renames.

### PR 2 — Retype the codec onto domain types; delete the bridge (complete in PR #463)

- Re-point encode/decode signatures at domain types; move the kind-enum
  and reason-enum translation inside them.
- Delete `upgrade_control_bridge.go`, the mirror family, the wire structs,
  and `upgradeControlPhase`.
- Rewrite call sites in `upgrade*.go`, `probe.go`, `candidate_plan.go` to
  call the codec directly.
- Delete `upgrade_control_bridge_test.go`; fold its unique cases (framing
  classification, unknown-reason default, RTT bounds) into the codec
  tests.

TDD guidance: **before** retyping, pin the golden frames — assert the
exact bytes for one offer, one fallback, one selected-pair, and each empty
phase message, constructed from domain values. These pins are written
against the PR 1 state and must pass unchanged after the retype; they are
the proof the wire format didn't drift.

## Acceptance Criteria

- Complete: `connect/internal/upgradecontrol/` no longer exists;
  `connect/upgrade_control_bridge.go` no longer exists.
- Complete: `grep -rn "upgradecontrol\." --include="*.go" .` returns nothing
  (excluding `.git-worktrees/`, `.ras/`).
- Complete: `grep -rn "upgradeControlOfferMessage\|mapCandidateToWire\|mapWireCandidate\|upgradeControlPhaseMessage" --include="*.go" .`
  returns nothing.
- Complete: golden frame bytes identical to pre-change fixtures (including 4-byte
  prefix).
- Complete: no exported identifier of package `connect` added, removed, or changed
  (`go doc ./connect` diff is empty).
- Complete: hostile-input decode tests (tags, floats, indefinite length, dup keys,
  non-canonical, oversize, nesting bounds) all present and passing.

## Validation Gates

```bash
go test ./connect/...
task verify
```

## Operating Discipline

Follow `docs/REVIEW-LOOP.md` for every PR. Stop conditions: if the retype
cannot reproduce a golden frame byte-for-byte, STOP — that is an
approach-level finding against the plan, not something to patch with a
fixture update. Vocabulary: this is the **upgrade control** codec for
**candidates**, **selected candidate pairs**, and **upgrade fallback
reasons** (CONTEXT.md terms); the codec is a deep module with an internal
seam — do not reintroduce a package boundary.
