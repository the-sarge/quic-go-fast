# Architecture directions closed without implementation — 2026-09-24

**Status:** Accepted after audit
**Program:** [AH-20260924](2026-09-24-architecture-deepening-program.md)
**Scope:** Normative dispositions and reopening conditions for the grilled directions not selected for implementation. These decisions are not blocked implementation slices or a requirement to build more evidence infrastructure.

## Selected setup handoff — defer

### Could one handoff operation replace the three setup recipes?

Keep the existing entry-specific setup. Dial, managed and ordered paths start observation around different preparation/pairing windows and project errors differently. selectedLifetime already owns copied diagnostics and actual packet failure; it explicitly does not inspect interfaces or close sockets. Moving cleanup there would add another owner or callback protocol.

### What would change this decision?

Reopen only if a concrete repeated disposal/transfer obligation can move without changing those windows or creating a second owner. Copying address helpers alone is maintenance, not a reason to redesign setup.

## TURN precommit cleanup — defer

**Source:** [connect/turn_retry_engine.go:280](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/turn_retry_engine.go#L280) · [connect/turn_retry_engine.go:395](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/turn_retry_engine.go#L395) · [connect/turn_retry_engine.go:995](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/turn_retry_engine.go#L995) · [connect/upgrade_terminal_executor.go:641](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/upgrade_terminal_executor.go#L641)

### Can preparation and probe cleanup share one complete operation?

The physical close-before-operation-join invariant already has an executor. Preparation and probe work join different operations, suppress different errors, retain different results, and run cleanup at different terminal-exchange points. A tiny helper would move only a few calls; a full owner would expose active-work adapters and timing policy.

### What would change this decision?

Reopen for another retry work stage with the same lifecycle or a concrete repeated settlement defect. This is a payoff decision; the existing prohibition on broad convergence merging does not itself forbid narrow precommit cleanup.

## Native constructors and source selection — defer

**Source:** [internal/routeselection/packet_linux.go:95](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/routeselection/packet_linux.go#L95) · [internal/routeselection/packet_darwin.go:94](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/routeselection/packet_darwin.go#L94) · [internal/routeselection/packet_windows.go:119](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/routeselection/packet_windows.go#L119)

### Is the shared family/source sorting rule enough to justify extraction?

Not on its own. All three stop on the first eligible source’s bind result, including failure: they do not try the next address. Windows also filters requested network and available family indices. Any future selector must preserve stable routable preference and IPv4 preference where permitted. Darwin temporary scope clearing, Windows coordinates, and Linux namespace handling remain native.

### What would change this decision?

The earlier ordered-candidate-list sketch is withdrawn: it omitted Windows’ constraint and suggested retries that do not exist. A first-source helper might fit future substantive native work; small duplication does not justify native certification and a new semantic type today.

## Measurement phase sharing — defer; generic runner — reject

**Source:** [internal/measurement/engine.go:554](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/engine.go#L554) · [internal/measurement/stream_worker.go:333](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/stream_worker.go#L333) · [internal/measurement/comparison_worker.go:228](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/comparison_worker.go#L228) · [internal/measurement/datagram_group.go:117](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/datagram_group.go#L117)

### After custody, can a common worker workflow own the remaining stages?

The differences are the behavior: v1 Datagram has a shutdown hold; v2 stream uses half-close and terminal EOF; v3 comparison requires bilateral drain/shutdown; v4 Datagram has its drain interval and reliable control join; four-flow execution has shared sampling and barriers. A common owner would need callbacks and mode rules that reproduce the existing implementations in its interface.

### What would change this decision?

Keep explicit phase orchestration, profiling and sample windows. Reopen only after custody lands and a complete, genuinely identical policy remains in multiple callers. Shared reply formatting alone does not warrant an architecture project.

## Measured-layer establishment — defer

**Source:** [internal/measurement/transport.go:228](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/transport.go#L228) · [internal/measurement/transport.go:317](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/transport.go#L317) · [internal/measurement/comparison_transport.go:194](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/comparison_transport.go#L194) · [internal/measurement/comparison_transport.go:250](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/comparison_transport.go#L250)

### Should native QUIC, adapter and Wire setup become one factory?

Keep useful existing shared preparation and the separate measured layers. Datagram native priming lacks the stream path’s zero-value check/write deadline, cleanup error aggregation differs, and required versus observed Datagram capability differs. Both adapter paths correctly surrender the socket for any non-nil stream, including stream-plus-error. Do not erase these differences incidentally.

### What would change this decision?

Reopen only with an explicit behavior decision about each difference and a smaller interface than the current procedures. Correct the inaccurate comment saying direct Wire retains channel AES-GCM as small documentation maintenance; it is not evidence for a factory. Direct() terminology is latent maintenance here: these measurement constructors do not configure TURN.

## Synchronous send recipe — maintenance only

**Source:** [transport/internal/adapter/packet_conn_oob.go:139](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/transport/internal/adapter/packet_conn_oob.go#L139) · [transport/internal/adapter/packet_conn_oob.go:321](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/transport/internal/adapter/packet_conn_oob.go#L321)

### Can sending normalize and check a selected packet once?

No. Preserve normalize/admit scope and binding failure → selected remote comparison → metadata preparation and binding recheck. Moving metadata first can permanently fail the PacketBinding for a foreign-remote packet that should only be rejected. Queueing and STUN retries require later observation of state.

### What would change this decision?

A private helper for the two immediate message-send adapters may be useful when those methods are next touched, preserving OOB counts and batch progress. No independent project, durable admission token, single-check optimization, or expansion to all WriteTo paths.

## Typed ordered preparation / transaction collapse — defer

**Source:** [internal/relaycandidate/preparation.go:11](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/relaycandidate/preparation.go#L11) · [ordered.go:62](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/ordered.go#L62) · [relay/ordered.go:160](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/relay/ordered.go#L160)

### Can the preparation callback become an ordinary private function argument across packages?

The callback is already typed and its disposal contract explicit; context carries it across the package seam. Root cannot call an unexported relay entry. A new public option expands the interface; moving the transaction drags relay-private trust/TLS/protocol decisions; an init bridge adds hidden wiring. None is an established improvement.

### What would change this decision?

Retain the private typed context transport until an intentional package/interface redesign supplies a simpler path. Do not make this a prerequisite for the ordered classifier or delete relaycandidate/packetfamily because they are small.

## Whole-attempt frame / preflight merge — reject for this scope

**Source:** [docs/adr/2026-07-29-establishment-settlement-plan.md:32](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/docs/adr/2026-07-29-establishment-settlement-plan.md#L32) · [migration.go:365](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/migration.go#L365) · [establishment_settlement.go:215](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/establishment_settlement.go#L215) · [docs/adr/adr-0010-auth-context-lifecycle-ownership.md:334](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/docs/adr/adr-0010-auth-context-lifecycle-ownership.md#L334)

### Why stop admission at post-upgrade result handling?

The earlier settlement plan deliberately keeps linear key/channel/negotiator construction outside the owner and retains its frame-level panic defer. Fresh migration-input preflight closes raw and joins immediate auth-release errors; failed establishment starts release before cleanup and reports it through its observer. These are different contracts.

### What would change this decision?

No whole-attempt facade, uniform release pipeline, or merged error projection. Revisit only if new concrete behavior establishes a shared policy and an ADR revision is warranted.

## Generic lifetime registry / retiring ManagedWire — reject

**Source:** [wiremux.go:632](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/wiremux.go#L632) · [managed_establishment.go:117](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/managed_establishment.go#L117) · [docs/MANAGED-MIGRATION.md:38](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/docs/MANAGED-MIGRATION.md#L38)

### Would one list of owned resources make shutdown simpler?

Wire already owns aggregate teardown, with deliberate release overlap and migration detach-before-join. A generic list hides the dependencies that make shutdown safe. ManagedWire expresses a real shipped close policy; its forwarding methods alone do not make it redundant.

### What would change this decision?

Keep the concrete owner and public facade. No added attachment registry or serialized auth release behind blocked carrier I/O.

## Packet-context envelope — reject at present

**Source:** [transport/internal/adapter/packet_permission.go:16](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/transport/internal/adapter/packet_permission.go#L16) · [upgrade_plan.go:470](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/upgrade_plan.go#L470)

### Do several context keys imply one missing domain owner?

No. Packet ownership, exact-socket permission and immutable routing binding carry different authorities. Supported selected admission checks the native socket before the managed-lease branch; no supported silent-binding-loss case was established. A tuple would couple consumers and potentially expose authority they should not receive.

### What would change this decision?

Reopen only for a supported combined path requiring a genuinely shared invariant, not the number of keys or repeated plumbing.

## Broad strict policy / convergence / terminal unification — reject current expansion

**Source:** [connect/upgrade_strict.go:65](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/connect/upgrade_strict.go#L65) · [docs/adr/2026-08-26-architecture-deepening-program.md:1](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/docs/adr/2026-08-26-architecture-deepening-program.md#L1)

### Why share decode facts but not all upgrade-failure behavior?

Decoding owns payload validity. Attempt resources and phase owners own source identity, first observed cause, cancellation and finality. Direct/TURN commit, stale-frame and terminal authorities differ. Descriptor-based v1/TURN codec unification is also separately deferred by the governing program.

### What would change this decision?

Honor the recorded third-dialect or shared-defect reopening conditions for convergence. A purely TURN-local state model is not automatically forbidden, but no current payoff warrants it. Do not interpret the six codec sites as six independent strict-policy adapters.

## Hostile error-tree traversal — defer

**Source:** [docs/adr/2026-08-26-architecture-deepening-program.md:1](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/docs/adr/2026-08-26-architecture-deepening-program.md#L1)

### Can all defensive error walking become one module?

Traversal order, limits, sanitization, identity consumption and rendezvous disposition have different authority. The August 8 traversal decision already rejected normalizing root/connect policies; root has its own shared primitives.

### What would change this decision?

Retain the recorded third-consumer or dual-defect reopening trigger. Do not create a configurable universal walker of callbacks and flags.

## Relay configuration, framing and ledger — reject broad change

**Source:** [cmd/wiremux-server/usage.go:324](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/cmd/wiremux-server/usage.go#L324) · [cmd/wiremux-server/serve.go:199](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/cmd/wiremux-server/serve.go#L199) · [relay/options.go:700](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/relay/options.go#L700) · [relay/ledger.go:681](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/relay/ledger.go#L681)

### Is duplicate validation or a grant returning a reply function a missing owner?

Abuse validation already delegates. The remaining scalar checks are small; CLI/TLS diagnostic order and process timeout policy differ. Assist grant reply() selects a function; it does not perform peer I/O inside the ledger. The accepted grant policy maps cause to consequences, allowance and events.

### What would change this decision?

Keep the I/O-free ledger and its resolution authority. No public validate-built-relay interface or reply boolean that forces callers to reinterpret consequences. Small identical scalar checks can be maintenance.

## Fixtures, naming, listener and Candidate helpers — maintenance only

**Source:** [docs/CONVENTIONS.md:1](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/docs/CONVENTIONS.md#L1)

### Should consistency cleanup be a seventh architecture project?

No. No remaining source-backed obligation gives these higher leverage than the accepted seams. Keep existing leaf test adapters and focused helpers unless a specific change makes one redundant. Reusing an Abort name does not establish identical capabilities.

### What would change this decision?

No mandatory test-constructor removal, public wiremuxtest expansion, import-cycle workaround, small-package deletion or promised line-count reduction. Correct demonstrably false comments in a future small docs change or touched scope.

## Documentation correction

The comparison transport comment claiming that an upgraded direct Wire retains channel AES-GCM is inaccurate. Record the correction here; no measured-layer setup framework follows from it. The runtime comment edit is deferred as touched-code hygiene rather than expanding this docs-only PR.

## Settled source claims

Supported selected-binding admission already rejects incompatible native socket forms before managed lease handling. Strict attempts run once; some semantic payloads are decoded more than once. In-process measurement tests already exist. Darwin classifies bind EPERM and has scope cleanup; Windows family coordinates and Linux namespace identity remain native facts. Report/agent rankings are historical evaluation, not normative architecture work.
