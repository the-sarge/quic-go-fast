# Direct-Control Event Projection Deletion Implementation Plan

**Date:** 2026-08-25
**Status:** Accepted; implemented by PR #1338
**Track:** 2 of 2 in the 2026-08-25 architecture deepening program
**Depends on:** nothing — safe to start independently
**Related:** ADR-0006; [`2026-07-05-upgrade-transition-authority-plan.md`](2026-07-05-upgrade-transition-authority-plan.md); [`2026-08-12-session-consumption-selected-pair-program.md`](2026-08-12-session-consumption-selected-pair-program.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** none

## Goal

Delete two shallow result projections around the existing direct-upgrade control classifier so listener commit handling and terminal fallback consume `directUpgradeControlEvent` directly, increasing locality without changing classification, phase policy, transition tables, control exchange, or terminal settlement.

## Current Shape (verified 2026-08-25 at `31d2be75de614950e6b104a447886a4dbd5a3667`)

- `directUpgradeControlClassifyState`, the six-kind `directUpgradeControlEvent`, and the state-aware shared classifier are the existing semantic authority at `connect/upgrade_protocol_classify.go:19-54,93-219`.
- `listenerCommitDecision` duplicates four shared event kinds and every shared payload field at `connect/upgrade_protocol_classify.go:3-17`; `classifyListenerCommitResult` calls the shared classifier and projects its event one-for-one at `connect/upgrade_protocol_classify.go:56-91`.
- Listener engine consumers switch on the projected kind and copy its payload into existing protocol actions at `connect/upgrade_protocol_engine_listener.go:514-555,582-599,642-672,713-735`.
- `terminalFallbackPeerDecision` duplicates the terminal exchange's four actionable shared-event outcomes at `connect/upgrade_terminal_fallback.go:14-27`; both read sources classify and immediately project at `connect/upgrade_terminal_fallback.go:218-256`, then `handlePeerDecision` performs the action switch at `connect/upgrade_terminal_fallback.go:272-304` and the projection itself appears at `connect/upgrade_terminal_fallback.go:306-318`.
- `TestClassifyListenerCommitResult` at `connect/upgrade_protocol_classify_test.go:8-87` repeats the listener-commit rows already present in the exhaustive shared classifier table at `connect/upgrade_protocol_classify_test.go:111-319`.
- The production-level listener and terminal exchange behavior is exercised by `connect/upgrade_protocol_listener_test.go:483-855`, `connect/upgrade_protocol_engine_test.go:67-379`, and `connect/upgrade_terminal_fallback_test.go:13-1134`. The terminal-executor structural census names `handlePeerDecision` at `connect/upgrade_terminal_executor_census_test.go:80-127` and must be updated with any deliberate rename.
- The historical transition-authority plan required one frame/error-to-event classifier at `docs/adr/2026-07-05-upgrade-transition-authority-plan.md:128-133`; ADR-0006 keeps state-dependent frame classification beside the transition authority while leaving the terminal fallback exchange as a separate lifecycle owner. No open issue, PR, or implementation branch owns this residual deletion. The 2026-08-12 program explicitly recorded control-classify collapse as not packaged.

## Decision

- Delete `listenerCommitDecisionKind`, its constants, and `listenerCommitDecision`. Retain a small, field-only `commitAwaitResult` input adapter only if it improves call-site readability, but make it return the classifier's shared `directUpgradeControlEvent` without interpreting the event kind. Keep the listener shared-event guard described below as a separate consumer guard.
- Update listener consumers to use the shared event kinds and fields directly. Retain a projection-free shared-event guard that admits the listener's four valid event kinds and normalizes every unsupported shared event to `directUpgradeControlEventControlError` with cause `errUnexpectedDirectUpgradeControlState`; this preserves the existing control-error action at each listener call site without recreating a result type. Preserve accept-join ordering, peer-fallback construction, error cause, transport-failure behavior, cancellation precedence, and terminal event dispatch.
- Delete `terminalFallbackPeerDecisionKind`, its constants, `terminalFallbackPeerDecision`, and `terminalFallbackPeerDecisionFromControlEvent`.
- Rename `terminalFallbackExchange.handlePeerDecision` to `handlePeerControlEvent` and make it accept `directUpgradeControlEvent`. Switch directly on relay fallback, ignore-and-wait, fail-closed committed, and control error. For commit observed, transport failure, zero, and unknown events, first honor `ctx.Err()` when present and otherwise fail closed with `errUnexpectedDirectUpgradeControlState`; preserve the live projection-to-error branch semantics rather than copying the current unreachable handler default arm that lacks context precedence.
- Preserve each consumer's exact admitted event set and fail-closed mapping. Listener commit handling admits commit observed, relay fallback, control error, and transport failure; ignore-and-wait, fail-closed committed, zero, and unknown kinds must become a control-error event whose cause is `errUnexpectedDirectUpgradeControlState`, then take the listener's existing control-error action path at each call site. They must not route through `dispatchUnexpectedListenerState`, which owns the distinct `errUnexpectedListenerHandoffState`. Terminal fallback admits relay fallback, ignore-and-wait, fail-closed committed, and control error; commit observed, transport failure, zero, and unknown kinds must become `errUnexpectedDirectUpgradeControlState`, while `ctx.Err()` retains precedence when the context is already done.
- Keep `classifyDirectUpgradeControlEvent`, its five classify states, phase-specific classifiers, and six shared event kinds unchanged. Keep terminal fallback as a separate lifecycle module; this slice deletes data projection, not ownership separation.
- Delete the duplicate `TestClassifyListenerCommitResult` table after the retained shared-classifier table demonstrably covers the same listener-commit semantic cases. Keep or add only a narrow input-adapter characterization if conversion from `commitAwaitResult` would otherwise be unobserved.
- Update the terminal-executor census for the deliberate handler rename and retain its enforcement of one terminal fallback exchange/handler owner.

**Rejected alternative (do not do this):** Fold the terminal fallback exchange into the classifier or transition table. Classification says what a frame means; the exchange still owns writes, timers, reads, cleanup disposition, settlement, and context precedence.

**Rejected alternative (do not do this):** Delete or combine the five classify states or six shared event kinds. Their phase-dependent distinctions are the accepted ADR-0006 protocol vocabulary and are not projection debt.

**Rejected alternative (do not do this):** Replace the shared event with raw frame inspection at listener or terminal call sites. That would recreate multiple classification authorities.

**Non-goals:** no transition-table row, control-frame byte, decoder, timeout, context precedence, fallback reason, error identity/tree, Session cleanup, packet ownership, Datagram behavior, public API, or downstream change; no classifier redesign; no terminal-exchange consolidation; no opportunistic listener-engine cleanup.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | implemented by PR #1338 | Listener and terminal fallback consume the shared control event directly and both projection families disappear | None | Removes both permanent shallow projections in the same slice |

## Implementation Slices

### Slice 1 — Delete direct-control result projections

**What it delivers:** A behavior-identical direct-upgrade control path with one classified event representation between the shared classifier and its two consumers, while listener actions and terminal settlement remain owned by their existing modules.

**Existing-work disposition:** New residual slice. Retain the completed ADR-0006 transition engine and terminal fallback exchange. This packages the control-classify collapse item that the 2026-08-12 program explicitly left unowned; no open PR, issue, or competing branch was found.

**Blocked by:** None.

**Single owner after merge:** `classifyDirectUpgradeControlEvent` owns state-aware frame/error meaning. Listener engine actions own listener event dispatch and accept joining. `terminalFallbackExchange` owns exchange orchestration and the complete terminal settlement lifecycle; `handlePeerControlEvent` is its direct event-to-action handler and preserves the existing branch-specific settlement calls. `attemptResources` remains the resource/result transition owner used by that lifecycle. No projection type owns a second vocabulary.

**Authority completeness:** No persisted or newly authoritative fact is introduced. Both classifier input paths, every listener projection consumer, both terminal read sources, the terminal action handler, and the structural census must migrate in the same slice; the deleted identifiers must have zero references.

**Transitional-seam budget:** None. Both projection families and all consumers are changed atomically. The optional commit-result input adapter may only convert fields and call the classifier. A separate projection-free listener consumer guard returns `directUpgradeControlEvent`, admits the four valid listener kinds, and normalizes unsupported values to the shared control-error event; neither helper may introduce another result type, rename valid event meanings, or become a second frame classifier.

**Blast radius:** Limited to direct-upgrade control classification consumers and tests inside `connect`, but the preserved path is concurrency- and lifecycle-sensitive. Classification outputs, accept/read/write ordering, timeout and caller-context precedence, fallback settlement, cleanup disposition, committed transport handling, errors, wire frames, and Datagram behavior are frozen. No public interface, schema, dependency, performance, security, platform, or downstream effect is accepted. Untraced effects: none after the required reference census and terminal-executor census update.

**Artifact classification:** Projection deletion and direct event consumption are shipped behavior with intentionally unchanged observation. The shared classifier table, listener/terminal behavior tests, structural census, and identifier census are verification aids; none becomes an independently maintained product deliverable. This plan, issues, review receipts, and task mirrors are process/traceability metadata.

**Representation contract:** Supported input domain = the five declared `directUpgradeControlClassifyState` values plus unknown/default, frames/errors admitted by the existing control decoder, and the six declared `directUpgradeControlEventKind` values plus unknown/default at the consumer seam. Representation owner = the existing classifier and control decoder; guarantee = universal over the finite state/event enums and canonical-subset preservation over decoder-admitted control frames. Terminating evidence = the retained classifier table, focused listener/terminal tests, terminal-executor census, deleted-identifier census, and the repository gate.

**Contract closure:** Not triggered. A protocol or lifecycle regression would be material, but this slice does not change the classifier, transition authority, or terminal owner, and ordinary focused tests already cover the behaviorally distinct shared events and phase states. Projection count alone does not satisfy the shared multiple-state closure trigger for additional evidence.

**Evidence budget:** Retain one shared-classifier case for each behaviorally distinct listener-commit and terminal-fallback outcome, including unknown classify state; one production-level listener and terminal exchange case for commit, wire fallback, synthesized protocol-mismatch fallback, control error/timeout, ignore-and-wait, and fail-closed committed behavior where the event belongs to that consumer; a mandatory listener shared-event admission/rejection matrix covering its four admitted events, ignore-and-wait, fail-closed committed, zero, and unknown; focused `handleListenerAcceptFirstCommit` evidence that TransportFailure with nil cause retains the noncommit/`ErrUpgradeTransportNotConverged` action and TransportFailure with non-nil timeout cause preserves that cause; a mandatory terminal-handler admission/rejection matrix covering its four admitted events, commit observed, transport failure, zero, and unknown while preserving `ctx.Err()` precedence; one reference census for both deleted projection families; one update to the existing terminal-executor census. No mutation harness, new race scenario, stress repetition, platform matrix, wire fixture family, or transition-table expansion. Review budget = one initial review plus at most one fully briefed replacement review. Terminate when focused tests, both consumer matrices, TransportFailure consumer cases, the structural/reference censuses, and `task verify` pass.

**TDD and preservation evidence:** Before deletion, record that the eight rows in `TestClassifyListenerCommitResult` at `connect/upgrade_protocol_classify_test.go:8-87` exactly match the shared classifier's listener-commit rows at `connect/upgrade_protocol_classify_test.go:123-179`, then write the two mandatory consumer admission/rejection matrices and the listener TransportFailure nil/non-nil cause cases so they fail if unsupported or failure events take a different action. Keep `TestListenerEngineHandoffTimeoutNonWireFallbackUsesSequencer`, `TestListenerEngineHandoffTimeoutCompletedControlAcrossAcceptShapes`, `TestListenerEngineAcceptFirstControlErrorUsesL25`, the managed listener engine tests, and terminal fallback commit/timeout/read-source tests green while removing the projections. Delete the duplicate table only after the coverage mapping and consumer guards are explicit.

**Dispatch context budget:** This exact slice contract; ADR-0006 and the current transition-authority plan; `connect/upgrade_protocol_classify.go`, `connect/upgrade_protocol_engine_listener.go`, `connect/upgrade_terminal_fallback.go`, `connect/upgrade_protocol_classify_test.go`, the focused listener/terminal tests named above, and `connect/upgrade_terminal_executor_census_test.go`; the bounded current diff only. The source and test surface is compact enough for implementation, one review/fix cycle, and verification in one fresh agent context.

**Slice decision audit:** Splitting listener and terminal projection deletion would leave the shared classifier followed by one residual shadow vocabulary and would require two rounds of the same census; the combined deletion remains small and coherent. Merging the Candidate-kind track would mix unrelated protocol-transition and Candidate-domain invariants. There are no genuine blocking edges.

**Stop conditions:** Stop if direct event consumption requires changing a classifier output, classify state, transition row, terminal action, cleanup/settlement owner, context or timeout precedence, control frame, error identity, or public API; if a projection contains behavior not represented by the shared event and existing consumer; or if deletion requires folding terminal exchange lifecycle into classification.

## Acceptance Criteria

- [x] `listenerCommitDecisionKind`, `listenerCommitDecision`, `terminalFallbackPeerDecisionKind`, `terminalFallbackPeerDecision`, and `terminalFallbackPeerDecisionFromControlEvent` are absent, with zero references.
- [x] Listener commit handling receives `directUpgradeControlEvent` from the existing classifier through at most a field-only `commitAwaitResult` adapter and the separate shared-event guard that enforces the listener subset without introducing another result type.
- [x] Terminal fallback handles `directUpgradeControlEvent` directly, preserves the default fail-closed path for unsupported events, and remains the sole exchange/settlement owner.
- [x] Listener and terminal fallback each admit only their exact four-event subset; their mandatory matrices prove every other declared event plus zero/unknown fails with `errUnexpectedDirectUpgradeControlState`, listener rejection uses each call site's existing control-error action rather than `dispatchUnexpectedListenerState`, and terminal context errors retain precedence.
- [x] Listener TransportFailure with nil cause retains the post-commit noncommit/`ErrUpgradeTransportNotConverged` action, while TransportFailure with a non-nil timeout cause preserves that cause.
- [x] The five classifier states, six shared event kinds, phase-dependent classifications, and shared classifier table remain semantically unchanged.
- [x] The duplicate listener-decision table is removed only after its cases map to retained shared-classifier or real-consumer evidence.
- [x] Existing control bytes, transition behavior, listener accept ordering, timeout/context precedence, fallback outcomes, error identities, cleanup, packet ownership, Datagram behavior, and public interface remain unchanged.

Universal-criterion representation note: “every,” “zero,” and “sole” above range over the finite reference census of the named projection identifiers, the five declared classifier states plus the default class, and the six declared event kinds plus the default class. Control-frame guarantees remain limited to the decoder-enforced canonical subset. The representation owner and finite terminating evidence are stated above.

## Validation Gates

Run `TestClassifyDirectUpgradeControlEvent`; the new listener and terminal shared-event admission/rejection matrices; the focused listener TransportFailure nil/non-nil cause cases; the focused managed listener engine, listener fallback/control, and terminal fallback tests named in the evidence section; `TestAttemptResourcesTerminalConsumerCensus` and related terminal-executor census tests; `go test ./connect`; the existing focused root/connect auth-lifecycle and direct-upgrade race lanes selected by `task verify`; `./scripts/check-gofmt.sh`; `task docs-check`; and `task verify`. Follow the repository Go toolchain supply-chain audit before any Go command.

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) and the certification lanes in [`docs/CI.md`](../CI.md). Treat any classifier, transition, lifecycle, wire, error, or ownership change as an approach stop rather than deletion latitude.
