# Datagram-Admission Prototype Result

**Date:** 2026-08-08
**Plan:** [`2026-08-08-datagram-admission-prototype-plan.md`](2026-08-08-datagram-admission-prototype-plan.md), Slice 1
**Prototype implementation head:** `88a635c472cfe4b6fc2412c68394d0b61d191eda`
**Verdict:** Reject the extraction. The tested surface could centralize the queue protocol, but it did not preserve both caller-owned terminal-ordering recipes without a wider authority or synchronization seam.

## Result

One shared admission object served both the root `Datagrams` queue and the QUIC adapter queue without callbacks, caller modes, error translators, framing or size policy, Wire or QUIC knowledge, carrier termination policy, queue collapse, or a second queue owner. The prototype instantiated the object once per caller, so ADR-0009's two independently bounded cancellable queues remained distinct. This apparent interface narrowness was insufficient: moving each caller's commit fence into the object left its caller-owned terminal transition outside the same atomic boundary.

The tested candidate surface was:

```go
var ErrClosed error

type Queue struct { /* one owner context, capacity, provisional entries */ }

func New(owner context.Context, capacity int) *Queue
func (*Queue) Admit(call context.Context, payload []byte) error
func (*Queue) Dequeue() (payload []byte, ok bool)
func (*Queue) Close()
```

`Admit` owned finite-capacity reservation, the payload copy, provisional enqueue, call/owner cancellation arbitration, and commit/discard resolution. `Dequeue` blocked for a committed entry, released its slot, and returned `ok == false` when the queue closed or its owner context ended; each caller derived the terminal-policy distinction from its retained state. `Close` rejected new work and caused queued or unresolved work to be discarded. A single unexported prototype-only observation hook exercised cancellation after provisional enqueue; it was not part of the candidate surface and was removed with the experiment.

## Rejection Reason

The root prototype called `Queue.Admit` outside `gateMu`. Its `closeGate` path acquired `gateMu`, published `d.closed`, canceled the root Datagram context, and then called `Queue.Close`. A blocked admission was released correctly, but an admission already resolving under the queue mutex could commit after the caller-owned closed transition had been published and before `Queue.Close` acquired that mutex. Production instead uses `gateMu` to order the root closed transition with provisional resolution. The prototype retained `gateMu` for gate/receive policy but no longer used it as the send-admission commit fence.

The QUIC prototype removed `admissionMu` and its `closeAdmission` path called `endLifetime(cause)` before `Queue.Close`, followed by the existing caller-owned `terminateCarrier`. The queue observed that lifetime and checked it before commit, but cause publication was not serialized by the queue mutex with the final commit. Reversing the calls would make a concurrently rejected `Admit` able to observe queue closure before the caller published the terminal cause. Closing this family requires the queue to own more cause/terminal authority, or requires a wider caller synchronization protocol; neither was part of the tested narrow surface.

Root explicit close and QUIC terminal cause are behaviorally distinct cases at the same invariant and owner: once terminal closure linearizes, no shared admission may commit afterward, while an earlier commit may finish before closure, and `Queue.Admit`/`Queue.Close` must own that boundary for both callers. Because the prototype failed this family at the proposed central seam, passing example tests cannot support an accept verdict. The plan's uncertainty rule therefore requires rejection rather than a second prototype.

## Caller Mapping

| Concern | Root `Datagrams` | QUIC adapter | Shared candidate |
| --- | --- | --- | --- |
| Queue instance and capacity | Retained its own capacity of 8 | Retained its own capacity of 8 | Owned capacity accounting per instance |
| Payload preparation | Retained discriminator framing and public size validation | Retained lower payload size validation | Copied the prepared payload on admission |
| Admission errors | Retained `ErrWireClosed`, cause preservation, and call-context precedence | Retained transport-error normalization | Returned only call, owner, or closed admission outcomes |
| Post-admission policy | Retained permitted-loss and lower ceiling-breach handling | Retained native-send failure termination | Returned committed payloads to the caller's worker |
| Lifetime and close | Retained the separately closable public gate, `gateMu`, and aggregate Wire teardown, but the tested ordering published `d.closed` before `Queue.Close` | Retained carrier lifetime and termination callback, but the tested ordering published the lifetime cause before `Queue.Close` and then terminated the carrier | Arbitrated the supplied owner context and discarded on `Close`, but did not atomically own either caller's complete terminal transition |

## Deletion Accounting

The throwaway production diff removed 194 lines and added 203 lines, including the 170-line shared prototype object, for a raw net addition of 9 lines. The census demonstrates mechanical centralization potential, not a net-deletion or performance claim, and it does not override the terminal-ordering rejection.

| Production location | Prototype line delta | Removed caller-owned machinery | Replacement |
| --- | ---: | --- | --- |
| `datagrams.go` | +14 / -112 | `datagramSendAdmission`; `sendQueue`; `sendSlots`; resolution-channel creation and worker handling; `testBeforeSendCommit` | One `*datagramadmission.Queue` field and `Admit`/`Dequeue`/`Close` calls |
| `transport/quic/transport.go` | +19 / -82 | `quicDatagramAdmission`; `sendQueue`; `sendSlots`; `admissionMu`; resolution-channel creation and worker handling; `testBeforeAdmissionCommit` | One `*datagramadmission.Queue` field and `Admit`/`Dequeue`/`Close` calls |
| `internal/datagramadmission/queue.go` | +170 / -0 | n/a | The sole candidate mechanism, including the temporary unexported observation point |

The static caller census changed `sendQueue` from 4 references per caller to 0, `sendSlots` from 8 root and 7 QUIC references to 0, each provisional admission type from its caller's 4–5 references to 0, each caller-specific commit hook from 3 references to 0, and QUIC `admissionMu` from 9 references to 0. Neither caller retained resolution-channel handling. Root `gateMu` remained for gate/receive policy but left the send-admission path, which exposed the root ordering failure above.

## Finite Evidence

| Example-level case | Root evidence | QUIC evidence |
| --- | --- | --- |
| Available capacity, copied payload, commit, dequeue, worker observation | `TestDatagramsSendFramesCopiesAndKeepsLocalErrorsNonTerminal` | `TestDatagramAdapterCopiesPayloadOnAdmission` |
| Blocked capacity and canceled waiter | `TestDatagramsBlockedAdmissionIsCancellableAndCloseDiscardsQueuedSend` | `TestDatagramAdapterSendAdmissionUnblocksOnCallAndLifetimeCancellation`; `TestDatagramAdapterCanceledWaiterCannotCrossReleasedAdmissionSlot` |
| Call cancellation before commit | `TestDatagramCallCancellationDuringAdmission` | `TestDatagramAdapterCallCancellationDuringAdmission` |
| Owner lifetime ending before commit | `TestDatagramLifetimeCancellationDuringAdmission` | `TestDatagramAdapterLifetimeRaceHasCoherentAdmissionOutcome`; the temporarily adapted `TestDatagramAdapterParentLifetimeCancellationDuringAdmission` repeated that coherent-outcome race shape, while the shared-object observation supplied the post-provisional discard case |
| Close or lifetime discard | `TestDatagramsBlockedAdmissionIsCancellableAndCloseDiscardsQueuedSend` | `TestDatagramAdapterDiscardsQueuedPayloadsAfterLifetimeTermination` |

The required Go audit reported `go1.26.5 darwin/arm64` for both the installed and selected toolchains. All named focused tests passed under `-race` in their temporary adapted forms. The broader existing root Datagram race lane (`-run 'Datagram'`) and QUIC Datagram race lane (`-run '^Test.*Datagram'`) also passed against that throwaway tree.

Deleting the caller hooks required temporary test adaptation rather than silently dropping their observations. The root lifetime and call-cancellation sentinels and the QUIC call-cancellation sentinel used temporary contexts gated at the candidate's final pre-commit check. The temporarily adapted QUIC parent-lifetime sentinel used a 100-iteration coherent-outcome race and therefore did not retain its production form's deterministic cause and zero-native-send assertions; the separate shared-object test used the single unexported observation hook to verify that owner cancellation after provisional enqueue discarded the entry, and also covered call cancellation at that point. All adaptations were removed with the prototype. These finite observations covered the plan's named examples, but they did not establish the missing terminal-transition atomicity described above.

## Boundaries and Next Step

This is example-level design evidence over the two implementations at the recorded head. It is not exhaustive concurrency proof, a benchmark, a platform claim, a public API decision, or evidence that an extracted implementation has been reviewed for production. All prototype Go and test changes were removed before this document was committed.

The rejected verdict closes this candidate until materially new evidence exists. It does not authorize a production-extraction `$architecture-handoff`; production ownership and behavior remain unchanged.
