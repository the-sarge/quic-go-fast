# Third Architecture Deepening Program — 2026-07-05

**Status:** Complete as of 2026-07-08 (`5913a1e`); all four tracks implemented, with the later ADR-0006 D3 conformance boundary recorded below

## What this is

Historical index for the completed third wiremux architecture deepening program, produced by the second 2026-07-05 architecture review (run after the ADR-0006 program landed) and a delegated design walkthrough (grilling) of its six candidates. Four tracks were accepted; one candidate closed with no code and one was later triggered and implemented (below). Each track's plan doc carries the full grilled design — verified facts, rejected alternatives, PR slicing, and frozen contracts — so no implementing agent re-derives decisions from the conversation that produced them.

The second program (ADR-0006; index at
[2026-07-05-upgrade-deepening-program.md](2026-07-05-upgrade-deepening-program.md))
is complete as of main commit `e12dd1f`.

## Outcomes that require no implementation

- **Terminal-fallback fold into the transition authority — rejected and reaffirmed by #829.** `terminalFallbackExchange` remains the blocking send-and-await mini-protocol with commit racing and typed Session cleanup. The unified engine selects its narrow entry points, but folding the exchange or `controlFrameSequencer` into transition rows would repeat the mega-table shape ADR-0006 rejected; both remain separate authorities unless their protocols materially change.
- The transport accept-once listener state machine is already tracked as
  #418; `attemptResources` post-commit close routing as #473. Neither is
  re-proposed here.
- CONTEXT.md gains one domain term — **Session consumption** — committed
  with this program's docs.
- Grilling correction recorded: the review's original top candidate (the
  consume lifecycle) cited open bugs #441/#443 as evidence; both are fixed
  by PR #492, which was in flight during grilling. The structural case
  survives — #492 fixes by adding a fourth scattered consume call site —
  but the track is re-ranked to last (Track 4).

## Later-triggered outcomes

- **Probe run deepening (review candidate E, reshaped) — triggered and landed through #831.** The restricted-NAT coverage program satisfied the recorded trigger: one attempt-bound opaque datagram/time runtime now owns probe I/O, logical deadlines, cancellation release, and helper joining; the probe engine retains protocol authority; and scenario tests replace the eight scheduler-specific `net.PacketConn` fakes. The runtime remains only the enabling first slice for deterministic restricted-NAT evidence; the NAT fabric and matrix rows belong to the successor slices.

## Completed tracks

| # | Track | Plan doc | Depends on | Size |
|---|-------|----------|------------|------|
| 1 | Control-frame sequencer speaks `recv` | [2026-07-05-control-frame-recv-plan.md](2026-07-05-control-frame-recv-plan.md) | nothing — safe to start first | 1 PR |
| 2 | Relay pair session | [2026-07-05-relay-pair-session-plan.md](2026-07-05-relay-pair-session-plan.md) | nothing (relay package only) | 3 PRs |
| 3 | Wire-dialer upgrade plan | [2026-07-05-dial-upgrade-plan-plan.md](2026-07-05-dial-upgrade-plan-plan.md) | PR #492 merged | 2 PRs |
| 4 | Consume coordinator | [2026-07-05-consume-coordinator-plan.md](2026-07-05-consume-coordinator-plan.md) | PR #492 merged; Track 3 first | 2 PRs |

Tracks 1 and 2 touched disjoint packages (`connect` vs `relay`) and were
parallel-safe. Tracks 3 and 4 both edited `wiremux.go`/`options.go` and ran
3 → 4 after PR #492 merged. Track 4 completed in PR #566 at main commit
`5913a1e`.

## Rules that bound every track

- **Behavior preservation is the hard gate.** Wire format frozen; exported
  APIs frozen; error identities and wrapping shapes frozen — including
  `ErrUpgradeControlTimeout` vs context-error distinctions and the
  packet-socket ownership contract. ADR-0008 supersedes the historical
  pre/post-commit shorthand here: bare errors leave the socket caller-owned
  before the applicable local boundary, while
  `ErrUpgradeTransportNotConverged` closes it after that boundary.
- Follow `docs/REVIEW-LOOP.md` for every PR; `task verify` (including the
  relay race gate) is the acceptance bar for every slice.
- Do not re-litigate settled ADRs: ADR-0002 (CBOR profile), ADR-0003
  (selected-pair binding), ADR-0004 (ledger owns pair resolution),
  ADR-0005 (shutdown supervision), ADR-0006 (upgrade type family and
  transition authority, including its rejected alternatives).
- Replace, don't layer: superseded tests are deleted with their modules —
  but only after the deleting PR's scenario-mapping checklist names a
  replacement for every covered scenario.
- Vocabulary discipline: CONTEXT.md domain terms in all code, comments,
  PRs, and issues.
- Post-merge ritual per PR: review loop clean → merge → append-dev-journal
  → complete the OmniFocus subtask and file any review follow-ups.
