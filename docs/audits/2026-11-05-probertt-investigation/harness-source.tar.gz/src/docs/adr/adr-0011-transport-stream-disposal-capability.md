# ADR-0011: Transport Stream Close Owns Post-Transfer Disposal

## Status

Accepted.

## Context

After `Session.Dial` or `TransportListener.Accept` returns a non-nil stream, the returned connection path must own the exact packet socket even if the same result also carries an error. Before this decision was activated, the QUIC adapter returned from `io.ReadWriteCloser.Close` before its grace/background packet cleanup completed, independently closing both the stream and raw socket permitted a delayed second `PacketConn.Close`, and interface prose assigned transfer only on nil-error success while reachable result matrices admitted stream-plus-error. No branch-local recipe, fact check, or error shape could close that ownership hole or make two disposal authorities exclusive.

## Decision

Keep the frozen public method set: `Session.Dial` and `TransportListener.Accept` continue returning `io.ReadWriteCloser`. Define any non-nil returned stream as the packet-ownership transfer boundary, regardless of accompanying error, and strengthen that stream's already-mandatory `Close`: Close must return only after attempting reliable-stream, parent-connection, transport-resource, and exact-packet closure, including the existing bounded transport grace; all Close, parent-completion, and Datagram teardown paths share the same internal once authorities and may not invoke the exact socket's `Close` again. A nil stream does not transfer by result; commit remains the independent post-boundary transfer fact.

Close attempts all owned cleanup even after the reliable stream reports an error, treats `net.ErrClosed` from exact-packet closure as successful idempotent closure, and retains the existing public error contract: every repeated/concurrent Close returns the reliable stream Close result only; parent, transport, and packet cleanup errors are not surfaced. Parent completion and Datagram teardown may help complete the same physical once state, but Close waits for that state before returning.

One persistent direct-attempt resource owner holds the packet-disposal claim after commit or any non-nil Dial/Accept result. If a definitive joined result contains a stream, including stream-plus-error, fail-closed disposal invokes only that stream's synchronous `Close` and never closes the raw socket. If post-commit definitive settlement proves that no stream materialized, the owner closes the exact raw socket itself. A pre-commit nil-stream result leaves the packet caller-owned. Root reads the monotonic transfer fact and cannot close after transfer. Direct success transfers the same close-owned claim into the returned Wire.

An independently merged listener-finality prerequisite makes caller-visible `TransportListener.Close` actively unblock and join the complete Accept result; QUIC `Accept` uses a separate nonjoining internal release helper so its own completion path cannot self-join. Moved #827 within the revised #825 integration boundary owns pending Dial/Listen goroutines: it cancels their contexts, invokes `Session.Close` to actively unblock implementation I/O, and directly joins the registered result before terminal conversion selects stream Close versus raw socket Close. The strengthened Session contract requires Dial/Listen to return promptly after cancellation plus concurrent Close, while Close itself remains prompt and is not the join authority. A late success after owner settlement is outside the contract. These finality contracts let the resource owner distinguish “stream owns disposal” from “no stream can ever materialize” before it acts.

The integration program first refactored the production adapter to a behavior-preserving shared completion substrate and separately staged the complete semantic executor. This coherent activation component changes Close, every non-nil producer/wrapper, every terminal caller, root settlement, and the interface/ADR/PRD contract together, after removing the legacy external raw-close authority; exact-head #825 certification is the only publication to `main`.

## Considered Options

- Close the stream and raw socket independently. Rejected because the stream adapter can later invoke `PacketConn.Close` a second time.
- Treat one owner-side call as “exactly once.” Rejected because the contract requires one invocation on the exact supplied socket, not merely one cleanup decision.
- Wrap the packet socket with a close gate. Rejected because transports and integration contracts require the exact caller-supplied `net.PacketConn` identity.
- Add `TransportStream.Abort` or another public method. Rejected because the accepted boundary freezes the public method set.
- Discover an optional private abort interface. Rejected because external transport conformance would not be enforceable.
- Move exact-packet disposal back to wiremux while allowing transport Close to retain a second socket authority. Rejected because it recreates the dual disposer under a different wrapper.

## Consequences

This is a pre-release behavioral strengthening without a public method-set change. The default QUIC transport, internal nettest transport, repository fixtures, and downstream custom transports must prove that every non-nil result's existing Close synchronously completes exact-packet disposal once, including stream-plus-error. Session implementations must also prove cancellation-plus-Close liveness for Dial/Listen; consumer audits/adaptations land in separate repository PRs before those consumers adopt merged #825. Wire protocol bytes do not change, the exact packet socket is still passed unwrapped, the existing bounded grace remains, and Close continues returning only the reliable stream-close result. Close latency now includes completion of the bounded grace/parent/transport/packet cleanup; on the default QUIC path, reliable-stream grace and concurrent Datagram termination share a 500 ms window before the remaining synchronous cleanup completes.

The default QUIC adapter's read-completion classification remains a distinct owner from disposal: native EOF remains EOF, while a normal remote parent close becomes EOF only after coherent final-offset publication and complete caller delivery. Earlier parent teardown preserves a non-EOF transport error and cannot be reclassified merely because FIN or RESET arrived.
