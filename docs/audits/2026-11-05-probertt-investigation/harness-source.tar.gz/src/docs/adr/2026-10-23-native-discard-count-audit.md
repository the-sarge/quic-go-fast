# Slice 3.4 amendment audit — 2026-10-23

**Normative contract:** [Track 3, Slice 3.4](2026-10-19-native-observability-plan.md#slice-34--public-received-datagram-full-queue-discard-count). **Issue:** [#1969](https://github.com/GridSwarm/wiremux/issues/1969). This record holds source evidence and audit history, not a second execution contract.

## Authority and source evidence

The owner approved the two-PR plan in the initiating Codex conversation on 2026-10-23: first amend/audit Track 3, then deliver one implementation PR. The [settled triage design](https://github.com/GridSwarm/wiremux/issues/1969#issuecomment-6370249114) supplies all public semantics. This amends #1828 decision 3 and H4 only for the received-DATAGRAM full-queue count. It does not reopen #1924's gate or broaden the measurement API.

Inspected wiremux `3cb67e8f61525b7d57d021b2e802e58713ed5f3e` and adopted fork fast.8 `8095c72244755f0c1e24f4158253bf09cfbe6e17`:

- `native_promotion.go`: `NativeWireInfo` is static provenance, and `Native()` copies it. Native construction already has the committed `Promotion`.
- `internal/nativequic/promote.go`: the promotion retains the candidate/connection, owns Close/Abort and joins endpoint teardown. A direct optional reader needs no added lifecycle owner.
- `internal/nativequic/readout.go`: an optional `DatagramReceiveDropsV1` assertion already exists, but its measurement registry is enabled separately and unregisters at Close entry. Public lifetime cannot depend on it.
- `internal/nativequic/capability.go`: `connV1` and `Supported` omit the method; preserve that admission contract.
- Fork `connection.go` and `datagram_queue.go`: the method reads the existing atomic full-queue count, concurrent-safe and retained after close, excluding receive-phase/protocol discards. The fork owns those semantics; wiremux does not duplicate its queue tests.

## Boundary and slice audit

The implementation changes the state owner's read interface and the public snapshot together. Splitting them leaves an unused internal interface; combining with 3.3 inherits unrelated binding/timing work. The existing connection is the only accumulator and lifecycle owner. Registry access and a cached final count would add identity, enablement or final-increment obligations without serving the contract.

D1–D7 bound optionality, value/snapshot behavior, identity, measurement independence, lifecycle, cost and compatibility. Tests and the existing manifest are verification aids. Audit/plan/mirror records are metadata, with no recursive completeness gate. Focused examples cover the typed reader; no external grammar, exhaustive schedule or new throughput claim is introduced. The two-platform fork race lane preserves the approved native validation scope; no new operational campaign is required.

## Amendment PR review contract

This PR delivers only the normative Track 3 amendment, program index reconciliation and this audit record. Acceptance: the settled #1969 behavior is represented consistently, the completed 5.1 prerequisite and independent #1924 hold are accurate, implementation remains one PR, and the acceptance evidence/stop conditions are executable without an unresolved audit blocker. Existing slice obligations remain intact. Supported representation: repository Markdown and named issue/source contracts; owner: the normative Track 3 plan. Guarantee: example-level semantic fidelity, checked by reading the scoped diff and linked sources. All changed artifacts are process metadata. There is no runtime or public declaration change.

Terminating evidence: repository docs/whitespace/secret checks, exact-head `task verify`, one briefed fresh RAS review and at most one replacement after accepted fixes, scoped verification if needed, then required successful same-head hosted CI. No mutation, performance, platform campaign or implementation tests are added by this docs PR. Review history and dispositions belong below or in linked PR discussion; current requirements stay in the normative plan.

## Review history

[PR #2004](https://github.com/GridSwarm/wiremux/pull/2004) received independent RAS audit `20261023T170835-9f80d108de0f4e2709b53674` at `59d6c1170913605b3e7a832e4d7bf06c4817d8f7`: five reviewers completed, one reviewer process failed, and the run completed with adjudication and synthesis. No architectural blocker was found. The initial attempt `20261023T170734-17002481f4772a49b8ebb7ef` started no reviewers because the configured worktree root was missing; it supplies no review evidence.

| Finding | Independent disposition |
| --- | --- |
| C-002 / CLAUDEOPUS-F-001: leftover internal-only wording | fix-now: the amendment must represent the public exception consistently. Qualify the original decision introduction, the program's discard-count reference and the general readout owner's-design boundary; preserve historical quotations and other counts' internal status. Documentation/whitespace checks pass. |
| C-001 / CLAUDEOPUS-F-002: require new release-tag ownership/gating | reject: the accepted tag-inclusion requirement is already present in the normative contract and program index. Publication is explicitly separate work; this amendment does not own a new release gate or checklist. No follow-up is required. |

The cheap documentation-only corrections use the shared baseline's polish exemption: no additional RAS review or verification cycle. Final local certification and successful same-head required CI are recorded in the PR. Implementation remains undispatched until the amendment merges. This audit does not claim runtime verification of the unbuilt feature.
