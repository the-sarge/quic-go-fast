# Receive cap RTT acceptance audit — 2026-10-25

The normative [Slice 6.4 contract](2026-10-19-macos-native-stack-plan.md#slice-64--recvmsg_x-into-the-forks-eight-read-slots-on-the-connected-socket) owns current obligations. [Decision #2030](https://github.com/GridSwarm/wiremux/issues/2030), the [owner acceptance receipt](https://github.com/GridSwarm/wiremux/issues/2030#issuecomment-6394458484) and the [finite campaign receipt](https://github.com/GridSwarm/wiremux/pull/2029#issuecomment-6394372525) retain the decision and evidence. Product work remains in #1932 / PR #2029.

## Accepted decision

After seeing the complete comparison and its practical interpretation, the owner agreed to retain cap 32 and accept the measured RTT cost, record it and continue through normal product review and validation. The ≤100 µs benchmark bound was carried from an earlier comparison expecting about 85 µs of added RTT; no application deadline was established by that derivation. This acceptance weighs measured throughput and CPU gains against submillisecond mean RTT; it makes no application-latency, tail-latency or causal claim.

| Cap 32 versus cap 8, pooled medians | Pinned Datagrams | Stream |
| --- | ---: | ---: |
| Mean RTT at cap 8 | 241.793673 µs | 227.735068 µs |
| Mean RTT at cap 32 | 426.495397 µs | 478.480366 µs |
| RTT rise, accepted for this completed cohort only | 184.701724 µs | 250.745298 µs |
| Throughput | +11.4854% | +14.9114% |
| Sender CPU per GiB | −14.2250% | −15.3804% |
| Receiver CPU per GiB | −4.8142% | −6.9039% |

The two RTT rises remain original-bound failures, accepted retrospectively. No new general bound, prospective guarantee or sample exclusion is created. All six declared A1/B1/C1/A2/B2/C2 blocks completed at REPS=3 with ten-second windows and recorded warm-ups: 144 records, 108 measured. There was no fallback exclusion, replacement or extension. All arms disabled F9 on both peers and used the declared load and Tart gates. The pair claim and owned processes were released.

B used runtime `5969efdc31e436896baf19c9e68222957a147f6c` on fast.8; C differed only by the admitted local fork copy’s `maxSendBatch = 8`, with queue depth 32 retained. A used default base `d100abb6e8c699f9438299b6a4f3849c4c1b4e8b`. Candidate `2e5a7cb58694ad873ff4bd591f6270a758f2b7b4` adds only test fixture/assertion and completion/frontier metadata changes after that runtime. Immutable raw records, binaries, scripts, environment and fork-copy diff remain under `/Volumes/worktrees/wiremux/macos-recvmsg-x-1932/.cache/1932/` and in the linked receipts; they are not blended or rerun.

Receive B/A gates pass: Datagrams +48.7582% rate, −43.3713% receiver CPU/GiB, +2.0516% sender CPU/GiB and −0.0121955 percentage points loss; stream +54.8157% rate, −42.7732% receiver CPU/GiB, −6.5777% sender CPU/GiB and zero measured PTO/spurious-loss counters. All 48 candidate native records, warm-ups included, average 3.893966–6.102171 datagrams per receive call with fallback reason zero. One cap-32 Datagram run has one fork receive-queue discard, 0.00002094214% of delivered Datagrams, below 0.01%; every other candidate Datagram record has zero. All cap reference payoff rows pass. The [platform receipt](https://github.com/GridSwarm/wiremux/pull/2029#issuecomment-6394115388) records the five platform runs and repaired synthetic poller fixture; it does not certify the eventual final head.

## Re-audit and boundary

Retain the same child, one product PR, accepted outcome and enforcement: qualified connected Darwin bindings fill F7’s eight equal-shaped ceiling-plus-one slots, independently admitting each datagram and retaining permanent single-receive fallback. XNU owns message results; F7 owns slots; the binding owns receive/qualification; `ReadUnicastBatch` owns admission/compaction. Universal admission and full-slot-drop guarantees, canonical-subset engagement, supported allowlisted pairs and the existing closure matrix are unchanged. No runtime mechanism, persisted state, public API, compatibility promise, fork release, cap setting, platform exclusion or transitional seam is introduced.

Artifact classes remain unchanged: receive is shipped behavior; per-slot admission and qualified fallback are required safety enforcement; tests, rig, counters and finite campaigns are existing verification aids; this amendment and mirrors are process metadata. No new maintained blocking aid is introduced. No new material invariant or runtime path triggers additional closure. The one admission-bypass mutation, at most 17 new cases plus allocation pin, conditional timestamp non-goal (3.3 remains deferred), five platform runs, 45,000-token dispatch target and one initial plus at most one replacement product review stay intact.

The completed evidence terminates measurement for this decision. Every other gate remains binding, including ordinary review, exact-head local certification, same-head hosted CI and squash merge. Concrete in-scope findings receive independent disposition under the existing protocol. No automatic traffic reruns or stronger evidence are authorized. The product PR owns its completion/frontier transition; its journal starts only after merge. Review and publication receipts belong in the amendment PR and #2030.

The strongest split, a new cap/fork implementation child, is rejected because the owner retains the measured existing cap and needs no runtime change. Revisit only for an owner-authorized scope change. Merging another transport lever is rejected because it changes attribution and the one-PR outcome. A further benchmark or open-ended scheduler investigation is rejected because the measured tradeoff is accepted and neither has a finite decision payoff here; revisit only for concrete product evidence or a separately authorized investigation. Scheduling cause and user-visible application/tail latency remain untraced.

Publish this scoped acceptance on the authoritative branch before synchronizing the child’s exact pointer and reconciling the retained product PR. It is neither another implementation slice nor a routine frontier PR. This documentation PR receives one initial review and at most one replacement, exact-head local certification and same-head hosted CI; that budget is separate from the unspent product review budget. It carries no product completion or journal entry.
