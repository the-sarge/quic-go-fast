# Establishment Settlement Implementation Plan

**Date:** 2026-07-29
**Status:** Accepted (grilled 2026-07-29; slice graph audited 2026-07-29); not yet implemented
**Track:** 1 of 1 in the 2026-07-29 architecture deepening program
**Depends on:** nothing — safe to start first
**Related:** CONTEXT.md **Establishment settlement** (term added with this plan); ADR-0008/0009/0010 frozen contracts honored, not amended; follow-up candidate: packet-socket ownership as a stated value (candidate 4 of the 2026-07-29 review), sequenced after this track
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** Slice audit 2026-07-29 (adversarial agent audit; verdict PASS WITH AMENDMENTS A1–A5, all folded into this plan); review chronology lives in the child PR discussion

## Goal

One deep module owns the outcome of the Wire dialer's establishment sequence. Today each of `dialPaired`'s nine terminal exits hand-assembles up to five ordered obligations — auth-context release, the correct upgrade-cleanup variant, the correct session-consumption hook, closing the right relay carrier, and one-shot rendezvous marking. After this plan, each exit declares what happened in one line and the settlement module derives what follows; the ordering invariants live in exactly one place, tested through the settlement interface instead of only through end-to-end dials.

## Current Shape (verified 2026-07-29 at `fdced06`)

- `dialPaired` (`wiremux.go:182-313`) has nine terminal `return nil, stageError(...)` exits between `:194` and `:306`. Each independently orders: `startFailedAuthRelease()` (closure at `:206-215`), one of three upgrade-cleanup variants (`upgrade.cleanup(upgradePlanCleanupSetupError)` / `cleanupAfterUpgradeError(err)` / `cleanupAfterUpgradeResult(result)` — the choice changes packet-socket ownership per ADR-0008), one of three consume hooks (`onIdentityFailure` / `onPostIdentitySuccessFailure` / `onPostAuthValidationFailure`, with differing `successSpendsRendezvous` argument conventions), `relayConn.Close()` vs `relayStream.Close()` (the current carrier switches at `:268`), and `markSpentAfterOneShotSuccess(err, ...)` wrapping.
- A hidden state machine spans the function: `authTransferredToWire`, `authReleaseStarted`, `releaseObserver` (`:202-204`), the `startFailedAuthRelease` closure, and an overlapping frame-level `defer` (`:220-225`) that also releases; correctness of the double-release window rests on once-semantics inside `authContextOwner.release` (`auth_context_lifecycle.go:44-57`), which caches `releaseErr` so both callers observe the same result.
- The frame-level `defer` at `:220-225` is also the only auth release on panic paths (a panicking `decorateChannel` decorator or connect stage); no test pins this.
- The composition is the residue of three completed deepening programs (consume coordinator, dial upgrade plan, auth-context lifecycle): each deepened one collaborator and thereby added one more participant every exit must coordinate. No module owns their composition.
- Collaborators already accept dependencies at their edges: `newConsumeCoordinator` takes a `consumeSessionFunc` (`consume_coordinator.go:36`), `newAuthContextOwner` takes a `connect.AuthContext` interface (`auth_context_lifecycle.go:24`), and the upgrade plan takes injected packet conns via options. No new test seams are required to test settlement with fake leaves.
- No test couples to `dialPaired`'s interior: zero test hits on `dialPaired`/`startFailedAuthRelease`/`authReleaseStarted`/`authTransferredToWire`/`releaseObserver`; `export_test.go:13-38` exposes only `dialConfig`-level hooks; `wiremux_test.go` is black-box through `Dial`; `wiremux_internal_test.go` tests collaborators, not the composition; `wiremux_production_budget_test.go:34` touches `cleanupAfterUpgradeError` at the collaborator level only.

## Decision

- **D1 — behavior freeze.** The refactor is observably invisible: same error trees, same cleanup order, same consumption outcomes, same ownership dispositions. Existing root tests pass unmodified and are the proof.
- **D2 — whole-outcome scope.** A new unexported settlement module in the root package settles all ten endings: the nine failures and the success handoff in which auth-context ownership transfers to the Wire. The `authTransferredToWire` / `authReleaseStarted` flags and the release-once logic move inside it.
- **D3 — declared outcomes, derived consequences.** Stages register resources as they materialize (relay conn, consume coordinator, auth owner, channel stream) and declare failures by kind from the seven situations the code already distinguishes: pairing failed, identity failed, nil auth context, auth validation failed, channel failed, upgrade failed, upgrade returned nil stream. From the declared kind plus registered state, settlement derives all five obligations in the one correct order, encoded once. Call sites become single-line declarations.
- **D4 — no new public surface.** The module is unexported; `wiremux.Dial`'s interface and doc contract do not change.
- **D5 — concrete collaborators, no new interfaces.** Settlement holds the existing `consumeCoordinator`, `preparedUpgradePlan`, and `authContextOwner` concretely. Nothing varies across those relationships, so no seam is introduced; tests substitute at the leaves that are already injectable.
- **D6 — candidate 4 sequenced after.** The error-tree ownership inference inside `cleanupAfterUpgradeError` stays as-is in this plan. Once settlement exists it is the single consumer of that inference, making ownership-as-a-stated-value a small local follow-up rather than part of this diff.
- **D7 (audit A1) — panic-safe release stays a frame-level defer.** `dialPaired` keeps exactly one frame-level `defer` into settlement (e.g. `defer settle.finish()`); the release guard is not converted into per-exit calls, because the current defer also covers panic paths and that behavior has no test sentinel. Settlement owns what the defer does; the frame owns that it always runs.
- **D8 (audit A4) — consume-ownership boundary.** Exit-time consumption is settlement's; success-side consumption is stream-mediated and stays stage-side: `consume.decorateRelay` (`wiremux.go:282`), `gateRelayWin` (`:309`), and direct-win consume triggered by stream close (`consume_coordinator.go:186-203`). The nil-auth context-error join at `wiremux.go:237-240` is pre-declaration error shaping and stays stage-side.
- **D9 (audit A5) — the spent-marking input is `successSpendsRendezvous`, not `oneShotRendezvous`.** They differ: a one-shot authenticator with a nil consume coordinator gives `successSpendsRendezvous == false` (no spent-marking, the `:227` exit unreachable) while `oneShotRendezvous` still independently gates the `:237` join. Do not "simplify" one to the other.

**Frozen behaviors (checklist for review):**

- The nil-auth-context matrix: one-shot post-success spent vs non-one-shot context-error retryable, per CONTEXT.md **Rendezvous disposition**.
- `ErrChannel` construction failures stay retryable unless one-shot.
- The `relayConn` → `relayStream` close switch at negotiator construction (`wiremux.go:268`).
- `cleanupAfterUpgradeResult` runs before the nil-stream check (`:299-300`).
- Relay-path streams gated through `consume.gateRelayWin` (`:309`).
- Release-observer publish ordering on the non-transfer path (`publishImmediate(releaseErr, true)` before `Dial` returns; `reportLate` gated on `<-o.published`, `auth_context_lifecycle.go:149-161`).
- **(audit A2) Release/consume overlap invariant:** the async release goroutine starts before the potentially-blocking consume hook and carrier close; the synchronous release-and-publish completes before `Dial` returns; both release callers observe one shared `releaseErr` via `releaseOnce`. Sentinels: `TestDialIdentityFailureConsumeRespectsEstablishTimeout` (`wiremux_test.go:734`), `TestDialIdentityFailureConsumeErrorHandlerDoesNotBlockReturn` (`:850`), `TestAuthContextReleaseBudgetStartsAtLogicalRevocation`.

**Rejected alternative (do not do this):** absorbing the whole stage sequence (authenticate → keys → channel → negotiate → upgrade) into the module. The linear flow is not the friction; the outcome assembly is. Moving the stages churns more code for no added depth and makes the freeze harder to review.

**Rejected alternative (do not do this):** bundling packet-socket-ownership-as-value into this change. It alters the internal contract between root and connect and violates D1; it lands after, smaller, on top of settlement.

**Non-goals:** no public-surface change; no change to connect, relay, channel, or transport packages; no retirement or rewrite of existing root tests; no change to the error-tree ownership inference (candidate 4); no new exported test hooks.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
|---|---|---|---|---|
| 1 | new | Settlement module owning all ten `dialPaired` endings, behavior-identical, with a settlement-interface test matrix | None | n/a — none introduced |

## Implementation Slices

### Slice 1 — Establishment settlement: behavior-identical consolidation

**What it delivers:** The settlement module in the root package, wired into `dialPaired` (its sole production caller, `wiremux.go:170`): all nine failure exits become single-line kind declarations, the success handoff transfers auth ownership through settlement, and the frame-level defer (D7) guards panic paths. Existing tests pass unmodified; a new settlement-interface test matrix pins the obligation set and order for every reachable kind × state row.

**Existing-work disposition:** new slice; no prior PRs, branches, or partial work exist for this track.

**Blocked by:** none — frontier.

**Single owner after merge:** settlement owns exit-time obligation derivation and ordering, the settled-exactly-once invariant, and the transfer/release decision. `authContextOwner` keeps owning release once-semantics; the consume coordinator keeps owning consume once/budget semantics; success-side stream-mediated consumption stays stage-side per D8. Each durable fact has one mutation owner; the previously caller-owned composition has exactly one.

**Authority completeness:** no new persisted or authoritative fact is introduced; not applicable.

**Transitional-seam budget:** none. The conversion is total in one slice; no exit remains hand-assembled, no duplicate representation or adapter is retained.

**Blast radius:** confined to the root package interior. Concurrency: the release-goroutine/defer overlap moves inside settlement with the A2 invariant preserved; the goroutine + `sync.Once` shape is unchanged, so `-race` behavior is neutral. No effect on `connect`, `relay`, `channel`, `transport`, `wiremuxtest`, the production-budget build tag, or benchmarks (verified in Current Shape). Performance: one small allocation per dial attempt; negligible. Security: auth-material release ordering and panic coverage preserved by D7/A2. No untraced effects.

**Artifact classification:** settlement module + `dialPaired` conversion = shipped behavior (behavior-preserving interior). Settlement-interface test matrix = verification aid maintained in the normal repo suite (standard Go tests; no special harness; maintained deliverable by ordinary test policy, retired only if the module it tests is removed). This plan doc = process/traceability metadata.

**Representation contract:** input domain = the seven declared failure kinds (a closed Go enum) × registered-resource state (carrier ∈ {none, conn, stream}, derived from registration order; auth owner nil/present; consume coordinator nil/present; `successSpendsRendezvous`; `authReturnedWithoutError` for the identity kind) plus the success declaration. Representation owner: the settlement module. Guarantee level: universal over the closed enum and reachable state combinations; unreachable combinations are structurally excluded (below), not silently accepted.

**Contract closure:** triggered (material consequence: cryptographic-material release, packet-socket ownership, session consumption; multiple independently reachable paths: nine exits). Invariant: every establishment attempt is settled exactly once, with the five obligations derived in fixed order from declared kind + registered state. Enforcement owner: settlement module. Behaviorally distinct semantic classes and dispositions — the reachable matrix: pairing 1 row (consume structurally nil, carrier none, no auth); identity 6 baseline rows (auth owner nil/present × consume-and-spend triples (nil,f)/(present,f)/(present,t)), with the `authReturnedWithoutError` split at spend=true adding 1 reachable row for auth-present `(present,t)` (post-success-spent + mark vs `onIdentityFailure`, no mark); the corresponding auth-nil post-success-spend state is structurally routed to the nil-auth declaration and is counted there, not duplicated as identity; nil-auth 3 rows (`:227` one-shot-spent forces (present,t); `:253` reachable only spend=false × consume nil/present); auth-validation 6 rows (3 consume/spend triples × carrier conn `:259` / stream `:283`); channel 3; upgrade 3; nil-stream 3; success transfer 1 — **27 reachable rows** out of a naive 112; the remainder are structurally unreachable because `successSpendsRendezvous = oneShot && consume != nil` (`wiremux.go:199-200`), the coordinator is constructed only after pairing (`:198`), the auth owner exists iff auth is non-nil (`:216`), the auth-nil post-success-spend branch precedes the identity-error branch (`:227-243`), and the carrier is derived from stage progress (`:268`). Terminating evidence: one settlement-interface test per reachable row, plus the frozen-behavior sentinels; unreachable classes recorded here, not tested.

**Evidence budget:** the 27-row settlement-interface matrix with shared fakes (recording consume function, fake `connect.AuthContext`, injected packet conn, recording release handler); the existing unmodified suite as the freeze proof; the three A2 sentinel tests named above; no new platforms, repetitions, timing harnesses, or hosted cells beyond the repo's standard gates; one review plus at most one replacement review per the review loop.

**TDD and preservation evidence:** the matrix tests are written first (red) against the settlement interface before the module exists; all fakes are constructible today (Current Shape, last bullet). Preservation gates: the untouched existing suite, the A2 sentinels, and the frozen-behaviors checklist as the reviewer's diff guide.

**Dispatch context budget:** this plan slice; `wiremux.go:136-330`; the three collaborator files (`consume_coordinator.go`, `upgrade_plan.go`, `auth_context_lifecycle.go`, ~1100 lines); `export_test.go`. No unresolved history; no governing diff (clean baseline at the plan commit). Estimated diff ~300-400 production lines + 700-1000 test lines, mostly a mechanical matrix. Implementation, local review fixes, and verification fit one fresh context; the concurrency subtleties that would otherwise consume discovery budget are pinned in writing (D7-D9, A2).

**Slice decision audit:** strongest further split — a characterization-first PR pinning the matrix through `Dial` before refactoring; rejected because every frozen behavior already has a named existing sentinel, so it would duplicate ~98 black-box tests and then be superseded by the settlement-interface matrix. Also rejected: module-then-conversion (horizontal; module without production caller) and partial exit conversion (two composition owners; incoherent transitional seam). Strongest merge — none; there is no adjacent slice. Blocking edges: none claimed, none exist.

**Stop conditions:** if converting any exit requires changing an observable error tree, cleanup order, consumption outcome, or ownership disposition — including discovering that two exits are inconsistent in a way the freeze cannot preserve simultaneously — stop and surface it as an approach-level finding rather than choosing silently. If preserving the A2 overlap invariant requires changing when the release goroutine starts relative to consume, stop likewise. D1 is the contract.

## Acceptance Criteria

- [ ] Every terminal exit in `dialPaired` is a single settlement declaration; no cleanup-ordering code remains at any call site. (Universal over the nine exits enumerated in Current Shape; owner: settlement; evidence: diff review against the exit map.)
- [ ] `authTransferredToWire` and `authReleaseStarted` no longer exist in `dialPaired`; the release-once and transfer invariants are settlement-internal, and the frame-level defer of D7 is the only release guard in the frame.
- [ ] The settlement matrix — all 27 reachable rows, success transfer included — is covered at the settlement interface with fake leaves; unreachable combinations are documented in this plan, not tested. (Universal over the closed kind enum × reachable states; owner: settlement; terminating evidence: the row-per-test matrix.)
- [ ] All pre-existing root tests pass unmodified, including the three A2 sentinels. (Universal over the existing suite; owner: the freeze; evidence: unmodified test files + green run.)
- [ ] No exported-surface change in the root package.

## Validation Gates

```bash
GOTOOLCHAIN=local go test . -count=1
GOTOOLCHAIN=local go test ./...
task verify
```

## Operating Discipline

Follow `docs/REVIEW-LOOP.md` for every slice/PR; it overlays the shared review-loop baseline, which governs the loop itself. No repository contract-closure overlay exists; this plan records its closure matrix inline (Slice 1) and the shared baseline governs where present. Track-specific stop conditions are in Slice 1; vocabulary is CONTEXT.md's (**Establishment settlement**, **Session consumption**, **Rendezvous disposition**, **One-shot rendezvous** — declare kinds in those terms, not ad-hoc names).
