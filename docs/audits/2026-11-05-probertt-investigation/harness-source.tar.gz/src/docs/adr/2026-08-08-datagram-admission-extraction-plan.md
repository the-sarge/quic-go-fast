# Datagram Admission Mechanism Extraction Implementation Plan

**Date:** 2026-08-08
**Status:** Implemented by [PR #1041](https://github.com/GridSwarm/wiremux/pull/1041); merged 2026-08-08
**Track:** 1 of 1 in the 2026-08-08 Datagram-admission extraction program
**Depends on:** nothing — safe to start immediately
**Related:** ADR-0009; [`2026-08-08-datagram-admission-prototype-plan.md`](2026-08-08-datagram-admission-prototype-plan.md); [`2026-08-08-datagram-admission-prototype-result.md`](2026-08-08-datagram-admission-prototype-result.md); accepted second-prototype verdict on [issue #1030](https://github.com/GridSwarm/wiremux/issues/1030#issuecomment-5227453373)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** First-prototype rejection receipt in the result doc above; second-prototype acceptance evidence (ordering matrices, focused `-race` results, census) in the linked #1030 comment; slice-decision audit recorded in this plan; implementation, review, exact-head verification, and hosted-certification receipts in [PR #1041](https://github.com/GridSwarm/wiremux/pull/1041) and the post-merge development journal

## Goal

Extract the send-admission mechanism duplicated by root `Datagrams.Send` and QUIC `quicDatagramCarrier.SendDatagram` into one deep internal module, `internal/datagramadmission`, whose seal owns the linearization point of send-side terminal closure. Both callers delete their slot semaphores, provisional admission structs, resolution channels, commit-fence mutex usage on the send path, `context.AfterFunc` commit arbitration, and unexported commit test hooks. Callers keep every policy: framing, size limits, error translation, cause vocabulary, gate/receive behavior, permitted loss, carrier termination, and aggregate teardown.

## Current Shape (verified 2026-08-08 at `4dc956646d57f0269fd2290d1132ef298f164bac`)

The four governed files are byte-identical between this head and `a87be7ad99038e2aaa48092fba3a16cb9d30070d`, the head where the accepted prototype ran (verified by empty `git diff` over `datagrams.go`, `datagrams_test.go`, `transport/quic/transport.go`, `transport/quic/transport_test.go`); the prototype evidence therefore transfers to this head verbatim.

- Root: `datagramSendAdmission` at `datagrams.go:21-24`; `sendQueue`/`sendSlots` at `datagrams.go:43-44`; `Send` at `datagrams.go:110-220` fences commits under `gateMu` with a release/reacquire window, two `context.AfterFunc` arbitrations, and the unexported `testBeforeSendCommit` hook at `datagrams.go:192`; `pumpSends` at `datagrams.go:341-386`; `closeGate` at `datagrams.go:418-428` publishes `d.closed` and closes `done` under `gateMu`; the first-cause-wins store is `setCause`/`closedError` at `datagrams.go:430-450`.
- QUIC: `quicDatagramAdmission` at `transport/quic/transport.go:482-485`; `sendQueue`/`sendSlots`/`admissionMu` and the unexported `testBeforeAdmissionCommit` hook at `transport/quic/transport.go:562-573`; `SendDatagram` at `transport/quic/transport.go:612-672` fences commits under `admissionMu` with its own send-path `context.AfterFunc` pair at `transport/quic/transport.go:632-635` (the root pair is `datagrams.go:144-147`; the extraction deletes both callers' arbitration mechanisms, four send-path registrations total); `pumpSends` at `transport/quic/transport.go:691-719`; `closeAdmission` at `transport/quic/transport.go:721-725` publishes the terminal cause via `endLifetime(cause)` under `admissionMu`; `streamConn.Close` drives it at `transport/quic/transport.go:534-555`.
- Both callers implement the same discipline with different vocabulary: one caller mutex serializes terminal publication with admission commit. The first prototype (rejected) showed that moving only the commit half into a shared queue splits that invariant across two mutexes. The second prototype (accepted, #1030) showed that moving the linearization point itself into the queue closes both terminal races without policy transfer.
- ADR-0009 requires two independently bounded cancellable queues (root capacity `datagramSendQueueCapacity` at `datagrams.go:15`; QUIC capacity `nativeDatagramQueueSize`). The shared mechanism is instantiated once per caller and never collapses them.

## Decision

Adopt the accepted seal-carries-reason design as the production contract. The shared surface is exactly four operations and one instantiation shape:

```go
package datagramadmission // internal; one Queue instance per caller

func New(owner context.Context, capacity int) *Queue
func (*Queue) Admit(call context.Context, payload []byte) error // nil | *SealedError | ErrOwnerEnded | call error
func (*Queue) Dequeue() (payload []byte, ok bool)
func (*Queue) Close(reason error) bool // first close wins; seals atomically with the commit fence
```

Grilled contracts, each stated in the package documentation. The queue's own deterministic tests cover the queue-owned portions of these contracts; caller-owned evidence (translation, close-site ordering) is assigned explicitly in the evidence budget and acceptance criteria:

1. **Seal linearization.** `Close` and the final admission checks share one mutex. Commit is the only enqueue; there are no provisional entries or resolution channels. After the winning `Close` returns, no admission can commit; an admission whose fence resolved before the seal may complete and its payload may still be discarded downstream under the callers' retained permitted-loss policy.
2. **Cancellation linearization.** The fence precedence is sealed → owner → call, universal for both callers; there are no caller modes. A commit linearizes when the fence resolves; a call cancellation or owner end that lands after the fence's checks does not revoke that commit. Blocked pre-slot waiters wake on seal, owner end, or call cancellation, and a canceled waiter cannot cross a released slot because the fence rechecks `call.Err()` under the mutex. Two-signal races (for example call cancellation concurrent with closure) stay within the callers' existing nondeterministic outcome envelopes; single-signal outcomes are deterministic.
3. **Dequeue-versus-seal ordering.** `Dequeue` returns committed payloads and releases their slots; it returns `ok == false` after seal or owner end. When a committed payload and the seal are simultaneously available, `Dequeue` may return either first; each caller's pump retains its production post-dequeue terminal checks, so this window never widens observable behavior. Payloads committed but not dequeued when the seal wins are discarded, and their slots are never recycled because the queue is terminal.
4. **Cause precedence.** The winning `Close` stores its opaque `reason error` under the fence mutex before the seal becomes observable, and `*SealedError` carries it out; the queue never inspects, wraps, or translates the reason. Root orders `setCause(cause)` before `Close` on every cause-carrying close path and translates seal rejection through its own `closedError()` store. QUIC seals with the cause and then calls `endLifetime(cause)`; its seal-rejection translation prefers a published `context.Cause(lifetime)` (preserving production precedence when the parent connection died first) and falls back to the seal reason, which is the same value its own `closeAdmission` publishes next. The #1030 case analysis shows no interleaving yields a nil or stale cause.
5. **Caller close discipline (the authority transfer).** The queue's seal — not `d.closed` or the carrier lifetime — is the source of truth for send-side terminality. Root `closeGate` seals before publishing `d.closed`/closing `done`; QUIC `closeAdmission` seals before `endLifetime(cause)`. These are the only two seal call sites, the caller-owned publications become post-seal echoes, and the inversion is the one intended behavioral change of this track. `Close` briefly blocks on an in-flight fence; production holds no I/O and no caller code under that mutex, so the wait is bounded by the fence's field checks.
6. **Deterministic testing without production callbacks or exported hooks.** The queue exposes no exported hook and accepts no caller callback. Deterministic fence-parking sentinels relocate into `internal/datagramadmission`'s own same-package tests through one unexported test-only hook field (the same class as today's unexported caller hooks), set only by tests. The caller packages delete `testBeforeSendCommit` and `testBeforeAdmissionCommit` together with the hook-dependent sentinels whose fence invariants moved into the queue; every caller-level translation contract retains deterministic hook-free evidence through blocked-waiter shapes (a waiter blocked pre-slot is released by the terminal transition and must observe the translated caller error). Two caller translation cases are separately required: seal-rejection translation (waiter released by the seal observes the caller's translated closed error and cause), and QUIC owner-ended translation (waiter released by parent-lifetime cancellation observes the normalized cause with `errors.Is` and zero native sends, replacing the deterministic evidence currently owned by `TestDatagramAdapterParentLifetimeCancellationDuringAdmission` at `transport/quic/transport_test.go:1199-1222`).
7. **Copy ownership.** `Admit` copies the payload; root keeps its framing copy, accepting the resulting double copy on the root path. Datagram payloads are small and bounded, and performance work is a non-goal.

**Rejected alternative (do not do this):** the first prototype's passive boundary, where callers publish terminal state and then call `Close`. Rejected with a committed receipt: it cannot preserve both terminal-ordering contracts in either call order.

**Rejected alternative (do not do this):** `Close(func())` executing the caller's terminal publication inside the seal. Atomically stronger but it is a callback, and it runs caller code under the shared lock — a deadlock class this repository has no need to adopt when seal-then-publish yields the same observable contract.

**Rejected alternative (do not do this):** injecting the caller's own mutex (`sync.Locker`) as the queue's fence. It keeps `gateMu`/`admissionMu` alive with two owners of one lock and re-splits the invariant across files, which is the original fragility.

**Rejected alternative (do not do this):** making the queue the Wire-level terminal-state owner by deleting `d.closed` and the cause store. Root's closed flag also serves receive and gate policy; that transfer widens scope into caller policy.

**Rejected alternative (do not do this):** lock-free/epoch or actor-loop rebuilds. No performance case at capacity 8, and deterministic race evidence becomes materially harder.

**Non-goals:** no public API or wire change; no queue collapse (ADR-0009 stands); no unification of error, lifetime, or terminal policy across callers; no performance claims, benchmarks, or fuzzing; no behavior change beyond the documented close-ordering inversion; no change to receive paths, gate semantics, framing, or size limits.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | merged in [#1041](https://github.com/GridSwarm/wiremux/pull/1041) | Shared admission queue and both rewired callers in one PR | None | n/a — none introduced |

## Implementation Slices

### Slice 1 — Extract the seal-owning admission queue and rewire both callers

**What it delivers:** `internal/datagramadmission` implementing the four-operation contract above with its own deterministic same-package test suite; root `Datagrams` and the QUIC carrier rewired to one `Queue` instance each with the seal-first close discipline; caller machinery deleted (both `sendQueue`/`sendSlots` fields, both provisional structs, all resolution-channel handling, `admissionMu`, both `context.AfterFunc` commit arbitrations, both unexported caller commit hooks); caller test suites adapted per the evidence budget. One PR.

**Existing-work disposition:** New slice. No open PR or branch implements this design; the two prototypes were throwaway and are fully removed. The #1023/#1029 rejection receipt stands as negative evidence and is not reworked.

**Blocked by:** None.

**Single owner after merge:** `datagramadmission.Queue` owns slot accounting, the copied committed entries, the seal with its opaque reason, and the commit/cancellation fence — the send-side terminal linearization point for both callers. Root `Datagrams` owns framing, public size limits, `ErrWireClosed` and cause translation, the cause store, gate/receive policy, permitted loss, and aggregate Wire teardown ordering. The QUIC carrier owns error normalization, lifetime and cause publication, native-send sequencing, and carrier termination. No fact or transition has two mutation owners; the caller flags become derived echoes on the send path while retaining their existing ownership for receive/gate consumers.

**Authority completeness:** The newly authoritative fact is the in-memory seal. Its constructor (`New`), all mutators (`Admit`, `Close`), and both destructive consumers (each caller's pump discard path and seal-rejection error path) land in this slice. Nothing is persisted; restart round-trip is not applicable.

**Transitional-seam budget:** None. No compatibility path, dormant package, feature flag, or duplicate representation remains; the old caller machinery is deleted in the same PR that introduces the queue.

**Blast radius:** Confined to the root Datagram send path, root close ordering inside `closeGate`, the QUIC carrier send path, and `closeAdmission` ordering. No public interface, wire format, or documented error identity changes; `Datagrams` and `connect.DatagramCarrier` surfaces are untouched. Concurrency effects are the contracts in the Decision section; the close-path fence wait is the only new latency and is bounded. Performance: one extra payload copy on the root path (accepted, non-goal). No new dependencies. Untraced effects: none identified; the prototype exercised both callers end to end at a byte-identical head.

**Artifact classification:** The queue package and rewired callers are shipped behavior. The queue's deterministic suite and the relocated/retained/added caller tests are verification aids running in the ordinary Go suite; no maintained verification-aid exception is claimed and none blocks shipped behavior. The reference census and the prototype evidence comment are process/traceability metadata.

**Representation contract:** Supported domain = the two production send-admission call sites and the behaviorally distinct terminal classes in the contract-closure matrix below, over payloads already validated by caller policy. Representation owner = `datagramadmission.Queue` for admission/terminal state; callers for all error surfaces. Guarantee = deterministic single-signal linearization evidence at the queue seam plus example-level caller integration evidence; two-signal races are explicitly bounded to the callers' existing nondeterministic envelopes, not universally ordered.

**Contract closure:** Triggered (terminal-ordering consequence; multiple independently reachable close paths). Invariant: no shared admission commits after send-side terminal closure linearizes, and every seal-rejected admission observes a coherent terminal cause. Enforcement owner: `datagramadmission.Queue` (single fence mutex plus reason slot). Behaviorally distinct semantic classes and dispositions:

| Class | Reaching path | Disposition and evidence |
| --- | --- | --- |
| Root explicit close (nil reason) | `Wire.Close` → `closeGate(nil)` | Seal-first; blocked/parked admissions reject to plain `ErrWireClosed`; root blocked-admission test |
| Root failure close (cause) | `fail(cause)`/monitor → `closeGate(cause)` | `setCause` precedes seal; rejection carries cause; root lifetime sentinels |
| Root carrier-lifetime end without close | monitor stopped or racing | Owner path at fence → `closeAfterCarrierLifetime`; idle-lifetime never-admits test |
| QUIC local close | `streamConn.Close` → `closeAdmission` | Seal precedes `endLifetime`; blocked-waiter translation test preserves cause |
| QUIC native-send failure | pump error → `closeAdmission(err)` → `terminateCarrier` | Sequencing preserved; unblocks/teardown tests |
| QUIC parent-connection death (no seal) | parent context cancels lifetime | Owner path; the queue suite owns the deterministic `ErrOwnerEnded` fence contract, the bounded hook-free QUIC owner-ended translation test owns normalized-cause and zero-native-send evidence, and the caller's coherent-outcome race covers the racing envelope |

**Evidence budget:** Queue package: at most eight deterministic same-package tests — call-cancellation at the fence, owner end at the fence, seal winning the fence, commit winning the seal race with `Close` blocking until the fence resolves, seal-reason visibility to rejected and blocked admitters, canceled-waiter slot recheck, capacity/slot accounting with dequeue release and payload-copy independence folded into the same test, and dequeue-after-seal discard. Callers: retain the hook-free named sentinels from the prototype evidence table in #1030 (root: frames/copies, blocked-admission cancellable and close-discard, idle-lifetime never-admits; QUIC: copies, unblocks-on-call-and-lifetime, canceled-waiter, coherent-outcome race, discards-after-termination) plus root `TestDatagramPostAdmissionLowerSendErrorSemantics`, an additional retained hook-free sentinel beyond those named in #1030's focused-evidence table; delete the four hook-dependent caller sentinels whose fence invariants relocate to the queue suite; add at most two new bounded hook-free tests total, both in QUIC — one seal-rejection translation test through a blocked waiter released by local `closeAdmission` (root already owns this evidence through its blocked-admission close-discard sentinel), and the QUIC owner-ended translation test required by Decision item 6. Gates: the validation sequence below, and a census showing `sendQueue`, `sendSlots`, both provisional structs, resolution handling, both caller hooks, both callers' send-path `context.AfterFunc` registrations, and `admissionMu` at zero references. Terminating rule: every contract-closure class has one evidence pointer per applicable caller. One review plus at most one fully briefed replacement review.

**TDD and preservation evidence:** Write the queue's deterministic suite first against the contract in the Decision section (red), then implement the queue (green), then rewire callers against the retained caller sentinels as the characterization oracle. The retained sentinels distinguish preserved behavior; the intended change (close-ordering inversion) is detected by the queue's seal-ordering test and by review of the two seal call sites.

**Dispatch context budget:** This plan slice; the Decision contracts; ADR-0009's two-queue rule; the #1030 evidence comment (ordering matrices and census); the first-prototype rejection receipt as negative context; `datagrams.go`, `datagrams_test.go`, `transport/quic/transport.go`, and the focused QUIC Datagram tests. The accepted prototype demonstrated the entire change plus tests inside one fresh context at a byte-identical head, so implementation plus local review fixes and verification fits one context. No historical plan versions are required.

**Slice decision audit:** Strongest split: land the queue package with its tests first, then rewire callers in a second PR. Rejected — a dormant internal package violates this repository's zero-transitional-seam budget, the queue contracts are only meaningful against the real callers, and the prototype already de-risked the combined diff (approximately 400 changed production lines per the #1030 census, plus test adaptations), which fits one review. Strongest merge: none; no adjacent open track exists. Blocking edges: none claimed, so none to justify.

**Stop conditions:** Stop for operator decision if the implementation requires any public API change, caller modes or flags in the shared object, a caller callback or exported test hook, expansion beyond one reviewable PR, collapsing the two queues, error translation or cause interpretation inside the queue, or if it uncovers a pre-existing production defect (file it separately; do not fix it inside this slice). A failing retained sentinel that cannot be satisfied under these constraints is an approach-level failure requiring a new handoff, not a wider slice.

## Acceptance Criteria

- [x] Both callers admit exclusively through one `datagramadmission.Queue` instance each, and the census shows every replaced machinery family at zero references (supported domain: the two production callers at the merge head; owner: this plan's census gate; guarantee: exact static count; evidence: the recorded grep census in the PR).
- [x] Root seals before publishing `d.closed`; QUIC seals before `endLifetime`; these are the only seal call sites (verified by review of `closeGate` and `closeAdmission` plus the queue seal-ordering test).
- [x] All retained caller sentinels pass unmodified except for the deletions and additions named in the evidence budget; the queue's deterministic suite covers the queue-owned portions of Decision items 1–4, 6, and 7 within the finite eight-test list; the caller-owned translation evidence of items 4 and 6 is discharged by the named caller tests; and Decision item 5 (seal-first caller close discipline) is verified separately by review of the two seal call sites in `closeGate` and `closeAdmission` plus the queue's seal-ordering evidence.
- [x] Root and QUIC Datagram race lanes and both full package suites pass under `-race` at the exact PR head.
- [x] No exported test hook, caller callback, caller mode, or public API change exists in the merged diff (negative criterion; verified by review and by the queue's exported-surface check in the PR).

## Validation Gates

First, before any Go subcommand, run the `AGENTS.md` Go toolchain supply-chain audit and record it in the PR: `GOTOOLCHAIN=local go version`, the selected `go version`, and `go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS`, requiring Go 1.26.5 or newer (prototype audit: `go1.26.5 darwin/arm64`).

Then run `task verify` (which owns format checks, module verification, the ordinary test suite, lint, vulnerability checks, and the standing race lanes; build and vet belong to the separate `cross-check` task), plus this slice's additions:

- New queue suite: `GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^Test' -count=1 ./internal/datagramadmission`
- The `AGENTS.md` Datagram race gates at the exact head, unchanged and additive to the queue suite: `GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run 'Datagram' -count=1 .`; `GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^Test.*Datagram' -count=1 ./transport/quic`; and `GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^Test(QUICProductionWireDatagramContract|ProductionWireDatagramAbsenceContract|ProductionWireMalformedDatagramContract|ProductionWirePostCommitMalformedDatagramContract)$' -count=1 ./internal/integration`
- Full-package race lanes: `GOTOOLCHAIN=local go test -race -count=1 . ./transport/quic`

Repository CI must pass at the same head per the shared baseline.

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice` for the slice PR, composed with the repository overlay [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md). Vocabulary: the **seal** is the queue's atomic terminal transition (reason-carrying, first close wins); the **fence** is the mutex-guarded final admission check; **seal-first close discipline** names the caller obligation in Decision item 5. Approach-level stop conditions are the slice stop conditions above; do not re-litigate the rejected alternatives or the two prototype verdicts.
