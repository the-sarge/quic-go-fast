# ADR-0005: Runtime Shutdown Supervision

## Status

Accepted.

## Context

The relay and deployable server need deterministic shutdown semantics before
wiremux can be treated as an operator-facing connectivity kernel.

The original `relay.Serve` API stopped accepting only when its listener failed
or was closed. That left accepted TLS handshakes, waiting peers, long-lived
registrations, and active byte proxies to finish on their own timing. The
`wiremux-server` binary also started relay, STUN, and ACME HTTP services as
independent loops without one bounded supervisor. A process receiving SIGTERM
could close the top-level context while sockets and in-flight relay work were
still live.

This was acceptable for early package behavior, but it is weak for deployment:
operators need a bounded termination path, tests need a deterministic way to
prove sockets are closed, and the relay must not corrupt rendezvous accounting
when shutdown interrupts active work.

## Decision

### D1: `relay.ServeContext` is the managed relay lifecycle API

`relay.Relay` exposes `ServeContext(ctx, listener)` as the context-aware serve
entry point. `Serve(listener)` remains available for callers that want the old
listener-driven lifecycle, but deployable code should use `ServeContext`.

On context cancellation, `ServeContext` closes the listener, closes tracked
accepted relay work, drains waiting peers, preserves consumed ephemeral
tombstones across clean restarts, and waits up to `WithShutdownTimeout` for
relay-owned goroutines and proxy connections to stop.

Clean context-triggered shutdown returns nil. Shutdown timeout returns
`ErrShutdownTimeout`; nonzero internal runtime accounting after drain returns
`ErrShutdownAccounting`. Those terminal shutdown failures make later
`Serve`/`ServeContext` calls return `ErrRelayTerminated`, because the relay may
have abandoned in-flight work. A relay also rejects concurrent serve calls with
`ErrRelayAlreadyServing`.

### D2: `wiremux-server` owns a bounded multi-service shutdown phase

`wiremux-server serve` runs relay, STUN, and ACME HTTP under one process
supervisor. The command derives its service context from the caller context plus
SIGINT/SIGTERM. On context cancellation or a service error, it starts a bounded
shutdown phase controlled by `--shutdown-timeout` (default 5s):

- relay uses `Relay.ServeContext`;
- STUN stops by closing its owned UDP packet socket;
- ACME HTTP stops through `http.Server.Shutdown`, falling back to `Close` if
  graceful HTTP shutdown fails.

The supervisor waits for every started service to report. Clean cancellation
returns exit code 0. Service errors and shutdown timeout return exit code 1.
Listener/packet-connection closure after shutdown starts is treated as an
expected stop condition rather than an operator-visible failure.

### D3: STUN remains socket-owned rather than context-owned

The `stun.Server` package contract remains unchanged: `Serve(net.PacketConn)`
runs until the caller-owned socket is closed and does not close that socket on
its own. The process supervisor owns the packet socket and closes it during
shutdown. This preserves the package's simple socket-ownership model and avoids
adding process lifecycle policy to the protocol package.

## Consequences

- Operators can send SIGINT/SIGTERM and expect relay, STUN, and ACME listeners
  to stop within the configured timeout or fail visibly.
- Relay package shutdown is testable without depending on process signals.
- `wiremux-server` tests assert that TCP and UDP listeners stop accepting after
  cancellation.
- A shutdown timeout is intentionally conservative: it reports a terminal relay
  state rather than pretending all relay-owned work stopped cleanly.
- Callers that embed `relay.Relay` directly should prefer `ServeContext` when
  they need bounded shutdown; `Serve` is still suitable for simple
  listener-owned lifecycles.
