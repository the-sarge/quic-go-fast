# ADR-0010: Root Dial Owns Auth-Context Lifecycle

## Status

Accepted.

An identity handshake produces an `AuthContext`, but the existing contract
leaves channel-key single use and retained-material cleanup with convention.
That is insufficient for identity schemes whose per-attempt material must be
claimed once and deterministically released. Keep the required `AuthContext`
method set minimal, add purpose-specific optional lifecycle capabilities, give
transports least-privilege revocable auth views, and make root `wiremux.Dial`
the lifecycle owner of every producer context returned to it.

## Decision

### Use purpose-specific capabilities, not incidental `io.Closer`

Add these optional `connect` capabilities:

```go
type ChannelUseClaimer interface {
    ClaimChannelUse() error
}

type AuthContextReleaser interface {
    ReleaseAuthContext() error
}
```

`AuthContextReleaser` is deliberately not `io.Closer`. Go interface
satisfaction is structural, so treating any `Close() error` as lifecycle opt-in
could silently transfer an unrelated or promoted close method on a BYO context.
The purpose-specific method makes the ownership contract explicit. A separate
adapter may opt an intentional `io.Closer` into release semantics; plain
`io.Closer` never does so by itself.

`ReleaseAuthContext` is a local cryptographic-state operation. It must be
concurrency-safe, idempotent, bounded, and free of network I/O or external
coordination. Its first call logically revokes the context even when physical
erasure reports an error; later calls return the retained first result. A
producer should implement idempotence as defense in depth. For conforming
bounded consumers, wiremux invokes release exactly once per valid exclusive
ownership transfer—not globally per concrete Go value. After a lease-drain
timeout, wiremux retains one release obligation and invokes the producer at
most once when safe; code that never relinquishes its active lease can prevent
physical invocation but cannot regain or create logical access.

Add `connect.ErrAuthContextReleaseTimeout`. Wiremux-owned auth views revoke new
access first, then wait only for one fixed internal lease-drain budget before
invoking the producer releaser. If an in-flight accessor or exporter call does
not finish within that budget, teardown returns
`ErrAuthContextReleaseTimeout` and one deferred completion remains responsible
for invoking `ReleaseAuthContext` after the final lease exits. No new lease can
start after revocation. If a producer releaser itself violates its bounded
contract, the same timeout classification is published while its one invocation
continues without a second call.

The implementation uses one one-second end-to-end release budget, beginning at
logical revocation. Lease drain and the producer `ReleaseAuthContext` call share
that budget; the producer receives only the time remaining after leases drain.
If either phase exhausts the deadline, the immediate stable result is
`ErrAuthContextReleaseTimeout` and the single deferred release obligation
continues as described above. There is no second timeout window.

This makes root teardown bounded and logical revocation immediate, but it does
not falsely promise synchronous physical erasure from non-conforming code. An
exporter call that never returns can retain the producer material it is already
using indefinitely; the timeout error and release-error observer make that
failure operationally visible. `KeyExporter.Derive` is correspondingly
documented as a bounded local derivation that must not perform I/O or external
coordination, while the runtime timeout still fails safely when an
implementation violates that contract.

Add shared `connect.ErrAuthContextReleased` and
`connect.ErrChannelUseClaimed` classifications. After logical release:

- `SendKey`, `ReceiveKey`, and `SessionBinding` return nil;
- `Exporter` returns a non-nil exporter whose `Derive` returns
  `ErrAuthContextReleased`;
- `ClaimChannelUse` returns `ErrAuthContextReleased`; and
- no accessor panics.

A second claim returns `ErrChannelUseClaimed`. Release never resets a claim.
Claim/claim, release/release, and claim/release races must be data-race-free and
linearizable. Identity layers may wrap either shared sentinel with scheme
detail, but callers must be able to classify it with `errors.Is`.

### Ownership transfers at the Authenticator result boundary

Root `Dial` uses this complete result contract:

| `Authenticator.Authenticate` result | Ownership |
| --- | --- |
| `(nil, err)` | No context transfers. |
| `(auth, nil)` | `Dial` owns `auth`. |
| `(auth, err)` | `Dial` owns and defensively releases the unusable partial `auth`. |
| `(nil, nil)` | Contract violation; no context transfers. |

An authenticator must not defer, schedule, or perform release after returning a
non-nil context to `Dial`. Any other party that retained the same value must
not read, derive from, claim, release, or transfer it again. Direct callers of
`Authenticate` instead own every non-nil result they receive, including an
invalid partial result returned with an error.

Transfer also applies when the context does not implement
`AuthContextReleaser`: root owns its use, but there is no automatic release
operation to invoke. A legacy or BYO context with intentional cleanup must be
wrapped in the explicit releaser adapter before transfer. Retaining the value
and calling an incidental `Close` after transfer is not supported.

Constructing `StaticAuth` does not transfer its context. A failure before
`StaticAuth.Authenticate` leaves the wrapper unspent and the context with the
caller. Once it returns the context, the table above applies and the wrapper is
spent. Starting `Dial` with `StaticAuth` therefore forbids concurrent use of
the same context while the outcome is unresolved. Constructing multiple
`StaticAuth` wrappers for one context or transferring the same context through
multiple Dials creates unsupported duplicate owners; wiremux does not add a
context-keyed global registry.

### Claim exactly one canonical encrypted channel

After rejecting a nil stream or nil context, `channel.NewChannel` invokes
`ClaimChannelUse` when the presented dynamic context supports it, before
snapshotting directional keys. `NewStream` continues to delegate to
`NewChannel`, so one stream construction makes one claim. A successful claim
is irreversible even if later key validation or channel construction fails;
the caller must authenticate again. Concurrent initializations permit at most
one successful claim.

`connect.NewDirectionalKeys`, `connect.NewNegotiator`, exporter access, and
ordinary accessors do not claim channel use. Root `Dial` may perform preflight
validation without spending the claim; its relay-channel construction makes
the one claim for both eventual relay and direct Wire outcomes. A direct
upgrade does not create a second wiremux encrypted channel.

Claim enforcement applies to the dynamic value presented to the channel
constructor. A key-preserving decorator must explicitly forward
`ChannelUseClaimer`; silently hiding it is non-conforming. Wiremux documentation
and conformance fixtures must show named claim-preserving and intentionally
non-claiming wrapper shapes rather than imply that optional discovery can see
through arbitrary wrappers.

### Give transports a least-privilege revocable auth view

The producer context cannot be released safely while a transport still uses
it. Today `Transport.NewSession` may remain in flight after cancellation, and a
timed-out `Session.Close` may still be running when cleanup returns. A prose
rule that transports stop using the producer context cannot make those bounded
paths safe.

Replace the transport-facing `AuthContext` parameter with a narrower public
surface:

```go
type TransportAuth interface {
    SessionBinding() ([]byte, error)
    Exporter() KeyExporter
}
```

`Transport.NewSession` receives a wiremux-owned `TransportAuth` view, never the
producer context and never directional channel keys. The view and every
exporter obtained from it share the producer lifecycle gate. Each accessor or
`Derive` call takes a bounded read lease. While live,
`TransportAuth.SessionBinding` returns a caller-owned binding and nil error;
after revocation it returns `(nil, ErrAuthContextReleased)`. `TransportAuth.Exporter`
always returns a non-nil gate-bound exporter; exporters obtained before or
after revocation return `ErrAuthContextReleased` from `Derive`. The view
contains no independently releasable secret state, so a blocked `NewSession`,
late result, or timed-out `Session.Close` may retain the view but cannot begin
new use of auth material after logical revocation.

The view cannot satisfy `connect.AuthContext`, so it mechanically cannot be
passed to `channel.NewChannel` and cannot restart AES-GCM channel nonces. A
transport owns caller-returned derived byte slices, as it does today; releasing
their source cannot erase those copies. Transport implementations must finish
all required exporter derivation while the Wire is live and handle
`ErrAuthContextReleased` if late cleanup or background work attempts derivation
after aggregate teardown.

This deliberately changes the public `Transport.NewSession` signature from
`AuthContext` to `TransportAuth`. It is preferable to duplicating a full auth
context with no release owner or relying on optional claim discovery to keep a
transport-held snapshot out of channel constructors.

### Expose a non-owning, non-releasing Wire.Auth view

`Wire` retains the producer context internally. `Wire.Auth()` returns a stable
wiremux-owned view implementing `connect.AuthContext`, not the producer-native
dynamic value. The view never exposes `AuthContextReleaser`. When the source is
claim-capable, the view also forwards `ChannelUseClaimer`, so passing it to a
second canonical channel constructor still fails instead of silently dropping
single-use enforcement.

The view is valid only while the Wire remains live. It serializes access
against release. Exporters obtained through the view share its revocation gate:
after explicit or automatic aggregate teardown, existing and future view
exporters return `ErrAuthContextReleased`, and view accessors follow the uniform
post-release rules above. This prevents callers from revoking a live Wire while
retaining `Wire.Auth` for session-binding and application-exporter use.

Consumers that type-assert `Wire.Auth()` to an identity-layer concrete type
must migrate. Identity-specific access belongs before ownership transfer or on
separate non-secret metadata, not on the root Wire's non-owning auth view.

### Coordinate explicit and automatic aggregate teardown

One aggregate teardown state machine owns carrier shutdown and auth release:

1. Close the Datagram admission gate and retain the initiating cause.
2. Logically revoke every auth view and start the bounded auth-lease drain and
   producer-release path.
3. Signal the Datagram lifetime monitor to exit.
4. Close the reliable carrier.
5. Wait for Datagram workers and monitor completion.
6. Join and retain carrier errors with the immediate auth-release result,
   including `ErrAuthContextReleaseTimeout` when release continues later.
7. Publish that stable completion result to concurrent and later `Wire.Close`
   calls under the existing `ErrWireClosed` normalization boundary.

If the Datagram lifetime monitor observes terminal carrier failure, it records
and signals teardown, then exits. A different coordinator execution performs
the waits; the monitor never waits for its own completion. Concurrent automatic
teardown and any number of `Wire.Close` calls converge on the same completion
and share the same release obligation for that ownership transfer.

Logical revocation therefore precedes potentially blocking carrier teardown.
The existing reliable-carrier `Close` and Datagram worker waits may still block
under their established contracts; this ADR does not introduce a new overall
Wire-close timeout. A blocked carrier cannot keep auth views live or postpone
the independently supervised producer-release path. The bounded verification
obligation applies to logical revocation and auth-release timeout publication,
not to arbitrary carrier shutdown.

A reliable-read outcome that closes only the Datagram gate is not aggregate
teardown: the independent reliable write direction may remain usable, so the
auth context remains live. Other direction-local errors likewise leave release
to later aggregate teardown. A caller that abandons a successful Wire without
calling `Wire.Close` forfeits deterministic release; no finalizer or background
expiry is added.

On failed `Dial`, release errors must not change the establishment stage or
rendezvous disposition. Add an optional
`WithAuthContextReleaseErrorHandler(func(error))` observer. Root invokes it at
least once when failed-Dial cleanup cannot fully release a context; the handler
must return promptly and cannot affect Dial. An immediate timeout or release
error is one event. If deferred completion later returns a distinct non-nil
producer error, that late error is a second and final event. Deferred success
does not generate a second event. Without an observer, these cleanup errors are
intentionally discarded, matching existing best-effort cleanup precedent while
documenting the operational-evidence risk.

On `Wire.Close`, join a release error with any carrier close error and normalize
the result through `ErrWireClosed`, preserving every underlying identity.
Automatic teardown retains the same result so a later `Wire.Close` observes it;
the stable result is never mutated by deferred completion. When the observer is
configured, automatic teardown follows the failed-Dial event rule. An explicit
`Wire.Close` that initiates teardown returns the immediate release result and
does not send that same event to the observer, but a distinct late producer
error from deferred completion must be sent once because it cannot be added to
the already-published close result. A later `Wire.Close` returns the same stable
result and never duplicates observer events.

### Forward optional capabilities deliberately

Key-preserving decorators must forward every optional capability their source
supports: `ChannelUseClaimer`, `AuthContextReleaser`, and any existing optional
contract relevant to the wrapper. Wiremux will provide documented named
wrapper patterns and conformance fixtures for preserving multiple capabilities.
A capability-dropping wrapper is non-conforming unless it is a deliberate
non-owning view such as `Wire.Auth`, which preserves claims while intentionally
hiding release.

Optional discovery does not protect legacy or BYO contexts that do not opt in.
Those contexts retain caller-enforced single use and receive no automatic
material release, but root ownership still prohibits caller cleanup after
transfer. Contexts requiring cleanup use `AuthContextReleaser` directly or the
explicit adapter. Schemes that promise enforced single use or retain releasable
per-attempt material must implement the new capabilities.

## Public contract and migration

Wire formats, AEAD nonce construction, rendezvous consumption, transport
negotiation, and the required `AuthContext` method set do not change. Public Go
behavior does change:

- authenticator authors must follow the result/ownership table;
- release-capable identity contexts implement the dedicated releaser and the
  uniform post-release contract;
- single-use identity contexts implement the channel-use claimer;
- transport authors accept `TransportAuth` and do not depend on directional
  channel keys;
- key-preserving decorators forward optional capabilities;
- legacy contexts with intentional cleanup adopt the explicit releaser adapter
  before transfer;
- `StaticAuth` callers stop using a context once authentication returns it;
- `Wire.Auth` consumers treat its result as a non-owning view and stop concrete
  identity-layer type assertions; and
- `Wire.Close` callers may observe joined auth-release failures.

Codemux Resume must adopt the claim, release, error, transport-view, and
root-Dial integration contracts. Other identity layers adopt them only when
their concrete design promises the corresponding lifecycle behavior; this ADR
does not assume unimplemented keymux internals.

## Considered options

- Use `io.Closer` as the release marker. Rejected because incidental structural
  satisfaction can silently opt BYO contexts into ownership transfer.
- Widen required `AuthContext` with claim and release methods. Rejected because
  it breaks every implementation even when it retains no releasable state or
  makes no enforced-single-use promise.
- Give transports a detached full `AuthContext` snapshot. Rejected because it
  duplicates directional keys and exporter state without a deterministic
  release owner, and absence of `ChannelUseClaimer` would let the snapshot
  initialize another nonce-zero channel. A narrow revocable `TransportAuth`
  view preserves bounded cleanup without copying channel authority.
- Wait for all transport work through a session-wide lease/barrier. Rejected
  because current bounded cancellation and cleanup may return while arbitrary
  BYO `NewSession` or `Session.Close` code remains live. Bounded per-operation
  leases on the narrow view let producer release revoke late consumers without
  waiting for the whole transport call to terminate.
- Return the producer-native context from `Wire.Auth` and rely on callers not
  to release it. Rejected because the release capability would remain reachable
  and post-release accessor behavior would remain identity-specific.
- Count ordinary accessor calls as channel claims. Rejected because root
  validation, channel construction, negotiation, and transports legitimately
  inspect the same material more than once.
- Roll back a claim after failed construction. Rejected because concurrent
  attempts and copied key snapshots make non-observation impossible to prove.
- Add a context-keyed global release registry. Rejected because exactly-once is
  scoped to valid exclusive transfers; duplicate owners are unsupported misuse.
- Join failed-Dial release errors into establishment errors. Rejected because
  an unrelated cleanup branch could distort stage or rendezvous-disposition
  classification; an explicit observer preserves both axes.

## Verification obligations

Use table-driven and race-tested conformance coverage for:

- all four `Authenticate` result shapes, including cancellation combined with
  `(auth, err)`;
- rendezvous/pre-auth failures leaving `StaticAuth` unspent and unreleased;
- validation, claim, channel, negotiator/exporter, upgrade, and nil-stream
  failures after transfer;
- exactly one full-Dial claim on relay and direct outcomes, and zero claims by
  pre-validation, `NewDirectionalKeys`, negotiation, and exporter access;
- nil inputs, failed claims, failed post-claim construction, claim/claim,
  release/release, claim-then-release, release-then-claim, and concurrent
  claim/release;
- revocable `TransportAuth` views with blocked `NewSession`, blocked
  `Session.Close`, retained exporters, and derivation racing release, proving
  bounded revocation without a data race or retained channel authority;
- a binding-only transport, proving live binding access succeeds and access
  after revocation fails with `ErrAuthContextReleased` rather than an ambiguous
  empty value;
- a deliberately blocked exporter and a deliberately blocked producer
  releaser, proving teardown returns `ErrAuthContextReleaseTimeout` within its
  budget, new calls fail immediately, and one deferred release runs if the
  blocker later exits;
- a BYO context with an unrelated `Close() error`, proving it is never invoked;
- preserving and capability-dropping wrappers, with the latter documented as
  non-conforming;
- `Wire.Auth` access and exporter derivation before, during, and after explicit
  and automatic teardown, with no panic or data race;
- blocked Datagram workers, monitor-initiated teardown, concurrent close calls,
  immediate pre-carrier logical revocation, non-self-waiting coordination, and
  auth-release progress independent of a blocked carrier;
- distinct carrier and release errors retained under `ErrWireClosed`;
- failed-Dial release errors reaching only the configured observer while stage
  and disposition remain unchanged, plus timeout and distinct late-error event
  counts for failed-Dial, automatic, and explicit-close initiation; and
- non-claiming, non-releasing legacy/BYO contexts receiving no automatic
  release while still surrendering use and cleanup authority after transfer.

Every failure row asserts claim count, release count, cleanup ordering, stage,
disposition, returned error identities, and observer calls. Run the focused
suites and the complete repository gate under the race detector where
specified before downstream pinning.

## Scope

This decision adds public optional capabilities and changes lifecycle behavior;
it is not accurately described as “no application API change.” It changes no
identity protocol, channel or relay wire format, AEAD nonce format, rendezvous
policy, transport selection, or application payload API. It does not make
arbitrarily duplicated key material impossible to misuse or erase copies
already handed to channel and transport consumers. It makes supported
claim-capable contexts enforce single canonical channel use, isolates bounded
transport work from producer release, and gives release-capable contexts one
deterministic root owner.
