# Datagram Admission Extraction Program — 2026-08-08

**Status:** Complete; the single track merged in [PR #1041](https://github.com/GridSwarm/wiremux/pull/1041)

## What this is

The dispatch index for the scoped follow-on handoff authorized by the [2026-08-08 architecture deepening program](2026-08-08-architecture-deepening-program.md), whose Track 3 required "a new scoped architecture handoff before production implementation" of any accepted Datagram-admission design. All five of that program's tracks have landed and its tracking issue #1024 records completion. The accepted seal-carries-reason design recorded on [issue #1030](https://github.com/GridSwarm/wiremux/issues/1030#issuecomment-5227453373) was implemented by [PR #1041](https://github.com/GridSwarm/wiremux/pull/1041). The single linked track plan remains the normative source of truth; this index records stable identity, dependencies, and the now-empty frontier. Audit history stays behind the plan's links.

## Outcomes that require no implementation

- The first prototype's passive four-operation boundary remains rejected per [`2026-08-08-datagram-admission-prototype-result.md`](2026-08-08-datagram-admission-prototype-result.md); do not re-propose it.
- Close-callback, injected-caller-lock, Wire-level terminal-owner, and lock-free/actor designs are rejected in the track plan's Decision section; do not re-litigate them without new evidence.

## Tracks, dependencies, and frontier

| # | Track | Plan | Parent issue | Blocked by | Slices | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Datagram admission mechanism extraction | [`2026-08-08-datagram-admission-extraction-plan.md`](2026-08-08-datagram-admission-extraction-plan.md) | [#1038](https://github.com/GridSwarm/wiremux/issues/1038) | None | 1 | COMPLETE |

The single child slice merged through [#1041](https://github.com/GridSwarm/wiremux/pull/1041), closing [#1039](https://github.com/GridSwarm/wiremux/issues/1039). The program frontier is empty: this track has no successor slice, deferred review finding, or remaining implementation work.

## Rules that bind every track

- Preserve the v0.1.x public interface, wire protocol, documented error identities, Datagram semantics, and ADR-0009's two independent bounded queues; the only intended behavioral change is the seal-first close ordering named in the plan.
- One PR, one fresh implementation context, zero transitional seams. Public-interface changes, caller modes, callbacks, exported hooks, or growth beyond one reviewable PR are stop conditions, not scope adjustments.
- Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md).
- Post-merge ritual: review loop → exact-head certification/same-head CI → merge → append-dev-journal → complete the OmniFocus slice task → update the tracker and frontier.
