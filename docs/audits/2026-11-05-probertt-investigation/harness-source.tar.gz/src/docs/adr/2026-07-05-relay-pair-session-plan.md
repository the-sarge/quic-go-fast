# Relay Pair Session Implementation Plan

**Date:** 2026-07-05
**Status:** Accepted; implemented by PRs #538, #541, and #545
**Track:** 2 of 4 in the 2026-07-05 third architecture deepening program
**Depends on:** nothing (relay package only; parallel-safe with Track 1)
**Related:** ADR-0004 (must honor — ledger owns pair resolution), ADR-0005

## Goal

Concentrate the relay's accepted-connection choreography — wait,
win-the-removal-race teardown, watcher stop, prefix handoff, proxy release
transfer, abuse accounting — in one deep pair-session module. The
rendezvous ledger stays the sole pair-resolution authority; the session
owns only the I/O choreography the ledger deliberately refuses to do.
Locality: the four hand-copied teardown sites become one method; the two
near-duplicate dial handlers collapse to constructing a session.

## Current Shape (verified 2026-07-05, main@49d8cb3)

- `handleEphemeralDial` (`relay/lifecycle.go:107-151`) and
  `handleLongLivedDial` (`:153-209`) are near-duplicate ~45-line
  select/timer blocks. Real differences: deadline source
  (`ephemeralDeadline` vs `cfg.pairTimeout`), the long-lived notify step
  (`notifyLongLivedIncoming` :172), abuse recording (ephemeral only), and
  timeout error codes.
- The "win removal → stop watching → write error" teardown trio is
  hand-copied at `lifecycle.go:141-146`, `:173-178`, `:183-187`,
  `:200-204`.
- `ephemeralWaiter` (`relay/ledger.go:34`) is simultaneously a ledger map
  value, an expiry-heap entry, a result-channel owner, and a watcher
  owner — mutated from `lifecycle.go`, `ledger.go`, and
  `waiter_watcher.go`.
- `pairing` (`ledger.go:567`) exposes six methods whose safe call order is
  prose (`:585-608`); `pair()` (`lifecycle.go:439-488`) hands release
  ownership to the proxy mid-function via a `proxyHandoff` bool and a
  wrapped-release closure.
- `lifecycle_test.go` already drives the handlers over `net.Pipe` without
  TLS (`relayLifecycleHarness`), but asserts on wire bytes and ledger
  snapshots — there is no session outcome to assert against.

## Decision

- New unexported `pairSession` type in `relay`: owns the accepted conn,
  waiter handle, result channel, prefix buffer, deadline, and mode
  strategy. Interface: a constructor plus one run method returning the
  `owned` outcome the handlers return today.
- Two constructors — `newEphemeralPairSession`, `newLongLivedPairSession`
  — share one run loop; mode differences (deadline, notify step, abuse
  hooks, timeout code) are strategy fields set by the constructors.
- The teardown trio becomes one session method; the four copies are
  deleted.
- The ledger API, locking, and linearization point are UNCHANGED. The
  session sits between the lifecycle handlers and the ledger.

**Rejected alternative (do not do this):** moving any peer I/O or watcher
ownership into the rendezvous ledger. ADR-0004 forbids it; the ledger
stays pure state plus the removal linearization point.

**Rejected alternative (do not do this):** one constructor with mode
flags. The grilling chose two constructors so each rendezvous mode's
contract stays explicit at the call site.

**Non-goals:** no relay protocol changes; no shutdown-supervision changes
(ADR-0005); no waiter-watcher rewrite (slices 1–2 move ownership, not
implementation).

## Implementation Slices

**PR 1.** Introduce `pairSession` and its run loop; port
`handleEphemeralDial` onto it. TDD: first write session-level tests
(pipe-based, following the `relayLifecycleHarness` pattern) for: immediate
pair; wait-then-pair; timeout-wins-the-race; cross-goroutine resolution
wins the race; watcher reject. Behavior preservation: existing
`relay_test.go` end-to-end suite unchanged and green; relay race gate.

**PR 2.** Port `handleLongLivedDial` (notify strategy); delete both
duplicated handler blocks and all four teardown copies. Scenario-mapping
checklist for any lifecycle tests deleted or moved.

**PR 3.** Absorb `pair()`'s release-transfer choreography into session
teardown and shrink what callers touch of `pairing`'s six-method surface.
Scenario audit plus repeated race validation.

## Acceptance Criteria

- `grep -rn "removeWin" relay/` shows exactly one call site (inside `pairSession`).
- `handleEphemeralDial`/`handleLongLivedDial` reduce to classify + construct + run.
- `ephemeralWaiter` no longer owns watcher lifecycle state (after PR 3, watcher ownership is session-side).
- Relay wire behavior byte-identical: the full `relay_test.go` e2e suite passes unchanged.

## Validation Gates

```bash
GOTOOLCHAIN=local go test ./relay/...
GOTOOLCHAIN=local go test -race ./relay/...
GOTOOLCHAIN=local go test -race -count=100 -run 'Dial|Pair|Waiter|Lifecycle' ./relay/
task verify
```

## Operating Discipline

Follow `docs/REVIEW-LOOP.md` for every PR. STOP condition: if any session
shape requires changing ledger lock ordering or the removal linearization
point, stop and check with the operator — that is ADR-0004 territory and
an approach-level finding.
