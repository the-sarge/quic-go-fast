# ADR-0012: TURN/UDP Relay Candidates Carry End-to-End QUIC

## Status

Accepted.

## Context

The released connectivity kernel establishes authenticated QUIC on a selected pair whose two candidate kinds independently belong to `{host, reflexive}` when direct probing succeeds and otherwise keeps the already-open encrypted TLS/TCP relay stream. The reliable fallback is correct when UDP is unavailable, but it cannot truthfully expose wiremux's unreliable-unordered Datagram capability. Restricted NATs can block peer-to-peer UDP while still permitting each peer to exchange UDP with a public relay.

Issue #707 compared packet-preserving relay architectures and selected QUIC over TURN/UDP as the narrowest fit, initially behind a demand measurement gate. A bounded Pion TURN prototype then carried the unchanged authenticated wiremux QUIC reliable stream and bidirectional Datagrams through two independent TURN/UDP allocations without Pion ICE or WebRTC. It also exposed production requirements: deterministic ChannelData readiness, a fragmentation-safe QUIC profile, one composite allocation owner, a compatibility-safe relay representation, and secure public-service controls. The product owner subsequently made relay-capable UDP/QUIC a required wiremux behavior and explicitly superseded the earlier demand gate.

A separate prototype rejected Pion ICE as wiremux's authoritative connectivity engine because its candidate-selection and connection abstractions could not preserve wiremux's exact packet-socket, source-binding, terminalization, and compatibility contracts. Future WebRTC work may use Pion ICE inside a Pion WebRTC transport, where that stack naturally owns its ICE session.

## Decision

Use Pion TURN directly behind a wiremux-owned carrier seam to carry the existing end-to-end authenticated QUIC transport over TURN/UDP. The adapter admits base-socket datagrams to Pion only when their actual canonical UDP source equals immutable `Config.Server`; peer-source filtering after Pion demultiplexing is not a substitute. TURN credentials authorize relay resource use only; `AuthContext`, authenticated probing, selected-remote enforcement, QUIC fingerprint binding, and the existing transport lifecycle remain the peer and Wire authorities. Retain the encrypted TLS/TCP relay as the last-resort reliable path when direct UDP and TURN/UDP do not produce a carrier.

Preserve upgrade-control v1 core fields/codes and the complete authenticated-probe v1 encoding byte-for-byte. An unconfigured peer's complete v1 Offer remains unchanged; a configured peer advertises exact `wiremux.turn-retry/1:true` through the existing ignore-unknown Offer extension map. Only after bilateral support and direct-probe failure before commit may the peers enter a separately framed and versioned TURN retry profile that owns relay allocation exchange, the relay/relay authenticated probe transcript, selection, readiness, commit, and convergence. Old peers ignore the capability and retain current direct-or-reliable-relay behavior. An ordinary TURN failure before commit returns to the already-open reliable relay when the synchronized terminal exchange succeeds; outer-context termination or failed control synchronization remains an error. After commit or any non-nil transport stream, existing no-fallback finality applies.

Use a separate fragmentation-safe QUIC ALPN profile, `wiremux-quic/3`, for the first TURN path. A `/3` connection offers exactly that ALPN with no `/1` or `/2` fallback. It starts from a 1200-byte inner QUIC packet class and may expose Datagrams only after ChannelData readiness is deterministically awaited and exact IPv4/IPv6-minimum outer-packet evidence certifies the lifetime-fixed lower and public ceilings. The existing `/2` profile and its 1240-byte lower/1239-byte public ceilings remain unchanged. Provisional `/3` values such as 1160/1159 are evidence hypotheses, not accepted constants.

Keep transport-upgrade outcome and carrier topology distinct. `UpgradePathRelay` continues to mean the original reliable TLS/TCP fallback and `UpgradePathDirect` continues to mean a successful transport upgrade for compatibility. A single classifier derives direct versus relay-assisted topology from the produced path and selected pair: direct upgrade admits two candidate kinds independently in `{host, reflexive}` in any order or combination, relay fallback and upgraded relay/relay are relay-assisted, and a mixed pair is exactly one relay plus one non-relay candidate and is invalid. An arbitrary externally constructed result is not authoritative.

The first supported client domain is built-in QUIC over TURN/UDP with relay/relay pairs, one selected allocation per peer, no migration, and caller-supplied short-lived credentials carried by typed `pionturn.Config`. The constructor performs no network I/O, and allocation happens only after authentication and direct failure. Do not overload `relayurl`, derive TURN authorization from peer identity, or require a bundled server: the client must interoperate with an independent standards-based server. A bundled `wiremux-server` TURN service, if enabled, is an explicit opt-in single-node service with bounded resources and a separate implementation track.

## Considered Options

- Adopt Pion ICE for all connectivity selection. Rejected by prototype because it would replace wiremux's authenticated selection and exact lifecycle authorities and would still require a new compatibility profile.
- Use WebRTC data channels now. Rejected for this path because SCTP/DTLS/ICE is a second transport architecture rather than a packet relay for the existing QUIC carrier. It remains appropriate for a future WebRTC transport.
- Use DERP instead of TURN. Rejected as a substitution because DERP is a reliable stream relay and therefore occupies the same last-resort role as wiremux's TLS/TCP relay. Issue #1048 separately studies DERP's reusable operational lessons.
- Add relay code 3 to v1 candidate or probe registries, or relabel a relay address as reflexive. Rejected because both encodings and the authenticated transcript are frozen and the latter would be semantically false.
- Send a new upgrade-control version as the first offer. Rejected because it would sacrifice old/new direct interoperability when the existing extension point can negotiate a later retry profile.
- Permanently fork Pion TURN immediately. Rejected. First contribute the minimal deterministic readiness capability upstream; a maintained GridSwarm fork requires a new owner decision if upstream declines or cannot release it in time.
- Carry the TURN path over TCP or TLS and expose Datagrams. Rejected because lower reliable retransmission and head-of-line ordering cannot satisfy the Datagram contract.

## Consequences

wiremux gains a third physical connectivity outcome—QUIC over a packet relay—without adding a second peer-authentication or candidate-selection authority. Direct QUIC remains preferred; TURN allocation cost is incurred only after negotiated direct failure; reliable relay fallback remains usable through ordinary pre-commit TURN failures whose synchronized terminal exchange succeeds and for UDP-blackholed networks. Outer-context termination and failed control synchronization remain terminal errors rather than successful fallback.

The implementation requires a selected-path resource owner, deterministic Pion ChannelData preparation, a new QUIC profile, a separate authenticated retry codec, public topology reporting, caller-supplied TURN configuration, interoperability evidence, and exact cleanup across direct sockets, TURN allocations, and transport resources. The accepted dispatch boundaries live in the [TURN/UDP architecture program](2026-08-09-turn-udp-architecture-program.md) and its two normative track plans. Public and wire additions are compatibility-sensitive even though there are currently no downstream users; the plan deliberately preserves frozen v0.1.x behavior instead of spending that freedom on avoidable breakage.

The accepted root signature `wiremux.WithTURN(pionturn.Config)` deliberately imports the Pion adapter into the root package and therefore places Pion TURN and its transitive packages in the root package's Go build/dependency closure for downstream consumers even when TURN is not configured. This is an accepted dependency-floor consequence, not a claim of a fixed binary-size increase; the Go linker remains authoritative for reachable code.

Operating a bundled TURN service is a distinct security and SRE commitment. It must never default to an open relay and must bound authentication lifetime, destination policy, allocations, relay ports, bandwidth, observations, and shutdown. Its unresolved Pion server join question is deliberately outside this accepted implementation program pending a separate prototype; the client architecture does not wait for it because interoperability with standard TURN is part of the product contract.

## Amendment (2026-08, [#1317](https://github.com/GridSwarm/wiremux/issues/1317))

The direct `/2` packet class this decision contrasts against was rebaselined from 1280/1240/1239 to 1232/1192/1191 (initial packet size / lower Datagram ceiling / public ceiling) in preparation for the transport honouring DF. The relay `/3` profile decided here is unchanged at 1200/1160/1159. Reason and derivation: [`docs/COMPATIBILITY.md`](../COMPATIBILITY.md).
