# Datagram-Admission Prototype Decision Plan

**Date:** 2026-08-08
**Status:** Accepted; prototype decision only; no production extraction approved
**Track:** 3 of 5 in the 2026-08-08 architecture deepening program
**Depends on:** nothing — safe to start first
**Related:** ADR-0009; [`2026-07-11-datagram-capability-implementation-plan.md`](2026-07-11-datagram-capability-implementation-plan.md)
**Normative scope:** Current outcome, prototype boundaries, success/rejection criteria, evidence budget, and stop conditions
**Audit history:** Final architecture-review convergence and grilling on 2026-08-08; independent slice audit PASS on 2026-08-08

## Goal

Answer one design question without changing production: can the root and QUIC Datagram send paths share a genuinely narrow admission mechanism that owns slot reservation, copied provisional enqueue, cancellation/lifetime arbitration, commit/discard resolution, and worker dequeue while leaving each caller's lifetime and terminal policy outside it?

## Current Shape (verified 2026-08-08 at `7f574a5a8b7ffff64fa69a10dd57b1b46e3ee78c`)

- Root `Datagrams.Send` at `datagrams.go:110-220` reserves `sendSlots`, copies/framed payload, enqueues a provisional `datagramSendAdmission`, arbitrates call and carrier lifetime cancellation, commits through a resolution channel, and has a race-only commit hook. `pumpSends` consumes the same protocol at `datagrams.go:341-385`.
- QUIC `quicDatagramCarrier.SendDatagram` at `transport/quic/transport.go:612-671` repeats the same structural protocol with `quicDatagramAdmission`, `sendSlots`, copied payload, two contexts, commit resolution, and a race-only hook. Its pump is `transport/quic/transport.go:691-718`.
- The policies around that mechanism differ materially. Root has a separately closable public gate, rechecks after releasing/reacquiring its lock, maps terminal state to `ErrWireClosed`, and permits post-admission loss. QUIC shares carrier lifetime and a native send failure terminates the carrier.
- ADR-0009 requires two distinct bounded queues because root callers and direct `connect.Upgrade` callers independently need cancellable admission. A shared mechanism may be instantiated twice; it must not collapse the queues or their policy layers.
- Existing race sentinels include root `TestDatagramLifetimeCancellationDuringAdmission` and `TestDatagramCallCancellationDuringAdmission`, and QUIC `TestDatagramAdapterLifetimeRaceHasCoherentAdmissionOutcome`, `TestDatagramAdapterParentLifetimeCancellationDuringAdmission`, and `TestDatagramAdapterCallCancellationDuringAdmission`.

## Decision

- Build a throwaway prototype outside the production diff. The narrow conceptual surface may contain only admission, committed dequeue, and close/discard operations with owner and call contexts; names are illustrative, not prescribed.
- The prototype succeeds only if both callers can delete their slots, provisional-admission structs, resolution channels, commit hooks, and worker-side resolution handling while preserving caller-owned error translation and terminal recipes.
- Reject the extraction if the shared surface needs callbacks, caller modes, error translators, carrier termination policy, framing, size policy, Wire knowledge, QUIC knowledge, or more public operations than the mechanism it replaces.
- Do not merge prototype code. Publish one concise result document at `docs/adr/2026-08-08-datagram-admission-prototype-result.md` recording the tested interface shape, deletion accounting, semantic mapping, verdict, and evidence.
- A successful verdict authorizes only a new scoped `$architecture-handoff`; it does not authorize production extraction. A rejected verdict closes the candidate until materially new evidence exists.

**Rejected alternative (do not do this):** Extract the visibly duplicated code directly. The race protocol is similar, but the enclosing lifetime and failure semantics are different enough that an interface can easily become callback-heavy and shallower than the duplication.

**Rejected alternative (do not do this):** Merge the root and lower queues. ADR-0009 intentionally gives independent direct-`connect` and root callers their own bounded cancellable admission.

**Non-goals:** no production Go change; no public interface or ADR-0009 change; no queue collapse; no error/lifetime/terminal-policy unification; no performance claim; no maintained benchmark, fuzz harness, or prototype package.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | new prototype decision | Throwaway two-caller prototype and a committed accept/reject receipt | None | Prototype code removed before PR |

## Implementation Slices

### Slice 1 — Prototype the narrow admission mechanism and record a verdict

**What it delivers:** A docs-only PR containing the result receipt. The local throwaway experiment must exercise both current callers and produce line/field deletion accounting, a semantic mapping, and an accept/reject verdict against the fixed criteria above.

**Existing-work disposition:** New slice; no prior PR, branch, or prototype is a continuation baseline.

**Blocked by:** None.

**Single owner after merge:** Production ownership is unchanged because no production code merges. The result doc owns only the architectural verdict. If later approved, a shared admission module would own queue capacity, copied provisional entries, commit/discard, close, and committed dequeue; callers would retain framing, limits, error mapping, loss policy, and carrier termination.

**Authority completeness:** Not applicable to the docs-only merge. The prototype must nevertheless exercise both constructors/call sites and both worker paths so its verdict is not based on one caller.

**Transitional-seam budget:** Zero in the repository. All prototype code and hooks are removed before the decision PR. No dormant package, build tag, feature flag, or alternate queue remains.

**Blast radius:** The merged slice changes documentation only. The local experiment touches race-sensitive admission code, so it must run only in an isolated branch/worktree and must preserve root/QUIC semantics long enough to evaluate the interface. No public, wire, error, lifecycle, queue-capacity, or performance change is accepted.

**Artifact classification:** Throwaway prototype = verification aid with no maintenance or merge lifetime. Result doc and plan = process/traceability metadata. No shipped behavior or required safety enforcement is delivered by this slice.

**Representation contract:** Supported domain = the two current send-admission implementations at the recorded implementation head and the behaviorally distinct cases of available capacity, blocked capacity, copied payload, call cancellation before commit, owner lifetime ending before commit, successful commit/dequeue, explicit close/discard, and worker observation after resolution. Representation owner = the prototype's one admission object. Guarantee = example-level design evidence only. Terminating evidence = both callers compile against one candidate shape, focused race sentinels pass locally, deletion accounting is complete, and the fixed interface-width verdict is recorded.

**Contract closure:** Not triggered. No shipped behavior or required safety enforcement changes. The prototype is deliberately bounded example-level evidence and must not claim exhaustive concurrency proof.

**Evidence budget:** One prototype design and both caller integrations. Map the supported example-level domain as follows: available capacity, copy, commit, dequeue, and worker observation use root `TestDatagramsSendFramesCopiesAndKeepsLocalErrorsNonTerminal` plus QUIC `TestDatagramAdapterCopiesPayloadOnAdmission`; blocked capacity uses root `TestDatagramsBlockedAdmissionIsCancellableAndCloseDiscardsQueuedSend` plus QUIC `TestDatagramAdapterSendAdmissionUnblocksOnCallAndLifetimeCancellation` and `TestDatagramAdapterCanceledWaiterCannotCrossReleasedAdmissionSlot`; call cancellation uses root `TestDatagramCallCancellationDuringAdmission` plus QUIC `TestDatagramAdapterCallCancellationDuringAdmission`; owner-lifetime cancellation uses root `TestDatagramLifetimeCancellationDuringAdmission` plus QUIC `TestDatagramAdapterLifetimeRaceHasCoherentAdmissionOutcome` and `TestDatagramAdapterParentLifetimeCancellationDuringAdmission`; close/discard uses the root blocked-admission test plus QUIC `TestDatagramAdapterDiscardsQueuedPayloadsAfterLifetimeTermination`. Add only a bounded prototype observation if one of those tests cannot exercise the candidate object. Include a static before/after census of slots, provisional entries, resolution handling, and commit hooks. No new stress profile, platform matrix, benchmark, fuzzing, or second prototype design. Review budget = one initial review plus at most one fully briefed replacement review. Terminate with an accept/reject result after every retained domain case has one evidence pointer for each applicable caller; uncertainty is a reject unless a single concrete missing observation can be obtained inside the same context.

**TDD and preservation evidence:** Use existing root and QUIC admission race tests as the prototype oracle; add no maintained test unless the result reveals a pre-existing production defect, which is outside this slice and must be separately filed. Restore the production tree before creating the docs-only PR.

**Dispatch context budget:** This plan; ADR-0009's two-queue and lifetime rules; `datagrams.go`, `datagrams_test.go`, `transport/quic/transport.go`, and the focused QUIC Datagram tests. One isolated experiment plus one short receipt fits one fresh context.

**Slice decision audit:** Splitting root and QUIC experiments would fail the design question, which is shared narrowness. Merging production extraction would pre-authorize an unknown representation. No cross-track blocker is necessary.

**Stop conditions:** Stop and record rejection if the interface requires callbacks, caller modes, error translation, terminal recipes, framing/size policy, queue collapse, more than one shared owner, or retained prototype code. Stop for operator decision if the experiment discovers a production defect rather than an extraction question.

## Acceptance Criteria

- [ ] The result doc records the exact implementation head, candidate interface, both-caller mapping, deletion accounting, focused evidence, and accept/reject verdict.
- [ ] The prototype covers both current admission implementations and the finite example-level cases named in the representation contract.
- [ ] No prototype or production Go change remains in the committed PR.
- [ ] Acceptance requires removal potential for both slot fields, both provisional structs/resolution paths, both commit hooks, and both worker resolution paths without callbacks or caller modes.
- [ ] A successful verdict points to a new architecture handoff; it does not claim authorization to implement.

## Validation Gates

During the isolated prototype, run focused root and QUIC Datagram admission tests and their existing race gates after the required Go toolchain audit. For the committed docs-only PR, run the repository documentation checks and confirm `git diff --name-only` contains only the result document (plus any required pointer update explicitly approved by the plan).

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md). The implementer must leave no prototype code behind and must not convert a favorable experiment into production work.
