# Static selected-option validation Implementation Plan

**Date:** 2026-09-24
**Status:** Complete; E1 implemented
**Track:** E of seven in program AH-20260924
**Depends on:** Nothing — independent frontier
**Program:** [2026-09-24-architecture-deepening-program.md](2026-09-24-architecture-deepening-program.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers and stop conditions
**Audit history:** [2026-09-24-architecture-handoff-audit.md](2026-09-24-architecture-handoff-audit.md)
**Parent issue:** pending

## Goal

Static selected-option validation: deepen the existing module at its private interface, concentrating the caller knowledge identified below. The scope is one independently green PR, not a framework or public-interface redesign.

## Current Shape (verified 2026-09-24)

[ordered.go:38](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/ordered.go#L38) · [upgrade_plan.go:493](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/upgrade_plan.go#L493) · [options.go:332](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/options.go#L332)

**Governing source surface:** upgrade_plan.go selected validation block, ordered.go option validation, focused options/plan/ordered tests. No socket, native selection, context callback or QUIC recognition rewrite.

## Decision

### What exactly changes?

Extract the selected-options block into `upgradePlan.validateSelectedOptions()`. Ordinary conflict validation calls it when selectionSet really is true. DialOrdered invokes it directly for its future selected posture; no temporary flag mutation.

### What effects may the validator have?

None. No OS observation, network operation, socket, lease or selected-lifetime creation. The plan still distinguishes configuration, selection and prepared resources.

### What error ordering must survive?

Keep ordinary newDialConfig checks first, then ordered selected-posture checks before endpoint/authenticator effects. Preserve current joined ErrOptionConflict/ErrUnsupported and the diagnostic interface name, including empty name for the hypothetical posture.

### Should it also unify built-in QUIC recognition?

No. The two exact type switches have different nil/type diagnostics. That is separate small maintenance and is not required by this change.

### Settled decisions and non-goals

The [no-code decisions](2026-09-24-architecture-no-code-decisions.md) close adjacent directions; they are not successor slices. Preserve the existing [ADR-0010 auth-release](adr-0010-auth-context-lifecycle-ownership.md), [ADR-0011 transport disposal](adr-0011-transport-stream-disposal-capability.md), [settlement D7](2026-07-29-establishment-settlement-plan.md), [selected-I/O ownership](2026-09-22-selected-io-plan.md) and [managed-migration contract](../MANAGED-MIGRATION.md) where touched. Broader deferred upgrade directions remain governed by the [August 26 program](2026-08-26-architecture-deepening-program.md). No new domain terms are introduced: this uses the existing Wire, MigrationSession, establishment settlement, ordered choice and reply concepts. Do not expand the scope to improve neighboring behavior, uniformize intentional error projections, or create new public interfaces. Keep current successful behavior except the explicitly accepted version>=2 custody retention improvement in track B.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| E1 | Complete | Static selected-option validation | None | None introduced; completes its own interface migration |

## Implementation Slices

### Slice E1 — selected-option-validation

**What it delivers:** Static selected-option validation through the real owner and relevant callers, with the acceptance criteria below; one intended PR.

**Existing-work disposition:** New slice. No open implementation PR for this contract was found. Retain existing merged behavior; no unmerged branch is an established dependency. [Audit history](2026-09-24-architecture-handoff-audit.md) records the checked open work and adjacent issues. Recheck related PRs at execution preflight; audit any new overlapping work rather than adopting it silently.

**Blocked by:** None. Recommended sequencing is not a blocking edge.

**Single owner after merge:** upgradePlan owns the static selected-option conflict query; callers decide when real or prospective selection requires the query. Resource preparation and live handle eligibility keep their owners.

**Authority completeness:** No newly authoritative persisted fact or schema. Existing constructors, validation and affected destructive consumers are within the scoped source surface; restart round-trip is not applicable. If implementation adds persisted authority or a new constructor family, stop and re-audit before proceeding.

**Transitional-seam budget:** None introduced. Migrate the listed callers in this PR and remove obsolete caller-owned recipes. Existing representations with distinct authority remain intentional, not temporary duplicate owners. There is no unmerged removal slice or widened seam.

**Blast radius:** upgrade_plan.go selected validation block, ordered.go option validation, focused options/plan/ordered tests. No socket, native selection, context callback or QUIC recognition rewrite. Trace touched shared state and ordering through the named owner and preservation tests. Public APIs, wire/JSON schemas, dependencies, native routing, security/auth authority and performance guarantees remain unchanged. No benchmark or optimization claim. No intended runtime behavior change. No known untraced effect is accepted; discovering one requires scoped re-audit or an approach stop.

**Artifact classification:** Runtime changes are shipped behavior; lifecycle/validity guards are required safety enforcement. Focused tests and existing test adapters are verification aids, not separately approved maintained verification products. This plan, review receipts, issues and task mirrors are process/traceability metadata. No new analyzer, harness, CI lane or maintained-aid exception.

**Representation contract:** Existing typed dial options and built-in transport values accepted by newDialConfig, with actual or prospective selection posture. The existing option constructors and private plan validator own representation. Canonical-subset guarantee for supported options and their current conflict diagnostics; no OS-interface eligibility guarantee.

**Contract closure:** Not triggered: the changed rule is pure, its supported cases are directly covered by the small focused table, and no unmodeled multi-path lifecycle is being moved. Multiple callers alone do not trigger closure.

**Evidence budget:** At most 4 new representative semantic cases plus the named existing regressions and mandatory repository gate. Count table subcases as cases. One normal and one focused race invocation on a successful final candidate; reruns only after diagnosed failure or relevant code changes. Zero required guard mutations; at most one central guard-bypass experiment if needed to show inherited coverage exercises its owner, with no syntax-variant campaign. No new operational/platform/repetition scope. One fully briefed fresh review, at most one replacement after accepted fixes; verification remains scoped to accepted findings. Terminate after this evidence passes with no unresolved stop-for-decision. This budget does not limit existing repository-required gates; it prevents optional evidence inflation.

**TDD and preservation evidence:** First characterize ordered validation with at most four cases: supported selected configuration, incompatible selected option, precedence when ordinary and selected conflicts coexist, and no endpoint/authenticator effects on rejection. Preserve TestDialOrderedInvalidContractHasOneAggregate and TestDialOrderedInvalidSTUNRemainsPreflight plus existing upgrade-plan conflict tests. The characterization may already pass; the architectural assertion is removal of temporary selectionSet mutation.

**Dispatch context budget:** Target at most 16,000 input tokens: this current plan and exact slice; current governing invariants from relevant ADR sections; the scoped source functions and named test bodies; current repository review/CI overlays and shared baselines; relevant unresolved findings only. No entire prior report history, duplicate historical plans or full engine dumps. No governing diff is needed for a new slice; later amendments supply a bounded current-contract diff. One owner-level change and this finite test surface must leave room for implementation, local fixes and verification in one fresh agent context. If the required context exceeds this bound or the change no longer fits one PR, re-audit before editing.

**Slice decision audit:** A pure query plus its actual and prospective callers is already the smallest vertical change. Merging the adjacent ordered classifier would combine independent semantics. No blockers are required merely because both touch ordered.go. The strongest adjacent merge case is shared files or convenient scheduling, which is insufficient: adjacent tracks can each deliver a coherent result independently. No blocker is needed for convenience. A later real dependency must be demonstrated and re-audited.

**Stop conditions:** Stop for representation/ownership change, new public authority or schema, changed protocol/timing/error policy outside this contract, inability to preserve the named outcomes, untraced shared-state effects, evidence needs beyond this budget, or a one-PR/context boundary failure. Apply the shared precise-root/representation stops to review and verification; do not expand the latest checklist. Same-child re-audit is allowed only within the accepted representation, outcome and one-PR boundary; otherwise return for decision or scoped architecture-handoff.

## Acceptance Criteria

- [x] DialOrdered validates prospective selected options without temporarily setting/resetting selectionSet.
- [x] Ordinary validation invokes the same private query only for actual selection; precedence, joined sentinels and diagnostic interface names remain unchanged.
- [x] The query has no OS, socket, lease, observer or authenticator effects.

The representation contract above scopes quantifiers such as “one,” “unchanged,” and “once” to the named supported constructors, consumers and semantic classes; finite named tests and source-owner inspection terminate acceptance. No exhaustive schedule or external-language proof is claimed.

## Validation Gates

Before any Go build/test command, perform the installed/base Go audit in AGENTS.md and stop below the approved floor. Write the named characterization/regression cases first. Run `go test -count=1 .` and a focused race invocation through `./scripts/run-go-test-require-match.sh -race -run '^(TestDialOrdered|TestUpgradePlan|Test.*OptionConflict|TestSelectedOptions)' -count=1 .` with `GOMAXPROCS=1 GOTOOLCHAIN=local`. Then run `task verify` for the exact final pushed head; retain head/base and results. Existing repository gates are not replaced by these focused cases. No added native-platform matrix, repetitions, fuzzing or hosted experiment. Required CI must report success (not skipped) on that same head before squash merge.

## Operating Discipline

Follow the shared `_shared/REVIEW-LOOP.md` and `_shared/CONTRACT-CLOSURE.md` baselines supplied by `$implement-architecture-slice` (reachable as `../_shared/` from its skill directory), composed with the repository [review overlay](../REVIEW-LOOP.md), [CI policy](../CI.md), [conventions](../CONVENTIONS.md), and root [AGENTS.md](../../AGENTS.md). No repository contract-closure overlay exists; use the shared baseline directly. The baselines govern artifact/representation gates, finite evidence, semantic-family closure, review and verification-aware approach stops, exact-head local certification, same-head hosted CI, merge, journal and pointer-only tracking. Do not copy or strengthen them in this plan.

After exact-head certification and same-head CI, merge, run `$append-dev-journal`, reconcile the parent/tracker frontier and complete only this slice’s OmniFocus task. Parent and OmniFocus notes carry state and pointers, not substantive contracts or certification SHAs. Dispatch is an operator action; this handoff does not launch implementation.
