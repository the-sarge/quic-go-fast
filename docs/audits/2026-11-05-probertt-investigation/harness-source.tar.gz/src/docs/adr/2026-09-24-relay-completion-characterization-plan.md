# Relay completion characterization Implementation Plan

**Date:** 2026-09-24
**Status:** Complete; early completion demonstrated, repair requires a new scoped handoff
**Track:** R of seven in program AH-20260924
**Depends on:** Nothing — independent frontier
**Program:** [2026-09-24-architecture-deepening-program.md](2026-09-24-architecture-deepening-program.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers and stop conditions
**Audit history:** [2026-09-24-architecture-handoff-audit.md](2026-09-24-architecture-handoff-audit.md)
**Parent issue:** pending

## Goal

Determine whether the existing proxy publishes completion before an owned reader exits. Deliver one evidence-only PR recording the observed behavior and its disposition; do not change a module interface or runtime owner.

## Current Shape (verified 2026-09-24)

[proxy.go:140](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/relay/proxy.go#L140), [proxy.go:181](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/relay/proxy.go#L181), [runtime.go:66](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/relay/runtime.go#L66), [relay_test.go:1444](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/relay/relay_test.go#L1444): writer completion is joined before aggregate close; spawned readers have no explicit completion join. This is static evidence, not a demonstrated persistent leak.

**Governing source surface:** Read relay/proxy.go, runtime.go, idle monitor and shaping completion paths, ADR-0005, and existing proxy tail tests. A temporary test adapter may be used locally; the one intended PR adds a concise result record under docs/research/2026-09-24-relay-completion.md and no production code.

## Decision

### What should the test distinguish?

Use an existing net.Conn test adapter: fail one destination write, allow the opposite direction to deliver its final bytes, and let socket Close promptly unblock the held source read. Hold that read just before it returns using an explicit channel. Observe whether proxy/runtime completion appears before releasing it. Always release it during fixture cleanup. This isolates absent joining from a connection whose Close itself blocks.

### Why not add defer reader.Wait immediately?

Both writers can fail while their readers are blocked. If each writer joins its reader before returning, the aggregate never reaches the socket Close that would unblock those readers. Early close on the first write failure can instead drop the opposite direction’s final bytes.

### Prospective repair constraints; no repair authorized here

Keep the existing proxy owner. Preserve directional draining, then aggregate socket closure, then join owned reader and monitor/timer work before completion publication. Exclude callback self-join. Keep runtime timeout as the existing bounded abandonment mechanism. No new relay-wide lifetime owner or ledger join responsibility.

### Is this an implementation prerequisite for the other six?

No. It is an independent diagnostic with a potentially more urgent result. If it proves a completion-contract defect, prioritize a focused fix before further cosmetic refactors. If it does not, document the observed completion guarantee and stop; do not force a new abstraction.

### Repair is outside this slice

Do not add a join inside copyWithActivity: writers may wait for readers that only the aggregate later Close can unblock. A future repair must preserve opposite-direction tail delivery and, if warranted, join after aggregate socket closure without callback self-join. The existing runtime timeout remains bounded abandonment. Publish the result and request scoped handoff for repair; no implementation agent is launched by this packaging run.

### Settled decisions and non-goals

The [no-code decisions](2026-09-24-architecture-no-code-decisions.md) close adjacent directions; they are not successor slices. Preserve the existing [ADR-0010 auth-release](adr-0010-auth-context-lifecycle-ownership.md), [ADR-0011 transport disposal](adr-0011-transport-stream-disposal-capability.md), [settlement D7](2026-07-29-establishment-settlement-plan.md), [selected-I/O ownership](2026-09-22-selected-io-plan.md) and [managed-migration contract](../MANAGED-MIGRATION.md) where touched. Broader deferred upgrade directions remain governed by the [August 26 program](2026-08-26-architecture-deepening-program.md). No new domain terms are introduced: this uses the existing Wire, MigrationSession, establishment settlement, ordered choice and reply concepts. Do not expand the scope to improve neighboring behavior, uniformize intentional error projections, or create new public interfaces. Keep current successful behavior except the explicitly accepted version>=2 custody retention improvement in track B.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| R1 | Complete | [Relay completion result](../research/2026-09-24-relay-completion.md); repair requires a new scoped handoff | None | None introduced; observation only |

## Implementation Slices

### Slice R1 — relay-completion-characterization

**What it delivers:** A bounded observation at the real proxy completion seam and a committed result/disposition document; one evidence-only PR.

**Existing-work disposition:** New slice. No open implementation PR for this contract was found. Retain existing merged behavior; no unmerged branch is an established dependency. [Audit history](2026-09-24-architecture-handoff-audit.md) records the checked open work and adjacent issues. Recheck related PRs at execution preflight; audit any new overlapping work rather than adopting it silently.

**Blocked by:** None. Recommended sequencing is not a blocking edge.

**Single owner after merge:** Existing proxy aggregate owns its completion callback/runtime slot; this slice observes it and publishes a disposition, without changing runtime authority.

**Authority completeness:** No newly authoritative persisted fact or schema. Existing constructors, validation and affected destructive consumers are within the scoped source surface; restart round-trip is not applicable. If implementation adds persisted authority or a new constructor family, stop and re-audit before proceeding.

**Transitional-seam budget:** None introduced. Runtime callers and representations remain unchanged. The temporary diagnostic adapter is removed before committing the evidence report; no unmerged removal slice or new authority is created.

**Blast radius:** Read relay/proxy.go, runtime.go, idle monitor and shaping completion paths, ADR-0005, and existing proxy tail tests. A temporary test adapter may be used locally; the one intended PR adds a concise result record under docs/research/2026-09-24-relay-completion.md and no production code. Trace touched shared state and ordering through the named owner and preservation tests. Public APIs, wire/JSON schemas, dependencies, native routing, security/auth authority and performance guarantees remain unchanged. No benchmark or optimization claim. No intended runtime behavior change. No production code is changed. No known untraced effect is accepted; discovering one requires scoped re-audit or an approach stop.

**Artifact classification:** Temporary test/adapter is a disposable verification aid, not a maintained deliverable or product gate; remove it before the evidence-only PR. The report’s embedded diagnostic patch/source is disposable historical verification evidence, not a maintained fixture. Result report, plan, receipts and mirrors are process/traceability metadata. The shipped proxy is read-only. No approved maintained-aid exception; a prospective repair is outside this slice.

**Representation contract:** Existing net.Conn proxy seam with prompt Close and explicitly controlled read-return completion. The standard net.Conn contract and test adapter own representation. Example-level deterministic evidence only; no claim about every scheduler, custom connection, persistent production leak, or shutdown timing bound.

**Contract closure:** Not triggered: this slice observes existing behavior through a bounded disposable verification aid and changes no product invariant. Do not recursively apply closure to the diagnostic fixture.

**Evidence budget:** At most 2 new representative semantic cases plus the named existing regressions and mandatory repository gate. Count table subcases as cases. One normal and one focused race invocation on a successful final candidate; reruns only after diagnosed failure or relevant code changes. Zero required guard mutations; at most one central guard-bypass experiment if needed to show inherited coverage exercises its owner, with no syntax-variant campaign. No new operational/platform/repetition scope. One fully briefed fresh review, at most one replacement after accepted fixes; verification remains scoped to accepted findings. Terminate after this evidence passes with no unresolved stop-for-decision. This budget does not limit existing repository-required gates; it prevents optional evidence inflation.

**TDD and preservation evidence:** Use one temporary deterministic TestHandoffRelayCompletion characterization in the agent’s dedicated worktree, with baseline normal completion and held reader after prompt Close (two cases). Fail one destination write, preserve opposite-direction tail, wait for both writer paths and socket closure, then observe completion while the reader return remains explicitly gated. Cleanup always releases the gate. Preserve TestProxyWriteFailureDrainsOppositeDirection and existing shaped-tail tests. No sleeps for ordering; watchdogs prevent fixture hangs. Do not commit the diagnostic helper as a maintained CI gate.

**Dispatch context budget:** Target at most 22,000 input tokens: this current plan and exact slice; current governing invariants from relevant ADR sections; the scoped source functions and named test bodies; current repository review/CI overlays and shared baselines; relevant unresolved findings only. No entire prior report history, duplicate historical plans or full engine dumps. No governing diff is needed for a new slice; later amendments supply a bounded current-contract diff. One evidence report and this finite diagnostic surface must leave room for implementation, local fixes and verification in one fresh agent context. If the required context exceeds this bound or the change no longer fits one PR, re-audit before editing.

**Slice decision audit:** Characterization and disposition form one independently green evidence PR. A speculative repair slice cannot be audited before the result; it is deliberately absent, not a blocked ready-made child. Merging repair now would violate the accepted conditional decision. The strongest adjacent merge case is shared files or convenient scheduling, which is insufficient: adjacent tracks can each deliver a coherent result independently. No blocker is needed for convenience. A later real dependency must be demonstrated and re-audited.

**Stop conditions:** Stop for representation/ownership change, new public authority or schema, changed protocol/timing/error policy outside this contract, inability to preserve the named outcomes, untraced shared-state effects, evidence needs beyond this budget, or a one-PR/context boundary failure. Apply the shared precise-root/representation stops to review and verification; do not expand the latest checklist. Same-child re-audit is allowed only within the accepted representation, outcome and one-PR boundary; otherwise return for decision or scoped architecture-handoff.

## Acceptance Criteria

- [x] Publish the deterministic result, committed source head, temporary test-state description, commands, completion contract interpretation and limits in docs/research/2026-09-24-relay-completion.md. Include a disposable patch or sufficient fixture source in that report to inspect the held-read, prompt-Close, opposite-tail and unconditional-release gates; do not present an uncommitted diagnostic run as testing a pristine commit.
- [x] Record either no demonstrated defect, or the precise early-completion defect and a bounded proposed repair requiring a new scoped handoff; do not implement the repair in this slice.
- [x] The fixture preserves opposite-direction tail delivery, promptly unblocks I/O on Close, releases its held return during cleanup, and does not become a maintained verification gate.

The representation contract above scopes quantifiers such as “one,” “unchanged,” and “once” to the named supported constructors, consumers and semantic classes; finite named tests and source-owner inspection terminate acceptance. No exhaustive schedule or external-language proof is claimed.

## Validation Gates

After the base-Go audit, run the temporary two-case characterization and existing tail regression once normally and once with `-race -count=1` in `./relay`. Record the committed source head separately from the temporary uncommitted test state, the exact commands, and fixture provenance. Embed a compact disposable unified diff or sufficient fixture source in the evidence Markdown report to inspect the held-read, prompt-Close, opposite-tail and unconditional-release gates; this is historical evidence, not a maintained test. Remove the temporary test, then certify the resulting docs-only PR with `task docs-check`, `task ci`, `task ci-race`, and `task ci-coturn`; the last two take the documented docs route. No production change, stress loop, platform campaign, or timing-bound claim.

## Operating Discipline

Follow the shared `_shared/REVIEW-LOOP.md` and `_shared/CONTRACT-CLOSURE.md` baselines supplied by `$implement-architecture-slice` (reachable as `../_shared/` from its skill directory), composed with the repository [review overlay](../REVIEW-LOOP.md), [CI policy](../CI.md), [conventions](../CONVENTIONS.md), and root [AGENTS.md](../../AGENTS.md). No repository contract-closure overlay exists; use the shared baseline directly. The baselines govern artifact/representation gates, finite evidence, semantic-family closure, review and verification-aware approach stops, exact-head local certification, same-head hosted CI, merge, journal and pointer-only tracking. Do not copy or strengthen them in this plan.

After exact-head certification and same-head CI, merge, run `$append-dev-journal`, reconcile the parent/tracker frontier and complete only this slice’s OmniFocus task. Parent and OmniFocus notes carry state and pointers, not substantive contracts or certification SHAs. Dispatch is an operator action; this handoff does not launch implementation.
