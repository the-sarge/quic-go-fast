# Wire-Dialer Upgrade Plan Implementation Plan

**Date:** 2026-07-05
**Status:** Accepted; implemented by PRs #553 and #558
**Track:** 3 of 4 in the 2026-07-05 third architecture deepening program
**Depends on:** PR #492 merged (edits the same files)
**Related:** ADR-0006 (packet-socket ownership contract frozen)

## Goal

One deep upgrade-plan module in the root package owns option translation,
default packet-socket acquisition, the async default-STUN lookup, and
outcome-keyed cleanup — so the wire dialer's `dialPaired` stops holding
resource-ownership contracts in its control flow, and the duplicated
option mapping is written exactly once.

## Current Shape (verified 2026-07-05; anchors at main@49d8cb3 — expect drift once PR #492 merges)

- `dialConfig.upgradeOptions` (`wiremux.go:355-425`) and
  `dialConfig.validateStaticUpgradeOptions` (`options.go:243-267`) both
  map root config → `connect.UpgradeOption`, and they DIVERGE: the static
  mapping adds a default transport only when a caller packet socket is set
  (`options.go:245-249`), while the live mapping adds the QUIC default
  whenever the dial is not relay-only (`wiremux.go:375-377`). That is a
  latent-divergence bug class, not merely double maintenance.
- `preparedUpgradeOptions` (`wiremux.go:334-353`) secretly carries a
  running goroutine: `pendingDefaultSTUN` (`wiremux.go:468-498`) with a
  cancel/result lifecycle bolted onto `options()`/`cancel()`.
- `cleanupUpgradeAfterUpgradeError` special-cases
  `connect.ErrUpgradeTransportNotConverged` (post-commit: `Upgrade`
  already closed the socket) — `dialPaired` must mirror connect's
  ownership transfer to avoid a double close.
- Package-level mutable test seams: `defaultListenPacket`,
  `defaultSTUNLookupIPAddr` (`wiremux.go:427-430`), swapped via
  `export_test.go`.

## Decision

New unexported `upgradePlan` type in the root `wiremux` package:

- Built once by `newDialConfig` — static validation IS building the plan,
  which deletes `validateStaticUpgradeOptions` and the divergence class.
- `prepare(ctx, endpoint)` acquires the default packet socket and starts
  the default STUN lookup (the plan owns `pendingDefaultSTUN`).
- `options() []connect.UpgradeOption` — the single mapping.
- `cleanup(outcome)` with outcome ∈ {setup-error, relay-fallback,
  direct-success, transport-not-converged}. The
  `ErrUpgradeTransportNotConverged` interpretation moves inside the plan
  (e.g. a `cleanupAfterUpgradeError(err)` helper maps error → outcome);
  `dialPaired` stops referencing the sentinel.
- `listenPacket`/`stunLookup` become plan fields with production defaults
  injected at construction; the two package-level vars are deleted and
  `export_test.go` swaps become constructor injection.

Frozen: `WithPacketConn` ownership semantics across the three outcomes
exactly as documented (`options.go:83-93`); the bare-vs-sentinel error
contract; `ErrOptionConflict` identities and option-conflict error texts.

**Rejected alternative (do not do this):** keeping a separate
static-validation mapping "for cheap preflight". The divergence risk is
the bug class this track exists to delete.

**Rejected alternative (do not do this):** folding `relayDialOptions` or
`WithChannelOptions` handling into the plan. Out of scope — the plan owns
direct-upgrade resources only.

**Non-goals:** no change to `connect.ValidateUpgradeOptions`; no new
public API; consume concerns stay out (Track 4).

## Implementation Slices

**PR 1.** Introduce `upgradePlan` with the single mapping;
`newDialConfig` builds it; delete `validateStaticUpgradeOptions`. TDD:
first pin current behavior with table tests over option combinations —
including the cases where today's two mappings differ — written so that
both current mappings satisfy them for the combinations each actually
handles; the unified mapping must provably match the live
(`upgradeOptions`) path. If a pinned test exposes a real behavioral
difference callers depend on, STOP (see discipline).

**PR 2.** Move socket/STUN acquisition and `cleanup(outcome)` into the
plan; delete the `cleanupUpgrade` closure threading and
`cleanupUpgradeAfterUpgradeError`; replace the package-level function
vars with injected fields. Unit-test `cleanup(outcome)` per outcome with
fake conns. This PR shrinks `dialPaired` and unblocks Track 4's cleaner
insertion.

## Acceptance Criteria

- `validateStaticUpgradeOptions` gone; exactly one root-config →
  `connect.UpgradeOption` mapping exists.
- `grep -rn "defaultListenPacket\|defaultSTUNLookupIPAddr" .` (root package) returns nothing.
- `dialPaired` no longer references `ErrUpgradeTransportNotConverged`.
- Root end-to-end dial tests pass unchanged.

## Validation Gates

```bash
GOTOOLCHAIN=local go test .
GOTOOLCHAIN=local go test ./...
task verify
```

## Operating Discipline

Follow `docs/REVIEW-LOOP.md` for every PR. STOP condition: if unifying
the two mappings surfaces a real behavioral difference that existing
callers depend on, stop and surface it to the operator — that is a
possible latent bug to adjudicate, not a decision to make silently.
