# ADR-0001: wiremux Vision and Scope

## Status

Accepted.

## Context

The GridSwarm family ADR (`org-docs:adr-0001-four-product-family.md`)
establishes wiremux as the connectivity primitive that all GridSwarm
identity products (codemux, keymux, eventually meshmux) and external
non-identity consumers (Kubernetes peering, IoT fleets, enterprise-PKI
tools) build on.

wiremux's role is "two parties meet and talk with NAT traversal, relay
fallback, and transport upgrade — identity-pluggable." It is not a
product on its own that end users install; it is a library and server
kit that other products embed.

Two design facts shape this ADR:

1. **Consumer evidence exists, but does not define byte compatibility.**
   codemux exercises the PAKE-derived identity shape, and tapmux has
   carried a downstream relay-to-channel-to-upgrade assembly. Those
   consumers validate wiremux's seams, but wiremux v1 remains designed
   around the canonical connectivity kernel rather than a byte-compatible
   extraction of earlier tapmux internals. Existing tapmux source under
   `internal/relay`, `internal/relayurl`, `internal/holepunch`,
   `internal/natdisco`, `internal/quicutil`, and `internal/control` is
   reference material, alongside iroh's connectivity stack and
   Syncthing's relay protocol. None of it is a normative blueprint.
2. **The auth-context interface uses a key exporter, not transport-
   specific named PSKs.** The seam between identity layers and
   wiremux's transport upgrade is an HKDF-style key exporter rooted in
   the identity layer's master secret. Transport implementations
   derive their own AEAD-sufficient keys via the exporter without the
   identity layer needing to know which transport is in use.
   Transports whose underlying stack cannot accept external keying
   material authenticate via channel-bound handshake material instead
   (see DP8).

This ADR establishes wiremux's vision and the primary decision points
for v1. PRD-0001 specializes the API surface.

## Decision

### DP1: vision-2 scope, identity-agnostic

wiremux v1 covers:

- **Relay rendezvous.** TLS-over-TCP relay server that pairs peers by an opaque
  rendezvous identifier and copies bytes between paired streams. Treats
  payloads as opaque; never learns auth secrets.
- **STUN responder and client.** Minimal STUN implementation for
  reflexive-address discovery. Co-located with the relay binary by
  default; separable in deployment.
- **Hole-punching.** UDP candidate exchange and synchronized probe
  protocol for direct peer connectivity through NATs.
- **Transport upgrade negotiation.** Coordinated upgrade from the
  relay-mediated stream to a direct transport once direct connectivity
  is established.
- **Pluggable transport.** Default transport implementation (QUIC), with
  a transport interface that other transports (DTLS, raw UDP, MASQUE,
  WebRTC data channels) can implement without forking wiremux.
- **Pluggable auth.** Auth-context interface that admits PAKE
  (codemux), Noise IK (keymux), and externally-supplied symmetric or
  AEAD keys (BYO-auth consumers).

wiremux v1 does not cover:

- Identity (ephemeral or persistent). Identity layers are codemux and
  keymux respectively.
- Mesh coordination (many-to-many ACLs, peer directory, mesh routing).
  Reserved for meshmux.
- Application protocol DTOs.

### DP2: pluggable auth interface uses a key exporter

wiremux exposes an `AuthContext` interface that identity layers
implement. The interface produces:

- `SendKey() []byte` — symmetric key for the channel layer's outbound
  traffic from the local peer.
- `ReceiveKey() []byte` — symmetric key for the channel layer's
  inbound traffic from the remote peer.
- `SessionBinding() []byte` — domain-separating session identifier
  mixed into every downstream derivation.
- `Exporter() KeyExporter` — HKDF-style exporter rooted in the
  session's master secret with the session binding mixed in.
  Transport implementations call `Exporter().Derive(label, context, length)`
  to derive their own transport-specific AEAD keys, PSKs, or other
  keying material.

Reference auth schemes that v1 must accommodate without modification:

- PAKE-derived directional keys with ephemeral session ID (codemux's
  case).
- Noise IK with long-lived peer public keys (keymux's case). Noise's
  built-in `CipherState.Export` primitive maps directly onto the
  `KeyExporter` shape.
- Externally-supplied auth contexts (BYO-auth). Consumers provide
  pre-derived keys, session binding, and an exporter (or a static
  passthrough exporter that fails on unknown labels) directly.

**Rationale for the exporter pattern.** An earlier draft of this ADR
proposed `TransportPSK(transport string) ([]byte, bool)` instead of
`Exporter()`. Code review surfaced that the named-method shape forces
every identity layer to know "what does QUIC need? what shape? what
length?" for every transport that's ever added. The exporter pattern
puts AEAD-sizing concerns in `wiremux/transport/<X>` where they
belong, and keeps identity layers transport-agnostic. This is the
canonical shape used by TLS 1.3 (`ExportKeyingMaterial`) and Noise.

**Not every transport consumes the exporter for handshake keying.**
The exporter is the seam for transports that can accept raw keying
material (DTLS-PSK, raw-UDP AEAD transports). The default QUIC
transport cannot: Go's `crypto/tls` has no external-PSK API (see DP8).
The interface is unaffected either way — identity layers implement the
same four methods regardless of which transports are in play.

The exact interface shape is owned by PRD-0001.

### DP3: dual-mode rendezvous

wiremux's relay protocol supports two rendezvous modes:

- **Ephemeral.** 16-byte session identifier, default expiry 15 minutes
  with configurable maximum of 1 hour, and single-use consumption semantics.
  This decision originally used consume-on-upgrade-success shorthand; PRD-0001
  owns the current precise consume contract. This mode satisfies codemux's
  muxcode rendezvous and the swarmcast bootstrap requirements (cross-repo:
  `swarmcast:adr-0016` D3).
- **Long-lived.** Persistent peer identifier (typically a hash of a long-lived public key) under which a peer registers and remains reachable until disconnect, explicit deregistration, or the server's idle timeout or absolute registration lease expires. Registration admission uses global and source-bucket budgets; lease expiry requires a fresh `Listen` under current quotas. A registration can accept multiple pairings, and paired streams survive registration expiry. This mode satisfies keymux's persistent-peer rendezvous; PRD-0001 owns the current precise lifetime contract.

Post-decision note (PR #492): PRD-0001 is the current living contract for
ephemeral `SessionID` consumption behavior. The root `wiremux.Dial` contract
now consumes after successful local upgrade or paired terminal identity failure;
context cancellation, deadline identity failures, and purely retryable relay I/O
closure during identity leave the `SessionID` retryable.

The two modes share underlying byte-forwarding, pair-timeout, and rate-
limiting machinery. The relay must not require a v1 deployment to
support both modes (`--no-longlived` and `--no-ephemeral` flags allow
operators to enable only one).

Guess-limiting is keyed by rendezvous identifier in both modes, not by
source IP, to avoid NAT-wide collateral damage and to make online
guessing of a *specific* identifier expensive.

Per-identifier limiting alone does not protect the relay itself: an
attacker presenting a stream of fresh random identifiers never trips a
per-identifier limit, yet each unknown identifier creates waiting
state that lives until pair-timeout. The relay therefore also enforces
coarse resource protection, distinct from guess-limiting:

- a bounded total budget for unpaired waiting entries, beyond which
  new rendezvous attempts are rejected cheaply;
- per-source network-bucket and global connection-rate caps as a flood backstop
  (coarse abuse control, not per-identifier guess accounting);
- bounded pair-timeouts in both modes.

"Not keyed by source IP" constrains how guessing of an identifier is
accounted; it does not preclude coarse per-source flood controls.
Per-source bucket caps are a relay-survival backstop, not a
guess-limiting mechanism, and must be sized for shared egress
populations: CGNAT, proxies, and IPv6 prefixes can place many
legitimate clients behind one bucket, so caps sized for single
households would recreate the NAT-wide collateral damage this DP
avoids.

### DP4: STUN co-location with relay

The default deployment binary serves both relay and STUN from a single
process. Operators may disable either subsystem via flag
(`--no-stun`, `--no-relay`) to deploy them independently.

Rationale: STUN is small (sub-thousand lines, well-understood
protocol). Bundling it with the relay binary reduces operator burden
for the common case (one VPC, one TLS cert, one observability
pipeline) without precluding split deployments for operators who
prefer them.

### DP5: relay endpoint scheme — `wiremux://host:port`, TLS always, pin in client config

Options considered:

- (a) `wiremux://<fingerprint>@host:port` — fingerprint embedded in
  URL. Self-contained; URL is ugly and tied to the cert.
- (b) Two schemes: `wiremux://host:port` for plain TCP,
  `wiremuxs://<fingerprint>@host:port` for pinned TLS.
- (c) `wiremux://host:port` only; TLS always required; pinning lives
  in client config out of band.

Choice: **(c)**. The relay protocol always uses TLS. The URL contains
no fingerprint. Cert verification follows two paths:

- **Public relays:** Web PKI. Operator provisions a CA-signed cert
  (Let's Encrypt is the obvious default). Clients verify the cert
  chain against the system CA store. No pinning, no client-side
  config beyond the URL.
- **Private relays:** self-signed cert plus out-of-band pinning. The
  operator distributes the cert's SHA-256 fingerprint via client
  configuration:

  ```yaml
  wiremux:
    relays:
      - url: wiremux://relay.lan.local:8443
        pin: sha256:5e2f8a1b9c4d3e7f6a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f
  ```

  The wiremux client library applies the pin only when present;
  unpinned configs use Web PKI verification.

Rationale:

- Plain TCP on a public relay is a security footgun; requiring TLS
  always closes that hole at the protocol level.
- Embedding a 64-hex-char fingerprint in the URL is bad UX, and the
  fingerprint can't be made shorter without losing cryptographic
  strength (4-word codes have ~50 bits of entropy and cannot resist
  offline preimage attack — they work as PAKE secrets only because
  PAKE adds rate-limit + expiry).
- Separating "where is the relay" (URL, changes occasionally) from
  "how is its cert verified" (config, changes per deployment model)
  means cert rotation and key rotation are server-side-only concerns
  under the public-relay path.
- Multiple relays are supported by listing multiple URLs in client
  config. Federation between relays (peers on different relays
  discovering each other) is out of v1 scope; reserved for meshmux.
- The aliases `tapmuxs://` and `codemuxs://` from earlier drafts are
  dropped. Existing and planned consumers use wiremux through the
  canonical `wiremux://` endpoint scheme.

Consequences:

- `wiremux/relayurl` accepts only `wiremux://host:port` and rejects
  the URL forms with embedded fingerprints. The package does not
  accept bare `host:port` either; the scheme is always required so
  parsing failures surface as errors rather than ambiguous fallbacks.
- `relayurl` parses pin material from a separate input (not from the
  URL string). The exact config-format mechanics are PRD-0001
  territory.
- Operators running public relays use Let's Encrypt or any CA-signed
  cert; ACME automation handles cert renewal transparently.
- Operators running private relays distribute a fingerprint via
  config; the fingerprint binds to the cert's public key, so cert
  rotation requires distributing a new fingerprint (no different
  from the URL-embedded model, but cleaner because URL stays stable).

### DP6: language and toolchain

Choice: Go. wiremux v1 is implemented in Go.

Rationale: matches likely consumers (tapmux, swarmcast, file-sync
tool); Go's standard library provides production-grade `crypto/rand`,
`crypto/tls`, `net`, and `net/http` implementations adequate for the
v1 surface; `quic-go` provides a production-ready QUIC implementation
for the default transport.

Future polyglot bindings (Rust, TypeScript, Python) are out of v1
scope and require a separate ADR.

### DP7: deployable kit

wiremux v1 ships:

- A Go library (multiple packages, see PRD-0001).
- A relay+STUN server binary (`cmd/wiremux-server`) deployable on a
  VPC or any host with public ingress.
- TLS configuration helpers (ACME for public certs, self-signed-with-
  pin helpers for private deployments) sufficient for operators to
  stand up a relay without touching application code.

The server binary is identity-agnostic: it serves codemux/muxcode-
style ephemeral sessions and keymux/muxkey-style long-lived peers
simultaneously. Operators do not need separate deployments per
identity layer.

### DP8: QUIC handshake authentication — channel-bound certificate pinning

The default QUIC transport cannot consume exporter-derived keying
material as a TLS pre-shared key. Go's `crypto/tls` supports TLS 1.3
PSKs only for session resumption; it has no API for external
out-of-band PSKs, and `quic-go` (which rides on `crypto/tls`'s QUIC
support) inherits that limit. The earlier draft's plan — derive a PSK
via `Exporter().Derive("wiremux v1 quic-psk", nil, 32)` and feed it to
the QUIC handshake — is not implementable on the chosen toolchain.

Options considered:

- (a) **External TLS 1.3 PSK.** Not available in `crypto/tls`; would
  require a forked TLS stack. Rejected.
- (b) **Simulated PSK via ticket resumption.** Mint a session ticket
  on a prior dummy connection and resume it. Rejected: the direct
  connection is the *first* connection between the peers, so there is
  nothing to resume; tickets minted over a stream-TLS session are not
  transferable to QUIC; and authentication silently degrades to none
  if the stack falls back to a full handshake.
- (c) **Post-handshake application-layer token.** Perform an
  unauthenticated handshake, then authenticate inside the first
  stream. Rejected as the primary mechanism: without binding the
  token to the TLS session it is relayable by a man-in-the-middle,
  and done correctly (a MAC over `ExportKeyingMaterial` output) it
  still costs an extra round trip plus an unauthenticated-connection
  window that all application traffic must be gated behind.
- (d) **Channel-bound certificate pinning.** Each peer generates an
  ephemeral self-signed certificate per upgrade session. Certificate
  fingerprints are exchanged during candidate exchange, which already
  runs over the identity-layer-authenticated channel. The direct QUIC
  handshake pins both certificates: verification runs in
  `VerifyConnection` (which Go invokes on every connection, including
  TLS resumptions — `VerifyPeerCertificate` is documented as skipped
  on resumed connections), with `RequireAnyClientCert` on the
  listening side; session tickets and client session caches are
  disabled for per-upgrade sessions, so resumption cannot bypass the
  pin. Authentication fails closed during the handshake.

Choice: **(d)**.

Rationale: wiremux's upgrade always happens in the presence of an
already-authenticated channel — the negotiator is constructed with
one, and candidate exchange is defined to run over it. The trust
chain is exactly right: the identity layer authenticated the channel;
the fingerprints rode the channel; the TLS handshake proves
possession of the pinned keys. Unlike (c) there is no post-handshake
confirmation round trip and no unauthenticated window; unlike (a)/(b)
every hook involved is standard `crypto/tls` API. The shape is the
one used by libp2p and iroh, simplified: those systems must embed
identity in the certificate because no prior channel exists at first
contact, while wiremux always has one — so the transport stays
identity-agnostic, and nothing about key formats or identity schemes
leaks into it.

Consequences:

- Candidate exchange carries transport handshake material (for QUIC,
  certificate fingerprints) in addition to address candidates. This
  material travels only over the authenticated channel; the relay
  never sees it.
- Hole-punching can produce simultaneous open, and a QUIC connection
  needs exactly one client and one server. The negotiator
  deterministically assigns dialer/listener roles during candidate
  exchange.
- The exporter remains the seam for transports that can consume raw
  keying material. QUIC v1 does not consume the exporter for
  handshake authentication.
- The label `"wiremux v1 quic-psk"` is retired before ever shipping.
  The label `"wiremux v1 quic-confirm"` is reserved for an optional
  post-handshake confirmation (a MAC over the TLS exporter value,
  mixed via the identity-layer exporter) as future defense-in-depth;
  it is not in v1 scope.

### DP9: long-lived registration requires proof of PeerID possession

Long-lived rendezvous (DP3) lets a peer register under a persistent
identifier and stay reachable. Registration that requires nothing but
the identifier is squattable: anyone who learns a victim's PeerID can
register it first (or keep re-registering it) and make the victim
unreachable. Confidentiality is unaffected — a squatter cannot pass
the identity layer's handshake — but targeted unreachability is a
real denial of service, and both reference designs authenticate
registration (Syncthing relays verify device certificates; iroh
clients prove their node key to the relay).

There is a tension with wiremux's identity-agnostic stance: the relay
must not learn auth secrets or bake in an identity layer's
assumptions. The resolution is that *public keys are not secrets*:

- The relay supports a pluggable registration-proof scheme, selected
  by operator configuration.
- The v1 default scheme is `ed25519-keyhash`: the PeerID must be the
  SHA-256 hash of an Ed25519 public key; at registration the relay
  issues a 32-byte random challenge, and the registrant returns the
  public key plus a signature over the domain-separated transcript
  `"wiremux v1 longlived-reg" || 0x00 || lp(scheme) || lp(PeerID) ||
  lp(challenge) || lp(tls-exporter-binding)`, where `lp(x)` is
  `u16be(len(x)) || x` — length-prefixed fields, so no alternate
  field split produces the same bytes. The binding is the 32-byte
  output of the registrant↔relay TLS connection's exporter,
  `ExportKeyingMaterial("EXPORTER-wiremux-v1-longlived-reg", nil, 32)`
  (RFC 9266 style); registration requires TLS 1.3 and fails closed
  if the exporter errors. The relay verifies the signature, that the
  key hashes to the claimed PeerID, and that the binding matches
  this connection. This matches keymux's planned PeerID derivation.
- The structured, channel-bound transcript — never a bare
  challenge — prevents two attacks: the relay acting as a signing
  oracle over attacker-chosen bytes for a long-lived key, and a
  malicious relay forwarding an honest relay's challenge to the
  victim and replaying the signature there (cross-relay proof
  forwarding), which would re-create exactly the squatting DoS this
  DP exists to prevent. A proof transcript is not verifiable on any
  other TLS connection.
- Operators may disable proof (`--longlived-proof=none`) for closed
  deployments. The squatting risk of doing so is documented at the
  flag.
- Ephemeral mode requires no registration proof: session IDs are
  high-entropy, single-use, secret-derived values; squatting one
  means already knowing the secret.

The relay learns a public key and a signature — no auth secrets, no
identity-layer protocol details. BYO consumers whose PeerIDs are not
key hashes either run proof-disabled relays or implement their own
proof scheme against the pluggable interface (PRD-0001 owns the
interface shape).

## Consequences

- wiremux v1 is the dependency floor for codemux v1, keymux v1 (when
  it lands), and any non-identity consumer.
- The relay server binary becomes the canonical GridSwarm-deployable
  service. Operators run one binary per VPC for the entire family
  unless they explicitly want split deployments.
- The auth-context interface (with the exporter) is the most load-
  bearing surface in wiremux. Getting it wrong forces every identity
  layer to monkey-patch it. PRD-0001 specifies it precisely; future
  ADRs may evolve it only with care.
- Direct UDP/QUIC upgrade is in scope.
- Relay endpoints use `wiremux://host:port` with no fingerprint.
  Public relays use Web PKI; private relays use out-of-band pinning
  via client config.
- HKDF labels for transport keys are wiremux-branded
  (`wiremux v1 <transport>-<purpose>`) and become permanent compat
  artifacts once shipped. The default QUIC transport does not consume
  an exporter-derived PSK (DP8); `wiremux v1 quic-psk` is retired
  unshipped and `wiremux v1 quic-confirm` is reserved. Channel-key
  labels (`wiremux v1 host->client` and `wiremux v1 client->host`)
  are produced by identity layers (codemux's pake) per their own
  derivation; wiremux invariants pin the labels by reference rather
  than by direct production.
- QUIC transport authentication is channel-bound certificate pinning
  (DP8); the negotiator deterministically assigns dialer/listener
  roles and carries transport handshake material over the
  authenticated channel.
- Long-lived registration requires proof of PeerID possession by
  default (DP9); ephemeral mode does not.
- The relay enforces coarse resource protection (waiting-state
  budget, connection-rate caps) in addition to per-identifier
  guess-limiting (DP3).
