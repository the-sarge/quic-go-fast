# Generic Upgrade-Engine Mode Deletion Implementation Plan

**Date:** 2026-08-08
**Status:** Accepted; not yet implemented
**Track:** 2 of 5 in the 2026-08-08 architecture deepening program
**Depends on:** nothing — safe to start first
**Related:** ADR-0006; [`2026-07-29-direct-upgrade-transition-conformance-plan.md`](2026-07-29-direct-upgrade-transition-conformance-plan.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** Final architecture-review convergence and grilling on 2026-08-08; independent slice audit PASS on 2026-08-08

## Goal

Delete the test-only third mode embedded in `directUpgradeProtocolEngine` so the engine has exactly the two managed production roles promised by ADR-0006. Tests must observe production dialer/listener paths or the pure transition cursor instead of constructing a generic pseudo-role with its own terminal behavior.

## Current Shape (verified 2026-08-08 at `7f574a5a8b7ffff64fa69a10dd57b1b46e3ee78c`)

- `directUpgradeProtocolEngine` at `connect/upgrade_protocol_engine.go:15-35` contains production role data plus generic-only `transportReady`, `finish`, and `abortTransport` behavior.
- Managed dialer execution begins at `connect/upgrade_protocol_engine.go:92`; managed listener execution begins at `connect/upgrade_protocol_engine_listener.go:41` and joins the shared post-commit loop at `connect/upgrade_protocol_engine_listener.go:755-776`.
- The shared `run` loop at `connect/upgrade_protocol_engine.go:285-522` repeatedly branches among managed dialer, managed listener, and neither. `dialerEngine` is true for role dial, while `listenerEngine` requires role listen plus non-nil cursor and runtime (`:524-530`); generic mode is therefore any construction satisfying neither predicate, including a listener role missing managed state. The neither path uses `applyGenericAwaitedPhase` (`:584-601`) and `genericTerminal` (`:837-843`).
- Production listener code assigns the narrow `send` and `await` operations before entering the post-commit loop (`connect/upgrade_protocol_engine_listener.go:755-776`), so those operations are not generic-only.
- Repository reference census shows `abortTransport`, generic `transportReady` channel construction, and the generic `finish` path are supplied only by `connect/upgrade_protocol_engine_test.go`. Unmanaged constructions include recorder-built engines and direct struct literals throughout `connect/upgrade_protocol_engine_test.go:14-610`; notably `TestDirectUpgradeProtocolEngineListenerHappyPathFollowsPhaseTable` uses role listen without cursor/runtime and therefore enters generic mode. `TestDirectUpgradeProtocolEngineRejectsUnknownRole` at `:197` tests one subset of the unmanaged domain.
- ADR-0006 D3 already defines one 43-row dialer table and one 82-row listener table, one transition cursor, and no third role.

## Decision

- Remove generic mode and every branch reachable only when both managed predicates are false. The dialer and listener constructors may continue to create pre-run engines with non-nil cursors and no runtime; `runDialer` and `runListenerPostCommit` attach runtime before calling the shared `run`. At `run` entry, fail closed before event processing unless role is dial or listen and both cursor and runtime are non-nil.
- Remove generic-only fields and helpers, including the test-supplied transport channel, `finish`, `abortTransport`, `applyGenericAwaitedPhase`, and `genericTerminal`, after confirming a fresh production reference census.
- Retain `send` and `await` because the production listener post-commit path uses them. Narrow their location or naming only when that makes the two managed paths clearer without changing sequencing.
- Audit the bounded deletion domain: constructions that enter `run` or reference fields/helpers removed with generic mode. In `connect/upgrade_protocol_engine_test.go`, this includes the recorder-backed listener happy path, Datagram agreement/mismatch, unknown-role, peer-fallback/wrong-phase, frame-error, and caller-context tests; direct `run` literals for transport/phase cancellation, terminal-confirmed races, and role-abort stream ownership; and the direct helper test using `abortTransport`. Port production behavior to managed dialer/listener tests, express pure row facts through the transition cursor/table, and delete only duplicate or impossible unmanaged-state assertions. Direct literals in other test files that exercise retained listener helpers without entering `run` or touching removed fields are outside the census.
- Dispose the generic call graph explicitly: main-loop generic branches and `applyGenericAwaitedPhase` map to managed role/cursor coverage; `observeEngineTransport`, `contextEngineOutcome`, and `unexpectedEngineOutcome` lose their `genericTerminal` exits in favor of role-owned outcomes; `genericTerminal`, `abortTransport`, `finish`, and the generic transport-ready channel are reference-proven deletions. No shared helper may retain a hidden neither-role terminal path.

The finite construction/test disposition is:

| Current test at `connect/upgrade_protocol_engine_test.go` | Required disposition |
| --- | --- |
| `TestDirectUpgradeProtocolEngineListenerHappyPathFollowsPhaseTable` | Port phase/action sequence to the managed listener post-commit seam or cursor/table evidence |
| `TestDirectUpgradeProtocolEngineListenerNegotiatesDatagramExposure` | Port to managed listener post-commit coverage |
| `TestDirectUpgradeProtocolEngineListenerRejectsContradictoryDatagramAgreement` | Port to managed listener mismatch coverage |
| `TestDirectUpgradeProtocolEngineRejectsUnknownRole` | Replace with the fail-closed `run`-entry role/cursor/runtime assertion, including incomplete dial and listen cases |
| `TestDirectUpgradeProtocolEngineFailsOnPeerFallbackOrWrongPhase` | Port to managed listener/cursor rejection coverage |
| `TestDirectUpgradeProtocolEngineFrameErrorIsJoined` | Port to managed listener frame-error coverage |
| `TestDirectUpgradeProtocolEnginePrefersCallerContext` | Port to managed listener context-precedence coverage |
| `TestDirectUpgradeProtocolEngineAwaitTransportPrefersCallerContextWhenBothDone` | Port to managed listener transport-wait coverage |
| `TestDirectUpgradeProtocolEngineAwaitPhasePrefersCallerContextWhenBothDone` | Port to managed listener phase-wait coverage |
| `TestDirectUpgradeProtocolEngineTerminalConfirmedContextRaceFinishesDirect` | Port to managed listener terminal-success coverage |
| `TestDirectUpgradeProtocolEngineAwaitPhasePrefersBufferedConfirmedFrameOverDoneContexts` | Retain the focused helper assertion using a managed role outcome/owner; delete its `abortTransport` callback |
| `TestDirectUpgradeProtocolEngineLeavesContextRacedStreamForRoleAbortAdapters` | Port to managed dialer/listener role-owned abort/stream-settlement coverage |

The following `connect/upgrade_protocol_test.go` groups are already complete managed-dialer coverage and remain unchanged except for mechanical adaptation if a removed field is referenced: `TestDialerEngineCompletedBoundaryPreference` (completed-result/cancellation ordering), `TestDialerEngineContradictoryConfirmedFrameUsesD20OwnerPath` (contradictory confirmation), `TestDialerEnginePendingTerminalSourceClassification` (terminal-source/result classes), `TestDialerEnginePendingReadErrorContextOverlap` (read-error/context overlap), and `TestDialerEngineConvergedSendRequiresMaterializedDial` (materialized-transport prerequisite). Their engines enter `run` with role dial, cursor, and runtime, so they are retained evidence rather than unmanaged migrations.
- Treat an unknown role as an internal construction invariant. It need not preserve a standalone generic execution contract.
- Preserve the ADR-0006 transition tables, completed-result precedence, cancellation/timeout behavior, Datagram agreement, terminal settlement, packet ownership, errors, and protocol bytes exactly.

**Rejected alternative (do not do this):** Keep a generic engine constructor as a test harness. It makes test convenience a third semantic authority and permits states production can never construct.

**Rejected alternative (do not do this):** Split the shared post-commit loop into copied dialer/listener loops. The accepted outcome removes a false role while retaining one transition authority, not two implementations.

**Non-goals:** no transition-table redesign; no ADR-0006 amendment; no wire/control-frame change; no public interface, error, timeout, Datagram, cleanup, or packet-ownership change; no removal of production `send`/`await`; no new exported test hooks.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | new cleanup/deepening | Two-role production engine with every generic test disposed by evidence | None | Removes the generic pseudo-role and terminal adapters |

## Implementation Slices

### Slice 1 — Remove the generic post-commit engine role

**What it delivers:** `directUpgradeProtocolEngine.run` can execute only complete managed dialer or managed listener behavior, while the shared transition cursor and post-commit logic retain one production authority. Generic-only fields/helpers disappear; run entry enforces role/cursor/runtime completeness; and every in-scope construction and generic-terminal call site maps to a managed-path replacement, cursor assertion, or reference-proven deletion.

**Existing-work disposition:** New slice; ADR-0006 conformance remains completed historical work. No open PR or competing branch exists.

**Blocked by:** None.

**Single owner after merge:** The ADR-0006 transition table/cursor owns phase transitions. Managed dialer and listener event selection own their role-specific observations. `attemptResources` remains the sole terminal lifecycle/result owner. No test-only terminal owner remains.

**Authority completeness:** No new persisted fact is introduced. Both production constructors, both managed entrypoints, every transition-table row, and all terminal actions remain connected; the production/reference audit proves that removed fields have no live consumer.

**Transitional-seam budget:** None. Generic branches, fields, helpers, and test constructors are removed together. No compatibility adapter or alternate runner remains.

**Blast radius:** Confined to `connect`'s direct-upgrade engine and tests, but concurrency and protocol ordering are high risk. Public interface, wire bytes, errors, cancellation precedence, timeout budgets, Datagram exposure, materialized-stream cleanup, and packet ownership are frozen. The implementation should reduce branches and test-only allocations; no performance regression is accepted.

**Artifact classification:** Generic-code deletion and managed-path simplification are shipped behavior with intentionally unchanged production observation. The test-disposition census, transition tests, managed protocol tests, and race gates are verification aids. This plan is process/traceability metadata.

**Representation contract:** Supported domain = every concrete reachable role/state/event combination in ADR-0006's 43 dialer and 82 listener rows plus explicitly impossible combinations already rejected by the completeness test. Representation owner = the existing transition table and cursor. Guarantee = universal over that finite modeled domain. Terminating evidence = exact table completeness, a row-to-test disposition census for generic tests, managed-path regression tests, focused race gates, and `task verify`.

**Contract closure:** Triggered because a missed transition can corrupt concurrent lifecycle/packet ownership and the finite engine has multiple independently reachable race states. Invariant: every supported role/state/event pair is selected and settled by the one ADR-0006 transition authority, with no unmanaged execution mode. Representation owner: the 43-row dialer and 82-row listener tables plus their cursor. Terminal enforcement owner: `attemptResources`. No external protocol syntax enters the representation.

| Semantic class | Expected disposition | Enforcement owner/location | Terminating evidence | Guard mutation | Status |
| --- | --- | --- | --- | --- | --- |
| Reachable dialer role/state/event rows | Select exactly one declared action and terminal disposition | Dialer table/cursor; `attemptResources` for effects | Existing 43-row completeness check plus managed dialer tests | n/a | covered |
| Reachable listener role/state/event rows | Select exactly one declared action and terminal disposition | Listener table/cursor; `attemptResources` for effects | Existing 82-row completeness check plus managed listener tests | n/a | covered |
| Explicitly impossible table combinations | Reject with zero matching rows; never fall into an unmanaged runner | Table completeness validator | Existing missing/overlap/impossible fixtures | n/a | rejected |
| Caller vs post-commit cancellation and completed-result races | Preserve current caller precedence and completed-result preference | Managed role event selection and cursor action | Port the current cancellation/confirmed-frame tests to managed roles | n/a | covered |
| Transport-before-frame and frame-before-transport ordering | Preserve current awaited action and terminal result for each ordering | Managed role event selection and cursor action | Managed dialer/listener ordering tests replacing recorder-only paths | n/a | covered |
| Datagram agreement, absence, and contradiction | Preserve negotiated exposure or fail with the current identity | Cursor plus role-owned Datagram validation | Managed Datagram negotiation/mismatch tests | n/a | covered |
| Terminal success/failure with materialized transport | Settle exactly once with current stream/packet ownership | `attemptResources` | Managed terminal and role-abort tests replacing `finish`/`abortTransport` callbacks | Delete/bypass one central terminal action only if inherited coverage is otherwise ambiguous | covered |
| Engine entering `run` with unknown role, or dialer/listener missing cursor or runtime | Fail closed before event processing; no generic protocol contract | `run` entry assertion | Focused invalid-run-entry assertions for unknown, incomplete dial, and incomplete listen plus zero in-scope unmanaged construction after migration | n/a | rejected |

**Evidence budget:** Preserve the table completeness test over all 43/82 rows; one managed positive and materially distinct negative/race case per matrix class; one pre-edit census limited to constructions entering `run` or referencing removed fields/helpers, plus every call site of `genericTerminal`, `abortTransport`, `finish`, the generic transport channel, `applyGenericAwaitedPhase`, `observeEngineTransport`, `contextEngineOutcome`, and `unexpectedEngineOutcome`; focused `-race` on `TestDialerEngine.*|TestNegotiatorUpgradeDialerEngineHappyPath` and corresponding listener/Datagram cases already in the repository gate. At most one central terminal guard mutation if inherited coverage is ambiguous. No migration of unrelated literals that exercise retained helpers, no new stress count, platform matrix, protocol fixture family, or additional mutation. Review budget = one initial review plus at most one fully briefed replacement review. Terminate when every in-scope census entry has a recorded disposition, every matrix row has evidence, removed-field/helper references are empty, and `task verify` passes.

**TDD and preservation evidence:** Before deleting a generic test, make its production-relevant assertion fail at the managed entrypoint or cursor when the relevant guard/action is removed; then port it. Delete assertions only when the census identifies them as duplicate or impossible third-role behavior. Keep transition completeness and all existing managed dialer/listener tests green throughout.

**Dispatch context budget:** This plan; ADR-0006 D3; `connect/upgrade_protocol_engine.go`, the `runListenerPostCommit` seam in `connect/upgrade_protocol_engine_listener.go`, the unmanaged migration ledger in `connect/upgrade_protocol_engine_test.go`, the retained managed-dialer groups in `connect/upgrade_protocol_test.go`, transition table/cursor tests, and the bounded current diff. Historical implementation chronology is unnecessary. The second test file supplies retained coverage rather than another migration family; the deletion census remains bounded by `run` and removed-field/helper references, so porting, mechanical adaptation, and deletion still fit one fresh context and one PR.

**Slice decision audit:** Splitting test ports from code deletion would temporarily leave either untested production semantics or the false role, so they are atomic. Merging a table redesign would change the authority being protected. No cross-track blocker is necessary.

**Stop conditions:** Stop if a removed generic branch has a production caller, if a production-relevant test cannot be represented through a managed role or the transition cursor, if removal requires duplicating the post-commit loop, or if any transition row, public error, wire frame, timeout, cancellation, Datagram, cleanup, or ownership behavior changes.

## Acceptance Criteria

- [ ] A fresh reference census shows no production use of the generic-only fields/helpers before they are deleted.
- [ ] The engine has only managed dialer and listener execution; generic role detection, `applyGenericAwaitedPhase`, `genericTerminal`, and test-only terminal adapters are absent.
- [ ] `run` fails closed before event processing for an unknown role and for dialer or listener state missing cursor/runtime; every engine entering normal shared-loop processing is a complete managed dialer or listener.
- [ ] Every construction entering `run` or touching removed fields/helpers, and every generic-terminal call site, has a recorded managed-path port, cursor/table port, or reference-proven deletion; unrelated retained-helper literals are not migrated.
- [ ] All 43 dialer and 82 listener transition rows remain owned by the existing table/cursor and its finite completeness evidence.
- [ ] Production `send`/`await` use remains intact.
- [ ] Public interface, wire protocol, errors, cancellation/timeouts, Datagram exposure, terminal cleanup, and packet ownership remain unchanged.

## Validation Gates

Run the transition completeness and direct-upgrade engine tests, `go test ./connect`, the repository's focused managed-dialer and listener/Datagram race gates, `./scripts/check-gofmt.sh`, and `task verify`. Follow the Go toolchain supply-chain audit before any Go command.

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md). Any second transition loop or production semantic change is an approach stop, not cleanup latitude.
