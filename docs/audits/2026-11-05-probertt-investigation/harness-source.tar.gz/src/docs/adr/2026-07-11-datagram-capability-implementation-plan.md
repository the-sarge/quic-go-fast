# Datagram Capability Implementation Plan

## Objective

Implement the optional carrier-bound Datagram capability accepted in
[ADR-0009](adr-0009-optional-datagram-capability.md) without changing reliable
Wire behavior, upgrade-control version or state sequence, or the required
transport method sets. Completion means PRD-0001's Datagram acceptance criteria
pass through production Wire establishment for supported QUIC,
mixed-capability, relay, and stream-only paths.

This plan is an implementation handoff, not implementation authorization from
the Wayfinder map.

## Operating Discipline

Each slice follows [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md), uses test-first
changes where behavior is observable, calls out public API additions in the PR
body, and keeps a representative pre-Datagram stream-only transport fixture
compiling throughout.

## Operating constraints

- Run the Go toolchain supply-chain audit in `AGENTS.md` before any Go
  subcommand. The installed base must be Go 1.26.3 or newer.
- Preserve upgrade-control version 1, its core schema, and its state sequence.
  Extension-free frames remain valid; the accepted `"wiremux.datagram/1"`
  extension changes present-case post-commit bytes. Transport-native
  negotiation validates each local carrier after handshake, and the extension
  intersects those local results into pairwise final exposure.
- Preserve `Transport`, `Session`, and `TransportListener` method sets. New
  transport participation is optional.
- Keep `Wire.Close` as the only lifetime owner. Do not add a Datagram-specific
  close, EOF, queue-full, overflow, or capability-absence error.
- Do not use queue lengths, goroutine timing, packet order, or universal
  delivery as test or API guarantees.
- Treat ADR-0009 and PRD-0001 as normative. The three research notes explain the
  audited library and cross-transport facts but do not override the contract.

## Slice 1: Extract the optional carrier at each role's transport boundary

Add `connect.DatagramCarrier`, `connect.DatagramCapable`, and
`UpgradeResult.Datagrams`. Test the negotiator with stream-only, absent,
present, nil/present, typed-nil carrier, nil, typed-nil, or non-signaling
`Lifetime`, unusable-ceiling, listener-decorator, and post-commit inconsistency
cases before implementation. Reuse or introduce a typed-nil-safe validation
helper and invoke no carrier or context method until that check passes.

There is no shared extraction instant. The dialer validates immediately when
post-commit `Session.Dial` returns. The listener validates immediately when
`TransportListener.Accept` returns, before wrapping or its next control
transition. Successful `Accept` is an independent packet-socket ownership
boundary, so a
malformed optional result closes the accepted connection and socket and returns
`ErrUpgradeTransportNotConverged`, zero result, and no relay fallback even
before observed `commit`; listener local commit is the other boundary. The
post-commit dialer uses the same result. Only transport failure before successful
`Accept` and before local commit may enter
synchronized `transport_failed` fallback. A valid listener carrier is retained
separately until final result assembly, before `listenerOwnedStream` strips
optional interfaces.
Extend the existing accepted/converged/confirmed encoders and decoders with the
already-valid bounded `Extensions` map key `"wiremux.datagram/1"` and CBOR
boolean `true`. Listener `accepted` advertises valid local presence; dialer
`converged` sends its intersection with that bit; listener `confirmed` echoes
the final result. Encode absence by omitting the key; never encode CBOR `false`.
Unknown extensions remain ignored, and a present non-true value or
contradictory echo fails convergence. Retain a local carrier in
`UpgradeResult.Datagrams` only after the final result is true. Test a shared
native transport whose optional interface appears on only one returned stream;
both roles must succeed reliably with capability absent.
Plumb that behavior explicitly: extend `upgradeControlPhaseResult` with the
Datagram extension state; update `encodeUpgradeControlAcceptedFrame`,
`encodeUpgradeControlConvergedFrame`, `encodeUpgradeControlConfirmedFrame`, and
`decodeUpgradeControlPhasePayload`; then thread the state through
`directUpgradeProtocolEngine` in `connect/upgrade_protocol_engine.go` so it
reads listener `accepted`, computes the dialer's `converged` intersection,
validates the listener's `confirmed` echo, and assembles
`UpgradeResult.Datagrams` only for agreed presence.
Add invalid-vector codec and convergence tests for explicit CBOR `false`, a
different well-formed non-true value, and contradictory `converged` or
`confirmed` echoes. Every case returns `ErrUpgradeTransportNotConverged`, a
zero result, and no active stream; none is a valid golden frame.
Add wrong-phase vectors that put the registered key in `offer`, `fallback`,
`selected_pair`, `ready`, and `commit`; each is rejected as `protocol_mismatch`
and follows the existing phase-specific fallback or fail-closed outcome rather
than the ignore-unknown path.
After extraction on either role, wrap the transport stream in a reliable-only
`ReadWriteCloser` view that strips `DatagramCapable`. The explicit
`UpgradeResult.Datagrams` field is the exclusive lower exposure surface.
Add it as the second exported field, between `Stream` and `Path`, exactly as
ordered in ADR-0009 and PRD-0001.
Because the new exported field breaks unkeyed `UpgradeResult` composite
literals, convert repository-local positional literals to keyed form, inventory
known downstream consumers, and call out the accepted pre-release break plus
follow-up repositories in the implementation PR. Do not make merged downstream
changes a Slice 1 exit condition.

Pin the ADR/PRD failure decision table with focused state tests: normal absence,
invalid native parameter encoding, generic handshake failure, and malformed
optional return. Discovery/query methods must return promptly without network
I/O. Blocking lower sends and receives must be released by their call context
or carrier lifetime. The lower send contract includes a bounded unexported
copy-on-admission queue so direct `connect.Upgrade` callers can cancel before
admission; success means only accepted for possible lower transmission.

Exit criteria:

- all existing custom transports and fakes compile without new transport
  methods; repository-local positional `UpgradeResult` literals are migrated
  and downstream occurrences are reported for follow-up;
- both roles preserve a valid carrier through `UpgradeResult`;
- both roles return a reliable stream that never satisfies `DatagramCapable`;
  asymmetric presence yields nil `Datagrams` and reliable success on both;
- every valid carrier exposes one stable cause-bearing lifetime context;
- typed-nil inputs never panic; malformed results after successful `Dial` or
  `Accept` close the connection and socket with no relay fallback;
- invalid native and generic transport failures use the correct pre-ownership
  fallback or post-ownership failure row;
- discovery/query methods are prompt and blocking carrier I/O honors both call
  cancellation and terminal lifetime;
- extension-free upgrade-control v1 goldens remain valid and mean absence;
  new present-case accepted/converged/confirmed goldens pin the Datagram
  extension without changing the state sequence.

## Slice 2: Add the root borrowed handle and aggregate lifecycle

Build the concrete `Datagrams` wrapper around a deterministic fake carrier,
then expose `Wire.Datagrams()` and `ErrDatagramTooLarge`. Test exact fixed
ceiling calculation, the `0x00` envelope, empty consumer messages, unknown and
empty native drops, local oversize rejection, copy-on-admission, caller-owned
receive slices, concurrent callers, and the complete error-precedence table.
Pin lower receive results through the root wrapper: non-nil empty payload plus
nil error is a valid empty native Datagram; nil payload plus terminal error is
failure; payload plus error and `(nil, nil)` are contract breaches that deliver
nothing, return `ErrWireClosed`, preserve an available cause, and initiate
aggregate teardown.
Test that repeated discovery returns the same pointer before and after local or
peer teardown, `MaxPayload` remains frozen, and I/O on that handle returns
`ErrWireClosed`. Update root `ErrWireClosed` godoc to explain that, on the
Datagram plane, it also covers gate-only closure while reliable writes remain
usable; it does not necessarily mean every reliable direction is closed.
Document that direct `connect.Upgrade` carrier calls operate
on already framed lower bytes and do not inherit root queue or error semantics.
After discarding every empty or reserved-discriminator lower message, recheck
the closed gate and call context in that precedence before reading again. A
deterministic carrier continuously producing invalid messages must not starve
call cancellation or `Wire.Close`, spin, or leak.

Change `newWire` to snapshot `UpgradeResult.Datagrams`, build and store exactly
one handle from that field, and start the lifetime monitor. It must never assert
`DatagramCapable` on `result.Stream`. Drive this through production Wire
construction in both roles so agreed capability survives reliable-only
decoration while neither result stream exposes the optional interface.

Add one bounded unexported send-admission queue and pump. Serialize carrier
sends and carrier receives in each direction while allowing full duplex and
concurrent reliable I/O. Close the Datagram gate before current stream-first
teardown, discard admitted unsent work, release every waiter, and ensure no
worker outlives the Wire.
Test the asynchronous send boundary: after public root admission succeeds, an
unclassified lower send error with active `Lifetime` is silent loss, does not
revoke or latch onto later calls, and leaves the Wire usable. An explicit
at-or-below-ceiling size rejection remains a terminal carrier breach.

Start a lifetime monitor when constructing the Wire. It feeds
`context.Cause(carrier.Lifetime())` into the aggregate teardown authority and
serializes gate closure with queue admission. Prove with an idle fake carrier
that, after root observes terminal cancellation, no later send can return
successful admission and every closed error preserves the cause.

Route classified reliable-read results through the Datagram-gate authority. The
initial classifier covers authenticated peer `io.EOF`, `ErrWireClosed`, channel
authentication/truncation failure, and transport reset/closure identities after
reporting any returned bytes. Close the Datagram gate and release its workers
without initiating aggregate teardown or closing the independent reliable write
direction while carrier lifetime remains active. Tests attempt reliable
`Write` after graceful read EOF and after a channel integrity failure and pin
today's behavior. Preserve other direction-local behavior:
`channel.ErrStreamEmptyDataFrame` remains read-side only, and an unclassified
per-call error does not end reliable writes or Datagrams unless the carrier
also terminates `Lifetime`.

Exit criteria:

- send precedence is closed, oversize, then context/admission;
- receive precedence is closed, then context;
- lower receive conformance covers empty success, terminal error,
  payload-plus-error, and nil-plus-nil without ambiguous delivery;
- cancellation and oversize are non-terminal;
- post-admission unclassified lower send errors are silent loss and never
  become deferred public errors; observed ceiling breach remains terminal;
- handle identity and capability presence remain stable through teardown;
- `ErrWireClosed` documentation and tests distinguish Datagram-gate-only
  closure from aggregate Wire closure without changing reliable-I/O meaning;
- local and peer close converge on `ErrWireClosed` with underlying causes
  preserved;
- race tests cover saturated sends, waiting receivers, reliable I/O, and
  teardown without leaks, including Datagram-gate-only reliable-read failure.

## Slice 3: Map the built-in QUIC carrier

Enable RFC 9221 unconditionally in both quic-go configs and implement the
optional carrier on the same authenticated connection as the reliable stream.
Offer `wiremux-quic/2` before legacy `wiremux-quic/1`; `/2` commits each peer to
`max_datagram_frame_size >= 1243`, which admits 1240 lower Data bytes after
frame overhead, while `/1` remains stream-only. Report local presence only
after `/2` and both directional support flags are true. Publish the
audited frame-fit lower ceiling of 1240 bytes for the current 1280-byte initial
packet size, producing a 1239-byte public ceiling after the envelope. The
arithmetic starts from quic-go's 1243-byte short-header payload estimate, then
subtracts the DATAGRAM type and two-byte length before the wiremux envelope.
Set `InitialPacketSize: 1280` explicitly in both client and server configs and
pin the effective value in focused configuration tests; do not depend on
quic-go's default remaining unchanged.

Keep QUIC's certificate pin, selected-remote filter, congestion controller,
connection, transport, and packet-socket ownership shared by both planes.
Implement a bounded QUIC-adapter admission queue and one lifecycle-owned send
worker. `SendDatagram(ctx, payload)` copies on admission and waits on its call
context or carrier lifetime when full; only the worker calls quic-go's blocking
send. Carrier termination closes the connection, releases the native call,
discards queued work, and joins the worker. Keep this queue distinct from the
root queue so direct `connect.Upgrade` callers receive cancellation semantics.
Contain receive overflow/drop and post-close enqueue behavior behind the root
and adapter gates. Add the transport evidence record required by ADR-0009,
citing RFC 9000, RFC 9221, and the exact pinned quic-go source.
Forward the cause-bearing quic-go connection context through `Lifetime`. An
explicit quic-go too-large rejection for a lower payload at or below the
frozen ceiling is terminal as an observed contract breach; a payload accepted
and later silently dropped by the packer is ordinary permitted loss. Pin this
distinction with adapter-focused tests or instrumentation.

Exit criteria:

- new/new direct QUIC exposes handles on both peers;
- new/legacy and one-direction-only paths preserve reliable success with
  capability absent in both roles;
- a peer with a smaller positive numeric DATAGRAM limit cannot offer `/2` and
  negotiates `/1` with capability absent, so no frozen ceiling exceeds its
  advertised limit;
- exact-boundary and zero-length messages work while the stream stays usable;
- the current 1239-byte public baseline is repeatedly delivered on a lossless
  1280-byte-baseline loopback and 1240 consumer bytes fail locally;
- the current frame-fit baseline is intentionally re-audited on sizing
  changes, while consumers always gate complete records on `MaxPayload` rather
  than assuming a portable 1200-byte floor;
- marked Datagram loss is not retransmitted, while later stream and Datagram
  traffic proceeds;
- wrong certificate, handshake tampering, or non-selected sources cannot
  inject or establish Datagram traffic;
- close and saturation tests leave no goroutine, connection, transport, or
  packet-socket leak.
- direct lower callers can saturate adapter admission, cancel a blocked send
  promptly without closing the connection, and leave no worker after teardown;
- invalid native parameters or generic handshake failure before successful
  `Accept` and before commit may use synchronized `transport_failed` fallback;
  detection after commit or successful `Accept` returns
  `ErrUpgradeTransportNotConverged`, zero-valued results, and no active stream.

## Slice 4: Publish reusable conformance coverage and close the matrix

Add a consumer-importable Datagram contract suite to `wiremuxtest`. Its
factory supplies fresh two-peer transports and drives production Wire
establishment rather than testing a friendly carrier directly. Document that
the suite proves observable behavior only; adapter security, retransmission,
and congestion evidence remains mandatory.

Run the suite against supported QUIC and retain a stream-only implementation as
the additive-API regression fixture. Cover both dialer/listener orientations,
directional ceilings, ownership, concurrency, loss-tolerant assertions,
context cancellation, close, malformed optional-interface results, relay
absence, extension-free compatibility frames, and present-case extension
goldens. Include asymmetric local-outbound ceilings and blocking carrier calls
released by call cancellation and lifetime termination.

Exit criteria:

- PRD-0001's entire Datagram acceptance inventory is executable or explicitly
  linked to the transport evidence record when non-observable;
- `task verify` and the required race gates pass;
- package docs and examples teach comma-ok discovery and the admission-not-
  delivery meaning of `Send`;
- implementation PR bodies identify the root and `connect` public additions
  and list downstream adoption as follow-up work only.

## Downstream follow-ups

After all wiremux slices merge:

1. GridCast may add capability discovery and switch only its coded-symbol
   carrier to Datagrams when the reported ceiling fits its complete record;
   its reliable protocol remains the fallback.
2. codemux and keymux should update compatibility fixtures only where their
   returned `Wire` wrappers or mocks need to forward the new additive surface;
   positional `UpgradeResult` literal conversions happen in these separate
   follow-up PRs, not Slice 1.
3. Other consumers adopt in their own repositories and PRs. No downstream
   migration is part of this plan.
4. Relay-capable Datagram carriers and logical multipath remain the separate
   architecture efforts linked from ADR-0009.

The compatibility follow-up PRs block the pre-release public-API compatibility
gate and downstream adoption, but they do not block the wiremux Slice 1 merge.
