# Architecture Deepening Program — 2026-09-04

**Status:** Complete; no implementation frontier

## What this is

Stable program identity: `wiremux-architecture-2026-09-04`. The two track plans are the normative contracts for the grilled TURN publication and auth-release observer ownership candidates. Each audited slice maps to one intended PR, one child issue and one OmniFocus task. This index owns track identity and dependencies; the eventual GitHub tracking issue owns current administrative frontier state. [Audit history](../research/2026-09-04-architecture-handoff-audit.md) is separate from implementation contracts.

## Outcomes that require no implementation

- Do not introduce a TURN construction builder, typestate hierarchy, whole-allocator abstraction or generic worker framework. The existing composite already has depth; its publication recipe is the surviving seam.
- Do not start the base source guard unconditionally in a new constructor: production/self-seal and the forced-close fixture deliberately use different base-pump arrangements.
- Do not add a release receipt, generic notification scheduler, third lifecycle owner or uniform release/publication schedule. Existing settlement and Wire timing is required behavior.
- Track 1 demonstrated and corrected the pre-publication base-reader failure within its finite characterization budget; its [receipt](../research/2026-09-05-turn-publication-characterization.md) distinguishes the observed fault from publication consolidation. No physical failure-frequency or broader network-liveness claim follows.
- Existing direct/TURN convergence distinctions, codecs, selected-path filtering, relay-assist shaping, waiting-peer ownership and server shutdown remain settled by the [August 25](2026-08-25-architecture-deepening-program.md) and [August 26](2026-08-26-architecture-deepening-program.md) programs. No unrelated tracks are rebaselined.
- No new glossary term or ADR is needed. TURN packet composite, Auth-context ownership, Establishment settlement and Aggregate teardown already name the chosen responsibilities.

## Tracks, dependencies, and frontier

| # | Track | Plan | Parent issue | Blocked by | Slices | Size | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | TURN composite publication | [Track 1 plan](2026-09-04-turn-composite-publication-plan.md) | pending | None | T1.S1 | Small; Medium concurrency risk | COMPLETE |
| 2 | Auth-release observer ownership | [Track 2 plan](2026-09-04-auth-release-observer-ownership-plan.md) | pending | None | T2.S1 | Small; Medium timing risk | COMPLETE |

There are no cross-track blocking edges. T1.S1 and T2.S1 are complete; no implementation frontier remains. Track 1 changes `connect/pionturn`, while Track 2 changes root auth/settlement/Wire code. Characterization and narrow publication work form one T1.S1 PR, with the demonstrated correction distinguished from consolidation in its linked evidence receipt. Neither track may combine with the other in one PR.

`FRONTIER` here means dependency-ready. Dispatch readiness additionally requires these contracts merged to the current remote default branch, the verified plan commit on each marked child, and correct ready labels. Publication uses pending issue fields; live issue mappings remain in GitHub rather than generating another plan commit to backfill this index.

## Rules that bind every track

- Preserve released public interfaces, wire profiles, ownership, lifecycle timing, error identities and downstream compatibility. Only Track 1 permits the specifically demonstrated base-fault/publication correction it names; nothing authorizes a broader failure-policy change.
- Each changed durable fact and transition has one named mutation owner. Constructors and destructive/security-sensitive consumers of newly authoritative state must be covered in the same slice; neither track introduces persistence.
- No duplicate production protocol, generic mutation adapter or second resource lifetime is budgeted. Permanent real/fake adapters remain testing seams, never competing state machines.
- The shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice` govern with [repository review](../REVIEW-LOOP.md), [CI](../CI.md), conventions and AGENTS.md. Use their representation/artifact gates, finite evidence/review budgets and precise-root history comparison; do not strengthen them through copied policies or recursive harness claims.
- Each child receives its exact current slice contract and bounded context. Scoped re-audit stays on that child only while representation, owner, accepted outcome and one-PR scope remain intact; other changes return to architecture-handoff or a decision.
- Before merge: independently disposition review evidence, diagnose failures before reruns, certify the exact local head and require same-head hosted CI. After merge: append-dev-journal, complete the slice task, reconcile parent/tracker/frontier. Keep tracking pointer-based; administrative state is not exact code-head certification.
- This handoff packages work and reports the frontier. It does not launch implementation or dispatch agents.
