# Send-thread payoff acceptance audit — 2026-10-24

The normative [Slice 6.2 contract](2026-10-19-macos-native-stack-plan.md#slice-62--user-initiated-send-thread-on-apple-silicon) owns current obligations. This audit records the retrospective owner decisions and their boundaries; [diagnosis #2022](https://github.com/GridSwarm/wiremux/issues/2022) and the [PR #2020 gate receipt](https://github.com/GridSwarm/wiremux/pull/2020#issuecomment-6386014517) retain the measurements and chronology.

## Completed 12-spinner owner decision

After the completed 12-spinner campaign missed the +25% Datagram and +35% stream payoff floors, the owner said: “those are tiny misses...I accept them”. The accepted observations are +23.7808% Datagram delivery and +34.3694% stream delivery (+34.3597% by stream packet rate). They stay recorded as original-floor misses accepted by the owner, rather than being relabeled original-floor passes.

The complete A1/B1/A2/B2 cohort contains 24 measured samples and eight excluded warm-ups. No sample was removed or replaced and no traffic was rerun. Hook engagement, fast-core placement and cost-to-others passed; the cause of the small payoff gap remains unestablished. The owner acceptance resolves that gap as a merge blocker for this cohort without requiring a causal explanation.

## Completed current-candidate 24-spinner owner decision

The remaining original campaigns found +9.1840% Datagram delivery and +18.0008% stream delivery (+17.9897% stream packet rate) at 24 other-program spinners, below the original +25%/+35% floors. The owner initially kept merge blocked for diagnosis in [#2024](https://github.com/GridSwarm/wiremux/issues/2024). After the [completed bounded control and executive summary](https://github.com/GridSwarm/wiremux/issues/2024#issuecomment-6390558674), the owner selected “option 1”: accept only this completed current-candidate cohort's payoff misses, publish the exception, and resume #1930's review/certification/merge workflow. The [acceptance receipt](https://github.com/GridSwarm/wiremux/issues/2024#issuecomment-6390752952) records that decision.

The accepted 24-spinner cohort used product `4f30a1f37ba54875ef3b5c12f8ca40437cbcaeb5`, rig `4f75c038e5fa29d2831fb1bf7e6fdd5ad7f044d5` and binary SHA-256 `0db68323124433c985498cd466f1de5295c8d8da0d759cc8d8f6a9250d464e89`. Datagram hook-off/on medians were 279988.0108/305702.1170 delivered packets/s; stream delivery medians were 2877.9577/3396.0124 Mbit/s. Both A/B pairs independently gained throughput. No sample was discarded to improve payoff.

Raised-thread E-core block medians satisfy the decided medians-of-three placement method; pooled medians are 0.2944% for Datagrams and 0.5673% for stream. Individual measured stream maxima of 1.5100% and 1.1157% remain retained: this is not a universal per-run ≤1% claim. Other-program spinner progress was 98.8081%/105.3210% of hook-off. All 768 load reports cover the full sender lifetime, all outcomes match and rate flags are zero.

The valid repaired pre-ACK16 control gained +11.6411%/+15.6665%, also below the old floors. It used the preserved product `6e6665f22fb7623fff82e978c2598e10e9a68ea5`, rig `69bf1468b373f3f0fbdd2ccdab2287fe4332ed0b` and binary SHA-256 `a089cf53308c75f6951af41e0e1195711d8c8d27525376f03573d19b477dd845`. Both binaries used the adopted fast.8 graph and Go 1.27.3; commands matched, while collection times and host conditions were not matched across binaries. The mixed marginal payoff change weakens ACK16 as the main explanation. A faster default-class baseline than the older fast.7/Go 1.27.2 research describes the smaller relative gain, but its exact source/runtime/scheduler/host cause remains unresolved. Current raised busy throughput retains approximately 98% of its observed raised idle reference; that reference is not a proven physical ceiling. The owner accepted that remaining uncertainty; no in-contract code defect or fix was established.

## Bounded disposition

| Obligation | Disposition |
| --- | --- |
| Completed 12-spinner Datagram and stream payoff floors | Accept the observed shortfalls for that cohort only; do not rerun it or lower the general floors. |
| Placement and cost-to-others for the completed cohort | Retain the passing evidence and raw samples. |
| Completed current-candidate 24-spinner payoff floors | Accept only the observed +9.1840%/+18.0008% shortfalls for this cohort; retain original failures and raw records. No new general floor. |
| Other original scenarios | Valid passing evidence: idle +6.6781%/+4.5200%; busy consumer +25.6693%/+51.5803%; refused launch +0.7687%/+1.7530% with refused outcome; receiving-8 replacement +2.5861%/+2.7748%; receiving-18 −2.9873%/−2.5186% (Datagram/actual stream delivery). Their original limits remain unchanged. |
| Separately authorized diagnostic control and replacements | All consumed; preserve the invalid attempts separately and use only complete valid cohorts. No further traffic or automatic rerun. |
| ACK16 merged during the first campaign | Preserve the old cohort's fixed-binary identity; the implementation was reconciled before the six later original scenarios. The old receipt does not certify the newer base. |
| Existing native preservation checks after reconciliation | The repeated macOS/Linux fork checks and Windows cross-build passed on the reconciled source. Ordinary exact-head local certification and same-head hosted CI remain required. No broader test, platform or stress matrix. |
| Review, product completion/frontier state, merge and journal | Remain mandatory under the shared and repository review protocol. The product PR owns its completion/frontier transition; the journal starts only after its merge. |

The first cohort used product source `6e6665f22fb7623fff82e978c2598e10e9a68ea5` and rig `69bf1468`; its immutable binary hash and all 32 runs are in the linked receipt and `/Volumes/worktrees/wiremux/native-gap-evidence/1930-send-thread/`. ACK16 merged as `ebb254d0d12b450cef2010553ab2b9e3764e4ad6` while that cohort ran. The post-ACK16 12-spinner payoff is unmeasured; accepting the already reported cohort does not create an exact-head performance claim. The six later original scenarios used the reconciled code, with a fixed binary per comparison. Their results and the subsequent diagnostic control do not blend samples with the accepted 12-spinner cohort.

## Re-audit gates

The same child #1930 and one product PR #2020 retain the accepted outcome. `prepareTransport` remains the single switch owner; F9 owns the per-transport capability, platform build constraint, per-connection outcome values, lock, checks and restoration. The universal constructor guarantee, internal readout, supported representation domain and authority boundary are unchanged. There is no persisted state or restart round trip, no public API or NativeConfig setting, no admission or compatibility change, and no new transitional seam.

Artifact classes are unchanged: runtime switch and launch-context docs are shipped behavior; fork restoration is fork-owned safety enforcement; the internal readout, focused tests, rig and finite campaigns are verification aids under their existing owners and retirement policies; this audit and tracking surfaces are process metadata. No new verification aid becomes a maintained blocking deliverable. Contract closure remains not triggered because wiremux still has one optional call site and one read-only outcome seam, while the fork owns the material thread-restoration invariant.

The 32,000-token dispatch target, four new wiremux cases, zero mutations and one initial plus at most one replacement product review remain unchanged. The seven valid scenario cohorts, consumed owner-approved extensions and named preservation checks terminate the measurement scope. Every other requirement remains binding; a new miss uses the plan's existing diagnosis route. Intel performance and a consumer saturating GOMAXPROCS remain the accepted untraced effects. ACK16's causal effect on the old cohort is not inferred. A combined-head preservation failure would be independently dispositioned before a fix.

The strongest split (readout separately) remains rejected because the refused-launch gate needs it and it has no independent shipped outcome. The strongest merge (with 6.1) remains rejected because the mechanisms and gates have separate contracts; 6.1 is already merged. No replacement design, new hand-off or state copy is proposed. This documentation publication is the scoped acceptance update, not a second implementation slice or a routine frontier PR.

## Consumed extensions and invalid-attempt exclusions

The original ceiling was seven 32-run A1/B1/A2/B2 scenarios, each with 24 measured samples and eight excluded warmups. The owner separately authorized exactly one pre-ACK16 busy-24 control, exactly one replacement receiving-8 campaign, and, after a harness failure, exactly one repaired replacement control. These exceptions expanded the finite evidence budget only for those named runs. All are finished; there is no pending measurement or automatic retry.

| Attempt | Validity and retained disposition |
| --- | --- |
| Original receiving-8, `recv8/` | Entire 32-run cohort excluded: reused remote load directories contained stale stop files, ending half the loads immediately. No favorable subset retained. |
| Replacement receiving-8, `recv8-replacement-2024/` | Owner approved one full replacement after the launcher selected fresh remote directories. All 32 valid; all 256 spinner reports cover sender lifetimes. |
| Original pre-ACK16 control, `diagnosis-2024-ack2-busy24/` | Failed at the first excluded warmup; zero measured samples. macOS killed the receiver after an in-place executable replacement because of cached-signature state. Original budget stopped on failure. |
| Repaired replacement control, `diagnosis-2024-ack2-busy24-replacement/` | Separately owner approved after fresh-file staging, full-hash verification and atomic rename plus a successful no-traffic startup check. All 32 valid; all 768 spinner reports cover sender lifetimes. |

The [receiver exclusion and repair](https://github.com/GridSwarm/wiremux/issues/2024#issuecomment-6389132731), [startup failure and atomic-install repair](https://github.com/GridSwarm/wiremux/issues/2024#issuecomment-6389945527), [replacement control approval](https://github.com/GridSwarm/wiremux/issues/2024#issuecomment-6389993531) and [complete comparison/cleanup receipt](https://github.com/GridSwarm/wiremux/issues/2024#issuecomment-6390558674) preserve the sequence. Harness repairs remained one-off evidence tools outside the product; no maintained shipped aid was added. All original reports, including invalid attempts, remain under `/Volumes/worktrees/wiremux/native-gap-evidence/1930-send-thread/` with explicit validity dispositions. Pair claims and owned processes were released after collection.

The five valid other scenarios, mechanism/cost observations, modest repeatable payoff and small integration cost support the owner's acceptance. This is a retrospective decision after seeing the observations, not a causal diagnosis of the historical baseline or a prospective +9%/+18% performance guarantee. Review, exact-head certification, hosted CI and the product merge remain required; the journal begins only after that merge.
