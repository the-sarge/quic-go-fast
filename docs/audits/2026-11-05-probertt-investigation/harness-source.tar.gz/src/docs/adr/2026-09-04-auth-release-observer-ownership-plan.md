# Auth-Release Observer Ownership Implementation Plan

**Date:** 2026-09-04
**Status:** Complete
**Track:** 2 of 2 in the [2026-09-04 architecture deepening program](2026-09-04-architecture-deepening-program.md)
**Depends on:** Nothing; second is recommended ordering only
**Related:** [ADR-0010](adr-0010-auth-context-lifecycle-ownership.md), [settlement policy](2026-08-08-establishment-settlement-policy-plan.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** [Handoff audit](../research/2026-09-04-architecture-handoff-audit.md)

## Goal

Make the existing auth-context owner retain and wire its ordered release observer, removing two-object callback pairing from establishment settlement and Wire while preserving each caller's release and publication timing.

## Current Shape (verified 2026-09-04)

- `auth_context_lifecycle.go:13-93` owns logical revocation, the first-revocation deadline, release once-semantics and the stable immediate result. The observer at `:131-176` already owns late-event gating, serialization and nonblocking panic-isolated delivery.
- `establishment_settlement.go:172-173,210-219,249-258` separately constructs the observer, starts release before cleanup, and publishes its immediate result from the frame-level finish guard.
- `wiremux.go:535-571` revokes before teardown, then its release goroutine constructs/wires/publishes independently of a possibly blocked carrier Close. `newWire` at `:457-475` retains the separate handler.
- The same live auth owner transfers on successful establishment. Observer identity/callback wiring is accidental caller knowledge; the differing release/publication schedules are required behavior.

## Decision

1. Keep the existing `authContextOwner` as the module; retain the ordered observer implementation privately inside it. Choose the handler once at owner construction from the existing Dial option and transfer that same owner on successful establishment. No mutable observer rebinding for tests or teardown.
2. Provide private lifecycle operations equivalent to `revoke(timeout)`, `startRelease(timeout)`, and `finishRelease(timeout, route) error`. Preserve existing borrowed auth/transport views. A small named route distinguishes observe-immediate from return-immediate; it affects reporting only, not cleanup, scheduling or budgets.
3. `startRelease` synchronously revokes and starts once-owned bounded release without publishing. `finishRelease` starts or joins that same operation, publishes the stable immediate result once at its caller-selected point, and returns it. The first real publication fixes the reporting route; repeated finishes do not duplicate notification. The timeout argument never resets the deadline fixed by first logical revocation.
4. Failed establishment starts release before upgrade cleanup, consume and carrier close; the existing frame defer finishes and observes after settlement, including panic paths. Successful establishment transfers without release/publication. Do not move the frame guard into individual exits.
5. Wire still revokes at the existing startTeardown point and uses its separate release goroutine/result channel. Automatic teardown finishes-and-observes there even while carrier Close blocks. Explicit initiating Close finishes-and-returns there without duplicating the immediate observer event; a later explicit caller joining an automatic teardown does not change its initiator's route.
6. Deferred success emits no second event; a distinct late producer error is observed once after immediate publication and cannot mutate the stable immediate/Close result. Preserve non-releasing legacy contexts, one producer invocation, lease drain, immediate logical revocation, and current error identities/stage/disposition semantics.
7. Handler completion is never joined by Dial or Wire completion. Retain blocked-handler isolation, panic recovery and safe reentry into Wire.Close; a non-conforming handler can still block its own observer chain under the existing documented contract.
8. Delete settlement's observer field/construction/callback pairing and its local release-start guard if that guard moves to the owner. Delete Wire's observer wiring and retained handler/newWire handler forwarding after the transferred owner holds it. Adapt private test constructors to initialize the handler at owner construction; do not keep a second callback protocol for tests. Preserve settlement outcome policy and Wire aggregate teardown.

**Rejected alternatives (do not do this):** Add a release receipt or a third lifecycle owner; rewrite the already useful observer; build a generic notification queue/scheduler; use one synchronous Close everywhere; publish automatically when release starts; defer automatic Wire notification until blocked carrier teardown finishes; or merely rename the same two-object callback recipe.

**Non-goals:** No public auth capability, key semantics, cryptographic erasure guarantee, producer contract, timeout/budget, rendezvous consumption, stage/disposition, Datagram plane, carrier or aggregate teardown redesign. No new external dependency or handler delivery guarantee.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| T2.S1 | Complete | Owner-held observer through failed Dial, success handoff and explicit/automatic Wire teardown | None | n/a; no transitional production protocol |

## Implementation Slices

### Slice 1 — Own auth-release observation without moving caller timing

**What it delivers:** A behavior-preserving auth-owner interface that hides observer identity and callback matching across both real callers, with their existing publication locations and event routing retained end to end.

**Existing-work disposition:** New slice. No open issue/PR implements this ownership move. Retain the merged auth lifecycle, settlement and aggregate teardown; replace only caller-owned observation plumbing. Existing merged plan obligations remain preservation evidence, not a competing implementation baseline.

**Blocked by:** None. TURN work touches a separate module and is not an input to this slice.

**Single owner after merge:** `authContextOwner` owns handler identity, release once-state, deadline origin, stable result and once-only observer publication. Its private ordered observer owns serialized callback execution. Settlement owns failed-attempt outcome and finish timing; Wire owns aggregate teardown initiation and its winning initiator's reporting choice. No new release or teardown authority exists.

**Authority completeness:** Cover owner construction, existing test constructors, late-report producers, success transfer, failure/panic finish, and explicit/automatic Wire consumers in one slice. No persisted representation or restart state exists; every producer context transfer creates one owner. Existing gate/claim/release views remain authoritative for auth access.

**Transitional-seam budget:** None. Delete the externally supplied late callback and duplicate observer construction in the same change; no compatibility callback path or mutable test handler rebinding. The existing observer is a permanent private collaborator, not a migration seam.

**Blast radius:** Root auth lifecycle, settlement and Wire teardown plus their tests. Concurrency changes only observer ownership and once-only lifecycle composition; the two caller schedules, first-revocation budget, stable errors, release/consume overlap and reentrant notification behavior must remain unchanged. No new network I/O, dependency, public method, schema, key copy, producer release obligation, or per-accessor work is authorized. Constructor/test migration is root-private. Untraced effects are approach stops.

**Artifact classification:** Owner/caller composition is shipped behavior; once-only release/publication, revocation ordering and notification isolation are required safety enforcement. Existing and new focused tests are verification aids, not independently maintained blocking deliverables. Plans, audit and mirrors are process metadata. No maintained-aid exception or recursive fixture proof is approved.

**Representation contract:** Supported domain is the root's exclusive AuthContext transfer and its existing release-capable/non-releasing adapters; failed-Dial, successful transfer, panic cleanup, explicit initiating Close, automatic teardown, and later joining Close; immediate success/error/timeout and eventual success/distinct error; bounded conforming access/release plus the existing timeout treatment of non-conforming producers. Owner constructors/gates own the representation, not arbitrary duplicated producer values. Guarantee is canonical-subset behavioral preservation through these existing constructors, with finite representative tests; no universal completion guarantee for arbitrary producer/handler code. Quantified criteria apply only to this caller/outcome census.

**Contract closure:** Not triggered. Auth lifetime failures have material consequences, but existing end-to-end sentinels plus the small missing owner-composition cases reasonably cover the changed ordering. Multiple callers and once-state alone do not satisfy the shared second trigger. No new formal matrix or mutation program is required.

**Evidence budget:** Retain the named lifecycle, failed-Dial and Wire sentinels below. Add at most three missing owner-composition cases: concurrent start/finish sharing one result/publication; release completed before failed-settlement finish with notification withheld until finish; and automatic initiator retaining its observe route while explicit Close joins. Reuse existing blocked/panicking/reentrant handler and late-result cases rather than recreate them. One constructor/callback reference audit. No required mutations, extra platforms, statistical repetitions, or new hosted experiments. One initial fully briefed review plus at most one replacement; stop when focused evidence/repository gates pass with no unresolved stop-for-decision.

**TDD and preservation evidence:** First pin the caller-observable timing and any missing composition cases, then move observer state and both callers atomically. Retain `TestAuthContextReleaseBudgetStartsAtLogicalRevocation`, `TestAuthContextReleaseDefersUntilActiveExporterExits`, `TestAuthContextReleaseTimesOutBlockedProducerOnce`, `TestAuthContextClaimAndReleaseAreLinearizable`, `TestAuthContextExporterPanicReleasesGate`, `TestDialAuthContextReleaseTimeoutObserverSequence`, `TestDialReleaseHandlerDoesNotBlockReturn`, `TestDatagramAutomaticTeardownTimeoutObserverSequence`, `TestDatagramAutomaticReleaseTimeoutPublishesWhileCarrierCloseIsBlocked`, `TestAutomaticTeardownReleaseHandlerCanCloseWire`, explicit-close immediate-suppression/late-error coverage, settlement success-construction-panic cleanup, and existing release/consume overlap sentinels. A later release completion never edits the cached timeout or aggregate close result.

**Dispatch context budget:** This current slice, program rules, ADR-0010's lifetime/budget/notification decision, and the current settlement policy's preservation paragraph; `auth_context_lifecycle.go`, `establishment_settlement.go`, Wire lifecycle portions of `wiremux.go`, and the relevant owner/settlement/Datagram/root test constructors and named tests. Receive only the current contract and any bounded governing diff if re-audited, not full historical plans or error-tree/transport internals. Three root modules with one shared private owner fit one fresh implementation/review context. Size: Small implementation, Medium timing-preservation risk.

**Slice decision audit:** Strongest split is move observer ownership before migrating callers. Rejected: an adapter period retains two observation protocols and weakens the exact deletion criterion; both callers and test constructors fit one context. Splitting failed-Dial from Wire similarly creates a second handler/observer path. Merging with TURN is rejected because it couples unrelated resource owners and verification. No edge to T1 exists; second is value/risk ordering only.

**Stop conditions:** Changed release deadline origin, stage/disposition, key access/claims, successful transfer/panic coverage, failed-Dial publication point, automatic publication independence from carrier Close, initiator route or handler reentry; a new release owner, mutable observer rebinding, public-interface change, alternate callback protocol, broader producer guarantees, or a required second PR. Apply shared review/verification-aware stops and scoped re-audit only within the accepted contract.

## Acceptance Criteria

- [x] Root owner construction retains one immutable handler/ordered observer; successful establishment transfers that same owner.
- [x] Settlement and Wire no longer construct a release observer or pair a late callback with a separate publication call; no alternate test-only production protocol remains.
- [x] Supported failed-Dial/panic, success-transfer, explicit-initiation, automatic-initiation and joining-Close histories retain the named timing and event rules, one release obligation and one stable immediate result/publication.
- [x] Logical revocation and its deadline origin, release/consume overlap, blocked-carrier timeout visibility and nonblocking/panic-isolated/reentrant handlers match existing behavior.
- [x] The named preservation tests and repository gates pass with unchanged public interfaces, cryptographic/producer contracts and aggregate teardown responsibility.

The representation contract limits quantified criteria; the finite caller/outcome evidence and constructor audit terminate verification.

## Validation Gates

Audit the installed/base Go toolchain under AGENTS.md first. Run `go test .`, then `GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestAuthContext|TestWireClose|TestExplicitWireClose|TestDialAuthContextReleaseTimeoutObserverSequence|TestDialReleaseHandlerDoesNotBlockReturn|TestDatagramAutomatic|TestAutomaticTeardownReleaseHandlerCanCloseWire|TestEstablishmentSettlement)' -count=1 .`, then `task verify`. Required hosted `ci-*` jobs must pass at the exact final head. Do not enlarge the matrix beyond changed timing and existing gates.

## Operating Discipline

The shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice` govern, composed with repository [review-loop](../REVIEW-LOOP.md), [CI](../CI.md), [conventions](../CONVENTIONS.md), and root AGENTS.md. No repository-specific contract-closure overlay exists. The shared policies govern representation/artifact gates, semantic-family classification, precise-root comparison, finite evidence/review budgets, diagnosis before reruns and approach stops. Run exact-head local certification, same-head hosted CI, exact-head merge, then append-dev-journal and reconcile pointer-based child/parent/OmniFocus state. Administrative readiness is not code certification. ADR-0010 and settled settlement/aggregate ownership remain binding.
