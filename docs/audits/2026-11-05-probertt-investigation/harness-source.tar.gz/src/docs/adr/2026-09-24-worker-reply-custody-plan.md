# Worker reply custody Implementation Plan

**Date:** 2026-09-24
**Status:** Complete; B1 implements worker reply custody
**Track:** B of seven in program AH-20260924
**Depends on:** Nothing — independent frontier
**Program:** [2026-09-24-architecture-deepening-program.md](2026-09-24-architecture-deepening-program.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers and stop conditions
**Audit history:** [2026-09-24-architecture-handoff-audit.md](2026-09-24-architecture-handoff-audit.md)
**Parent issue:** pending

## Goal

Worker reply custody: deepen the existing module at its private interface, concentrating the caller knowledge identified below. The scope is one independently green PR, not a framework or public-interface redesign.

## Current Shape (verified 2026-09-24)

[internal/measurement/controller.go:144](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/controller.go#L144) · [internal/measurement/controller.go:215](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/controller.go#L215) · [internal/measurement/remote_timing.go:26](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/remote_timing.go#L26) · [internal/measurement/remote_witness_protocol.go:154](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/remote_witness_protocol.go#L154) · [internal/measurement/stream_worker.go:391](https://github.com/GridSwarm/wiremux/blob/a16ea1cc8c2a393aa48e4affa50ba26ae10d12a3/internal/measurement/stream_worker.go#L391)

**Governing source surface:** internal/measurement/controller.go, remote_timing.go, remote_witness_protocol.go, cancellation collector in stream_worker.go, focused custody/witness/controller tests. Read worker producers and version gates; do not change transport establishers or workload algorithms.

## Decision

### What does the owner guarantee?

For versions >=2, a complete, associated `Kind:"result"` reply remains available until one final collection transfers it. Version 1 acquires no new collection obligation and retains the explicit behavior below. Decode or run/role/PID association failure yields no retainable partial fields. A result with a worker Error still counts as final evidence. Retention never turns an unexpected message into a successful pong, armed, drained, or witness reply.

### Does expectation skip messages until it finds a match?

No. Preserve the current mismatch/error behavior. Ordinary unexpected nonterminal replies are consumed. Do not repeatedly return a retained final reply to the same phase or silently resynchronize the normal protocol. Cancellation drainage can still read later associated evidence as it does today; an error does not justify permanently poisoning the decoder.

### What is the actual storage bound?

The witness path may defer one successful drained reply followed by one interruption. That interruption may be a final result, an error, an unknown kind, or a duplicate drain. Preserve this order and rejection behavior with at most two deferred entries. Final receipt bookkeeping must refer to the retained result or transfer it; it must not create an unbounded second queue.

### Who reads and who waits?

Keep one decoder and at most one outstanding read-ahead. If a boundary timer wins, the next protocol read takes the existing read-ahead result. Never start another decoder beside it. Process disposal/wait remains responsible for closing pipes and joining that outstanding read. No permanent router goroutine or mailbox framework.

### What changes in collection?

Use explicit final-result delivery state, not presence of `PeerResult.Stream`, to know that a result was collected. Datagram results are final too. Preserve the controller’s existing version-specific success, error, and partial-result behavior; the compatibility details below constrain removal of the current armed/drained branches.

### Can timing and calibration be combined?

Keep send timestamps before encoding and receive timestamps after the awaited decode at their existing callers. Do not timestamp in the background reader. Local calibration chooses minimum RTT; remote calibration validates signs and chooses rounded uncertainty. Rounding can change ties, so retain both numerical reducers.

### What is the intended behavior improvement?

A supported early failure can retain more associated final diagnostic evidence while the run still fails with the original phase error. Successful transcripts, numerical results, qualification, shutdown timing, the 128 MiB reader limit, and process budgets must remain unchanged. This is a deliberate narrow retention improvement, not a behavior-identical cleanup.

### Which replies are real partial workload evidence?

Supported producers put workload-bearing partial evidence in Kind:result. A non-result witness carries only PID/Role. Preserve the existing armed mismatch snapshot when Result.Role is present and the drained snapshot when Stream/Datagram is present, even though they are broader than supported terminal producers. Keep these incidental snapshots separate from final-receipt state; an identity-only witness must not block recovery of a later final result.

### Normal final collection

Preserve response assignment/append, existing read-error handling, capture validation/retention, process wait, then remote result-file publication. A terminal result with Error still transfers partial evidence. Versions 2 and later accumulate worker errors; v1 immediately returns on its first read error. A wrong-kind snapshot remains a failure, not a valid terminal receipt.

### Cancellation collection: versions 2 and later

Consume an already-read, associated terminal receipt first and transfer it once to its fixed peer slot. Otherwise use existing drain-and-wait behavior. Track real terminal transfer explicitly; a Datagram result is final, while an incidental identity-only snapshot is not. Preserve snapshots if no valid terminal arrives. No partial fields from invalid JSON/association, new artifact copying, or success qualification during cancellation.

### Version 1: preserve exactly

Its current error defer disposes workers without invoking the cancellation collector. Keep the armed-error append and the final append followed by immediate error return. Do not add cancellation reads, waits, or new early-terminal aggregate publication. This deliberately leaves v1 early-phase evidence loss outside the improvement; introducing a new recovery lifecycle would enlarge the change.

### What caller branches actually disappear?

Remove explicit terminal requeues and duplicated terminal-received inference. Keep armed/drained incidental-snapshot policy at the controller, or extract it only as a behavior-preserving helper there. The deletion test does not require removing every Result.Role or Stream/Datagram branch.

### Settled decisions and non-goals

The [no-code decisions](2026-09-24-architecture-no-code-decisions.md) close adjacent directions; they are not successor slices. Preserve the existing [ADR-0010 auth-release](adr-0010-auth-context-lifecycle-ownership.md), [ADR-0011 transport disposal](adr-0011-transport-stream-disposal-capability.md), [settlement D7](2026-07-29-establishment-settlement-plan.md), [selected-I/O ownership](2026-09-22-selected-io-plan.md) and [managed-migration contract](../MANAGED-MIGRATION.md) where touched. Broader deferred upgrade directions remain governed by the [August 26 program](2026-08-26-architecture-deepening-program.md). No new domain terms are introduced: this uses the existing Wire, MigrationSession, establishment settlement, ordered choice and reply concepts. Do not expand the scope to improve neighboring behavior, uniformize intentional error projections, or create new public interfaces. Keep current successful behavior except the explicitly accepted version>=2 custody retention improvement in track B.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| B1 | COMPLETE | Worker reply custody | None | None introduced; completes its own interface migration |

## Implementation Slices

### Slice B1 — worker-reply-custody

**What it delivers:** Worker reply custody through the real owner and relevant callers, with the acceptance criteria below; one intended PR.

**Existing-work disposition:** New slice. No open implementation PR for this contract was found. Retain existing merged behavior; no unmerged branch is an established dependency. [Audit history](2026-09-24-architecture-handoff-audit.md) records the checked open work and adjacent issues. Recheck related PRs at execution preflight; audit any new overlapping work rather than adopting it silently.

**Blocked by:** None. Recommended sequencing is not a blocking edge.

**Single owner after merge:** workerProcess private reply-custody state owns validated terminal retention and one final transfer; controller owns incidental snapshots, workload phase policy and result aggregation; workerProcess process disposal owns joining its one read-ahead.

**Authority completeness:** No newly authoritative persisted fact or schema. Existing constructors, validation and affected destructive consumers are within the scoped source surface; restart round-trip is not applicable. If implementation adds persisted authority or a new constructor family, stop and re-audit before proceeding.

**Transitional-seam budget:** None introduced. Migrate the listed callers in this PR and remove obsolete caller-owned recipes. Existing representations with distinct authority remain intentional, not temporary duplicate owners. There is no unmerged removal slice or widened seam.

**Blast radius:** internal/measurement/controller.go, remote_timing.go, remote_witness_protocol.go, cancellation collector in stream_worker.go, focused custody/witness/controller tests. Read worker producers and version gates; do not change transport establishers or workload algorithms. Trace touched shared state and ordering through the named owner and preservation tests. Public APIs, wire/JSON schemas, dependencies, native routing, security/auth authority and performance guarantees remain unchanged. No benchmark or optimization claim. The only intended observable strengthening is retained associated terminal failure evidence for version>=2; v1 remains unchanged. No known untraced effect is accepted; discovering one requires scoped re-audit or an approach stop.

**Artifact classification:** The existing measurement worker is a verification aid and this accepted track maintains its reply-custody behavior: payoff is retained associated failure evidence; domain is the versioned transcripts above; owner is internal/measurement; retirement is removal with the measurement worker or replacement preserving its receipt contract. It does not become a blocker for unrelated shipped connectivity work. Its tests/adapters remain ordinary verification aids with no recursive completeness obligation. Plans, receipts and mirrors are process/traceability metadata; no new harness or CI lane is approved.

**Representation contract:** Existing JSON reply structs decoded by encoding/json under the existing output limit; existing run/role/PID association checks own admission. Supported versions 1–4 and the current witness/drain transcript grammar. Canonical-subset semantic guarantee for associated Kind:result retention in the existing version>=2 collector; v1 and incidental nonterminal snapshots preserve existing behavior. No arbitrary JSON grammar validation, resynchronization or workload framework.

**Contract closure:** Triggered for this accepted bounded invariant: workerProcess private reply-custody state owns validated terminal retention and one final transfer; controller owns incidental snapshots, workload phase policy and result aggregation; workerProcess process disposal owns joining its one read-ahead. Material consequences include loss of accepted measurement evidence or broken reader cleanup. Independently reachable semantic states below require more than a happy-path/failure pair; the compact census covers the accepted family without crossing unrelated axes. No repeated-root conclusion is asserted; any later recurrence must pass the shared exact invariant/central-owner side-by-side comparison.

| Semantic class | Disposition | Enforcement owner | Budgeted evidence | Status |
| --- | --- | --- | --- | --- |
| Early associated final result in expectation | Return original phase failure; retain for >=2 collection | reply custody | Early hello/ready/calibration cases | Covered by named tests and owner inspection |
| Invalid decode or association | No partial retainable fields | existing decoder/association admission | Existing run/role/PID rejection plus malformed case | Covered by named tests and owner inspection |
| Drain then witness or interruption | FIFO at most drain plus one interruption, including unknown/duplicate | reply custody deferred storage | Existing interleaved drain plus unknown/duplicate cases | Covered by named tests and owner inspection |
| Read-ahead versus timer/cancel | One decoder and one outstanding read; disposal joins it | workerProcess read-ahead/disposal | Existing active-reader cancellation and boundary tests | Covered by named tests and owner inspection |
| Normal/cancel collection Stream or Datagram | One terminal transfer; incidental Role snapshot is not terminal | reply custody + controller transfer consumer | Already-collected Datagram and incidental witness cases | Covered by named tests and owner inspection |
| Version 1 failure | Existing append/error/dispose behavior; no new collector | controller version gate | v1 preservation characterization | Covered by named tests and owner inspection |

**Evidence budget:** At most 10 new representative semantic cases plus the named existing regressions and mandatory repository gate. Count table subcases as cases. One normal and one focused race invocation on a successful final candidate; reruns only after diagnosed failure or relevant code changes. Zero required guard mutations; at most one central guard-bypass experiment if needed to show inherited coverage exercises its owner, with no syntax-variant campaign. No new operational/platform/repetition scope. One fully briefed fresh review, at most one replacement after accepted fixes; verification remains scoped to accepted findings. Terminate after this evidence passes with no unresolved stop-for-decision. This budget does not limit existing repository-required gates; it prevents optional evidence inflation.

**TDD and preservation evidence:** First extend TestRemoteCalibrationRetainsAssociatedTerminalResult and add TestWorkerReplyCustody for early associated final receipt, malformed/invalid association, explicit Datagram terminal transfer and incidental witness handling. Add TestWorkerReplyCustodyV1PreservesFailureFlow. At most ten new cases across these tests. Retain TestRemoteWitnessPreservesInterleavedDrain, TestRemoteWitnessPreservesPartialResultAfterInterleavedDrain, TestRemoteWitnessCancellationJoinsActiveReaders, TestRemoteWitnessPeerFailureCancelsOtherBoundaryWait, and TestRemoteControllerRetainsOnlyAssociatedPostArmResults. No altered measurement clock, qualification, window or shutdown deadline.

**Dispatch context budget:** Target at most 34,000 input tokens: this current plan and exact slice; current governing invariants from relevant ADR sections; the scoped source functions and named test bodies; current repository review/CI overlays and shared baselines; relevant unresolved findings only. No entire prior report history, duplicate historical plans or full engine dumps. No governing diff is needed for a new slice; later amendments supply a bounded current-contract diff. One owner-level change and this finite test surface must leave room for implementation, local fixes and verification in one fresh agent context. If the required context exceeds this bound or the change no longer fits one PR, re-audit before editing.

**Slice decision audit:** A terminal-retention-only slice that leaves final collection using Stream!=nil would not establish custody for Datagram; splitting witness storage from delivery would introduce competing queues. The bounded reader, retained order, collection flag and real consumers must change together. Numerical calibration and phase runners remain outside. The strongest adjacent merge case is shared files or convenient scheduling, which is insufficient: adjacent tracks can each deliver a coherent result independently. No blocker is needed for convenience. A later real dependency must be demonstrated and re-audited.

**Stop conditions:** Stop for representation/ownership change, new public authority or schema, changed protocol/timing/error policy outside this contract, inability to preserve the named outcomes, untraced shared-state effects, evidence needs beyond this budget, or a one-PR/context boundary failure. Apply the shared precise-root/representation stops to review and verification; do not expand the latest checklist. Same-child re-audit is allowed only within the accepted representation, outcome and one-PR boundary; otherwise return for decision or scoped architecture-handoff.

## Acceptance Criteria

- [x] Versions >=2 retain an associated terminal reply consumed by an early expectation and later transfer it once to the existing collector while returning the original phase failure.
- [x] Within the declared witness grammar, deferred order, one decoder/read-ahead, association rejection and process joining remain intact.
- [x] Final receipt state is independent of Stream presence; incidental snapshots remain distinct, and v1 cancellation/append behavior is unchanged.
- [x] Successful measurement transcripts, timestamps, numerical reducers, qualification and output limits remain unchanged under the named preservation tests.

The representation contract above scopes quantifiers such as “one,” “unchanged,” and “once” to the named supported constructors, consumers and semantic classes; finite named tests and source-owner inspection terminate acceptance. No exhaustive schedule or external-language proof is claimed.

## Validation Gates

Before any Go build/test command, perform the installed/base Go audit in AGENTS.md and stop below the approved floor. Write the named characterization/regression cases first. Run `go test -count=1 ./internal/measurement` and a focused race invocation through `./scripts/run-go-test-require-match.sh -race -run '^(TestWorkerReplyCustody|TestRemoteCalibration|TestRemoteWitness|TestRemoteController)' -count=1 ./internal/measurement` with `GOMAXPROCS=1 GOTOOLCHAIN=local`. Then run `task verify` for the exact final pushed head; retain head/base and results. Existing repository gates are not replaced by these focused cases. No added native-platform matrix, repetitions, fuzzing or hosted experiment. Required CI must report success (not skipped) on that same head before squash merge.

## Operating Discipline

Follow the shared `_shared/REVIEW-LOOP.md` and `_shared/CONTRACT-CLOSURE.md` baselines supplied by `$implement-architecture-slice` (reachable as `../_shared/` from its skill directory), composed with the repository [review overlay](../REVIEW-LOOP.md), [CI policy](../CI.md), [conventions](../CONVENTIONS.md), and root [AGENTS.md](../../AGENTS.md). No repository contract-closure overlay exists; use the shared baseline directly. The baselines govern artifact/representation gates, finite evidence, semantic-family closure, review and verification-aware approach stops, exact-head local certification, same-head hosted CI, merge, journal and pointer-only tracking. Do not copy or strengthen them in this plan.

After exact-head certification and same-head CI, merge, run `$append-dev-journal`, reconcile the parent/tracker frontier and complete only this slice’s OmniFocus task. Parent and OmniFocus notes carry state and pointers, not substantive contracts or certification SHAs. Dispatch is an operator action; this handoff does not launch implementation.
