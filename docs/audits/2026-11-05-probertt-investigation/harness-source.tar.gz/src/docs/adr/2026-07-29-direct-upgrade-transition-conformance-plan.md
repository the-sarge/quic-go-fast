# ADR-0006 D3 Transition-Engine Conformance — Implementation Plan

**Date:** 2026-07-29
**Status:** Accepted after Track 2 disposal/finality rebaseline; not yet implemented
**Track:** 3 of 4 in the 2026-07-29 architecture deepening program
**Depends on:** merged revised Track 2 issue #825
**Related:** ADR-0006 D3/D4, ADR-0008, ADR-0011; terminal fallback and the sequencer remain accepted separate modules
**Normative scope:** Current outcome, boundaries, exhaustive reachable-branch matrices, evidence, blockers, context budgets, and stop conditions
**Audit history:** [Stopped PR #834](https://github.com/GridSwarm/wiremux/pull/834), its [architecture stop](https://github.com/GridSwarm/wiremux/pull/834#issuecomment-5122717091), and the approach-stop/fix record on [docs PR #835](https://github.com/GridSwarm/wiremux/pull/835)

## Goal

Finish ADR-0006 D3 only after Track 2 supplies definitive Accept and Dial/Listen settlement, synchronous existing-stream Close disposal, and one persistent terminal owner. One role-parameterized table and one engine then drive every synchronized direct-upgrade phase. Every current reachable branch maps mechanically to one exact row, one action, one #825 disposition or explicit continuation, one #825 owner/disposal row, and named evidence.

## Current Shape (verified 2026-07-29 at `18a61e30e019b3c9f87a5847dd1d0a2a515f4692`)

- The current table contains 25 listener/post-commit transitions (`connect/upgrade_protocol.go:63-313`), while the shared engine begins only after commit (`connect/upgrade_protocol_engine.go:12-312`).
- `dialerUpgradeHandoff.run` owns selected-pair encode/write, ready receive/classification, commit encode/write, Dial startup, and the adapter into the post-commit engine (`connect/upgrade_dialer.go:22-182`).
- `listenerUpgradeHandoff.run` and `runPostReady` own selected-frame receive/validation, Listen/fallback, pending Accept before ready, ready encode/write, Accept/commit/cancel/timeout interleavings, and branch-local terminal composition (`connect/upgrade_listener.go:18-275`; `connect/upgrade_protocol_listener_postready.go:107-530`).
- Terminal fallback and `controlFrameSequencer` remain narrow accepted authorities, not table defects.
- Revised Track 2 moves old issue #827 under the #825 integration boundary as the persistent-owner/operation-finality component. Track 3 contains no lifecycle/resource implementation slice and cannot reinterpret stream Close, operation finality, packet claim, or dispositions.

## Decision

- **D1 — Track 2 owns lifecycle first.** Engine actions register events/resources and invoke `settleRelay`, typed `failClosed`, or `succeedDirect`; they never close a stream, Session, Listener, raw packet, or control exchange, infer transfer, assemble an ordered cleanup recipe, or form a return. A fail-closed action selects only the closed Track 2 control-disposition enum; registered owner state selects and executes the literal sequence.
- **D2 — complete the synchronized engine.** Expand backward from post-commit convergence to selected-pair synchronization, ready, commit, and transport readiness. Pre-offer Session creation, candidate gathering, offer exchange, and probing remain imperative.
- **D3 — migrate dialer in #828.** Establish the expanded engine start/action representation with the smaller role, delete `dialerUpgradeHandoff`, and discharge every D-row/census edge before listener work.
- **D4 — migrate listener in #829.** Extend the exact #828 representation through Listen, pending Accept before ready, Accept/commit interleavings, and confirmation; delete `listenerUpgradeHandoff`, `runPostReady`, compatibility helpers, and branch-local result/cleanup actions.
- **D5 — fallback stays separate.** `terminalFallbackExchange` owns blocking fallback send/await and commit race, then requests a Track 2 disposition.
- **D6 — sequencer stays separate.** `controlFrameSequencer` is the only relay-read/order authority for engine and fallback.
- **D7 — public disposition sentinels stay in #825.** #825 R3/R4 own the accepted-stream cancellation/control-error result/cause/disposal assertions. #829 tests only event selection/routing for those races and retains the #825 sentinels unchanged.
- **D8 — correct exact historical documents in #829.** Update `docs/adr/2026-07-05-upgrade-transition-authority-plan.md`, `docs/adr/2026-07-05-upgrade-deepening-program.md`, and `docs/adr/2026-07-05-third-deepening-program.md`, plus ADR-0006 implementation status, to record final engine/owner/fallback/sequencer boundaries.

**Frozen behaviors:** golden frames/phase ordering; selected-pair validation; sequencer unread during probing; fallback precedence/reasons; pre-boundary relay eligibility; post-boundary fail-closed shape/cause precedence; abort-before/retain/abort-after control disposition; completed-event preference; fresh owned budgets; Datagram agreement; direct confirmation; exact Track 2 disposal sequences; listener-owned direct stream; relay retirement after confirmation only.

**Rejected alternatives:** do not leave #827 in Track 3; fold fallback into a mega-table; absorb sequencer; cover pre-offer work; migrate both roles in one PR; keep handoff tests as parallel specification; let engine actions become lifecycle owners; or split listener pre/post-ready into two live engines.

## Slice Graph

| Slice | Delivers | Blocked by | Removes |
| --- | --- | --- | --- |
| 1 / #828 | Complete dialer synchronized engine and exact branch/test census | #825 | Dialer handoff/adapter |
| 2 / #829 | Complete listener synchronized engine, exact branch/test census, final docs | #828 | Listener driver/post-ready action surface |

## Shared Owner Mapping

Track 3 rows reference the normative Track 2 matrix and literal sequences in `docs/adr/2026-07-29-packet-socket-ownership-fact-plan.md`.

Every `failClosed(cause)` notation below is shorthand for a typed request using `abortAfterOwnedResources`, as fixed by its owner mapping; rows that preserve a different frozen behavior spell out `retainForOuterSettlement` or `abortBeforeOwnedResources`. This shorthand is not an untyped implementation overload.

| Mapping | Exact Track 2 owner/disposal |
| --- | --- |
| PRE-OP-RELAY | R1-N / Q11 |
| LISTEN-JOIN-RELAY-FAILURE | R1-LF / Q12 |
| LISTEN-JOIN-RELAY-SUCCESS | R1-LS / Q13 |
| LISTEN-DEFINITIVE-MATERIALIZED-RELAY | R1-LD / Q13-D |
| LISTEN-JOIN-FAILCLOSED-FAILURE-ABORT-BEFORE | R2-LF-B / Q12-B |
| LISTEN-JOIN-FAILCLOSED-MATERIALIZED-ABORT-BEFORE | R2-LS-B / Q13-B |
| PRE-OP-FAIL-ABORT-BEFORE | R2-NB / Q1-B |
| PRE-OP-FAIL-RETAIN | R2-NK / Q1-K |
| ACCEPTED-CANCEL | R3 / Q2 |
| ACCEPTED-CONTROL | R4 / Q2 |
| ACCEPT-JOIN-SETTLE-FAILURE | R1-A / Q0 |
| ACCEPT-JOIN-FAILCLOSED-FAILURE-ABORT-AFTER | R2-AA / Q14-A |
| ACCEPT-JOIN-FAILCLOSED-FAILURE-RETAIN | R2-AK / Q14-K |
| ACCEPT-JOIN-SUCCESS-ABORT-AFTER | R5-A / Q3-A |
| ACCEPT-JOIN-SUCCESS-RETAIN | R5-K / Q3-K |
| ACCEPT-JOIN-MATERIALIZED-ERROR-ABORT-AFTER | R5-AM / Q3-A |
| ACCEPT-JOIN-MATERIALIZED-ERROR-RETAIN | R5-KM / Q3-K |
| COMMITTED-ACCEPT-FAILURE | R6 / Q4 |
| COMMITTED-ACCEPT-SUCCESS | R7 / Q5 |
| COMMITTED-ACCEPT-MATERIALIZED-ERROR | R7-E / Q5 |
| DIAL-MATERIALIZED-FAILURE | R8 / Q6 |
| DIAL-CONVERGENCE-FAILURE | R13 / Q6 |
| DIAL-JOIN-FAILURE | R9 / Q7 |
| DIAL-DEFINITIVE-FAILURE | R9-D / Q7-D |
| DIAL-JOIN-SUCCESS | R10 / Q8 |
| DIAL-JOIN-MATERIALIZED-ERROR | R10-E / Q8 |
| LISTENER-MATERIALIZED | R12 / Q2 |
| DIAL-SUCCESS | R15 / Q9 |
| LISTENER-SUCCESS | R16 / Q10 |

## Slice 1 / #828 — Extend the engine through dialer synchronized phases

**What it delivers:** Table states/events/actions cover selected-pair encode/send, ready receive/classification, commit encode/send/registration, pending/materialized Dial, post-commit phases, Datagram agreement, confirmation, and all terminal events through #825. `dialerUpgradeHandoff` and its adapter disappear.

**Single owner after merge:** table/engine own synchronized dialer state/action; #825 owns terminal lifecycle/result/disposal; sequencer owns reads; fallback owns its mini-protocol. No second driver loop or terminal callback remains.

**Authority completeness:** dialer synchronized state begins at selected-pair encode, mutates only through one table/engine event/action, registers commit/Dial results through #825, and ends through one disposition or success transfer. A terminal source that wins while Dial is pending must be selected before asking the same #825 owner exactly once to join and register the definitive result and before the engine selects its F/S/E event; final disposition and disposal remain exclusively with #825. Overlapping phase-read failure and caller/owned-budget cancellation therefore select the context source before the owner-preserving classifier mutates runtime state. Every reachable source branch and table transition appears in the census; invalid source/result combinations are marked rejected rather than manufactured as production paths, and impossible engine states reject through D23. Attempt memory has no persistence/restart.

**Transitional-seam budget:** listener retains its existing driver/adapter as the sole remaining role boundary, and #829 removes it. No dialer adapter, terminal callback, cleanup recipe, or second transition representation remains.

**Blast radius:** table/engine start contract, dialer driver deletion, #825 owner-preserving pending-Dial join/classification, dialer/generic scenarios and maps, and the repository validation lane that keeps the accepted dialer closure tests under `-race`. Wire, public interfaces, results/errors, packet identity/disposal, timeout budgets, security, dependencies, and platforms are frozen. State allocation may change insignificantly.

**Artifact classification:** engine/table/actions are shipped interior; branch census, completeness, scenarios, and mutation are verification aids; deleted-test/source maps are process metadata.

**Representation contract:** supported domain = every reachable source branch in `connect/upgrade_dialer.go` and the shared engine, crossed only with definitive Dial-result classes that can coexist with that source, plus the explicit D23 invalid-state guard family. The table/engine are the trusted transition/action owner and #825 is the trusted Dial-result/lifecycle owner. The guarantee is universal within that finite domain: each source/result class selects one row/action and exactly one disposition or continuation. The table retains 43 named D rows, including D15-F/S/E as rejected invalid combinations rather than claimed reachable behavior. Finite evidence = the source/result reachability matrix below, source-path F/S/E tests that do not inject target events, action-outcome assertions, the 43-row/table census, focused races, golden frames, and terminal-call audit.

**Contract closure:** multiple race-sensitive states have packet/relay consequences. The engine first resolves the winning terminal-source family, including context precedence over an armed Accepted-phase read failure, then one owner-preserving classifier at the engine/#825 seam joins a pending Dial exactly once, registers its definitive nil-stream failure, stream/no-error success, or stream-plus-error materialization, and selects the matching table event; the later table action requests final #825 settlement without owning disposal. The source census closes selected/ready/commit/Dial/phase/context/Datagram/confirmation/internal-error classes without claiming unreachable Cartesian products. Another counterexample must be an unmatched reachable source/result class, multiple owner-classifier invocations for one terminal decision, a table event selected before definitive owner classification, a lost frozen source/derived cause, or an action/disposition mismatch—not a new cleanup recipe.

### Pending Dial source/result reachability

| Terminal source while Dial may be pending | Nil-stream failure | Stream/no-error success | Stream-plus-error | Enforcement/evidence disposition |
| --- | --- | --- | --- | --- |
| Caller cancellation | D13-F | D13-S | D13-E | Reachable; production source path must join through #825, then select F/S/E |
| Owned post-commit budget expiry | D14-F | D14-S | D14-E | Reachable; production source path must join through #825, then select F/S/E |
| Converged write failure | D15-F | D15-S | D15-E | Rejected invalid: the engine awaits and records definitive Dial success before attempting Converged; retain the rows only as explicit negative-space table entries and do not manufacture a source path |
| Accepted-phase read failure | D16-F | D16-S | D16-E | Reachable; Confirmed-phase reads occur only after definitive Dial success and therefore use D16-M |
| Accepted-phase fallback/wrong phase | D17-F | D17-S | D17-E | Reachable; Confirmed-phase inadmissible payloads occur only after definitive Dial success and therefore use D17-M |
| Impossible/missing post-commit transition | D23-F | D23-S | D23-E | Explicit invalid-state guard family; a controlled cursor/table fault must join through #825 before selecting F/S/E |

When an Accepted-phase read failure is already armed while caller cancellation or the owned post-commit budget also becomes visible, the context source wins before pending-Dial classification. `TestDialerEnginePendingReadErrorContextOverlap` crosses both context sources with all three definitive Dial results, asserts the exact D13-F/S/E or D14-F/S/E row and context cause, and observes exactly one Dial cancellation and one Session close. This is the finite overlap family; it does not create a general source-order Cartesian product.

Terminal action evidence is separate from table metadata: `TestDialerEngineTerminalActionOutcomes` executes every `CoordinateFallback` and `FailClosed` row through the engine and asserts relay/direct path, exact fallback reason or preserved failure cause, and the #825 terminal disposition. Source-path pending-Dial cases separately assert the originating context, read, or internal cause, while focused owner-bearing `observeDialerTransport` cases prove D12's `errNilTransportStream` and D11-V's Datagram-validation cause are derived before the table action preserves them. `TestDialerEngineReadyTimeoutSkipsLateReady` begins at `runDialer`, presents a late Ready frame after the timeout, and distinguishes D03's no-second-ready-read fallback from ordinary session cleanup; temporarily routing D03 through ordinary cleanup must make that test fail. These are verification aids and do not create another transition representation.

| ID | Semantic branch | One engine action | Disposition/continuation | Exact owner mapping | Named evidence/subtest | Status |
| --- | --- | --- | --- | --- | --- | --- |
| D01 | Selected-pair encode fails | Classify local pre-ready transport failure | `settleRelay` | PRE-OP-RELAY | `TestDialerEngineBranchMatrix/selected_encode_failure` | planned |
| D02 | Selected-pair write fails | Reject control write and request abort before owned resources | `failClosed(write cause, abortBeforeOwnedResources)` fact=false | PRE-OP-FAIL-ABORT-BEFORE | `TestDialerEngineBranchMatrix/selected_write_failure` | planned; order-sensitive |
| D03 | Ready receive reaches pre-commit timeout | Coordinate fallback without a second ready read | `settleRelay` | PRE-OP-RELAY | `TestDialerEngineBranchMatrix/ready_timeout`; `TestDialerEngineReadyTimeoutSkipsLateReady` mutation-sensitive entry test | planned |
| D04 | Ready receive returns non-timeout control error | Reject control read and request abort before owned resources | `failClosed(control cause, abortBeforeOwnedResources)` fact=false | PRE-OP-FAIL-ABORT-BEFORE | `TestDialerEngineBranchMatrix/ready_control_error` | planned; order-sensitive |
| D05 | Ready payload carries peer fallback | Preserve peer/wire reason and coordinate fallback | `settleRelay` | PRE-OP-RELAY | `TestDialerEngineBranchMatrix/ready_peer_fallback` | planned |
| D06 | Ready payload phase mismatches | Coordinate protocol-mismatch fallback | `settleRelay` | PRE-OP-RELAY | `TestDialerEngineBranchMatrix/ready_phase_mismatch` | planned |
| D07 | Commit frame encode fails before transfer | Reject local encode and retain control for outer settlement | `failClosed(encode cause, retainForOuterSettlement)` fact=false | PRE-OP-FAIL-RETAIN | `TestDialerEngineBranchMatrix/commit_encode_failure` | planned; order-sensitive |
| D08 | Commit write fails before successful publication | Reject control write without marking commit and request abort before owned resources | `failClosed(write cause, abortBeforeOwnedResources)` fact=false | PRE-OP-FAIL-ABORT-BEFORE | `TestDialerEngineBranchMatrix/commit_write_failure` | planned; order-sensitive |
| D09 | Commit write succeeds | Register commit, create/register the pending Dial operation, then start its owned budget/work | none; continue | #825 transfer + pending-Dial registration | `TestDialerEngineBranchMatrix/commit_success_registers_dial` | planned |
| D10 | Dial returns stream/no error and Datagram validation succeeds, including completed-result preference | Register materialized stream | none; continue | #825 stream registration | `TestDialerEngineBranchMatrix/dial_success_or_completed_success` under `-race` | planned |
| D11-M | Dial returns both a stream and transport error | Register materialized stream and reject transport result | `failClosed(dial cause)` | DIAL-MATERIALIZED-FAILURE | `TestDialerEngineBranchMatrix/dial_stream_with_error` | planned |
| D11-V | Dial returns stream/no error but Datagram carrier validation adds an error | Register materialized stream and reject validation | `failClosed(datagram cause)` | DIAL-CONVERGENCE-FAILURE | `TestDialerEngineBranchMatrix/dial_datagram_validation_error`; `TestDialerEngineProductionFailClosedCauses/datagram_validation` | planned |
| D11 | Dial returns error with nil stream, including completed-result preference | Register definitive failed result | `failClosed(dial cause)` | DIAL-DEFINITIVE-FAILURE | `TestDialerEngineBranchMatrix/dial_error_or_completed_error` under `-race` | planned |
| D12 | Dial returns nil stream/nil error, including completed-result preference | Register contract violation | `failClosed(errNilTransportStream)` | DIAL-DEFINITIVE-FAILURE | `TestDialerEngineBranchMatrix/dial_nil_stream_or_completed_nil`; `TestDialerEngineProductionFailClosedCauses/nil_transport_stream` under `-race` | planned |
| D13-M | Caller cancels after Dial stream registration | Select caller cause and terminate | `failClosed(context cause)` | DIAL-MATERIALIZED-FAILURE | `TestDialerEngineBranchMatrix/cancel_materialized` | planned |
| D13-F | Caller cancels while Dial pending; join returns failure | Join Dial and preserve caller cause | `failClosed(context cause)` | DIAL-JOIN-FAILURE | `TestDialerEnginePendingTerminalSourceClassification/caller_cancel/failure`; `TestDialerEnginePendingReadErrorContextOverlap/caller_cancel/failure` | planned |
| D13-S | Caller cancels while Dial pending; join returns success | Join/register Dial and preserve caller cause | `failClosed(context cause)` | DIAL-JOIN-SUCCESS | `TestDialerEnginePendingTerminalSourceClassification/caller_cancel/success`; `TestDialerEnginePendingReadErrorContextOverlap/caller_cancel/success` | planned |
| D13-E | Caller cancels while Dial pending; join returns stream-plus-error | Join/register stream and operation error, preserve caller cause, and use stream-owned disposal | `failClosed(context cause)` | DIAL-JOIN-MATERIALIZED-ERROR | `TestDialerEnginePendingTerminalSourceClassification/caller_cancel/stream_error`; `TestDialerEnginePendingReadErrorContextOverlap/caller_cancel/stream_error` | planned |
| D14-M | Owned budget expires after stream registration | Select owned-budget cause | `failClosed(context cause)` | DIAL-MATERIALIZED-FAILURE | `TestDialerEngineBranchMatrix/budget_materialized` | planned |
| D14-F | Owned budget expires while Dial pending; join fails | Join Dial and preserve budget cause | `failClosed(context cause)` | DIAL-JOIN-FAILURE | `TestDialerEnginePendingTerminalSourceClassification/budget_expiry/failure`; `TestDialerEnginePendingReadErrorContextOverlap/budget_expiry/failure` | planned |
| D14-S | Owned budget expires while Dial pending; join succeeds | Join/register Dial and preserve budget cause | `failClosed(context cause)` | DIAL-JOIN-SUCCESS | `TestDialerEnginePendingTerminalSourceClassification/budget_expiry/success`; `TestDialerEnginePendingReadErrorContextOverlap/budget_expiry/success` | planned |
| D14-E | Owned budget expires while Dial pending; join returns stream-plus-error | Join/register stream and operation error, preserve budget cause, and use stream-owned disposal | `failClosed(context cause)` | DIAL-JOIN-MATERIALIZED-ERROR | `TestDialerEnginePendingTerminalSourceClassification/budget_expiry/stream_error`; `TestDialerEnginePendingReadErrorContextOverlap/budget_expiry/stream_error` | planned |
| D15-M | Local post-commit phase send fails after stream registration | Reject exact phase send | `failClosed(control cause)` | DIAL-CONVERGENCE-FAILURE | `TestDialerEngineBranchMatrix/send_failure_materialized` | planned |
| D15-F | Local phase send fails while Dial pending; join fails | Defensively fail closed if the impossible event is injected | `failClosed(control cause)` | DIAL-JOIN-FAILURE | `TestDialerEnginePendingTerminalSourceClassification/converged_send_requires_materialized_dial`; table-action case retained | rejected invalid as a production source: Converged send waits for definitive Dial success |
| D15-S | Local phase send fails while Dial pending; join succeeds | Defensively fail closed if the impossible event is injected | `failClosed(control cause)` | DIAL-JOIN-SUCCESS | `TestDialerEnginePendingTerminalSourceClassification/converged_send_requires_materialized_dial`; table-action case retained | rejected invalid as a production source: Converged send waits for definitive Dial success |
| D15-E | Local phase send fails while Dial pending; join returns stream-plus-error | Defensively fail closed if the impossible event is injected | `failClosed(control cause)` | DIAL-JOIN-MATERIALIZED-ERROR | `TestDialerEnginePendingTerminalSourceClassification/converged_send_requires_materialized_dial`; table-action case retained | rejected invalid as a production source: Converged send waits for definitive Dial success |
| D16-M | Awaited phase returns control error after stream registration | Reject exact phase read | `failClosed(control cause)` | DIAL-CONVERGENCE-FAILURE | `TestDialerEngineBranchMatrix/read_failure_materialized` | planned |
| D16-F | Phase read fails while Dial pending; join fails | Join Dial and reject read | `failClosed(control cause)` | DIAL-JOIN-FAILURE | `TestDialerEnginePendingTerminalSourceClassification/read_failure/failure` | planned |
| D16-S | Phase read fails while Dial pending; join succeeds | Join/register Dial and reject read | `failClosed(control cause)` | DIAL-JOIN-SUCCESS | `TestDialerEnginePendingTerminalSourceClassification/read_failure/success` | planned |
| D16-E | Phase read fails while Dial pending; join returns stream-plus-error | Join/register stream and operation error, preserve read cause, and use stream-owned disposal | `failClosed(control cause)` | DIAL-JOIN-MATERIALIZED-ERROR | `TestDialerEnginePendingTerminalSourceClassification/read_failure/stream_error` | planned |
| D17-M | Awaited payload is fallback/wrong phase after stream registration | Reject inadmissible payload | `failClosed(frozen phase cause)` | DIAL-CONVERGENCE-FAILURE | `TestDialerEngineBranchMatrix/wrong_phase_materialized` | planned |
| D17-F | Wrong payload arrives while Dial pending; join fails | Join Dial and reject payload | `failClosed(frozen phase cause)` | DIAL-JOIN-FAILURE | `TestDialerEnginePendingTerminalSourceClassification/wrong_phase/failure` | planned |
| D17-S | Wrong payload arrives while Dial pending; join succeeds | Join/register Dial and reject payload | `failClosed(frozen phase cause)` | DIAL-JOIN-SUCCESS | `TestDialerEnginePendingTerminalSourceClassification/wrong_phase/success` | planned |
| D17-E | Wrong payload arrives while Dial pending; join returns stream-plus-error | Join/register stream and operation error, preserve phase cause, and use stream-owned disposal | `failClosed(frozen phase cause)` | DIAL-JOIN-MATERIALIZED-ERROR | `TestDialerEnginePendingTerminalSourceClassification/wrong_phase/stream_error` | planned |
| D18 | Valid Accepted frame is admitted, including completed-frame preference at cancellation | Record peer Datagram capability and advance | none; continue | No terminal owner call | `TestDialerEngineBranchMatrix/accepted_frame_completed_or_ordinary` under `-race` | planned |
| D19 | Valid Converged frame and Datagram capabilities agree, including completed-frame preference at cancellation | Record fixed agreement and advance | none; continue | No terminal owner call | `TestDialerEngineBranchMatrix/converged_datagram_agreement_completed_or_ordinary` under `-race` | planned; completed-frame alias |
| D20 | Datagram exposure contradicts local capability/confirmation | Reject Datagram agreement | `failClosed(datagram cause)` | DIAL-CONVERGENCE-FAILURE | `TestDialerEngineBranchMatrix/datagram_mismatch` | planned |
| D21 | Confirmed frame is admitted at cancellation boundary | Prefer completed confirmation and finalize | `succeedDirect` | DIAL-SUCCESS | `TestDialerEngineBranchMatrix/completed_confirmed_wins` under `-race` | planned |
| D22 | Ordinary accepted→converged→confirmed path completes | Close Session, retire relay, finalize direct | `succeedDirect` | DIAL-SUCCESS | `TestNegotiatorUpgradeDialerEngineHappyPath` | planned |
| D23-M | Missing/impossible transition after stream registration | Reject internal state | `failClosed(internal cause)` | DIAL-MATERIALIZED-FAILURE | `TestDialerEngineBranchMatrix/unexpected_materialized` | planned |
| D23-F | Missing/impossible transition while Dial pending; join fails | Join Dial and reject internal state | `failClosed(internal cause)` | DIAL-JOIN-FAILURE | `TestDialerEnginePendingTerminalSourceClassification/internal_failure/failure` | planned guard evidence |
| D23-S | Missing/impossible transition while Dial pending; join succeeds | Join/register Dial and reject internal state | `failClosed(internal cause)` | DIAL-JOIN-SUCCESS | `TestDialerEnginePendingTerminalSourceClassification/internal_failure/success` | planned guard evidence |
| D23-E | Missing/impossible transition while Dial pending; join returns stream-plus-error | Join/register stream and operation error, preserve internal cause, and use stream-owned disposal | `failClosed(internal cause)` | DIAL-JOIN-MATERIALIZED-ERROR | `TestDialerEnginePendingTerminalSourceClassification/internal_failure/stream_error` | planned guard evidence |

### Dialer Source Census

| Row | Exact source branch/result condition |
| --- | --- |
| D01 | `upgrade_dialer.go:33-35`: selected-pair encode returns error |
| D02 | `upgrade_dialer.go:37-41`: selected-pair write returns error |
| D03 | `upgrade_dialer.go:43-51`: ready receive returns classified pre-commit timeout |
| D04 | `upgrade_dialer.go:43-51`: ready receive returns non-timeout control error |
| D05 | `upgrade_dialer.go:52-62`: decoded ready payload is peer fallback |
| D06 | `upgrade_dialer.go:52-62`: decoded ready payload has the wrong phase |
| D07 | `upgrade_dialer.go:64-73`: commit-frame encode returns error |
| D08 | `upgrade_dialer.go:64-73`: commit-frame write returns error |
| D09 | `upgrade_dialer.go:75-80,96-107`: commit-frame write succeeds, then the pending Dial operation is created and registered before its goroutine can publish |
| D10 | `upgrade_dialer.go:99-107,141-150`, `upgrade.go:603-616`: ordinary or completed-poll Dial result is a stream/no error and Datagram validation succeeds |
| D11-M | Same Dial result source: result retains a non-nil stream and a transport error |
| D11-V | Same Dial result source: result retains a non-nil stream and Datagram carrier validation adds an error |
| D11 | Same Dial result source: result has nil stream and non-nil error |
| D12 | `upgrade_dialer.go:99-107,141-150`: ordinary or completed-poll Dial result is nil stream/nil error |
| D13-M | `upgrade_protocol_engine.go:29-34,79-83,135-138,247-256`: caller context fires after Dial stream registration |
| D13-F | Same caller-context branch while Dial is pending and definitive join fails |
| D13-S | Same caller-context branch while Dial is pending and definitive join succeeds |
| D13-E | Same caller-context branch while Dial is pending and definitive join returns stream-plus-error |
| D14-M | Same context source range: owned budget fires after Dial stream registration |
| D14-F | Same owned-budget branch while Dial is pending and definitive join fails |
| D14-S | Same owned-budget branch while Dial is pending and definitive join succeeds |
| D14-E | Same owned-budget branch while Dial is pending and definitive join returns stream-plus-error |
| D15-M | `upgrade_protocol_engine.go:101-115`: local Converged send fails after the engine has awaited and registered definitive Dial success |
| D15-F | Rejected invalid as a production source/result combination: the engine cannot attempt Converged while Dial remains pending; retained only as a defensive table entry |
| D15-S | Same rejected invalid combination with a hypothetical successful pending join; no production source may emit it |
| D15-E | Same rejected invalid combination with a hypothetical stream-plus-error join; no production source may emit it |
| D16-M | `upgrade_protocol_engine.go:202-205,245-256`: phase read fails after Dial stream registration |
| D16-F | Same phase-read branch while Dial is pending and definitive join fails |
| D16-S | Same phase-read branch while Dial is pending and definitive join succeeds |
| D16-E | Same phase-read branch while Dial is pending and definitive join returns stream-plus-error |
| D17-M | `upgrade_protocol_engine.go:206-223`: fallback/wrong-phase payload arrives after Dial stream registration |
| D17-F | Same inadmissible-payload branch while Dial is pending and definitive join fails |
| D17-S | Same inadmissible-payload branch while Dial is pending and definitive join succeeds |
| D17-E | Same inadmissible-payload branch while Dial is pending and definitive join returns stream-plus-error |
| D18 | `upgrade_protocol_engine.go:206-223` and dialer table `upgrade_protocol.go:255-278`: ordinary or completed-boundary Accepted frame is valid |
| D19 | Same engine/table range: ordinary or completed-boundary Converged frame is valid and Datagram capabilities agree |
| D20 | Same engine/table range: Datagram exposure contradicts local capability/confirmation |
| D21 | `upgrade_protocol_engine.go:140-159`: valid Confirmed frame is already completed when context becomes selectable |
| D22 | Same completion range: ordinary valid Confirmed frame completes the protocol |
| D23-M | `upgrade_protocol_engine.go:67-71,87-90,132-134`: impossible state/readiness after Dial stream registration |
| D23-F | Same impossible-state branch while Dial is pending and definitive join fails |
| D23-S | Same impossible-state branch while Dial is pending and definitive join succeeds |
| D23-E | Same impossible-state branch while Dial is pending and definitive join returns stream-plus-error |

**Evidence budget:** 43 named table rows with explicit covered or rejected-invalid status, one finite reachable source/result matrix, source-path three-shape pending-Dial join cases for D13/D14/D16/D17 and the D23 guard with exact source causes, one six-case context/read overlap family proving single classification and cleanup, one negative-space D15 ordering case, terminal action outcomes, focused production-derived D12/D11-V cause cases, the D03 late-Ready mutation, D19/D20 closure regressions, the failed-write cancellation timing regression, complete table/constructor/terminal-call censuses, retained golden/listener/integration behavior, one bounded managed-dialer standing race lane, three exact-head multicore D19 stress runs, one exact-head multicore overlap stress run at 3,000 repetitions, and the standard suite. Mutations are limited to D03, D20, source-cause removal in the four source families, and derived-cause removal in D12/D11-V; evidence aids do not recursively acquire their own closure matrix.

**Dispatch context budget:** merged Track 2/#825 API; this slice; `connect/upgrade_dialer.go`; `connect/upgrade_protocol.go`; `connect/upgrade_protocol_engine.go`; dialer/generic handoff and protocol tests; fallback/sequencer interfaces. Expected 450-700 production lines with deletion and 650-950 test/mapping lines.

**Slice decision audit:** splitting pre/post-commit retains two dialer authorities; merging listener exceeds one context. #825 → #828 is required by the terminal API. #828 → #829 is required because the listener extends this exact engine start/action representation.

**Stop conditions:** stop if a reachable source/result class lacks one action/disposition, an invalid combination must be made reachable to satisfy the matrix, pending Dial classification or final settlement bypasses #825, a second loop or result authority remains, frozen behavior changes, evidence exceeds the finite budget above, or work exceeds one PR.

### Slice 1 scoped re-audit disposition

Slice 1 retains the same child, outcome, table/engine representation, #825 owner, listener seam, and one-implementation-PR boundary. The current bounded closure matrix requires: owner-bearing dialers and listener-only generic semantics; D19 bounded completion arbitration; D20 owner-bearing classification; one #825-owned pending-Dial join/classification seam that selects F/S/E only for the reachable source/result combinations above; exact terminal action/disposition evidence including the D03 late-Ready mutation; a failed-write cancellation fast path; and a standing race lane covering the managed-dialer closure tests. D15 pending combinations remain rejected invalid rather than becoming new behavior. Terminating evidence is exactly the updated evidence budget above. After the current triggering review is verified against the exact pushed head, the slice receives at most one replacement review; another non-critical fresh root does not open another fix/review cycle. The causal comparisons, finding dispositions, run IDs, and receipts remain in [the Slice 1 scoped re-audit](2026-07-31-direct-upgrade-slice-1-reaudit.md).

The allowed replacement review exposed a same-invariant overlap counterexample before merge: a read-failure path can invoke the owner-backed classifier before context precedence is resolved, then invoke it again. This third scoped re-audit admits one final inner fix/verify cycle for that review's accepted shipped-behavior finding and its two bounded cause-evidence gaps. The cycle must preserve the same representation and #825 owner, select one terminal source before one classifier invocation, satisfy the exact updated evidence budget, and verify replacement review `20260801T005534-923b62861a7305476ea40120` against the exact pushed head. It receives no further fresh review. A new non-critical observation is deferred or stops the slice rather than reopening another cycle; only the shared baseline's directly in-scope critical-safety exception can override that ceiling. The causal comparisons, finding dispositions, run IDs, and receipts remain in [the Slice 1 scoped re-audit](2026-07-31-direct-upgrade-slice-1-reaudit.md).

## Slice 2 / #829 — Extend the engine through listener synchronized phases

**What it delivers:** The exact #828 engine covers selected-frame receipt/validation, Listen/fallback, Accept pending before ready, ready encode/write, every Accept/commit/cancel/timeout/control interleaving, post-commit phases, and success. Listener driver/post-ready switches/helpers disappear; exact historical docs are corrected.

**Single owner after merge:** one table/engine owns both-role synchronized transitions; #825 owns lifecycle/result/disposal; sequencer/fallback retain narrow authority. No listener driver, post-ready switch, compatibility alias, or parallel handoff-test specification remains.

**Authority completeness:** listener synchronized state begins at selected-frame receipt, registers Listen/Accept/commit results through #825, mutates only through one table/engine event/action, and terminates once. Publication, timeout/cancel, control, fallback, Datagram, post-commit, and success states all appear in the source census. No persistence/recovery applies.

**Transitional-seam budget:** zero. Listener adapter/driver state, post-ready switches, branch-local terminal composition, and implementation-coupled handoff authority are deleted in this slice.

**Blast radius:** listener/post-ready deletion, shared table/engine/actions, #825 registrations/dispositions, listener/handoff/Datagram tests, ADR-0006, and the three exact historical documents. Accept/commit/cancel/control concurrency is material; public interface, wire, packet claim, errors, budgets, dependencies, and platforms are frozen.

**Artifact classification:** final engine/deletions/docs are shipped interior/traceability truth; branch census, completeness, public scenarios, retained #825 sentinels, and optional mutation are verification aids; deleted-test maps are process metadata.

**Representation contract:** supported domain = every reachable branch/resource-state combination in `connect/upgrade_listener.go`, `connect/upgrade_protocol_listener_postready.go`, listener transitions in `connect/upgrade_protocol.go`, and shared engine branches. Guarantee = each event/result combination has one row/action and one disposition or explicit continuation. Finite evidence = 82 L-rows, branch-to-row census, 82 named primary cases, Track 2 canonical race sentinels, golden/order tests, deleted-test map.

**Contract closure:** Listen/Accept/commit ownership and independently reachable event orderings require full closure. The 82 rows plus source census close pending-Listen registration and every result/sequencer/context source-outcome class, every pending Accept join split into nil-stream failure, stream/no-error success, and stream-plus-error materialization, pre-ready, waiting-both, accept-first, commit-first, post-commit, context, control, Datagram, success, and internal-error classes; another counterexample must be an unmatched source/event branch or an action bypassing #825.

| ID | Semantic branch | One engine action | Disposition/continuation | Exact owner mapping | Named evidence/subtest | Status |
| --- | --- | --- | --- | --- | --- | --- |
| L01 | Selected-frame receive times out | Coordinate pre-listener fallback | `settleRelay` | PRE-OP-RELAY | `TestListenerEngineBranchMatrix/selected_timeout` | planned |
| L02 | Selected-frame receive returns control error | Reject control read and request abort before owned resources | `failClosed(control cause, abortBeforeOwnedResources)` fact=false | PRE-OP-FAIL-ABORT-BEFORE | `TestListenerEngineBranchMatrix/selected_control_error` | planned; order-sensitive |
| L03 | Selected payload carries peer fallback | Preserve reason and coordinate fallback | `settleRelay` | PRE-OP-RELAY | `TestListenerEngineBranchMatrix/selected_peer_fallback` | planned |
| L04 | Selected pair missing/disallowed | Coordinate protocol-mismatch fallback | `settleRelay` | PRE-OP-RELAY | `TestListenerEngineBranchMatrix/selected_invalid` | planned |
| L05-P | Selected pair is admitted | Create/register pending Listen before starting work that can race peer fallback | none; continue | #825 pending-Listen registration | `TestListenerEngineBranchMatrix/selected_starts_registered_listen` | planned |
| L05-F | Sequencer frame arrives while Listen is pending and classifies as wire fallback or protocol-mismatch relay fallback; joined Listen fails | Register definitive failure and coordinate the exact decoded fallback | `settleRelay` | LISTEN-JOIN-RELAY-FAILURE | `TestListenerEngineBranchMatrix/listen_sequencer_relay_failure` with wire-fallback/wrong-phase/malformed subcases | planned |
| L05-S | Same relay-eligible sequencer frame; joined result contains a listener, with or without error | Register/close returned listener and coordinate the exact decoded fallback | `settleRelay` | LISTEN-JOIN-RELAY-SUCCESS | `TestListenerEngineBranchMatrix/listen_sequencer_relay_materialized` with wire-fallback/wrong-phase/malformed subcases under `-race` | planned |
| L05-EF | Sequencer control-read error arrives while Listen is pending; joined Listen fails | Preserve the control cause, abort control before owned-resource settlement, and join Listen | `failClosed(control cause, abortBeforeOwnedResources)` fact=false | LISTEN-JOIN-FAILCLOSED-FAILURE-ABORT-BEFORE | `TestListenerEngineBranchMatrix/listen_control_error_failure` under `-race` | planned |
| L05-ES | Sequencer control-read error arrives while Listen is pending; joined result contains a listener, with or without error | Preserve the control cause, abort control before owned-resource settlement, join Listen, and close the returned listener | `failClosed(control cause, abortBeforeOwnedResources)` fact=false | LISTEN-JOIN-FAILCLOSED-MATERIALIZED-ABORT-BEFORE | `TestListenerEngineBranchMatrix/listen_control_error_materialized` under `-race` | planned |
| L05-CF | Caller context cancels while Listen is pending; joined Listen fails | Preserve the caller cause, abort control before owned-resource settlement, and join Listen | `failClosed(context cause, abortBeforeOwnedResources)` fact=false | LISTEN-JOIN-FAILCLOSED-FAILURE-ABORT-BEFORE | `TestListenerEngineBranchMatrix/listen_caller_cancel_failure` under `-race` | planned |
| L05-CS | Caller context cancels while Listen is pending; joined result contains a listener, with or without error | Preserve the caller cause, abort control before owned-resource settlement, join Listen, and close the returned listener | `failClosed(context cause, abortBeforeOwnedResources)` fact=false | LISTEN-JOIN-FAILCLOSED-MATERIALIZED-ABORT-BEFORE | `TestListenerEngineBranchMatrix/listen_caller_cancel_materialized` under `-race` | planned |
| L05-TF | Owned handoff budget expires while Listen is pending; joined Listen fails | Register definitive failure and coordinate transport-failure fallback | `settleRelay` | LISTEN-JOIN-RELAY-FAILURE | `TestListenerEngineBranchMatrix/listen_handoff_budget_failure` under `-race` | planned |
| L05-TS | Owned handoff budget expires while Listen is pending; joined result contains a listener, with or without error | Register/close returned listener and coordinate transport-failure fallback | `settleRelay` | LISTEN-JOIN-RELAY-SUCCESS | `TestListenerEngineBranchMatrix/listen_handoff_budget_materialized` under `-race` | planned |
| L06-F | Listen returns error or nil/nil with no listener | Register definitive no-listener result and coordinate fallback | `settleRelay` | PRE-OP-RELAY | `TestListenerEngineBranchMatrix/listen_failure_without_listener` | planned |
| L06-E | Listen returns both listener and error | Register/close the definitive returned listener and coordinate transport-failure fallback | `settleRelay` | LISTEN-DEFINITIVE-MATERIALIZED-RELAY | `TestListenerEngineBranchMatrix/listen_listener_with_error` | planned |
| L07 | Listen returns a listener | Register the successful Listen result/listener, then create/register pending Accept before ready publication | none; continue | #825 listener + pending-Accept registration | `TestListenerEngineBranchMatrix/listen_success_registers_accept_before_ready` | planned |
| L08-F | Ready encode fails; joined Accept result is failure | Seal/join, reject local encode, and retain control for outer settlement | `failClosed(encode cause, retainForOuterSettlement)` fact=false | ACCEPT-JOIN-FAILCLOSED-FAILURE-RETAIN | `TestListenerEngineBranchMatrix/ready_encode_accept_failure` | planned; order-sensitive |
| L08-S | Ready encode fails; joined Accept result is success | Register stream, reject local encode, and retain control for outer settlement | `failClosed(encode cause, retainForOuterSettlement)` fact=true | ACCEPT-JOIN-SUCCESS-RETAIN | `TestListenerEngineBranchMatrix/ready_encode_accept_success` | planned; order-sensitive |
| L08-E | Ready encode fails; joined Accept returns stream-plus-error | Register stream/error, preserve encode cause, retain control, and use stream-owned disposal | `failClosed(encode cause, retainForOuterSettlement)` fact=true | ACCEPT-JOIN-MATERIALIZED-ERROR-RETAIN | `TestListenerEngineBranchMatrix/ready_encode_accept_stream_error` | planned; order-sensitive |
| L09-F | Ready write fails; joined Accept result is failure | Seal/join, reject write, and request control abort after owned resources | `failClosed(write cause, abortAfterOwnedResources)` fact=false | ACCEPT-JOIN-FAILCLOSED-FAILURE-ABORT-AFTER | `TestListenerEngineBranchMatrix/ready_write_accept_failure` | planned; order-sensitive |
| L09-S | Ready write fails; joined Accept result is success | Register stream, reject write, and request control abort after owned resources | `failClosed(write cause, abortAfterOwnedResources)` fact=true | ACCEPT-JOIN-SUCCESS-ABORT-AFTER | `TestListenerEngineBranchMatrix/ready_write_accept_success` | planned; order-sensitive |
| L09-E | Ready write fails; joined Accept returns stream-plus-error | Register stream/error, preserve write cause, abort control after owned resources, and use stream-owned disposal | `failClosed(write cause, abortAfterOwnedResources)` fact=true | ACCEPT-JOIN-MATERIALIZED-ERROR-ABORT-AFTER | `TestListenerEngineBranchMatrix/ready_write_accept_stream_error` | planned; order-sensitive |
| L10-F | Accept fails before commit with no stream, including an already-completed failure preferred at the handoff-timeout boundary | Register definitive no-stream result and coordinate fallback | `settleRelay` | ACCEPT-JOIN-SETTLE-FAILURE | `TestListenerEngineBranchMatrix/precommit_accept_failure_or_completed_timeout_failure` under `-race` | planned; completed-result alias |
| L10-E | Accept returns both stream and error before commit, including an already-completed materialized error preferred at the handoff-timeout boundary | Register transfer/stream and reject the Accept error | `failClosed(accept cause)` fact=true | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/precommit_accept_stream_error_or_completed_timeout_stream_error` under `-race` | planned; completed-result alias |
| L11 | Accept succeeds before commit, including an already-completed success preferred at the handoff-timeout boundary | Register transfer/stream and start fresh commit budget | none; continue | #825 Accept registration; no terminal disposition | `TestListenerEngineBranchMatrix/accept_before_commit_or_completed_timeout_success` under `-race` | planned; completed-result alias |
| L12 | Accepted stream fails Datagram carrier validation | Register stream and reject validation | `failClosed(datagram cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/accepted_datagram_validation` | planned |
| L13 | Commit observed before Accept | Register commit and start fresh Accept budget | none; continue | #825 commit registration | `TestListenerEngineBranchMatrix/commit_before_accept` | planned |
| L14-F | Pre-commit peer fallback; joined Accept fails | Coordinate fallback after definitive failure | `settleRelay` | ACCEPT-JOIN-SETTLE-FAILURE | `TestListenerEngineBranchMatrix/peer_fallback_accept_failure` | planned |
| L14-S | Pre-commit peer fallback; joined Accept succeeds | Register stream, promote relay request, and abort control after owned resources | `failClosed(fallback cause, abortAfterOwnedResources)` | ACCEPT-JOIN-SUCCESS-ABORT-AFTER | `TestListenerEngineBranchMatrix/peer_fallback_accept_success` under `-race` | planned |
| L14-E | Pre-commit peer fallback; joined Accept returns stream-plus-error | Register stream/error, promote relay request, preserve fallback cause, and use stream-owned disposal | `failClosed(fallback cause, abortAfterOwnedResources)` | ACCEPT-JOIN-MATERIALIZED-ERROR-ABORT-AFTER | `TestListenerEngineBranchMatrix/peer_fallback_accept_stream_error` under `-race` | planned |
| L15-F | Commit-read control error; joined Accept fails | Preserve control cause and abort control after owned resources | `failClosed(control cause, abortAfterOwnedResources)` fact=false | ACCEPT-JOIN-FAILCLOSED-FAILURE-ABORT-AFTER | `TestListenerEngineBranchMatrix/control_error_accept_failure` | planned |
| L15-S | Commit-read control error; joined Accept succeeds | Register stream, preserve control cause, and abort control after owned resources | `failClosed(control cause, abortAfterOwnedResources)` fact=true | ACCEPT-JOIN-SUCCESS-ABORT-AFTER | `TestListenerEngineBranchMatrix/control_error_accept_success` under `-race` | planned; #825 R5-A canonical pending-result disposal |
| L15-E | Commit-read control error; joined Accept returns stream-plus-error | Register stream/error, preserve control cause, abort control after owned resources, and use stream-owned disposal | `failClosed(control cause, abortAfterOwnedResources)` fact=true | ACCEPT-JOIN-MATERIALIZED-ERROR-ABORT-AFTER | `TestListenerEngineBranchMatrix/control_error_accept_stream_error` under `-race` | planned; #825 R5-AM canonical pending-result disposal |
| L16-F | Handoff timeout/no commit; joined Accept fails | Coordinate fallback after definitive failure | `settleRelay` | ACCEPT-JOIN-SETTLE-FAILURE | `TestListenerEngineBranchMatrix/timeout_accept_failure` | planned |
| L16-S | Handoff timeout/no commit; joined Accept succeeds | Register stream, promote fallback request, and abort control after owned resources | `failClosed(timeout cause, abortAfterOwnedResources)` | ACCEPT-JOIN-SUCCESS-ABORT-AFTER | `TestListenerEngineBranchMatrix/timeout_accept_success` under `-race` | planned |
| L16-E | Handoff timeout/no commit; joined Accept returns stream-plus-error | Register stream/error, preserve timeout cause, promote fallback request, and use stream-owned disposal | `failClosed(timeout cause, abortAfterOwnedResources)` | ACCEPT-JOIN-MATERIALIZED-ERROR-ABORT-AFTER | `TestListenerEngineBranchMatrix/timeout_accept_stream_error` under `-race` | planned |
| L17-F | Commit completes at timeout boundary; joined Accept fails | Register commit and reject timeout | `failClosed(context cause)` | COMMITTED-ACCEPT-FAILURE | `TestListenerEngineBranchMatrix/timeout_commit_accept_failure` | planned |
| L17-S | Commit completes at timeout boundary; joined Accept succeeds | Register commit/stream and reject timeout | `failClosed(context cause)` | COMMITTED-ACCEPT-SUCCESS | `TestListenerEngineBranchMatrix/timeout_commit_accept_success` under `-race` | planned |
| L17-E | Commit completes at timeout boundary; joined Accept returns stream-plus-error | Register commit/stream/error, preserve timeout cause, and use stream-owned disposal | `failClosed(context cause)` | COMMITTED-ACCEPT-MATERIALIZED-ERROR | `TestListenerEngineBranchMatrix/timeout_commit_accept_stream_error` under `-race` | planned |
| L18 | Wire fallback is completed after timeout settlement joined a failed Accept | Preserve completed peer reason | `settleRelay` | ACCEPT-JOIN-SETTLE-FAILURE | `TestListenerEngineBranchMatrix/handoff_timeout_wire_fallback` | planned |
| L19 | Control error is completed after timeout settlement joined a failed Accept | Preserve completed control cause and abort control after owned resources | `failClosed(control cause, abortAfterOwnedResources)` fact=false | ACCEPT-JOIN-FAILCLOSED-FAILURE-ABORT-AFTER | `TestListenerEngineBranchMatrix/handoff_timeout_control_error` | planned |
| L20 | Failed Accept is completed at caller-cancel boundary | Prefer failed result, preserve caller cancellation, and abort control after owned resources | `failClosed(context cause, abortAfterOwnedResources)` fact=false | ACCEPT-JOIN-FAILCLOSED-FAILURE-ABORT-AFTER | `TestListenerEngineBranchMatrix/cancel_failed_accept_wins` under `-race` | planned |
| L21 | Successful Accept is completed at caller-cancel boundary | Prefer/register stream, then reject cancellation | `failClosed(context cause)` | ACCEPTED-CANCEL | `TestListenerEngineBranchMatrix/cancel_successful_accept_wins` under `-race` | planned; #825 R3 canonical result |
| L21-E | Stream-plus-error Accept is completed at caller-cancel boundary | Prefer/register the completed stream/error, preserve the Accept error as the completed-result cause, and use stream-owned disposal | `failClosed(accept cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/cancel_accept_stream_error_wins` under `-race` | planned |
| L22-F | Commit completes at caller-cancel boundary; joined Accept fails | Prefer/register commit, join Accept, reject cancellation | `failClosed(context cause)` | COMMITTED-ACCEPT-FAILURE | `TestListenerEngineBranchMatrix/cancel_commit_accept_failure` | planned |
| L22-S | Commit completes at caller-cancel boundary; joined Accept succeeds | Prefer/register commit/stream, reject cancellation | `failClosed(context cause)` | COMMITTED-ACCEPT-SUCCESS | `TestListenerEngineBranchMatrix/cancel_commit_accept_success` under `-race` | planned |
| L22-E | Commit completes at caller-cancel boundary; joined Accept returns stream-plus-error | Prefer/register commit/stream/error, preserve cancellation, and use stream-owned disposal | `failClosed(context cause)` | COMMITTED-ACCEPT-MATERIALIZED-ERROR | `TestListenerEngineBranchMatrix/cancel_commit_accept_stream_error` under `-race` | planned |
| L23-F | No event was observed at caller cancellation; joined Accept fails | Seal/join pre-boundary work, reject cancellation, and abort control after owned resources | `failClosed(context cause, abortAfterOwnedResources)` fact=false | ACCEPT-JOIN-FAILCLOSED-FAILURE-ABORT-AFTER | `TestListenerEngineBranchMatrix/cancel_poll_empty_accept_failure` | planned |
| L23-S | No event was observed at caller cancellation; Accept publishes before Close joins | Register stream, reject cancellation, and abort control after owned resources | `failClosed(context cause, abortAfterOwnedResources)` fact=true | ACCEPT-JOIN-SUCCESS-ABORT-AFTER | `TestListenerEngineBranchMatrix/cancel_poll_empty_accept_success` under `-race` | planned |
| L23-E | No event was observed at caller cancellation; Accept publishes stream-plus-error before Close joins | Register stream/error, preserve cancellation, abort control after owned resources, and use stream-owned disposal | `failClosed(context cause, abortAfterOwnedResources)` fact=true | ACCEPT-JOIN-MATERIALIZED-ERROR-ABORT-AFTER | `TestListenerEngineBranchMatrix/cancel_poll_empty_accept_stream_error` under `-race` | planned |
| L24 | Accept-first then valid commit | Register commit and enter post-commit engine | none; continue | #825 registrations complete | `TestListenerEngineBranchMatrix/accept_first_commit` | planned |
| L25 | Accept-first then commit-read control error | Reject control error after registered Accept | `failClosed(control cause)` | ACCEPTED-CONTROL | `TestListenerEngineBranchMatrix/accept_first_control_error` | planned; #825 R4 canonical result |
| L26 | Accept-first then peer fallback/transport-failure payload | Reject post-transfer noncommit result | `failClosed(frozen cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/accept_first_noncommit` | planned |
| L27 | Accept-first fresh commit budget expires | Reject owned budget | `failClosed(context cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/accept_first_budget_expiry` | planned |
| L28 | Accept-first caller cancellation | Reject caller cause | `failClosed(context cause)` | ACCEPTED-CANCEL | `TestListenerEngineBranchMatrix/accept_first_caller_cancel` | planned |
| L29 | Commit-first Accept succeeds | Register stream and enter post-commit engine | none; continue | #825 stream registration | `TestListenerEngineBranchMatrix/commit_first_accept_success` | planned |
| L30-F | Commit-first Accept fails with no stream | Register definitive no-stream result | `failClosed(accept cause)` | COMMITTED-ACCEPT-FAILURE | `TestListenerEngineBranchMatrix/commit_first_accept_failure_without_stream` | planned |
| L30-E | Commit-first Accept returns both stream and error | Register stream and reject the Accept error | `failClosed(accept cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/commit_first_accept_stream_with_error` | planned |
| L31-F | Commit-first peer abort; joined Accept fails | Join Accept and reject peer abort | `failClosed(peer cause)` | COMMITTED-ACCEPT-FAILURE | `TestListenerEngineBranchMatrix/peer_abort_accept_failure` | planned |
| L31-S | Commit-first peer abort; joined Accept succeeds | Register stream and reject peer abort | `failClosed(peer cause)` | COMMITTED-ACCEPT-SUCCESS | `TestListenerEngineBranchMatrix/peer_abort_accept_success` | planned |
| L31-E | Commit-first peer abort; joined Accept returns stream-plus-error | Register stream/error, preserve peer cause, and use stream-owned disposal | `failClosed(peer cause)` | COMMITTED-ACCEPT-MATERIALIZED-ERROR | `TestListenerEngineBranchMatrix/peer_abort_accept_stream_error` | planned |
| L32-F | Commit-first Accept budget expires; joined Accept fails | Join Accept and reject budget | `failClosed(context cause)` | COMMITTED-ACCEPT-FAILURE | `TestListenerEngineBranchMatrix/accept_budget_failure_result` | planned |
| L32-S | Commit-first Accept budget expires; joined Accept succeeds | Register stream and reject budget | `failClosed(context cause)` | COMMITTED-ACCEPT-SUCCESS | `TestListenerEngineBranchMatrix/accept_budget_success_result` | planned |
| L32-E | Commit-first Accept budget expires; joined Accept returns stream-plus-error | Register stream/error, preserve budget cause, and use stream-owned disposal | `failClosed(context cause)` | COMMITTED-ACCEPT-MATERIALIZED-ERROR | `TestListenerEngineBranchMatrix/accept_budget_stream_error_result` | planned |
| L33-F | Commit-first caller cancellation; joined Accept fails | Join Accept and reject caller cause | `failClosed(context cause)` | COMMITTED-ACCEPT-FAILURE | `TestListenerEngineBranchMatrix/commit_first_cancel_accept_failure` | planned |
| L33-S | Commit-first caller cancellation; joined Accept succeeds | Register stream and reject caller cause | `failClosed(context cause)` | COMMITTED-ACCEPT-SUCCESS | `TestListenerEngineBranchMatrix/commit_first_cancel_accept_success` | planned |
| L33-E | Commit-first caller cancellation; joined Accept returns stream-plus-error | Register stream/error, preserve caller cause, and use stream-owned disposal | `failClosed(context cause)` | COMMITTED-ACCEPT-MATERIALIZED-ERROR | `TestListenerEngineBranchMatrix/commit_first_cancel_accept_stream_error` | planned |
| L34 | Accepted phase encode/write fails | Reject phase send after registered stream | `failClosed(control cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/accepted_send_failure` | planned |
| L35 | Converged-frame read returns control error | Reject phase read | `failClosed(control cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/converged_control_error` | planned |
| L36 | Converged payload is fallback/wrong phase | Reject inadmissible phase | `failClosed(frozen phase cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/converged_wrong_phase` | planned |
| L37 | Datagram exposure agreement contradicts capability | Reject Datagram agreement | `failClosed(datagram cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/datagram_mismatch` | planned |
| L38 | Confirmed phase encode/write fails | Reject final phase send | `failClosed(control cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/confirmed_send_failure` | planned |
| L39 | Caller cancels during post-commit engine | Reject caller cause | `failClosed(context cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/postcommit_caller_cancel` | planned |
| L40 | Owned post-commit budget expires | Reject owned-budget cause | `failClosed(context cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/postcommit_budget_expiry` | planned |
| L41 | Accepted→converged→confirmed completes | Close Session, retire relay, return listener-owned stream | `succeedDirect` | LISTENER-SUCCESS | `TestNegotiatorUpgradeListenerEngineHappyPath` | planned |
| L42-PF | Unexpected pre-boundary state; joined Accept fails | Seal/join, reject internal state, and abort control after owned resources | `failClosed(internal cause, abortAfterOwnedResources)` fact=false | ACCEPT-JOIN-FAILCLOSED-FAILURE-ABORT-AFTER | `TestListenerEngineBranchMatrix/unexpected_pre_accept_failure` | planned |
| L42-PS | Unexpected pre-boundary state; joined Accept succeeds | Register stream, reject internal state, and abort control after owned resources | `failClosed(internal cause, abortAfterOwnedResources)` fact=true | ACCEPT-JOIN-SUCCESS-ABORT-AFTER | `TestListenerEngineBranchMatrix/unexpected_pre_accept_success` | planned |
| L42-PE | Unexpected pre-boundary state; joined Accept returns stream-plus-error | Register stream/error, preserve internal cause, abort control after owned resources, and use stream-owned disposal | `failClosed(internal cause, abortAfterOwnedResources)` fact=true | ACCEPT-JOIN-MATERIALIZED-ERROR-ABORT-AFTER | `TestListenerEngineBranchMatrix/unexpected_pre_accept_stream_error` | planned |
| L42-CF | Unexpected committed state; joined Accept fails | Join Accept and reject internal state | `failClosed(internal cause)` | COMMITTED-ACCEPT-FAILURE | `TestListenerEngineBranchMatrix/unexpected_commit_accept_failure` | planned |
| L42-CS | Unexpected committed state; joined Accept succeeds | Register stream and reject internal state | `failClosed(internal cause)` | COMMITTED-ACCEPT-SUCCESS | `TestListenerEngineBranchMatrix/unexpected_commit_accept_success` | planned |
| L42-CE | Unexpected committed state; joined Accept returns stream-plus-error | Register stream/error, preserve internal cause, and use stream-owned disposal | `failClosed(internal cause)` | COMMITTED-ACCEPT-MATERIALIZED-ERROR | `TestListenerEngineBranchMatrix/unexpected_commit_accept_stream_error` | planned |
| L42-M | Unexpected state after stream registration | Reject internal state | `failClosed(internal cause)` | LISTENER-MATERIALIZED | `TestListenerEngineBranchMatrix/unexpected_materialized` | planned |

### Listener Source Census

| Row | Exact source branch/result condition |
| --- | --- |
| L01 | `upgrade_listener.go:39-47`: selected-frame receive returns classified timeout |
| L02 | Same receive branch returns non-timeout control error |
| L03 | `upgrade_listener.go:48-58`: decoded selected payload is peer fallback |
| L04 | Same decoded payload is missing/disallowed |
| L05-P | `upgrade_listener.go:59-75` and `upgrade.go:559-579`: valid selected pair creates/registers the pending Listen operation before the operation goroutine or peer-fallback selection |
| L05-F | `upgrade.go:581-598`, `control_codec.go:549-570`, and `upgrade_listener.go:62-75`: sequencer produces a wire-fallback or nonfallback payload decoded to protocol mismatch while Listen is pending and definitive Listen join fails |
| L05-S | Same relay-eligible sequencer source and definitive Listen result contains a listener, with or without error |
| L05-EF | Same sequencer source produces a control-read error while Listen is pending and definitive Listen join fails |
| L05-ES | Same control-error source and definitive Listen result contains a listener, with or without error |
| L05-CF | `upgrade.go:581-601`: caller cancellation makes the shared handoff context done while Listen is pending and definitive Listen join fails |
| L05-CS | Same caller-cancellation source and definitive Listen result contains a listener, with or without error |
| L05-TF | Same context source expires from its owned handoff deadline while caller context remains live and definitive Listen join fails |
| L05-TS | Same owned-budget source and definitive Listen result contains a listener, with or without error |
| L06-F | Same range: definitive Listen result has no listener and returns error or nil/nil |
| L06-E | Same range: definitive Listen result contains both listener and error |
| L07 | `upgrade_listener.go:62-84`: successful Listen result/listener is registered, then pending Accept is created/registered before ready publication |
| L08-F | `upgrade_listener.go:86-97`: ready encode fails and definitive Accept join fails |
| L08-S | Same ready-encode branch and definitive Accept join succeeds |
| L08-E | Same ready-encode branch and definitive Accept join returns stream-plus-error |
| L09-F | Same range: ready write fails and definitive Accept join fails |
| L09-S | Same ready-write branch and definitive Accept join succeeds |
| L09-E | Same ready-write branch and definitive Accept join returns stream-plus-error |
| L10-F | `upgrade_protocol_listener_postready.go:133-177,184-235` and `upgrade.go:603-616`: first Accept result before commit has no stream and returns error or nil/nil; this includes the nonblocking completed-result preference at lines 143-148 when handoff timeout becomes selectable |
| L10-E | Same first-Accept source and completed-timeout preference: result retains both stream and transport error |
| L11 | Same first-Accept source and completed-timeout preference: result returns a stream before commit |
| L12 | Same first-Accept branch or `upgrade_listener.go:198-229`: returned stream fails Datagram carrier validation |
| L13 | `upgrade_protocol_listener_postready.go:133-174,184-235`: first commit result is valid while Accept remains pending |
| L14-F | Same first-commit range: payload is peer fallback and definitive Accept join fails |
| L14-S | Same peer-fallback branch and definitive Accept join succeeds |
| L14-E | Same peer-fallback branch and definitive Accept join returns stream-plus-error |
| L15-F | Same first-commit range: read returns control error and definitive Accept join fails |
| L15-S | Same control-error branch and definitive Accept join succeeds |
| L15-E | Same control-error branch and definitive Accept join returns stream-plus-error |
| L16-F | `upgrade_protocol_listener_postready.go:138-169,396-433`: handoff budget expires without commit and definitive Accept join fails |
| L16-S | Same handoff-timeout branch and definitive Accept join succeeds |
| L16-E | Same handoff-timeout branch and definitive Accept join returns stream-plus-error |
| L17-F | Same timeout range: completed valid commit wins and definitive Accept join fails |
| L17-S | Same completed-commit branch and definitive Accept join succeeds |
| L17-E | Same completed-commit branch and definitive Accept join returns stream-plus-error |
| L18 | Same timeout range after failed-Accept settlement: completed wire fallback wins |
| L19 | Same failed-Accept timeout range: completed control error wins |
| L20 | `upgrade_protocol_listener_postready.go:170-174,65-85`: failed Accept is completed when caller cancellation becomes selectable |
| L21 | Same cancellation boundary: successful Accept is completed |
| L21-E | Same cancellation boundary: stream-plus-error Accept is completed |
| L22-F | Same cancellation boundary: valid commit is completed and definitive Accept join fails |
| L22-S | Same completed-commit branch and definitive Accept join succeeds |
| L22-E | Same completed-commit branch and definitive Accept join returns stream-plus-error |
| L23-F | Same cancellation range: nonblocking poll observes no event and definitive Accept join fails |
| L23-S | Same empty-poll branch and Accept publishes success before caller-visible Close completes its join |
| L23-E | Same empty-poll branch and Accept publishes stream-plus-error before caller-visible Close completes its join |
| L24 | `upgrade_protocol_listener_postready.go:271-348` and listener table `upgrade_protocol.go:165-227`: Accept-first state receives valid commit |
| L25 | Same Accept-first range: commit read returns control error |
| L26 | Same Accept-first range: commit payload is fallback/transport failure/wrong phase |
| L27 | Same Accept-first range: fresh commit budget expires |
| L28 | Same Accept-first range: caller context fires |
| L29 | `upgrade_protocol_listener_postready.go:350-393`, `upgrade_listener.go:198-229`, and listener table `upgrade_protocol.go:165-227`: commit-first Accept returns valid stream |
| L30-F | Same commit-first branch: definitive Accept result has no stream and returns error or nil/nil |
| L30-E | Same commit-first branch: definitive Accept result retains both stream and transport error |
| L31-F | Same commit-first range: peer abort wins and definitive Accept join fails |
| L31-S | Same peer-abort branch and definitive Accept join succeeds |
| L31-E | Same peer-abort branch and definitive Accept join returns stream-plus-error |
| L32-F | Same commit-first range: Accept budget expires and definitive Accept join fails |
| L32-S | Same Accept-budget branch and definitive Accept join succeeds |
| L32-E | Same Accept-budget branch and definitive Accept join returns stream-plus-error |
| L33-F | Same commit-first range: caller context fires and definitive Accept join fails |
| L33-S | Same caller-context branch and definitive Accept join succeeds |
| L33-E | Same caller-context branch and definitive Accept join returns stream-plus-error |
| L34 | `upgrade_protocol_engine.go:101-115` and listener post-commit table `upgrade_protocol.go:231-254`: Accepted-phase encode/write fails |
| L35 | `upgrade_protocol_engine.go:202-223,245-256` and the same table: Converged-frame read returns control error |
| L36 | Same Converged range: decoded payload is fallback/wrong phase |
| L37 | Same Converged range: Datagram exposure contradicts capability |
| L38 | `upgrade_protocol_engine.go:101-115` and the same table: Confirmed-phase encode/write fails |
| L39 | `upgrade_protocol_engine.go:29-34,79-83,135-138,247-256`: caller context fires during the post-commit engine |
| L40 | Same context source range: owned post-commit budget fires |
| L41 | `upgrade_protocol_engine.go:140-159` and the listener post-commit table: valid confirmation completes |
| L42-PF | `upgrade_protocol_listener_postready.go:184-235,516-530`: unexpected pre-boundary state and definitive Accept join fails |
| L42-PS | Same unexpected pre-boundary state and definitive Accept join succeeds |
| L42-PE | Same unexpected pre-boundary state and definitive Accept join returns stream-plus-error |
| L42-CF | `upgrade_protocol_listener_postready.go:350-393,516-530`: unexpected committed state and definitive Accept join fails |
| L42-CS | Same unexpected committed state and definitive Accept join succeeds |
| L42-CE | Same unexpected committed state and definitive Accept join returns stream-plus-error |
| L42-M | `upgrade_protocol_listener_postready.go:271-348,516-530` or `upgrade_protocol_engine.go:67-71,87-90,132-134`: unexpected state after stream registration |

**Evidence budget:** 82 semantic rows/82 named primary subcases, one 82-row mechanical branch map, complete two-role table census, retained #825 R3/R4 public sentinels plus R5-A/R5-K/R5-AM/R5-KM pending-result sentinels, explicit complete pending-Listen source/outcome/result races, three-shape pending-Accept join races, resource-plus-error/operation-registration/event-result preference races, golden wire/Datagram/order gates, deleted-test one-to-one map, standard suite, optional one central engine mutation.

**Dispatch context budget:** merged #825 and #828; this slice; `connect/upgrade_listener.go`; `connect/upgrade_protocol_listener_postready.go`; `connect/upgrade_protocol.go`; shared engine; listener/handoff/Datagram tests; fallback/sequencer; `docs/adr/adr-0006-upgrade-module-single-type-family.md`; `docs/adr/2026-07-05-upgrade-transition-authority-plan.md`; `docs/adr/2026-07-05-upgrade-deepening-program.md`; `docs/adr/2026-07-05-third-deepening-program.md`. Expected 700-1,050 production lines with substantial deletion and 1,000-1,450 test/mapping lines.

**Slice decision audit:** splitting pre/post-ready leaves two live Accept/commit engines and repeats PR #834; merging #828 exceeds one context. #828 → #829 is necessary because this slice extends its exact representation.

**Stop conditions:** stop if an L-row lacks one action/disposition, a source branch is unmatched, Accept/commit event needs a second state machine, an action bypasses #825, #825 canonical sentinels are weakened/duplicated, fallback/sequencer must be absorbed, frozen behavior changes, or the work exceeds one PR.

## Acceptance Criteria

- [ ] **C1:** #828 leaves one table/engine for all 43 dialer rows and no dialer driver/second loop.
- [ ] **C2:** #829 leaves the same engine for all 82 listener rows and no listener driver/post-ready switch/compatibility alias/second loop.
- [ ] **C3:** Every reachable branch in the four governing source files and shared engine maps to exactly one row; no default, unmatched return, or convenience alias remains.
- [ ] **C4:** Every row has one action and one disposition or explicit continuation, exact #825 owner/disposal mapping, named evidence, and status.
- [ ] **C5:** R3/R4 remain canonical public race sentinels; #829 event-selection cases are non-overlapping and reference them.
- [ ] **C6:** Fallback and sequencer stay separate; no engine action performs resource disposal or result formation.
- [ ] **C7:** Every deleted test maps to a retained/new public scenario or pure table/classifier/#825 test.
- [ ] **C8:** ADR-0006 and all three named 2026-07-05 documents describe final boundaries.

## Validation Gates

Run the base-toolchain audit, then for each slice:

```bash
GOTOOLCHAIN=local go version
go version
go env GOTOOLCHAIN GOFLAGS GOPROXY GOSUMDB GOINSECURE GOPRIVATE GONOPROXY GONOSUMDB GOVCS
GOTOOLCHAIN=local go test ./connect/... -count=1
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestNegotiatorUpgrade|TestDirectUpgradeProtocol|TestDialerEngine.*|TestListenerEngineBranchMatrix|TestAttemptResources)' -count=1 ./connect
task verify
```

Each PR records the row-to-source map, row-to-test map, deleted-test map, terminal-call audit, and zero unmatched branches. For #829 also run:

```bash
rg -n '2026-07-05-' docs/adr/2026-07-29-direct-upgrade-transition-conformance-plan.md
```

## Operating Discipline

The shared review-loop and contract-closure baselines referenced by `$architecture-handoff` and `$implement-architecture-slice` govern. Merge/journal #828 before #829. Each implementation slice gets one initial plus at most one replacement review, exact-head certification, same-head hosted CI, merge, journal, and synchronized tracking. Stop rather than reinterpret Track 2 disposal/finality, retain a second authority, leave an unmatched branch, expand representation, absorb fallback/sequencer, or exceed one PR.
