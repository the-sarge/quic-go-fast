# Native-Gap Execution Program — 2026-10-19

**Status:** Accepted; implementation in progress (Tracks 1, 2, 5 and 6 and slices 3.1, 3.2 and 3.4 complete; slice 3.3 deferred)
**Program:** NG-20261019
**Decided by:** the wayfinder map [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794), packaged by [Package the decided native-gap execution as dispatchable issues](https://github.com/GridSwarm/wiremux/issues/1871)
**Audit history:** [2026-10-19-native-gap-handoff-audit.md](2026-10-19-native-gap-handoff-audit.md)
**Tracking issue:** [#1908](https://github.com/GridSwarm/wiremux/issues/1908)

## What this is

This is the dispatch index for the native-gap program: the execution of every lever the wayfinder map decided for closing the gap between wiremux's native QUIC path and kernel TCP, toward the per-platform targets set in [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797). The seven linked plans are the normative source of truth. The map's tickets hold the reasoning and the measurements; each plan quotes the decided behaviour, gates and ordering, and links the deciding resolution. This index records stable track identity, cross-track edges, the frontier, outcomes closed without code, the decisions this packaging pass made on the owner's behalf, and the rules that bind every track.

The program spans two repositories. wiremux slices (Tracks 1–3 and 5–7) are dispatched here with `$implement-architecture-slice`. The fork changes (Track 4's eleven fork slices) were decided here and are executed in the-sarge/quic-go-fast's tracker, under one bundle-release issue, as self-contained public briefs; the fork is public and wiremux is private, so those briefs carry no wiremux links or private host names. Track 4's plan holds the consumer's normative requirements for each fork slice and the consumer gate tasks wiremux runs on the fork's changes.

Every figure below and in the plans is one native Wire at MTU 1500 and a sub-millisecond round trip, with an otherwise idle consumer, packets per second first, Datagrams at a consumer-sized heap (`-ballast 64 -gc-role both`) with the default-GC row beside it, measured with the rig on branch `codex/native-gap-rig` (never merged) under its [PROTOCOL.md](https://github.com/GridSwarm/wiremux/blob/b47a253a/cmd/nativerig/PROTOCOL.md).

## Targets

| Platform | Cell | Floor | Certified by |
| --- | --- | --- | --- |
| macOS | `tb` (two Apple-silicon Macs, Thunderbolt Bridge) | Datagrams at the pin ≥ 420k/s (≥ 4.7 Gbit/s at 1,397-byte Datagrams); stream ≥ 440k packets/s (≥ 4.8 Gbit/s) | Slice 7.1 |
| Linux | `netns` shape cell | Datagrams at the pin ≥ 10.0 Gbit/s at 1,397-byte Datagrams (about 895k/s); stream ≥ 10.5 Gbit/s | Slice 7.2 |
| Windows | `winvm` (Windows Server 2025 VM receiving from its Linux host) | faster / slower receive queue: Datagrams at the pin (1,024 queue) ≥ 300k/s / ≥ 225k/s; stream at the pin ≥ 350k packets/s (≥ 3.8 Gbit/s) / ≥ 260k packets/s (≥ 2.85 Gbit/s) | Slice 7.3 |

Floors are quoted from [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) and [Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572). Each slice has its own gate and the target is their sum, so "a certification below a floor files a diagnosis issue and reverts nothing." Linux figures are shape-cell estimates (no representative Linux hardware, by the owner's ruling) and Windows figures come from one virtual NIC.

## Outcomes that require no implementation

Each item is closed by its deciding ticket; the plans repeat only the ones that bound a slice.

- **The fork's ownership-taking Datagram APIs** (`SendDatagramOwned` and the release callback) were dropped: about 0.37–0.39 sender CPU-s/GiB saved and no rate gain once the deeper queues are in ([Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084)). **Revisit if:** a Linux Datagram certification misses its floor with the sender's CPU as the measured bound.
- **Batching four records per `Write`** was jumbo-only (about 0.8% at MTU 1500) and moved to the jumbo seed ([How should the reliable Wire hand channel records to QUIC?](https://github.com/GridSwarm/wiremux/issues/1822#issuecomment-6064821976), [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797)). Pipelined sealing and larger records were rejected on merit.
- **A native send with no wiremux hop** was rejected: it would change the admission bound and showed unexplained loss ([Which per-Datagram cost reductions should native Datagrams adopt?](https://github.com/GridSwarm/wiremux/issues/1826#issuecomment-6148612825)). `none: rejected on merit`.
- **A wiremux-owned Linux `recvmmsg`** was rejected: Linux receives stay on `x/net`'s batch read ([Should Linux native receives own recvmmsg to drop x/net's per-message address allocations?](https://github.com/GridSwarm/wiremux/issues/1831#issuecomment-6195696608)). **Revisit if:** Go ships a non-allocating batch read (the binding switches), or coalescing is rejected and a Linux stream target needs the ~2%.
- **Connected native sockets on Linux** were rejected (no measured gain; ECN rides a control message on every send), and Windows connected sockets and batched calls are out of scope ([Should the native path use a connected socket per peer?](https://github.com/GridSwarm/wiremux/issues/1843#issuecomment-6207453285)). **Revisit if:** ECN moves to a socket option and a real NIC shows a gain.
- **Unconnected native sends keep their packet-info record** on every platform; macOS drops it only on the connected socket in Slice 2.2 ([Should native listener sends drop the packet-info record when the socket is bound to one address?](https://github.com/GridSwarm/wiremux/issues/1852#issuecomment-6208159922)). **Revisit if:** Linux or Windows connects native sockets; their connected sends must then carry no packet info.
- **Network.framework** is not a lever now ([Can Network.framework's user-space networking beat BSD sockets for a native flow on macOS?](https://github.com/GridSwarm/wiremux/issues/1817#issuecomment-6182807238)). **Revisit if:** connected sockets are adopted, a batched send on them is tried, and the sender is still the wall by a margin worth cgo, measured on an Ethernet cell.
- **No raised class for the receiving Mac's receive goroutine or run loop**; the adopted send raise stays on the receiving peer ([Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?](https://github.com/GridSwarm/wiremux/issues/1868#issuecomment-6251637328)). **Revisit if:** batched receives don't become the lasting macOS shape, or the targets need a busy receiving Mac's rate.
- **The busy-goroutine stall is answered by a documented consumer rule, not a fix**; a Go runtime change that polls the network from the scheduler is out of scope ([Should native throughput targets require consumer headroom, or should wiremux pursue a scheduler fix?](https://github.com/GridSwarm/wiremux/issues/1867#issuecomment-6245076072)). A stricter four-free-processor rule was rejected on merit.
- **The fork's own Darwin `recvmsg_x` reader stays retired.** It engages only on a bare `*net.UDPConn`, so it never runs on wiremux's path; wiremux's batched receive (Slice 6.4) uses fork read slots instead ([Should macOS receives be batched with recvmsg_x in the fork and wiremux?](https://github.com/GridSwarm/wiremux/issues/1816#issuecomment-6219113617), superseded by [Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863#issuecomment-6235627888)).
- **No fork "discovery settled" signal** unless Slice 1.2's gate shows Wires regularly promoted mid-search; then it is filed as a follow-up outside this program ([How should the native Datagram ceiling follow path MTU discovery?](https://github.com/GridSwarm/wiremux/issues/1819#issuecomment-6064664332)).
- **Separate future efforts** (seed issues, not part of this program): [Future effort: jumbo frames for native Wires](https://github.com/GridSwarm/wiremux/issues/1872), [Future effort: several paths per native Wire](https://github.com/GridSwarm/wiremux/issues/1873), [Future effort: the macOS native sender past the batched-send list path](https://github.com/GridSwarm/wiremux/issues/1874), [Future effort: native Wires at long round trips](https://github.com/GridSwarm/wiremux/issues/1875).
- **Out of scope by the map:** GridCast's own pipeline limits, congestion-control choice (the fork's BBR map), Linux measurement on representative hardware, the Linux GSO pair past about 11.9 Gbit/s, real-consumer GC marks, and a busy receiver's standing queue (recorded in the busy-consumer table and the received-DATAGRAM discard count, public from Slice 3.4).
- **No new ADR.** Slice 2.2 amends [ADR-0016](adr-0016-native-binding-admission-failures.md)'s "Other socket errors" bullet; ADR-0009 needs no amendment for the ceiling change (its lifetime-fixed, per-Wire ceiling clause covers it). Domain terms added by slices: Never-blocking goroutine and Processor headroom (Slice 3.2), and Late read (Slice 3.3, with the count).

## Tracks, dependencies, and frontier

| # | Track | Plan | Parent issue | Blocked by | Slices | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Native send path | [2026-10-19-native-send-path-plan.md](2026-10-19-native-send-path-plan.md) | pending | None | 3 | Complete (1.1, 1.2, 1.3) |
| 2 | Native binding and receive path | [2026-10-19-native-binding-receive-plan.md](2026-10-19-native-binding-receive-plan.md) | pending | [Native Wire: a route refusal or a briefly unassigned source address ends the connection instead of dropping the datagram](https://github.com/GridSwarm/wiremux/issues/1880) (closed); 2.1 (complete) for 2.2 and 2.3; 3.1 (complete) for 2.2 | 3 | Complete (2.1, 2.2, 2.3) |
| 3 | Native observability and published targets | [2026-10-19-native-observability-plan.md](2026-10-19-native-observability-plan.md) | [#1911](https://github.com/GridSwarm/wiremux/issues/1911) | 3.4 by 5.1 / #1925 (complete); no 3.3 → 3.4 edge | 4 | 3.1, 3.2 and 3.4 complete; 3.3 / #1924 deferred by owner decision on 2026-10-23; no active frontier |
| 4 | The one fork bundle: consumer requirements and gates | [2026-10-19-fork-bundle-plan.md](2026-10-19-fork-bundle-plan.md) | pending | 3.1 (complete) for the consumer tasks | 11 fork slices + 7 consumer tasks | Consumer tasks complete (4.R and 4.G1–4.G6, the last on 2026-10-22); the bundle release is the fork's ([quic-go-fast#851](https://github.com/the-sarge/quic-go-fast/issues/851)) |
| 5 | Fork bundle adoption | [2026-10-19-bundle-adoption-plan.md](2026-10-19-bundle-adoption-plan.md) | [#1913](https://github.com/GridSwarm/wiremux/issues/1913) | 5.1 complete; release/consumer prerequisites satisfied | 6 | Complete (5.P1, 5.P2, 5.1–5.4) |
| 6 | macOS native stack after the bundle | [2026-10-19-macos-native-stack-plan.md](2026-10-19-macos-native-stack-plan.md) | pending | 5.1 and 2.2 complete (and 3.2 complete for 6.2); internal child edges remain | 4 | Complete (6.1–6.4; 6.4 in [#2029](https://github.com/GridSwarm/wiremux/pull/2029)) |
| 7 | Native throughput certification | [2026-10-19-native-certification-plan.md](2026-10-19-native-certification-plan.md) | [#1915](https://github.com/GridSwarm/wiremux/issues/1915) | Product prerequisites and Task 7.R complete | 3 product slices + 1 rig task | Complete (7.1 in [#2035](https://github.com/GridSwarm/wiremux/pull/2035), 7.2 in [#2036](https://github.com/GridSwarm/wiremux/pull/2036), 7.3 in [#2050](https://github.com/GridSwarm/wiremux/pull/2050); Windows 3/4 floors missed with [#2045](https://github.com/GridSwarm/wiremux/issues/2045), Arm pending) |

The program runs in four phases, from [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) section 5: wiremux-only slices with no fork release (Tracks 1–3); the one fork bundle (Track 4, executed in the fork); wiremux's adoption of the bundle release (Tracks 5 and 6); and one certification per platform after its last slice (Track 7).

Cross-track edges (A → B means B is blocked by A):

- [Native Wire: a route refusal or a briefly unassigned source address ends the connection instead of dropping the datagram](https://github.com/GridSwarm/wiremux/issues/1880) closing (ADR-0016's implementation, outside this program) → 2.1, 2.2 and 3.3.
- 2.1 → 2.2, 2.3, 6.3 and 6.4. 2.2 → 6.1, 6.2 and 6.3.
- 3.1 → Task 4.R (rig readiness) → Tasks 4.G1–4.G6. 3.1 → 5.1 (the evidence record reads the drop counts through its seam). 3.1 → 2.2 (2.2 adds its connect-failure count to the seam).
- 4.G1, 4.G2, 4.G4 and 4.G5 → 5.1; 4.G3 → 5.1 only if fork slice F8 ships in the release, and 4.G6 → 5.1 only if F11 does. 4.G1, 4.G2 and 4.G4 → 4.G5 (gluing is measured on a candidate carrying those slices).
- 5.P1 and 5.P2 → 5.1; neither prerequisite blocks the other.
- The fork's bundle release → 5.1 → 5.2, 5.3, 5.4, 6.1, 6.2, 6.3 and 6.4. 6.1 → 6.3 → 6.4. 5.2 is blocked by 5.1 because fork slice F2 exists only in the release 5.1 moves the fork lane to.
- 3.2 → 3.3, 6.2 and every certification slice (3.2 creates the targets document; 6.2 rewrites its launch-context section; 7.x fill it).
- 5.1 / [#1925](https://github.com/GridSwarm/wiremux/issues/1925) (complete) → 3.4 / [#1969](https://github.com/GridSwarm/wiremux/issues/1969), the public received-DATAGRAM full-queue count. 3.3 is independent. The count must ship in the bundle-adoption wiremux tag GridCast consumes; publishing that tag remains separate work.
- Task 7.R (certification payload readiness) → 7.1, 7.2 and 7.3. It is a bounded never-merged rig task under Track 7, not a fourth product PR; completed Task 4.R remains complete.
- 7.1 is blocked by 1.1, 1.2, 1.3, 2.3, 3.2, 5.2, 6.2 and 6.4. 7.2 is blocked by 1.1, 1.2, 1.3, 2.3, 3.2, 5.2, 5.3, 6.1 and the adoption of a release carrying fork slice F10. 7.3 is blocked by 1.1, 1.2, 1.3, 2.3, 3.2, 5.2, 5.4 and 6.1, and its record names the Linux sender peer's levers. Each certification measures every adopted lever that ships on its platform; acknowledging every 16 (6.1) applies to native transports everywhere.

Serialization without an edge:

- 1.2, 1.3 and 2.2 land one at a time; they share promotion and binding code.
- 5.3 and 5.4 land one after the other, in either order, on `internal/nativequic/endpoint.go` L222.
- The second PR of [Native Wire: a route refusal or a briefly unassigned source address ends the connection instead of dropping the datagram](https://github.com/GridSwarm/wiremux/issues/1880) (the native adapter's report-as-written sends, send counts and idle-timeout cause) rewrites `internal/nativequic/promote.go`, `candidate.go`, `endpoint.go`, `packetconn.go` and the `NativeCandidate.Promote` godoc. 1.2, 1.3, 3.1 and 3.2 land before or after it in either order, and re-anchor by function at their preflight.
- The ruleset forces up-to-date branches, so any two slices that touch the same file merge serially in practice.

Fork-side ordering (normative in Track 4):

- Slices F1–F6 hold the bundle release.
- F7–F11 never hold it: "the bundle ships without whichever of them isn't ready, and it goes in the next fork release".
- F5 never ships ahead of F1, and F8 lands after F4.
- F10 never ships ahead of F1 and F5, and F11 never lands ahead of F1 and F3.
- If a never-hold slice slips to a later fork release, the wiremux slices that need it wait for that release, and the operator runs a scoped `/architecture-handoff` to add the second repin.

**Certification frontier rule:** [Task 7.R — Prepare the certification payload](2026-10-19-native-certification-plan.md#task-7r--prepare-the-certification-payload) / [#2034](https://github.com/GridSwarm/wiremux/issues/2034) is complete. Linux 7.2 / [#1934](https://github.com/GridSwarm/wiremux/issues/1934) is complete in [#2036](https://github.com/GridSwarm/wiremux/pull/2036), with both floors met. macOS 7.1 / [#1933](https://github.com/GridSwarm/wiremux/issues/1933) is complete in [#2035](https://github.com/GridSwarm/wiremux/pull/2035), with both floors met. Windows 7.3 / [#1935](https://github.com/GridSwarm/wiremux/issues/1935) is complete in [#2050](https://github.com/GridSwarm/wiremux/pull/2050), with 3 of four floors missed and [#2045](https://github.com/GridSwarm/wiremux/issues/2045) owning diagnosis; Arm remains pending. No active certification frontier remains and no successor becomes ready from this completion. The [program tracker](https://github.com/GridSwarm/wiremux/issues/1908) owns live closure and readiness. Each certification product PR owns its own committed completion/frontier transition. Track 6 and Track 5 are complete; Track 3’s 3.3 / #1924 remains deferred under its [plan](2026-10-19-native-observability-plan.md#slice-33--late-read-count-on-wirenative), blocking no certification or release. The [fast.9 maintenance adoption record](../research/quic-go-fast-v0.62.1-fast.9-native-adoption.md) owns the selected native fork lane and its maintenance evidence; the [fast.8 adoption record](../research/quic-go-fast-v0.62.1-fast.8-native-adoption.md) retains the bundle decisions and historical evidence.

## Decisions accepted on the owner's behalf

The map's tickets decided every lever. This packaging pass made the calls the tickets left open. Each is recorded with its reasoning as a handoff decision (H1–H31) in [the handoff audit](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), and each is reversible before its slice is dispatched. The ones a reviewer will ask about:

- **Track 2 waits for ADR-0016's implementation, and Slice 2.2 amends ADR-0016** ([H2](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H21](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H25](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
  - On a connected macOS native socket, ICMP-driven errors and `ENOBUFS` are datagram drops. They form their own drop class and don't feed the idle-timeout cause hint; that is what the connected-socket ticket decided before ADR-0016 existed.
  - A failed `connect` promotes the Wire unconnected, and a send to any other destination is refused as a peer refusal.
  - Drop counts stay in ADR-0016's own unit, dropped datagrams, including on coalesced reads.
- **A new internal readout seam, Slice 3.1** ([H4](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H24](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
  - The owner's decision that the rig "gains RTT, PTO and spurious-loss readouts before those gates run" needs a way from the rig to the fork connection behind a native Wire. It is an internal verification aid, off by default, with no public API.
  - Later counters are added by the product slice that first needs them on main.
  - `internal/measurement` also reads the fork's drop counts, as decided.
- **Deferred on 2026-10-23:** Slice 3.3 remains research until a reproducible consumer slowdown establishes an actionable diagnostic need and the owner authorizes a bounded revisit; see the [deferral decision](2026-10-19-native-observability-plan.md#slice-33--late-read-count-on-wirenative). Its prior design decisions below remain reference material.
- **The late-read count is its own slice, 3.3, after the headroom docs (3.2)** ([H5](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H22](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
  - The docs ship regardless.
  - The count uses kernel receive timestamps with a fixed 5 ms threshold. Its gate gains a no-harm row and numeric readings for "climbs" and "flat"; if the gate fails, the count doesn't merge.
  - Targets publish in a new `docs/NATIVE-THROUGHPUT.md`, with every floor marked as a target until its certification.
- **Fork slices are ordinary public fork issues under one bundle-release issue** ([H11](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H12](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H13](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H30](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
  - F1 and F10 are retained with recorded deviations. F1 (quic-go-fast#824) counts only full-queue discards; F10 (#742 and #743) caps a send at 64 segments rather than Linux's 128.
  - Gluing is already on by default on fork `main`. If its consumer gate fails, the release ships it off by default, and wiremux adopts no release that has it on by default without both deeper queues.
  - Each fork brief carries the design guards found by reading code.
- **Consumer gates are wiremux tasks, 4.R and 4.G1–4.G6** ([H14](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H26](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). Each default-on fork slice is measured against the fork commit it lands on, and unquantified gate words get one recorded reading each.
- **The repin, 5.1, cuts no wiremux release and changes no `go.mod`** ([H16](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
- **Certification statistic** ([H17](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), [H31](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).
  - One headline campaign, with the median against each floor; on a miss, one more campaign is pooled.
  - A pooled miss files a diagnosis issue.
  - macOS certifies under the adopted send raise's launch context.
- **Smaller calls:**
  - the ceiling keeps 1,192 when the fork reports no limit ([H27](2026-10-19-native-gap-handoff-audit.md#handoff-decisions));
  - truncated control is counted on the kernel flag, before admission ([H28](2026-10-19-native-gap-handoff-audit.md#handoff-decisions));
  - no Windows row is added to the acknowledgment switch's gate ([H29](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).

## Rules that bind every track

- **Admission.** Every lever keeps wiremux's per-datagram admission contract (the guarantees of [Native unicast admission re-inspects interfaces and routes on every packet, capping macOS direct Datagrams near 4.7k packets/s](https://github.com/GridSwarm/wiremux/issues/1784), published in `COMPATIBILITY.md`), unless its deciding ticket explicitly decided otherwise with the owner.
  - The coalescing slices (5.3, 5.4) admit once per coalesced read. Each relies on its platform's documented merge guarantee: Linux by [Can native receives take GRO-coalesced buffers and keep per-datagram ingress admission?](https://github.com/GridSwarm/wiremux/issues/1824#issuecomment-6075680888), and Windows by [Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572) "under Windows' default strong-host receive", with the weak-host gap accepted.
  - Each tests the coalesced path. Every message of a multi-message batch read is still admitted separately, and each adds the `COMPATIBILITY.md` sentence that says so.
  - The connected-socket slice (2.2) keeps every per-datagram check.
- **Measurement.**
  - Every gate is the rig's A/B rule (A, B, A, B campaigns at `REPS=3`, pooled medians) unless its plan says otherwise.
  - Datagram arms run at the pin (`-ballast 64 -gc-role both`) with the default-GC row reported, except slices A and B, which keep their CPU thresholds on the default-GC row. Stream arms run at the default GC unless a gate names the pin (#1801 section 4 "Unit" and PROTOCOL.md).
  - Every run follows the shared-host rules in the map Notes, at any time: a per-run no-other-`nativerig` gate on minimax, announcing CPU-heavy mbp128 work to the session holding the `tb` pair, `LOADGATE`/`GATE` beside mbp128's GARM Tart VMs, and the owner's OK for any VM build.
- **Ownership.** Each fact a slice touches has one named mutation owner after merge. No slice budgets a temporary duplicate representation or a second state machine; a slice that needs one stops for a decision.
- **Private calls.** Private Darwin system calls are allowed in wiremux's binding on the fork's terms. Each is a measured lever with its own gate, allowlisted by macOS version with a startup self-check and a fallback to today's public call, and tested in the macOS fork lane.
- **Native tests.**
  - They run in the fork lane: `-modfile` at the fork release the slice names, with `WIREMUX_TEST_NATIVE=required` and `-race`.
  - Hosted CI skips them, so each slice names its local and one-off platform runs.
  - The program adds no CI lanes. 6.3 and 6.4 widen the macOS lane's existing test step.
- **Review and certification.** Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) and [`docs/CI.md`](../CI.md). Diagnose failures before reruns. Certify the exact head locally and on same-head hosted CI before merge.
- **Approach stops.** These stop a slice: a public, wire or contract change its deciding ticket did not decide; a change to an accepted ADR other than Slice 2.2's ADR-0016 amendment; a second semantic authority; or contradicting a quoted decision. Route a changed representation owner, topology, adjacent scope, product decision, irreversible authority, or one-PR boundary back through `$architecture-handoff`.
- **Post-merge ritual for each slice:**
  1. bounded review loop;
  2. exact-head certification and same-head hosted CI;
  3. merge;
  4. `$append-dev-journal`;
  5. complete its OmniFocus slice task;
  6. reconcile the tracking issue and the frontier.

  Consumer gate tasks don't journal: Slice 5.1's journal entry records their results.
