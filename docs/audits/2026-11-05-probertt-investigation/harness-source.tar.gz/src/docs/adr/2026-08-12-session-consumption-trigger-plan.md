# Session-Consumption Trigger Implementation Plan

**Date:** 2026-08-12
**Status:** Implemented by PR #1149
**Track:** 1 of 2 in the 2026-08-12 session-consumption and selected-pair program
**Depends on:** nothing — safe to start first
**Related:** [`2026-07-29-establishment-settlement-plan.md`](2026-07-29-establishment-settlement-plan.md) (D7–D9 remain binding); [`2026-07-05-consume-coordinator-plan.md`](2026-07-05-consume-coordinator-plan.md) (coordinator keeps once/budget/RPC and the two stream shells); [`2026-07-07-rendezvous-disposition-plan.md`](2026-07-07-rendezvous-disposition-plan.md); [`2026-08-08-establishment-settlement-policy-plan.md`](2026-08-08-establishment-settlement-policy-plan.md) (landed policy table); ADR-0008, ADR-0010
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** 2026-08-12 architecture review candidate 1; decide-mode grilling of 2026-08-12; in-plan slice decision audit below

## Goal

Give establishment settlement the only *failure-path* authority over which Session-consumption family runs. Today the 2026-08-08 policy table already derives stage, consume family, and one-shot spend, then `consumeAfterFailure` forwards auth-validation to `consumeCoordinator.onPostAuthValidationFailure`, which repeats the same `spendsRendezvous` fork. After this track, `resolve()` maps auth-validation onto one of the two real consume families, the third consume action and the coordinator reclassify method disappear, and the coordinator keeps only *how* consume runs. Leverage: one policy evaluator, every failure exit. Locality: irreversible Session consumption cannot diverge between table and hook.

## Current Shape (verified 2026-08-12 at `4ada940442c071f7da13c6f2f514ff383e7ac385`)

- Settlement already owns failure obligation order in `settleFailure` (`establishment_settlement.go:185-195`): failed-auth release, upgrade cleanup, consume, carrier close, then `markSpentAfterOneShotSuccess`.
- The closed policy table (`establishment_settlement.go:46-87`) already stores auth-validation as `establishmentFailureConsumeAuthValidationFailure` with `spendsAfterIdentitySuccess: true` (`:63-68`). `resolve()` (`:100-110`) already computes `spendsRendezvous = spendsAfterIdentitySuccess && successSpends` and already promotes identity/nil-auth via `promoteAfterSuccessfulIdentity`.
- `consumeAfterFailure` (`:213-225`) still has a third action that only forwards to the coordinator.
- `onPostAuthValidationFailure` (`consume_coordinator.go:100-106`) is a shuttle: `successSpendsRendezvous` → `onPostIdentitySuccessFailure(true)`; else → `onIdentityFailure(cause)`. Production callers are only `consumeAfterFailure`.
- The 27-row settlement matrix already includes six auth-validation rows (`establishment_settlement_test.go:354-428`). Non-spending rows expect consume when the cause passes the identity heuristic; spending rows expect consume and `DispositionSpent`.
- The only test that uniquely exercises the shuttle is `TestPostAuthValidationFailureOneShotIgnoresCauseDisposition` (`wiremux_internal_test.go:961-982`): a canceled dial context plus `MarkRendezvousRetryable` still consumes when `successSpendsRendezvous` is true. That fact is not pinned at `settlement.fail`.
- `dialPaired` declares auth-validation at directional-key construction (`wiremux.go:226-228`) and at negotiator construction (`:243-245`). Kind declaration, the nil-auth ladder (`:209-225`), and success-side `decorateRelay` / `gateRelayWin` (`:241`, `:256-257`) stay stage-side per settlement D8/D9.
- `finish()` (`establishment_settlement.go:238-248`) remains the frame-level panic auth-release guard (D7). Packet settle already runs from `cleanupUpgrade` (`:209-211`) and `registerUpgradeResult`.

## Decision

- **Collapse the third consume family inside `resolve()`, and only for auth-validation.** Auth-validation is still a failure *kind* (`establishmentAuthValidationFailed`, stage `ErrIdentity`). It is not a third consume *family*. Only that kind remaps: when `resolve()` computes `spendsRendezvous`, it sets `consumeAction` to `establishmentFailureConsumePostIdentitySuccessFailure`; otherwise to `establishmentFailureConsumeIdentityFailure`. Every other kind keeps the table's `consumeAction`, including channel / upgrade / nil-stream remaining post-identity-success even when `spendsRendezvous` is false (the hook then no-ops). Delete `establishmentFailureConsumeAuthValidationFailure` and the matching `consumeAfterFailure` case.
- **Delete `onPostAuthValidationFailure`.** After merge, failure-path consume has two hooks: identity-failure (heuristic, including `RendezvousDisposition`) and post-identity-success (unconditional without-cancel consume when `successSpends` is true). The coordinator retains once-semantics, budgets, handler timing, and the two stream shells.
- **Move the one-shot-ignores-retryable-cause proof to settlement.** Replace `TestPostAuthValidationFailureOneShotIgnoresCauseDisposition` with a settlement-interface case: `fail(establishmentAuthValidationFailed, MarkRendezvousRetryable(canceled))` with `successSpends` true must consume and mark spent. The existing six auth-validation matrix rows keep their current expectations.
- **Preserve D7–D9.** Do not absorb `decorateRelay` / `gateRelayWin`. Do not move kind declaration or the nil-auth ladder into settlement. Do not expand `finish()` into a second full settlement.

**Rejected alternative (do not do this):** Leave the third action and add a synchronization test between table and shuttle. That verifies duplication rather than removing the second owner.

**Rejected alternative (do not do this):** Move identity-failure heuristic (`identityFailureConsumePolicy`) into settlement. The heuristic is the identity hook's job and is owned by the consume-coordinator and rendezvous-disposition plans. Settlement selects the family; the coordinator applies identity-only skip/spend rules.

**Rejected alternative (do not do this):** Absorb success-side stream consume, kind declaration, or panic `finish()` into this slice. Those reopen D7–D9 and turn a residual single-owner fix into a second settlement redesign.

**Non-goals:** no public Dial, error-tree, consume-budget, one-shot, or rendezvous-disposition change; no shared hostile-error walker; no `CloseAfterDirectUpgradeSuccess` public connect interface; no change to success-path consume; no packet-ownership or auth-release ordering change; no connect/relay/channel/transport edits.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | complete in PR #1149 | Auth-validation consume family selected only by settlement `resolve()`; third action and coordinator shuttle gone | None | Removes the auth-validation reclassify shuttle |

## Implementation Slices

### Slice 1 — Collapse auth-validation consume into the two real families

**What it delivers:** `establishmentFailurePolicy.resolve` is the only failure-path selector of consume family, including auth-validation. `consumeAfterFailure` has three actions (none, identity, post-success). `onPostAuthValidationFailure` and `establishmentFailureConsumeAuthValidationFailure` are absent. The 27-row matrix plus the moved one-shot-ignores-retryable-cause case stay green. Observable Dial consume behavior is unchanged.

**Existing-work disposition:** implemented by PR #1149.

**Blocked by:** None.

**Single owner after merge:** `establishmentFailurePolicy.resolve` owns failure-kind → consume-family selection, including the auth-validation spend fork. `establishmentSettlement` owns obligation order. `consumeCoordinator` owns once/budget/RPC, identity heuristic, and stream shells. `markSpentAfterOneShotSuccess` owns spent-marker shaping.

**Authority completeness:** No new persisted fact. Every production `fail(establishmentAuthValidationFailed, …)` site (`wiremux.go:228`, `:245`), the policy table row, `resolve()`, `consumeAfterFailure`, and the two remaining consume hooks are covered. No restart fact is introduced.

**Transitional-seam budget:** None. The third action and shuttle disappear in the same PR. No compatibility mapper remains.

**Blast radius:** Root package settlement and consume-coordinator tests only. Material risk is irreversible Session consumption and one-shot spend vs retryable marking. Concurrency is unchanged (`consumeOnce` stays on the coordinator). No public interface, wire, connect, or performance change. Untraced effects: none beyond the two `dialPaired` auth-validation declaration sites and the named tests.

**Artifact classification:** The production collapse is shipped behavior with intentionally unchanged observation. The 27-row matrix and the moved one-shot-ignores-retryable case are verification aids in the ordinary Go suite. This plan is process metadata. No verification aid is a blocking maintained deliverable.

**Representation contract:** Supported domain = the seven-member closed `establishmentFailureKind` enum and the reachable `authReturnedWithoutErr` / `successSpends` / consume-coordinator states already modeled by the 27-row matrix, plus the one-shot auth-validation + `DispositionRetryable` cause already pinned by `TestPostAuthValidationFailureOneShotIgnoresCauseDisposition`. Representation owner = `establishmentFailurePolicy.resolve` for consume-family selection. Guarantee = universal over the finite failure enum and those reachable dynamic inputs. Terminating evidence = mechanical enum completeness (every declared kind still maps exactly once), unchanged expectations for all 27 matrix rows, the moved one-shot-ignores-retryable case at `fail()`, and `task verify`.

**Contract closure:** Triggered. A wrong consume-family choice irreversibly consumes or leaves reusable an ephemeral SessionID, and auth-validation is independently reachable from two `dialPaired` sites with and without `successSpends`. Invariant: every declared failure kind derives exactly one consume family from `resolve()`; auth-validation is never a third family. Enforcement owner: `establishmentFailurePolicy.resolve`.

| Semantic class | Expected disposition | Enforcement owner | Evidence | Guard mutation | Status |
| --- | --- | --- | --- | --- | --- |
| Pairing failure | no consume | `resolve()` → none | existing pairing matrix row | n/a | covered |
| Identity or nil-auth without `authReturnedWithoutErr && successSpends` | identity-failure hook; heuristic may skip | `resolve()` → identity | existing identity/nil-auth rows | n/a | covered |
| Identity or nil-auth with `authReturnedWithoutErr && successSpends` | post-success consume; spend rendezvous | `resolve()` promotion | existing post-success identity/nil-auth rows | n/a | covered |
| Auth-validation with `successSpends` | post-success consume even if cause is `DispositionRetryable` or canceled | `resolve()` spend fork | existing spending auth-validation rows plus moved one-shot-ignores-retryable case | delete/bypass the spend fork only if inherited coverage is otherwise ambiguous | covered |
| Auth-validation without `successSpends` | identity-failure hook on the cause | `resolve()` non-spend mapping | existing non-spending auth-validation rows | n/a | covered |
| Channel / upgrade / nil-stream | post-success consume iff `successSpends` | `resolve()` | existing channel/upgrade/nil-stream rows | n/a | covered |
| Undeclared kind including zero | panic at policy lookup after release/cleanup; no consume | `establishmentFailurePolicyFor` | existing invalid-zero characterization | n/a | rejected |
| Success-path consume | unchanged stream shells; not a failure-policy lookup | `decorateRelay` / `gateRelayWin` | existing success-transfer row; D8 | n/a | non-goal/preserved |

**Evidence budget:** Preserve all 27 matrix expectations; add or relocate one settlement-interface case for auth-validation + `successSpends` + `MarkRendezvousRetryable` canceled cause; keep mechanical seven-kind completeness; at most one optional guard-deletion of the auth-validation spend fork if the moved case would otherwise pass without it; no new platform, repetition, fuzz, or hosted matrix. Review budget = one initial review plus at most one replacement. Terminate when the third action and shuttle are absent, all named expectations are unchanged, and `task verify` passes.

**TDD and preservation evidence:** First add a settlement-interface assertion that fails while auth-validation still has its own consume action: with `successSpends == true`, `establishmentFailurePolicyFor(establishmentAuthValidationFailed).resolve(anyAuthReturned, true).consumeAction` must be `establishmentFailureConsumePostIdentitySuccessFailure`, not `establishmentFailureConsumeAuthValidationFailure`. Separately relocate `TestPostAuthValidationFailureOneShotIgnoresCauseDisposition` to `fail(establishmentAuthValidationFailed, MarkRendezvousRetryable(canceled))` as a characterization/preservation case (it is already green through the shuttle). Then delete the third action and `onPostAuthValidationFailure`, keep the 27-row matrix and root consume sentinels green, and delete only coordinator tests whose sole subject is the shuttle.

**Dispatch context budget:** This plan; `establishment_settlement.go`, `consume_coordinator.go`, `establishment_settlement_test.go`, `wiremux_internal_test.go`; D7–D9 of the 2026-07-29 settlement plan; the 2026-08-08 policy-table plan as historical evidence. No governing production diff. Implementation, review fixes, and verification fit one fresh context.

**Slice decision audit:** Strongest further split — land the `resolve()` mapping without deleting the coordinator method, then delete the method later; rejected because the leftover method remains a second owner and the two halves edit the same call path. Strongest adjacent merge — fold selected-pair handoff into this PR; rejected because it lives in `connect`, has a different owner, and breaks the one-fresh-context budget. Blocking edges: none; Track 2 is parallel-safe.

**Stop conditions:** Stop if preserving behavior requires a public API change, a change to identity-failure heuristic outcomes, moving success-side consume, expanding `finish()`, changing D8/D9 kind declaration, introducing a shared error walker, or growing beyond one reviewable PR. Stop if `resolve()` cannot express the auth-validation spend fork without a remaining third consume action or a coordinator reclassify callback.

## Acceptance Criteria

- [ ] `establishmentFailureConsumeAuthValidationFailure` and `onPostAuthValidationFailure` are absent. Supported domain = current root production and test source; owner = this slice; guarantee = canonical-subset over repository references; evidence = reference census after deletion.
- [ ] `resolve()` is the only failure-path selector of consume family, including auth-validation. Domain = seven declared kinds × reachable `successSpends` / `authReturnedWithoutErr` states; owner = `resolve()`; guarantee = universal over that finite model; evidence = mechanical kind completeness plus the 27-row matrix.
- [ ] Auth-validation with `successSpends` selects the post-success consume family, including when the cause is `DispositionRetryable` or canceled. Domain = that reachable dynamic class; owner = `resolve()`; guarantee = example-level at the settlement interface; evidence = the red `resolve().consumeAction` assertion plus the relocated one-shot-ignores-retryable `fail()` case.
- [ ] All 27 existing matrix expectations and existing root consume sentinels remain unchanged. Domain = those named tests; owner = preservation gate; guarantee = example-level; evidence = green focused settlement and consume tests plus `task verify`.
- [ ] No exported root or connect interface change.

## Validation Gates

```bash
GOTOOLCHAIN=local go test . -count=1 -run 'EstablishmentSettlement|PostAuth|Consume|IdentityFailure'
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestAuthContext|TestTransportAuth|TestBlockedTransport|TestWireAuth|TestWireClose|TestExplicitWireClose)' -count=1 .
task verify
```

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) and the certification lanes in [`docs/CI.md`](../CI.md). Vocabulary is CONTEXT.md **Establishment settlement**, **Session consumption**, **Rendezvous disposition**, and **One-shot rendezvous**. D7–D9 of the 2026-07-29 settlement plan remain stop conditions, not reopeners.
