# ADR-0014: Keep QUIC Fork Integration Optional

## Status

Accepted compatibility and staging decisions. The [complete cross-repository program](2026-09-14-quic-packet-io-program.md) records the delegated technical decisions and pending implementation/evidence stages.

## Decision

wiremux must remain buildable and functional with upstream quic-go while an explicit optional integration enables quic-go-fast capabilities. Making quic-go-fast mandatory for the built-in QUIC transport is rejected at this stage: retaining the upstream path supports controlled comparisons and rollback while the new socket contract is established, at the cost of maintaining both paths during evaluation.

The optional integration must preserve ordinary downstream builds without an application-owned fork replacement. Fork-only references cannot enter the ordinary build unless the selected integration mechanism preserves that requirement. This decision does not select build tags, a separate adapter/module, optional interfaces, or another integration mechanism, and does not promise configuration-only rollback for applications that directly adopt fork-only interfaces.

## Staged Integration

The first usable integration enables offloads through the existing selected-peer wrapper. Native fixed-peer enforcement in quic-go-fast and removal of wiremux's wrapper are evaluated separately within the joint design and are not prerequisites for that first integration. This ordering makes wrapper-compatible capabilities reusable by other consumers and permits measuring their effect before relocating selected-peer enforcement, accepting that wrapper overhead remains initially and some integration machinery may become unnecessary for wiremux later.

The first stage preserves the wrapper's packet filtering and the existing selected-path contract. Any later removal requires a separate accepted enforcement design and evidence that its replacement preserves the complete contract. This staging decision does not select an offload rollout order, require every offload in the first release, or approve implementation.

## Complete Program

The joint program selects explicit transport registration independent of close ownership, wrapper-preserving platform I/O, initial disposal-guaranteed receive coalescing, later managed reusable endpoints, and immutable transport-wide fixed-peer enforcement. Native enforcement implementation and selective wrapper removal have separate evidence gates; no current behavior is claimed to have changed. Existing [selected-path binding](adr-0003-quic-selected-path-binding.md) and [packet-socket ownership](adr-0008-immediate-packet-socket-ownership-transfer.md) decisions remain in force. The program includes consumer rollout, releases and a closeout gate that cannot be completed by shipping the initial milestone alone. Recording this design does not claim implementation or dependency adoption.
