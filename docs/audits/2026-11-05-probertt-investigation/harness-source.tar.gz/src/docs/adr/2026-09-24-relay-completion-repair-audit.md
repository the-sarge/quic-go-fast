# Relay completion repair handoff audit

## Scope and evidence

This scoped extension of AH-20260924 follows the completed [R1 diagnostic](../research/2026-09-24-relay-completion.md) and the owner's instruction to plan its repair. It adds RR/RR1 under the existing program and OmniFocus parent; it does not reopen R1 or A1–F1 and launches no implementation agent.

Planning inspected source head `b8dbf53ffcae0e2e928b0dd3b3d54bdc6ac73adb`: proxy reader/writer ownership, idle and allowance exit paths, runtime timeout/accounting, pairing release and short-pair observation, shaping waits/release and the named existing regressions. Open PRs #1674 and #1484 only change dependencies; no overlapping implementation was adopted. R1 review had no unresolved finding; its optional relative-link suggestion is not an inherited repair obligation.

## Proposed graph and self-audit

RR1 is one product PR, dependent only on completed R1. It repairs one aggregate completion invariant for three worker classes. Prefix failures seal a registration set of zero, one, or two readers after both writers return. Callbacks close without joining; the aggregate joins after close/stop outside locks. Existing runtime timeout remains abandonment. Eight new cases and named preservation checks terminate evidence. No new public or persisted authority, transitional adapter, general harness, or untraced effect is accepted.

An inert callback prefactor or narrower partial-join repairs are technically possible; one slice retains the accepted complete outcome within the bounded packet without a temporary completion contract; merging neighboring tracks has no semantic justification. The reader, timer and monitor changes fit a 32,000-token fresh-context contract. Independent slice audit passed after the preservation correction below; dispatchability requires the accepted plan to be merged to the default branch and its child pointer to be verified.

## Preservation correction during slice audit

The independent audit confirmed that delaying the combined short-pair observation/release callback would change duration classification and live shutdown suppression. The current contract therefore separates a private observation-only drained callback from joined accounting completion at the same aggregate owner. Its eighth case will verify observation before a held-worker join and retained accounting until release. Passing only a saved timestamp was rejected because suppression also reads runtime-closing state. The context budget now includes shared baselines and named source/test bodies explicitly; no whole-file or historical-program dump is required.

## Independent slice audit disposition

Read-only audit agent `audit_repair_slice` reviewed the current plan, scoped program update and pinned source. Final result: PASS; no required contract correction remained. The audit confirmed aggregate ownership, zero-to-two-reader registration sealing, close/stop before joins, callback self-join avoidance, observation-only drained notification, retained runtime abandonment, the eight-case evidence budget and the revised 32,000-token dispatch packet. It accepted the documented one-PR choice after considering an inert callback prefactor and narrower reader/monitor repairs. No tests or implementation were run and no source files were modified by the audit.
