# Windows guard readout scoped re-audit

Slice: [5.4](2026-10-19-bundle-adoption-plan.md#slice-54--windows-receive-coalescing-switch-x64-and-arm64), child [#1928](https://github.com/GridSwarm/wiremux/issues/1928).

## Trigger and routing

At wiremux `a3e4938389e9ea4ca1d90614c1b76b3d0033a880`, `readoutEntry` holds a connection and binding; promotion registers those two objects. The adopted fast.8 release exposes the guard count only through [`Transport.ReceiveCoalescingFallbacksV1`](https://github.com/the-sarge/quic-go-fast/blob/8095c72244755f0c1e24f4158253bf09cfbe6e17/receive_coalescing_fallbacks.go#L12). Its godoc states the count is socket-scoped, monotonic, concurrency-safe, and at most one per socket. The original slice explicitly stopped when that count was unreachable through the held objects. No product implementation or measurement campaign began.

Disposition: scoped re-audit under `implement-architecture-slice`. The accepted outcome already requires this optional counter in the internal, disabled-by-default readout. The endpoint already owns one QUIC transport per binding. Retaining only that transport’s optional reader at promotion registration repairs the factual assumption without changing product intent, platform representation, socket authority, or the one-product-PR boundary. No operator representation decision is needed. Guest builds remain separately subject to owner approval.

## Gate reconciliation

| Gate | Current disposition |
| --- | --- |
| Representation | Unchanged Windows strong-host URO domain; the optional counter has two method-set states, present and absent. No external syntax parser is introduced. |
| Owner and authority | The fork owns the socket count. Existing endpoint binding identity selects its transport; the readout owns only the association and optional read. No socket or transport mutation is exposed. |
| Artifact | Verification aid with the gate-readout payoff, internal owner, supported domain, and retirement condition recorded in the normative slice. No recursive evidence requirement. |
| Lifecycle | Capture the optional reader only when enabled and registering a committed promotion. Unregister removes it with the connection entry. An already-started lookup may finish using the concurrency-safe method, consistent with existing readout semantics. |
| Transitional seams | None. No second registry, copied counter, goroutine, or callback. |
| Preservation | Present/absent count cases, one two-binding association case, and existing disabled, duplicate-registration, and unregister/Close cases. No new timing, repetition, or platform scope. |
| Blast radius | Internal readout registration and its promotion call site; no public API, required capability, binding authority, or dependency change. Control-buffer capacity remains an execution-preflight check. |
| Contract closure | Existing admission closure remains unchanged. The counter aid gets bounded regressions; closure is not recursively applied to it. |
| Context and evidence | Remains within 55,000 dispatch tokens, one review plus at most one replacement, and the existing platform and campaign budget. |

## Design cost and alternatives

The fork’s owner-facing design is already an appropriate socket-scoped transport method. Moving it to the connection would alter an external dependency contract and obscure socket scope; rejected, revisit only if the fork changes that API. Moving a counter or reader into `routeselection` would give binding code knowledge of the QUIC verification aid; rejected, none: rejected on merit. A separate transport registry or callback adds synchronization and teardown obligations that the existing endpoint association avoids; rejected, none: rejected on merit.

Splitting the guard readout into another product slice would leave this slice’s required gate without its count. Merging broader readout restructuring or adjacent observability work would add unrelated obligations. Both are rejected, none: rejected on merit. The normative plan owns the replacement contract; this audit is traceability metadata only.
