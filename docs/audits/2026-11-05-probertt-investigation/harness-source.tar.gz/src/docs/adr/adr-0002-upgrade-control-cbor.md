# ADR-0002: Deterministic CBOR for Upgrade Control

## Status

Accepted.

## Context

PRD-0001 defines v1 upgrade negotiation as a small authenticated control protocol carried over the paired relay channel. The messages are security-sensitive because they carry candidate offers, transport handshake material, fallback decisions, selected candidate pairs, listener readiness plus dialer commit, and post-commit convergence messages such as `accepted`, `converged`, and `confirmed`.

The encoding needs to be canonical across implementations, bounded
before allocation, hostile-input testable, and compact enough that the
wire protocol does not inherit a local-IPC or service-mesh schema stack.
The field set is small and versioned, but future optional metadata needs
a safe ignore-unknown area without making core protocol maps open-ended.

## Decision

wiremux v1 upgrade-control messages use a length-prefixed RFC 8949
Section 4.2.1 Core Deterministic CBOR envelope with a strict bounded
subset. Core protocol maps use small integer keys and are closed:
unknown fields are rejected in core maps, and future optional metadata
is confined to an explicit ignore-unknown extension map.

PRD-0001 owns the normative v1 upgrade-control registry: message discriminators, core field keys, candidate-map keys, fallback-reason values, message phases, post-commit convergence frames, required fields, and field bounds. ADR-0002 chooses the encoding profile and registry discipline; implementation code must mirror the PRD registry exactly rather than inventing local field numbers in the CBOR wrapper.

The frame prefix is byte-exact and not CBOR: every control frame is
`u32be(payload_len) || payload_cbor`. The unsigned big-endian
four-octet prefix counts only the CBOR payload bytes and excludes the
prefix itself. Valid payload lengths are 1 through 65,536 bytes
inclusive. Prefix values greater than 65,536 bytes are rejected before
allocating a payload buffer or reading the advertised payload. A
zero-length frame is a complete but invalid control frame and is
classified by the PRD's invalid-CBOR/protocol-mismatch rule. Golden
encodings include the four prefix bytes.

The v1 decoder rejects tags, floats, indefinite-length items, duplicate
map keys, non-canonical encodings, unknown core fields, oversize frames,
and values exceeding documented byte-string, text-string, map, array,
and nesting bounds, including the PRD's maximum extension-value nesting
depth of 8. The v1 encoder emits only deterministic definite-
length forms and pins golden encodings for every network-facing control
message.

The implementation should use `github.com/fxamacker/cbor/v2` behind a
small internal wiremux wrapper. The wrapper owns deterministic encode
mode, duplicate-key rejection, rejected tags, rejected indefinite
lengths, and strict size/depth/map/array bounds so package code cannot
accidentally drift into a broader CBOR profile. The implementation PR
that adds the dependency must pin it in `go.mod`/`go.sum`, document the
dependency choice in the PR body, and include malformed/adversarial CBOR
tests for the network-facing decode path.

## Consequences

- Upgrade-control messages have one canonical byte representation, which
  supports golden tests, transcript review, and cross-implementation
  compatibility.
- The protocol avoids protobuf-style defaults and unknown-field behavior
  for core security-sensitive maps while preserving an explicit
  extension map for future optional metadata.
- Implementations must maintain a code-level mirror of PRD-0001's
  numeric key registry and a bounded decode wrapper; direct use of a
  permissive generic CBOR decoder is not sufficient for v1.
- Malformed or adversarial CBOR test coverage is required in the first
  implementation slice that decodes upgrade-control messages from the
  network.
