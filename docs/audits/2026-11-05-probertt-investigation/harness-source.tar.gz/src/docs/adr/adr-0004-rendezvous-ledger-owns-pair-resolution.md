# ADR-0004: The Rendezvous Ledger Owns Pair Resolution

## Status

Accepted. Implementation lands in a follow-up slice; this ADR records the
agreed shape so the deepening is not re-litigated or accidentally reversed.

Refined after a RAS consideration of the first draft (run
`20260619T030049-0ca5532b78cf79ac173d53a7`, agents codex/claude/grok). The
consideration affirmed the core shape — keep the ledger free of peer I/O, and
keep the two rendezvous modes separate at entry (consistent with ADR-0001 DP3)
— and sharpened the resolution-authority model, the handle contract, and the
self-resolution vs cross-goroutine distinction recorded below.

## Context

The relay matches two waiting peers under a shared rendezvous identifier and
forwards opaque bytes between them (ADR-0001 DP3, dual-mode rendezvous). State
lives in `relay/ledger.go` (`rendezvousLedger`); the pairing choreography —
writing `OK` to both peers, starting the byte proxy, reading the waiting peer's
prefix bytes — lives in `relay/lifecycle.go`.

The load-bearing invariant is best stated as **outcome-once**, not
channel-once:

> Every waiting peer's outcome is resolved exactly once. The right to resolve a
> waiting peer is granted by **winning its removal from the ledger's
> waiting/pending state under `mu`** — removal is the linearization point.

Two resolution shapes share that linearization point but differ in delivery:

- **Self-resolution.** The waiting peer's *own* goroutine decides its fate —
  ephemeral and long-lived dial timeout, and long-lived notify-write failure.
  It wins removal under `mu`, then writes the protocol error **to its own
  connection** and returns. It sends **nothing** on the result channel.
- **Cross-goroutine resolution.** A *different* goroutine decides the waiting
  peer's fate — the disconnect watcher, the expiry ticker, `consumeEphemeral`,
  long-lived unregister, and a counterpart `pair`. The resolver wins removal
  under `mu`, then delivers the outcome across goroutines by **sending on the
  result channel**; the waiting goroutine wakes and writes its own connection.

The `result` channel is buffered with capacity 1, and that is load-bearing: a
cross-goroutine resolver that wins removal must be able to deliver without
blocking even in the window before the waiting goroutine reaches its channel
receive (or after it has stopped reading because it lost a removal race).

Today neither the linearization authority nor the self/cross distinction is
expressed in one place. The send is upheld by hand at several sites, with three
delivery conventions (resolved internally, returned as `[]waiterNotification`
for the caller to deliver, or sent directly on `waiter.result`). And active-pair
accounting (`activePairs`, the `paired` ref map) is incremented at claim time
but released in two different places (`pair`'s failure defer and the proxy
completion callback), with no single owner.

The failure modes this creates are severe and hard to debug: a remover that
wins but forgets to deliver hangs the losing goroutine forever on `<-result`;
an accounting path that releases zero or twice corrupts the relay's capacity
counters.

There is also a terminology gap. The connectivity domain (`CONTEXT.md`) already
uses "pair" for a *selected candidate pair* — two candidate addresses on the
direct path. The relay's notion of matching two peer connections was undefined,
so naming a module after it risked colliding with the connectivity sense.

## Decision

### D1: The ledger owns resolution authority; it stays free of peer I/O

The `rendezvousLedger` is the single authority over **pair resolution**: it owns
removal linearization (under `mu`) and cross-goroutine result-channel delivery.
It does **not** read or write peer connections — `writeOK`, the byte proxy, the
idle monitor, the prefix read-ahead, and every self-resolution wire write stay
in `rendezvousLifecycle`.

Concretely, self-resolving handlers (dial timeout, notify-write failure) call a
ledger **remove-win** method that performs no connection I/O and returns whether
this caller won removal; the lifecycle then writes the protocol error to its own
connection only if it won. Cross-goroutine resolvers call ledger methods that
win removal and deliver on the channel in one atomic step.

This was chosen over a fuller "pairing authority" that would absorb `writeOK`
and `proxy`: that alternative couples the ledger to connection I/O and the relay
wire framing, and forces socket fakes into what should be a pure state test. The
consideration's reviewers independently rejected making the ledger do peer I/O.

### D2: Resolution authority is ledger state; handles carry it explicitly

`sync.Once` per waiter is **only** the at-most-once delivery guard on the result
channel. It is not the authority. The authority is ledger state under `mu`: a
caller may resolve a waiter only if it wins removal of that waiter from the
structure it lives in. Once a waiter is claimed (removed under `mu`), a stale
disconnect, timeout, or consume can no longer win removal, so it cannot resolve
the now-claimed waiter; the claimant is the sole remaining authority.

Two handle types make this structural. Both are opaque and never expose the
result channel:

- **Waiter handle** — minted by `beginEphemeralDial` / `beginLongLivedDial` for
  a peer that joins the waiting/pending set. It carries enough internal metadata
  for the ledger to remove the waiter from the *correct* structure under `mu`
  (ephemeral `waiting`+heap vs long-lived `registration.pending`+
  `longLivedWaiting`). The disconnect watcher closes over this handle and calls
  the ledger's unified `Reject(handle, err)` (cross-goroutine: remove-win +
  channel deliver). The self-timeout path calls the ledger's remove-win method
  with the same handle (no channel; lifecycle writes the wire).
- **Pairing handle** — minted under `mu` at the moment of claim, by
  `beginEphemeralDial` (when it finds a waiting counterpart) and
  `acceptLongLived`. Claiming binds the **active-pair slot** (`activePairs`++ and
  the `paired` ref) to this handle. The pairing handle is the sole authority for
  resolving the claimed waiter:
  - `Fail(err)` resolves the waiter (channel) **and releases the active-pair
    slot**, exactly once.
  - `Succeed()` resolves the waiter (channel) and **transfers** active-pair
    release ownership to the proxy completion callback, exactly once.

  The pairing handle is returned **already armed**: the sole consuming function
  (`pair`) must install `defer h.Fail(errPairingAbandoned)` with no intervening
  work, so a panic or early return in the claim-to-guard window cannot leak the
  waiter or the active-pair slot. Connection and prefix bytes are exposed only
  **after** the handle quiesces the watcher (joins `watchDone`); the handle hands
  out an **immutable prefix snapshot**, never the live `prefixByte` slice.

### D3: Cross-goroutine resolution fuses through the ledger; self-resolution stays remove-win; entry stays mode-specific

Cross-goroutine resolution paths — disconnect, expiry, consume, unregister, and
counterpart pair — become atomic ledger calls that win removal and deliver on
the channel through one private `resolve` chokepoint (the only writer of any
`result` channel). This eliminates the three scattered delivery conventions and
the returned-`[]waiterNotification` dance.

Self-resolution paths — dial timeout and long-lived notify-write failure — use a
ledger **remove-win** method that does no channel send and no connection I/O; the
lifecycle writes the wire error itself. The earlier draft incorrectly folded
timeout into channel delivery; that is corrected here.

`Reject(handle, err)` is a single ledger method that interprets the waiter
handle's mode metadata under `mu`; the old `removeWaitingWithResult` and
`removeLongLivedWaiterWithResult` are deleted, and the watcher no longer carries
raw remover callbacks.

Resolution is unified across both rendezvous modes because the pairing itself is
mode-blind. **Entry stays mode-specific** — ephemeral waiting/consumed keyed
maps and long-lived persistent registration, pending queue, and notify handshake
differ for real reasons, and ADR-0001 DP3 commits only to shared byte-forwarding,
pair-timeout, and rate-limiting machinery, not shared registration. Merging
entry would manufacture a shallow seam; the consideration's reviewers agreed.

Post-decision note (PR #492): the root `wiremux.Dial` orchestration later
extended ephemeral entry consumption to paired terminal identity failure. This
does not change this ADR's decision that rendezvous entry remains mode-specific.
PRD-0001 is the current living contract.

**Expiry scope:** ledger cleanup expiry (`cleanupExpiredLocked` over the
`waiting`/`consumed` heaps) covers ephemeral waiting and consumed entries only.
Long-lived pending waiters are not heap-indexed and are bounded by the handler's
pair-timeout, disconnect, unregister, or accept — not by the cleanup ticker. This
is existing behavior, documented here; v1 does not add independent ledger expiry
for long-lived pending waiters.

### D4: The disconnect watcher splits along the seam

`watchWaiterDisconnect` keeps its protocol-I/O job — buffering the waiting peer's
prefix bytes for forwarding — in `rendezvousLifecycle`. Its decision job moves:
`beginEphemeralDial`/`beginLongLivedDial` mint and return the waiter handle, the
watcher closes over that handle, and on disconnect it calls
`ledger.Reject(handle, errWaiterDisconnected)`. Removal authority under `mu` makes
any tie with an in-flight claim safe: exactly one of disconnect or claim wins
removal. Prefix read-ahead is quiesced (watcher joined) before the pairing handle
exposes the prefix snapshot, so the slice and connection handoff are race-free
under `go test -race`.

### D5: Terminology

`CONTEXT.md` defines **waiting peer**, **rendezvous pairing**, **rendezvous
ledger**, and **pair resolution**, and states the outcome-once invariant (a
waiting peer is resolved exactly once; channel delivery carries only
cross-goroutine resolution). A rendezvous pairing (two peer connections at the
relay) is explicitly distinct from a selected candidate pair (two addresses on
the direct path). The module keeps the name `rendezvousLedger`; the new handle
types are `waiterHandle` and `pairing`, unambiguous within `package relay`.

### D6: `errPairingAbandoned` is a defined sentinel with an explicit wire mapping

`errPairingAbandoned` is defined in `relay/errors.go`. It fires only on an
internal fault (panic or early return in the claim-to-guard window), never in
correct operation. `codeForError` maps it to an internal/server-fault status
(not the default `errorCodeProtocol`), and `finishWaiterResult` writes that
status to the waiting peer so the peer receives a deliberate, distinguishable
code rather than a mislabeled protocol error.

## Consequences

- The exactly-once invariant gains locality and a precise statement: removal
  under `mu` is the single authority; the result channel carries only
  cross-goroutine delivery; self-resolution writes its own wire. "No peer hangs"
  and "accounting never drifts" both become structural rather than conventional.
- The relay's hardest concurrency becomes unit-testable without TLS or sockets.
  Implementation acceptance requires deterministic `relay/ledger_test.go` tests,
  run under `-race`, covering at minimum: stale `Reject` after claim cannot
  override `Succeed`/`Fail`; `Fail` releases `activePairs`/`pairedRefs` exactly
  once; `Succeed` transfers release to proxy completion exactly once; double
  `Succeed`/`Fail` neither double-sends nor double-releases; a dropped/abandoned
  handle resolves once and releases accounting; timeout-vs-pair and
  disconnect-vs-pair races; expire-vs-claim race; ephemeral `Reject` removes
  `waiting`+heap state; long-lived `Reject` removes `registration.pending` and
  decrements `longLivedWaiting`; prefix read-ahead is quiesced before the prefix
  snapshot/proxy handoff; and `errPairingAbandoned` maps to the intended status.
  `snapshot().activePairs == 0` and `pairedRefs == 0` are the post-resolution
  assertions for the accounting tests.
- The change is behavior-preserving and entirely internal to `package relay`
  (`rendezvousLedger`, `rendezvousLifecycle`, the handle types are all
  unexported). wiremux's public API is unchanged, so no downstream consumer
  (codemux, keymux, or external) is affected and no follow-up PRs are required
  there. The existing `relay/relay_test.go` integration suite remains a
  regression net, but it is not a substitute for the ledger race tests above.
- A future reviewer who sees the ledger writing a result channel, the handle
  indirection, or the self-timeout path that bypasses the channel should treat
  all three as deliberate. Collapsing the handles back into a returned waiter,
  routing self-timeout through the channel, or moving resolution back to callers
  re-introduces the hang-forever and accounting-drift classes this ADR removes.
- Entry remaining mode-specific is intentional; a future "unify the two
  rendezvous modes" proposal must reckon with ADR-0001 DP3 and D3 above.
