# The one fork bundle: consumer requirements and consumer gates

**Date:** 2026-10-19
**Status:** Accepted; not yet implemented. Amended 2026-10-20 by two owner decisions: F5 is re-decided and re-gated (see [F5](#fork-slice-f5--1024-packet-unprocessed-packet-queue-after-handshake-confirmation) and [Task 4.G1](#task-4g1--deeper-queues-gate-f1-and-f5)), and F4 is kept as merged with amended readings (see [F4](#fork-slice-f4--32-entry-send-queue-for-every-connection) and [Task 4.G2](#task-4g2--32-entry-send-queue-gate-f4)). Amended 2026-10-21 by a second F5 decision: the changed F5 failed one re-gate row, and its condition now applies at every depth (see [F5](#fork-slice-f5--1024-packet-unprocessed-packet-queue-after-handshake-confirmation) and [Task 4.G1](#task-4g1--deeper-queues-gate-f1-and-f5)). Amended again on 2026-10-21 by a reading decision: the stock Datagram workload's latency is judged on the smoothed-RTT row, as the stream's is, and under it Task 4.G1 passed on `2a83ed29` (see [Task 4.G1](#task-4g1--deeper-queues-gate-f1-and-f5)). Amended on 2026-10-21 by the 4.G3 decision: F8 failed five rows as written, and the owner kept it at cap 32 with those rows accepted in writing until slice 6.3 (see [F8](#fork-slice-f8--send-batch-cap-follows-the-queue-depth) and [Task 4.G3](#task-4g3--batch-cap-ship-gate-f8)). Amended on 2026-10-21 by the 4.G5 decision: F10 failed one row as written (the Datagram minimum RTT), the owner accepted it with latency judged on the row's own mean-RTT bound, and gluing ships on by default (see [F10](#fork-slice-f10--equal-size-datagram-gluing) and [Task 4.G5](#task-4g5--equal-size-gluing-gate-on-the-bundle-candidate-f10)). Amended on 2026-10-22 by the 4.G6 decision: F11 passes on both platforms under three owner readings, F11 ships, and slice 5.4 grants x64 and Arm64 (see [F11](#fork-slice-f11--windows-copy-at-read-the-missing-record-guard-and-slab-retirement) and [Task 4.G6](#task-4g6--windows-copy-at-read-gate-f11)). With it every consumer task of this track (4.R and 4.G1–4.G6) is complete.
**Track:** 4 of 7 in program NG-20261019
**Depends on:** Slice 3.1 ([2026-10-19-native-observability-plan.md](2026-10-19-native-observability-plan.md)) for Task 4.R, and through 4.R for every gate task. The eleven fork slices depend on nothing in wiremux.
**Program:** [2026-10-19-native-gap-program.md](2026-10-19-native-gap-program.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers and stop conditions
**Audit history:** [2026-10-19-native-gap-handoff-audit.md](2026-10-19-native-gap-handoff-audit.md)
**Parent issue:** pending
**Decided by:** [How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507); [Which per-packet allocation removals should the native path adopt?](https://github.com/GridSwarm/wiremux/issues/1832#issuecomment-6152076446); [Should native receives adopt coalescing once the fork copies coalesced datagrams at read time?](https://github.com/GridSwarm/wiremux/issues/1835#issuecomment-6196268143) (mechanism from [Why does native receive coalescing cost throughput in the netns shape cell?](https://github.com/GridSwarm/wiremux/issues/1829#issuecomment-6154923896)); [Should the fork raise its packet send queue from 8 to 32 entries?](https://github.com/GridSwarm/wiremux/issues/1850#issuecomment-6207580215) (background [Why do slice A and the fork's ownership APIs cost the stock Datagram sender 3–5% at a consumer-sized heap?](https://github.com/GridSwarm/wiremux/issues/1845#issuecomment-6201012510)); [Should native connections get a deeper unprocessed-packet queue than the fork's 256 packets?](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120); [Should native connections acknowledge less often, and through which fork mechanism?](https://github.com/GridSwarm/wiremux/issues/1859#issuecomment-6224678494) (background [How much native send cost and throughput would fewer acknowledgments buy on macOS?](https://github.com/GridSwarm/wiremux/issues/1854#issuecomment-6221871999)); [Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863#issuecomment-6235627888) (with its [input from the receiving-Mac load ticket](https://github.com/GridSwarm/wiremux/issues/1863#issuecomment-6247569200)); [Should the fork's send batch cap follow its 32-entry send queue?](https://github.com/GridSwarm/wiremux/issues/1864#issuecomment-6240753010) (background [How much would a fork send batch cap above 8 add once the macOS receiver is faster?](https://github.com/GridSwarm/wiremux/issues/1862#issuecomment-6236968867)); [Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6240861645) (with the [busy-receiving-Mac row](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6251638999) from [Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?](https://github.com/GridSwarm/wiremux/issues/1868#issuecomment-6251637328)); [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084); [Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572) (background [Does Windows native receive coalescing (URO) fit wiremux's admission, and what does it buy through wiremux?](https://github.com/GridSwarm/wiremux/issues/1869#issuecomment-6257878249)); the bundle paragraph of [Wayfinder map: close the gap between native QUIC and TCP throughput](https://github.com/GridSwarm/wiremux/issues/1794) Notes; and section 5 of [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797). Packaging inputs on [Package the decided native-gap execution as dispatchable issues](https://github.com/GridSwarm/wiremux/issues/1871): [adopt quic-go-fast#824 for the first slice](https://github.com/GridSwarm/wiremux/issues/1871#issuecomment-6256404586), [the first slice landed](https://github.com/GridSwarm/wiremux/issues/1871#issuecomment-6258478107), [the Windows corrections](https://github.com/GridSwarm/wiremux/issues/1871#issuecomment-6259142960).

## Goal

Eleven decided fork changes ship in one quic-go-fast release, so wiremux and its downstream repin once and audit one release diff. The fork owns the code; this plan owns what the consumer requires of it: each slice's decided behaviour, the guards the consumer found in the fork's code, the fork-side tests, the consumer gate that admits a default-on slice to the release, and the rules that decide what the release carries. The seam is the fork's versioned, interface-asserted capability surface (the `Configure…V1` family on `Transport` and the `…V1` methods on `Conn`), which keeps [ADR-0014](adr-0014-optional-quic-fork-integration.md)'s upstream build intact. The leverage is one release, one repin ([Track 5](2026-10-19-bundle-adoption-plan.md) slice 5.1) and one evidence record that cites seven measured consumer gates instead of eleven unmeasured fork merges.

The track has two parts. **Part A** is the eleven fork slices F1–F11, filed in the-sarge/quic-go-fast as ordinary self-contained public issues under one bundle-release parent issue. **Part B** is seven wiremux task issues: Task 4.R prepares the measurement rig, and Tasks 4.G1–4.G6 run the consumer gates of the default-on slices on fork commits before the release is cut. No wiremux `main` code changes in this track.

Related records: [ADR-0014](adr-0014-optional-quic-fork-integration.md) (fork integration stays optional; fork capabilities are found by interface assertion); the fork's [ADR 0005](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/docs/adr/0005-incoming-packet-lifetime.md) (incoming packet lifetime, with the 2026-09-11 slab exception F11 retires); [Track 5](2026-10-19-bundle-adoption-plan.md) (the repin and the F2 adoption, and the Linux and Windows coalescing switches that repeat the F3 and F11 measurements); [Track 6](2026-10-19-macos-native-stack-plan.md) (the macOS switch slices that gate F6, F7 and F9); [Track 7](2026-10-19-native-certification-plan.md) (certification after the bundle).

## Current Shape (verified 2026-10-19)

**Fork.** Fork `main` is [`5b05133d`](https://github.com/the-sarge/quic-go-fast/commit/5b05133dcc878d847123d9485206b77d42426453) (committed 2026-10-18 23:38 ET), 76 commits past the latest release `v0.62.1-fast.7` (`55ea687d`); every fork anchor in this plan is at that pin. Fork `main` has since moved: at 2026-10-19 01:20 ET it was `f0d56068`, six commits later (a migration-probe amplification fix and HTTP/3 changes, touching `connection.go`, `packet_emission.go` and `packet_packer.go` among others), so a fork agent re-locates the anchors at pickup. No release carries any bundle slice.

- **F1 is merged.** [Deepen the received-DATAGRAM queue and make its discards visible before a release ships #743 on by default](https://github.com/the-sarge/quic-go-fast/issues/824) landed as `42b9b5de` ([PR #829](https://github.com/the-sarge/quic-go-fast/pull/829)): [`datagram_queue.go` L15](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L15) `maxDatagramRcvQueueLen = 1024`, the counter [L26](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L26) incremented at [L112](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L112) in `HandleDatagramFrame` ([L95–L116](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L95-L116)), and [`(*Conn).DatagramReceiveDropsV1`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2996-L3006), whose doc comment names its exclusions.
- **F10 is merged and on by default.** [GSO emission costs ~3% throughput when each send carries one packet](https://github.com/the-sarge/quic-go-fast/issues/742) landed as `592e98cb` ([PR #805](https://github.com/the-sarge/quic-go-fast/pull/805)) and [Consider GSO-batching equal-size short packets with the first packet's size as the segment](https://github.com/the-sarge/quic-go-fast/issues/743) as `9b52dca8` ([PR #818](https://github.com/the-sarge/quic-go-fast/pull/818)): [`packet_emission_gso.go` L12–L14](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_gso.go#L12-L14) caps a send at 64 segments, [L19](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_gso.go#L19) names the kill switch `QUIC_GO_DISABLE_SHORT_GSO_SEGMENTS`, and [`connection.go` L2714](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2714) reads it once per connection.
- **The send queue is per-controller.** [`send_queue.go` L109](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L109) `sendQueueCapacity = 8`, [L117](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L117) `bbrSendQueueCapacity = 32`, and [L120](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L120) `maxSendBatch = sendQueueCapacity`; [`sendQueueCapacityFor`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission.go#L604-L610) keeps the choice across path replacement.
- **Nothing of F2–F9 or F11 exists.** [`internal/protocol/params.go` L43](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/protocol/params.go#L43) `MaxConnUnprocessedPackets = 256`; [`internal/ackhandler/received_packet_tracker.go` L79](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L79) `packetsBeforeAck = 2` with the alarm restart at [L126–L132](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L126-L132); [`sys_conn_helper_darwin.go` L22](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_helper_darwin.go#L22) `batchSize = 1`; the admission copies at [`packet_policy.go` L50](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L50) and [L73](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L73); Linux and Windows coalesced reads still go through the slab ([`coalesced_delivery.go` L24–L47](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/coalesced_delivery.go#L24-L47)). No fork issue exists for any of them.
- **Readouts.** [`ConnectionStats`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L858-L894) carries `MinRTT`, `SmoothedRTT`, `PacketsReceived` and `PacketsLost`. PTO counts and spurious losses exist only as qlog events ([`qlog/event.go` L512](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/qlog/event.go#L512), [L547](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/qlog/event.go#L547)).
- **The fork's BBR campaign.** [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808) is registered on `main` with F1 and F10 in (draft [PR #835](https://github.com/the-sarge/quic-go-fast/pull/835); at its last update, 2026-10-19 00:03 ET, the readiness stage had not started), and states: "If a BBR or send/receive-path code change lands before the readiness run, the agent stops and asks." The fork's BBR rule, set by [Port the corrected BBRv3 sender (r9) into main's experimental opt-in sender](https://github.com/the-sarge/quic-go-fast/issues/748) ([`docs/agents/bbr-production-port.md` L13](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/docs/agents/bbr-production-port.md?plain=1#L13)) and restated in that campaign's issue ("Every change to BBRv3's code, including its send path, makes a new revision"), makes every BBRv3 code change a new revision needing its own readiness measurement.
- **Fork CI** runs the unit suite on Ubuntu, Windows and macOS ([`.github/workflows/unit.yml` L14](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/.github/workflows/unit.yml#L14)).

**wiremux.** `main` is `467fc555`. [`go.mod` L12](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/go.mod#L12) pins upstream quic-go v0.62.0 with no `replace`; native work runs in the fork lane through an isolated `-modfile`. The native endpoint registers always-true admission callbacks ([`internal/nativequic/endpoint.go` L206](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/endpoint.go#L206), [L216](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/endpoint.go#L216)) and withholds receive coalescing ([L222](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/endpoint.go#L222)), reaching fork capabilities only through [`transportV1`](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/capability.go#L23-L30) by interface assertion ([L52](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/capability.go#L52)). Upgraded QUIC Wires use the fork's managed or external packet I/O ([`transport/internal/adapter/packet_permission.go` L34–L66](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/transport/internal/adapter/packet_permission.go#L34-L66)), and fork managed mode turns coalescing on by itself ([`managed_packet_receive_linux.go` L60](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/managed_packet_receive_linux.go#L60), [`managed_packet_receive_windows.go` L45–L46](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/managed_packet_receive_windows.go#L45-L46)), so F3 and F11 reach upgraded Wires at the repin without any wiremux switch. Nothing on `main` reads a fork counter or `ConnectionStats` behind a native Wire; slice 3.1 adds that seam.

**The rig.** Branch `codex/native-gap-rig` at `b47a253a` (never merged). [`rig.mod`](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/rig.mod) replaces quic-go with `v0.62.1-fast.7`, and [`MODFILE`](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/rig.sh#L38) selects another module file per campaign. [`GATE`](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/rig.sh#L295) runs before every run, [`LOADGATE`](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/rig.sh#L115-L130) waits on `tb` load, and [`PORT`](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/rig.sh#L45) moves the receiver off the shared port. Arms are `udp`, `binding`, `dgram`, `stream` and `tcp` ([`main.go` L174](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/main.go#L174)): no mixed stream-and-Datagram arm, and [ARMSPEC](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/rig.sh#L11) passes only rig flags, no per-arm environment. It builds no `windows/arm64` binary ([L54–L60](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/rig.sh#L54-L60)). [PROTOCOL.md](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/PROTOCOL.md) defines the A/B rule ([L124](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/PROTOCOL.md?plain=1#L124): "A, B, A, B, each `REPS=3`. Compare the pooled medians, and report all four campaigns") and "Every run is reported, and none is ever dropped or quietly re-run" ([L184](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/PROTOCOL.md?plain=1#L184)), but no certification campaign. The `winvm` guest was deleted on 2026-10-18; its rebuild recipe is `native-gap-evidence/1869-windows-uro/vm/REBUILD.txt`. The Windows 11 Arm64 cell is not built.

## Decision

### One release, two kinds of slice

The bundle is the vehicle every fork-side decision chose: [Should the fork raise its packet send queue from 8 to 32 entries?](https://github.com/GridSwarm/wiremux/issues/1850#issuecomment-6207580215) set it up ("None of the four ships alone, so wiremux and GridCast repin once. The owner chose this over shipping in the next fork release with no holds"), and every later fork decision joined it. The map's Notes fix its content and its holds (quoted under [Bundle release rules](#bundle-release-rules)).

The slices come in two kinds, as [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084) states: "the bundle's other internal, wire-invisible slices (the received-Datagram queue, the 32-entry send queue, the batch cap)" are default-on, while "The opt-in slices (ack every 16, the admits mode, read slots) change peer-visible behaviour, admission callbacks or adapter contracts."

| Kind | Slices | Consumer gate | When |
| --- | --- | --- | --- |
| Default-on (reaches every fork connection, or every reader with coalescing on, with no consumer switch) | F1, F3, F4, F5, F8, F10, F11 | A wiremux gate task (4.G1–4.G6) through the rig, the fork change against the fork commit it lands on | After the fork slice merges on fork `main`, before the bundle release is cut |
| Opt-in (off until a consumer switches it on) | F2, F6, F7, F9 | Fork-side tests before the release; the consumer's measured gate is the wiremux switch slice after adoption: 5.2 (F2), 6.1 (F6), 6.4 (F7), 6.2 (F9) | Fork tests at merge; switch gates after slice 5.1 |

A default-on slice ships only after its consumer gate passed ([H14](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). Base arms that need a counter the parent commit lacks use a local one-line fork copy at the old depth, the precedent [Should the fork's send batch cap follow its 32-entry send queue?](https://github.com/GridSwarm/wiremux/issues/1864#issuecomment-6240753010) set for its cap-8 arm ("a local one-line fork copy, as the rig already builds").

### How fork slices are filed

wiremux is private and the fork is public, so the filing follows [H11](2026-10-19-native-gap-handoff-audit.md#handoff-decisions). Every fork slice is an ordinary self-contained fork issue in the style of [GSO emission costs ~3% throughput when each send carries one packet](https://github.com/the-sarge/quic-go-fast/issues/742), [Consider GSO-batching equal-size short packets with the first packet's size as the segment](https://github.com/the-sarge/quic-go-fast/issues/743) and [Deepen the received-DATAGRAM queue and make its discards visible before a release ships #743 on by default](https://github.com/the-sarge/quic-go-fast/issues/824), written as "a downstream consumer", with this header line: `> *This was generated by AI from a downstream consumer's planning.*` One fork **bundle-release parent issue** carries every slice as a sub-issue, the retained F1 and F10 issues included. They are not architecture-handoff children in the fork. Labels follow the fork's [triage labels](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/docs/agents/triage-labels.md): frontier slices get `ready-for-agent` and `enhancement`; a blocked slice carries native `blocked_by` and no readiness label. At filing, F8 is blocked by F4 and F11 by F3; F2–F7 and F9 are frontier. Retained work (F1, F10) gets a consumer comment recording acceptance and the outstanding gate, not a body rewrite ([H12](2026-10-19-native-gap-handoff-audit.md#handoff-decisions); for F10, [H30](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).

**Public-brief rules (every fork issue, every consumer comment in the fork tracker):**

- **Never in public text:** links to GridSwarm/wiremux (issues, comments, blobs, research notes); host names (mbp128, m4mini, minimax, imacpro, m1mini); GARM pool names; guest names and their paths; evidence paths (`/Volumes/worktrees/...`, `native-gap-evidence/...`); probe diff names; rig branch names, commits and flags; session names; review run ids; the name GridCast and its internals; wiremux work names ("slice A", "slice B", "native Wire", `NativeConfig`). The fork's own merged records already name the Linux host in places; new text still follows this rule.
- **Cells, in these words:** `tb` = "two Apple-silicon Macs over a Thunderbolt Bridge at MTU 1500"; `netns` = "two Linux network namespaces joined by a veth pair on one host (MTU 1500, sender and receiver on different CCDs, no NIC offload)"; `winvm` = "a Windows Server 2025 VM (virtual e1000e NIC, software URO) receiving from its Linux host"; Arm = "a Windows 11 Arm64 VM receiving from its macOS host". Non-identifying detail may be added (macOS 27, Linux 7.0, the M4 Max sender and M4 Pro receiver, 4 pinned vCPUs, Receive Buffers 2,048). The pin is "a 64 MiB pointer-free ballast heap on both peers (a consumer-sized heap), with the default-GC row reported beside it". wiremux's native connections are "the consumer's own peer-to-peer connections"; its upgraded QUIC Wires are "the consumer's other QUIC connections".
- **Figures** keep their **measured** / **derived** / **source** labels and say "measured downstream".
- **Brief outline:** header line; Behaviour (decided, in the fork's terms); Why (measured downstream); Guards and safeguards; Tests; Downstream gate (what the consumer measures, when, and that it posts the result on this issue and the release issue); Release (bundle membership, holds or never holds, ordering); Not requested (the rejected alternatives the fork would otherwise propose).

### Bundle release rules

The map's Notes, verbatim:

> The one fork bundle: eleven decided fork slices ship in a single fork release, so wiremux and GridCast repin once. […] The seventh to eleventh never hold the bundle: the bundle ships without whichever of them isn't ready, and it goes in the next fork release. The eighth ships even if the seventh slips, the ninth is tied to neither, the tenth never ships ahead of the two deeper queues (the first and fifth), and the eleventh never lands ahead of the first and third (the received-Datagram queue and Linux copy-at-read).

Section 5 of [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797), verbatim:

> - The unprocessed-packet queue never ships ahead of the received-Datagram queue.
> - The batch cap lands after the 32-entry queue.
> - Read slots, the batch cap and the send hook never hold the release.
> - The rig gains RTT, PTO and spurious-loss readouts before those gates run.

Handoff decision [H15](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), which binds them, verbatim:

> Eleven slices in one fork release; slices 1–6 hold it; "The seventh to eleventh never hold the bundle: the bundle ships without whichever of them isn't ready, and it goes in the next fork release. The eighth ships even if the seventh slips, the ninth is tied to neither, the tenth never ships ahead of the two deeper queues (the first and fifth), and the eleventh never lands ahead of the first and third". The unprocessed-packet queue never ships ahead of the received-Datagram queue; the batch cap lands after the 32-entry queue. A default-on slice ships only after its consumer gate passed (or, for a never-hold slice, is left out). If a never-hold slice slips to a later release, its dependent wiremux slices wait for that release and the operator runs a scoped `/architecture-handoff` to add the second repin.

What these rules mean for the release:

- **The release is cut** when F1–F6 have merged, F2's and F6's fork tests pass, and the consumer gates of the holding default-on slices have passed: 4.G1 (F1, F5), 4.G2 (F4) and 4.G4 (F3). Each never-hold slice is in only if it has merged and, when default-on, its gate passed: 4.G3 (F8) and 4.G6 (F11). F8's gate is met by the owner's acceptance of 2026-10-21 (below). F7 and F9 are in when merged with their fork tests green. F10 is already merged; it ships on by default only if 4.G5 passed. 4.G5 passed on 2026-10-21 under the owner's reading (below), so F10 ships on by default. 4.G6 passed on 2026-10-22 under the owner's decision (below), so F11 ships.
- **A failed gate on a holding slice** (F1, F3, F4, F5): the release does not ship that slice as merged. The fork reverts or reworks it on `main`; the operator decides through the map whether the release waits for a re-decided slice, and posts that decision on the release issue. Gate tasks report; they never revert fork code. A carried slice that is reverted or reworked voids every gate measured on a candidate that carried it; the operator re-dispatches those gates.
- **The two holding-slice failures of 2026-10-20 and their decisions:**
  - **F5** failed 4.G1's F5 rows as written. The owner re-decided it: the fork changes F5 (see [F5](#fork-slice-f5--1024-packet-unprocessed-packet-queue-after-handshake-confirmation)), and F5 still holds the release. The changed F5 lands as a new merge on fork `main`; 4.G1's F5 rows are re-gated on that merge under the re-read rows, and F1's `netns` set re-runs, because its arms carried the reworked F5. 4.G3 and 4.G6 are measured on candidates carrying the change, and 4.G5 and the release wait for it.
  - **F5 again, 2026-10-21:** the changed F5 (`5f73ddc4`) failed one re-gate row (received-Datagram discards rose on `netns`). The owner chose to extend its condition to every depth (see [F5](#fork-slice-f5--1024-packet-unprocessed-packet-queue-after-handshake-confirmation)); the fork merged that as `2a83ed29`. 4.G1's F5 rows and F1's `netns` set run a third time on `2a83ed29`. 4.G3 and 4.G6 are measured on candidates carrying `2a83ed29`, and 4.G5 and the release waited for that third run (satisfied on 2026-10-21, next item; the release's other prerequisites are unchanged).
  - **4.G1 passed on `2a83ed29`, 2026-10-21.** The third run failed one row as written (the `netns` stock-Datagram lifetime minimum RTT, +0.8 µs against 0.6 µs noise). The owner extended the 2026-10-20 stream-latency re-reading to the Datagram workload ([decision](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6323452830)), and under it every row passes. F1 and F5 have met their consumer gates, and 4.G1's release prerequisite is met.
  - **F4** failed six of 4.G2's rows as written. The owner kept it as merged with amended readings (see [Task 4.G2](#task-4g2--32-entry-send-queue-gate-f4)). Under them every 4.G2 row passes or is accepted, so 4.G2's release prerequisite is met and F4 no longer holds the release back. F4 stays a holding slice the release must carry. No gate is voided, because F4 is not reworked.
- **A failed gate on a never-hold default-on slice** leaves it out: F8 ships at cap 8 ("A failure means the bundle ships without the cap, and the cap comes back to the map"); F11 waits for the next fork release; F10 follows the rule below.
  - **F11, 2026-10-22:** 4.G6's measured rows passed on x64 and Arm, but its Tests row was not met as written, and the Arm guest crashed once. The owner passed both platforms ([decision](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345797171); see [Task 4.G6](#task-4g6--windows-copy-at-read-gate-f11)): the Tests row is accepted as run, the Arm CPU row is judged on the receiving process, and the crash is accepted and watched in [#1988](https://github.com/GridSwarm/wiremux/issues/1988). F11 ships in the release, slice 5.4 grants x64 and Arm64, and no gate is voided.
  - **F10, 2026-10-21:** 4.G5 failed one row as written, the Datagram workload's minimum RTT. The owner accepted it ([decision](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331887768), [reading](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331999513); see [Task 4.G5](#task-4g5--equal-size-gluing-gate-on-the-bundle-candidate-f10)): the minimum RTT is reported, not judged, and latency is judged on the row's own mean-RTT bound, which passed. Under that reading 4.G5 passed, so [If F10's consumer gate fails](#if-f10s-consumer-gate-fails) does not apply: F10 ships in the release on by default, and no gate is voided.
  - **F8, 2026-10-21:** 4.G3 failed five rows as written. The owner kept F8 at cap 32 instead and accepted those rows in writing until slice 6.3's batched send ([decision](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6330277355); see [Task 4.G3](#task-4g3--batch-cap-ship-gate-f8)). F8 ships in the release at cap 32, and no gate is voided, because F8 is not reverted or reworked. Its check on the batched macOS shape is slice 6.4's cap-8 arm, which gains a mean-RTT-under-load row.
- **Ordering at release:** no release carries F5 without F1, F8 without F4, F10 on by default without F1 and F5, or F11 without F1 and F3. F1 is merged, so F5's ordering already holds.
- **Scheduling against the fork's BBR campaign.** F2, F3, F5, F7 and F11 touch the receive and admission paths [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808)'s readiness run guards, and F8 raises BBR's batch cap (a new BBR revision under the fork's rule); the release issue asks the fork to schedule them with that campaign ([H13](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). F4 (the default send queue), F6 (the receiver's acknowledgment tracker) and F9 (the top of `sendQueue.Run`) are send or receive-path code too, so the release issue names every bundle slice that would merge before the campaign's readiness run; for F4, F6 and F9 the fork decides how to schedule them.
- **A slipped never-hold slice** goes in the next fork release; the wiremux slices that need it wait for that release, and the operator runs a scoped `/architecture-handoff` to add the second repin.

### If F10's consumer gate fails

Equal-size gluing is already on by default on fork `main`, so "leave it out" cannot mean an unmerged slice ([H12](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). If Task 4.G5 fails, the bundle release must ship gluing **off by default** (the fork chooses a revert or a default flip), and gluing returns to the map as a diagnosis issue. Independently of the gate, the consumer adopts no fork release that has gluing on by default without both deeper queues (F1 and F5). The fork's own release condition ("No release ships it on by default until #824 [...] lands, or the release sets the kill switch") is met by F1 alone; if the fork cuts a release from `main` for its own reasons before F5 lands, wiremux does not adopt it unless gluing is off by default in it.

**Status (2026-10-21).** Task 4.G5 passed on `642f014e` under the owner's reading of its round-trip-time row (see [Task 4.G5](#task-4g5--equal-size-gluing-gate-on-the-bundle-candidate-f10)), so this rule did not apply: the release ships gluing on by default. The independent rule above still holds: wiremux adopts no release with gluing on by default without F1 and F5.

### Rejected alternatives

**Rejected alternative (do not do this):** Ship each fork slice in the next fork release as it merges, with no holds. The owner chose the bundle: "None of the four ships alone, so wiremux and GridCast repin once. The owner chose this over shipping in the next fork release with no holds." **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** File the fork slices as architecture-handoff children in the fork, or with links to this plan. The fork is public and this repo is private; the fork executes ordinary self-contained issues ("Fork changes are decided here and executed in the fork's tracker", map Notes). **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** Accept the fork's own loopback records as the consumer gates for F1 and F10. They ran a fork harness on single-host loopback, not the consumer's cells; the Datagram GSO decision's shape-cell gate "replaces #743's owned-host gate". The records are early warnings only. **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** Measure a counter row against the pre-slice parent commit. The parent has no counter, so rows such as "unprocessed-packet drops, read by the new counter, at least halved" cannot be read; the base is the slice with a one-line change back to the old depth. **Revisit if:** none: rejected on merit.

**Rejected alternative (do not do this):** Adopt the release first and gate default-on slices afterwards in wiremux. Default-on slices have no wiremux switch to turn off, so a post-adoption gate could only revert the repin. **Revisit if:** none: rejected on merit.

**Owner's design:** The fork is the state owner of every changed fact, and the owner's design is adopted throughout: depths are fork constants, modes are fork configuration on `Transport`, counts are fork methods on `Conn`. The contained choices are the internal shapes. The counts are versioned methods found by interface assertion rather than public fields on `ConnectionStats` (which [Deepen the received-DATAGRAM queue and make its discards visible before a release ships #743 on by default](https://github.com/the-sarge/quic-go-fast/issues/824) placed out of scope; [How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507) notes that "A public count would also have to mean 'unknown', not 0, on plain upstream quic-go"); the admits mode declares the real admission owner rather than adding a facts callback; acknowledging every 16 is a receiver rule rather than the IETF Acknowledgment Frequency extension (the owner's long-term design, [Finish the IETF QUIC Acknowledgment Frequency extension (draft-ietf-quic-ack-frequency)](https://github.com/the-sarge/quic-go-fast/issues/645), recorded as F6's rejected alternative with its reopen trigger).

**Non-goals:** wiremux `main` code (every wiremux artifact here is rig-branch commits, evidence and task records); cutting, tagging or reverting anything in the fork (the fork's agents and owner do that); the repin and evidence record (slice 5.1); the opt-in switch slices (5.2, 6.1, 6.2, 6.4); certification (Track 7); the fork's ownership-taking Datagram APIs (dropped by the Datagram GSO decision); a `PathMTUSettledV1` fork signal (a follow-up outside this program if slice 1.2's gate triggers it); the Acknowledgment Frequency extension; jumbo frames; the fork's BBRv3 qualification ([BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808) and its program); upstream reports; new CI lanes; downstream repins outside wiremux.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| F1 | retain ([quic-go-fast#824](https://github.com/the-sarge/quic-go-fast/issues/824), `42b9b5de`); holds | 1,024-entry received-DATAGRAM queue, full-queue discards counted | None (merged) | n/a |
| F2 | new, to be filed; opt-in; holds | Admits mode: the transport calls neither admission callback | None | n/a |
| F3 | new, to be filed; default-on; holds | Linux copy-at-read for coalesced reads | None | Linux stops producing slabs (Windows keeps them until F11) |
| F4 | new, to be filed; default-on; holds | 32-entry send queue for every connection, batch cap kept at 8 | None | Per-controller depth (`sendQueueCapacityFor`, `bbrSendQueueCapacity`) |
| F5 | new, to be filed; default-on; holds | Unprocessed-packet queue 1,024 after handshake confirmation, 256 before; with DATAGRAM support, a packet is admitted at any depth only while queued packets plus queued received Datagrams stay below 1,024 (re-decided 2026-10-20 for entries beyond 256, extended to every depth 2026-10-21, merged as `2a83ed29`), drops counted | F1 (met) | n/a |
| F6 | new, to be filed; opt-in; holds | Receiver rule: acknowledge every N ack-eliciting packets, 1 ms group cap | None | n/a |
| F7 | new, to be filed; opt-in; never holds | Darwin read slots for batch-capable adapters that opt in | None | n/a |
| F8 | new, to be filed; default-on; never holds | Batch cap follows the queue depth again (ships at cap 32: 4.G3's five failed rows accepted by the owner on 2026-10-21 until slice 6.3) | F4 | F4's split cap |
| F9 | new, to be filed; opt-in; never holds | User-initiated send thread on Apple silicon | None | n/a |
| F10 | retain ([quic-go-fast#742](https://github.com/the-sarge/quic-go-fast/issues/742) `592e98cb`, [quic-go-fast#743](https://github.com/the-sarge/quic-go-fast/issues/743) `9b52dca8`); default-on; never holds | Equal-size DATAGRAM gluing (ships on by default: 4.G5 passed on 2026-10-21 under the owner's reading) | None (merged); never ships ahead of F1, F5 | n/a |
| F11 | new, to be filed; default-on; never holds | Windows copy-at-read, missing-record guard, slab retirement (ships: 4.G6 passed on 2026-10-22 under the owner's decision) | F3 (F1 met) | Coalesced slab and ADR 0005's atomic exception |
| 4.R | new wiremux task | Rig readouts, arms, build recipes and protocol text for the gates | 3.1 | n/a |
| 4.G1 | new wiremux task | Deeper-queues gate (F1, F5) | 4.R, F5 merged | n/a |
| 4.G2 | new wiremux task | 32-entry send queue gate (F4) | 4.R, F4 merged | n/a |
| 4.G3 | new wiremux task | Batch cap ship gate (F8) | 4.R, F8 merged, the final F5 merged (`2a83ed29`, 2026-10-21) | n/a |
| 4.G4 | new wiremux task | Linux copy-at-read gate (F3) | 4.R, F3 merged | n/a |
| 4.G5 | new wiremux task | Equal-size gluing gate on the bundle candidate (F10) | 4.R, 4.G1, 4.G2, 4.G4 | n/a |
| 4.G6 | new wiremux task | Windows copy-at-read gate (F11) | 4.R, F11 merged, the final F5 merged (`2a83ed29`, 2026-10-21), the owner's OK for both guests | n/a |
| Release | fork bundle-release parent issue | One fork release carrying the passed slices | F1–F6 merged; 4.G1, 4.G2, 4.G4 passed (4.G2 met on 2026-10-20: every row passed or accepted under the owner's amended readings; 4.G1 met on 2026-10-21: its third run on the final F5 `2a83ed29` passed under the owner's extended reading); never-hold F8 in at cap 32 (4.G3 met on 2026-10-21: every row passed or was accepted by the owner); F10 on by default (4.G5 met on 2026-10-21: every judged row passed under the owner's reading of its round-trip-time row); never-hold F11 in (4.G6 met on 2026-10-22: every row passed under the owner's decision on both platforms) | n/a |

Downstream: slice 5.1 is blocked by the release, 3.1 and the recorded results of 4.G1, 4.G2, 4.G4 and 4.G5, plus 4.G3 if F8 ships in the release and 4.G6 if F11 ships in it.

## Part A: Fork slices

Every section below is the consumer's normative requirement for one fork slice and the source for its public brief. Fork anchors are at fork `main` `5b05133d`. "Who runs it" names the party, the cell and the moment. Template fields apply to the fork's change as the fork agent will implement it; the Dispatch context budget states what the fork agent's self-contained brief must carry.

### Fork slice F1 — 1,024-entry received-Datagram queue with an internal discard count

**What it delivers:** Every fork connection's received-DATAGRAM queue holds a fixed 1,024 payloads instead of 128, counted in entries, and the fork counts the payloads it refuses because the queue is full, behind a versioned connection method the consumer finds by interface assertion. Plain upstream quic-go keeps 128.

**Decided fork behaviour** ([How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507)):

> The fork's received-DATAGRAM queue becomes a fixed 1,024 entries, and the fork counts its discards. Wiremux reads that count only internally. No setting, no public API, and no contract text changes.

> `maxDatagramRcvQueueLen` goes from 128 to 1,024 […]. There is no fork setting, no wiremux setting and no consumer setting. Every connection built on the fork gets it, both native and upgraded QUIC Wires. Plain upstream quic-go stays at 128.

> Count discards in `HandleDatagramFrame`'s not-queued path with an atomic counter. Expose the count through a versioned connection method; the fork picks the name, for example `DatagramReceiveDropsV1() uint64`.

**Existing-work disposition:** **Retain** ([H12](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). [Deepen the received-DATAGRAM queue and make its discards visible before a release ships #743 on by default](https://github.com/the-sarge/quic-go-fast/issues/824) merged as `42b9b5de` ([PR #829](https://github.com/the-sarge/quic-go-fast/pull/829)) and closed on 2026-10-19; no release carries it. Accepted deviations: (1) the count covers only full-queue refusals, excluding payloads withheld before the receive phase opens, payloads discarded when it opens and protocol-violation frames ([doc comment](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2996-L3003)). That is narrower than "the fork counts every discard" and exactly the "not-queued path" the fork-slice text names, and the consumer's gates read exactly those discards. (2) Its gate was the fork's single-connection harness on single-host loopback, so the consumer's `netns` gate was still owed: Task 4.G1, met on 2026-10-21 (both F1 rows passed on `2a83ed29`). Also accepted: `Receive` now clears delivered slots so a drained queue pins no payloads. The fork's record (**measured**, fork harness, eight rounds): DATAGRAM loss 1.895% → 0.0122%, queue discards 0% median and 0.0094% at most, throughput 1.021×, receiver CPU per GiB 0.974×, peak RSS 1.084× (16.2 → 17.9 MiB). Packaging posts a consumer comment on the retained issue (no body rewrite) recording acceptance and the outstanding gate, and makes it a sub-issue of the release parent.

**Blocked by:** None (merged).

**Ordering and never-hold rules:** Holds the release. "The slice has no prerequisites and is independent of Datagram GSO, so it can go first." F5 never ships ahead of it, F10 never ships ahead of it, and F11 never lands ahead of it.

**Fork seams:** [`datagram_queue.go` L15](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L15) (depth), [L26](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L26) (`rcvDrops`), [L95–L116](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L95-L116) (`HandleDatagramFrame`, count at [L112](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L112)), [L118–L122](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L118-L122) (`receiveDrops`); [`connection.go` L2283–L2299](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2283-L2299) (`handleDatagramFrame`: oversize violation, withheld before the receive phase opens, then the queue); [`connection.go` L3004](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L3004) (`DatagramReceiveDropsV1`); [`internal/protocol/protocol.go` L111](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/protocol/protocol.go#L111) (`MaxPacketBufferSize = 1452`, the entry bound).

**Required design guards:** None beyond the decided behaviour.

**Required fork-side tests:** Present on `main`: [`TestDatagramReceiveOverflowNoAllocation`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue_test.go#L92), [`TestDatagramReceiveOverflowCount`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue_test.go#L128), [`TestDatagramReceiveDropsExcludeInvalidation`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue_test.go#L149), [`TestDatagramReceiveReleasesDelivered`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue_test.go#L171), [`TestConnectionDatagramReceiveDropsV1`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection_test.go#L3703) and [`TestConnectionDatagramReceiveDropsExclusions`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection_test.go#L3736). The decision named no unit tests.

**Consumer acceptance gate:** verbatim from [How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507):

> Gate: an A/B in the minimax `netns` cell with the faster GSO sender shows zero queue drops at 1,024, and the counter accounts for the 128-entry build's queue loss.

A [packaging input](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6150683086) on [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) words the first clause "about zero queue drops". **Reading of the F1 gate:** "zero queue drops at 1,024" is read as received-Datagram queue discards at or below 0.01% of Datagrams, pooled as total discards ÷ total Datagrams ([H22](2026-10-19-native-gap-handoff-audit.md#handoff-decisions); the same line later gates use, the Datagram GSO gate's loss row). "The counter accounts for the 128-entry build's queue loss" is read as agreement within one Datagram per run between the counter and the derived queue loss ("sent − received − unprocessed-queue drops − packer residual", the formula the fork's own gate on [Deepen the received-DATAGRAM queue and make its discards visible before a release ships #743 on by default](https://github.com/the-sarge/quic-go-fast/issues/824) used; [H26](2026-10-19-native-gap-handoff-audit.md#handoff-decisions), because the fork's record was exact in seven of eight runs and one off in the eighth). Pooled discards above the line fail the gate; a disagreement beyond one Datagram is a readout fault that Task 4.G1 diagnoses before posting. **Who runs it:** Task 4.G1, through wiremux's rig, after F5 merges on fork `main` (so both counts are readable) and before the release is cut. The base arm is a local one-line copy of the candidate with the depth at 128, because the parent of F1's merge has no counter. On a candidate carrying F5's every-depth condition (`2a83ed29`, 2026-10-21), the base arm also keeps that condition's bound at 1,024, or the 128 queue would overflow only through the residual dequeue-to-push window ([Task 4.G1](#task-4g1--deeper-queues-gate-f1-and-f5)). The faster GSO sender is now real code: F10 on fork `main`.

**Single owner after merge:** The fork's `datagramQueue` owns the depth and the count; `DatagramReceiveDropsV1` is the only read path. wiremux reads it only through slice 3.1's internal seam, for measurement and diagnosis.

**Authority completeness:** No new authoritative or persisted fact. The count is monotonic, concurrency-safe, keeps its value after close and is zero without datagram support (its doc comment). Its only constructor is `newDatagramQueue`; no restart round trip applies.

**Transitional-seam budget:** None.

**Blast radius:** Adds one atomic add on the refusal path (allocation-free, pinned by the no-allocation test) and a bound of about 1.5 MB per connection when full (**derived**: 1,024 × at most 1,452 bytes). Removes payload pinning by delivered slots. Reaches every fork connection, upgraded QUIC Wires included. Flagged, not this slice's gate: under load on a receiving Mac the 1,024 queue still discards 0.3–2.4% (**measured**, [Does load on the receiving Mac cost the native pair, and do its receive goroutine and run loop need a raised class?](https://github.com/GridSwarm/wiremux/issues/1866#issuecomment-6247562292)); the decided gates run on an idle receiver.

**Artifact classification:** The depth is shipped behaviour; the count method is a shipped internal diagnostic API of the fork that the consumer's verification aids read (slice 3.1's seam, the rig); the fork's audit record and the consumer comment are process metadata.

**Representation contract:** Domain: DATAGRAM frames that pass the size check and arrive in an open receive phase, on any fork connection. Owner: `HandleDatagramFrame`. Guarantee: universal over full-queue refusals (each adds one to the count), with example-level evidence in the named tests.

**Contract closure:** Not triggered: one enforcement site (L112) on one path, and a miscount degrades a measurement, not data or authority.

**Evidence budget:** Fork side complete (merged tests and fork CI). Consumer side: Task 4.G1's budget.

**TDD and preservation evidence:** Done in [PR #829](https://github.com/the-sarge/quic-go-fast/pull/829); `TestDatagramReceiveOverflowNoAllocation` stays at zero allocations.

**Dispatch context budget:** No fork dispatch is needed. If 4.G1 fails and the fork must act, the fork brief carries the sanitized gate result, the decided gate text, the seams above and the decision's reopen trigger: about 15,000 tokens.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** A fork setting that wiremux turns on, or a public wiremux depth option. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** A byte limit. **Revisit if:** jumbo frames enter the targets ("revisit it only if jumbo frames enter the targets"; seed [Future effort: jumbo frames for native Wires](https://github.com/GridSwarm/wiremux/issues/1872)).
- **Rejected alternative (do not do this):** Measuring 256 and 512 first, or 4,096 or 2,048 entries. **Revisit if:** a real overflow at 1,024 shows up in the count, when "the depth can be raised on evidence with a one-line fork change".
- **Rejected alternative (do not do this):** A public discard count on `Datagrams`, a `ConnectionStats` field or a qlog event. **Revisit if:** a consumer would act on a public count ("It stays available later as a purely additive change, if a consumer would act on it").
- **Rejected alternative (do not do this):** No count at all, or naming the depth in ADR-0009. **Revisit if:** none: rejected on merit.

**Public-brief constraints:** Nothing new is filed. The acceptance comment on the retained issue names no host (the Linux cell host is already in the fork's own records; new text still omits it), no wiremux link and nothing about GridCast's timers or paths. Cell phrasing: the `netns` sentence from the public-brief rules, "with a faster equal-size GSO sender".

**Slice decision audit:** Merging F5 into F1, as the retained issue's original body did, was undone by the owner on 2026-10-18 so F1 could land before [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808) started; F5 keeps its own gate. No further split exists. F1 has no blocking edge.

**Stop conditions:** A counter disagreement beyond one Datagram stops 4.G1 as a readout fault. A 4.G1 failure on the F1 row means the release does not ship F1 as merged; F1 holds the release, so the operator re-decides it through the map (the decision's own reopen trigger is a deeper queue, not a revert to 128). A fork proposal to widen or narrow what the count covers reopens the representation contract above and goes to the operator.

### Fork slice F2 — Admits mode: the packet connection is the admission owner

**What it delivers:** One opt-in fork configuration in which a consumer declares that its packet connection admits every datagram in both directions, so the transport calls neither network-admission callback: no per-packet re-encode of the packet info for the receive callback and no copy of the ancillary data for the send callback. Every other user keeps `ConfigureNetworkAdmissionV1`'s documented behaviour.

**Decided fork behaviour** ([Which per-packet allocation removals should the native path adopt?](https://github.com/GridSwarm/wiremux/issues/1832#issuecomment-6152076446)):

> One opt-in fork mode in which the packet connection is the admission owner, so the fork skips both admission callbacks.

> **The mode.** An opt-in fork configuration, set after `ConfigureNetworkAdmissionV1` and before initialization (or an equivalent V2), declares that the packet connection admits every datagram in both directions. The transport then calls neither callback, so it neither re-encodes nor copies.

> **Unchanged:** the restricted profile: no `AddPath` either way, no preferred-address adoption, the `disableActiveMigration` flag; the structural endpoint checks (a non-UDP or invalid remote is still rejected); the fork's own parse of each datagram's control message, which its server needs for reply metadata; `ConfigureNetworkAdmissionV1`'s documented behavior for every other user.

> Why one mode, not the probed pair (a receive facts callback plus a borrowed-send flag): wiremux has no use for the facts, and declaring the real owner is more honest than an always-true callback.

Value (**measured**): "−0.037 CPU-s/GiB on the Linux stream receiver ([−0.040, −0.033]) and −0.06 to −0.08 user CPU-s/GiB on macOS […], plus the send copy." "It is the one saving that survives Linux receive coalescing" (**source**: the decision).

**Existing-work disposition:** New slice, to be filed. No fork issue or branch exists.

**Blocked by:** None.

**Ordering and never-hold rules:** Holds the release (one of the four slices the 32-entry send queue decision bundled). "It touches the fork's admission code, not the packet-emission code that quic-go-fast#743 changes." Its wiremux adoption, slice 5.2, lands after the repin.

**Fork seams:** [`packet_policy.go` L22–L32](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L22-L32) (`ReadPacket`, admission after splitting and before routing); [L44–L55](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L44-L55) (`checkSend`; the send copy at [L50](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L50)); [L57–L74](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L57-L74) (`allowsReceive`; the re-encode `packet.info.OOB()` at [L73](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L73)); [L76–L86](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L76-L86) (`packetEndpoint`, the structural check that stays); [L109–L114](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L109-L114) (`checkPacketSend`, the batched-submission seam); [L119–L141](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L119-L141) (`checkPathPolicy`, the restricted profile); [L145–L150](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L145-L150) (`networkAdmission`); [L152–L198](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L152-L198) (`ConfigureNetworkAdmissionV1`, whose doc at [L168–L170](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L168-L170) says "Every ordinary, segmented, probe and batched submission is checked again at the socket boundary" and needs an amendment for the mode); [L200–L207](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L200-L207) (`networkDisablesActiveMigration`). Naming precedents: [`ConfigureExternalPacketIOV1`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/external_packet_io.go#L65), [`ConfigureFixedPeerV1`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_policy.go#L228), [`ConfigureReceivePhasesV1`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/receive_phase.go#L153), [`ConfigureSetupAdmissionV1`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/setup_reservation.go#L105).

**Required design guards:** The mode covers every path that reaches the callbacks: receive, and every ordinary, stateless, segmented, probe and batched submission through `checkSend` (the test "neither callback is ever called" covers both directions). The structural `packetEndpoint` check stays on both directions. The shape (a separate setter or a V2) and the name are the fork's call; the mode is refused before network admission is configured and after initialization. The slice touches the admission paths [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808)'s readiness run guards, so the release issue asks the fork to schedule it with that campaign ([H13](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).

**Required fork-side tests** (verbatim): "in the mode, neither callback is ever called; the restricted profile still holds; invalid remote endpoints are still rejected; zero allocations in `allowsReceive` and `checkSend` under the mode; the mode is accepted only after network admission is configured and before initialization; V1 behavior is unchanged without the mode."

**Consumer acceptance gate:** Opt-in, so the fork tests above are the only gate before the release. The measured gate is wiremux's adoption, slice 5.2 in [Track 5](2026-10-19-bundle-adoption-plan.md), after slice 5.1 adopts the release, judged at the pin. Verbatim: "the mode is registered only when the selected fork offers it, and today's callbacks are kept otherwise; the native fork lane passes against a fork commit carrying the mode; minimax `netns` A/B (A, B, A, B at `REPS=3`), `stream` arm: receiver **at least 0.02 CPU-s/GiB below base** (about half the measured 0.037 and twice the cell's ±0.01 spread), and stream throughput no lower; recorded, not gated: the `dgram` arm, the Linux Datagram sender (the send copy), and a `tb` run; the dependency evidence record notes the mode when wiremux adopts the fork release carrying it."

**Single owner after merge:** The fork's `networkAdmission` owns whether the callbacks run. Under the mode, the consumer's packet connection owns every per-datagram verdict; `checkPathPolicy` and `networkDisablesActiveMigration` keep the restricted profile, and `packetEndpoint` keeps the structural check.

**Authority completeness:** The mode is a new configured fact. Its only constructor is the configuration call, validated for order (after network admission, before initialization), and it is immutable afterwards like `networkAdmission`. Nothing persists.

**Transitional-seam budget:** None. The V1 callbacks remain the contract for every other user; on a fork without the mode the consumer keeps them.

**Blast radius:** Under the mode it removes three receive allocations and one send allocation per packet. It adds one configuration fact, one ordering rule and a doc amendment. Obligation: the restricted profile and the structural checks behave the same on every submission path with or without the mode. No effect without the mode. Untraced, flagged for the fork: whether the mode may combine with `ConfigureFixedPeerV1` (the consumer never sets both); the fork states its rule.

**Artifact classification:** The mode is shipped behaviour (opt-in); the restricted profile and structural checks are required safety enforcement, unchanged; the allocation tests are verification aids.

**Representation contract:** Domain: transports with network admission configured and the mode set, on the receive path and every send submission that reaches `checkSend`. Owner: `packetPolicyConn`. Guarantee: no callback on any of those paths (canonical over the enumerated paths); structural checks and the restricted profile universal, as today.

**Contract closure:** Triggered. Admission is a security boundary, and the mode is reachable through independent receive and send paths.

| Semantic class | Expected disposition | Enforcement owner | Evidence | Status |
| --- | --- | --- | --- | --- |
| Receive under the mode, valid remote | Delivered with no callback, no allocation | `allowsReceive` | "neither callback is ever called"; zero-allocation test | Required |
| Receive under the mode, non-UDP or invalid remote | Rejected | `packetEndpoint` | "invalid remote endpoints are still rejected" | Required |
| Ordinary and batched send under the mode | Written with no callback; invalid remote rejected | `checkSend` via `checkPacketSend` | One ordinary and one batched submission in the never-called test | Required |
| `AddPath` either way, preferred address, under the mode | Refused as today | `checkPathPolicy` | "the restricted profile still holds" | Required |
| Mode set before admission or after initialization | Refused | configuration call | ordering test | Required |
| No mode | V1 behaviour | `ConfigureNetworkAdmissionV1` | existing V1 tests | Preserved |

At most one guard mutation: bypassing the mode check in `allowsReceive` must fail the zero-allocation test.

**Evidence budget:** One representative case per row above (at most eight new cases), the fork suite with race on the three unit lanes, at most one guard mutation, and the fork's own review practice. No fork measurement row.

**TDD and preservation evidence:** The never-called and zero-allocation tests are written first and fail on `main`. Existing `ConfigureNetworkAdmissionV1` and restricted-profile tests stay green unchanged.

**Dispatch context budget:** About 30,000 tokens. The fork brief carries: the decided mode and the unchanged list (in the fork's terms), the guards, the six tests, the doc amendment, the BBR-campaign scheduling note, and the public measurement phrasing. The fork agent reads `packet_policy.go`, `packetInfo.OOB` in `sys_conn_oob.go`, the send paths that reach `checkPacketSend`, and the existing admission tests.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** The probed pair, a receive facts callback plus a borrowed-send flag. **Revisit if:** a fork user appears that wants its own allocation-free callback: "A future fork user who wants its own allocation-free callback would need the facts form later, as an additive change. No such user exists today."
- **Rejected alternative (do not do this):** A consumer-only workaround that skips the fork's admission. It "breaks `TestUnicastBatchProvenance` and hides from the fork the destination and interface it uses for server replies". **Revisit if:** none: rejected on merit.

**Public-brief constraints:** No link to wiremux's `admitBound` or endpoint code, and no cell host names beside CPU figures. Describe the consumer as "a consumer whose packet connection already admits each datagram before the transport sees it (it wraps the socket with its own per-datagram admission) and currently registers always-true callbacks". Measurement phrasing: "measured downstream in a two-namespace veth cell, stream receiver".

**Slice decision audit:** Splitting receive from send would need two declarations of one owner; the decision is "one mode". Merging with the wiremux binding slice (2.1) crosses repositories; merging with F3 joins unrelated code. No blocking edge: the mode is independent of every other slice.

**Stop conditions:** The fork finds that skipping a callback changes anything other than admission (for example, that the server needs a callback's facts for reply metadata beyond the control-message parse that stays) → stop and report to the operator. The fork prefers the facts form → back to the map (the decision rejected it).

### Fork slice F3 — Linux copy-at-read

**What it delivers:** The fork's Linux reader copies each datagram of a coalesced (GRO) read into an ordinary packet buffer as it decodes the read, keeps its 64 KiB read buffers for the next read and allocates nothing per read. No slab, no per-datagram views and no pending list reach a Linux connection, and the copy under the connection's receive lock disappears for Linux.

**Decided fork behaviour** ([Should native receives adopt coalescing once the fork copies coalesced datagrams at read time?](https://github.com/GridSwarm/wiremux/issues/1835#issuecomment-6196268143), mechanism from [Why does native receive coalescing cost throughput in the netns shape cell?](https://github.com/GridSwarm/wiremux/issues/1829#issuecomment-6154923896)):

> The fork change is copy-at-read, as in the probe (`fix-knobs.diff` in the #1829 evidence).

> the reader copies each datagram into an ordinary packet buffer as it decodes the read, keeps its 64 KiB buffer for the next read, and allocates nothing per read.

> **Linux reader only.** The probe changed `sys_conn_oob.go` only. The Windows URO reader stays on today's slab path, which measured 1.34× on Windows.

> **The slab and its ADR 0005 atomic exception stay** while the Windows reader uses them. They are retired only if a later change moves Windows too.

> **Datagrams above the 20 KiB packet tier** are delivered or refused exactly as they would be without coalescing, with a test. The probe's 64 KiB coalesced-tier buffer is acceptable as the mechanism.

> **Memory: 512 KiB of read slots per reader, held for its life (8 × 64 KiB), is accepted.**

Why: today "per read [the fork] allocates a slab, one view per datagram and a growing pending list. It also copies each datagram while holding the connection's receive lock, which the run loop takes twice per packet." No new setting: coalescing stays gated by the existing permission and `QUIC_GO_DISABLE_GRO`.

**Existing-work disposition:** New slice, to be filed. The probe exists only in private evidence and has never run through the fork's suite.

**Blocked by:** None ("It has no prerequisites").

**Ordering and never-hold rules:** Holds the release (bundled by the 32-entry send queue decision: "That turns copy-at-read's 'may share a release' into 'shares'"). F11 never lands ahead of it and reuses its copy path.

**Fork seams:** [`sys_conn_helper_linux.go` L24](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_helper_linux.go#L24) (`batchSize = 8`), [L89–L93](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_helper_linux.go#L89-L93) (`enableGRO`, `QUIC_GO_DISABLE_GRO`); [`sys_conn_oob.go` L62–L80](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L62-L80) (`oobConn`: `buffers` at L70, `delivery` at L73), [L191–L194](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L191-L194) (activation under permission), [L203–L261](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L203-L261) (`ReadPacket`: coalesced-tier read buffer at [L218–L221](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L218-L221), `ReadBatch` at L232, decode at L248), [L263–L280](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L263-L280) (`readManagedPacket`, managed without GRO; untouched here), [L284–L359](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L284-L359) (`decodeReadPacket`; `delivery.accept` at [L358](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L358)), [L363–L375](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L363-L375) (`releaseReadBuffers`); [`coalesced_delivery.go` L24–L47](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/coalesced_delivery.go#L24-L47); [`coalesced_slab.go` L115–L154](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/coalesced_slab.go#L115-L154) (`retainForRetentionQueue`); [`connection.go` L2053–L2063](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2053-L2063) (the retention copy under `receivedPacketMx`); [`buffer_pool.go` L102–L110](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/buffer_pool.go#L102-L110); [`internal/protocol/protocol.go` L114](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/protocol/protocol.go#L114) and [L119](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/protocol/protocol.go#L119) (20 KiB and 65,535-byte tiers); [`external_packet_io.go` L247–L250](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/external_packet_io.go#L247-L250) (permission); [`managed_packet_receive_linux.go` L60](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/managed_packet_receive_linux.go#L60) (managed mode enables GRO itself).

**Required design guards:** (1) The brief states the mechanism in words, since the probe is private: reader-owned read slots (8 × 64 KiB) kept for the reader's life; each datagram copied into an ordinary tier as the read is decoded; no slab, views or pending list on Linux. (2) The >20 KiB reference behaviour has one form per reader kind. With coalescing off, the unmanaged reader reads into 1,452-byte buffers ([`sys_conn_oob.go` L222–L225](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L222-L225)), and the managed reader goes through `readManagedPacket` with a 64 KiB buffer and delivers the datagram whole ([L204–L205](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L204-L205), [L263–L280](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L263-L280)). One test per reader kind feeds the same oversized datagram with coalescing off and on and asserts the same outcome; the fork issue records both observed outcomes. (3) The slice changes the managed-mode reader (managed mode enables coalescing itself), so the fork's managed-mode tests cover it, and slice 5.1's evidence record notes that upgraded Linux Wires' coalesced delivery changed. (4) It touches the receive path [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808)'s readiness run guards: schedule with that campaign ([H13](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).

**Required fork-side tests** (verbatim): "**Tests:** the fork's full suite, including race, and the shared coalesced-delivery and routing-closure fixtures on every platform, with the Windows URO tests unchanged and green. The probe has never run through the suite." Plus the >20 KiB test. The shared fixtures are `coalesced_fixtures_test.go`, `coalesced_routing_closure_test.go`, `coalesced_retention_holds_test.go`, `coalesced_delivery_test.go`, `coalesced_slab_test.go` and `sys_conn_gro_linux_test.go`.

**Consumer acceptance gate:** verbatim, fork half: "a protocol written before measurement for a minimax `netns` A/B of the real change against today's coalescing path and against no coalescing, at the pin with the default row alongside: stream throughput no worse than no coalescing (−1% floor); stream receiver CPU per GiB at least 20% below no coalescing (the probe measured 24%); stock Datagrams within ±2% at the pin; no new loss." **Who runs it:** Task 4.G4, after F3 merges on fork `main`, on a coalescing-grant scratch build of wiremux (wiremux withholds coalescing until slice 5.3). Later, slice 5.3 repeats the measurement on the adopted release: "a `netns` A/B through wiremux on the adopted fork release, coalescing on against off, at the pin with the default row: stream ≥ −1%, receiver CPU per GiB ≥ 20% lower; stock Datagrams within ±2%; no new loss. No macOS run: nothing changes there."

**Single owner after merge:** The Linux `oobConn` owns its read slots for its life and the copy into ordinary tiers; Linux connections receive only ordinary-tier buffers from it. Permission stays with `receiveCoalescingAllowed` and `QUIC_GO_DISABLE_GRO`.

**Authority completeness:** No new configured or persisted fact. The reader's constructor allocates the slots; `releaseReadBuffers` remains the only cleanup path.

**Transitional-seam budget:** The slab, `coalescedDelivery`, `retainForRetentionQueue` and ADR 0005's atomic exception stay for the Windows reader. Removal slice: F11. If F11 slips, they live one fork release longer (accepted cost in [Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572)).

**Blast radius:** Removes the per-read slab allocation, the per-datagram views, the pending list and the copy under `receivedPacketMx` for Linux coalesced reads. Adds 512 KiB per reader held for life (accepted) and one copy per datagram at decode. Reaches upgraded Linux Wires at the repin through managed mode. The Linux retention-budget refusal ([`connection.go` L2056–L2063](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2056-L2063)) becomes unreachable on Linux. Probe result (**measured**, downstream): stream parity with no coalescing (+0.7–0.9%), −23% sender and −24% receiver CPU per GiB. No known untraced effect beyond the managed-mode reach, which is recorded.

**Artifact classification:** The reader change is shipped behaviour; the oversized-datagram behaviour is preserved behaviour pinned by a verification aid; the shared fixtures are existing verification aids.

**Representation contract:** Domain: Linux reads with coalescing on (permitted or managed), including single-datagram reads, multi-segment reads, failed batches, reader stop and datagrams above 20 KiB. Owner: `oobConn.decodeReadPacket` and `releaseReadBuffers`. Guarantee: no Linux connection holds a slab-backed buffer (canonical over those read shapes), with example-level evidence in the shared fixtures.

**Contract closure:** Triggered. Wrong storage ownership would corrupt delivered data, and the reader reaches it through independent states.

| Semantic class | Expected disposition | Enforcement owner | Evidence | Status |
| --- | --- | --- | --- | --- |
| Multi-segment coalesced read | Each segment copied to an ordinary tier, delivered in order | `decodeReadPacket` | shared coalesced-delivery fixtures | Required |
| Single datagram with coalescing on | Copied, delivered once | `decodeReadPacket` | shared fixtures | Required |
| Read with invalid metadata or truncation | Rejected whole, slots reused | `ReadPacket` | existing rejection tests | Preserved |
| Failed batch | The batch's datagrams discarded (today's policy); the read slots stay reader-owned for the next read | `ReadPacket` | failed-batch test under race | Required |
| Reader stop | Slots released once, nothing delivered | `releaseReadBuffers` | stop test under race | Required |
| Datagram above 20 KiB, unmanaged and managed reader | Same outcome as with coalescing off, for each reader kind | `decodeReadPacket`, `readManagedPacket` | the two new >20 KiB tests | Required |
| Managed reader with GRO | Same copy path | `oobConn` via managed setup | fork managed-mode tests | Required |
| Windows URO reader | Unchanged slab path | `windowsConn` | Windows URO tests unchanged and green | Preserved |

**Evidence budget:** The two new >20 KiB tests, the failed-batch and reader-stop cases, and the existing shared fixtures; the full suite with race on the three unit lanes; at most one guard mutation (restoring `delivery.accept` on Linux must fail a fixture that asserts no slab-backed buffer); the fork's review practice. Consumer measurement: Task 4.G4's budget.

**TDD and preservation evidence:** A fixture assertion that a Linux connection never receives a slab-backed buffer is written first and fails on `main`. The Windows URO tests stay unchanged and green.

**Dispatch context budget:** About 40,000 tokens. The fork brief carries the mechanism in words, the decided bullets, the guards, the tests, the downstream gate in public phrasing and the BBR-campaign note. The fork agent reads `sys_conn_oob.go`, `sys_conn_helper_linux.go`, `coalesced_delivery.go`, `coalesced_slab.go`, `buffer_pool.go`, the receive part of `connection.go`, `managed_packet_receive_linux.go`, the shared coalesced fixtures and ADR 0005.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** Moving only the copy out of the receive lock; it recovers about 40% of the cost. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Rejecting receive coalescing and taking an owned `recvmmsg` instead. **Revisit if:** coalescing is rejected (the owned `recvmmsg` "reopens only if coalescing is rejected"); not triggered.
- **Rejected alternative (do not do this):** Widening this slice to the Windows reader. Windows evidence needs two VM cells and would hold the release; it is F11. **Revisit if:** none: rejected on merit.

**Public-brief constraints:** No probe diff name or evidence path (describe the mechanism), no `netns` host, nothing about GridCast. Public phrasing: "Measured downstream in two Linux network namespaces joined by a veth pair (veth GRO off, so only segmented sends coalesce), at a consumer-sized heap: copy-at-read restored the stream to parity with no coalescing (+0.7–0.9%) and kept −23% sender and −24% receiver CPU per GiB."

**Slice decision audit:** Splitting the oversized-datagram rule into its own slice would ship a reader whose large-datagram behaviour is unpinned. Merging with F11 is rejected above. No blocking edge: F3 has no prerequisite.

**Stop conditions:** The >20 KiB reference outcome differs between coalescing off and on in a way the copy cannot preserve → stop for the operator. The copy path cannot avoid a per-read allocation → stop (the decision says it "allocates nothing per read"). A 4.G4 failure → the release does not ship F3 as merged; the operator re-decides it through the map.

### Fork slice F4 — 32-entry send queue for every connection

**What it delivers:** Every fork connection's packet send queue holds 32 entries, the default controller and BBR alike, with the send batch cap kept at 8 as its own constant. The per-controller depth choice disappears.

**Decided fork behaviour** ([Should the fork raise its packet send queue from 8 to 32 entries?](https://github.com/GridSwarm/wiremux/issues/1850#issuecomment-6207580215)):

> The fork's packet send queue becomes 32 entries for every connection, the default controller and BBR alike. `maxSendBatch` stays 8 as its own constant. The depth is fixed with no setting anywhere, like the received-Datagram queue.

> This change removes the per-controller depth choice. Selecting BBR in wiremux to get the depth is not an option: BBR is experimental and unqualified, and congestion control is outside this map.

> wiremux needs no code change for this slice. Its connections get the depth when they repin to the bundle.

Mechanism ([Why do slice A and the fork's ownership APIs cost the stock Datagram sender 3–5% at a consumer-sized heap?](https://github.com/GridSwarm/wiremux/issues/1845#issuecomment-6201012510)): the writer signals room only after a whole batch, the run loop sleeps on the writer's processor and the writer runs dry; 32 entries cut dry-outs by 95% (**measured**).

**Existing-work disposition:** New slice, to be filed. Related merged fork work: [PR #766](https://github.com/the-sarge/quic-go-fast/pull/766) (BBR-only 32 entries, `4b3f3a5a`), whose per-controller seam this slice removes.

**Blocked by:** None.

**Ordering and never-hold rules:** Holds the release: "The change ships only in a fork release that also carries the other three decided fork slices […]. None of the four ships alone, so wiremux and GridCast repin once." F8 lands after it: "Before it, the depth is 8 and the change does nothing." "**Slice A doesn't wait.**"

**Fork seams:** [`send_queue.go` L109](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L109) (`sendQueueCapacity = 8`), [L111–L117](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L111-L117) (`bbrSendQueueCapacity`), [L119–L120](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L119-L120) (`maxSendBatch = sendQueueCapacity`), [L128–L143](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L128-L143) (constructors), [L149–L165](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L149-L165) (`Send`), [L180–L182](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L180-L182) (`WouldBlock`), [L188–L218](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L188-L218) (`Run`), [L255–L271](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L255-L271) (`runBatched`; the group bound at [L258](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L258)), [L279–L288](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L279-L288) (one room signal per group); [`packet_emission.go` L593–L602](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission.go#L593-L602) (`replacePath`) and [L604–L610](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission.go#L604-L610) (`sendQueueCapacityFor`); [`connection.go` L2704–L2706](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2704-L2706) (`initPacketEmission`); [`send_conn_sendmsg_x_darwin.go` L214](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_conn_sendmsg_x_darwin.go#L214) (the Darwin batch size check against `maxSendBatch`). Tests that reference the constants: [`bbr_send_queue_depth_test.go` L26](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/bbr_send_queue_depth_test.go#L26) and [L186](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/bbr_send_queue_depth_test.go#L186), [`candidate_authority_test.go` L314](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/candidate_authority_test.go#L314), [`send_conn_sendmsg_x_darwin_test.go` L53–L54](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_conn_sendmsg_x_darwin_test.go#L53-L54) (a batch of `sendQueueCapacity` packets, which at 32 exceeds the Darwin size check and falls back).

**Required design guards:** On fork `main`, `maxSendBatch = sendQueueCapacity`, so the slice first makes the batch cap its own constant (8) and only then raises the queue to 32; otherwise it silently ships F8. A test pins `maxSendBatch == 8` independently of the depth, so F8 is one visible line. The slice changes the default send path, which [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808)'s stop-and-ask covers, and deletes the BBR depth seam: the release issue names it, and the fork decides its scheduling and whether deleting the seam (BBR's behaviour unchanged: it already has 32 entries and cap 8) is a new BBR revision under its rule.

**Required fork-side tests:** Decided: "**The fork's test suite** passes." The guard's test (cap stays 8 at depth 32) and a depth test for both controllers at creation and across `replacePath` (rewriting `TestBBRSendQueueDepth` and `TestBBRSendQueueDepthRenoUnchanged`) enforce the decided behaviour.

**Consumer acceptance gate:** verbatim from [Should the fork raise its packet send queue from 8 to 32 entries?](https://github.com/GridSwarm/wiremux/issues/1850#issuecomment-6207580215):

> The fork change is compared against the fork commit it lands on, through wiremux's rig at the pin (`-ballast 64 -gc-role both`). Campaigns run A, B, A, B at `REPS=3`, and decisions use pooled medians. It passes when all of these hold:
> - **`netns`, stock Datagram sender:** delivered throughput at least 3% higher (about 7% expected).
> - **`netns`, native stream:** no worse than −1%.
> - **Thunderbolt pair, stock Datagram sender and stream:** no slower. Base campaigns there have differed by 8.6%, so this fails only if both A/B pairs show the change lower.
> - **Both cells:** no new packet loss (within 0.1 point) and no rise in received-Datagram queue discards.
> - **Minimum RTT:** no rise beyond noise. Noise is the gap between the two base campaigns.
> - **Smoothed RTT:** it may rise, by no more than 24 entries' worth of wait at the base run's send rate (about 60 µs in `netns` and 180 µs on Thunderbolt for stock Datagrams, derived). A larger rise means something other than queue depth is at work.
> - **`netns` sender CPU per GiB:** no more than 5% above base. BBR's own 32-entry queue cost 5% more Datagram sender CPU on its S5 cell and was kept by owner decision. #1845 measured 4.5% *less* on the default controller.
> - **The fork's test suite** passes.
> - **The rig gets an RTT readout,** which it doesn't have today: `MinRTT` and `SmoothedRTT` from the fork's `Conn.ConnectionStats()` at the end of each run.

**Amended readings and owner decision (2026-10-20).** Task 4.G2 ran on F4's merge `48db9bc6` and failed six rows as written ([the gate record](https://github.com/GridSwarm/wiremux/issues/1938#issuecomment-6303532449)): `netns` received-Datagram discards, minimum RTT and smoothed RTT, and on `tb` the stream rate and minimum RTT on both workloads. Its headline rows passed (`netns` stock Datagrams +8.09%). [The diagnosis](https://github.com/GridSwarm/wiremux/issues/1972#issuecomment-6304069857) found that the fork stamps a packet's RTT send time before it waits in the send queue, so every RTT sample includes the queue's standing wait, and that on today's macOS path the queue sits full at either depth. [The owner decision](https://github.com/GridSwarm/wiremux/issues/1938#issuecomment-6306221100), verbatim:

> **Owner decision, 2026-10-20 (coordinator relay):** keep F4 as merged, with amended readings. Josh: "so we can save 2% for a few days?" in reply to the coordinator's revised recommendation (keep F4 as merged; the per-platform split the [findings](https://github.com/GridSwarm/wiremux/issues/1972#issuecomment-6304069857) proposed would be undone by slice 6.3, and would cap F8/6.3's macOS groups at 8 in the meantime).
>
> - **Amended readings for 4.G2's rows:**
>   1. **Received-Datagram discards:** pass when application loss does not rise and discards are at most 0.01% of Datagrams.
>   2. **Minimum RTT, every cell:** judged on the smoothed-RTT bound instead of the lifetime minimum.
>   3. **Smoothed RTT:** a rise within the bound plus the readout's 1 µs resolution passes.
> - **Accepted in writing:** the `tb` stream is about −2% as an interim macOS cost until slice 6.3.
> - **Added to 6.3's gate:** an arm comparing depth 32 against a local depth-8 fork copy, with batching on. If depth 32 still costs there, F4 comes back to the map with those numbers.
> - **Under these readings** every 4.G2 row passes, or is accepted.

The 6.3 arm is recorded in [Slice 6.3](2026-10-19-macos-native-stack-plan.md#slice-63--one-sendmsg_x-per-send-group-on-connected-macos-sockets) of the macOS plan.

**Who runs it:** Task 4.G2, after F4 merges on fork `main`: A is the commit F4 lands on, B is F4's merge commit. The base has F1's counter, so no fork copy is needed.

**Single owner after merge:** `send_queue.go` owns two constants: the depth (32, every controller) and the batch cap (8, its own constant until F8).

**Authority completeness:** No configured or persisted fact; `newSendQueue` and `replacePath` both take the one depth.

**Transitional-seam budget:** Adds the split batch-cap constant; removal slice F8. If F8's gate fails, the split stays (the decided outcome). Removes `sendQueueCapacityFor` and `bbrSendQueueCapacity`.

**Blast radius:** The 24 extra entries add about 60 µs of wait before the socket for the `netns` stock Datagram sender and about 180 µs on Thunderbolt (**derived** in the decision). On macOS, until slice 6.3's batched send, the owner accepted in writing the `tb` stream at about −2%; the minimum and smoothed RTT about doubled there, and the amended readings judge that rise on the smoothed-RTT bound (**measured**, [4.G2 and its diagnosis](https://github.com/GridSwarm/wiremux/issues/1972#issuecomment-6304069857)). BBR's depth and cap are unchanged. Removes one seam and its tests. The Darwin batched-send test sized by `sendQueueCapacity` must be resized. Flagged, untraced: whether the fork counts deleting the seam as a BBR revision.

**Artifact classification:** The depth is shipped behaviour; the cap-pinning test is a verification aid enforcing the slice boundary.

**Representation contract:** Domain: every fork connection, every controller, at creation and after path replacement. Owner: the two constants. Guarantee: universal (one depth, one cap), with example-level tests.

**Contract closure:** Not triggered: one constant per fact, read at two construction sites that one test covers.

**Evidence budget:** The rewritten depth test (two controllers × creation and replacement), the cap test, the resized Darwin test and the fork suite with race on the three lanes; the fork's review practice. Consumer measurement: Task 4.G2's budget.

**TDD and preservation evidence:** The cap test is written first, before the depth changes, so a combined change fails it. `TestCandidateSendQueueAuthorityAtEachDepth` stays green at the new depth.

**Dispatch context budget:** About 30,000 tokens. The fork brief carries the decided behaviour, the guard, the tests, the downstream gate in public phrasing, the BBR-campaign and BBR-revision note and the release rule. The fork agent reads `send_queue.go`, `packet_emission.go` (queue construction), `connection.go` `initPacketEmission`, `send_conn_sendmsg_x_darwin.go` and the listed tests.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** A separate measurement before the change; [Does a fork send queue that keeps its packet writer fed lift native senders without adding loss or delay?](https://github.com/GridSwarm/wiremux/issues/1849) "was closed unworked, and the gate above proves the change instead". **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Signalling room when the writer takes a batch ("untested, and it changes more behavior"). **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** An upstream report ("Upstream quic-go signals room after every packet, so the batch signal is the fork's own"). **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Selecting BBR in the consumer to get the depth. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** A per-platform depth: 32 only where the send path submits a batch in one system call (Linux today) and 8 elsewhere, as [the 4.G2 diagnosis](https://github.com/GridSwarm/wiremux/issues/1972#issuecomment-6304069857) proposed. The owner kept F4 as merged instead ([decision](https://github.com/GridSwarm/wiremux/issues/1938#issuecomment-6306221100)): slice 6.3's batched send would undo the split, and in the meantime it would cap F8's and 6.3's macOS groups at 8. **Revisit if:** slice 6.3's depth arm shows depth 32 still costing against depth 8 with batching on; F4 then comes back to the map with those numbers.
- **Rejected alternative (do not do this):** Reverting F4. F4 is the Linux stock sender's +8% gain, F8's split cap builds on it, and F5 was developed on top of it ([the 4.G2 diagnosis](https://github.com/GridSwarm/wiremux/issues/1972#issuecomment-6304069857)). **Revisit if:** slice 6.3's depth arm shows depth 32 still costing against depth 8 with batching on; F4 then comes back to the map with those numbers (the owner's trigger, which reopens F4 without prescribing a revert).

**Public-brief constraints:** No wiremux links, no evidence or probe-copy names, no host names, no "slice A" or "ownership APIs" as consumer work. Cells: the `netns` and `tb` sentences; "stock Datagram sender" is "the consumer's ordinary (non-GSO) DATAGRAM sender through its batched external packet I/O"; the rig is "the consumer's measurement rig".

**Slice decision audit:** Merging with F8 would ship two separately gated changes as one (the guard exists to prevent it). Splitting the seam removal from the depth would leave a per-controller choice for one constant. No blocking edge.

**Stop conditions:** The fork's change raises the cap with the depth → stop before the gate (it would measure F8). A 4.G2 failure → the release does not ship F4 as merged; the operator re-decides it through the map (on 2026-10-20 the owner kept F4 as merged with amended readings, above). A depth other than 32 → back to the map ("If a later decision changes the depth, the cap moves with it, and that decision's gate measures both").

### Fork slice F5 — 1,024-packet unprocessed-packet queue after handshake confirmation

**What it delivers:** Every fork connection's unprocessed-packet queue holds 1,024 packets once its handshake is confirmed and stays at 256 before that, so open servers keep their flood protection mid-handshake. On a connection with DATAGRAM support, a packet is admitted at any depth only while queued packets plus queued received Datagrams stay below the received-Datagram queue's 1,024 (the owner's re-decision of 2026-10-20 for the entries beyond 256, extended to every depth on 2026-10-21, both below). The fork counts every drop at that bound behind a versioned connection method beside F1's.

**Decided fork behaviour** ([Should native connections get a deeper unprocessed-packet queue than the fork's 256 packets?](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120)):

> The fork's unprocessed-packet queue becomes 1,024 packets once a connection's handshake is confirmed, and stays 256 before that. Every fork connection gets it, and the fork counts its drops for wiremux to read internally. It ships as the fifth slice of the one fork bundle.

> The depth is counted in packets, not bytes, and has no setting anywhere.

> It costs one flag the packet reader can read safely. Today `handshakeConfirmed` is a plain field owned by the run loop […], and `handlePacket` runs on the transport's reader under `receivedPacketMx`.

> The 0-RTT invariant holds at both depths: `Max0RTTQueueLen` (31) must stay below the unprocessed bound

> **Visibility: the fork counts every drop, and wiremux reads the count only internally.** One atomic add on the drop path […]. The count is exposed through a versioned connection method found by interface assertion, in the same hook family as #1828's discard count; the fork picks the name and shape.

> Raise the unprocessed-packet bound to 1,024 once the handshake is confirmed; 256 before. A reader-safe confirmation flag (atomic, or set under `receivedPacketMx`). Count every drop at that bound with an atomic counter, exposed through a versioned connection method beside #1828's discard count.

New figure from the fork's F1 record (**measured**, fork loopback harness): with the 1,024-entry received-DATAGRAM queue, unprocessed-queue loss was 0.0118% (0.0099–0.0158%), and "The sender declared nearly every one of those packets lost."

**Re-decided fork behaviour (2026-10-20).** F5 as merged (`c3fb3c45`) failed Task 4.G1's F5 rows as written. [The diagnosis](https://github.com/GridSwarm/wiremux/issues/1970#issuecomment-6303240725) found that at the pin short receiver pauses, mostly outside GC, overrun any depth. With 1,024 entries the backlog that 256 would have dropped before the acknowledgment is acknowledged and handed to the received-Datagram queue in one go, and that queue discards it when the read loop is still behind. Its prototype of the condition below cut the pin's received-Datagram discards from 6,935 in 8 of 9 runs to 158 in 2 of 6 (**measured**, instrumented diagnosis runs, not gate evidence) and leaves streams unchanged. [The owner decision](https://github.com/GridSwarm/wiremux/issues/1970#issuecomment-6303592965), verbatim:

> **Owner decision, 2026-10-20 18:53 EDT:** "let's go with your recommendation". That is the recommendation in the [findings](https://github.com/GridSwarm/wiremux/issues/1970#issuecomment-6303240725):
>
> 1. **Change F5 in the fork, not keep it as merged and not revert it.** Entries beyond 256 are admitted only while queued packets plus queued received Datagrams stay below the received-Datagram queue's 1,024. Prototype: `proto-c-headroom.diff` in the evidence directory. It needs a clean implementation with a unit test; the prototype's instrumentation hook does not belong in it.
> 2. **Re-read F5's 4.G1 rows:**
>    - "Unprocessed drops at least halved" is judged at default GC, where the depth engages. No tested depth halves the drops at the pin.
>    - Stream latency is judged on the smoothed-RTT bound, not the lifetime minimum RTT, which measures the floor of the same queueing under load.
>    - A row is judged only in a cell where the change engages: A's unprocessed drops above zero. On `tb`, where the depth never engaged, the minimum-RTT reading is not judged.
>
> **What follows, as the findings' cost table says:**
>
> - the fork change lands as a new merge;
> - F5's 4.G1 rows are re-gated on that merge (`netns` and `tb`);
> - F1's `netns` set re-runs, because its arms carry `c3fb3c45`;
> - 4.G3 and 4.G6 are measured on candidates carrying the change;
> - 4.G5 and the bundle release wait for it.

The fork-side request is the public [change request on F5's issue](https://github.com/the-sarge/quic-go-fast/issues/855#issuecomment-6303685551). In the fork's terms: in `handlePacket`, the refusal for the region beyond 256 gains one condition: on a connection with a DATAGRAM queue, refuse when the queued packets plus the DATAGRAMs waiting in the received-DATAGRAM queue are at or above that queue's length (`maxDatagramRcvQueueLen`, 1,024). That length must be readable without the queue's mutex; the change request names an atomic mirror of `len(rcvQueue)`, updated on every push, pop and clear, as enough, not as the required representation. A refusal under the condition is counted by the existing drop counter. The first 256 entries, the pre-confirmation limit, the 1,452-byte rule for entries beyond 256 and connections without DATAGRAM support are unchanged. (Superseded in part on 2026-10-21: the condition now applies to the first 256 entries too; the other safeguards stay unchanged. See the second re-decision below.)

**Second re-decision (2026-10-21): the condition at every depth.** The changed F5 merged as `5f73ddc4` ([PR #920](https://github.com/the-sarge/quic-go-fast/pull/920)) and matched the request above. Task 4.G1's re-gate on it ([record](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6309306109)) passed every judged F5 row but one: on `netns`, received-Datagram queue discards with the stock sender at the pin rose from 540 to 2,384 (0.0017% → 0.0073%, **measured**), both B campaigns above both A campaigns; `tb` never engaged. The condition guarded only the entries beyond 256, so packets admitted into the first 256 entries could still be acknowledged and handed to a received-Datagram queue that a stalled read loop had left full. The owner chose the first of three options ([decision](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6320165861)), verbatim:

> **Owner decision, 2026-10-21 11:48 EDT:** "option 1", which means changing F5 again.
>
> The re-gate's one failed row (`netns` received-Datagram discards at the pin, 540 → 2,384; [record](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6309306109)) comes from a gap in the changed F5. The room check (queued packets + queued received Datagrams < 1,024) applies only to entries beyond 256. Packets admitted into the first 256 entries are never checked against the received-Datagram queue's fill. When the read loop stalls, the run loop can still acknowledge them and hand them to a full queue, which discards them after the acknowledgment. This is a hypothesis from the code, untested.
>
> Option 1 applies the room check to every admission on a connection with DATAGRAM support, not only beyond 256. Then queued packets plus queued Datagrams can never pass 1,024, so a Datagram is never discarded after its acknowledgment, and excess is refused on arrival, where the sender sees it.
>
> Its cost is a behaviour change inside the first 256: while the application leaves its received-DATAGRAM queue full, the connection refuses arriving packets, ACK-carrying ones included. Connections without DATAGRAMs are unchanged.
>
> **Options not taken:**
> - accepting the result under F4's "discards ≤ 0.01%" line (B was 0.0073%), which would partly undo the 2026-10-20 rejection of amended readings;
> - reverting F5, which would also ship gluing off by default.
>
> **Next:**
> 1. **Trial run first:** a short prototype check on `netns` (local fork copy, not gate evidence; arms 256 / `5f73ddc4` / prototype) confirms the mechanism before anything is requested of the fork, so a second failed re-gate is avoided.
> 2. **If it confirms:**
>    - a change request on the-sarge/quic-go-fast#855;
>    - a plan amendment, since F5's text says the first 256 entries are unchanged;
>    - the fork's merge;
>    - a third run of F5's rows on both cells and F1's `netns` set.
> 3. **What waits:** 4.G3, 4.G6, 4.G5 and the release wait for that.
>
> #1937 stays open.

Apart from a short window in which the run loop has dequeued a packet but not yet pushed its DATAGRAM (see Rejected alternatives), queued packets plus queued received Datagrams then stay below 1,024, so a Datagram is no longer discarded after its acknowledgment for one DATAGRAM frame per packet. A [trial](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6320665208) on `netns` (local fork copy, two interleaved campaigns per build, **measured**, indicative and not gate evidence) cut the pin's received-Datagram discards to 4, against 397 at 256 and 511 for `5f73ddc4`, at `5f73ddc4`'s throughput (+3.9% against 256). The fork-side request is the public [second change request](https://github.com/the-sarge/quic-go-fast/issues/855#issuecomment-6320679574); the fork merged it as `2a83ed297fdebe1b2ae7b033620d66c4de8b3798` ([PR #954](https://github.com/the-sarge/quic-go-fast/pull/954)): in `handlePacket` the DATAGRAM disjunct `EnableDatagrams && queued + receiveQueueLen() >= maxDatagramRcvQueueLen` moved out of the `extended && (...)` group. The pre-confirmation limit, the 1,024 depth after confirmation, the 1,452-byte rule beyond 256, the drop counter and connections without DATAGRAM support are unchanged. The one behaviour change inside the first 256: while an application leaves its received-Datagram queue nearly full, the connection refuses arriving packets, ACK-carrying ones included, where before it admitted them and discarded their Datagrams after the acknowledgment.

**Existing-work disposition:** New slice, to be filed. It was briefly in [Deepen the received-DATAGRAM queue and make its discards visible before a release ships #743 on by default](https://github.com/the-sarge/quic-go-fast/issues/824)'s original body and was removed by the owner on 2026-10-18; it has no fork issue.

**Blocked by:** F1 (met: merged as `42b9b5de`).

**Ordering and never-hold rules:** Holds the release. "It ships only in the fork release that carries the four slices bundled by #1850 […], and this change never reaches them before the 1,024-entry Datagram queue." F10 never ships ahead of it.

**Fork seams:** [`internal/protocol/params.go` L40](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/protocol/params.go#L40) (`MaxServerUnprocessedPackets = 1024`, precedent), [L43](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/protocol/params.go#L43) (`MaxConnUnprocessedPackets = 256`), [L167–L171](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/protocol/params.go#L167-L171) (`Max0RTTQueueLen = 31`, "has to be smaller than MaxConnUnprocessedPackets"); [`connection.go` L187–L189](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L187-L189) (`receivedPacketMx`, the queue, `receivedPacketsClosed`), [L217](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L217) (`handshakeConfirmed`), [L1066–L1079](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L1066-L1079) (`handleHandshakeConfirmed`, set at [L1074](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L1074)), [L2038–L2071](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2038-L2071) (`handlePacket`: closed-connection release at L2040–L2043, the bound at [L2047](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2047), the retention-budget refusal at [L2056–L2063](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2056-L2063)), [L2075–L2088](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2075-L2088) (`qlogUnprocessedPacketDropped`); counter precedent [`DatagramReceiveDropsV1`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2996-L3006). Readers that queue 64 KiB buffers: [`sys_conn_oob.go` L263–L280](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L263-L280) (Linux and Darwin managed readers without coalescing) and [`sys_conn_windows.go` L166–L170](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows.go#L166-L170) (Windows managed reader).

**Required design guards:** (1) **Memory invariant:** per-connection worst-case unprocessed-queue memory after confirmation stays about 1,024 × the fork's packet buffer size. Readers that queue larger buffers (managed readers without coalescing take 64 KiB buffers) either copy into packet-sized buffers before queueing or keep 256 for those connections, and the fork issue records which. Without the guard the worst case is about 64 MiB per connection at 1,024 against about 16 MiB at 256 (**derived** from code, post-confirmation only); the decision assumed "a queued packet holds a buffer of at most 1,452 bytes". (2) The count's doc comment names what it excludes, as `DatagramReceiveDropsV1`'s does: closed-connection releases are outside the bound; the retention-budget refusal at the same queue is the fork's call to include or exclude, stated in the comment (it disappears for Linux after F3 and for Windows after F11). (3) The flag is reader-safe (atomic, or set under `receivedPacketMx`). (4) The count method uses built-in types only (a `uint64` count, no fork-defined type in its signature), found by interface assertion like `DatagramReceiveDropsV1`. (5) The slice touches the receive path [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808)'s readiness run guards: schedule with that campaign ([H13](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).

**Required fork-side tests** (verbatim): "**Fork tests:** the limit is 256 until the handshake is confirmed and 1,024 after, on both client and server; the counter counts every drop at either depth; the fork's test suite passes." The memory guard gets one test for the path the fork chose (a managed reader's queued packets hold packet-sized buffers, or its bound stays 256). The re-decided condition gets the unit test the owner required, as the [change request](https://github.com/the-sarge/quic-go-fast/issues/855#issuecomment-6303685551) states it: at handshake-confirmed state, with the unprocessed queue at or beyond 256 and the received-DATAGRAM queue holding N entries, a packet is refused and counted once `queued + N >= 1,024` and admitted below it; the condition never applies below 256 (superseded on 2026-10-21, next sentence) or without DATAGRAM support; `TestConnectionUnprocessedQueueDepth` still passes. After the second re-decision (2026-10-21) the condition applies below 256 too, as the [second change request](https://github.com/the-sarge/quic-go-fast/issues/855#issuecomment-6320679574) states: below 256 with a full received-DATAGRAM queue, a packet is refused and counted; below 256 on each side of the line (for example 100 queued with 923 waiting admitted, 924 refused); without DATAGRAM support the condition never applies; `TestConnectionUnprocessedQueueDepth` and `TestConnectionUnprocessedQueueReadmitsAsDatagramsAreRead` still pass.

**Consumer acceptance gate:** verbatim from [Should native connections get a deeper unprocessed-packet queue than the fork's 256 packets?](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120):

> The fork change is compared against the fork commit it lands on, through wiremux's rig at the pin (`-ballast 64 -gc-role both`). Campaigns run A, B, A, B at `REPS=3`, and decisions use pooled medians. It passes when all of these hold:
> - **Fork tests:** the limit is 256 until the handshake is confirmed and 1,024 after, on both client and server; the counter counts every drop at either depth; the fork's test suite passes.
> - **`netns`, stock Datagram sender:** unprocessed-packet drops, read by the new counter, at least halved; delivered throughput no worse than −1%.
> - **`netns`, native stream:** no worse than −1%.
> - **Thunderbolt pair, stock Datagram sender and stream:** no slower. Base campaigns there have differed by 8.6%, so this fails only if both A/B pairs show the change lower.
> - **Both cells:** no new packet loss (within 0.1 point), and no rise in received-Datagram queue discards. That row guards against the loss moving behind the acknowledgement (see Why).
> - **Minimum RTT:** no rise beyond noise. Noise is the gap between the two base campaigns.
> - **Smoothed RTT:** it may rise, by no more than 768 extra packets' wait at the base run's packet rate: about 1 ms for the `netns` stream and 2 ms for stock Datagrams (**derived**). The RTT readout is the one #1850's gate adds to the rig.
> - **No GSO-pair gain row.** The +15% is re-measured on real code by [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825), the only sender that needs it.

The gate's rows are read as the owner re-read them on 2026-10-20 (quoted above): the "at least halved" row at default GC, stream latency on the smoothed-RTT bound rather than the lifetime minimum, and every row only in a cell where A's unprocessed drops are above zero. On 2026-10-21 the owner extended the second re-reading to the stock Datagram workload: its latency is judged on the smoothed-RTT bound too, and its lifetime minimum RTT is reported only. [Task 4.G1](#task-4g1--deeper-queues-gate-f1-and-f5) states how each row is judged.

**Who runs it:** Task 4.G1, after F5 merges on fork `main`. B is F5's merge commit; A is a local one-line copy of B with the post-confirmation depth set back to 256, because the parent has no drop counter. After the 2026-10-20 re-decision, B is the merge commit of the changed F5, and A is that commit's one-line copy. After the 2026-10-21 second re-decision, B is `2a83ed29`, and A is a copy of it with the depth back to 256 and the DATAGRAM condition removed, because at 256 the every-depth condition would stay active in a one-line copy ([Task 4.G1](#task-4g1--deeper-queues-gate-f1-and-f5) states both arms).

**Single owner after merge:** `Conn.handlePacket` owns the bound, reading the confirmation flag that `handleHandshakeConfirmed` sets on the run loop and, on a connection with DATAGRAM support, the received-DATAGRAM queue's length at every admission (beyond 256 only, until the 2026-10-21 second re-decision), read without the queue's mutex; the drop counter lives on `Conn`, beside F1's.

**Authority completeness:** The confirmation flag is a new reader-visible fact with one writer (`handleHandshakeConfirmed`) and one reader (`handlePacket`); it never reverts. The received-DATAGRAM queue's length, readable without its mutex, is a second reader-visible fact: the queue owns it and `handlePacket` reads it (in the change request's implementation, an atomic mirror the queue writes on every push, pop and clear). No persistence.

**Transitional-seam budget:** None.

**Blast radius:** Adds one reader-safe flag, one atomic add on the drop path and the memory guard. The re-decided condition adds a mutex-free length read per admission on a connection with DATAGRAM support (at every depth since the 2026-10-21 second re-decision); with the change request's atomic mirror, that is one atomic load per admission and one atomic store per DATAGRAM push and pop. Since 2026-10-21 it also changes behaviour inside the first 256 entries: while an application leaves its received-DATAGRAM queue nearly full, the connection refuses arriving packets, ACK-carrying ones included, where it used to admit them and discard their DATAGRAMs after acknowledging them. A full queue holds about 1.5 MB per connection against about 0.37 MB today (**derived** in the decision, at 1,452-byte buffers), and the ring buffer behind it never shrinks. Delay and stall survived at 1,024 (**derived**): 0.85 ms for the Linux GSO pair, 2.6 ms for the stock sender, 7.7 ms on Thunderbolt. The pre-confirmation limit, 0-RTT queueing and flood protection are unchanged (the DATAGRAM condition can refuse earlier, never admit more). Reaches every fork connection, upgraded Wires included (the memory guard covers their managed readers).

**Artifact classification:** The depth rule is shipped behaviour; the pre-confirmation bound is required safety enforcement (flood protection mid-handshake), unchanged; the count is a shipped internal diagnostic API.

**Representation contract:** Domain: every fork connection, client and server, before and after confirmation, on every reader. Owner: `handlePacket`. Guarantee: universal (256 before, 1,024 after; with DATAGRAM support, every admission only while queued packets plus queued received Datagrams stay below 1,024; every bound drop counted), with example-level tests for both perspectives and both depths.

**Contract closure:** Triggered. Both triggers hold: a wrong depth before confirmation removes open servers' flood protection, and a missed reader under the memory guard admits up to about 64 MiB per connection (**derived**); the bound is reached independently by client and server connections, by unmanaged readers, by the Linux and Darwin `readManagedPacket` and the Windows managed reader, and through the retention-refusal path.

| Semantic class | Expected disposition | Enforcement owner | Evidence | Status |
| --- | --- | --- | --- | --- |
| Client before confirmation | Bound 256 | `handlePacket` + confirmation flag | depth test, client | Required |
| Server before confirmation | Bound 256 | `handlePacket` + confirmation flag | depth test, server | Required |
| Client after confirmation | Bound 1,024 | `handlePacket` + confirmation flag | depth test, client | Required |
| Server after confirmation | Bound 1,024 | `handlePacket` + confirmation flag | depth test, server | Required |
| Unmanaged reader (packet-sized buffers) | 1,024 × packet buffer worst case | memory guard | memory-guard test, unmanaged case | Required |
| Linux or Darwin managed reader without coalescing (`readManagedPacket`) | Packet-sized buffers queued, or bound kept at 256, as the fork chose | memory guard | memory-guard test, managed case | Required |
| Windows managed reader without URO | Same disposition as the other managed readers | memory guard | memory-guard test on the Windows lane | Required |
| Drop at the bound, either depth | Counted once | drop counter | counter test at each depth | Required |
| Closed-connection release | Not counted (outside the bound) | `handlePacket` | named in the doc comment; one exclusion case | Required |
| Retention-budget refusal | Counted or excluded, as the doc comment states | drop counter | one case matching the doc comment | Required |
| DATAGRAM support, any depth, received-DATAGRAM queue holding N (re-decided 2026-10-20 beyond 256; every depth since 2026-10-21) | Refused and counted once queued + N ≥ 1,024; admitted below it | `handlePacket` + the queue's mutex-free length | headroom unit test, cases beyond and below 256 | Required |
| A connection without DATAGRAM support (re-decided 2026-10-20; below 256 was also excluded until 2026-10-21) | The headroom condition never applies | `handlePacket` | headroom unit test, negative case | Required |

At most one guard mutation: reading the plain `handshakeConfirmed` field instead of the reader-safe flag must fail under race.

**Evidence budget:** One case per row of the closure table (twelve), the fork suite with race on the three lanes, at most one guard mutation; the fork's review practice. Consumer measurement: Task 4.G1's budget.

**TDD and preservation evidence:** The depth-after-confirmation test fails on `main` first. Existing 0-RTT queueing and undecryptable-packet tests stay green.

**Dispatch context budget:** About 35,000 tokens. The fork brief carries the decided rule, the flag requirement, the memory guard, the count's exclusions requirement, the tests, the downstream gate in public phrasing, the BBR-campaign note and the release rule. The fork agent reads `connection.go` (`handlePacket`, `handleHandshakeConfirmed`, the counter precedent), `internal/protocol/params.go`, the managed readers named above and the ring buffer.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** Measuring the stream, the stock sender and macOS before deciding; 512 packets; leaving 256. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** One constant for every connection with no handshake condition, or a native-only `Configure…V1`. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** A public drop count, or no count. **Revisit if:** a consumer would act on a public count ("A public count stays available later as an additive change").
- **Rejected alternative (do not do this):** A confirmation run that ports a probe sender, a separate fork release after the bundle, or an upstream report. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** A byte limit. **Revisit if:** jumbo targets enter the map (the same reopen as F1).
- **Rejected alternative (do not do this):** Keeping F5 as merged with amended readings. It moves part of the stock sender's loss behind the acknowledgment, the case the received-Datagram discard row guards ([the 4.G1 diagnosis](https://github.com/GridSwarm/wiremux/issues/1970#issuecomment-6303240725), adopted by the [owner decision](https://github.com/GridSwarm/wiremux/issues/1970#issuecomment-6303592965)). **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Reverting F5, or a different depth. The owner chose to change F5 "not keep it as merged and not revert it"; no tested depth halved the drops at the pin. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Keeping the condition beyond 256 only (`5f73ddc4`) and accepting its re-gate under F4's "discards ≤ 0.01%" line (its pin discards were 0.0073%). It leaves loss behind the acknowledgment, which the 2026-10-20 decision rejected, and the owner chose option 1 instead ([decision](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6320165861)). A revert, the third option, would also have forced F10's gluing off by default (ordering rule). **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Closing the residual window between the run loop dequeuing a packet and pushing its DATAGRAM (1–3 discards in some trial runs). **Revisit if:** a gate's discard row fails on that residual alone.

**Public-brief constraints:** No host names, no wiremux links, nothing about GridCast. Public phrasing: "Measured downstream in two Linux network namespaces joined by a veth pair at a consumer-sized heap: with a faster equal-size GSO sender, 256 packets cover about 0.21 ms of arrivals, shorter than the receiver's ~0.5 ms GC mark phases, so each mark drops a burst; 1,024 packets lifted that pair from 10.2 to 11.9 Gbit/s with loss at 0.01%." The Thunderbolt row is "a two-Mac Thunderbolt Bridge pair, no-regression only".

**Slice decision audit:** Merging with F1 was undone by the owner (see F1). Splitting the counter from the depth would leave the "at least halved" row unreadable. Blocking edge F1 → F5 is the decided "never reaches them before the 1,024-entry Datagram queue" and is already met.

**Stop conditions:** The fork chooses neither branch of the memory guard, or finds a reader the guard misses → stop. A 4.G1 failure on an F5 row → the release does not ship F5 as merged; F5 holds the release and gates F10's default, so the operator re-decides it through the map (on 2026-10-20 and again on 2026-10-21 the owner re-decided it as above). The changed F5's merge departing from the re-decided condition (since 2026-10-21: at every depth) → stop before the re-gate.

### Fork slice F6 — Acknowledge every 16 ack-eliciting packets (opt-in receiver rule)

**What it delivers:** An opt-in receiver acknowledgment mode, switched on per transport through a versioned method that takes the threshold. With it on, the Application Data receiver acknowledges every N ack-eliciting packets, a group of two or more never waits more than 1 ms, a lone packet keeps today's 25 ms timer, the immediate triggers are unchanged, and the delay timer runs from the oldest unacknowledged packet without restarting. With it off, nothing changes.

**Decided fork behaviour** ([Should native connections acknowledge less often, and through which fork mechanism?](https://github.com/GridSwarm/wiremux/issues/1859#issuecomment-6224678494), background [How much native send cost and throughput would fewer acknowledgments buy on macOS?](https://github.com/GridSwarm/wiremux/issues/1854#issuecomment-6221871999)):

> **Native connections acknowledge every 16 ack-eliciting packets, through a receiver-side rule in the fork that is off by default and that wiremux switches on for its native transports while they run Reno, on macOS, Linux and Windows. A group of two or more packets never waits more than 1 ms.**

> The new rule is off by default, so every fork connection that doesn't ask for it behaves exactly as today. wiremux asks for it through a versioned method found by interface assertion, the same family as `ConfigureNetworkAdmissionV1` and `ConfigureReceivePhasesV1` […]; the fork picks the name and shape.

> **Threshold: 16, fixed.** wiremux passes 16; there's no public wiremux setting.

> **Guard: a group of two or more packets never waits more than 1 ms.** The receiver queues an acknowledgment at the earliest of:
> - 16 ack-eliciting packets since the last acknowledgment;
> - at least 2, once the oldest unacknowledged one is 1 ms old;
> - 25 ms after a lone packet, as today (`max_ack_delay` and its transport parameter unchanged […]);
> - and at once on today's triggers, all unchanged: a packet previously reported missing, a new gap, an ECN-CE mark […].

> **Mandatory, not a choice:** the delay timer runs from the oldest unacknowledged ack-eliciting packet and is never restarted. Today the fork restarts it on every packet that doesn't queue an acknowledgment ([L128]). At a threshold of 2 that's harmless; at 16 the probe's rule would hold a 100-packets-a-second flow's oldest packet for 150 ms (**derived**: 15 gaps × 10 ms), six times the 25 ms the receiver advertises, so the sender's PTO would fire on packets that aren't lost.

Packaging summary: "A receiver acknowledgment mode, off by default, switched on per transport through a versioned method; it takes the threshold (wiremux passes 16) and applies to Application Data only."

**Existing-work disposition:** New slice, to be filed. An informational consumer comment already sits on [Finish the IETF QUIC Acknowledgment Frequency extension (draft-ietf-quic-ack-frequency)](https://github.com/the-sarge/quic-go-fast/issues/645) and says the request "will come to this tracker as its own issue when it's packaged."

**Blocked by:** None.

**Ordering and never-hold rules:** Holds the release: "The fork part ships only in the fork release that carries the bundle's other five slices […]. wiremux and GridCast still repin once, and the bundle may wait for this slice." The wiremux switch (slice 6.1) lands after the release is adopted and after the macOS connected-socket slice (2.2).

**Fork seams:** [`internal/ackhandler/received_packet_tracker.go` L78–L79](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L78-L79) (`packetsBeforeAck = 2`), [L83–L98](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L83-L98) (tracker fields; no oldest-unacknowledged receive time exists), [L100–L107](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L100-L107) (constructor), [L109–L134](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L109-L134) (`ReceivedPacket`; the restart at [L126–L132](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L126-L132)), [L175–L206](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L175-L206) (`shouldQueueACK`), [L208–L226](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L208-L226) (`GetAckFrame` resets), [L228](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_tracker.go#L228) (`GetAlarmTimeout`); [`internal/ackhandler/received_packet_handler.go` L20–L27](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/ackhandler/received_packet_handler.go#L20-L27) (constructor with no options); [`connection.go` L592](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L592) (per-connection construction, where a per-transport mode is plumbed), [L556](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L556) (ACK_FREQUENCY not supported), [L1090](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L1090) (`maxPacketsToProcess = 32`); [`internal/protocol/params.go` L152](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/protocol/params.go#L152) (`MaxAckDelay`); the versioned-method family on `Transport` (see F2's seams).

**Required design guards:** The mode is off by default and changes nothing when off, including the timer restart ("with the rule off, acknowledgment behaviour is unchanged"). It applies to Application Data only. The refusal unless the connection runs Reno is the consumer's (slice 6.1's test); the fork may add its own. The fork defines and tests the accepted threshold range; 16 must be accepted. The slice changes the receiver's acknowledgment code, which [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808)'s stop-and-ask covers; the release issue names it, and the fork decides its scheduling.

**Required fork-side tests** (verbatim): "**Fork tests:** with the rule off, acknowledgment behaviour is unchanged; with it on, the threshold of 16, the delay timed from the oldest packet with no restart, the 1 ms cap for two or more, the 25 ms lone-packet timer and the immediate triggers; the fork's suite passes, race included."

**Consumer acceptance gate:** Opt-in, so the fork tests are the only gate before the release. The measured gate is slice 6.1 in [Track 6](2026-10-19-macos-native-stack-plan.md), after adoption and connected sockets. Verbatim: "wiremux with the switch off against on, on the bundle's fork release, with the connected-socket slice in, through the rig at the pin (`-ballast 64 -gc-role both`, default-GC row reported beside it). Campaigns run A, B, A, B at `REPS=3`; decisions use pooled medians." Rows: "**`tb`, connected (the payoff):** native Datagrams at least +25%, the stream at least +20%; CPU per delivered GiB at least 20% lower on both peers; loss no more than 0.1 point worse; no spurious losses; no more PTOs than the base runs." "**`tb`, paced Datagrams at 1k, 10k and 100k a second (the guard):** every arm delivers what it's offered with no loss; RTT samples within noise of the base (noise is the gap between the two base campaigns); CPU per GiB no worse." "**`netns` (no harm):** Datagrams and stream no worse than −1%; CPU per GiB no worse; no new loss." "**wiremux tests:** the switch is on for native transports only, and refused unless the connection runs Reno." "**Windows:** the native test suite passes with the rule on, on the Windows GARM pool." Amendments that bind 6.1: the cap-32 rerun ("If either misses a floor, it is rerun against the cap-8 build", [Should the fork's send batch cap follow its 32-entry send queue?](https://github.com/GridSwarm/wiremux/issues/1864#issuecomment-6240753010) section 4) and the send hook off ("The acknowledgment switch, batched send and batched receive gates run with the hook turned off", [Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6240861645) section 6).

**Single owner after merge:** `appDataReceivedPacketTracker` owns the rule when the mode is on; the transport's versioned method owns whether connections get it; the consumer owns where it is switched on.

**Authority completeness:** The mode and its threshold are configured per transport before initialization and immutable afterwards; validation of the threshold is the method's. No persistence.

**Transitional-seam budget:** None.

**Blast radius:** Off: none. On: fewer acknowledgments (peer-visible cadence), one new tracked time (the oldest unacknowledged packet), a 1 ms group timer and no restart. `max_ack_delay` and its transport parameter are unchanged. Untraced, flagged: BBR's behaviour with fewer acknowledgments (the consumer refuses the mode unless Reno, and "any change that moves native connections to BBRv3 must first re-pass this ticket's gate under BBRv3 or leave the rule off for them").

**Artifact classification:** The mode is shipped behaviour (opt-in); the 1 ms group cap and the no-restart timer are required safety enforcement (they keep the sender's PTO from firing on packets that aren't lost).

**Representation contract:** Domain: Application Data packets on connections whose transport has the mode on. Owner: the tracker. Guarantee: the earliest-of rule holds for every ack-eliciting arrival pattern the decided tests represent (example-level, one case per trigger).

**Contract closure:** Not triggered: one owner, and the decided tests give one case per trigger plus the mode-off preservation case; a failure costs rate, not data or authority.

**Evidence budget:** One case per trigger (threshold, 1 ms cap, 25 ms lone packet, missing, new gap, ECN-CE), one no-restart case, one mode-off case, the suite with race; the fork's review practice.

**TDD and preservation evidence:** The no-restart and 1 ms cap cases fail on `main` with the mode forced on. Existing tracker tests stay green with the mode off.

**Dispatch context budget:** About 30,000 tokens. The fork brief carries the decided rule, the mandatory timer fix, the tests, the downstream gate in public phrasing, the RFC 9000 §13.2.2 peer statement and the BBR-campaign note. The fork agent reads `received_packet_tracker.go`, `received_packet_handler.go`, the connection's construction and the versioned-method family.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** The Acknowledgment Frequency extension now, or waiting for it. **Revisit if:** the fork ships [Finish the IETF QUIC Acknowledgment Frequency extension (draft-ietf-quic-ack-frequency)](https://github.com/the-sarge/quic-go-fast/issues/645) ("Reopens when the fork ships the IETF Acknowledgment Frequency extension […], which waits on [quic-go-fast#619] and the fork's BBRv3 program. […] If #619 rejects acknowledgment tuning and #645 closes unbuilt, the rule stays").
- **Rejected alternative (do not do this):** A threshold of 32 or 8. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Every fork connection by changing the constant, or native plus upgraded QUIC Wires; macOS only; macOS and Linux with Windows on the fork's rule. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** No guard beyond the timer fix, or a quarter-RTT cap. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Its own fork release after the bundle, or ahead of it. **Revisit if:** none: rejected on merit.

**Public-brief constraints:** No wiremux links, no "native transports", "Wire" or "upgraded QUIC Wires" (say "the consumer's own peer-to-peer connections" and "its other QUIC connections"), no endpoint paths, host names, evidence paths, rig flags or GARM pool names. Cells: "M4 Max → M4 Pro over Thunderbolt Bridge, MTU 1500, macOS 27, one connected socket per peer, the default Reno controller, saturating senders"; paced rows "an application-limited DATAGRAM sender paced at 1k, 10k and 100k DATAGRAMs a second on the same Thunderbolt pair"; the Windows row "the consumer's test suite on its Windows CI lane". Peer statement for RFC 9000 §13.2.2: "the consumer enables it only on connections whose peer is the same consumer on this fork running Reno."

**Slice decision audit:** Splitting the timer fix from the threshold would ship a mode that breaches `max_ack_delay` at 16. Merging with the IETF extension is the rejected alternative. No blocking edge in the fork.

**Stop conditions:** The fork wants the timer fix for every connection (mode off too) → stop for the operator (the decision keeps mode-off behaviour unchanged). The fork can only offer the mode per `Config` rather than per transport → stop for the operator (the decision says "switched on per transport").

### Fork slice F7 — Darwin read slots for batch-capable adapters

**What it delivers:** A per-connection opt-in on Darwin: an adapter that implements `ReadBatch` and declares that it handles batches is offered more than one read slot (the consumer asks for 8), each slot one byte larger than the fork's packet ceiling. The default stays one slot. A receive kill switch and the no-private-syscalls build tag give one slot. The fork itself makes no private call; the adapter does.

**Decided fork behaviour** ([Should native macOS receives use recvmsg_x on the connected socket, with Darwin read slots in the fork?](https://github.com/GridSwarm/wiremux/issues/1863#issuecomment-6235627888), background [What makes up the connected macOS receive goroutine's cost per datagram, and what would lower it?](https://github.com/GridSwarm/wiremux/issues/1861#issuecomment-6235012064)):

> **What it is:** a per-connection opt-in. An adapter that implements `ReadBatch` and declares that it handles batches is offered more than one read slot on Darwin (wiremux asks for 8). The default stays today's one slot, so bare quic-go users and every adapter that doesn't opt in see no change. It is not process-wide like the probe's `Research1861SetReadBatch`, so one library can't change another's behavior.

> **Slot buffers** one byte larger than the fork's packet ceiling on this path

> Each slot is the fork's packet ceiling plus one byte, derived from the same setting. Today the ceiling is the fork's `MaxPacketBufferSize`, 1,452 bytes […] so slots are 1,453 bytes. That is not a no-jumbo assumption.

> **A receive kill switch,** `QUIC_GO_DISABLE_RECVMSG_X`, mirroring `QUIC_GO_DISABLE_SENDMSG_X`: when it is set, the fork offers one slot, so wiremux reads one datagram per call as today. The `quic_go_no_private_syscalls` build tag does the same.

> **Its own gate is correctness** in the fork's macOS lane: the default is unchanged, an opted-in adapter gets N slots, and the kill switch and build tag give one slot. The speed gate belongs to the wiremux slice, because neither half alone reads more than one datagram per call.

**Existing-work disposition:** New slice, to be filed. The fork's retired `recvmsg_x` experiment ([D2: recvmsg_x receive-batching experiment](https://github.com/the-sarge/quic-go-fast/issues/234)) is not on `main` and is not reopened.

**Blocked by:** None.

**Ordering and never-hold rules:** Never holds the release: "if it is the only slice not ready, the bundle ships without it and it goes in the next fork release. It never holds the other six." "The eighth ships even if the seventh slips." The wiremux half (slice 6.4) is last on macOS.

**Fork seams:** [`sys_conn_helper_darwin.go` L20–L22](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_helper_darwin.go#L20-L22) (`batchSize = 1`); [`sys_conn_oob.go` L37–L39](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L37-L39) (`batchConn`), [L41–L55](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L41-L55) (one-message fallback), [L62–L80](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L62-L80) (`oobConn`: `buffers` is a `[batchSize]` array at L70, so a per-connection N needs restructuring), [L153–L171](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L153-L171) (a participating wrapper owns batch receive), [L173–L197](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L173-L197) (messages and OOB allocated per `batchSize`), [L222–L225](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L222-L225) (slots taken from the 1,452-byte pool today); [`buffer_pool.go` L66–L84](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/buffer_pool.go#L66-L84) (`putBack` accepts only the three tier sizes and panics otherwise, L83); [`sys_conn_sendmsg_x_qual_darwin.go` L33](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_sendmsg_x_qual_darwin.go#L33) (the send kill switch to mirror); opt-in seam candidates [`external_packet_io.go` L65–L74](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/external_packet_io.go#L65-L74) or a method on the adapter.

**Required design guards:** Slot buffers (packet ceiling + 1 byte) never return to the packet-buffer pool, which would panic on their size; they keep their own lifetime with no per-datagram copy into a pool tier, or the fork stops and says so on the issue (the copy changes the cost the consumer's gate measures). The declaration's shape (an adapter method returning a slot count, a configuration successor, or a capability flag) is the fork's call. The kill switch disables slot offers; the brief says the fork never calls `recvmsg_x` on this path. Tests split explicitly: the fork's own macOS lane tests the fork side; the consumer's macOS lane against the fork tests its binding (slice 6.4). The slice touches the receive path [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808)'s readiness run guards: schedule with that campaign ([H13](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).

**Required fork-side tests:** The fork's own gate, verbatim: "the default is unchanged, an opted-in adapter gets N slots, and the kill switch and build tag give one slot"; and from the decided test list, the fork-side row "an adapter that doesn't opt in gets one slot (fork side)". Plus one test that a slot buffer's release path never reaches `putBack`.

**Consumer acceptance gate:** Opt-in; the fork's gate is correctness. The speed gate is slice 6.4 in [Track 6](2026-10-19-macos-native-stack-plan.md), on the adopted release with connected sockets, the acknowledgment switch and the batched send in. Verbatim: "**Datagrams:** rate at least +20%, and receiver CPU per delivered GiB at least 25% lower." "**Stream:** rate at least +20%, receiver CPU per GiB at least 25% lower, no spurious losses, and no more PTOs than base." "**Sender CPU per GiB no more than 20% above base.**" "**Datagram loss** […]: 1. Datagram loss no more than 0.1 point above base […]. 2. Datagrams that the fork's received-Datagram queue discards after acceptance stay at or below 0.01% of those delivered, read from the bundle's internal discard counter." "**Every B run proves the batched receive ran:** more than one datagram per call on average in the slice's counters. A run that fell back is discarded, not counted as a pass." "**No new per-packet allocations,** by the binding allocation slice's exact counts." "A result under any floor comes back to the map; it doesn't ship." Amendments: the cap-8 arm for F8 ([Should the fork's send batch cap follow its 32-entry send queue?](https://github.com/GridSwarm/wiremux/issues/1864#issuecomment-6240753010) section 3) and loss rule 2 holding "only on an idle receiving Mac" ([input from the receiving-Mac load ticket](https://github.com/GridSwarm/wiremux/issues/1863#issuecomment-6247569200)).

**Single owner after merge:** The Darwin `oobConn` owns the slot count and the slot buffers per connection; the adapter owns the private call and its policy.

**Authority completeness:** The opt-in is configured per connection; the kill switch and build tag override it to one slot. No persistence.

**Transitional-seam budget:** None.

**Blast radius:** Default: none. Opted in: N × 1,453-byte slots per connection plus N message headers and OOB buffers (about 13 KB at 8, per the decision), a restructured `oobConn` buffer array, and a slot lifetime distinct from the pool. Linux and Windows never take the path. Untraced, flagged: the slot buffer's tier (a 20 KiB tier per slot would make about 160 KiB per connection; the decision assumed about 13 KB).

**Artifact classification:** The opt-in is shipped behaviour; the slot lifetime is required safety enforcement (a pool return would crash the process); the tests are verification aids.

**Representation contract:** Domain: Darwin connections whose adapter declares batch handling, with and without the kill switch and the build tag. Owner: `oobConn`. Guarantee: slot count is 1 unless opted in and not overridden (universal over those switches); example-level tests.

**Contract closure:** Triggered for the slot lifetime: a wrong release crashes the process, and slots are released along independent paths.

| Semantic class | Expected disposition | Enforcement owner | Evidence | Status |
| --- | --- | --- | --- | --- |
| Datagram delivered from a slot, released by the connection | Slot storage returns to the slot owner, never to `putBack` | slot lifetime | release-path test | Required |
| Failed batch | The batch's datagrams discarded (today's policy); slots stay slot-owned for the next read | `ReadPacket` | failed-batch test under race | Required |
| Reader stop | Slots released once | `releaseReadBuffers` | stop test under race | Required |
| Not opted in, kill switch, build tag | One pooled slot, today's path | `oobConn` | the three one-slot tests | Required |

**Evidence budget:** The four correctness rows above plus the three one-slot cases, the suite with race on the macOS lane; at most one guard mutation (returning a slot to `putBack` must fail the release-path test); the fork's review practice.

**TDD and preservation evidence:** The opted-in N-slot test fails on `main` first. The default one-slot behaviour is pinned before the restructure.

**Dispatch context budget:** About 35,000 tokens. The fork brief carries the decided behaviour, the slot-size rule, the lifetime guard, the fork-side tests, the split between the fork's and the consumer's lanes, the BBR-campaign note and the public measurement phrasing. The fork agent reads `sys_conn_oob.go`, `sys_conn_helper_darwin.go`, `buffer_pool.go`, `external_packet_io.go`, the `sendmsg_x` kill-switch file and the fork's Darwin batch ADR 0008.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** 16 slots, one run-loop notification per batch, a raw `recvmsg` without Go's allocations, a shared source address. None gained beyond 8. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** One slot through `recvmsg_x` (it costs 10–12% more than `recvmsg`). **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** A process-wide knob. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Slots exactly at the packet ceiling (truncation would be undetectable). **Revisit if:** none: rejected on merit; any jumbo work reruns the gate.

**Public-brief constraints:** No host names, GARM pool names, evidence or probe names (including the private probe hook name), no wiremux links. Public phrasing: "A downstream consumer's adapter implements `ReadBatch` and will fill several slots with one `recvmsg_x` on a connected socket (its own private-call policy: version allowlist, self-check, fallback). Measured downstream on two Apple-silicon Macs over a Thunderbolt Bridge, eight slots lifted rates about 28% with 37–38% less receiver CPU per GiB." The fork brief needs no cell, since its gate is correctness.

**Slice decision audit:** Merging with the consumer's binding work crosses repositories; the decision split them because "neither half alone reads more than one datagram per call". Splitting the kill switch out would ship slots with no field escape. No blocking edge.

**Stop conditions:** The fork cannot give slots their own lifetime without a per-datagram copy into the pool tier → stop for the operator (the copy changes the cost the gate measures). A loss-rule-2 failure in slice 6.4 is a separate decision ("a deeper queue or a reader change would be a separate decision"), not a revert of this slice.

### Fork slice F8 — Send batch cap follows the queue depth

**What it delivers:** `maxSendBatch = sendQueueCapacity` again, the fork's original definition that F4 split. With F4's 32-entry queue, every fork connection sends groups of up to 32, BBR included, and the fork's own Darwin batched send follows.

**Decided fork behaviour** ([Should the fork's send batch cap follow its 32-entry send queue?](https://github.com/GridSwarm/wiremux/issues/1864#issuecomment-6240753010), background [How much would a fork send batch cap above 8 add once the macOS receiver is faster?](https://github.com/GridSwarm/wiremux/issues/1862#issuecomment-6236968867)):

> **Decision: adopt.** The fork's send batch cap follows its send queue's depth again: `maxSendBatch = sendQueueCapacity`, the fork's own original definition, which [#1850] split to keep its change narrow. In the bundle that makes the cap 32 for every fork connection.

> **Reach.** Every fork connection, BBR included (fork `main` already gives BBR a 32-entry queue with cap 8 […]; its pacer seldom fills a group), and the fork's own macOS batched send for plain quic-go users, whose scratch and size check follow `maxSendBatch` ([`send_conn_sendmsg_x_darwin.go` L214]).

> **No setting and no kill switch** for the cap; it is one fork constant.

**Existing-work disposition:** New slice, to be filed.

**Blocked by:** F4 ("Order inside the fork: after the 32-entry queue slice. Before it, the depth is 8 and the change does nothing.").

**Ordering and never-hold rules:** Never holds the release: "**It takes the read-slot slice's never-hold rule:** if it is the only slice not ready, the bundle ships without it and it goes in the next fork release." "**It isn't tied to the read slots.** If the seventh slice slips, the cap still ships in the bundle (+1.3% on macOS and +0.4–4.3% on Linux, no harm measured), and its macOS gain appears when the read slots follow."

**Fork seams:** [`send_queue.go` L119–L120](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L119-L120) (the definition, split by F4), [L258](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L258) (the group bound), [L279–L288](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L279-L288) (one room signal per group); [`send_conn_sendmsg_x_darwin.go` L211–L236](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_conn_sendmsg_x_darwin.go#L211-L236) (the Darwin batch writer; size check at L214), with scratch growth at [L41–L47](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_conn_sendmsg_x_darwin.go#L41-L47); tests [`send_conn_sendmsg_x_darwin_test.go` L53–L54](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_conn_sendmsg_x_darwin_test.go#L53-L54) and the batch fakes in `send_queue_batch_test.go` and `send_queue_batch_feedback_test.go`.

**Required design guards:** The cap raise reaches BBR's send path, which by the fork's BBR rule makes a new BBR revision needing its own readiness measurement: coordinate with [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808) (land after its readiness run, or have the fork owner decide how the revision is measured; [H13](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). The consumer runs Reno only.

**Required fork-side tests** (verbatim): "**The fork's test suite passes,** its own macOS batched-send tests with 32-packet groups among them."

**Consumer acceptance gate:** The ship gate, verbatim from [Should the fork's send batch cap follow its 32-entry send queue?](https://github.com/GridSwarm/wiremux/issues/1864#issuecomment-6240753010):

> The cap slice's commit is compared against the queue slice's commit (cap 8), through wiremux's rig as wiremux's `main` stands then, at the pin (`-ballast 64 -gc-role both`). Campaigns run A, B, A, B at `REPS=3`, and decisions use pooled medians. It passes when all of these hold:
> - **`tb`, Datagrams at the pin and the stream: no slower.** It fails only if both A/B pairs show cap 32 lower, the 32-entry queue's own rule, because `tb`'s sender-bound runs drift 7–16% between campaigns. This row matters most: when the bundle ships, wiremux on macOS still sends one packet per call, and every research arm had batched sends, so it is the first measurement of cap 32 on that shape.
> - **`netns`, every workload: no worse than −1%,** and CPU per GiB within 2% on both peers.
> - **Minimum RTT:** no rise beyond noise (the gap between the two base campaigns).
> - **Mean RTT under load:** a rise of no more than 100 µs on `tb` and 40 µs in `netns`.
> - **Loss:** no more than 0.1 point above base, no rise in the bundle's received-Datagram queue discards, and no more PTOs than base.
> - **The fork's test suite passes,** its own macOS batched-send tests with 32-packet groups among them.
>
> A failure means the bundle ships without the cap, and the cap comes back to the map.

**Owner decision (2026-10-21): F8 ships at cap 32.** Task 4.G3 failed five rows as written and passed every other row ([record](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6329860799); see [Task 4.G3](#task-4g3--batch-cap-ship-gate-f8)). [The owner decision](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6330277355), verbatim:

> **Owner decision, 2026-10-21 21:14 EDT:** "option 2". Josh gave this answer to this task's recommendation, after reading the failed rows of the [record](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6329860799).
>
> Option 2, as put to him: **keep F8 (cap = depth = 32) as merged, and accept its interim costs in writing**, rather than shipping at cap 8.
>
> - **Why not cap 8:**
>   - A revert of F8 would void 4.G1's pass, because `0b0f77b0` is an ancestor of `2a83ed29`, which every 4.G1 third-run build carried.
>   - A later raise of the cap would need another fork release and repin.
>   - The Mac latency cost comes from today's one-packet-per-call macOS sender, which slice 6.3 replaces.
> - **Accepted in writing, until slice 6.3's batched send:** the five rows that failed as written.
>   - `tb` mean RTT under load: +101.8 µs for Datagrams and +274.4 µs for the stream (bound 100 µs).
>   - `netns` stock-Datagram receiver CPU per GiB: +2.46% (bound 2%).
>   - Stock-Datagram minimum RTT: `netns` +0.9 µs against 0.4 µs noise; `tb` +30.0 µs against 25.7 µs noise.
> - **No separate re-test.** F8's check on the batched macOS shape stays the cap-8 arm already in slice 6.4's gate ("Harm sends the cap back to the map"). That arm gains a mean-RTT-under-load row, read from the readout every run records, so it adds no runs. The plan amendment states the row's bound.

The 6.4 row and its bound are recorded in [Slice 6.4](2026-10-19-macos-native-stack-plan.md#slice-64--recvmsg_x-into-the-forks-eight-read-slots-on-the-connected-socket) of the macOS plan.

**Who runs it:** Task 4.G3, after F8 merges on fork `main`, before the release. The speed confirmation runs later inside slice 6.4's gate ("**One extra arm,** everything on, built against the same fork release with the cap set back to 8 (a local one-line fork copy, as the rig already builds), in the same A, B, A, B campaign"; "Datagrams at the pin at least +8% and the stream at least +12%; the stream's sender CPU per GiB at least 10% lower and the Datagrams' no higher; the receiver no worse"; "**Harm sends the cap back to the map,** most likely to revert to 8 in the next fork release"; "**A gain short of the reference but not negative is recorded, not reverted.**"). Slices 6.1 and 6.3 keep their floors and "If either misses a floor, it is rerun against the cap-8 build". Since the 2026-10-21 decision, 6.4's cap-8 arm also judges mean RTT under load.

**Single owner after merge:** `send_queue.go`'s one depth constant; the cap is defined from it.

**Authority completeness:** No configured or persisted fact.

**Transitional-seam budget:** Removes F4's split constant.

**Blast radius:** Every fork connection sends groups of up to 32. Measured costs (**measured**, [How much would a fork send batch cap above 8 add once the macOS receiver is faster?](https://github.com/GridSwarm/wiremux/issues/1862#issuecomment-6236968867) research): the mean RTT under saturation rises about 85 µs on `tb` and 20–27 µs in `netns`, with the minimum unchanged; Datagram loss rises by up to 0.1 point, almost all at the 128-entry received-Datagram queue the bundle raises. On wiremux's one-packet-per-call send shape, Task 4.G3 measured larger costs on both cells, which the owner accepted in writing until slice 6.3 (**measured**, [record](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6329860799)): `tb` mean RTT under load +101.8 µs for Datagrams and +274.4 µs for the stream, `netns` stock-Datagram receiver CPU per GiB +2.46%, and stock-Datagram minimum RTT +0.9 µs (`netns`) and +30.0 µs (`tb`). A new BBR revision under the fork's rule (flagged above). The Darwin scratch grows on demand, so nothing allocates per call.

**Artifact classification:** Shipped behaviour (one constant).

**Representation contract:** Domain: every fork connection's batched send. Owner: the constant. Guarantee: universal (cap equals depth).

**Contract closure:** Not triggered: one constant.

**Evidence budget:** The updated Darwin batched-send tests at 32 and the batch fakes, the suite with race on the three lanes; the fork's review practice. Consumer measurement: Task 4.G3's budget.

**TDD and preservation evidence:** F4's cap-pinning test is updated to pin cap equals depth; the Darwin test sends a 32-packet group through `sendmsg_x`.

**Dispatch context budget:** About 20,000 tokens. The fork brief carries the decided definition, the reach, the BBR-revision note, the tests, the downstream ship gate and speed confirmation in public phrasing and the never-hold rule. The fork agent reads `send_queue.go`, `send_conn_sendmsg_x_darwin.go` and the batch tests.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** The cap as its own constant of 32, or cap 16. "Each group is drawn from the queue, so a cap above the depth does nothing and one below it is today's split." **Revisit if:** a later decision changes the depth ("the cap moves with it, and that decision's gate measures both").
- **Rejected alternative (do not do this):** A positive Linux floor ("the paired `netns` gain was only +2.2%, so a floor would mostly test noise, and the cap is there for macOS"). **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** A probe build before the bundle ships, or no separate check. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Shipping at cap 8 after 4.G3's five failed rows, by reverting F8 or leaving it out. The owner kept cap 32 ([decision](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6330277355)): a revert would void 4.G1's pass, a later raise would need another fork release and repin, and the Mac latency cost comes from today's one-packet-per-call macOS sender, which slice 6.3 replaces. **Revisit if:** slice 6.4's cap-8 arm shows harm, including its mean-RTT-under-load row ("Harm sends the cap back to the map").

**Public-brief constraints:** No wiremux links, probe worktree or copy names, evidence paths, host or session names. Cells: `tb` "two Apple-silicon Macs over a Thunderbolt Bridge at MTU 1500, macOS 27, connected sockets"; `netns` as in F4. "Batched receives" is "the consumer's batched receive (eight datagrams per `recvmsg_x` call on a connected socket)"; "one packet per send call" is "the consumer's macOS sender without batched sends".

**Slice decision audit:** Merging with F4 is what F4's guard prevents. Merging with F7 would tie a never-hold cap to read slots, which the decision rejects. Blocking edge F4 → F8 is necessary: before F4 the change does nothing.

**Stop conditions:** A 4.G3 failure → the bundle ships at cap 8 (the fork reverts F8 or leaves it unmerged) and the cap returns to the map (on 2026-10-21 the owner accepted 4.G3's failed rows instead, above, and F8 ships at cap 32). The fork's BBR readiness for the new revision raises a cell → the fork owner's disposition decides BBR; the consumer's gate is Reno only and does not decide it.

### Fork slice F9 — User-initiated send thread on Apple silicon

**What it delivers:** A fork hook at the top of every `sendQueue.Run` (each connection and each path) that, when a consumer switches it on through a versioned capability, locks the send goroutine to its thread, raises the thread to user-initiated, verifies the raise by base priority, re-checks about once a second, stands down for the rest of the connection if the raise is taken away, restores the class before unlocking, and reports each connection's outcome internally. Apple silicon only; a no-op build elsewhere; an environment-variable kill switch.

**Decided fork behaviour** ([Should native connections raise the fork's send thread to user-initiated on macOS?](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6240861645)):

> **Decision: adopt.** On Apple-silicon Macs, the fork's send goroutine locks itself to its thread and raises that thread to user-initiated, for every native Wire.

> - **Class: user-initiated.** User-interactive gave the same rates (#1853 §5), cost other work 2–5× more (6.7% against 1.4% at 24 spinners), and only the frontmost app can have it.
> - **Apple silicon only.** Intel Macs have no efficiency cores, so the measured mechanism doesn't exist there and the effect is unmeasured. Intel and Linux builds compile the hook as a no-op. Intel can be added later if a gain is measured on [an Intel Mac].
> - **Where:** a fork hook at the top of every `sendQueue.Run` (each connection, and each path), reaching libSystem through a trampoline as `golang.org/x/sys/unix` does, with no cgo. wiremux switches it on through a versioned `Configure…V1` capability found by interface assertion, so stock quic-go still compiles.

> - **At start:** lock, raise, then read the thread's base priority (`proc_pidinfo` `PROC_PIDTHREADID64INFO`, public in `libproc.h`). Only a base priority of 37 or more counts; `qos_class_self()` reports the requested class even when it is squashed (#1853). If it didn't rise, restore the class and unlock.
> - **While sending:** re-check about once a second. If the raise has been taken away, restore and unlock for the rest of that connection; it isn't raised again. […] The cost is one system call per second per sending connection.
> - **On exit:** restore the class before unlocking, so Go's thread pool never gets a raised thread back.

> **4. Visibility: internal, plus docs** — The fork reports each connection's outcome (raised, refused at start, or stood down later) to wiremux internally, the way the decided queue-discard counts work. The rig and tests read it. There's no public API.

> **5. Which goroutines: the send goroutine only**

> - **Kill switch:** the fork hook has an environment-variable kill switch (for example `QUIC_GO_DISABLE_SEND_QOS`, after the read slots' `QUIC_GO_DISABLE_RECVMSG_X`; the fork names it). The later macOS gates use it, and so can an operator.

From [Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?](https://github.com/GridSwarm/wiremux/issues/1868#issuecomment-6251637328) section 3: "**The adopted send raise on the receiving peer: kept, no stand-down** […] the fork can't tell a receiving peer from a sending one. […] The hook's environment-variable kill switch is the operator's escape hatch."

**Existing-work disposition:** New slice, to be filed. Nothing on fork `main` (no QoS, thread-locking, `proc_pidinfo` or trampoline code).

**Blocked by:** None.

**Ordering and never-hold rules:** "**Fork half: the ninth slice of the one fork bundle, never holding it.** If it's the only slice not ready, the bundle ships without it and it goes in the next fork release. It isn't tied to the read slots or the batch cap." The wiremux switch (slice 6.2) lands once the release and the connected-socket slice are on `main`.

**Fork seams:** [`send_queue.go` L188–L218](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_queue.go#L188-L218) (`Run`: the hook at the top, after `defer close(h.runStopped)` at L189; the re-check inside the loop, which blocks in `select` at L195); goroutine starts at [`connection.go` L639–L643](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L639-L643) (via [`packet_emission.go` L100](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission.go#L100)) and [`connection.go` L987–L999](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L987-L999) (`switchToNewPath` starts a new `Run` per path); goroutine-confined Darwin batch state at [`send_conn_batch_state_darwin.go` L5–L10](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/send_conn_batch_state_darwin.go#L5-L10); platform-split precedent `pacing_kick_linux.go` and `pacing_kick_other.go`; kill-switch precedents [`sys_conn_sendmsg_x_qual_darwin.go` L33](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_sendmsg_x_qual_darwin.go#L33) and [`packet_emission_gso.go` L19](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_gso.go#L19); internal-outcome precedent [`DatagramReceiveDropsV1`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L3004).

**Required design guards (from the fork's code):** "Stand down for the rest of that connection" means the stood-down state outlives one `sendQueue` (a path change makes a new one), so it lives on `packetEmission` or `Conn`. The build constraint is `darwin && arm64` with a no-op elsewhere (Rosetta amd64 and `ios` builds fall out as no-ops; the fork confirms). libSystem access without cgo is new to the fork: the fork decides whether it needs a record under its Darwin private-call rules ([ADR 0008](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/docs/adr/0008-darwin-batch-compatibility.md)), noting these are public libSystem calls. The fork's macOS lane needs an injectable seam to emulate a refusing launch context and a mid-run priority drop on hosted runners. The thread id source and the `proc_threadinfo` field that is the base priority are the fork's to verify. The outcome method uses built-in types only (for example a small integer code with documented values, no fork-defined type in its signature), found by interface assertion like the other counts. The hook sits on the send path [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808)'s stop-and-ask covers; the release issue names it, and the fork decides its scheduling.

**Required fork-side tests** (verbatim): "**Fork tests:** the fork's macOS lane tests the stand-down at start (a refusing launch context) and mid-run (an injected priority drop), and that the class is restored before unlocking."

**Consumer acceptance gate:** Opt-in; the fork's gate is its macOS-lane tests. The measured gate is slice 6.2 in [Track 6](2026-10-19-macos-native-stack-plan.md): "On `tb`, on the shape main has when the switch lands (connected socket plus the bundle). […] One binary, the hook on against off, interleaved A, B, A, B, medians of three, Datagrams at the pin (`-ballast 64 -gc-role both`) and the stream. All must hold:"

| Row | Load | Pass if |
| --- | --- | --- |
| Busy Mac | 12 and 24 spinners in another program (separate ssh session) | Datagrams ≥ +25% and stream ≥ +35% over hook-off at both steps (measured +37–53% and +58–69%) |
| Idle | none | hook-on no worse than −2% (measured +14–18% Datagrams, +3% stream) |
| Busy consumer | 12 CPU-bound goroutines in the sender (`-goload 12`) | hook-on no worse than hook-off (measured +41% and +50%) |
| Refused launch | sender started from a shell under an app, 24 spinners | within ±5% of hook-off, and the internal outcome reads refused (the trap would show about −40%) |
| Stays on fast cores | the busy-Mac rows | the raised thread spends ≤ 1% of its time on efficiency cores (`-threads`; measured ≤ 0.34%) |
| Cost to others | the busy-Mac rows | the spinners' median progress ≥ 90% of what they made beside hook-off (measured median 97%, worst 90%) |

Plus the [busy-receiving-Mac row](https://github.com/GridSwarm/wiremux/issues/1858#issuecomment-6251638999) from [Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?](https://github.com/GridSwarm/wiremux/issues/1868#issuecomment-6251637328):

| Row | Load | Pass if |
| --- | --- | --- |
| Busy receiving Mac | Other-program spinners on the receiving Mac at its performance-core count and at 1.5× all its cores (8 and 18 on m4mini, from a separate ssh session). Sender idle with the hook on; the receiver's hook on against off. | Hook-on no worse than −8% at both steps, Datagrams at the pin and stream (measured −3% to +2% at 8, −2% to −7% at 18) |

Later macOS gates run with the hook off: "**Later macOS slices keep their floors.** The acknowledgment switch, batched send and batched receive gates run with the hook turned off (the kill switch below), so the floors decided for them stay valid."

**Single owner after merge:** The fork hook owns the thread's class for the send goroutine's life; the per-connection stood-down state and outcome live on the connection's emission; the kill switch overrides the consumer's switch.

**Authority completeness:** The switch is configured per transport through the versioned capability; the outcome is a read-only internal report. No persistence.

**Transitional-seam budget:** None.

**Blast radius:** On Apple silicon with the switch on: the send goroutine is locked to its thread, one system call per second per sending connection, and a raised thread that must never return to Go's pool raised. Off, or on other platforms: none. Measured costs to other work are in the gate's "Cost to others" row. Untraced, flagged: interaction with Go runtime thread handling beyond lock and unlock (the restore-before-unlock guard is the enforcement).

**Artifact classification:** The hook is shipped behaviour (opt-in); restore-before-unlock is required safety enforcement; the outcome report is a shipped internal diagnostic API.

**Representation contract:** Domain: send goroutines of connections whose transport switched the hook on, on `darwin/arm64`, every path. Owner: the hook. Guarantee: the class is restored before every unlock on every exit (universal over the enumerated exits below), example-level tests.

**Contract closure:** Triggered: a raised thread leaking into Go's pool is a broken restoration obligation, reachable through independent exits.

| Semantic class | Expected disposition | Enforcement owner | Evidence | Status |
| --- | --- | --- | --- | --- |
| Raise refused at start | Class restored, thread unlocked, outcome "refused" | hook start | refusing-context test | Required |
| Raise taken away mid-run | Restored, unlocked, never raised again for the connection, outcome "stood down" | hook re-check + connection state | injected priority drop test | Required |
| Normal exit of `Run` | Restored before unlock | hook exit | restore-before-unlock test | Required |
| `Run` exits on a send error | Restored before unlock | hook exit | error-exit case | Required |
| Path change after a stand-down | New `Run` does not raise | connection state | path-change case | Required |
| Kill switch set, or not `darwin/arm64` | No lock, no raise | build split + switch | kill-switch case; non-darwin build | Required |

**Evidence budget:** One case per row (six), on the fork's macOS lane, plus the no-op build on the other lanes; at most one guard mutation (unlocking before restoring must fail the restore test); the fork's review practice.

**TDD and preservation evidence:** The refusing-context and injected-drop tests come first, against the injectable seam. Existing `sendQueue.Run` tests stay green with the switch off.

**Dispatch context budget:** About 40,000 tokens. The fork brief carries the decided behaviour, the check-and-fallback rules, the guards from the fork's code, the tests, the downstream gate rows in public phrasing, the kill-switch name rule, the never-hold rule and the BBR-campaign note. The fork agent reads `send_queue.go`, the goroutine starts in `connection.go` and `packet_emission.go`, the Darwin platform files and kill-switch precedents, ADR 0008 and `golang.org/x/sys/unix`'s trampoline pattern.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** User-interactive class. **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Intel Macs. **Revisit if:** a gain is measured on an Intel Mac ("Intel can be added later if a gain is measured").
- **Rejected alternative (do not do this):** Raising the receive goroutine or run loop, a load-aware stand-down, or research first ([Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?](https://github.com/GridSwarm/wiremux/issues/1868#issuecomment-6251637328) options 2 and 3). **Revisit if:** batched receives don't become the lasting macOS shape, or the platform targets need a busy receiving Mac's rate ([Should the fork raise the native receiver's receive goroutine or run loop on macOS, given gains on a busy receiving Mac and losses on an oversubscribed one?](https://github.com/GridSwarm/wiremux/issues/1868#issuecomment-6251637328) section 2; both recorded as not triggered).
- **Rejected alternative (do not do this):** A stand-down on the receiving peer. **Revisit if:** none: rejected on merit ("the fork can't tell a receiving peer from a sending one").

**Public-brief constraints:** No host or session names, launcher tool names, evidence paths, rig flags, "native Wire", `NativeConfig` or wiremux links, and nothing about GridCast's launch situation. Public phrasing: cell "two Apple-silicon Macs over a Thunderbolt Bridge at MTU 1500, macOS 27: an M4 Max (12 performance + 4 efficiency cores) sending to an M4 Pro (8 performance + 4 efficiency cores), connected socket per peer"; launch "the sender runs where its QoS ceiling admits user-initiated: its own ssh session or a launchd daemon/agent context"; busy Mac "12 and 24 CPU-bound spinner threads at the default class in a separate process with its own coalition (another thread group)"; busy consumer "12 CPU-bound goroutines inside the sending process (GOMAXPROCS 16)"; refused launch "the sender started as a child of an app (a terminal or IDE), whose QoS ceiling refuses the raise"; busy receiving Mac "8 and 18 spinners on the receiving M4 Pro, its performance-core count and 1.5× all its cores"; core residency "a per-thread performance/efficiency-core residency readout".

**Slice decision audit:** Splitting the re-check from the start check would ship a raise with no stand-down. Merging with F7 or F8 is rejected ("not tied to the read slots or the batch cap"). No blocking edge.

**Stop conditions:** The fork cannot reach libSystem without cgo → stop for the operator (cgo would break the consumer's pure-Go builds). The base-priority readout cannot tell a squashed raise from a real one on some macOS version the consumer supports → stop.

### Fork slice F10 — Equal-size DATAGRAM gluing

**What it delivers:** Segmented (GSO/USO) sends batch equal-size short DATAGRAM packets with the first packet's size as the segment size, on both emission paths, by default for every connection, with a kill switch for gluing alone; a lone packet goes without a segment size.

**Decided fork behaviour** ([Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084)):

> **Gluing is on for every connection, on both the ordinary (`withGSO`) and BBR bounded (`boundedDatagrams`) emission paths. There is no API setting and no wiremux switch.**

> A new environment variable turns off gluing alone, so a regression can be ruled out in the field without a rebuild. […] `QUIC_GO_DISABLE_GSO` is unchanged. It turns off every segmented send, including the stream's.

> **Windows:** default-on also reaches Windows segmented sends (USO), because the emission loop is shared.

> 1. **Never drop a Datagram that misses only the short size.** […]
> 2. **Never exceed the platform's segment limit per send:** 128 on Linux (`UDP_MAX_SEGMENTS`). Windows USO's limit is verified in the fork's Windows test lane. The probe closed one Wire with `EINVAL`.
> 3. **Only a packet that carries a DATAGRAM frame may start a short batch.** […]
> 4. **#742 lands first:** a buffer holding one packet is sent with no segment size.
> 5. **BBR bounded path:** credit is reserved in maximum-size units. The unused remainder is released, and credit accounting stays exact.
> 6. **Stream data is never packed at a short size.** […]

**Existing-work disposition:** **Retain** ([H12](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). [GSO emission costs ~3% throughput when each send carries one packet](https://github.com/the-sarge/quic-go-fast/issues/742) landed as `592e98cb` ([PR #805](https://github.com/the-sarge/quic-go-fast/pull/805)) and [Consider GSO-batching equal-size short packets with the first packet's size as the segment](https://github.com/the-sarge/quic-go-fast/issues/743) as `9b52dca8` ([PR #818](https://github.com/the-sarge/quic-go-fast/pull/818)), both closed; the related [GSO-error fallback loops forever on a size-0 write that returns EIO](https://github.com/the-sarge/quic-go-fast/issues/809) fix landed as `501e80bd` ([PR #817](https://github.com/the-sarge/quic-go-fast/pull/817)). No release carries them. Every decided safeguard is in the code: S1 through [`AppendDatagramPacket`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_packer.go#L468-L495), which "leaves the frame queued"; S3 in [`gsoBatch.add`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_gso.go#L60-L70); S4 in [`gsoSize`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_gso.go#L80-L85); S5 in [`boundedDatagrams`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_bbr.go#L167-L180); S6 by DATAGRAM-only continuations. **Accepted deviation:** a 64-segment cap ([`packet_emission_gso.go` L12–L14](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_gso.go#L12-L14), "Linux before 6.9 rejects more than 64") instead of Linux's 128. It is stricter and never binds at the consumer's sizes, because the 20 KiB GSO buffer holds at most about 14–18 such packets (**derived**: 20,480 ÷ 1,424 or 1,126 bytes). **Early warnings** from the fork's loopback record that the consumer gate checks: the stream at 0.979× and smoothed RTT +84 µs (23 → 107 µs; **measured**, fork harness). [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084) section 7 asked packaging to rewrite the gluing issue's labels and brief; that issue has since merged and closed, so packaging posts a consumer comment instead ([H30](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)), recording acceptance, the deviation and the outstanding gate; both issues become sub-issues of the release parent.

**Blocked by:** None (merged). Release-level: never ships ahead of F1 and F5.

**Ordering and never-hold rules:** "**#742 and #743 together are the tenth slice of the one fork bundle. They never hold the release.** If they aren't ready, the bundle ships without them and they go in the next fork release (a second repin only then)." "**They never ship ahead of the two deeper queues.** That is automatic: those are bundle slices 1 and 5, which hold the release. Without them, default-on gluing would bring back 1.6–2.7% silent Datagram loss (#1844)." Since gluing is merged and on by default, the rule now binds the release, not the merge order: see [If F10's consumer gate fails](#if-f10s-consumer-gate-fails).

**Fork seams:** [`packet_emission_gso.go` L12–L94](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_gso.go#L12-L94) (`maxGSOSegments`, the kill switch at L19, `shortGSOSegmentsEnabled` at L23–L26, `gsoBatch`); [`connection.go` L2714](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2714) (read once per connection); [`packet_emission_bbr.go` L167–L180](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_bbr.go#L167-L180); [`packet_packer.go` L468–L495](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_packer.go#L468-L495) (`AppendDatagramPacket`) and the upstream discard kept for frames too large for a maximum-size packet at [L684–L689](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_packer.go#L684-L689) (the packer-discard counter site for the gate build); tests [`packet_emission_gso_test.go` L176](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_gso_test.go#L176)–[L394](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_emission_gso_test.go#L394), [`sys_conn_helper_linux_test.go` L81](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_helper_linux_test.go#L81) (`TestSysConnSendShortSegmentLimit`), [`sys_conn_windows_uso_test.go` L209](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows_uso_test.go#L209) (`TestWindowsConnShortSegmentLimit`, which skips on hosts without USO).

**Required design guards:** None new. The Tests row is met once the fork confirms that `TestWindowsConnShortSegmentLimit` ran, not skipped, on a USO-capable Windows runner for `9b52dca8`; the consumer comment on the gluing issue asks for that confirmation. On 2026-10-21 the fork had not replied; the 4.G5 record read from the fork's CI that the test ran and passed, not skipped, for `9b52dca8` and `642f014e`, and the owner accepted the result on that record (see [Task 4.G5](#task-4g5--equal-size-gluing-gate-on-the-bundle-candidate-f10)).

**Required fork-side tests:** Present: the safeguard tests, the kill-switch test and the segment-limit tests on Linux and Windows. The decision's row: "full fork suite (race and shuffle), the safeguard tests, a kill-switch test, and the segment-limit test in the fork's Windows lane."

**Consumer acceptance gate:** verbatim from [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084) section 5:

> - The Linux `netns` shape cell, on the fork-bundle candidate. The deeper queues, the 32-entry send queue and copy-at-read are in.
> - The adopted Linux wiremux stack is in through the rig's stand-ins: slice A, slice B, and coalescing with copy-at-read.
> - Both arms use one binary, with gluing switched on or off by the kill switch, run as interleaved A,B,A,B campaigns with 3 repetitions each.
> - Runs are at the pin (`-ballast 64 -gc-role both`), with the default-GC row reported, at the Datagram size in force. A 1,099-byte row (GridCast's record size) is reported too.

| Line | Threshold |
| --- | --- |
| Datagram throughput | ≥ 2× the gluing-off arm (the probe pair against the stock sender: about 2.5–2.9×, **derived** across campaigns) |
| Sender CPU per GiB | ≥ 20% lower (the probe measured −35%, 5.18 → 3.39, [on quic-go-fast#743](https://github.com/the-sarge/quic-go-fast/issues/743)) |
| Receiver CPU per GiB | ≤ +5% |
| Stream alone | ≥ −1% |
| Mixed stream and Datagrams on one Wire (new rig arm) | stream ≥ −1%, Datagrams no worse. The slice states the mix before measuring. |
| Loss | Datagram loss ≤ +0.1 point. Received-Datagram queue discards ≤ 0.01% (internal count from [How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507)). Packer discards exactly 0 (counted in the gate build). Unprocessed-queue drops reported ([Should native connections get a deeper unprocessed-packet queue than the fork's 256 packets?](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120)). |
| Wire closures (`EINVAL` or any send error) | 0 across every run |
| Round-trip time | minimum flat; mean ≤ +40 µs (the netns bound from [Should the fork's send batch cap follow its 32-entry send queue?](https://github.com/GridSwarm/wiremux/issues/1864#issuecomment-6240753010)) |
| Reported, not gated | segments per `sendmsg` and the share of sends with ≥ 2 segments |
| Tests | full fork suite (race and shuffle), the safeguard tests, a kill-switch test, and the segment-limit test in the fork's Windows lane |

> - **No macOS row:** macOS never takes this path.
> - **No Windows speed row:** Windows rates belong to [Does Windows native receive coalescing (URO) fit wiremux's admission, and what does it buy through wiremux?](https://github.com/GridSwarm/wiremux/issues/1869) and [Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870).
> - **No absolute 10.0 Gbit/s line:** per #1801, each slice has its own gate, and the Linux certification task checks the floor.

**Owner decision (2026-10-21): gluing ships on by default.** Task 4.G5 failed one row as written, the Datagram workload's minimum RTT, and passed every other row ([record](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331860438); see [Task 4.G5](#task-4g5--equal-size-gluing-gate-on-the-bundle-candidate-f10)). [The owner decision](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331887768), verbatim:

> "Accept on smoothed RTT like 4.G1; gluing ships on"

The reading he then chose ([reading](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331999513), coordinator relay: "your recommendation"):

- **Minimum RTT:** the minimum-RTT half of the "Round-trip time" row (`dgrampin` +9.8 µs against 0.9 µs noise) is reported, not judged, as in 4.G1.
- **Latency:** judged on that row's own bound, "mean ≤ +40 µs". The run measured +22.7 µs, so it passes.
- **Smoothed RTT:** reported beside it (`dgrampin` 84 → 141 µs, +57 µs).
- **Not used:** 4.G1's 768-packet smoothed-RTT bound, which [the decision as first recorded](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331887768) applied. That bound derives from F5's queue depth and does not belong to the gluing gate. The verdict is the same under either.

**Who runs it:** Task 4.G5, on a bundle candidate carrying F1, F3, F4 and F5, before the release is cut.

**Single owner after merge:** `gsoBatch` owns batch growth; the kill switch is read once per connection at setup.

**Authority completeness:** No configured or persisted fact beyond the environment variable read at connection setup.

**Transitional-seam budget:** None.

**Blast radius:** Retained as merged. Default-on reaches Linux GSO and Windows USO sends for every connection. The consumer's stake is the early warnings above and the release rule tying the default to F1 and F5. Task 4.G5 measured, and the owner accepted, a Datagram minimum RTT +9.8 µs higher with gluing on, smoothed RTT 84 → 141 µs and mean RTT +22.7 µs (**measured**, [record](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331860438)).

**Artifact classification:** Shipped behaviour; the safeguards are required safety enforcement (S1, S2, S6 prevent loss, send errors and stream damage); the gate build's packer-discard and segment counters are verification aids that never ship.

**Representation contract:** Domain: segmented sends on Linux and Windows. Owner: `gsoBatch` and `AppendDatagramPacket`. Guarantee: each safeguard universal over its path, with example-level tests (merged).

**Contract closure:** Retained work; the merged safeguard tests and the fork's guard mutations (listed in [PR #818](https://github.com/the-sarge/quic-go-fast/pull/818)) are its evidence. Not re-opened.

**Evidence budget:** Fork side complete. Consumer side: Task 4.G5's budget.

**TDD and preservation evidence:** Done in [PR #805](https://github.com/the-sarge/quic-go-fast/pull/805) and [PR #818](https://github.com/the-sarge/quic-go-fast/pull/818).

**Dispatch context budget:** No fork dispatch unless 4.G5 fails. Then the fork brief carries the sanitized gate result, the release rule (off by default; revert or default flip, the fork's choice) and the seams above: about 15,000 tokens.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** The fork's ownership-taking `SendDatagram` and release-callback APIs. **Revisit if:** "a Linux Datagram certification misses its floor with the sender's CPU as the measured bound."
- **Rejected alternative (do not do this):** The gluing issue's original owned-host gate. A shape-cell A/B "replaces #743's owned-host gate", because owned Linux hardware is ruled out ([Get representative Linux hardware for multi-Gbit/s measurement](https://github.com/GridSwarm/wiremux/issues/1799#issuecomment-6063540031)). **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Holding the release for gluing. **Revisit if:** none: rejected on merit ("They never hold the release").

**Public-brief constraints:** The consumer comment on the gluing issue follows the public decision comment already there: no wiremux links, evidence paths, host, session or GARM names, no "slice A" or "slice B" as consumer work, no "Wire" (say "connection closures"), and GridCast only as "a downstream consumer that sends fixed-size DATAGRAMs … about 1,100 bytes". Cells: the `netns` sentence; "a consumer-like heap (a 64 MiB pointer-free ballast on both peers), with the default-GC row reported"; "the consumer's send changes are in, plus the two deeper receive queues"; "a 1,099-byte payload row".

**Slice decision audit:** The lone-packet fix and gluing are one slice because safeguard 4 requires the lone-packet fix first. Holding the release for them is rejected. Release-level edges F1 → F10 and F5 → F10 are necessary: without the deeper queues gluing brings back 1.6–2.7% silent Datagram loss.

**Stop conditions:** A 4.G5 failure → the release ships gluing off by default and gluing returns to the map as a diagnosis issue (the fork chooses the mechanism). On 2026-10-21 4.G5 passed under the owner's reading instead (above). A fork release cut from `main` with gluing on and without F5 → wiremux does not adopt it. The fork has not confirmed that the Windows-lane segment-limit test ran, not skipped, on a USO-capable runner for `9b52dca8` → the Tests row is recorded as not run, and the gate does not pass until the fork confirms it. On 2026-10-21 the fork had not replied; the 4.G5 record read the row from the fork's CI, where that test ran and passed, and the owner accepted the result on that record (see [Task 4.G5](#task-4g5--equal-size-gluing-gate-on-the-bundle-candidate-f10)).

### Fork slice F11 — Windows copy-at-read, the missing-record guard and slab retirement

**What it delivers:** The fork's Windows reader copies each datagram of a coalesced (URO) read into an ordinary packet buffer as it splits the read, covering the managed reader too; a read longer than the fork's largest packet that carries no segment-size record turns URO off for that socket, is counted once and is dropped; and the coalesced slab and ADR 0005's atomic exception, then without a producer, are retired.

**Decided fork behaviour** ([Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572) sections 3 and 4):

> - copy-at-read in the Windows reader: the probe's `-wcr`, the Windows counterpart of slice 3's Linux copy-at-read, reusing its copy path;
> - the guard;
> - retirement of the coalesced slab and ADR 0005's atomic exception […], which then have no producer. That is the condition the Linux decision named for retiring them.

> - **Trigger:** a read longer than the fork's largest packet (`MaxPacketBufferSize`, 1,452 bytes […]) that carries no segment-size record.
> - **Action:** URO is turned off for that socket's life, the event is counted once, and the read is dropped. The count is internal; wiremux reads it the way it reads the fork's other counts.
> - Reads with the record, and reads of at most 1,452 bytes, are unchanged.

> **Versions:** no allowlist. The fork's `UDP_RECV_MAX_COALESCED_SIZE` call is itself the probe: a Windows build without URO refuses it and runs as today […]. `QUIC_GO_DISABLE_GRO` still turns it off.

The [Windows corrections](https://github.com/GridSwarm/wiremux/issues/1871#issuecomment-6259142960), verbatim: "The probe's copy-at-read covered only a reader with coalescing on (`c.cap.GRO`). A managed reader without coalescing still takes slab buffers ([`sys_conn_windows.go` L167] at `v0.62.1-fast.7`). Two consequences for the brief: Retiring the slab and ADR 0005's atomic exception requires covering that path too. Two managed-mode tests that assert slab views join the four to rewrite: `TestWindowsManagedReceiveHandback` and `TestWindowsManagedECNCoalescedMetadata`." The defect the guard answers is public: [Potential bug in GRO code for Windows?](https://github.com/quinn-rs/quinn/issues/2041) and [fix(udp): do not enable URO on Windows on ARM](https://github.com/quinn-rs/quinn/pull/2071).

**Existing-work disposition:** New slice, to be filed. The fork's closed W3 URO work ([W3: Windows coalesced receive (URO)](https://github.com/the-sarge/quic-go-fast/issues/233) and [its follow-up](https://github.com/the-sarge/quic-go-fast/issues/250)) built today's slab reader, which this slice replaces.

**Blocked by:** F3 (F1 met): "It never lands ahead of slice 1 (the 1,024-entry received-Datagram queue the Windows gains were measured with) or slice 3."

**Ordering and never-hold rules:** "So the eleventh slice **never holds the bundle**: if it isn't ready, the bundle ships without it and it goes in the next fork release. […] Accepted cost: if it slips, the slab lives one release longer and consumers repin once more, for Windows only." The wiremux switch (slice 5.4) is "its own PR, after wiremux adopts a fork release carrying the eleventh slice".

**Fork seams:** [`sys_conn_windows.go` L39–L54](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows.go#L39-L54) (`windowsConn`), [L133–L155](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows.go#L133-L155) (`enableURO`; `QUIC_GO_DISABLE_GRO` at L145), [L157–L209](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows.go#L157-L209) (`ReadPacket`: the buffer choice at [L166–L176](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows.go#L166-L176), where `c.cap.GRO || c.managed` takes a 64 KiB coalesced-tier buffer; `parseWindowsControlMessages` at L191 returns segment size 0 when the record is absent; `delivery.accept` at [L207](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows.go#L207)), [L214–L216](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows.go#L214-L216) (`releaseReadBuffers`); [`coalesced_delivery.go` L33–L35](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/coalesced_delivery.go#L33-L35) (the defect path: a long read without the record becomes one datagram); [`coalesced_slab.go`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/coalesced_slab.go) (the whole file); [`buffer_pool.go` L16–L24](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/buffer_pool.go#L16-L24) (`slab`, `retentionCharge`) and [L66–L70](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/buffer_pool.go#L66-L70); [`connection.go` L191–L193](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L191-L193) and the retention calls at [L2053–L2063](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2053-L2063) and [L2883–L2900](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/connection.go#L2883-L2900); [`internal/protocol/params.go` L45–L51](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/internal/protocol/params.go#L45-L51) (`MaxConnRetainedCoalescedBytes`); [`managed_packet_receive_windows.go` L45–L46](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/managed_packet_receive_windows.go#L45-L46) (managed mode enables URO itself); ADR 0005's [2026-09-11 amendment](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/docs/adr/0005-incoming-packet-lifetime.md?plain=1#L11). Tests that assert slab shape: [`sys_conn_windows_uro_test.go` L245](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows_uro_test.go#L245), [L318](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows_uro_test.go#L318), [L344](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows_uro_test.go#L344), [L431](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows_uro_test.go#L431); [`managed_packet_receive_windows_test.go` L161](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/managed_packet_receive_windows_test.go#L161); [`managed_packet_ecn_windows_test.go` L237](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/managed_packet_ecn_windows_test.go#L237).

**Required design guards:** (1) Copy-at-read covers every Windows path that hands a coalesced-tier buffer to a connection, the managed reader without URO included, so nothing slab-backed or coalesced-tier reaches a Windows connection. (2) Retirement scope follows the deletion test: everything that exists only for the slab goes (`coalescedSlab`, `coalescedDelivery`'s slab views, `retainForRetentionQueue` and the retention budget, `MaxConnRetainedCoalescedBytes`, the `packetBuffer.slab` and `retentionCharge` fields), and ADR 0005's 2026-09-11 amendment gets a dated note that the exception is retired; the fork issue records the scope it retired. (3) The guard's state is per socket ("for that socket's life"), its count is one per socket, and its trigger stays pinned to `MaxPacketBufferSize`. The count is readable from the connection through a versioned method on `Conn` that uses built-in types only (a `uint64`, found by interface assertion like `DatagramReceiveDropsV1`), or the fork names the object that carries it, so the consumer's per-connection readout can reach it; its name is the fork's call. (4) The slice changes the managed-mode reader, so the fork's managed-mode tests cover it, and slice 5.1's evidence record notes that upgraded Windows Wires' coalesced delivery changed. (5) It touches the receive path [BBRv3 port: one readiness and L6 campaign on the revision with #742, #800 and #803](https://github.com/the-sarge/quic-go-fast/issues/808)'s readiness run guards: schedule with that campaign ([H13](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)).

**Required fork-side tests** (verbatim, with the correction): "the full suite including race on the fork's Windows lane; the Windows URO tests with their four slab-shape assertions rewritten; guard tests: a long read without the record turns URO off for that socket, counts once and drops that read; reads with the record and short reads without it are unaffected; the cross-machine engagement test against a host peer." Plus `TestWindowsManagedReceiveHandback` and `TestWindowsManagedECNCoalescedMetadata` rewritten.

**Consumer acceptance gate:** verbatim from [Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572) section 5: "**Gate: the fork slice before its release, wiremux's switch on the adopted release.** **Method, both times:** a `winvm` A/B of coalescing on (with Windows copy-at-read) against off. At the pin, with the default-GC row alongside. Three runs per arm, in interleaved campaigns. Every native sender on a fixed port (`-lport`). The faster receive queue gates; the slower is reported."

| Line | Threshold |
| --- | --- |
| Stream throughput, pin | ≥ +5% |
| Stream throughput, default GC | no worse than −1% |
| Datagrams, 1,024 queue, pin | ≥ +5% |
| Receiver CPU per GiB, stream, whole guest | ≥ 10% lower |
| Received-Datagram discards (1,024 queue) | ≤ 0.1%, no higher than off |
| Rejected coalesced reads; guard trips | 0; 0 |
| Admission | a refused sender's coalesced reads refused whole on first contact **and** on an established connection; every admitted datagram reaches QUIC once |

"A +10% stream floor would fail this data, so it is not used." **Arm rows** (an Arm64 guest receiving from the macOS host): "coalescing engages (most bulk datagrams arrive in coalesced reads); zero rejected reads and zero guard trips; the admission rows; stream and Datagrams no worse than −1%; receiver CPU per GiB at least 10% lower." "There is no gain floor, since there is nothing yet to set one from. Failing Arm rows mean an x64-only grant and a diagnosis issue." Fork measurement framing: "section 5's rows for the slice against no coalescing (what Windows users have today) in the `winvm` cell. Today's slab reader runs beside it as a reported arm: copy-at-read was 1.6% slower than the slab reader on Datagrams at the pin without the 1,024 queue (unexplained)." **Who runs it:** Task 4.G6, after F11 merges on fork `main`, before the release; slice 5.4 repeats it on the adopted release.

**Owner decision (2026-10-22): F11 ships on both platforms.** Task 4.G6 passed every measured row on x64 and on Arm. Its Tests row was not met as written, and the Arm guest crashed once during a coalescing-on run ([record](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345139618); see [Task 4.G6](#task-4g6--windows-copy-at-read-gate-f11)). [The owner decision](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345797171), verbatim:

> "Pass both platforms: accept the Tests row as run, the Arm CPU row on the receiving process, and the Arm guest crash; F11 ships, slice 5.4 grants x64 and Arm64."

What it means for the gate, as [the decision comment](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345797171) states it:

- **Tests row:** accepted as run for `0dae7d44`. The fork's CI ran the full Windows suite without race, and race on the Windows reader tests only (`^TestWindows(URO|USOURO|Managed|External)`), all passing. It skipped the cross-machine engagement test, which passed 3/3 on both guests downstream.
- **Arm "receiver CPU per GiB at least 10% lower":** judged on the receiving process (`streampin` −26.84%, `dgrampin` −34.57%), as the Arm protocol stated before measuring. The whole-guest figure (stream −9.43% at the pin) is reported, not judged.
- **The Arm guest crash is accepted:** bugcheck `0xD1` in VMware's `vmxnet3.sys` 1.9.20.0, 1 in 48 coalescing-on runs and 0 in 32 off ([addendum](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345691209)). It is tracked as the watch item [#1988](https://github.com/GridSwarm/wiremux/issues/1988) for slice 5.4's rerun on the adopted release.

**Single owner after merge:** The Windows reader owns its read buffer, the copy and the per-socket guard state; Windows connections receive only ordinary-tier buffers; no slab exists.

**Authority completeness:** The guard's "URO off" is a new per-socket fact with one writer (the reader) and no reversal; the count is read-only. No persistence.

**Transitional-seam budget:** Removes the slab, the retention budget and ADR 0005's exception (the seams F3 left for Windows). None added.

**Blast radius:** Removes the slab producer and its atomic reference count, the retention budget and the copy under the receive lock for Windows; adds one copy per datagram and the guard. Reaches upgraded Windows Wires at the repin through managed mode, where the guard protects them too. On a defective host the guard costs one read, which QUIC resends. Task 4.G6 recorded one Arm guest kernel crash in VMware's virtual NIC driver during a coalescing-on run (1 in 48, 0 in 32 off), which the owner accepted and [#1988](https://github.com/GridSwarm/wiremux/issues/1988) watches (**measured**, [addendum](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345691209)). Accepted gap ([Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572)): an interface with weak-host receive enabled. Untraced, flagged: Linux and Darwin `readManagedPacket` still hand out a 64 KiB coalesced-tier buffer per datagram without a slab ([`sys_conn_oob.go` L263–L280](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L263-L280)); retiring the slab does not change them (F5's memory guard covers their queue cost). If F5 kept the 256 bound for managed connections, F11 makes the Windows managed reader queue ordinary buffers, so the fork may lift that exception for Windows; Linux and Darwin managed readers keep it.

**Artifact classification:** Copy-at-read is shipped behaviour; the guard is required safety enforcement; the slab retirement removes code; the rewritten tests are verification aids.

**Representation contract:** Domain: Windows reads with URO on or off, managed or not, with or without the segment-size record, at most or more than 1,452 bytes. Owner: `windowsConn.ReadPacket`. Guarantee: canonical over those classes (below), with example-level tests.

**Contract closure:** Triggered: wrong storage ownership corrupts data, and a missed guard trip loses every datagram in each read, read after read; the classes are independently reachable.

| Semantic class | Expected disposition | Enforcement owner | Evidence | Status |
| --- | --- | --- | --- | --- |
| URO on, record present | Split, each datagram copied, delivered once | `ReadPacket` | rewritten URO split test | Required |
| URO on, no record, read > 1,452 bytes | URO off for the socket, counted once, read dropped | guard | guard test | Required |
| URO on, no record, read ≤ 1,452 bytes | Delivered as one datagram, as today | `ReadPacket` | short-read guard test | Required |
| Managed, URO off | Ordinary-tier buffer, no coalesced-tier hand-off | `ReadPacket` | rewritten managed handback test | Required |
| Managed, URO on (managed ECN) | Copied like the unmanaged path, metadata kept | `ReadPacket` | rewritten managed ECN test | Required |
| Truncated or malformed metadata | Read rejected whole, reading continues | `ReadPacket` | existing rejection tests | Preserved |
| Reader stop | Nothing pending to release | `releaseReadBuffers` | release test | Required |

At most one guard mutation: removing the record check must fail the guard test.

**Evidence budget:** One case per row (seven), the four URO rewrites and two managed rewrites, the cross-machine engagement test and the suite with race on the Windows lane; the fork's review practice. Consumer measurement: Task 4.G6's budget.

**TDD and preservation evidence:** The guard test and the managed no-URO test fail on `main` first. The rewritten tests keep their names and assert ordinary-tier buffers instead of slab views.

**Dispatch context budget:** About 45,000 tokens. The fork brief carries the three contents, the guard's trigger and action, the managed-path correction, the retirement scope, the tests, the downstream gate in public phrasing (cell, rows, Arm rows), the public quinn references, the never-hold rule and the BBR-campaign note. The fork agent reads `sys_conn_windows.go`, `managed_packet_receive_windows.go`, `coalesced_delivery.go`, `coalesced_slab.go`, `buffer_pool.go`, the retention parts of `connection.go`, ADR 0005 and its amendment, F3's merged copy path and the six Windows tests.

**Rejected alternatives:**

- **Rejected alternative (do not do this):** Widening F3 to both readers. "Why a separate slice: slice 3 holds the bundle, and the Windows evidence needs two VM cells on shared hosts, one of them not built yet." **Revisit if:** none: rejected on merit.
- **Rejected alternative (do not do this):** Leaving Windows on Arm out. **Revisit if:** none: the owner put Arm in on its own rows.
- **Rejected alternative (do not do this):** An allowlist by Windows version. **Revisit if:** none: rejected on merit (the fork's URO call is itself the probe).
- **Rejected alternative (do not do this):** A +10% stream floor ("would fail this data"). **Revisit if:** none: rejected on merit.

**Public-brief constraints:** No host names, guest name or paths, infra config links, GARM, the rebuild recipe path, probe diff or tool names, GridCast's admission bar or wiremux links. Cell: the `winvm` sentence, with "4 pinned vCPUs, one emulated e1000e adapter, software URO and USO, Receive Buffers raised to 2,048, at MTU 1500, sender on a fixed port, the guest's two RSS receive queues reported separately"; Arm rows "a Windows 11 Arm64 VM under VMware Fusion receiving from its Apple-silicon macOS host". The quinn issue and pull request and Microsoft's URO and strong-host pages may be cited.

**Slice decision audit:** Splitting the guard from copy-at-read would ship a reader that still loses whole reads on defective hosts; splitting the retirement out would keep a dead slab one more release for no gain. Blocking edges are decided: F1 because the Windows gains were measured with it, F3 because F11 reuses its copy path.

**Stop conditions:** Covering the managed reader requires a change the decision didn't make (for example, a separate managed buffer tier) → stop for the operator. A 4.G6 failure on the x64 rows → F11 is left out of the release (the fork reverts it or leaves it unmerged) and returns to the map; failing Arm rows alone do not fail F11 (they mean an x64-only grant in slice 5.4 and a diagnosis issue). On 2026-10-22 4.G6 passed on both platforms under the owner's decision (above), so F11 ships and the grant is x64 and Arm64.

## Part B: Consumer gate tasks

Seven wiremux task issues, not architecture-handoff slice children. Each is dispatched by the operator to one fresh agent session. None changes wiremux `main`.

### Rules for every gate task

**Timing.** A gate task runs after the fork merge it names and before the bundle release is cut, so a failure can still keep its slice out of the release.

**Stock-sender arms.** Equal-size gluing (F10) is on by default on fork `main`, so every arm whose workload is the stock Datagram sender sets `QUIC_GO_DISABLE_SHORT_GSO_SEGMENTS=true` on both peers and records it in the arm's recipe: that non-gluing sender is the one the decided gates were calibrated on ([the 32-entry queue decision](https://github.com/GridSwarm/wiremux/issues/1850#issuecomment-6207580215), [the unprocessed-queue decision](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120)). Arms named for the faster GSO or gluing sender keep gluing on, and stream workloads keep stream GSO, which the switch does not touch.

**Builds.**

- Each task works in its own worktree and branch, created from the rig commit it measures with: `git worktree add -b codex/<task-slug> /Volumes/worktrees/wiremux/<task-slug> <rig commit>`, where the rig commit is `codex/native-gap-rig` at or after Task 4.R's last commit. `rig.sh` builds from that tree, and the record names the rig commit's SHA. Scratch changes stay unpushed on the task's branch; the only pushes to `codex/native-gap-rig` are Task 4.R's commits and Task 4.G6's Arm-cell driver and `windows/arm64` build commits (see Operating Discipline).
- Each fork arm is a `MODFILE`: a copy of `rig.mod` whose `replace` names the fork commit or a local fork copy. A local fork copy (the one-line changes below) is a throwaway tree exported from the fork commit or a worktree under `/Volumes/worktrees/quic-go-fast/<slug>`, never a commit on any fork branch and never pushed. Its diff is kept in the evidence directory.
- A wiremux scratch build (the coalescing grant, stand-ins, gate-build counters, and the additions to slice 3.1's seam that read a counter 3.1 does not read yet, per [H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)) is a local change on the task's branch, never pushed and never merged. Its diff is kept in the evidence directory.
- Every result names the wiremux commit merged into the rig, the rig commit, each arm's fork commit or copy diff, and the `MODFILE`.
- **Preflight for no-coalescing arms:** before the first counted run, check on the commit under test that the `QUIC_GO_DISABLE_GRO` return still precedes activation in the reader the slice rewrote (F3 and F11 rewrite them), so the arm still equals the permission withheld; if it does not, build that arm with the permission withheld instead.

**Protocol.** [PROTOCOL.md](https://github.com/GridSwarm/wiremux/blob/b47a253ae1b805396cb7d10173c33808d958774e/cmd/nativerig/PROTOCOL.md)'s A/B rule unless the task says otherwise: interleaved A, B, A, B campaigns at `REPS=3` (10 s runs), pooled medians, all four campaigns reported. Every arm runs at the pin (`-ballast 64 -gc-role both`) with the default-GC row reported beside it. Arm labels differ by more than case. Every run is reported; none is dropped or quietly re-run, except the documented `winvm` stuck state. Rows that read PTOs or spurious losses need 3.1's counting recorder on in both arms identically.

**Readings.** Decided lines are applied as written, with the readings the handoff recorded for words the deciding tickets left unquantified: [H22](2026-10-19-native-gap-handoff-audit.md#handoff-decisions) (F1's "zero queue drops at 1,024" = received-Datagram queue discards ≤ 0.01%, pooled) and [H26](2026-10-19-native-gap-handoff-audit.md#handoff-decisions): a counter "equals" or "accounts for" = agreement within one Datagram per run; "no new loss" = within 0.1 point; "minimum flat" = no rise beyond noise, the gap between the two base campaigns; an unquantified "no worse" fails only if both A/B pairs show it lower; "most" = more than half by count; a pooled share = total events ÷ total Datagrams. The owner's re-readings of 2026-10-20 (and their 2026-10-21 extension to F5's stock-Datagram latency) also apply, each only to the rows it names: F5's 4.G1 rows (in [Task 4.G1](#task-4g1--deeper-queues-gate-f1-and-f5)) and 4.G2's rows (in [Task 4.G2](#task-4g2--32-entry-send-queue-gate-f4)). So does the owner's 2026-10-21 reading of 4.G5's round-trip-time row (in [Task 4.G5](#task-4g5--equal-size-gluing-gate-on-the-bundle-candidate-f10)), and the owner's 2026-10-22 readings of 4.G6's Tests row and Arm CPU row (in [Task 4.G6](#task-4g6--windows-copy-at-read-gate-f11)). No other reading is made.

**Host rules.**

- **minimax `netns`:** set `GATE` to a per-run check that no other `nativerig` is running (several sessions measure there and the cell's port is shared), and use a non-default `PORT`. The namespaces stay as they are set up. minimax is a live fleet host.
- **`tb` (mbp128 sending to m4mini):** claim the pair for the campaign, set `LOADGATE=1`, announce CPU-heavy mbp128 work to any session holding the `tb` pair and queue behind it. mbp128 also hosts GARM Tart VMs; `LOADGATE` and `GATE` are how a campaign accounts for them. No profiles inside a gate campaign.
- **`winvm` (minimax):** each rebuild needs the owner's OK. Every run is gated as `REBUILD.txt` step 8 says, through `busy1869.sh` (`native-gap-evidence/1869-windows-uro/scripts/`): the guest's busy share at most 6% outside interrupt time, no other libvirt guest (which includes GARM guests on minimax), no foreign heavy process. The guest adapter's Receive Buffers are 2,048, and each receive queue has its fixed sender port.
- **The Arm cell (mbp128):** each build needs the owner's OK. mbp128 always hosts GARM Tart VMs, so the minimax rule cannot apply: every run uses `LOADGATE=1` plus a `GATE` that checks the guest's busy share (at most 6% outside interrupt time) and records the running Tart VM count in the run directory. mbp128's pair-claim etiquette applies.
- **Both guests** are deleted when the task ends, and the record says so.
- **Wait ceiling:** a campaign that waits more than 4 hours on its gates in total is stopped and counts as its set's one replacement (a ceiling this plan sets).
- **GARM is read-only:** never mutate pools, runners, the service or its configuration.
- **Timing:** coordinate with the owner only for a run that needs exclusive access to a host.

**Artifact classification and the template's other fields.**

- **Rig-branch commits** (Task 4.R's and Task 4.G6's setup commits) are an approved blocking verification aid. Payoff: the decided consumer gates and [Decide what closing the gap means on each platform](https://github.com/GridSwarm/wiremux/issues/1801#issuecomment-6252143797) section 5 ("The rig gains RTT, PTO and spurious-loss readouts before those gates run"). Domain: Tasks 4.G1–4.G6 and certification slices 7.1–7.3. Owner: this program. Retirement: with the program; the rig is never merged ([Preserve the native measurement rig and fix one measurement protocol](https://github.com/GridSwarm/wiremux/issues/1795)).
- **Local fork copies and wiremux scratch builds** are throwaway verification aids, kept only as diffs in the evidence directory.
- **Records, evidence directories and public comments** are process metadata, consumed by slice 5.1.
- **Representation contract:** the rig's result lines and `summarize.py`'s pooled medians own every gate row's representation; PROTOCOL.md names each readout and its unit. Guarantee: example-level.
- **Single owner after merge, authority completeness, transitional-seam budget, contract closure, TDD:** not applicable (no pull request against `main`, no durable fact).

**Outputs.**

1. **Evidence directory** `/Volumes/worktrees/wiremux/native-gap-evidence/<task issue number>-<slug>/`: every `OUTDIR`, `meta.txt` and `summary.txt`, the `MODFILE`s, the fork-copy and scratch diffs, and any protocol written before measurement.
2. **The record** (what slice 5.1's dependency evidence record links): a resolution comment on the task issue with each threshold row's verdict and pooled medians, the four campaigns, the commits, `meta.txt` and `summary.txt` pasted, the evidence path, and any stopped campaign with its cause.
3. **Public result comments** on the fork slice issue(s) and on the bundle-release issue: the header line `> *This was generated by AI from a downstream consumer's planning.*`, the downstream consumer's voice, the public cell phrasing, each row's threshold and result with its **measured** or **derived** label, and the verdict. Before posting, a case-insensitive search of the text for the private terms in the public-brief rules returns nothing; the record notes the search.
4. The task's OmniFocus completion and tracker reconciliation. Gate tasks do not run `$append-dev-journal`; slice 5.1's journal entry records their results.

**Common stop conditions.**

- **A failing default-on gate:** post the record and both public comments and report to the operator. The fork slice is reverted or reworked before release, as the operator decides under the [bundle release rules](#bundle-release-rules) (F5's reworks of 2026-10-20 and 2026-10-21 are such decisions), or, for a never-hold slice, left out of the bundle (F10: off by default). The gate task never reverts, commits, pushes, labels or edits anything in the fork beyond its two comments.
- **A readout fault** (a missing readout, counters that disagree beyond the recorded readings) → stop before posting, diagnose and report; a row whose words have no recorded reading → stop and report. Never reinterpret a threshold beyond the readings above.
- **A campaign stopped by `GATE`, the wait ceiling or a host fault** → report it; at most one replacement campaign per A/B set; a second stop ends the task for the operator.
- **The fork commit under test differs from the decided behaviour** → stop before measuring.
- **A carried slice is reverted or reworked** after this task measured a candidate carrying it → the result is void; report it, and the operator re-dispatches the task.

### Task 4.R — Prepare the rig for the bundle gates

**Purpose:** Give the rig every readout, arm, build recipe and protocol text the gate tasks need, on the rig branch only, before any gate runs: "The rig gains RTT, PTO and spurious-loss readouts before those gates run."

**Blocked by:** Slice 3.1 (merged on wiremux `main`).

**What it delivers** (commits on the task's branch, pushed to `codex/native-gap-rig` as a fast-forward with `git push origin codex/<task-slug>:codex/native-gap-rig`; the rig is never merged):

1. Merge wiremux `main` (carrying 3.1) into the rig branch. `rig.mod` follows `main`'s `go.mod` requirements and keeps its `replace` at `v0.62.1-fast.7`.
2. Readouts through 3.1's seam, per native run and per peer, in the result lines and `summarize.py`: `MinRTT` and `SmoothedRTT` at the end of each run; the mean of RTT samples over the send window (the "mean RTT under load" of F8's and F10's rows, as the [batch-cap research](../research/issue-1862-batch-cap.md) measured it), computed from the deltas of slice 3.1's counting-recorder RTT-sample sum and count; PTO count updates and spurious losses from the same recorder; both of 3.1's `Readout` counts, `DatagramReceiveDrops` and `UnprocessedDrops`, each shown as absent when the fork offers no method; stream packets per second from `PacketsReceived`. A count 3.1's seam does not read yet (F5's count if the fork had not named it by 3.1's preflight, F11's guard-trip count, the gate-build counters) is read through a never-merged scratch addition to the seam in the gate task that needs it ([H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)), not here.
3. Per-arm environment: fork environment variables (kill switches such as `QUIC_GO_DISABLE_SHORT_GSO_SEGMENTS`, `QUIC_GO_DISABLE_GRO`, F9's switch, `QUIC_GO_DISABLE_RECVMSG_X`) set per arm on a named peer or both, recorded in `meta.txt` and each result line, and passed through the guest agent for `winvm`. The fork reads them at socket or connection setup, so setting them before endpoint creation suffices.
4. The mixed stream-and-Datagram arm: one Wire carrying a stream and Datagrams at once, with the mix (Datagram size and offered rate or share, stream write size) as arm parameters, reporting each kind's delivered rate, loss and CPU per GiB. The default mix is stated in PROTOCOL.md before any gate measures with it ("The slice states the mix before measuring").
5. A PROTOCOL.md section "Bundle gate builds" with three recipes: (a) the packer-discard counter for the gluing gate build, a local fork copy adding an atomic count at the discard branch [`packet_packer.go` L684–L689](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/packet_packer.go#L684-L689), read through a never-merged scratch addition to 3.1's seam ([H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)), and never in a fork release; (b) the old-depth and cap-8 local fork copies, each the slice commit with one constant changed (Task 4.G1's third run on `2a83ed29` uses two-change copies instead, as it states) (F1's depth back to 128 at [`datagram_queue.go` L15](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/datagram_queue.go#L15), F5's post-confirmation depth back to 256, F8's cap back to 8); (c) the coalescing-grant scratch build, the rig worktree plus the one-line grant at [`internal/nativequic/endpoint.go` L222](https://github.com/GridSwarm/wiremux/blob/467fc5552312847cb0fc97dd346df18857f7d9e1/internal/nativequic/endpoint.go#L222) (Linux for 4.G4 and 4.G5, Windows for 4.G6), never merged.
6. PROTOCOL.md text for certification campaigns, as [H17](2026-10-19-native-gap-handoff-audit.md#handoff-decisions) decides them: one PROTOCOL.md headline campaign (`REPS=5`, 10 s, its warm-up rotation recorded and excluded from the statistics) on the platform's cell with every adopted lever; a floor is met when the median meets it; on a miss, one more headline campaign is run and pooled; a pooled miss files a diagnosis issue, records the miss and reverts nothing. And the `winvm` exception to "Every run is reported, and none is ever dropped or quietly re-run", from [Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572) section 8: "a run below about 60k packets/s with a growing round trip is the stuck state and is rerun, not counted". The stuck run is still reported.

**Cells:** smoke runs on `netns` and `tb` only. **Arms:** none. **Thresholds:** none; smoke runs are never evidence.

**Host rules and outputs:** the common rules. Outputs are the rig commits, the PROTOCOL.md sections, the smoke `OUTDIR`s in the evidence directory and a resolution comment listing the commits, readout names and units, the recipes and the stated mix. No public fork comment: nothing is measured.

**Artifact classification and representation:** The rig-branch commits are the approved blocking verification aid of the common classification block; the representation contract is that block's (here, the smoke run shows each readout present and plausible).

**Evidence budget:** `WIREMUX_TEST_NATIVE=required go test -race -modfile=cmd/nativerig/rig.mod ./cmd/nativerig` on macOS and Linux; one smoke campaign (`REPS=2 SECS=5`) per cell covering every new readout, the mixed arm and one per-arm environment variable; at most one re-smoke after a fix. No measurement campaign.

**Dispatch context budget:** About 40,000 input tokens: this plan's common rules and this task; slice 3.1's plan section and merged seam; PROTOCOL.md, `rig.sh`, `main.go`, `summarize.py` and `winqga.py` (the guest-agent path for per-arm environment); the fork's `ConnectionStats`, the qlog PTO and spurious-loss events and the counter methods.

**Stop conditions:** A change is needed on wiremux `main` → stop (it belongs to Track 3). Merging `main` into the rig conflicts beyond `rig.mod` → stop.

### Task 4.G1 — Deeper queues gate (F1 and F5)

**Purpose:** The consumer gates of F1 ([How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507)) and F5 ([Should native connections get a deeper unprocessed-packet queue than the fork's 256 packets?](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120)), including the `netns` gate F1 owed (met on 2026-10-21).

**Blocked by:** Task 4.R; F5 merged on fork `main` (F1 is merged). For the re-gate: the changed F5 (re-decided 2026-10-20) merged on fork `main`. For the third run: the final F5 (every depth, 2026-10-21) merged on fork `main` (met: `2a83ed29`).

**Status (2026-10-20).** The first run measured F5 as merged (`c3fb3c45`): F1 passed and F5 failed its rows as written ([record on the task issue](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6301169094)). The owner re-decided F5 ([decision](https://github.com/GridSwarm/wiremux/issues/1970#issuecomment-6303592965), quoted under [F5](#fork-slice-f5--1024-packet-unprocessed-packet-queue-after-handshake-confirmation)). Both sets are void, because their arms carried the reworked F5. The task re-gates on the changed F5's merge commit: the F5 set in both cells under the re-read rows below, and the F1 set on `netns` again.

**Status (2026-10-21).** The re-gate on `5f73ddc4` ([record](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6309306109)): F1 passed again; F5 failed one row, the `netns` received-Datagram discards at the pin (540 → 2,384), and every other judged F5 row passed (`tb` not engaged). The owner extended the condition to every depth (quoted under F5), and the fork merged it as `2a83ed29`. Both sets are void again. The task runs a third time on `2a83ed29`: the F5 set in both cells under the same re-read rows, and the F1 set on `netns`, with the arms below.

**Result (2026-10-21).** The third run on `2a83ed29` ([record](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6323180440)) passed every row but one as written. F1 passed both rows (2 discards in 35.7 M at 1,024; the counter within one Datagram in all 16 runs). F5's `netns` discard row passed (3,224 → 2). The one failure was the `netns` stock-Datagram lifetime minimum RTT: 11.4 → 12.3 µs against 0.6 µs of noise, while the same workload's smoothed RTT fell 12 µs. `tb` did not engage. The owner extended the stream-latency re-reading to the Datagram workload (below), and under it every row passes, so Task 4.G1 passes ([resolution](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6323452830)).

**Cells:** `netns` (F1 and F5 rows) and `tb` (F5 rows).

**Build:** Unless slice 3.1's seam on wiremux `main` already reads F5's drop count (the fork named it before 3.1's preflight), the task reads it through a scratch wiremux build on its branch that adds the count to 3.1's seam by interface assertion, never merged ([H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)); its diff is kept in the evidence directory. The packer residual of the F1 row comes from 4.R's packer-discard gate build through the same kind of scratch addition.

**Arms** (two-build; both counts readable in every arm):

- **F5 set, both cells:** B is F5's merge commit; A is a local one-line copy of B with the post-confirmation depth back to 256. Workloads: the stock Datagram sender and the native stream.
  - **Third run (on `2a83ed29`):** a one-line copy no longer gives the base behaviour, because at 256 the every-depth DATAGRAM condition stays active and A would carry part of F5. A is a local copy of `2a83ed29` with the post-confirmation depth back to 256 **and** the DATAGRAM disjunct removed from `handlePacket`: the parent's admission rule with F5's drop counter. Both changes go in the fork-copy diff.
- **F1 set, `netns`:** B is F5's merge commit (the 1,024-entry queue); A is a local one-line copy of B with `maxDatagramRcvQueueLen = 128`. Workload: the faster GSO sender, the rig's native `dgram` sender with F10's gluing on (the fork default).
  - **Third run (on `2a83ed29`):** with the condition at every depth, the one-line 128 copy changes two things at once: the received-Datagram queue's depth and the admission bound, which falls to 128. Queued packets plus queued Datagrams then stay below 128, so the 128 queue overflows only through the residual dequeue-to-push window, and the counter check would rest on a handful of discards (a smoke run of it discarded 12 Datagrams, against 17,268 for the copy below; **measured**, one 5 s run each at the pin, not evidence). A is B with `maxDatagramRcvQueueLen = 128` **and** the `handlePacket` condition's bound kept at the literal 1,024, so the arms differ only in the received-Datagram queue's depth. Both changes go in the fork-copy diff; the two checks read as before.
  - **Third-run copies and recipe (b):** both third-run A arms are two-change copies. They override Task 4.R's recipe (b) and its PROTOCOL.md preflight ("`git -C "$C" diff --stat` shows exactly one changed line") for this run only: the preflight instead checks that each copy's diff is exactly its two named changes, and the record keeps the full diff. The F5 B and F1 B builds are unchanged.

**Thresholds** (verbatim). F1: "Gate: an A/B in the minimax `netns` cell with the faster GSO sender shows zero queue drops at 1,024, and the counter accounts for the 128-entry build's queue loss." Read per [H22](2026-10-19-native-gap-handoff-audit.md#handoff-decisions) and [H26](2026-10-19-native-gap-handoff-audit.md#handoff-decisions): queue discards at 1,024 at or below 0.01% of Datagrams, pooled as total discards ÷ total Datagrams; and the counter within one Datagram per run of the derived queue loss ("sent − received − unprocessed-queue drops − packer residual", the fork's own formula). F5:

| Row | Threshold |
| --- | --- |
| Fork tests | the limit is 256 until the handshake is confirmed and 1,024 after, on both client and server; the counter counts every drop at either depth; the fork's test suite passes. |
| `netns`, stock Datagram sender | unprocessed-packet drops, read by the new counter, at least halved; delivered throughput no worse than −1%. |
| `netns`, native stream | no worse than −1%. |
| Thunderbolt pair, stock Datagram sender and stream | no slower. Base campaigns there have differed by 8.6%, so this fails only if both A/B pairs show the change lower. |
| Both cells | no new packet loss (within 0.1 point), and no rise in received-Datagram queue discards. That row guards against the loss moving behind the acknowledgement (see Why). |
| Minimum RTT | no rise beyond noise. Noise is the gap between the two base campaigns. |
| Smoothed RTT | it may rise, by no more than 768 extra packets' wait at the base run's packet rate: about 1 ms for the `netns` stream and 2 ms for stock Datagrams (**derived**). The RTT readout is the one #1850's gate adds to the rig. |
| No GSO-pair gain row | The +15% is re-measured on real code by [Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825), the only sender that needs it. |

The smoothed-RTT bound is computed per cell and workload from the A arm's pooled packet rate (768 ÷ rate) and stated in the record. The fork-tests row is read from the fork's CI for F5's merge commit.

**Re-read F5 rows (owner decision, 2026-10-20).** The F5 rows above are judged as [the owner decision](https://github.com/GridSwarm/wiremux/issues/1970#issuecomment-6303592965) re-reads them, verbatim:

> - "Unprocessed drops at least halved" is judged at default GC, where the depth engages. No tested depth halves the drops at the pin.
> - Stream latency is judged on the smoothed-RTT bound, not the lifetime minimum RTT, which measures the floor of the same queueing under load.
> - A row is judged only in a cell where the change engages: A's unprocessed drops above zero. On `tb`, where the depth never engaged, the minimum-RTT reading is not judged.

**Extension (owner decision, 2026-10-21).** After the third run, [the owner](https://github.com/GridSwarm/wiremux/issues/1937#issuecomment-6323452830) extended the second re-reading, verbatim:

> **Owner decision, 2026-10-21 14:25 EDT:** "extend the re-reading to the Datagram workload".

In the record:

- the `netns` stock-Datagram row's "unprocessed-packet drops […] at least halved" clause is judged on the default-GC row, with the pin's drops reported beside it; its throughput clause is judged at the pin as written;
- the stream's lifetime minimum RTT is reported, not judged, and its latency is judged on the smoothed-RTT row; since 2026-10-21 the same holds for the stock Datagram workload;
- an F5 row in a cell where A's unprocessed drops are zero is reported as "not engaged", not judged, and the record states A's unprocessed drops for each cell and workload.

The fork-tests row also covers the re-decided condition's unit test (see F5's required fork-side tests). F1's thresholds and readings are unchanged.

**Host rules:** the common `netns` and `tb` rules.

**Outputs:** the common outputs; public comments on [Deepen the received-DATAGRAM queue and make its discards visible before a release ships #743 on by default](https://github.com/the-sarge/quic-go-fast/issues/824), F5's issue and the release issue.

**Evidence budget:** Three A/B sets (F5 on `netns`, F5 on `tb`, F1 on `netns`): 12 campaigns at `REPS=3`, at most one replacement campaign per set. The re-gate on the changed F5 has the same budget again, and so does the third run on `2a83ed29`.

**Dispatch context budget:** About 40,000 input tokens: the common rules, this task, the F1 and F5 sections, PROTOCOL.md with 4.R's sections, slice 3.1's seam source, and the fork's two count methods.

**Stop conditions:** The common ones, plus: (1) pooled queue discards at 1,024 above 0.01% of Datagrams fail the F1 row, which takes the common failed-gate path (record, public comments, report); (2) any 128-arm run whose counter differs from the derived queue loss by more than one Datagram is a readout fault: stop before posting and diagnose; (3) the 128 arm shows no queue loss at all → the sender is not the faster one; stop.

### Task 4.G2 — 32-entry send queue gate (F4)

**Purpose:** F4's consumer gate ([Should the fork raise its packet send queue from 8 to 32 entries?](https://github.com/GridSwarm/wiremux/issues/1850#issuecomment-6207580215)).

**Blocked by:** Task 4.R; F4 merged on fork `main`.

**Cells:** `netns` and `tb`.

**Arms** (two-build): A is the commit F4 lands on; B is F4's merge commit. F1's counter is in both, so no fork copy is needed. Workloads: on `netns`, the stock Datagram sender and the native stream; on `tb`, the stock Datagram sender and the stream.

**Thresholds** (verbatim):

| Row | Threshold |
| --- | --- |
| `netns`, stock Datagram sender | delivered throughput at least 3% higher (about 7% expected). |
| `netns`, native stream | no worse than −1%. |
| Thunderbolt pair, stock Datagram sender and stream | no slower. Base campaigns there have differed by 8.6%, so this fails only if both A/B pairs show the change lower. |
| Both cells | no new packet loss (within 0.1 point) and no rise in received-Datagram queue discards. |
| Minimum RTT | no rise beyond noise. Noise is the gap between the two base campaigns. |
| Smoothed RTT | it may rise, by no more than 24 entries' worth of wait at the base run's send rate (about 60 µs in `netns` and 180 µs on Thunderbolt for stock Datagrams, derived). A larger rise means something other than queue depth is at work. |
| `netns` sender CPU per GiB | no more than 5% above base. BBR's own 32-entry queue cost 5% more Datagram sender CPU on its S5 cell and was kept by owner decision. #1845 measured 4.5% *less* on the default controller. |
| The fork's test suite | passes. |
| The rig gets an RTT readout | which it doesn't have today: `MinRTT` and `SmoothedRTT` from the fork's `Conn.ConnectionStats()` at the end of each run. |

The record states the smoothed-RTT bound computed from the A arm's send rate, and the macOS send shape wiremux `main` has when the gate runs (one packet per send call: the batched send, slice 6.3, needs the adopted release).

**Amended readings (owner decision, 2026-10-20).** The rows above are read as [the owner decision](https://github.com/GridSwarm/wiremux/issues/1938#issuecomment-6306221100) amends them, verbatim:

> 1. **Received-Datagram discards:** pass when application loss does not rise and discards are at most 0.01% of Datagrams.
> 2. **Minimum RTT, every cell:** judged on the smoothed-RTT bound instead of the lifetime minimum.
> 3. **Smoothed RTT:** a rise within the bound plus the readout's 1 µs resolution passes.
>
> - **Accepted in writing:** the `tb` stream is about −2% as an interim macOS cost until slice 6.3.

**Result (2026-10-20).** The task ran on F4's merge `48db9bc6` against `b7bee44d` ([record](https://github.com/GridSwarm/wiremux/issues/1938#issuecomment-6303532449)). Six rows failed as written; [the diagnosis](https://github.com/GridSwarm/wiremux/issues/1972#issuecomment-6304069857) traced them. Under the amended readings, every row passes or is accepted:

- **`netns` received-Datagram discards** pass under reading 1: application loss fell from 0.0138% to 0.0111%, and discards were 0.0016% of Datagrams.
- **Minimum RTT,** on `netns` stock Datagrams and on both `tb` workloads, is judged on the smoothed-RTT row under reading 2. The `tb` smoothed-RTT rows pass as written (stock Datagrams +170 µs against 194.7 µs; stream +182 µs against 186.7 µs), and the `netns` one passes under reading 3.
- **`netns` stock-Datagram smoothed RTT** passes under reading 3: +50.5 µs against a 49.7 µs bound plus 1 µs.
- **The `tb` stream** was lower in both A/B pairs (−4.66% and −0.94%; about −2% over the diagnosis's eight pairs). It is accepted as the interim macOS cost until slice 6.3, whose gate adds the depth arm ([Slice 6.3](2026-10-19-macos-native-stack-plan.md#slice-63--one-sendmsg_x-per-send-group-on-connected-macos-sockets)).

Every 4.G2 row is recorded as passed or accepted, which meets the release's 4.G2 prerequisite without another run. F4 stays a holding slice the release must carry.

**Host rules:** the common `netns` and `tb` rules.

**Outputs:** the common outputs; public comments on F4's issue and the release issue.

**Evidence budget:** Two A/B sets: 8 campaigns at `REPS=3`, at most one replacement per set.

**Dispatch context budget:** About 35,000 input tokens: the common rules, this task, the F4 section and PROTOCOL.md with 4.R's sections.

**Stop conditions:** The common ones, plus: F4's commit raises the batch cap with the depth → stop before measuring (it would measure F8).

### Task 4.G3 — Batch cap ship gate (F8)

**Purpose:** F8's ship gate ([Should the fork's send batch cap follow its 32-entry send queue?](https://github.com/GridSwarm/wiremux/issues/1864#issuecomment-6240753010) section 2). The speed confirmation is not this task; it is the cap-8 arm in slice 6.4's gate.

**Blocked by:** Task 4.R; F8 merged on fork `main`; the final F5 (re-decided 2026-10-20, every depth 2026-10-21) merged on fork `main` (met: `2a83ed29`).

**Cells:** `tb` and `netns`.

**Arms** (two-build): B is F8's merge commit. When F8 lands directly on F4's commit, A is that commit, "the queue slice's commit" exactly. When other commits land between them, A is a local one-line copy of B with the cap set back to 8, so the arms differ only by the cap; the record names the intervening commits. Workloads: on `tb`, Datagrams at the pin and the stream; on `netns`, every workload (stock Datagram sender and stream).

**After F5's re-decision (2026-10-20).** The task measures a candidate carrying the changed F5 ([the owner decision](https://github.com/GridSwarm/wiremux/issues/1970#issuecomment-6303592965)). F8's merge commit carries F5 as first merged, so B is a fork `main` commit carrying F8 and the final F5 (`2a83ed29` or later), named by SHA, and A is a local one-line copy of that commit with the cap set back to 8, so the arms still differ only by the cap.

**Thresholds** (verbatim):

| Row | Threshold |
| --- | --- |
| `tb`, Datagrams at the pin and the stream | no slower. It fails only if both A/B pairs show cap 32 lower, the 32-entry queue's own rule, because `tb`'s sender-bound runs drift 7–16% between campaigns. This row matters most: when the bundle ships, wiremux on macOS still sends one packet per call, and every research arm had batched sends, so it is the first measurement of cap 32 on that shape. |
| `netns`, every workload | no worse than −1%, and CPU per GiB within 2% on both peers. |
| Minimum RTT | no rise beyond noise (the gap between the two base campaigns). |
| Mean RTT under load | a rise of no more than 100 µs on `tb` and 40 µs in `netns`. |
| Loss | no more than 0.1 point above base, no rise in the bundle's received-Datagram queue discards, and no more PTOs than base. |
| The fork's test suite passes | its own macOS batched-send tests with 32-packet groups among them. |

"A failure means the bundle ships without the cap, and the cap comes back to the map." The gate runs "through wiremux's rig as wiremux's `main` stands then"; the record states that shape. Mean RTT under load is 4.R's mean of RTT samples; PTOs need the counting recorder in both arms.

**Result (2026-10-21).** The task ran on B = fork `main` `71581cfc` (F8's merge `0b0f77b0` and the final F5 `2a83ed29` among its ancestors) against A = a one-line local copy of it at cap 8, on wiremux's one-packet-per-call send shape ([record](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6329860799)). Five rows failed as written:

- `netns` stock-Datagram receiver CPU per GiB: +2.46% (limit 2%);
- stock-Datagram minimum RTT: `netns` +0.9 µs against 0.4 µs noise, `tb` +30.0 µs against 25.7 µs noise;
- `tb` mean RTT under load: +101.8 µs for Datagrams and +274.4 µs for the stream (limit 100 µs).

Every other row passed: `tb` no slower (Datagrams +2.31% pooled, stream +3.47%), `netns` −1% (Datagrams +2.58%, stream −0.90%), sender CPU per GiB and the stream's receiver CPU, `netns` mean RTT (+9.6 µs and −2.2 µs against 40 µs), loss, received-Datagram discards, PTOs (0 in every run) and the fork's tests (17 of 17 on `71581cfc`).

**Owner decision (2026-10-21).** The owner kept F8 at cap 32 and accepted the five failed rows in writing until slice 6.3's batched send ([decision](https://github.com/GridSwarm/wiremux/issues/1939#issuecomment-6330277355), quoted in full under [F8](#fork-slice-f8--send-batch-cap-follows-the-queue-depth)). Under it F8 is accepted and ships at cap 32, and 4.G3's release condition is met. No gate is voided, because F8 is not reverted or reworked. F8's check on the batched macOS shape is slice 6.4's cap-8 arm, which gains a mean-RTT-under-load row ([Slice 6.4](2026-10-19-macos-native-stack-plan.md#slice-64--recvmsg_x-into-the-forks-eight-read-slots-on-the-connected-socket)).

**Host rules:** the common `netns` and `tb` rules.

**Outputs:** the common outputs; public comments on F8's issue and the release issue.

**Evidence budget:** Two A/B sets: 8 campaigns at `REPS=3`, at most one replacement per set.

**Dispatch context budget:** About 35,000 input tokens: the common rules, this task, the F4 and F8 sections and PROTOCOL.md with 4.R's sections.

**Stop conditions:** The common ones. A failure is reported as "ships at cap 8"; the fork chooses how to keep F8 out of the release (on 2026-10-21 the owner accepted the failed rows instead, above).

### Task 4.G4 — Linux copy-at-read gate (F3)

**Purpose:** F3's fork-half consumer gate ([Should native receives adopt coalescing once the fork copies coalesced datagrams at read time?](https://github.com/GridSwarm/wiremux/issues/1835#issuecomment-6196268143)).

**Blocked by:** Task 4.R; F3 merged on fork `main`.

**Cell:** `netns`.

**Build:** The Linux coalescing-grant scratch build (4.R's recipe), since wiremux withholds coalescing until slice 5.3.

**Arms** (three): **C**, copy-at-read, F3's merge commit; **S**, today's coalescing path, the commit F3 lands on; **N**, no coalescing, F3's merge commit with `QUIC_GO_DISABLE_GRO=true` on both peers. N shares C's binary and is equivalent to the permission withheld: [`enableGRO`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_helper_linux.go#L89-L93) returns before activation, just as [`sys_conn_oob.go` L191–L194](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_oob.go#L191-L194) skips activation without permission. Workloads: the native stream and stock Datagrams.

**Protocol written before measurement** (decided): before the first counted run, the task posts on its issue the arm rotation, the campaign count and the statistic. Ceiling (this plan's): two interleaved rotations of the three arms, six campaigns at `REPS=3`, pooled medians per arm. The common preflight confirms that N still equals the permission withheld on F3's merge commit.

**Thresholds** (verbatim): "stream throughput no worse than no coalescing (−1% floor); stream receiver CPU per GiB at least 20% below no coalescing (the probe measured 24%); stock Datagrams within ±2% at the pin; no new loss." "No new loss" is read as within 0.1 point ([H26](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). S is reported beside them. Tests row, verbatim, read from the fork's CI for F3's merge commit: "**Tests:** the fork's full suite, including race, and the shared coalesced-delivery and routing-closure fixtures on every platform, with the Windows URO tests unchanged and green."

**Host rules:** the common `netns` rules.

**Outputs:** the common outputs; public comments on F3's issue and the release issue.

**Evidence budget:** Six campaigns at `REPS=3`, at most one replacement.

**Dispatch context budget:** About 35,000 input tokens: the common rules, this task, the F3 section and PROTOCOL.md with 4.R's sections.

**Stop conditions:** The common ones, plus: the scratch build's grant also enables coalescing on another platform → stop (the grant must be Linux-only).

### Task 4.G5 — Equal-size gluing gate on the bundle candidate (F10)

**Purpose:** F10's consumer gate ([Should the map adopt equal-size Datagram GSO as its Linux Datagram lever?](https://github.com/GridSwarm/wiremux/issues/1825#issuecomment-6252950084) section 5), on the bundle candidate.

**Blocked by:** Tasks 4.R, 4.G1, 4.G2 and 4.G4, so F1, F3, F4 and F5 are merged and have passed.

**Cell:** `netns`.

**Candidate and build:** A fork `main` commit carrying F1, F3, F4, F5 and F10, named by SHA. wiremux: the Linux coalescing-grant scratch build, plus slice A and slice B. When slices 1.3 and 2.3 are on wiremux `main` at run time, they are the real code; otherwise their measured probe shapes stand in (slice A: `native-gap-evidence/1823-dgram-cost/probes/s3b-rootpumpless.diff`; slice B: `r1-nocopy.diff` plus `r2-ctxcache.diff` in the same directory). F5's unprocessed-queue drop count (the reported loss row) through the same scratch addition to 3.1's seam that Task 4.G1 uses, never merged, unless slice 3.1's seam on `main` reads it by then ([H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). Gate-build counters, read through the same scratch addition: packer discards (4.R's recipe) and segments per `sendmsg` with the share of sends carrying at least two segments (a gate-build socket-level count, as the fork's own audit took it).

**Arms** (kill switch, one binary per campaign): A is gluing off, `QUIC_GO_DISABLE_SHORT_GSO_SEGMENTS=true` on both peers; B is gluing on. Workloads: Datagrams at the size in force; a 1,099-byte Datagram row (reported); the stream alone; the mixed arm at 4.R's stated mix.

**Thresholds** (verbatim):

| Line | Threshold |
| --- | --- |
| Datagram throughput | ≥ 2× the gluing-off arm (the probe pair against the stock sender: about 2.5–2.9×, **derived** across campaigns) |
| Sender CPU per GiB | ≥ 20% lower (the probe measured −35%, 5.18 → 3.39, [on quic-go-fast#743](https://github.com/the-sarge/quic-go-fast/issues/743)) |
| Receiver CPU per GiB | ≤ +5% |
| Stream alone | ≥ −1% |
| Mixed stream and Datagrams on one Wire (new rig arm) | stream ≥ −1%, Datagrams no worse. The slice states the mix before measuring. |
| Loss | Datagram loss ≤ +0.1 point. Received-Datagram queue discards ≤ 0.01% (internal count from [How deep should the native received-Datagram queue be, and should its discards be visible?](https://github.com/GridSwarm/wiremux/issues/1828#issuecomment-6150671507)). Packer discards exactly 0 (counted in the gate build). Unprocessed-queue drops reported ([Should native connections get a deeper unprocessed-packet queue than the fork's 256 packets?](https://github.com/GridSwarm/wiremux/issues/1855#issuecomment-6208362120)). |
| Wire closures (`EINVAL` or any send error) | 0 across every run |
| Round-trip time | minimum flat; mean ≤ +40 µs (the netns bound from [Should the fork's send batch cap follow its 32-entry send queue?](https://github.com/GridSwarm/wiremux/issues/1864#issuecomment-6240753010)) |
| Reported, not gated | segments per `sendmsg` and the share of sends with ≥ 2 segments |
| Tests | full fork suite (race and shuffle), the safeguard tests, a kill-switch test, and the segment-limit test in the fork's Windows lane |

"Minimum flat" is read as no rise beyond noise, and the mixed arm's "Datagrams no worse" as failing only if both A/B pairs show them lower ([H26](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). The record sets the fork's early warnings beside the stream and RTT rows (loopback stream 0.979×, smoothed RTT +84 µs). The Tests row is read from the fork's CI for [PR #805](https://github.com/the-sarge/quic-go-fast/pull/805), [PR #818](https://github.com/the-sarge/quic-go-fast/pull/818) and the candidate, including whether `TestWindowsConnShortSegmentLimit` ran rather than skipped.

**Result (2026-10-21).** The task ran on fork `main` `642f014e` (F1, F3, F4, the final F5 `2a83ed29`, F8 and F10 among its ancestors), with slices 1.3 and 2.3 as the real code on wiremux `main` and no stand-in diff ([record](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331860438)). One row failed as written: the Datagram workload's minimum RTT at the pin rose 9.8 µs (13.3 → 23.1 µs) against 0.9 µs of noise. Every other row passed: Datagram throughput 2.484×, sender CPU per GiB −57.21%, receiver −53.09%, the stream alone +1.22%, the mixed arm's stream +0.53% and its Datagrams no worse, Datagram loss +0.004 point, no received-Datagram discards, packer discards 0, no Wire closure, mean RTT +22.7 µs (Datagrams), −0.4 µs (stream) and +5.1 µs (mixed) against 40 µs, and the Tests row. The record read the Tests row from the fork's CI: the Windows-lane segment-limit test ran and passed, not skipped, for `9b52dca8` and `642f014e`. The fork had not replied on [quic-go-fast#743](https://github.com/the-sarge/quic-go-fast/issues/743), and the owner accepted the result on that record.

**Owner decision (2026-10-21).** The owner accepted the failed row, and gluing ships on by default ([decision](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331887768), quoted under [F10](#fork-slice-f10--equal-size-datagram-gluing)). Under the reading he chose ([reading](https://github.com/GridSwarm/wiremux/issues/1941#issuecomment-6331999513)), the Datagram workload's minimum RTT is reported, not judged, as in 4.G1. Latency is judged on the row's own bound, "mean ≤ +40 µs", which passed at +22.7 µs, and the smoothed RTT (84 → 141 µs) is reported beside it. 4.G1's 768-packet smoothed-RTT bound is not used, because it derives from F5's queue depth. Under this reading every judged row passes, so Task 4.G5 passes on `642f014e`, F10 ships on by default, and no gate is voided.

**Host rules:** the common `netns` rules.

**Outputs:** the common outputs; public comments on [Consider GSO-batching equal-size short packets with the first packet's size as the segment](https://github.com/the-sarge/quic-go-fast/issues/743) (with the lone-packet issue named) and the release issue.

**Evidence budget:** One A/B set: 4 campaigns at `REPS=3`, at most one replacement.

**Dispatch context budget:** About 45,000 input tokens: the common rules, this task, slice 3.1's seam source, the F10 section with [If F10's consumer gate fails](#if-f10s-consumer-gate-fails), the F1, F3, F4 and F5 rows of the slice graph, PROTOCOL.md with 4.R's sections, and the stand-in diffs or merged slices.

**Stop conditions:** The common ones, plus: (1) a failure follows [If F10's consumer gate fails](#if-f10s-consumer-gate-fails): the record and comments say the release ships gluing off by default and gluing returns to the map as a diagnosis issue (on 2026-10-21 the task passed under the owner's reading instead, above); (2) a stand-in diff no longer applies to the scratch build → stop for the operator; (3) the fork has not confirmed that the Windows-lane segment-limit test ran, not skipped, on a USO-capable runner for `9b52dca8` → the Tests row is "not run" and the fork is asked on the release issue; if it has not confirmed within 7 days of the request, the task ends with the row open and the operator decides (on 2026-10-21 the record read the row from the fork's CI instead, and the owner accepted the result on that record, above).

### Task 4.G6 — Windows copy-at-read gate (F11)

**Purpose:** F11's fork-half consumer gate ([Should wiremux grant native receive coalescing on Windows, and what is the Windows target?](https://github.com/GridSwarm/wiremux/issues/1870#issuecomment-6258365572) section 5), x64 and Arm64.

**Blocked by:** Task 4.R; F11 merged on fork `main`; the final F5 (re-decided 2026-10-20, every depth 2026-10-21) merged on fork `main` (met: `2a83ed29`); the owner's OK to rebuild the `winvm` guest and to build the Arm guest.

**Cells:** `winvm`, rebuilt from `native-gap-evidence/1869-windows-uro/vm/REBUILD.txt`; the Arm cell, a VMware Fusion clone of infra's Windows 11 Arm64 golden on mbp128, receiving from the macOS host.

**Setup:** re-identify the faster and slower receive queues' fixed sender ports on the new guest; an Arm cell driver for the Fusion guest and a `windows/arm64` build, both committed on the task's branch and pushed to `codex/native-gap-rig` as a fast-forward (guest credentials, if the driver needs them, set up by the owner); the Windows coalescing-grant scratch build (4.R's recipe); counts of coalesced reads and segments per read (engagement), of rejected coalesced reads (binding verdicts) and of guard trips (F11's count, read through a scratch wiremux build that adds it to slice 3.1's seam by interface assertion, never merged, since 3.1 predates the count; [H23](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)), with gate-build counters where none exist; a two-machine admission test covering a refused sender's coalesced reads on first contact and on an established connection (the established-connection row has never been measured), written as a reusable rig tool and pushed to `codex/native-gap-rig` with the Arm driver, because Slice 5.4 reruns it on the adopted release.

**Arms:** **ON**, F11's merge commit with the grant; **OFF**, the same binary with `QUIC_GO_DISABLE_GRO=true` on the guest receiver, passed through the guest agent (equivalent to the grant withheld: [`enableUROWith`](https://github.com/the-sarge/quic-go-fast/blob/5b05133dcc878d847123d9485206b77d42426453/sys_conn_windows.go#L144-L147) returns before activation); **SLAB** (reported only), the commit F11 lands on, with the grant. Workloads: the stream and Datagrams (1,024 queue), at the pin with the default-GC row; every native sender on its queue's fixed port.

**After F5's re-decision (2026-10-20).** The task measures a candidate carrying the changed F5 ([the owner decision](https://github.com/GridSwarm/wiremux/issues/1970#issuecomment-6303592965)). F11's merge commit carries F5 as first merged, so ON is a fork `main` commit carrying F11 and the final F5 (`2a83ed29` or later), named by SHA, with the grant; OFF is that same binary with the switch, and the common preflight checks OFF on that commit. SLAB stays the commit F11 lands on and stays reported only; it lacks the changed F5, so the record says that SLAB against ON is not an isolated comparison.

**Protocol:** the common preflight confirms that OFF still equals the grant withheld on F11's merge commit. On `winvm`, per receive queue, two interleaved rotations of OFF, ON and SLAB at `REPS=3` ("Three runs per arm, in interleaved campaigns"); the faster queue gates and the slower is reported. On the Arm cell, A, B, A, B of OFF and ON at `REPS=3`, no SLAB arm. A stuck-state run is rerun once under PROTOCOL.md's exception; a second stuck run in the same slot stops the campaign.

**Thresholds** (verbatim):

| Line | Threshold |
| --- | --- |
| Stream throughput, pin | ≥ +5% |
| Stream throughput, default GC | no worse than −1% |
| Datagrams, 1,024 queue, pin | ≥ +5% |
| Receiver CPU per GiB, stream, whole guest | ≥ 10% lower |
| Received-Datagram discards (1,024 queue) | ≤ 0.1%, no higher than off |
| Rejected coalesced reads; guard trips | 0; 0 |
| Admission | a refused sender's coalesced reads refused whole on first contact **and** on an established connection; every admitted datagram reaches QUIC once |

Arm rows: "coalescing engages (most bulk datagrams arrive in coalesced reads); zero rejected reads and zero guard trips; the admission rows; stream and Datagrams no worse than −1%; receiver CPU per GiB at least 10% lower." "There is no gain floor, since there is nothing yet to set one from. Failing Arm rows mean an x64-only grant and a diagnosis issue." "Most" is read as more than half of bulk datagrams by count ([H26](2026-10-19-native-gap-handoff-audit.md#handoff-decisions)). Tests row, verbatim, read from the fork's CI for F11's merge commit: "the full suite including race on the fork's Windows lane; the Windows URO tests with their four slab-shape assertions rewritten; guard tests: a long read without the record turns URO off for that socket, counts once and drops that read; reads with the record and short reads without it are unaffected; the cross-machine engagement test against a host peer", plus `TestWindowsManagedReceiveHandback` and `TestWindowsManagedECNCoalescedMetadata` rewritten.

**Result (2026-10-22).** The task ran ON = fork `main` `1c4a28b7` (F11's merge `0dae7d44` and the final F5 `2a83ed29` among its ancestors) with the grant, against OFF = the same binary with `QUIC_GO_DISABLE_GRO=true`, with SLAB (`17c46097`) reported ([record](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345139618)).

- **x64 (`winvm`):** every row passed on the faster queue that gates and on the slower one that is reported. Faster queue: stream at the pin +31.02%, at default GC +34.07%, Datagrams +19.04%, whole-guest receiver CPU per GiB −18.43%, discards 0.00006% (OFF 0.00008%), rejected reads and guard trips 0; 0, and both admission rows.
- **Arm:** every Arm row passed as written. Coalescing engaged, there were no rejected reads or guard trips, both admission rows passed, stream +8.33%, Datagrams +16.27%, and receiver CPU per GiB −26.84% (stream) and −34.57% (Datagrams) on the receiving process. On the whole guest, stream was −9.43%.
- **Tests row:** not met as written. On `0dae7d44` the fork's CI ran the full Windows suite without race and race only on `^TestWindows(URO|USOURO|Managed|External)`, all passing, and it skipped the cross-machine engagement test. Downstream, that test passed 3/3 on both guests against a host peer.
- **Incident:** one Arm guest kernel crash, bugcheck `0xD1` in VMware's `vmxnet3.sys` 1.9.20.0, at the start of a coalescing-on run: 1 in 48 coalescing-on runs and 0 in 32 off ([addendum](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345691209)). The campaign was stopped as a host fault and its one replacement ran clean.

**Owner decision (2026-10-22).** The owner passed both platforms ([decision](https://github.com/GridSwarm/wiremux/issues/1942#issuecomment-6345797171), quoted under [F11](#fork-slice-f11--windows-copy-at-read-the-missing-record-guard-and-slab-retirement)): the Tests row is accepted as run, the Arm receiver-CPU row is judged on the receiving process with the whole-guest figure reported, and the crash is accepted and tracked as the watch item [#1988](https://github.com/GridSwarm/wiremux/issues/1988). Under these readings every row passes, so Task 4.G6 passes on `1c4a28b7`. F11 ships in the release, slice 5.4 grants Windows coalescing on x64 and Arm64, and no gate is voided. This was the last consumer gate of the track.

**Host rules:** the common `winvm` and Arm rules, plus mbp128's pair-claim etiquette for the Arm cell (it shares mbp128 with `tb` and the GARM Tart VMs). Both guests are deleted at the end.

**Outputs:** the common outputs; public comments on F11's issue and the release issue, with the cells in their public phrasing.

**Evidence budget:** `winvm`: two queues × six campaigns = 12 campaigns; Arm: 4 campaigns; the admission test once per cell for both rows; at most one replacement campaign per set; stuck-state reruns as above.

**Dispatch context budget:** About 45,000 input tokens: the common rules, this task, the F11 section, PROTOCOL.md with 4.R's sections, slice 3.1's seam source, `REBUILD.txt` and `busy1869.sh`, the `winvm` driver (`rig.sh`, `winqga.py`), [infra's Windows 11 Arm64 guest definition](https://github.com/the-sarge/infra/blob/7934472eaf3b8f3f3b3de28b4cb40ad0c72bca72/config/windows-filesystem-qualification/windows-11-arm64.yaml), the first-contact admission test `uro1869` (`/Volumes/worktrees/wiremux/1869-probe/cmd/uro1869`, a never-pushed probe), and the [Windows research note](../research/issue-1869-windows-receive-coalescing.md) sections 2 and 4.

**Stop conditions:** The common ones, plus: (1) the owner's OK for a guest is not given → the task waits and reports; (2) x64 rows fail → F11 is left out of the release and returns to the map; (3) only Arm rows fail → F11 ships, the record and comments say slice 5.4 grants x64 only, and the task drafts a diagnosis issue for the operator (on 2026-10-22 every Arm row passed under the owner's decision, above, and the grant is x64 and Arm64); (4) the established-connection admission row cannot be built on the two-machine cell → stop for the operator.

## Acceptance Criteria

- [ ] **Every bundle slice is filed or retained under one parent.** F2–F9 and F11 are new self-contained fork issues; F1 and F10 (their three existing issues) are retained with consumer comments recording acceptance, deviations and the outstanding gate; all eleven are sub-issues of one fork bundle-release issue, with frontier labels or native `blocked_by` as above. Domain: the eleven slices. Representation owner: the fork tracker's sub-issue list. Guarantee: canonical (one list). Terminating evidence: the parent's sub-issue list read once after filing.
- [ ] **No public text carries a private term.** Every issue body and consumer comment this program files in the fork contains none of the private terms in the public-brief rules. Domain: text this program files in the fork tracker (not the fork's own records). Representation owner: the filing agent's pre-posting check. Guarantee: canonical subset (the fixed private-term list, searched case-insensitively). Terminating evidence: the recorded search output for each filed text.
- [ ] **Every default-on slice the release carries has a recorded gate before the release.** F1 and F5 (4.G1), F4 (4.G2), F3 (4.G4) and F10 (4.G5) always; F8 (4.G3) if F8 ships in the release; F11 (4.G6) if F11 ships in it. Each has a task resolution and public comments on the fork issue and the release issue before the release is cut. Domain: the default-on slices the release carries. Representation owner: the gate task records. Guarantee: universal over that set. Terminating evidence: the resolutions of the gate tasks whose slices the release carries.
- [ ] **No release carries a failed default-on slice as merged.** A holding slice with a failed gate is not shipped as merged; F8 failed ships at cap 8, unless the owner accepts its failed rows (as on 2026-10-21, so F8 ships at cap 32); F11 failed is left out; F10 failed ships off by default. Domain: the release's diff from `v0.62.1-fast.7`. Representation owner: the fork's release; the consumer verifies at slice 5.1's audit. Guarantee: universal over the seven default-on slices. Terminating evidence: the recorded gate verdicts set against the release's commit list and F10's default.
- [ ] **Release ordering holds.** No release carries F5 without F1, F8 without F4, F10 on by default without F1 and F5, or F11 without F1 and F3; wiremux adopts no fork release with gluing on by default without F1 and F5. Domain: fork releases considered for adoption. Representation owner: slice 5.1's fork audit. Guarantee: universal over those four rules. Terminating evidence: the audit's check of the release's commits and of F10's default.
- [ ] **Opt-in slices ship off by default with their fork tests green.** F2, F6, F7 and F9 behave as before unless a consumer switches them on; their measured gates are slices 5.2, 6.1, 6.4 and 6.2. Domain: the four opt-in slices as merged. Representation owner: each slice's mode-off or default test in the fork suite. Guarantee: example-level (one mode-off or default case per slice). Terminating evidence: those four tests green in the fork's CI for each merge commit.
- [ ] **Negative: no wiremux `main` change.** Every wiremux artifact of this track is a commit on a task branch or `codex/native-gap-rig`, an evidence directory or a task record. Domain: the seven wiremux tasks. Representation owner: the wiremux repository's pull requests against `main`. Guarantee: universal over the seven tasks. Terminating evidence: no pull request against `main` names a Track 4 task, checked once when the last task closes.
- [ ] **Negative: no GARM mutation, no leftover guest.** Domain: Task 4.G6's two guests and every gate task's session. Representation owner: each task's record. Guarantee: universal over the seven tasks. Terminating evidence: each record states that GARM was only read (no mutating `garm-cli` or service command in the session), and 4.G6's record names each guest's deletion.

## Validation Gates

- **Fork side** (run by the fork under its own process): each slice's required tests and the fork suite with race on the Ubuntu, Windows and macOS unit lanes; the managed-mode tests for F3 and F11; the fork's review practice. The consumer reads the merged commit's CI result as the "fork tests" or "Tests" row of each gate.
- **Task 4.R:** `WIREMUX_TEST_NATIVE=required go test -race -modfile=cmd/nativerig/rig.mod ./cmd/nativerig` on macOS and Linux, and one smoke campaign per cell; smoke output is never evidence.
- **Tasks 4.G1–4.G6:** each task's arms, thresholds and evidence budget above, on PROTOCOL.md's A/B rule with the pin and the default-GC row, under the host rules and the recorded readings.
- **Before posting any public comment:** the private-term search returns nothing.
- No hosted CI applies: nothing in this track changes wiremux `main`, and adding CI lanes is out of scope.

## Operating Discipline

The fork slices are executed in the-sarge/quic-go-fast by the fork's own agents under the fork's process (its agent docs, triage labels and review practice). This plan never dispatches a fork agent, and no wiremux agent commits, pushes, labels, closes or reverts anything in the fork; the only wiremux writes there are the filing pass (the operator's packaging step) and the gate tasks' result comments. If a fork agent's work departs from a requirement here, the gate task or the operator reports it on the fork issue and stops; the fork decides.

The wiremux tasks are task issues, dispatched by the operator to fresh agent sessions; dispatch is an operator action. Each task works on its own branch in its own worktree (`git worktree add -b codex/<task-slug> /Volumes/worktrees/wiremux/<task-slug> <rig commit>`) and treats every other checkout as read-only. Two sets of commits are pushed, both to `codex/native-gap-rig` as fast-forwards from the task's branch and never merged to `main`: Task 4.R's readouts, arms, recipes and PROTOCOL.md text, and Task 4.G6's Arm-cell driver, `windows/arm64` build and two-machine admission tool. Everything else (scratch builds, seam additions, gate-build counters) stays unpushed on the task's branch, with its diff in the evidence directory. No pull request is involved, so the shared review-loop baseline supplied by `$implement-architecture-slice`, composed with [docs/REVIEW-LOOP.md](../REVIEW-LOOP.md) and [docs/CI.md](../CI.md), applies only if a task ever has to propose a wiremux `main` change, which is a stop condition here. The shared contract-closure baseline governs the closure tables in Part A. Native fork-lane rules (`-modfile` at the named fork commit, `WIREMUX_TEST_NATIVE=required`, `-race`) apply to the rig's own tests. Measurements follow the host rules above: the per-run no-other-`nativerig` gate on minimax, the `tb` pair claim and mbp128 announcements with `LOADGATE` and `GATE` for the GARM Tart VMs, the owner's OK for every Windows guest, guests deleted afterwards, GARM read-only. Each task closes with its resolution record, its public comments, the OmniFocus task's completion and the tracker's reconciliation; gate tasks do not run `$append-dev-journal`, because slice 5.1's journal entry records their results. Slice 5.1 consumes the records; it does not re-run the gates.
