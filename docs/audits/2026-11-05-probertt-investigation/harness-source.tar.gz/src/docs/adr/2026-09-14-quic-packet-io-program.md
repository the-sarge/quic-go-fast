# QUIC packet I/O program

**Stable identity:** QUIC-IO-2026-09
**Status:** Complete through Z01. Both tracks, named consumer adoption, releases and rollback are reconciled; E01-L/W/D remain retired.

## Destination

Make quic-go-fast useful with caller sockets and policy wrappers while preserving ordinary upstream wiremux. Complete safe managed reuse, native fixed-peer enforcement, Linux/Windows/macOS qualification, library releases, application adoption and rollback. Early acceleration is a milestone; only Z01 closes the program. Contracts live in the two track plans; this index and trackers contain pointers and ordering only.

## Tracks

| Track | Normative plan | Parent issue | Slices |
| --- | --- | --- | --- |
| W — wiremux integration and delivery | [Plan](2026-09-15-wiremux-packet-io-plan.md) | [#1520](https://github.com/GridSwarm/wiremux/issues/1520) | 19 stable IDs: 16 required, 3 retired |
| Q — fork packet I/O and managed endpoints | [Plan](https://github.com/the-sarge/quic-go-fast/blob/main/docs/adr/2026-09-15-external-packet-io-plan.md) | [#324](https://github.com/the-sarge/quic-go-fast/issues/324) | 13 |

## Complete dependency map

| Slice | Track | Blocked by |
| --- | --- | --- |
| E01 | W | None |
| Q01 | Q | None |
| W01 | W | Q01 |
| W02 | W | W01 |
| E01-L | W | Retired; no blockers or dispatch |
| E01-W | W | Retired; no blockers or dispatch |
| E01-D | W | Retired; no blockers or dispatch |
| Q02 | Q | Q01 |
| Q03 | Q | Q01 |
| Q04 | Q | Q01 |
| Q05 | Q | Q01 |
| R01-A | Q | None |
| R01-B | Q | R01-A, Q01 |
| R01-L | Q | R01-B, Q03 |
| R01-W | Q | R01-B, Q04 |
| R02 | W | R01-B, W01, W02 |
| R03 | Q | R01-L, R01-W |
| P01-A | Q | None |
| P01-B | Q | P01-A, Q01 |
| P02 | W | P01-B, W01, E01 |
| E02-L | W | W02, R02, P02, Q03, R01-L |
| E02-W | W | W02, R02, P02, Q02, Q04, R01-W |
| E02-D | W | W02, R02, P02, Q05 |
| E02 | W | E02-L, E02-W, E02-D, R03 |
| L01 | Q | E02 |
| L02 | W | L01 |
| C01-C | W | L02 |
| C01-CR | W | C01-C |
| C01-G | W | L02, C01-CR |
| C01-T | W | L02, C01-CR |
| C01 | W | C01-G, C01-T, C01-CR |
| Z01 | W | C01 |

Current frontier: none. [Z01's aggregate closeout](../research/z01-program-closeout.md) records all 32 stable IDs, merged delivery/release evidence, support and rollback, retired seams and explicit non-claims. Both tracks and C01's named consumers are complete. The [live tracker](https://github.com/GridSwarm/wiremux/issues/1540) and W/Q parents close after the Z01 merge and journal. E02 retains correct opt-in support, ordinary defaults and unavailable performance; R03 rejects raw handback; managed reuse and the selected-peer wrapper remain supported. E01-L/W/D remain retired, with no invented measurement receipts.

## Outcomes closed without implementation

The prior P00 publication stage is consumed by this handoff; it is not a future recursive implementation ticket. All required runtime delivery is complete; no implementation frontier remains. The original R01 is split into R01-A/B/L/W; final E02 evidence is split into E02-L/W/D plus aggregation; C01 is expanded into named compatibility, release and application children. The three standalone baseline campaigns are superseded by evidence reuse and the bounded final comparison; no accepted product outcome was removed. P02 has selected wrapper retention. See the [revision audit](2026-09-15-packet-io-evidence-reuse-audit.md). Dormant/excluded consumer dispositions and source evidence are in the [handoff audit](2026-09-15-packet-io-handoff-audit.md).

## Binding rules

Follow the [design contract](2026-09-15-quic-packet-io-design.md), both plans and repository review overlays. Preserve one mutation owner and full authority consumers at every merge. Ordinary upstream and unsupported paths remain maintained fallbacks. Do not bypass opaque wrappers or claim coalescing engagement from compilation. Native correctness and managed reuse are mandatory; insufficient measured speedup may retain correct opt-in behavior. Only Z01 may close both parent programs after every required slice and named consumer is resolved.

Issues own live blockers and frontier; immutable default-branch plan commits identify dispatch contracts. OmniFocus mirrors stable pointers under the user-selected parents. Per slice: fresh `$implement-architecture-slice` context, bounded review, exact-head validation/CI, merge, append-dev-journal, then complete its task. No implementation is launched by this handoff.
