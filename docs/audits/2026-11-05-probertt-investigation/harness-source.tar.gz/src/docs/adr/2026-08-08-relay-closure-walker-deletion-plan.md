# Dead Relay-Closure Walker Deletion Implementation Plan

**Date:** 2026-08-08
**Status:** Accepted; not yet implemented
**Track:** 5 of 5 in the 2026-08-08 architecture deepening program
**Depends on:** nothing — safe to start first
**Related:** Existing child issue #1014; [`2026-07-07-rendezvous-disposition-plan.md`](2026-07-07-rendezvous-disposition-plan.md)
**Normative scope:** Current outcome, boundaries, preservation evidence, blockers, and stop conditions
**Audit history:** Final architecture-review convergence and grilling on 2026-08-08; independent slice audit PASS on 2026-08-08; synchronization of existing issue #1014 is administratively pending the accepted docs commit

## Goal

Delete the unused `isRelayIOClosure` classifier and its dedicated hostile-error traversal so root production source no longer carries a second policy/proof path with no production caller. Preserve the live identity-failure summary and `connect.RendezvousDisposition` policies independently.

## Current Shape (verified 2026-08-08 at `7f574a5a8b7ffff64fa69a10dd57b1b46e3ee78c`)

- `isRelayIOClosure` at `error_tree.go:113-121` is described as a diagnostic/test classifier. Repository reference census finds only its focused test at `wiremux_internal_test.go:763-816` and the dedicated `BenchmarkRelayIOClosureCyclicTree` at `wiremux_error_tree_benchmark_test.go:48-56`.
- Its dedicated traversal occupies `error_tree.go:338-485`, including recursive and linear-fallback paths. `relayIOClosureCanUnwrap` at `:476-485` is deletion-eligible only if the fresh census confirms it remains exclusive to that traversal. The `relayIOClosureResult` type/constants at `:123-129`, `maxRelayIOClosureUnwrapDepth`/`maxErrorTreeTraversalDepth` at `:15-20`, and shared leaf checks such as `isDirectRelayIOClosure` remain used by the live identity-failure summary/tests and are explicit retention targets.
- Root's live identity-failure policy performs rich path-sensitive summarization and sanitization. `connect.RendezvousDisposition` uses a separate bounded breadth-first policy with different precedence and fail-closed behavior. Their similarity does not create one safe shared owner.
- Issue #1014 is open and unassigned with no implementation PR or blocker. Its prior `ready-for-agent` label was removed while this plan and thin child body are synchronized; readiness is restored only after that administrative update.

## Decision

- Perform a fresh reference audit at implementation head, then delete only `isRelayIOClosure`, the helpers exclusively reachable from it, its focused test, and `BenchmarkRelayIOClosureCyclicTree` in full. Retain shared benchmark/test helpers such as `benchmarkBool` and `newCyclicError` while other references remain.
- Retain every representation/helper shared with the production identity-failure summary, including `relayIOClosureResult` and its constants, `maxRelayIOClosureUnwrapDepth`, `maxErrorTreeTraversalDepth`, direct leaf classification, safe unwrap/typed-nil support, and production adversarial coverage.
- Do not extract or normalize root and `connect` traversal policies. The no-code decision in the program index remains binding.
- If a production caller has appeared, stop rather than deleting or silently rewriting it.

**Rejected alternative (do not do this):** Extract a generic hostile-error walker while deleting the dead classifier. Root and `connect` differ in traversal order, precedence, sanitization, and fail-closed contract; callbacks or policy flags would make a shallow module.

**Rejected alternative (do not do this):** Delete shared leaf/sanitization helpers based on proximity. They remain production dependencies of the live summary.

**Non-goals:** no behavior change; no shared walker; no change to identity-failure consumption, typed-nil sanitization, errors.Is identity, error reconstruction, traversal budgets, `connect.RendezvousDisposition`, public errors, or downstream code.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | rework existing #1014 | Reference-proven deletion of the dead classifier family | None | Removes unused parallel traversal |

## Implementation Slices

### Slice 1 — Delete the unused relay-closure classifier family

**What it delivers:** A smaller root error module with no production-semantic change: only code, test, and benchmark material exclusively owned by the no-caller classifier are removed.

**Existing-work disposition:** Rework issue #1014 into this audited child contract. Retain its cleanup outcome; replace its mirrored details with a pointer to this plan. No open PR, branch, comments, or unresolved review findings exist.

**Blocked by:** None.

**Single owner after merge:** The existing identity-failure summary remains root's sole relay-closure classification owner for consumption policy. `connect.RendezvousDisposition` remains its package's independent public disposition owner.

**Authority completeness:** No new authoritative fact is introduced. A fresh production/test/benchmark reference graph must classify every removed helper as exclusive to the dead entrypoint and every retained helper as live or independently justified.

**Transitional-seam budget:** None. The dead entrypoint, exclusive helpers, focused test, and focused benchmark reference disappear together; no shim remains.

**Blast radius:** Root error source/tests/benchmark only. The chief risk is accidental deletion of a shared helper or adversarial test protecting live error handling. No concurrency, interface, wire, performance promise, dependency, or security behavior changes; binary/source size should decrease modestly.

**Artifact classification:** Source deletion is shipped behavior with intentionally unchanged reachable observation. Reference audit and surviving tests are verification aids. The plan is process/traceability metadata.

**Representation contract:** Supported domain = the current Go reference graph rooted at `isRelayIOClosure` versus live production error-classification entrypoints. Representation owner = Go identifiers resolved by `rg` plus compiler/test results. Guarantee = canonical-subset claim over repository source at implementation head, not reflection or generated external code. Terminating evidence = zero production caller before deletion, zero removed-identifier references after deletion, focused live error tests, and `task verify`.

**Contract closure:** Not triggered. The slice removes unreachable code and does not alter an accepted material invariant; ordinary reference and regression evidence is sufficient. Discovery of a production caller is a stop condition.

**Evidence budget:** One pre-delete and one post-delete reference census, compiler/lint results, focused live root error tests, benchmark compilation through the ordinary suite where applicable, and `task verify`. The census must separately prove `relayIOClosureCanUnwrap` exclusive; `relayIOClosureResult`, both live traversal-budget constants, `benchmarkBool`, and `newCyclicError` live. No new fuzzing, mutation, platform, repetition, or traversal matrix. Review budget = one initial review plus at most one fully briefed replacement review. Terminate when exclusive code and the complete dedicated benchmark are gone and surviving production behavior is green.

**TDD and preservation evidence:** No new behavior test is required for dead code. Before deletion, identify which adversarial tests protect the live identity-failure summary; after deletion, run them unchanged, including cycle/join/malformed unwrap/typed-nil/traversal-limit cases.

**Dispatch context budget:** This plan; `error_tree.go`, `wiremux_internal_test.go`, `wiremux_error_tree_benchmark_test.go`, the live identity-failure call sites, and `connect.RendezvousDisposition` only for the explicit non-merge boundary. One PR fits one fresh context.

**Slice decision audit:** Splitting helper deletion from test/benchmark deletion would leave broken or dead artifacts. Merging shared traversal extraction contradicts the reviewed decision and enlarges risk. No blocker is necessary.

**Stop conditions:** Stop if a production caller exists; if an exclusive-helper classification is ambiguous; if deletion changes any live identity-failure/Rendezvous disposition or error-tree test; or if cleanup requires changes in `connect`.

## Acceptance Criteria

- [ ] A fresh implementation-head reference audit confirms `isRelayIOClosure` has no production caller.
- [ ] `isRelayIOClosure`, every helper exclusively reachable from it, its focused test, and `BenchmarkRelayIOClosureCyclicTree` in full are absent.
- [ ] Shared `relayIOClosureResult` values, `maxRelayIOClosureUnwrapDepth`, `maxErrorTreeTraversalDepth`, `benchmarkBool`, `newCyclicError`, direct-leaf, sanitization, unwrap, typed-nil, and live identity-failure summary code remains where references survive.
- [ ] Existing production adversarial error-tree and identity-failure disposition tests pass unchanged.
- [ ] `connect.RendezvousDisposition`, public errors, error identities/trees, wire protocol, and downstream consumers remain unchanged.
- [ ] No shared hostile-error traversal module or callback policy is introduced.

## Validation Gates

Run pre/post `rg` reference censuses; focused root tests for live identity-failure and error-tree behavior; `go test ./...`; `./scripts/check-gofmt.sh`; and `task verify`. Follow the Go toolchain supply-chain audit before any Go command.

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md). Delete only reference-proven dead ownership; do not use this slice to harmonize distinct error policies.
