# Architecture Deepening Program — 2026-08-08

**Status:** Accepted; tracks not yet implemented

## What this is

This is the dispatch index for the final 2026-08-08 architecture review. The five linked track plans are the normative source of truth for implementation. This index records stable identity, true dependencies, the parallel-safe frontier, and outcomes deliberately closed without production changes.

## Outcomes that require no implementation

- Do not extract a shared hostile-error traversal module. Root error normalization and `connect.RendezvousDisposition` have intentionally different traversal order, bounds, precedence, sanitization, and fail-closed behavior. Revisit only if a third production consumer appears or the same concrete defect must be fixed in both policies.
- Do not introduce a startup transaction around `cmd/wiremux-server.serve`. Its sequential acquisition, immediate defers, and existing `serviceGroup` supervisor already localize rollback and runtime shutdown for one caller. Revisit only after a second startup caller or a demonstrated rollback defect.
- Do not require deletion of `upgradePlanOptionSet` in Track 1. It is a derived prepared snapshot created after packet/STUN resources are known; the accepted ownership problem is the direct-upgrade mirror in `dialConfig` and its copier.
- Do not approve a production Datagram-admission extraction in advance. Track 3 may publish only a prototype decision receipt; a successful result requires a new scoped architecture handoff before production implementation.
- Keep the production listener's narrow `send` and `await` operations in Track 2. The rejected seam is the test-only generic engine role and its generic terminal machinery, not the operations used by the managed listener path.
- ADR-0006, ADR-0008, ADR-0009, and ADR-0010 remain settled. None of these tracks changes their public or wire contracts.

## Tracks, dependencies, and frontier

| # | Track | Plan | Parent issue | Blocked by | Slices | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Upgrade-plan ownership | [`2026-08-08-upgrade-plan-ownership-plan.md`](2026-08-08-upgrade-plan-ownership-plan.md) | Pending | None | 1 | FRONTIER |
| 2 | Generic upgrade-engine mode deletion | [`2026-08-08-generic-upgrade-engine-mode-deletion-plan.md`](2026-08-08-generic-upgrade-engine-mode-deletion-plan.md) | Pending | None | 1 | FRONTIER |
| 3 | Datagram-admission prototype decision | [`2026-08-08-datagram-admission-prototype-plan.md`](2026-08-08-datagram-admission-prototype-plan.md) | Pending | None | 1 | FRONTIER |
| 4 | Establishment settlement policy | [`2026-08-08-establishment-settlement-policy-plan.md`](2026-08-08-establishment-settlement-policy-plan.md) | Pending | None | 1 (existing #1013) | FRONTIER |
| 5 | Dead relay-closure walker deletion | [`2026-08-08-relay-closure-walker-deletion-plan.md`](2026-08-08-relay-closure-walker-deletion-plan.md) | Pending | None | 1 (existing #1014) | FRONTIER |

All five child slices are parallel-safe: there are no cross-track blocking edges. `FRONTIER` records dependency readiness, not publication readiness; dispatch begins only after each child issue is published or synchronized with the accepted plan commit and labeled `ready-for-agent`. The recommended starter is Track 1 because it removes the clearest production ownership duplication; this is a prioritization recommendation, not a dependency. Track 3 is intentionally a docs-closing prototype slice and cannot dispatch production extraction work.

## Rules that bind every track

- Preserve the v0.1.x public interface, wire protocol, documented error identities, validation timing, ownership transfer, lifecycle ordering, and Datagram semantics unless a track plan explicitly says otherwise; none currently does.
- Each production fact or transition touched by a slice has one owner after merge. Derived snapshots may remain when they are materialized after additional resources become known and cannot be mutated as a second authority.
- No slice retains a temporary compatibility path, generic role, double mutation path, or shadow owner unless its plan names the seam and its exact removal slice. These one-slice tracks budget no such seam.
- Universal claims name their supported domain, representation owner, guarantee level, and finite terminating evidence. Verification aids do not recursively expand product scope.
- Track 3's throwaway prototype is never merged. Its decision receipt is process metadata, not production authorization.
- Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md).
- Public-interface changes are stop conditions. If a plan assumption fails outside the accepted one-PR boundary, stop for a decision rather than broadening the slice.
- Post-merge ritual for each production slice: review → exact-head certification/same-head CI → merge → append-dev-journal → complete its OmniFocus task → update the tracker and frontier. The Track 3 docs-only decision PR follows the repository's applicable documentation lane and the same administrative ritual.
