# ADR-0006: The Upgrade Module Owns One Type Family and One Transition Authority

## Status

Accepted and implemented. D1 and D2 landed in the original 2026-07-05 program; D3 reached final conformance through issues #825, #828, and #829. Produced by an architecture review and design walkthrough on 2026-07-05 and corrected to the shipped boundary on 2026-07-31.

## Context

Direct upgrade in `connect` currently spreads its concepts across parallel
representations and files:

- Candidate, offer, and selected candidate pair each exist as two or three
  parallel Go types: the `connect` domain types, the
  `connect/internal/upgradecontrol` wire structs, and connect-side
  `upgradeControl*Message` mirrors. `upgrade_control_bridge.go` holds ~25
  functions that copy fields between them.
- Each upgrade fallback reason exists as three values: the public
  `UpgradeFallbackReason` string, the `internal/fallbackreason` string
  constant, and the `upgradecontrol.FallbackReason` uint64. The
  deterministic-precedence table in `fallbackreason` — the authority behind
  the terminal fallback exchange — has no direct tests.
- The ordering invariant of upgrade control (ready → commit → accepted →
  converged → confirmed, with the direct upgrade commit point and
  split-brain rules) is encoded in two separate tables
  (`upgrade_phase.go`, `upgrade_listener_postready.go`), four
  terminal-fallback peer policies, and imperative branches across roughly
  ten files sharing one mutable `directUpgradeAttempt`. Cleanup obligations
  (session, listener, accepted stream, packet socket, relay channel) are
  distributed across ~10 `abort*/close*` helpers whose composition differs
  per path.
- Both internal packages are hypothetical seams: `upgradecontrol` and
  `fallbackreason` each have exactly one consumer (`connect`). Go's package
  boundary forces the type duplication and the bridge; it buys no
  substitutability.

## Decision

### D1: The upgrade-control codec speaks domain types

`connect/internal/upgradecontrol` dissolves into `connect` (codec and CBOR
scanner as their own files). Encode/decode functions operate directly on
the domain types (`Candidate`, `selectedPair`, offer and phase messages,
`UpgradeFallbackReason`). The wire enums (uint64 candidate kinds, field
keys, message discriminators) become unexported constants co-located with
the codec, still mirroring the PRD-0001 registry exactly. The bridge file
and the `upgradeControl*Message` mirror family are deleted. ADR-0002's
encoding profile, bounds, and registry discipline are unchanged; golden
frame encodings stay byte-identical.

### D2: One fallback-reason authority

After D1, `connect/internal/fallbackreason` has a single consumer and folds
into `connect`. `UpgradeFallbackReason` remains the only reason type; the
definition table (wire code, phase validity, precedence rank) is keyed on
it directly. The precedence and phase-validity table gets direct tests at
its own interface. The one-line delegation shims in `upgrade_fallback.go`
are deleted. The protocol rule that an unknown or phase-invalid wire reason
resolves to `protocol_mismatch` is preserved.

### D3: One transition authority for direct upgrade

One role-parameterized transition table and `directUpgradeProtocolEngine` own every synchronized dialer and listener phase from selected-pair synchronization through confirmed success. The table records 43 dialer rows and 82 listener rows; role-specific event selection feeds the same cursor, action representation, and post-commit loop, with no listener driver, post-ready switch, compatibility alias, or second transition authority.

`attemptResources` is the sole lifecycle, definitive-result, packet-claim, and terminal-disposition owner. Engine actions register Session, Listen, Accept, Dial, and commit facts, then request only `settleRelay`, typed `failClosed`, or `succeedDirect`; they do not compose cleanup or form results.

`terminalFallbackExchange` remains a separate blocking rendezvous module, and `controlFrameSequencer` remains the separate serialized frame-read authority. The engine selects their narrow operations but does not absorb either module. Pre-offer setup (session creation, candidate gathering, offer construction) stays imperative because it is sequential rather than interleaving-sensitive.

The public interface stays exactly `Negotiator.Upgrade(ctx, opts...)`. Frozen contracts are the wire protocol; exported error identities and `errors.Is` classification; the ADR-0008 packet-socket ownership rule; Accept pending before ready; completed-result preference at timeout and cancellation boundaries; and fresh probe-timeout-derived budgets after commit or non-nil Dial/Accept materialization.

### D4: No internal subpackages for single-consumer modules in connect

Codec, reason table, and protocol engine are modules with internal seams
inside the `connect` package, organized by file. A Go package boundary is
reintroduced only when a second consumer exists. (A
`connect/internal/upgrade` subpackage is also ruled out mechanically: it
would need `connect`'s exported contract types and create an import cycle.)

## Considered Options

- **Type aliases into the internal packages** (`type Candidate =
  upgradecontrol.Candidate`): removes the copying but leaks internal
  packages into the public API surface and keeps the hypothetical package
  seams. Rejected.
- **Deleting only the middle mirror family, keeping the wire structs and a
  thinner bridge**: keeps two type families and most mappers. Rejected as a
  half-measure.
- **One mega-table covering setup through confirmed**: setup is sequential
  and not event-driven; forcing it into rows adds table complexity without
  locality gain. Rejected — the table covers the synchronized protocol
  phases only.

## Consequences

- Implementation order was D1 → D2 → D3. D3 conformance completed later through the persistent owner in #825, the dialer engine in #828, and the listener engine in #829.
- D3 is a behavior-identical refactor of race-sensitive code. Before any
  existing test file is deleted, each scenario it covers is mapped to its
  replacement at the new surface (transition-table tests plus
  protocol-level tests through `Negotiator.Upgrade`); `task verify`
  including the race gate is the acceptance bar for every slice.
- Bridge, mirror-family, and delegation-shim tests are deleted with their
  modules rather than ported (replace, don't layer). Hostile-input and
  golden-frame codec tests are rewritten against the domain-typed codec
  functions and must reproduce the existing golden bytes.
- A transition-table completeness test expands pattern rows across every concrete role/state/event combination, requires exactly one match for each reachable combination and zero matches for explicitly impossible combinations, and includes negative missing/overlap fixtures so omissions and ambiguity fail loudly instead of falling through to default branches.
