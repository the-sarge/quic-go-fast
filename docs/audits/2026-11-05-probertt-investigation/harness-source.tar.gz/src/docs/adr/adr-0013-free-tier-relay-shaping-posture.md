# ADR-0013: Free-Tier Relay Shaping Degrades Assist Before Rendezvous

## Status

Accepted.

## Context

The GridSwarm free tier is accountless and shaped rather than metered: metered forwarding rides TURN, while anonymous relay assist rides the wiremux relay's retained reliable stream. Roughly half of the relay's protective knob set already exists as connection, request, and session counters (connection-rate windows, session caps, ephemeral abuse backoff). Nothing bounds forwarded bytes, nothing bounds monthly egress, and the order in which the relay sheds load under pressure is operator judgment rather than server behavior. An independent consideration run classified these controls as a public-release gate for anonymous relay exposure. Issue #1255 grilled the missing half into the decisions below.

## Decision

Shaping applies to the relay-assist stream — one rendezvous pairing, both directions summed — never to a source address, because CGNAT and IPv6 rotation make an address a poor proxy for a person and an attacker rotates addresses for free. The knobs form one medium-neutral shaping policy that any forwarding path consults; the TLS/TCP fallback loop is its first enforcer, and a future UDP forwarder would consult the same policy and express degradation as packet drop instead of read-side backpressure.

Shaping degrades a stream and never terminates it. The per-stream ceiling throttles through backpressure; the global ceiling is a fair-share throttle drawn from one shared bucket, so the relay fills gradually instead of refusing the next peer. Refusal exists only as a shedding rung, never as a shaping outcome.

The monthly egress breaker counts relay-assist bytes only, over the UTC calendar month the hosting bill is denominated in, and persists its running total to a small versioned JSON state file written atomically and read by nothing but the relay binary. A breaker that must reach a control plane to know the month's total is a dashboard, not a breaker, so the local file remains the backstop even after a control plane exists; the control plane later pushes budget values and reads counters for fleet-wide totals, and never becomes the relay's authority on whether to trip. SQLite was rejected: the file holds three fields with one writer, and the floor module should not inherit a database dependency for a struct.

The shedding order is encoded in the server, in this sequence: per-stream ceiling, global fair-share, refusal of new relay assist when the breaker has tripped or the active-pair cap is full, and finally the pre-existing rendezvous limits. Refusing assist still completes rendezvous and candidate exchange so direct upgrade can succeed; only the retained fallback is withheld, enforced by a small byte-and-time allowance after which the relay closes the stream. The relay signals this with a new pairing reply status distinct from OK and error. That reply is a deliberate v0.1.x wire break for old clients under active shedding only — the existing single-byte reply has no extension point and the relay cannot observe the upgrade attempt inside opaque forwarded bytes — accepted because the release line has no external users, and handled by regenerating wire vectors, amending the compatibility contract, and bumping downstream pins in lockstep.

Knob values reload at runtime from an optional shaping file re-read on SIGHUP, applied all-or-nothing so a malformed edit during an incident keeps the running values. Every knob defaults to unlimited so shipping the knobs changes no deployment; egress counting runs whenever a state path is configured so calibration data accumulates before enforcement is ever turned on. Calibrated values, fleet-wide spend caps, TURN-side quotas, and the forwarded-bytes accounting taxonomy remain outside wiremux.
