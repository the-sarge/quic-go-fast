# Selected-Pair Owner Implementation Plan

**Date:** 2026-08-12
**Status:** Implemented by PR #1151
**Track:** 2 of 2 in the 2026-08-12 session-consumption and selected-pair program
**Depends on:** nothing — safe to start first
**Related:** ADR-0003, ADR-0006, ADR-0012; [`2026-08-09-turn-retry-connectivity-plan.md`](2026-08-09-turn-retry-connectivity-plan.md) (topology and `turnRetrySelected` stay there); CONTEXT.md **Probe**, **Authenticated probe**, **Selected candidate pair**
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** 2026-08-12 architecture review candidate 2; decide-mode grilling of 2026-08-12; in-plan slice decision audit below

## Goal

Make the selected candidate pair the only handoff currency from the probe/control race into the direct-upgrade protocol engine. Today a listener that sees the dialer's selected-pair frame while probing still running returns `probeResultFromSelectedPair`, a probe result with `succeeded: true`. After this track, that race reports a selected-pair observation, not a successful probe. Probe stays proof of reachability. Selected pair stays the synchronized packet path. Leverage: one pair type for dialer conversion and listener admission. Locality: later TURN retry cannot treat "we heard the pair" as "we proved the path."

## Current Shape (verified 2026-08-12 at `4ada940442c071f7da13c6f2f514ff383e7ac385`)

- Dialer path is honest: `selectedPairFromProbeResult` (`connect/selected_pair.go:49-55`) copies a real probe success into role-absolute form. `runDialer` then encodes that pair (`connect/upgrade_protocol_engine.go:91-92`).
- Listener path during the probe race is not: `probeCandidatePairsWithTerminalFallback` (`connect/upgrade.go:346-383`) cancels the local probe, unreads the control frame, and returns `probeResultFromSelectedPair(selectedPhase.SelectedPair, local.role)` (`:365-372`).
- `runListener` then ignores that fabricated success for selection. It decodes the selected pair from the unread frame and checks `pairPlan.allowsSelectedPair` (`connect/upgrade_protocol_engine_listener.go:52-65`). The fake probe result is only a "do not fall back" token plus an RTT fallback via `selectedProbeRTT(runtime.selected, d.probeResult.rtt)` (`connect/upgrade_protocol_engine.go:247`, `connect/upgrade_protocol_engine_listener.go:175`).
- `probeResultFromSelectedPair` sets `succeeded: true` (`connect/selected_pair.go:57-67`). That bit is what bypasses the post-race terminal-fallback gate (`connect/upgrade.go:202-206`) and reaches `directTransportHandoff`. `runListener` ignores the success bit for admission; the dispatcher is the load-bearing consumer. This slice replaces that success-bit gate with an explicit selected-pair-observation arm.
- `directTransportHandoff` (`connect/upgrade.go:404-421`) always constructs an engine from `candidatePairProbeResult`. There is no race-outcome type.
- `probeResultFromSelectedPair` (`connect/selected_pair.go:57-67`) exists to serve the lie. `TestSelectedPairProbeResultWireRoundTrip` (`connect/selected_pair_test.go:76-134`) round-trips through it. Selected-frame race tests that currently require `succeeded: true` are `connect/upgrade_terminal_fallback_test.go:589-591` and `:705-707`. Fail-closed selected-frame probe error is `:905-994`. Caller cancel without a selected frame is `:816-903`.
- Non-cancel probe errors during the selected-frame race already fail closed (`connect/upgrade.go:368-370`). The selected-frame arm fabricates on both cancel and `err == nil` (local probe already finished) (`:368-372`).
- TURN-retry `turnRetrySelected` is a separate profile type (`connect/turn_retry_codec.go:56-60`). No `CarrierTopology()` implementation exists yet; that is TURN Track 2 work.

## Decision

- **The probe/control race returns what happened.** An unexported race outcome distinguishes: local probe finished; a selected-pair control frame arrived (listener only); a peer fallback frame arrived; or an error. It does not set `candidatePairProbeResult.succeeded` unless a probe succeeded.
- **Selected pair is the handoff currency.** Dialer engine construction converts a real probe success with `selectedPairFromProbeResult`. Listener engine construction does not take a fabricated probe result. `runListener` continues to admit the pair from the control frame. Unread-and-replay of that frame may stay.
- **Keep local probe RTT as an engine fallback only on the real-probe arms.** Replace `directUpgradeProtocolEngine.probeResult` with the selected pair (dialer) plus `localProbeRTT` used only by `selectedProbeRTT`. When the selected-frame arm wins, the listener contributes no local probe RTT even if the joined probe already finished successfully; reported RTT is the frame's RTT, or zero when the frame omits it. That preserves today's fabricate-from-frame behavior.
- **Keep `selectedPairFromProbeResult`.** Delete `probeResultFromSelectedPair` and the shuttle half of `TestSelectedPairProbeResultWireRoundTrip`.
- **Do not change the protocol.** The listener may still accept the dialer's selected pair without finishing its own probe. Pair selection stays dialer-authoritative; the listener still validates `pairPlan.allowsSelectedPair`.

**Rejected alternative (do not do this):** Require the listener to finish a local probe before accepting the selected-pair frame. That changes the upgrade protocol and is not a deepening.

**Rejected alternative (do not do this):** Keep returning `succeeded: true` from the race and only rename the helper. The type still says a probe proved reachability.

**Rejected alternative (do not do this):** Fold `turnRetrySelected` into v1 `selectedPair`, or implement `CarrierTopology()` here. ADR-0012 and the TURN program own those.

**Non-goals:** no public `Negotiator.Upgrade` change; no wire-byte change; no topology classifier; no TURN-retry codec/probe merge; no change to pair ranking, candidate gathering, or the ADR-0006 transition tables; no change to terminal fallback as a separate blocking module.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | complete in PR #1151 | Probe/control race reports a selected-pair observation; engines no longer take a fabricated probe success | None | Removes `probeResultFromSelectedPair` |

## Implementation Slices

### Slice 1 — Stop fabricating probe success from a selected-pair frame

**What it delivers:** `probeCandidatePairsWithTerminalFallback` (or its replacement) returns an explicit race outcome. The post-race dispatcher at `connect/upgrade.go:192-206` proceeds to the listener engine when a selected-pair frame arrived, to the role engine when a local probe succeeded, and to terminal fallback otherwise. `directTransportHandoff` is no longer entered through a fabricated `succeeded: true`. `probeResultFromSelectedPair` is gone. Protocol bytes, fallback reasons, pair admission, and packet-socket ownership are unchanged.

**Existing-work disposition:** implemented by PR #1151.

**Blocked by:** None.

**Single owner after merge:** The probe/control race owns whether a probe succeeded versus whether a selected-pair frame arrived. `selectedPair` owns the synchronized pair handed to transport. The protocol engine owns phase transitions from that pair. `candidatePairProbeResult` owns only actual probe outcomes.

**Authority completeness:** No new persisted fact. Both production race exits, the post-race dispatcher at `connect/upgrade.go:202-206` (the destructive consumer of `succeeded`), both engine constructors, `selectedProbeRTT`, and every test that constructed `probeResultFromSelectedPair` are covered.

**Transitional-seam budget:** None. The shuttle is deleted in the same PR. Unread-and-replay is existing control-sequencer behavior, not a new seam.

**Blast radius:** `connect` package: `upgrade.go` race and handoff, `selected_pair.go`, both engine constructors, focused selected-pair and protocol-engine tests. Concurrency: the existing probe-vs-control select is unchanged in events, only in how the selected-frame arm is named. Failure modes: non-cancel probe error during the selected-frame race remains fail-closed; cancel remains proceed-to-listener. Public interface and wire bytes unchanged. Security: authenticated selected-pair admission stays on `pairPlan.allowsSelectedPair`. Untraced effects: none beyond the census in Current Shape. TURN retry is an explicit non-goal.

**Artifact classification:** The production race-outcome change is shipped behavior with intentionally unchanged observation. Focused race/engine tests are verification aids. This plan is process metadata.

**Representation contract:** Supported domain = the four race arms already implemented (probe done, listener selected-pair frame, peer fallback/other control frame, probe error) plus the two engine roles. Representation owner = the unexported race-outcome type and `selectedPair`. Guarantee = canonical-subset over those arms, not an open control-frame grammar (decode stays on the existing codec). Terminating evidence = one case per race arm, engine constructor/reference census showing `probeResultFromSelectedPair` is gone, existing protocol-engine tests adapted to the new construction, and `task verify`.

**Contract closure:** Triggered. Treating a selected-pair frame as probe success can send the listener into direct handoff on a fact the local probe did not prove, and the race has multiple independently reachable arms. Invariant: `candidatePairProbeResult.succeeded` is true only when the local probe succeeded; a selected-pair frame is a distinct observation that may still enter listener handoff. Enforcement owner: the probe/control race outcome constructor.

| Semantic class | Expected disposition | Enforcement owner | Evidence | Guard mutation | Status |
| --- | --- | --- | --- | --- | --- |
| Dialer local probe success | convert to `selectedPair`; run dialer engine | race + `selectedPairFromProbeResult` | existing dialer-engine happy path | n/a | covered |
| Listener local probe success, then selected frame | run listener engine; admit pair from frame; use local RTT only as `selectedProbeRTT` fallback | `runListener` | existing listener selected-admission tests | n/a | covered |
| Listener selected-pair frame during probe, local probe canceled | cancel probe; unread frame; proceed to listener engine; do **not** set probe succeeded; no local RTT | race selected-frame arm | new/rewritten race test that forbids `succeeded` | n/a | covered |
| Listener selected-pair frame during probe, local probe already finished successfully | discard the local probe result, including its RTT; unread frame; proceed to listener engine; do **not** set probe succeeded | race selected-frame arm | rewritten race test plus omitted-frame-RTT case | n/a | covered |
| Selected-pair observation at the post-race dispatcher | enter listener engine without using `succeeded` as the handoff token | race outcome + `upgrade.go:192-206` | rewritten selected-frame race test | n/a | covered |
| Selected-pair frame omits RTT | reported `ProbeRTT` stays zero; do not substitute listener-local probe RTT | selected-frame arm RTT rule | one focused omitted-frame-RTT preservation case | n/a | covered |
| Non-cancel probe error during selected-frame race | return the probe error; no handoff | race selected-frame error arm | preserve `upgrade.go:368-370` plus `upgrade_terminal_fallback_test.go:905-994` | n/a | covered |
| Probe done, unsuccessful, no selected-pair frame | terminal fallback; do not enter handoff | dispatcher replacing `upgrade.go:202-206` | existing probe-failed race/engine coverage | n/a | covered |
| Probe done with error/cancel, no selected-pair frame | return probe error / fail-closed; no handoff | race `probeDone` arm | `TestProbeCandidatePairsWithTerminalFallbackCallerCancellationReleasesHeldListener` | n/a | covered |
| Peer fallback / other control frame during probe | terminal fallback; not a selected pair | race fallback arm | existing terminal-fallback probe-race coverage | n/a | covered |
| Selected pair not in `pairPlan` | listener invalid-selected event; no direct success | `allowsSelectedPair` | existing listener invalid-selected tests | n/a | covered |
| TURN-retry selected pair | unchanged separate type | TURN program | n/a | n/a | non-goal |

**Evidence budget:** One focused case per race arm above, including one omitted-frame-RTT preservation case on the selected-frame arm; adapt existing engine tests to construct with selected pair + local RTT; delete shuttle-only assertions; at most one optional mutation of the selected-frame arm if a test would otherwise pass while still setting `succeeded`; no new platform, NAT, or protocol-fixture family. Review budget = one initial review plus at most one replacement. Terminate when `probeResultFromSelectedPair` has zero references, every race arm has a disposition, and `task verify` passes.

**TDD and preservation evidence:** First write or rewrite a listener race test that fails if the selected-frame arm returns `candidatePairProbeResult{succeeded: true}`. Then introduce the race outcome and delete the shuttle. Keep `TestSelectedPairLocalRemoteByRole`, RTT wire tests, `allowsSelectedPair` tests, and managed dialer/listener engine tests green after mechanical constructor adaptation.

**Dispatch context budget:** This plan; `connect/upgrade.go` race, post-race dispatcher (`:192-206`), and handoff; `connect/selected_pair.go`; `connect/upgrade_protocol_engine.go` and `_listener.go` constructors; `connect/selected_pair_test.go`; `connect/upgrade_terminal_fallback_test.go` (selected-frame, fail-closed, and caller-cancel arms); and the named engine tests. ADR-0003/0006 as invariants. No TURN governing diff. Fits one fresh context.

**Slice decision audit:** Strongest further split — change the race return without touching engine constructors; rejected because handoff would still pass a probe-success token into the engine and leave two owners for "why are we in handoff." Strongest adjacent merge — Track 1 consume-trigger; rejected because it is a root-package settlement change with a different owner. Blocking edges: none; Track 1 is parallel-safe. TURN topology is a different program.

**Stop conditions:** Stop if preserving behavior requires a public Upgrade change, a wire-byte change, requiring local probe success before selected-pair admission, merging `turnRetrySelected`, implementing `CarrierTopology()`, or growing beyond one reviewable PR. Stop if listener-without-local-probe admission cannot be preserved without keeping `candidatePairProbeResult.succeeded` as the handoff token. Stop if engine construction changes require ADR-0006 table edits.

## Acceptance Criteria

- [ ] `probeResultFromSelectedPair` is absent. Domain = current `connect` production and test source; owner = this slice; guarantee = canonical-subset over repository references; evidence = reference census.
- [ ] A listener selected-pair frame during probe does not set `candidatePairProbeResult.succeeded`. Domain = that race arm; owner = race outcome constructor; guarantee = universal over that arm; evidence = focused race test.
- [ ] Dialer handoff still converts a real probe success through `selectedPairFromProbeResult`. Domain = dialer success path; owner = dialer engine construction; guarantee = example-level; evidence = existing dialer-engine happy path.
- [ ] Listener still admits the pair from the control frame via `pairPlan.allowsSelectedPair` and may do so without a finished local probe. Domain = listener selected-admission; owner = `runListener`; guarantee = example-level; evidence = existing plus rewritten race tests.
- [ ] No public `Negotiator.Upgrade`, wire-byte, fallback-reason, or packet-ownership change.

## Validation Gates

```bash
GOTOOLCHAIN=local go test ./connect -count=1 -run 'SelectedPair|ProbeCandidate|DialerEngine|Listener|Upgrade'
GOMAXPROCS=1 GOTOOLCHAIN=local ./scripts/run-go-test-require-match.sh -race -run '^(TestDialerEngine.*|TestNegotiatorUpgradeDialerEngineHappyPath)$' -count=1 ./connect
task verify
```

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) and the certification lanes in [`docs/CI.md`](../CI.md). Vocabulary is CONTEXT.md **Probe**, **Authenticated probe**, and **Selected candidate pair**. Do not reopen ADR-0006's one transition authority or ADR-0012's separate TURN-retry profile.
