# ADR-0007: GridCast as a Named Consumer

## Status

Accepted 2026-07-09.

This ADR records a consumer's requirements against wiremux's contracts. It grants the consumer no design authority: the requirements are stated as properties, and wiremux chooses every mechanism. Requested-track sequencing belongs to [Tracking: consumer contract program (wiremux tracks)](https://github.com/GridSwarm/wiremux/issues/551).

## Context

The family ADR (`org-docs:adr-0001-four-product-family.md`) establishes wiremux as the connectivity primitive that identity products and external consumers build on, and ADR-0001 (DP1) names consumer evidence — codemux, tapmux — as validation for wiremux's seams. Until now no consumer outside the family's identity tier has recorded its requirements in wiremux's own decision record.

**GridCast** ([GridCastIO/gridcast](https://github.com/GridCastIO/gridcast)) is a resumable file-transfer CLI built on rateless (RaptorQ, RFC 6330) coding: the sender sprays fungible coded symbols, the receiver banks symbols until each block decodes, and any interruption — including kill −9 and a days-later resume from a different network — is recoverable without range negotiation. Its approved design ([2026-07-08-gridcast-design.md](https://github.com/GridCastIO/gridcast/blob/main/docs/superpowers/specs/2026-07-08-gridcast-design.md), decision D5) states its transport requirement minimally: a bidirectional message pipe; unreliable-unordered datagram mode preferred; reliable degrades gracefully.

GridCast's seam inventory (validated against wiremux `origin/main` @ `8496de9`, 2026-07-09) found every requirement except one satisfied by existing surface. The exception is the datagram mode: the generic transport contract (`connect.Session.Dial`/`Listen` → `io.ReadWriteCloser`) is streams-only, so an unreliable message primitive is a contract change, not a QUIC flag.

## Decision

### DP1: GridCast is a named consumer of these existing contracts

GridCast v1 builds on, and its resumability story depends on, the following surface as it exists today. Changes here affect a named consumer and should be weighed accordingly (the consumer-contract program's compatibility gates already treat these as load-bearing):

- **The Wire bidi stream.** `wiremux.Dial` → `*Wire` as an authenticated encrypted `io.ReadWriteCloser`; GridCast v1 carries its entire protocol — control messages and coded-symbol records, multiplexed by self-delimiting frames — over this single stream.
- **The `AuthContext` seam for consumer-assembled resumption.** `connect.AuthContext` as a symmetric-PSK interface, `StaticAuth` accepting a fully-formed context with no live handshake, and the HKDF `Exporter` for deriving transfer-scoped secrets. GridCast persists an exporter-derived resumption secret at pairing and, on resume, assembles a fresh `AuthContext` (fresh directional keys and session binding per attempt — never reusing keys against the zero-based AES-GCM nonces) around a fresh caller-supplied rendezvous ID.
- **Rendezvous by opaque caller-supplied ID with no server-side session state**, which is what makes days-later meet-again-from-a-secret possible at all.
- **Teardown-error identities (W1) and the rendezvous disposition vocabulary (W2)** for kill/resume error classification and fail-closed handling of spent-vs-retryable rendezvous outcomes.

### DP2: Requested track — an unreliable-unordered message primitive

GridCast requests, as a track proposed against [Tracking: consumer contract program (wiremux tracks)](https://github.com/GridSwarm/wiremux/issues/551) and filed as [Datagram track: unreliable-unordered message primitive on the transport contract (GridCast consumer request)](https://github.com/GridSwarm/wiremux/issues/624):

> An **unreliable-unordered message primitive on the transport contract**, payload ≥ ~1200 B per message, sharing the connection's congestion control.

The `≥ ~1200 B` phrase records the original consumer shorthand, not a portable
wiremux minimum. The QUIC audit for ADR-0009 found that a literal 1200-byte
consumer payload is not portable: the accepted current configuration provides
1239 bytes after DATAGRAM-frame and wiremux framing, while the QUIC protocol-
minimum packet size can provide only 1159. ADR-0009 therefore resolves the
requirement as exact per-carrier discovery: GridCast sizes its complete coded-
symbol record to `Datagrams.MaxPayload()`, uses the Datagram plane only when
that record fits, and otherwise uses a smaller symbol or its reliable carrier.
A 1024-byte symbol
has 135 or 215 bytes of headroom at the two audited ceilings; a 1152-byte
symbol remains conditional on GridCast metadata fitting the 7- or 87-byte
remainder.

Properties, not mechanisms. RFC 9221 QUIC datagrams inside the existing connection are the obvious candidate, but wiremux owns the design — including how the primitive appears on the generic transport contract for transports that will never support it.

Why the properties are what they are: rateless symbols are fungible, so
retransmission and ordering are pure waste to this consumer — a lost symbol is
replaced by a *fresh* one, never re-sent. GridCast's sizing invariant is that
one complete symbol record fits one Datagram; splitting it across loss-atomic
messages reintroduces the loss amplification rateless coding eliminates. The
original `≥ ~1200 B` phrasing aimed at that around-path-MTU budget, while the
accepted exact query makes the invariant enforceable across real carriers.
Congestion-control sharing is the fairness half of D1's split — network
fairness inherited, usefulness scheduling owned by the consumer.

**This is not a v1 blocker.** GridCast v1 ships over the reliable Wire stream by its own decision ([gridcast#5](https://github.com/GridCastIO/gridcast/issues/5)): its symbol record is byte-identical to the future datagram payload, and carrier capability is negotiated in its hello, so datagram carriage lands later as a carrier swap with zero protocol revision. What streams cost the consumer is loss-efficiency (QUIC retransmits bytes the sender would rather replace), not correctness.

### DP3: Explicitly not requested

- **A multi-stream surface.** GridCast's conceivable multi-stream use is subsumed by DP2, and a multi-stream Wire is a larger change than it looks (per-stream key derivation and nonce domains for the directional AES-GCM channels). GridCast's spec records multi-stream + RESET_STREAM-per-decoded-block only as its named fallback if the DP2 track is refused or stalls indefinitely.
- **A congestion-control or pacing API.** A datagram primitive inside the QUIC connection inherits its congestion control; that alone satisfies DP2's fairness property.
- **Raw UDP or any transport beyond the contract.** Transports wiremux grows later (WebRTC data channels, WebTransport) slot under GridCast's symbol spray with zero protocol change, per its D5.

### DP4: Consumer-tier boundaries

GridCast holds requirements against wiremux and codemux only. keymux gains GridCast as its second named consumer at GridCast's trusted-peers milestone (v2), not before; org-docs is legacy and records nothing. The consumer-side paper trail for this ADR is [GridCastIO/gridcast#7](https://github.com/GridCastIO/gridcast/issues/7).

## Consequences

- wiremux gains its first recorded external-tier consumer contract; the consumer-contract program's binding rules now protect a consumer that exists by name, not by hypothesis.
- [ADR-0009](adr-0009-optional-datagram-capability.md) accepts the optional
  carrier-bound Datagram design, now implemented for supporting direct QUIC
  Wires. GridCast adoption remains separate follow-up work; its existing
  carrier-capability negotiation absorbs the feature without a protocol
  revision. ADR-0009's exact `MaxPayload` discovery supersedes treating DP2's
  original `≥ ~1200 B` shorthand as a portable wiremux floor.
- Until GridCast adopts the capability, nothing in either project breaks:
  GridCast continues on the Wire stream and its named fallback remains a
  consumer-side spec note, not a wiremux obligation.

## Amendment (2026-08, [#1317](https://github.com/GridSwarm/wiremux/issues/1317))

The 1239-byte direct Datagram ceiling cited above, and any headroom figure derived from it, are superseded: the direct `/2` public ceiling is now 1191 bytes (see [`docs/COMPATIBILITY.md`](../COMPATIBILITY.md)). GridCast's stream path is unaffected by the change.
