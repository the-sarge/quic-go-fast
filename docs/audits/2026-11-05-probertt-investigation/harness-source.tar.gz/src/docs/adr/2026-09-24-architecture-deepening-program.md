# Architecture Deepening Program — 2026-09-24

**Stable identity:** AH-20260924
**Status:** Complete; A1, B1, C1, D1, E1, F1, R1 and RR1 complete; no remaining implementation frontier
**Tracking issue:** pending
**Audit history:** [2026-09-24-architecture-handoff-audit.md](2026-09-24-architecture-handoff-audit.md)

## What this is

This packages the accepted grilled architecture decisions into six original implementation tracks and one evidence-only relay investigation, extended by the scoped RR relay completion repair after R1. Each current plan is normative; each slice maps to one child issue, one intended PR and one OmniFocus task. Prior temporary HTML is not required dispatch context. Historical review chronology belongs in audit artifacts, not this index.

## Outcomes that require no implementation

The [no-code decision ledger](2026-09-24-architecture-no-code-decisions.md) records rejected and deferred directions, their reasons and reopening conditions. No generic framework, new public interface, whole-attempt merge, native constructor rewrite or workload runner is approved. Relay repair is limited to the RR1 contract; no automatic implementation dispatch is approved. Existing settled ADRs remain governing.

## Tracks, dependencies, and frontier

| ID | Track | Plan | Parent issue | Blocked by | Slices | Status |
| --- | --- | --- | --- | --- | --- | --- |
| A | Settlement result admission | [A1](2026-09-24-settlement-result-admission-plan.md) | pending | None | 1 | COMPLETE |
| B | Worker reply custody | [B1](2026-09-24-worker-reply-custody-plan.md) | pending | None | 1 | COMPLETE |
| C | Wire-owned migration transitions | [C1](2026-09-24-wire-migration-transitions-plan.md) | pending | None | 1 | COMPLETE |
| D | Ordered after-choice classification | [D1](2026-09-24-ordered-after-choice-classification-plan.md) | pending | None | 1 | COMPLETE |
| E | Static selected-option validation | [E1](2026-09-24-selected-option-validation-plan.md) | pending | None | 1 | COMPLETE |
| F | Retained control-decoding facts | [F1](2026-09-24-retained-control-decode-facts-plan.md) | pending | None | 1 | COMPLETE |
| R | Relay completion characterization | [R1](2026-09-24-relay-completion-characterization-plan.md) | pending | None | 1 | COMPLETE; [result](../research/2026-09-24-relay-completion.md) |
| RR | Relay completion repair | [RR1](2026-09-24-relay-completion-repair-plan.md) | pending | R1 (complete) | 1 | COMPLETE |

A1, B1, C1, D1, E1, F1, R1 and RR1 are complete: A1 centralizes settlement result admission; B1 owns validated worker reply retention and final transfer; C1 moves migration transitions and managed close onto Wire; D1 centralizes after-choice context/deadline classification in internal/relaycandidate; characterization demonstrated early proxy completion and RR1 repairs the owned-worker completion boundary. E1 centralizes pure selected-option validation for actual and prospective selection. F1 retains payload validity in the typed control decoders while preserving phase and attempt authority. A1, B1, C1, D1, E1, F1 and RR1 enable no additional successor; no open cross-track blocking edges exist.

No accepted implementation slices remain.

The program has no successor dispatch. Adjacent deferred or rejected directions remain governed by the no-code decision ledger.

## Rules that bind every track

Follow the shared `_shared/REVIEW-LOOP.md` and `_shared/CONTRACT-CLOSURE.md` baselines supplied by `$implement-architecture-slice` (reachable as `../_shared/` from its skill directory), composed with the repository [review overlay](../REVIEW-LOOP.md), [CI policy](../CI.md), [conventions](../CONVENTIONS.md), and root [AGENTS.md](../../AGENTS.md). No repository contract-closure overlay exists; use the shared baseline directly. The baselines govern artifact/representation gates, finite evidence, semantic-family closure, review and verification-aware approach stops, exact-head local certification, same-head hosted CI, merge, journal and pointer-only tracking. Do not copy or strengthen them in this plan.

Preserve public API/CLI/wire schemas and existing behavior except track B’s stated retention improvement and RR1’s joined-completion correction. There are no newly authoritative persisted facts. The plans name the single owners, supported domains, guarantee levels, artifact classes, finite evidence, context bounds and stop conditions. No plan creates a maintained analyzer, universal harness or CI gate. The existing measurement worker’s bounded custody maintenance is confined to track B; relay characterization remains disposable evidence; RR1 owns the narrow runtime repair.

Use the exact default-branch plan commit in child issues. Use `pending` here for pre-publication issue links; issues and the tracking issue own the live mapping. Do not create a new authoritative plan version solely to backfill issue IDs. Mirrors carry pointers and current state; code-head certification remains separate.

Dispatch each verified frontier child to a fresh agent with `$implement-architecture-slice`; clear context between children. That skill may perform same-child scoped re-audits only while representation, outcome and one-PR boundary remain intact. A broader change requires a decision or scoped handoff. Per slice: review loop → exact-head certification → same-head CI → merge → `$append-dev-journal` → reconcile pointers and complete slice task.
