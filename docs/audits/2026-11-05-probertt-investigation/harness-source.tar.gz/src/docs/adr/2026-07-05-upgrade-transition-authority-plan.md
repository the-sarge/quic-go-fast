# One Transition Authority for Direct Upgrade — Implementation Plan

**Date:** 2026-07-05
**Status:** Accepted; original implementation by PRs #472, #475, #477, #482, and #486; final conformance by issues #825, #828, and #829
**Track:** 3 of 3 in the 2026-07-05 upgrade deepening program
**Depends on:** Track 1 PR 2 (frames must decode into domain types before
the engine is rebuilt); Track 2 recommended first (reason resolution
call sites are touched here)
**Related:** ADR-0006 D3/D4 (this track implements them); ADR-0003 and
PRD-0001 convergence semantics (settled — behavior must not change)

## Goal

Co-locate the **direct upgrade** state machine. The ordering invariant of
upgrade control — ready → commit → accepted → converged → confirmed, with
the **direct upgrade commit point**, **pre-commit transport window**,
**split-brain** prohibition, and **terminal fallback exchange**
(CONTEXT.md) — currently lives in two transition tables, four peer-frame
policies, one classifier, and imperative branches across ~10 files sharing
one mutable struct. After this track there is one role-parameterized
transition authority and one resource owner; a maintainer answers any
interleaving question from one table plus one cleanup module. The public
interface is unchanged: `Negotiator.Upgrade(ctx, opts...)`.

## Final Conformance Boundary (2026-07-31)

The original five-PR implementation established the table, engine, and owner vocabulary but left dialer and listener imperative authorities alongside them. The #825 → #828 → #829 conformance sequence finished ADR-0006 D3: `attemptResources` first became the persistent lifecycle/result/disposal authority, then the dialer and listener synchronized paths moved onto the same `directUpgradeProtocolEngine` and transition table.

The shipped boundary is one role-parameterized table and engine for 43 dialer rows and 82 listener rows, including selected-frame, pending Listen, pending Accept, ready/commit interleavings, post-commit phases, and success. There is no role handoff driver, listener post-ready switch, compatibility alias, or branch-local terminal composition.

Two deliberately separate authorities remain: `terminalFallbackExchange` owns the blocking terminal-fallback rendezvous, while `controlFrameSequencer` serializes control-frame reads and preserves frame-vs-work races. Engine actions choose these operations and the three typed `attemptResources` terminal dispositions without absorbing their protocols or performing resource disposal.

## Current Shape (verified 2026-07-05)

Dispersed authorities over the same invariant:

- Post-commit phase order table: `connect/upgrade_phase.go:25-40`
  (listener sends accepted/confirmed, awaits converged; dialer mirrors).
- Listener post-ready transition table (~20 rows):
  `connect/upgrade_listener_postready.go:72-205`, driven by
  `runPostReady` (`:258-375`) and hand-checked re-lookups
  (`nextListenerPostReadyState` calls at `:416,423,433,472,480,486,492`).
- Commit-frame classifier: `classifyListenerCommitResult`
  (`connect/upgrade_phase.go:58-94`).
- Four terminal-fallback peer policies:
  `connect/upgrade_terminal_fallback.go:246-288`, dispatched through
  `exchangeWithPolicy` (`:125-216`).
- Convergence engine: `postCommitConvergenceDriver`
  (`connect/upgrade_convergence.go:13-132`) with role callbacks wired
  separately by `upgrade_dialer.go:164-186` and
  `upgrade_listener.go:232-263`.
- Cleanup helpers with per-path composition: `abortPendingTransportAccept`,
  `abortTransportAccept`, `abortTransportAcceptForFallback`,
  `closeAcceptedTransport`, `closeAcceptedTransportForFallback`
  (`connect/upgrade.go:816-892`), `closeCommittedPacketConn`
  (`upgrade.go:806-810`), `abortUpgradeControlExchange`
  (`upgrade.go:917-929`), `closeTransportSessionWithTimeout`
  (`upgrade.go:251-255`), `closeDirectUpgradeRelay` (`upgrade.go:909-915`),
  plus the dialer's inline `closeSession`/`stopPendingDial`/`closeStream`
  closures (`upgrade_dialer.go:114-151`).
- Shared mutable state: `directUpgradeAttempt` (`upgrade.go:47-54`)
  threaded into `newDialerUpgradeHandoff`, `newListenerUpgradeHandoff`,
  `newTerminalFallbackExchange`.

Tests are heavy but sit past the interface: `upgrade_handoff_test.go`
(~3,269 lines), `upgrade_listener_postready_test.go`,
`upgrade_convergence_test.go`, `upgrade_terminal_fallback_test.go`,
`upgrade_phase_test.go` — all `package connect`, driving unexported
handoff methods directly.

Prior art to build on, not discard: the post-ready table itself was the
product of issue #412 (2026-07-03 program) and is the *shape* this track
generalizes; #426/PR #449 already simplified its lookup surface.

## Decision

One transition authority plus one resource owner, all in package `connect`
(ADR-0006 D4 — no subpackage; a `connect/internal/upgrade` package would
need the exported contract types and create an import cycle):

1. **Unified table:** `upgrade_protocol.go` contains a single role-parameterized (role, state, event) → (next state, action) table covering synchronized selected-pair, ready, commit, post-commit, fallback-selection, fail-closed, and success branches. Frame classification remains beside the table where it is state-dependent; the blocking fallback protocol remains separate.
2. **Resource owner:** `attemptResources` owns Session, transport listener, accepted or dialed stream, packet socket, relay channel disposition, operation results, and the commit/transfer facts. It exposes idempotent, path-aware `settleRelay`, typed `failClosed`, and `succeedDirect` operations; table actions register facts and request those operations without composing cleanup.
3. **Engine:** `directUpgradeProtocolEngine` uses one cursor, runtime, action representation, and post-commit loop for both roles. Pre-offer setup remains imperative in `upgrade.go`, while `terminalFallbackExchange` and `controlFrameSequencer` retain their narrow independent authority.

Frozen contracts (behavior-identical refactor; each needs a named test):

- Five-phase convergence order; asymmetric success forbidden.
- Pre-commit failures may settle relay via terminal fallback exchange;
  post-commit failures fail closed; a peer commit observed during the
  terminal fallback exchange fails closed
  (`terminalFallbackPeerFailClosedCommitted`).
- Packet-socket ownership: bare error before commit = caller still owns
  the socket; `ErrUpgradeTransportNotConverged` (possibly joined with a
  cause) after commit = socket closed by Upgrade. Error identities and
  wrapping shapes are frozen.
- Accept must be pending before ready is observable
  (`upgrade_listener.go:92-94`).
- An already-completed accept wins over timeout/cancel at signal
  boundaries (`upgrade_listener_postready.go:288-320`).
- Fresh owned-transport budgets derive from the probe timeout
  (`newOwnedTransportBudgetContext`, `upgrade.go:735-737`).
- The listener's selected-pair `unread` during the probe race
  (`upgrade.go:362-374`) keeps wire order via the sequencer.

**Rejected alternative (do not do this):** one mega-table that also
covers pre-offer setup. Setup is sequential, not event-driven; rows would
add complexity without locality.

**Rejected alternative (do not do this):** moving the machine into a
`connect/internal/upgrade` subpackage — import cycle, and ADR-0006 D4.

Non-goals: wire changes; public API changes; deepening the sequencer's own
interface (review candidate D — out of scope; the engine simply becomes
its sole consumer); the options/consume-hook candidate F.

## Original Implementation Slices (Historical)

These slices record the original 2026-07-05 implementation sequence. The final conformance work and current boundary are recorded above; the role-handoff collapse was completed by #828 and #829 after the persistent owner landed in #825.

Each PR must land behavior-identical and green on the full gate.

### PR 1 — `attemptResources` owner

Introduce the resource owner and migrate the `abort*/close*` helpers and
dialer closures onto it mechanically. Gate: existing tests pass
unmodified (this PR earns no test rewrites).

### PR 2 — Unified event classification

Merge `classifyListenerCommitResult` and the four terminal-fallback
policies into one classifier from (state, frame-or-error) to protocol
event. TDD: table-test the classifier exhaustively first, encoding the
current policies' outputs; then swap call sites.

### PR 3 — Unified transition table + engine

Merge the post-commit order table and the post-ready table into the
role-parameterized table; replace `postCommitConvergenceDriver` with the
engine loop. Add the completeness test: enumerate (role, state, event)
and assert every pair is either a row or explicitly impossible. TDD:
write transition-table tests (pure, no goroutines) before wiring the
engine.

### PR 4 — Collapse the role handoffs

Fold `upgrade_dialer.go`, `upgrade_listener.go`, and
`upgrade_listener_postready.go`'s imperative drivers into engine rows and
actions. Delete `upgrade_phase.go` and `upgrade_convergence.go` as
separate authorities.

### PR 5 — Test migration audit

Complete the scenario-mapping checklist (rule below), delete superseded
internal test files, keep protocol-level tests through
`Negotiator.Upgrade` plus the table/classifier tests. Re-run the
ready-commit race test under `-race` 100x (precedent: PR #449
validation).

**Scenario-mapping rule (binding):** before any existing test file is
deleted, its PR description lists every scenario the file covered and
names the replacement test for each. No scenario is dropped silently.

## Acceptance Criteria

- Exactly one transition table remains:
  `grep -rn "listenerPostReadyTransitions\|dialerPostCommitPhaseOrder\|listenerPostCommitPhaseOrder\|terminalFallbackPeerPolicy" --include="*.go" .`
  returns nothing (excluding `.git-worktrees/`, `.ras/`).
- The completeness test expands the table across every concrete role/state/event combination, requires exactly one reachable match or an explicit impossibility, and rejects missing and overlapping fixtures; no default-branch fall-throughs decide protocol outcomes.
- Every frozen contract above has a named test; the packet-socket
  ownership error shapes (bare vs `ErrUpgradeTransportNotConverged`) are
  asserted explicitly.
- No exported identifier of package `connect` added, removed, or changed;
  golden wire frames unchanged.
- Scenario-mapping checklists exist in the PRs that deleted test files.

## Validation Gates

```bash
go test ./connect/...
go test -race -count=100 -run 'ReadyCommit|ListenerEngine|Handoff' ./connect/
task verify
```

## Operating Discipline

Follow `docs/REVIEW-LOOP.md` for every PR. Stop conditions: if any frozen
contract cannot be reproduced by the table shape — e.g. a path where
cleanup genuinely cannot be expressed as settle-relay / fail-closed /
succeed-direct — STOP and check with the operator; that is an
approach-level finding against ADR-0006 D3, not something to special-case
around. This track is race-sensitive: never weaken a flaky test to pass;
diagnose it. Vocabulary: CONTEXT.md terms throughout — **listener
transport readiness**, **direct upgrade commit point**, **pre-commit
transport window**, **transport phase failure**, **split-brain transport
state**, **terminal fallback exchange**.
