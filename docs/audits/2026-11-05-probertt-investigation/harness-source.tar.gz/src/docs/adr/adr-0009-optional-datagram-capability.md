# ADR-0009: Optional Carrier-Bound Datagram Capability

## Status

Accepted.

## Context

The reliable `Wire` byte stream remains sufficient for wiremux v1, but
[ADR-0007](adr-0007-gridcast-consumer.md) records a concrete consumer that can
avoid waste when an established transport also carries bounded atomic messages
without retransmission or ordering. GridCast replaces a lost rateless symbol
with a fresh symbol; retransmitting or ordering the old one consumes bandwidth
without improving correctness.

The change cannot be a QUIC-only flag. `Wire` is transport-agnostic, relay
fallback and stream-only custom transports must keep working, and future
WebRTC, WebTransport, or relayed carriers may or may not satisfy the requested
properties depending on the path they actually establish. The capability must
therefore describe an established carrier's semantics rather than its
transport name or whether the path is direct.

The design is grounded in:

- [QUIC Datagram constraints for issue 624](../research/issue-624-quic-datagram-constraints.md),
  covering RFC 9221 and the pinned quic-go API, queueing, payload, negotiation,
  ownership, and proof limits.
- [Cross-transport Datagram seams](../research/issue-714-cross-transport-datagram-seams.md),
  covering QUIC, WebRTC, WebTransport, MASQUE, carrier identity, and
  congestion-policy extension points.
- [Unreliable Datagram relay architectures](../research/issue-624-unreliable-datagram-relays.md),
  establishing why the current TLS/TCP relay cannot qualify while future
  TURN/UDP, WebRTC, MASQUE, or purpose-built relay carriers might.
- [QUIC Datagram conformance evidence](../research/issue-624-quic-datagram-conformance.md),
  binding the first implementation to its selected path, security,
  retransmission, congestion, payload, and executable-test evidence.
- The consumer-shaped prototype preserved at
  [`internal/prototype/issue710`](https://github.com/GridSwarm/wiremux/tree/87d2605d8d5ac96bbe03bb2f66dcf52eac3442fc/internal/prototype/issue710),
  which validated discovery, exact payload reporting, context-bearing I/O,
  concurrent reliable use, and aggregate close ergonomics before its
  throwaway code was removed.

## Decision

### Public surface

`Wire` gains optional comma-ok discovery of a concrete borrowed Datagram
handle:

```go
func (w *Wire) Datagrams() (*Datagrams, bool)

func (d *Datagrams) MaxPayload() int
func (d *Datagrams) Send(ctx context.Context, payload []byte) error
func (d *Datagrams) Receive(ctx context.Context) ([]byte, error)
```

Capability absence is normal: `Datagrams` returns `(nil, false)` while the
reliable Wire remains fully usable. `Datagrams` is a concrete root-package
type, not a consumer-implemented interface. It has no independent `Close`;
`Wire.Close` is the sole aggregate lifetime authority.

Discovery is a lifetime-stable snapshot. Repeated successful calls return the
same non-nil `*Datagrams` pointer, including after local or peer teardown, and
`MaxPayload` keeps its frozen value. Teardown does not turn presence into
absence; calls on that handle fail with `ErrWireClosed`.

On the Datagram surface, `ErrWireClosed` means that this borrowed Datagram view
is no longer usable. It covers aggregate Wire close or peer teardown and the
narrower case where a terminal reliable-read outcome closes only the
bidirectional Datagram gate while reliable writes remain usable. It does not,
by itself, assert that every reliable direction is closed. The implementing PR
updates the sentinel's root-package documentation with this plane-specific
meaning.

`MaxPayload` is the lifetime-fixed exact **local outbound** ceiling for the
complete consumer payload after wiremux framing. It governs this peer's send
admission, not inbound delivery. Oversize sends fail locally, synchronously,
and without fragmentation or connection damage with `ErrDatagramTooLarge`.
Messages preserve their boundaries, including an empty consumer message, and
are delivered whole or not at all. No ordering promise exists, including for
sequential sends from one goroutine.

The handle is safe for concurrent use. Senders block only until admission to a
small bounded wiremux-owned queue and may cancel that wait with their context.
wiremux copies the payload on admission. Success means only accepted for
possible transmission, never transmitted or delivered. Receivers are
single-flight inside wiremux; concurrent callers are serialized with
context-aware waiting, and each delivered message reaches exactly one caller
as a fresh caller-owned slice. wiremux adds no receive queue beyond the
transport's bounded buffer.

`Wire.Close` closes the public Datagram gate before the existing aggregate
teardown. Pending and future Datagram calls then fail with `ErrWireClosed`, and
admitted unsent messages may be discarded. Graceful or abrupt peer teardown
also converges on `ErrWireClosed` while preserving the underlying cause. There
is no Datagram EOF, queue-full, overflow, absence, or Datagram-only terminal
error. `ErrDatagramTooLarge` and context cancellation are non-terminal.

### Transport seam and extraction boundary

The required `connect.Transport`, `connect.Session`, and
`connect.TransportListener` method sets remain unchanged. A supporting
transport optionally implements this surface on the stream returned by
`Session.Dial` or `TransportListener.Accept`:

```go
type DatagramCarrier interface {
    Lifetime() context.Context
    MaxDatagramPayload() int
    SendDatagram(ctx context.Context, payload []byte) error
    // ReceiveDatagram returns either a non-nil payload and nil error,
    // or a nil payload and non-nil error.
    ReceiveDatagram(ctx context.Context) ([]byte, error)
}

type DatagramCapable interface {
    DatagramCarrier() (DatagramCarrier, bool)
}

type UpgradeResult struct {
    Stream         io.ReadWriteCloser
    Datagrams      DatagramCarrier
    Path           UpgradePath
    SelectedPair   *CandidatePair
    ProbeRTT       time.Duration
    FallbackReason UpgradeFallbackReason
}
```

`Datagrams` is normatively the second exported field, between `Stream` and
`Path`, matching PRD-0001.

Each upgrade role asserts and validates `DatagramCapable` immediately when its
transport result arrives: the dialer after post-commit `Session.Dial`, and the
listener whenever `TransportListener.Accept` completes, which may be before or
after the listener observes `commit`. Validation happens before stream wrapping
or the role's next control transition. Any non-nil Dial/Accept stream, including
stream-plus-error, is an independent packet-socket ownership boundary even
before observed `commit`; local commit is the other boundary. A malformed
optional result therefore closes only the materialized stream, whose
synchronous Close owns the exact socket, and returns
`ErrUpgradeTransportNotConverged` with zero result and no relay fallback. Relay
fallback remains possible only before both local commit and any non-nil
Dial/Accept stream.

The validated local carrier is retained separately through the post-commit exposure agreement below and copied into `UpgradeResult.Datagrams` only when both roles agree presence. The explicit result field is required because `terminalListenerOwnedStream` deliberately forwards only `Read`, `Write`, and `Close`. Root `newWire` snapshots that field during construction, builds and stores the one lifetime-stable `*Datagrams` handle from it, and never tries to rediscover `DatagramCapable` on `UpgradeResult.Stream`. Root then supplies the public queueing, copy, framing, serialization, fixed-ceiling, and error guarantees. After optional-interface extraction, both roles replace the transport-returned stream with a reliable-only wrapper that forwards exactly `Read`, `Write`, and `Close`. `UpgradeResult.Datagrams` is the exclusive lower capability-exposure surface; `UpgradeResult.Stream` must never satisfy `DatagramCapable`, including when pairwise agreement resolves capability absence.

`Lifetime` returns one non-nil cause-bearing context with a non-nil `Done`
channel. It is canceled exactly once when the established carrier becomes
terminal, including idle local close, peer teardown, or transport failure;
`context.Cause` then returns the terminal cause. Per-call cancellation,
oversize rejection, and permitted Datagram loss do not cancel it. Root wiremux
monitors this context from Wire construction and serializes the resulting
closed gate with send admission: once root observes carrier termination, no
later `Send` can report successful admission. The same observation starts
aggregate teardown so the reliable and Datagram planes keep one fate.

Reliable-read outcomes that make the optional bidirectional Datagram surface
unusable close only the Datagram gate after any returned bytes are reported:
authenticated peer close (`io.EOF` from `Wire.Read`), `ErrWireClosed`, channel
authentication or truncation failure, and transport stream-reset/closure
identities. Root preserves the cause and releases Datagram workers, but does
not initiate aggregate teardown or close the independent reliable write
direction while carrier `Lifetime` remains active. A subsequent reliable
`Write` keeps today's behavior. Other direction-local or per-call errors do not
silently gain Datagram-gate meaning: in particular,
`channel.ErrStreamEmptyDataFrame` remains a latched read-side error that does
not poison reliable writes or the Datagram plane. An unclassified error is
returned without aggregate teardown unless the adapter also terminates
`Lifetime`; future Datagram-gate classifications must be explicit.

On the default QUIC carrier, a normal remote parent close reaches the authenticated-peer-close `io.EOF` class only when the adapter has coherently observed the final receive offset and the caller has received every byte through it. Parent teardown with an unknown final offset or unread payload remains a non-EOF transport closure and still closes the Datagram gate under the existing `ErrWireClosed` classification.

A valid optional-interface result is either absence or a non-nil, non-typed-
nil carrier with a lower ceiling greater than the one-byte wiremux envelope and
a usable, non-typed-nil `Lifetime` context. Validation uses a typed-nil-safe
check before invoking any carrier or context method. Nil/present, typed-nil
carrier, nil or typed-nil lifetime, non-signaling lifetime, and unusable-ceiling
combinations are malformed. They follow the per-role phase rules above and must
never panic or create split-brain capability presence.

Local validation is not the final exposure decision. During the existing
post-commit `accepted` / `converged` / `confirmed` exchange, peers use the
bounded upgrade-control `Extensions` map key `"wiremux.datagram/1"` with CBOR
boolean `true`. Implementations encode presence as `true`; they encode absence
by omitting the key and must never encode CBOR `false`. The listener's
`accepted` advertises its valid local carrier;
the dialer's `converged` advertises the intersection of that bit and its own
valid carrier; the listener's `confirmed` echoes the final intersection. A
missing key means false and unknown extensions remain ignored. Because
`"wiremux.datagram/1"` is registered only for those three messages, its presence
in any message other than `accepted`, `converged`, or `confirmed` is
`protocol_mismatch`, not an ignore-unknown case. A present key with any other
CBOR value or a contradictory echo is
`ErrUpgradeTransportNotConverged`. Each role retains its local carrier
in `UpgradeResult.Datagrams` only when the echoed result is true. Thus a
mixed-version peer or a transport that exposes the optional interface on only
one returned stream produces synchronized capability absence, not one-sided
presence. This extension agrees exposure; transport-native negotiation remains
the authority for whether a local carrier is valid.

All discovery and query methods are prompt local operations:
`DatagramCapable.DatagramCarrier`, `DatagramCarrier.Lifetime`, and
`MaxDatagramPayload` perform no network I/O and do not block indefinitely.
`SendDatagram` and `ReceiveDatagram` unblock when their supplied context ends or
the carrier lifetime becomes terminal. A supporting adapter that cannot meet
those liveness rules reports capability absence.

Lower `ReceiveDatagram` returns exactly one result. Success is a non-nil payload
and nil error; a zero-length native Datagram is represented by a non-nil empty
slice so root can identify and discard it. Failure is a nil payload and non-nil
error. `(nil, nil)` and a non-nil payload paired with an error are observed
carrier contract breaches: root delivers no payload, initiates aggregate
teardown, and returns `ErrWireClosed` while preserving the lower error when one
exists. An internal nonconformance cause is preserved for `(nil, nil)`.

Lower `SendDatagram` has its own bounded admission contract for direct
`connect.Upgrade` callers: it copies on admission, blocks for a finite queue
slot, and returns the call-context error without accepting the payload when
canceled first. Success means accepted for possible lower transmission, not
sent or delivered. The bound is unexported and not configurable. This lower
queue is distinct from the root handle's public queue; both exist because root
callers and direct `connect` callers must independently receive cancellable
admission semantics.

Root public `Send` returns when the root queue admits the copied payload. The
later pump call to lower `SendDatagram` has no waiting public caller and cannot
revoke that success. A pump-observed at-or-below-ceiling size rejection is the
terminal carrier contract breach defined below. Any other lower send error
while `Lifetime` remains active is ordinary silent Datagram loss: it is not
latched or returned by a later public call. Direct lower callers still receive
errors from their own in-flight `SendDatagram` calls normally.

The lower `MaxDatagramPayload` value is the exact stable local-outbound ceiling
for the whole byte slice passed to lower `SendDatagram`, including wiremux
framing. Root `MaxPayload` snapshots that ceiling minus the one-byte envelope.
Directional outbound ceilings may differ, and `Receive` may return a peer
payload larger than this receiver's own local send ceiling. An adapter with a changing native limit publishes a
conservative value it can uphold or terminates the whole Wire if it can no
longer uphold the promise; it never mutates the published value or silently
retargets the handle.

The observation boundary is explicit. A lower send that rejects a payload at
or below the published ceiling as too large is an observed contract breach and
terminates the Wire. A payload that the carrier accepted and later silently
drops during packet packing or in the network is ordinary permitted Datagram
loss and does not by itself prove that the ceiling changed. The public ceiling
is a deterministic admission promise, never a delivery promise.

`DatagramCarrier` is the public low-level `connect` surface, not the consumer
surface. Its send and receive payloads include the wiremux discriminator octet;
direct `connect.Upgrade` callers must apply and validate that envelope and
accept the carrier's lower queue and error model. Root `Wire.Datagrams()` is the
recommended consumer surface: it accepts only consumer bytes, prepends or
strips `0x00`, and supplies the queueing, copy, context, size, and closed-Wire
guarantees above.

### Carrier-bound conformance

The handle is bound immutably to one established transport carrier/session
instance. It is not a logical multipath endpoint, a collection of candidate
pairs, or a frozen network route. A future carrier may migrate internally or
retest PMTU while continuously satisfying the contract. Switching transport
sessions or children of a future composite requires a different handle.
Today's v1 selected-address restriction remains unchanged.

A transport may report Datagram presence only when its reliable and Datagram
planes are authenticated views of that same carrier and satisfy all of these
invariants:

- peer binding, confidentiality, integrity, authentication, and duplicate or
  replay suppression are end to end;
- neither wiremux nor any protocol layer selected or controlled by the adapter
  retransmits an accepted consumer message;
- one send yields at most one whole receive and never a partial payload;
- both planes compete under one carrier-level congestion authority;
- one aggregate owner governs both planes; carrier-lifetime termination ends
  both, while a classified reliable-read outcome may close the optional
  Datagram gate earlier without changing reliable half-close behavior.

These are transport-carrier properties, not properties inherited from the
wiremux encrypted reliable-stream channel. On relay paths, reliable bytes use
wiremux channel framing. On direct QUIC paths, both the reliable stream and
Datagrams use certificate-pinned QUIC TLS and QUIC packet protection. Datagram
bytes never pass through wiremux channel framing, so the channel's counter
nonces, strict stream sequencing and gap detection, and authenticated close
frame do not apply to them.

Opaque link-layer ARQ or FEC outside the adapter's control is not included in
the no-retransmission claim. A black-box test suite cannot prove the security,
retransmission, or congestion invariants, so conformance requires both
executable production-path behavior tests and a transport-specific evidence
record grounded in primary protocol specifications plus source and
configuration audit.

The term Datagram describes one unreliable-unordered atomic consumer message,
not necessarily one UDP packet. wiremux itself does not fragment or reassemble
it. A transport may fragment internally only when no fragment is retransmitted,
loss of any fragment drops the complete message, and partial payload is never
exposed. This keeps zero-retransmission WebRTC/SCTP carriers possible without
weakening the consumer contract.

### Negotiation and wire compatibility

Capability discovery is transport-native. For QUIC, the Datagram-capable
application profile is ALPN `wiremux-quic/2`; both peers offer it only when
they enable RFC 9221 with `max_datagram_frame_size >= 1243`, large enough for a
1240-byte lower Data field plus the length-bearing frame overhead. Both
implementations also offer legacy
`wiremux-quic/1`, which remains stream-only. A handle is locally valid only
when `/2` was selected and post-handshake
`SupportsDatagrams.Local && SupportsDatagrams.Remote` is true.
`Transport.Name()` alone is never capability evidence.

The authenticated upgrade-control protocol stays at version 1 and keeps its
message sequence. Datagram-capable implementations use its already-valid,
ignore-unknown `Extensions` map during the three post-commit phases to agree
the intersection of their locally validated carriers. Extension-free golden
frames remain valid and mean capability absent; new/new Datagram golden frames
include `"wiremux.datagram/1": true` as specified above. This synchronized
agreement is not a second native capability detector. A control-version bump
remains reserved for a mandatory incompatible change.

Every lower Datagram carries one wiremux envelope octet:

- `0x00`: application payload follows, including a zero-length payload.
- `0x01` through `0xFF`: reserved for future wiremux use.

Empty native Datagrams and unknown discriminators are silently dropped. A
sender never emits a non-zero discriminator without a future negotiated
agreement. Drop-unknown evolution is safe on an already unreliable plane and
prevents future control bytes from being confused with application bytes.
After every such discard, root rechecks the closed-Wire gate and then the call
context before requesting another lower message. Continuous invalid input must
not starve cancellation or teardown; the normal receive precedence remains
closed Wire before context.

New wiremux QUIC peers offer `/2` before `/1`; there is no public configuration
knob. New/new peers expose the capability only when `/2`, both RFC 9221
directions, and the post-commit exposure agreement all succeed. New/old selects
`/1`; one-direction-only, one-sided-adapter, stream-only, and relay outcomes
retain the reliable Wire with capability absent. Capability absence never
changes fallback precedence, reliable stream I/O, or teardown.

The failure vocabulary is exact:

| Condition | Classification | Required outcome |
| --- | --- | --- |
| Datagram ALPN not selected; native support absent or negotiated in only one direction; optional interface absent on either role or returns `(nil, false)` | Normal capability absence | Post-commit extension agreement resolves false on both roles; reliable Wire succeeds and `Wire.Datagrams()` returns `(nil, false)` |
| Invalid native transport-parameter encoding or equivalent handshake-hard defect | Native transport establishment failure | Before any non-nil `Accept` stream and before commit, synchronized `transport_failed` relay fallback is permitted; after commit or a non-nil Dial/Accept stream, return `ErrUpgradeTransportNotConverged`, zero result, and no active stream |
| Other transport handshake or setup error | Existing transport establishment failure | Same existing ownership/commit rule as the preceding row |
| Returned stream reports a malformed `DatagramCapable` result | Carrier-validation failure after transport success | Dialer and listener close the returned connection; return `ErrUpgradeTransportNotConverged`, zero result, and no relay fallback, regardless of whether the listener observed `commit` |

### Initial QUIC mapping

The first implementation maps the lower carrier to QUIC DATAGRAM frames on
the same authenticated quic-go connection as the single reliable stream.
It offers ALPN `wiremux-quic/2` followed by `wiremux-quic/1`. The `/2`
application-profile contract requires each endpoint's QUIC transport parameter
to be at least 1243 and admit a length-bearing DATAGRAM frame with 1240 Data
bytes; an endpoint with a smaller positive limit must not offer `/2` and
therefore negotiates the stream-only `/1` profile. quic-go v0.61.0 advertises
16,383 when
Datagrams are enabled, satisfying this floor. Selection of `/2` plus both
support flags is the enforceable precondition for the built-in carrier; a peer
cannot publish a smaller positive limit while conformingly selecting `/2`.
The implementation sets `InitialPacketSize: 1280` explicitly in both client
and server QUIC configurations rather than inheriting quic-go's default. At
that pinned baseline, quic-go v0.61.0 calculates a
1243-byte short-header packet-payload budget. A length-bearing DATAGRAM frame
at this size uses one type byte and a two-byte length, leaving a conservative
1240-byte lower Data field; the one-octet wiremux envelope gives the public
handle a 1239-byte ceiling. This frame-fit value, not quic-go's raw estimate,
is the audited baseline. It is not a permanent protocol constant. Any
dependency or configuration change touching packet sizing intentionally
re-audits and rebaselines it.

QUIC-layer send success is admission, not delivery. The QUIC adapter owns a
bounded admission queue plus one lifecycle-owned send worker; it copies lower
payloads before admission and is the sole caller of quic-go's non-contextual
`SendDatagram`. A full adapter queue makes lower callers wait on their supplied
context or carrier lifetime. Carrier termination closes the connection,
unblocks any native send, discards admitted unsent work, and joins the worker so
none outlives teardown. The root queue and closed gate add the public consumer
semantics above this lower queue. Together they contain quic-go's bounded native
queues, silent packing or receive-overflow drops, and post-close enqueue edge.
Streams and Datagrams share the same QUIC congestion controller, certificate-
pinned connection, selected remote, teardown owner, quic-go transport, and
punched packet socket.

The carrier's `Lifetime` forwards the cause-bearing quic-go connection context.
If quic-go explicitly rejects a lower payload at or below the frozen 1240-byte
ceiling because its current native limit fell, the adapter terminates the Wire
as an observed ceiling breach. A frame accepted into quic-go and later dropped
silently by its packer remains ordinary Datagram loss. This distinction keeps
the fixed admission contract testable without turning unobservable loss into a
false connection-failure signal.

## Considered Options

- **Expose QUIC APIs or a raw UDP socket.** Rejected because it breaks the
  transport abstraction, bypasses aggregate security and congestion control,
  and cannot describe future carriers.
- **Infer support from directness or transport name.** Rejected because a
  future relayed carrier may qualify while a reliable fallback profile of an
  otherwise capable transport may not.
- **Add a required method to `Session` or `TransportListener`.** Rejected
  because it breaks every stream-only custom transport. The optional interface
  keeps the change additive.
- **Use upgrade control as the native capability authority.** Rejected because
  upgrade control cannot make a non-conforming carrier valid or replace native
  transport negotiation. The accepted post-commit extension only intersects
  and synchronizes already-validated local results so optional-interface or
  mixed-version asymmetry becomes absence on both roles.
- **Expose a dynamic payload ceiling.** Rejected because consumers need a
  deterministic sizing contract and time-dependent local rejection is easy to
  misuse. Conservative fixed ceilings are portable across carriers.
- **Give `Datagrams` an independent close or independent failure.** Rejected
  because stream and Datagram views share authentication, congestion, and
  transport ownership; partial survival would misrepresent connection state.
- **Add a second receive queue or public queue configuration.** Rejected to
  avoid another drop site, exported upstream-derived tuning, and policy that no
  present consumer needs.
- **Promise one network packet per public send.** Rejected because atomic
  consumer-message semantics are sufficient and more portable.

## Consequences

- The reliable `Wire` methods and all required transport interface method sets
  remain source-compatible. The root package gains additive surface.
  `UpgradeResult.Datagrams` is an accepted pre-release source-compatibility
  exception: adding the exported field breaks external unkeyed composite
  literals. Keyed literals and field reads remain compatible. The wiremux
  implementation migrates repository-local literals, inventories downstream
  occurrences, and calls out the break in its PR; separate downstream PRs own
  their conversions before the public-API compatibility gate. No required
  transport method is added.
- The current TLS/TCP relay remains stream-only. As the
  [relay architecture research](../research/issue-624-unreliable-datagram-relays.md)
  shows, a qualifying relayed Datagram carrier is separate future architecture,
  not reliable framing over the current relay.
- Consumers must discover the handle on every Wire and size outbound messages
  to that handle's fixed ceiling. They must tolerate loss, reordering, and
  silent drops at any queue or network point permitted by the contract.
- Transport authors must supply both executable behavior coverage and an
  evidence record for non-observable invariants. Stream-only transports remain
  fully conformant without either optional interface.
- Public API additions must be called out in the implementation PRs. GridCast,
  codemux, keymux, and other consumers adopt the capability only in separate
  downstream PRs after wiremux implementation lands.
- Multipath enumeration, routing, retargeting, failover, per-carrier policy,
  and composite lifecycle remain deferred to
  [Explore multi-transport and multipath Wire architecture](https://github.com/GridSwarm/wiremux/issues/708).
- The former relay-capable-path deferral and evidence gate recorded in [Relay-capable Datagram paths](../research/issue-707-relay-capable-datagram-paths.md), with [issue #707](https://github.com/GridSwarm/wiremux/issues/707) as provenance, are historical: [ADR-0012](adr-0012-turn-udp-relay-candidates.md) and the active [TURN/UDP architecture program](2026-08-09-turn-udp-architecture-program.md) supersede them.
- The staged implementation and validation handoff is
  [Datagram capability implementation plan](2026-07-11-datagram-capability-implementation-plan.md).

## Amendment (2026-08, [#1317](https://github.com/GridSwarm/wiremux/issues/1317))

The implementation baseline recorded above (`InitialPacketSize: 1280`, 1243-byte payload estimate, 1240-byte lower and 1239-byte public ceilings, `max_datagram_frame_size >= 1243`) was rebaselined to 1232 / 1195 / 1192 / 1191 / `>= 1195` in preparation for the transport honouring DF (#1317). The derivation, the audit obligation, and the rest of this decision are unchanged; the reason and the compatibility consequences are recorded in [`docs/COMPATIBILITY.md`](../COMPATIBILITY.md).
