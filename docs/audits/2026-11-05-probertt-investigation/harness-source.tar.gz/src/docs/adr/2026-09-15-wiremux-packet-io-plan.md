# Wiremux integration and delivery implementation plan

**Date:** 2026-09-15
**Status:** Complete through Z01; all required deliveries resolved and E01-L/W/D explicitly retired
**Track:** W of the QUIC packet-I/O program
**Normative scope:** Current slice contracts plus the [design contract](2026-09-15-quic-packet-io-design.md)
**Audit history:** [Handoff audit](2026-09-15-packet-io-handoff-audit.md); [evidence revision](2026-09-15-packet-io-evidence-reuse-audit.md)
**Issue links:** [Track W #1520](https://github.com/GridSwarm/wiremux/issues/1520)

## Goal and settled decisions

Deliver the complete optional integration through real external sockets, wrappers, safe reusable endpoints, fixed-peer enforcement, native qualification and consumer adoption. The design contract records the accepted interface and ownership decisions. Upstream builds, authenticated same-socket establishment and existing close-transfer contracts remain intact. Do not implement socket replacement after probing, automatic authority inferred from methods, opaque-wrapper unwrapping, receive-format mutation on borrowed raw sockets, or raw handback inferred from toggling an option. No new wire grammar, authenticated migration, helper module, monitoring service or verification framework is in scope.

## Evidence reuse and remaining qualification

The fork's existing adoption receipts are the baseline evidence for unchanged native algorithms. Reuse their protocols, source identities, raw results, known venue limitations and fallback tests; do not repeat their adoption campaigns. E01 is complete. E01-L/E01-W/E01-D are retired as superseded baseline campaigns, not completed measurements. Their removal unblocks Q02–Q05 after Q01; it does not waive native correctness or observed engagement on the new external/wrapped paths.

Q02–Q05 and R01-L/W own only their named finite correctness, native engagement and lifecycle regressions. Compare changed source owners with the adoption receipt before relying on it. A materially changed kernel algorithm or newly supported OS/architecture requires a scoped re-audit of that affected capability; unchanged neighboring algorithms do not inherit another campaign. R03 completed its bounded raw-handback investigation: [raw return is rejected and managed reuse remains supported](https://github.com/the-sarge/quic-go-fast/blob/main/docs/audits/2026-09-16-r03-raw-handback.md).

E02-L/W/D each own one final assembled comparison under the current wiremux measurement protocol: one predeclared control/candidate pair, three paced workloads, ten pairs per workload, and no separate baseline campaign. Managed reuse, mixed upstream/fork peers, TURN, disabled/unavailable and IPv6 cases retain representative correctness checks where their behavior differs; they do not multiply the performance matrix. No capacity pilot, impairment campaign or TURN performance harness is a required deliverable. Historical results establish only their recorded native domains, not current full-Wire performance. Insufficient statistical resolution terminates with an explicit limitation and ordinary defaults; correctness failure or absent native qualification still blocks the affected capability. Releases, named consumers, rollback and Z01 are complete; see the [aggregate closeout](../research/z01-program-closeout.md).

P02's owner has selected wrapper retention. The wiremux selected-peer wrapper remains the enforcement owner on direct and managed paths; the fork's fixed-peer API remains independently useful to other consumers. E02 evaluates acceleration through the retained wrapper and cannot reopen its removal. P02's existing experiment keeps its original protocol and conclusions; its documentation PR must finish its own merge/journal gates before P02 is complete.

## Current shape

At wiremux `b290852d134d7f45795219671951336d32477ae4`, `upgrade_plan.go:48` owns packet disposition; `upgrade_plan.go:408` carries attempt context; `connect/upgrade.go:311` creates sessions. `transport/quic/transport.go:99` has the two-field public Transport layout; `:308` and `:355` create QUIC transports with the selected wrapper. `transport/internal/adapter/packet_conn.go:27` preserves native capabilities only for concrete UDP; `_oob.go:30` stores that concrete socket. Managed leases require the explicit new adapter in R02.

## Slice graph

| Slice | Delivery | Blocked by | Disposition |
| --- | --- | --- | --- |
| E01 | Freeze measurement protocol | None | Complete |
| W01 | Pass exact-resource permission to built-in QUIC | Q01 | Complete |
| W02 | Connect the checked native batch writer | W01 | Complete |
| E01-L | Linux native baseline receipts | None | Retired; reuse adoption evidence |
| E01-W | Windows native baseline receipts | None | Retired; reuse adoption evidence |
| E01-D | Darwin native baseline receipts | None | Retired; reuse adoption evidence |
| R02 | Use managed leases through full wiremux establishment | R01-B, W01, W02 | Complete |
| P02 | Record decision to retain wiremux peer wrapper | P01-B, W01, E01 | Complete |
| E02-L | Linux assembled Wire qualification | W02, R02, P02, Q03, R01-L | Complete |
| E02-W | Windows assembled Wire qualification | W02, R02, P02, Q02, Q04, R01-W | Complete |
| E02-D | Darwin assembled Wire qualification | W02, R02, P02, Q05 | Complete |
| E02 | Publish assembled support and default-enablement decision | E02-L, E02-W, E02-D, R03 | Complete |
| L02 | Release upstream-compatible wiremux integration | L01 | Complete |
| C01-C | Qualify codemux against released wiremux | L02 | Complete |
| C01-CR | Release qualified codemux compatibility | C01-C | Complete |
| C01-G | Adopt qualified libraries in GridCastIO/gridcast | L02, C01-CR | Complete |
| C01-T | Adopt qualified libraries in SwarmCast/tapmux | L02, C01-CR | Complete |
| C01 | Reconcile consumer coverage and reusable example | C01-G, C01-T, C01-CR | Complete |
| Z01 | Close the complete cross-repository program | C01 | Complete |

Per-slice successor remarks below record their merge-time transitions. The completed slice graph and [program index](2026-09-14-quic-packet-io-program.md) own the current frontier; historical ready/blocked remarks do not reopen a completed slice.

Cross-repository blockers refer to the other track in the program index. The tracker owns live completion state. A stage is one intended PR in its named code/evidence repository; consumer PRs live in their own repositories while their issue and normative contract stay with this integration track.

## Implementation slices

### E01 — Freeze measurement protocol

**Current state:** Complete documentation. The [current protocol](../MEASUREMENT.md#quic-io-frozen-measurement-protocol-e01) supersedes future collection requirements; the original E01 experiment contract below records the completed design scope. E01-L/W/D are retired. P02 is complete with wrapper retention.

**What it delivers and acceptance criteria:** Use the existing [measurement ladder](../MEASUREMENT.md) and [stream](../research/1465-stream/README.md)/[Datagram](../research/1456-datagram/README.md) receipts as harness context, not capacity claims. Commit the protocol before candidate measurement. Compare current upstream, the fork before this program's runtime changes, and each candidate at recorded commits; isolate the program's effect from unrelated existing fork changes.

E01 freezes workload, supported hosts, baseline identities, engagement metrics and statistical decisions. Under the revised evidence policy, host-specific admission belongs to E02-L/W/D; the earlier independent baseline obligations are retired. The design contract defines the finite campaign and adoption thresholds. No native run is required here.

**Blocked by:** None.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** The committed protocol owns experiment choices; issue tracker owns live state.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to docs/MEASUREMENT.md and existing 1465-stream/1456-datagram READMEs; this slice and design evidence section only. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Documentation, protocols, receipts and dependency records: process/traceability metadata. Existing tests and measurement tools: verification aids; no new maintained framework or parser is authorized.

**Representation contract:** Named workload cells only; example-level measurements, no universal performance claim.

**Contract closure:** Not triggered: metadata does not enforce product safety.

**Evidence budget and TDD:** Characterize available harness commands by reading their interfaces. Check declared cells, metric and terminating decision; no new tests for prose. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and docs/MEASUREMENT.md and existing 1465-stream/1456-datagram READMEs; this slice and design evidence section only. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Splitting workload and statistical decisions would leave an unusable protocol. No dependency on W01: a protocol can name future candidate behavior before it exists.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### W01 — Pass exact-resource permission to built-in QUIC

**Current state:** Complete. W02 is complete. R02 is complete; P02 is complete with wrapper retention. The built-in adapter registers exact native-resource permission with the optional Q01 extension; upstream and unsupported inputs retain ordinary I/O. This slice does not enable or qualify receive coalescing.

**W01 semantic coverage:** The grant owns immutable exact-resource permission; `packetConnLifecycle` retains disposal authority and the selected adapter owns registration. Universal enforcement is limited to the native `*net.UDPConn` identity and exact built-in transport types. The following finite regressions discharge the matching permission and setup/teardown rows of the design matrix; managed leases remain R02 scope. No new maintained verification aid is required.

| Semantic class | Disposition and owner | Evidence |
| --- | --- | --- |
| Internal/transferred native; default/configured value/pointer | Grant issued by root preparation; configured transport and socket identities preserved | `TestPreparedUpgradePermissionBindsOnlyOwnedNativeBuiltInResources` |
| Borrowed, custom embedded transport, opaque packet wrapper, different native resource/TURN composite | No grant or no matching adapter registration | Preparation regression plus `TestQUICPacketPermissionBindsExactSelectedNativeWrapper`; one adapter permission-guard bypass must fail borrowed/different-resource cases |
| Dial/Listen; missing material before initialization; timeout and listener precommit close | Session retains grant; adapter binds its exact selected wrapper before initialization; existing close owner retained | `TestSessionPacketPermissionReachesBothRolesBeforeInitialization` in upstream and Q01 fork fixture main modules |
| Probe still owns I/O | Existing handoff joins probing and drains before transport entry | `TestProbeRuntimeReleasePrecedesDrainAndTransportDial` |
| Context deadline/cancellation | Context propagation preserves parent termination | Preparation and both-role regressions; existing session-close race gate |
| Non-nil stream plus error; transferred sentinel and exact disposal; reliable fallback/direct success | Existing attempt and packet lifecycle owners remain authoritative | Existing `TestAttemptResources*`, `TestDialAcceptBeforeCommitClosesSuppliedPacketConnsExactlyOnce`, `TestDial*PacketConn*`, and ordinary local/race gates |

Registration is tested against the real fork's immutable registration slot, with extension presence required in the fork fixture. Native receive coalescing and managed handback are subsequent slices; no new native campaign or stress-count escalation is admitted here.

**What it delivers and acceptance criteria:** Change the prepared-upgrade and built-in-adapter seam to pass a sealed exact-resource permission without wrapping custom transport inputs or changing the public Session contract. The known native selected wrapper registers permission when the fork extension is present; upstream and unsupported inputs keep the existing path. Direct and TURN resource identities must not share a grant.

Acceptance: default and configured built-in transports preserve settings and public struct layout; internal/transferred native sockets eligible; borrowed raw sockets ineligible; custom transport identity preserved; direct grant rejected for TURN; joined probing precedes mutation; no changed transfer/error sentinel or exact-close behavior; existing context cancellation/deadlines survive permission propagation. Exercise pre-initialization failure, listener precommit failure, non-nil-stream-plus-error, direct success and reliable fallback through existing lifecycle fixtures. Bounds: `upgrade_plan.go`, prepared attempt invocation, the internal permission module, QUIC adapter construction and these fixtures; no global registry or new socket ownership state machine.

**Blocked by:** Q01.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** packetConnLifecycle remains sole close/disposition owner; immutable prepared context grant owns permission; adapter binds exact selected wrapper.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to upgrade_plan.go:48,231,390,408; connect/upgrade.go:311; transport/quic/transport.go:99,135,308,355; adapter packet constructors. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Runtime API and diagnostics: shipped behavior. Admission, progress and lifecycle guards: required safety enforcement. Tests: verification aids; no maintained-aid exception.

**Representation contract:** The standard-library packet/address and explicit registration domain in the design contract; universal enforcement within that domain, finite regression evidence.

**Contract closure:** Use the matching owner row in the design contract semantic matrix; write the named positive and distinct failure regressions first.

**Evidence budget and TDD:** Characterize internal/transferred/borrowed/custom/TURN resources, joined probing, context deadlines, Dial/Listen and nonnil-stream-plus-error before changing grant flow. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and upgrade_plan.go:48,231,390,408; connect/upgrade.go:311; transport/quic/transport.go:99,135,308,355; adapter packet constructors. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Root grant and adapter consumer must merge together to avoid unused authority. Q01 is necessary for the real fork fixture to acknowledge permission, while upstream stays green.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### W02 — Connect the checked native batch writer

**Current state:** Complete. Known native selected wrappers register their private checked writer with the optional fork extension; upstream, opaque wrappers and TURN retain ordinary I/O. Borrowed native sockets retain false receive permission. No acceleration qualification is claimed. R01-B and R02 are also complete. E02-L/E02-W/E02-D retain their other blockers.

**What it delivers and acceptance criteria:** Compose the selected wrapper's destination check with the fork writer for known native sockets; keep opaque wrappers and TURN ordinary. Deliver checked callback composition using Q01 ordinary writer now, and automatic native dispatch once Q05 is selected. Full-Wire reliable/Datagram/mixed delivery and wrong-peer rejection use the real adapter with isolated upstream/fork module fixtures; the all-platform acceleration milestone is E02, not a prerequisite for this code.

**Blocked by:** W01.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Selected wrapper owns destination authorization; fork writer owns syscall; existing QUIC send worker owns retry.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** `transport/internal/adapter/packet_permission.go` composes registration; `packet_conn_oob.go` owns the private checked callback; focused adapter, QUIC-session and production-Wire tests exercise delivery. The existing `transport/quic` construction seam, root permission and disposal owners remain unchanged. No shared/global state, public API/layout, wire grammar, dependency selection, syscall implementation, second queue or close owner is introduced. Opaque wrappers and TURN remain ordinary; managed leases belong to R02 and platform acceleration qualification to E02. No additional untraced effects are accepted.

**Artifact classification:** Callback integration is shipped behavior; selected-destination enforcement and exact wrapper binding are required safety enforcement. Tests and isolated upstream/fork main modules are verification aids, with no maintained-aid exception or new framework. Plan state and tracking are process metadata.

**Representation contract:** The accepted design owns standard-library UDP addresses, synchronous batches of complete UDP payloads with one destination and OOB block, and exact known native wrapper identity. Existing `ObservedAddrMatchesSelectedRemote` owns directional selected-peer matching; the fork owns syscall representation, accepted-prefix counts and send-worker progress. Universal enforcement is limited to these supported representations; finite regressions are evidence, not an exhaustive network proof. Borrowed native sockets may use checked sending independently of receive-format permission; their receive-coalescing grant remains false. Opaque wrappers and TURN receive no native callback.

**Contract closure:** Triggered for selected-peer enforcement and send-result preservation across concurrent callbacks and setup paths. The W02 matrix below specializes the design contract send-worker/registration rows. The selected wrapper is the sole destination owner; the fork retains progress enforcement. No endpoint/lease or new receive-owner obligation enters W02.

**Evidence budget and TDD:** At the real selected adapter seam, make wrong-peer batch rejection and selected-peer batch delivery red before composition. Cover exact callback registration with and without receive permission, opaque/TURN ordinary behavior, unchanged buffers/OOB and exact prefix/error forwarding without local retry. Run reliable-only, Datagram-only and mixed production-Wire delivery in separate immutable upstream/Q01 fork main-module selections, requiring the extension in the fork fixture. Run one concurrent-callback race regression, existing session cancellation/close and root ownership/fallback tests, and `task verify`. One representative positive per distinct behavior and negative per failure mode; at most one destination-guard bypass when needed to demonstrate enforcement. No added native performance campaign, platform expansion, lease-close test, repetition escalation or recursive harness validation. One initial review and at most one replacement. Terminate when these finite regressions and ordinary exact-head gates pass.

**Dispatch context budget:** This slice; design decisions D01–D09, packet-I/O/batching and matching semantic matrix rows; adapter packet construction, selected-address matcher and focused tests; QUIC session construction and production-Wire delivery fixtures only. Target under 25k source/context tokens, with no whole historical plan or audit chronology. No unresolved implementation review is inherited. Reserve the remaining context for implementation, review and verification; re-audit if this bounded diff cannot fit.

**Slice decision audit:** Callback creation, selected-wrapper authorization and exact registration merge together in one independently green product PR. Splitting them would expose an unused callback or untested binding; merging native Q05 implementation, managed R02 leases or platform E02 qualification would cross owners and evidence budgets. Q01 ordinary writing discharges this integration criterion; selecting a later compatible Q05 writer requires no wiremux syscall change.

**W02 semantic coverage:** No uncovered in-scope class is accepted at certification; the following finite regressions discharge this slice. Native engagement, managed generation/handback and P02 decision documentation remain named successor scope.

| Semantic class | Expected disposition and owner | Terminating evidence |
| --- | --- | --- |
| Selected destination, including existing mapped IPv4 and directional IPv6-zone semantics; wrong/nil destination | Private wrapper callback invokes the fork writer only after the existing destination matcher admits it | Adapter callback regression; one guard bypass if needed |
| Full/short/zero prefix; negative/over-count; error with known or uncertain progress | Forward exactly once, without copying, local retry or reinterpretation; fork send worker retains validation/fallback authority | Finite callback forwarding table with shared OOB/payload identity and exact result/error |
| Exact native selected wrapper with/without receive grant; absent extension; opaque/TURN input | Bind the checked callback only for known native wrapper; receive flag follows W01 grant independently; ordinary fallback otherwise | Real upstream/fork constructor and both-role regressions |
| Concurrent callbacks | Per-call authorization and synchronous borrowing; fork writer owns its own synchronization | One concurrent-callback race regression |
| Full Wire reliable, Datagram and mixed traffic; cancellation and terminal disposal | Production adapter carries supported traffic; existing lifecycle owners remain authoritative | Upstream/fork production-Wire fixtures plus ordinary required local/race gates |

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.


### E01-L — Linux native baseline receipts

**Disposition:** Retired as superseded. No campaign ran and no baseline measurement is claimed. Reuse the existing fork adoption receipts through the [evidence revision audit](2026-09-15-packet-io-evidence-reuse-audit.md); E02-L owns the one final assembled comparison. Close the existing issue as not planned and drop its OmniFocus task after this revision merges. Retain its stable identity and historical plan pointer for traceability; do not dispatch another PR for this retired slice.

**Blocked by:** None. This retired row blocks no runtime or qualification slice.

### E01-W — Windows native baseline receipts

**Disposition:** Retired as superseded. No campaign ran and no baseline measurement is claimed. Reuse the existing fork adoption receipts through the [evidence revision audit](2026-09-15-packet-io-evidence-reuse-audit.md); E02-W owns the one final assembled comparison. Close the existing issue as not planned and drop its OmniFocus task after this revision merges. Retain its stable identity and historical plan pointer for traceability; do not dispatch another PR for this retired slice.

**Blocked by:** None. This retired row blocks no runtime or qualification slice.

### E01-D — Darwin native baseline receipts

**Disposition:** Retired as superseded. No campaign ran and no baseline measurement is claimed. Reuse the existing fork adoption receipts through the [evidence revision audit](2026-09-15-packet-io-evidence-reuse-audit.md); E02-D owns the one final assembled comparison. Close the existing issue as not planned and drop its OmniFocus task after this revision merges. Retain its stable identity and historical plan pointer for traceability; do not dispatch another PR for this retired slice.

**Blocked by:** None. This retired row blocks no runtime or qualification slice.

### R02 — Use managed leases through full wiremux establishment

**Current state:** Complete. The opt-in facade acquires an exact, receipt-bound lease through root preparation, and the selected adapter registers its checked generation-aware writer. Existing lifecycle owners release the lease on terminal paths; the caller retains the parent endpoint. Upstream retains ordinary functionality and an explicit unsupported factory result. E02-L/E02-W/E02-D remain blocked by their other prerequisites; this completion makes no additional slice ready.

**R02 semantic coverage:** The endpoint is the generation/join owner, root lifecycle is the attempt-disposal owner, the internal receipt owns provenance, and the per-lease adapter owns peer filtering. The current R01-B factory supplies ordinary receives; a complete message/batch surface, when supplied by a proven lease, is filtered without raw descriptor access. No acceleration qualification is claimed. The following finite evidence specializes the design matrix; tests remain verification aids, with no maintained-aid exception.

| Semantic class | Disposition and owner | Evidence |
| --- | --- | --- |
| Upstream factory absence; ordinary parent packet I/O and terminal Close | Explicit unsupported result, or factory-owned ordinary endpoint | `TestManagedPacketEndpointOrdinaryIOOrExplicitUnsupported` in upstream/fork selections |
| Invalid or conflicting options, custom/promoted transport, simultaneous acquisition, post-acquisition validation failure | Reject before acquisition where possible; existing root lifecycle releases an acquired lease | `TestManagedPacketPreparationValidatesBeforeAcquiringAndDisposesExactLease` |
| Factory lease versus parent, opaque wrapper, other resource and next generation | Immutable receipt admits only its exact lease; fork rejects stale registration | `TestManagedPacketBindingRejectsUnprovenAndStaleLeases`; one receipt-guard bypass |
| Selected/foreign destinations, message/batch metadata and callback prefix/error | Per-lease filter retains policy and forwarding; fork owns progress and generations | `TestManagedSelectedPacketMethodsPreservePolicyAndMetadata`; one destination-guard bypass; existing native batch regressions |
| Parent deadlines across repeated attempts | Root preparation resets both attempt deadlines; lease Close restores saved parent read/write deadlines | `TestManagedPacketEndpointRepeatedProductionWire` with expired parent deadlines on the later attempt |
| STUN/probe then QUIC; repeated peer selection; Wire Close and parent Close | Same lease throughout establishment; disposal returns ordinary parent or parent Close terminates I/O | `TestManagedPacketEndpointRepeatedProductionWire`; inherited probe-reader handoff and session lifecycle gates |
| Failed rendezvous, failed direct probing, reliable fallback and TURN | Release direct lease while alternative Wire remains live | `TestManagedPacketEndpointReturnsAfterFailureFallbackAndTURN` |
| Concurrent checked writers and lease return | Fork generation accounting joins operations and rejects stale callbacks | Real-factory binding regression under race detection; R01-B's held-I/O joining evidence remains at the fork owner |

No in-scope matrix cell remains uncovered by the stated regression or inherited evidence. No restart format, new native campaign, stress escalation, or additional untraced effect is introduced.

**What it delivers and acceptance criteria:** Provide the explicit construction/use path for a managed endpoint and per-attempt lease; transfer each lease through existing root lifecycle semantics. Preserve ordinary raw WithPacketConn and custom input identity. Treat the managed packet resource as a deliberate separate input class, never infer it from a UDP-like LocalAddr or an inherited method. Use a sealed binding/receipt for the known endpoint implementation, carried by the explicit managed-endpoint option. Public constructor additions need compatibility documentation and a downstream example.

Acceptance: gathering/STUN/authenticated probing use the supplied lease before QUIC and their readers join before transition; failed direct attempt, reliable fallback, TURN outcome and successful Wire teardown release exactly the attempt lease; the parent is usable for ordinary reads and a later attempt; separate peer selection applies on later leases; parent-close interrupts all associated work. Test consumer-shaped repeated attempts without repeated successful-run fishing. Upstream-only builds retain ordinary functionality and a clear unsupported result for an explicitly requested unavailable factory. Bounds: endpoint integration, root/adapter permission seam and lifecycle fixtures. Add a provenance-checked managed selected-peer adapter: the factory acquisition closure records exact returned leases in an internal owner-bound receipt, and only those known leases preserve OOB/ReadBatch and checked writer methods. Never rely on a promoted method to grant authority. Use ConfigureManagedPacketIOV1 instead of ordinary registration to pass the exact original lease, outer filtered conn and checked callback around the proven lease WriteBatchV1; obtain no raw native socket. Ordinary managed QUIC is usable before R01-L/W; enabled platform support is qualified by E02. Freeze NewManagedPacketEndpoint(network string, laddr *net.UDPAddr) (*ManagedPacketEndpoint, error) and WithManagedPacketEndpoint(endpoint *ManagedPacketEndpoint) Option. The facade forwards ordinary net.PacketConn operations and parent Close; its factory/acquisition closure stays private. The option carries the exact facade and sealed internal owner receipt through prepared-upgrade state; prepare acquires the per-attempt fork lease once, records the receipt in the immutable grant and transfers that exact lease into existing disposal machinery. This option is mutually exclusive with raw packet options and requires the exact built-in QUIC transport, validated before acquisition. It never infers provenance from a method, LocalAddr or global registry. Existing raw options receive no managed authority. Constructor/factory absence gives an explicit unsupported result on upstream. Endpoint construction remains opt-in.

**Blocked by:** R01-B, W01, W02.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Endpoint owns native lifetime; root owns transferred exact lease disposal; internal receipt owns provenance, adapter owns per-lease peer filter.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to upgrade_plan.go; new public endpoint facade; adapter packet_conn.go:20,27 and packet_conn_oob.go:30; frozen R01 methods and existing lifecycle fixtures. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Runtime API and diagnostics: shipped behavior. Admission, progress and lifecycle guards: required safety enforcement. Tests: verification aids; no maintained-aid exception.

**Representation contract:** The standard-library packet/address and explicit registration domain in the design contract; universal enforcement within that domain, finite regression evidence.

**Contract closure:** Use the matching owner row in the design contract semantic matrix; write the named positive and distinct failure regressions first.

**Evidence budget and TDD:** Repeated full-Wire attempts: failed direct, reliable fallback, TURN, success and parent Close; STUN/probe then QUIC ordering; stale generation; opaque wrapper and upstream unsupported factory. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and upgrade_plan.go; new public endpoint facade; adapter packet_conn.go:20,27 and packet_conn_oob.go:30; frozen R01 methods and existing lifecycle fixtures. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Facade, receipt and adapter belong together; a constructor-only PR would expose an input that loses receive capabilities. Native OS slices need not block ordinary reuse.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### P02 — Evaluate and selectively remove wiremux peer wrapper

**Current state:** Complete in [PR #1551](https://github.com/GridSwarm/wiremux/pull/1551). The [evaluation](../research/p02-fixed-peer.md) records the settled owner decision to retain wiremux's wrapper, the historical experiment and inconclusive performance preservation. No experimental native-selection runtime or tests ship. The comparison contract below is historical context, not authorization to implement removal or collect more captures. E02 uses the retained wrapper and cannot reopen removal. Q02/Q03/Q04/Q05 remain the frontier; P02 completion makes no additional slice ready.

**What it delivers and acceptance criteria:** For direct concrete UDP inputs, compare current wrapper enforcement with acknowledged native fixed-peer mode using the same selected-pair, authentication and lifecycle fixtures. Keep caller wrappers, TURN composites, upstream and unsupported fork versions on the existing wrapper path. Preserve configured built-in transport settings and exact packet ownership. Amend ADR-0003's enforcement mechanism only if native enforcement meets its existing decision. Adopt removal when it provides measurable resource benefit under the protocol, or demonstrated maintainability benefit without performance regression; otherwise retain the wrapper with an explicit decision. Native fixed-peer support remains a documented optional fork capability either way. This slice implements the equivalence-qualified selectable path with the existing wrapper as the ordinary default. Budget its comparison on one predeclared available native platform using E01; do not require all three venues here. E02-L/W/D and aggregate E02 make the final per-platform enablement decision. Missing Windows access therefore does not block Linux/Darwin dispatch through P02.

**Blocked by:** P01-B, W01, E01.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Native policy is acknowledged sole peer enforcer only on selected direct concrete UDP path; wrapper remains owner elsewhere.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to transport/quic construction; adapter peer matching; ADR-0003; P01-B setter and source audit. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Runtime API and diagnostics: shipped behavior. Admission, progress and lifecycle guards: required safety enforcement. Tests: verification aids; no maintained-aid exception.

**Representation contract:** The standard-library packet/address and explicit registration domain in the design contract; universal enforcement within that domain, finite regression evidence.

**Contract closure:** Use the matching owner row in the design contract semantic matrix; write the named positive and distinct failure regressions first.

**Evidence budget and TDD:** Shared selected-pair, authentication, local socket, close and error fixtures across old/native paths; caller wrapper, TURN, upstream and unsupported mode preserve fallback. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and transport/quic construction; adapter peer matching; ADR-0003; P01-B setter and source audit. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Do not split activation from equivalence evidence. Managed path stays filtered; no R02 blocker since direct concrete UDP is the only admitted removal domain.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### E02-L — Linux assembled Wire qualification

**Current state:** Complete. The [Linux receipt](../research/e02-l-linux.md) records native full-Wire GSO/GRO and managed receive/reuse engagement, compatibility and correctness evidence. Disposition: correct opt-in, ordinary defaults; performance unavailable because the proposed venue failed admission. E02-W and R03 are also complete; raw return is rejected and E02 is ready.

**What it delivers and acceptance criteria:** Run the final matrix on the assembled revisions, including managed endpoint reuse, upstream/fork peer combinations and the retained wiremux selected-peer wrapper. Re-audit changed source dependencies named in [the v0.62 audit](../research/quic-go-v0.62-source-audit.md). Record platform-specific support and failures; reuse historic adoption evidence for unchanged algorithms, without presenting those numbers as assembled-Wire results. Close unresolved product correctness findings before release. This gate must not be satisfied by compiling unused extensions or measuring native QUIC while full Wire used fallback. Limit this slice to Linux; baseline and final candidate identities are fixed before measurement. Managed receive on macOS remains ordinary; native send must engage where qualified.

**Blocked by:** W02, R02, P02, Q03, R01-L.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Receipt author owns observations; shipped owners remain unchanged.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to current E01 evidence policy and reused adoption receipts, merged W/R/P contracts, existing full-Wire harness and dependency source audit. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Documentation, protocols, receipts and dependency records: process/traceability metadata. Existing tests and measurement tools: verification aids; no new maintained framework or parser is authorized.

**Representation contract:** Linux declared platform/socket/workload cells; example-level performance and native-engagement evidence.

**Contract closure:** Not triggered for receipts. Product regressions return to the responsible shipped owner and named repair child.

**Evidence budget and TDD:** One final paired comparison under the revised E01 protocol and one representative lifecycle/compatibility case per admitted mode, mixed upstream/fork peers, managed reuse and TURN preservation. No implementation fixes hidden in this evidence PR. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and current E01 evidence policy and reused adoption receipts, merged W/R/P contracts, existing full-Wire harness and dependency source audit. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Per-platform evidence is independently publishable. Every listed implementation dependency is exercised by this assembled matrix.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### E02-W — Windows assembled Wire qualification

**Current state:** Complete. The [Windows receipt](../research/e02-w-windows.md) records native full-Wire USO/URO, managed receive across three joined generations, compatibility and preservation evidence. Disposition: correct opt-in, ordinary defaults; performance unavailable at admission. The disposable observer is archived and retired. E02-L, E02-D and R03 are also complete, so E02 is ready; L01 retains E02.

**What it delivers and acceptance criteria:** Run the final matrix on the assembled revisions, including managed endpoint reuse, upstream/fork peer combinations and the retained wiremux selected-peer wrapper. Re-audit changed source dependencies named in [the v0.62 audit](../research/quic-go-v0.62-source-audit.md). Record platform-specific support and failures; reuse historic adoption evidence for unchanged algorithms, without presenting those numbers as assembled-Wire results. Close unresolved product correctness findings before release. This gate must not be satisfied by compiling unused extensions or measuring native QUIC while full Wire used fallback. Limit this slice to Windows; baseline and final candidate identities are fixed before measurement. Managed receive on macOS remains ordinary; native send must engage where qualified.

**Blocked by:** W02, R02, P02, Q02, Q04, R01-W.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Receipt author owns observations; shipped owners remain unchanged. The disposable observation handle owns bounded scalar evidence only, never packet admission, decoding, submission, retry, qualification or disposal.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to current E01 evidence policy and reused adoption receipts, merged W/R/P contracts, existing full-Wire harness, dependency source audit and the exact-source observation fixture below. Shared/global state changes are forbidden. The operator-authorized disposable minimax Windows Server 2025 guest through existing guarded admission and cleanup, including task-local guest access, is a narrow operational exception; the instance-local disposable observation state below is the only code-state exception. Neither exception permits changing shared product or machine configuration. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Documentation, protocols, receipts and dependency records: process/traceability metadata. Existing tests, measurement tools and the disposable exact-source observation fixture: verification aids. Archive its sources, source hashes, commands and results with the receipt and retire it from active builds at closure. No maintained framework, parser or diagnostic API is authorized.

**Representation contract:** Windows declared platform/socket/workload cells; example-level performance and native-engagement evidence. Go compilation owns source representation; the fixture rejects any mismatch with its frozen source hashes. Existing standard-library addresses, fork metadata parsing and batch-progress classification retain their representation ownership. One active observed connection per endpoint process at a time, with one active resource/generation per handle, bounds attribution. The three sequential managed generations retain separate generation-attributed snapshots.

**Contract closure:** Not triggered for receipts. Product regressions return to the responsible shipped owner and named repair child.

**Bounded observation method:** The [scoped observation audit](2026-09-16-e02-w-observation-audit.md) authorizes a disposable Go build overlay and a cross-host fixture derived from the existing production-Wire/managed-reuse tests. Carry one instance-local scalar observation handle in the existing Dial/session context into exact selected-wrapper registration; preserve cancellation and deadlines. Context plumbing, signature changes and any required cross-package handle/accessor symbols exist only in disposable overlay builds; none ships or becomes supported API. Bind direct observation to the registered Windows raw connection and managed observation to the retained decoder under the existing endpoint registration/generation lock. No global registry, extra reader, socket reference retained by the handle, new parser or supported API is admitted. Materialize the pinned fork outside module caches and shared checkouts.

Observe segmented and single sends at `windowsConn.WritePacket`, grouped ordinary sends at `ordinaryUDPBatchWriter` through the checked callback, receive/URO calls at `windowsConn.ReadPacket`, and normalized delivery through the managed endpoint. Observe these existing calls and their existing validation/classification results without changing arguments, results, ordering or invocation count. Count attempted and successful USO sends, offered segments, ordinary sends, native receive calls, valid multi-datagram URO completions and normalized deliveries separately. Count rejected/error results separately; never infer native engagement from option settings or successful Wire delivery. Exclude probe/control-plane and qualification sockets by exact registration binding. Managed observation follows the current active generation; an invocation captures its observation handle before the call so later binding cannot charge an earlier operation to a new generation. Retain only bounded counters, resource/wrapper identities and monotonic timing. Observe basic ordinary packet methods when the managed surface uses them, without claiming they are native syscalls.

Publish snapshots only after the existing Wire/endpoint close-and-join boundary, through test output or the existing capture owner, with run, endpoint, selected local/remote resource, ownership/generation and switch values. Whole-connection correctness snapshots are not measurement-window performance evidence. CPU/allocation results from an observer-equipped binary describe that instrumented pair and cannot support default enablement without a supported differential-overhead bound. Missing calibration leaves that verdict unavailable; no new calibration campaign is required. No hot-path output, polling goroutine, tracing privilege or extra transport owner is admitted. URO qualification requires the separate Linux/Windows endpoints and traffic crossing the guest NIC. The fixture must exercise checked Windows-originated bulk to establish USO and checked Windows-received bulk to establish URO, either bidirectionally on one production Wire or in separately declared fixed-role cases. It may coordinate those endpoints through the existing measurement runner and task-local SSH access, or one temporary host endpoint and the existing QEMU Guest Agent; it must use production Dial, authenticated establishment, retained wrappers and exact payload verification. This coordination is disposable test setup, not a new measurement runner or product topology.

**Observation evidence ceiling:** First demonstrate that the unobserved build cannot discharge engagement. Then collect one enabled and one disabled direct case with exact selected resource attribution; one managed-reuse case covering the existing three generations and joins; and a foreign/unregistered resource exclusion check. Require actual multi-segment send and multi-datagram receive before claiming their Windows support. Reuse unchanged lifecycle, IPv6, authentication, TURN and mixed-peer preservation tests. The existing ten-pair/three-workload performance budget is unchanged; unavailable venue, control or collector qualifications terminate performance as unavailable and cannot substitute for native correctness. No recursive observer completeness or mutation campaign is required. One initial review and at most one replacement remain the review budget.


**Evidence budget and TDD:** One final paired comparison under the revised E01 protocol and one representative lifecycle/compatibility case per admitted mode, mixed upstream/fork peers, managed reuse and TURN preservation. No implementation fixes hidden in this evidence PR. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and current E01 evidence policy and reused adoption receipts, merged W/R/P contracts, existing full-Wire harness and dependency source audit, the scoped observation audit, Windows raw/managed observation call sites, exact registration/context plumbing, and the reused production-Wire/managed-reuse fixture. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Per-platform evidence is independently publishable. Every listed implementation dependency is exercised by this assembled matrix.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### E02-D — Darwin assembled Wire qualification

**Current state:** Complete. The [Darwin receipt](../research/e02-d-darwin.md) records native full-Wire and managed engagement, upstream/fork compatibility and correctness evidence. Disposition: correct opt-in, ordinary defaults; performance unavailable because the two-host venue failed admission. The [observation re-audit](2026-09-16-e02-d-observation-audit.md) remains the authority for the archived disposable observer. E02-W and R03 are also complete; raw return is rejected and E02 is ready.

**What it delivers and acceptance criteria:** Run the final matrix on the assembled revisions, including managed endpoint reuse, upstream/fork peer combinations and the retained wiremux selected-peer wrapper. Re-audit changed source dependencies named in [the v0.62 audit](../research/quic-go-v0.62-source-audit.md). Record platform-specific support and failures; reuse historic adoption evidence for unchanged algorithms, without presenting those numbers as assembled-Wire results. Close unresolved product correctness findings before release. This gate must not be satisfied by compiling unused extensions or measuring native QUIC while full Wire used fallback. Limit this slice to Darwin; baseline and final candidate identities are fixed before measurement. Managed receive on macOS remains ordinary; native send must engage where qualified.

**Blocked by:** W02, R02, P02, Q05.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Receipt author owns observations; shipped owners remain unchanged. The disposable observer aggregates evidence only and never owns packet admission, submission, retry, qualification, configuration or disposal.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to current E01 evidence policy and reused adoption receipts, merged W/R/P contracts, existing full-Wire harness, dependency source audit and the exact-source disposable observation overlay described below. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Documentation, protocols, receipts and dependency records: process/traceability metadata. Existing tests, measurement tools and the disposable observation overlay: verification aids. The overlay is not a maintained deliverable, public diagnostic API or framework; archive its source, checksums and reproduction commands with the receipts, then retire it from active builds when E02-D closes. No new maintained aid is approved. Required evidence remains native engagement and correctness, not completeness of the observer.

**Representation contract:** Darwin declared platform/socket/workload cells; example-level performance and native-engagement evidence. The observer admits only frozen source blobs and the named native UDP/managed lease paths, one Wire connection per endpoint process and one active observed socket/lease generation at a time. Go compilation owns source representation; standard-library UDP values, existing fork return classification and the existing measurement configuration/capture owners retain their representations. Reject a source-hash mismatch rather than approximately patching another source version.

**Contract closure:** Not triggered for receipts. Product regressions return to the responsible shipped owner and named repair child.

**Bounded observation method:** Use a disposable Go build overlay against pinned Wc/Fc sources to record actual native submissions and ordinary packet-method calls without changing their arguments, results, invocation count or ordering. Count once immediately around the existing invocation of `sendmsgXSubmit` inside `darwinBatch.submit`'s raw-write callback; exits before that invocation count no native submission. Preserve `sendmsgXSubmit` as the returned-progress classifier, without a second native-call/offered-message increment. Observe the disjoint ordinary send owners (`ordinaryUDPBatchWriter` and basic/OOB `WritePacket`), exact external/managed registration and the existing measurement boundary/capture seams. Observe the selected wrapper binding and native socket identity within an instance-scoped handle; correlate native submissions by that socket's descriptor while it remains live. Exclude qualification self-check sockets, relay/control-plane sockets and stale generations; a descriptor alone is not a durable identity. Retain only bounded scalar counters and identity metadata, never payloads, socket references, another queue or a reader. Ordinary counters count packet-method invocations, not hidden kernel retry syscalls; report that distinction.

The measurement setup owns one scalar-observation handle per endpoint. In the disposable overlay only, carry it in the existing setup/Dial context, retrieve it from the built-in QUIC session's context, and pass it through `session.newPacketTransport` and `adapter.NewQUICTransport` before exact fork writer/managed registration. Admit the required cross-package exported handle/accessor symbols only in these overlay builds; they are not a shipped or supported API. The registered writer/managed endpoint holds a bounded observation slot, not a socket owned by the observer. Managed registration updates that slot only under the existing generation/admission rules; snapshots retain the generation token, and later bindings cannot charge an earlier generation. The measurement owner retains the same handle for snapshots and clears observation state after the existing endpoint close/join, including failed setup. This is an explicit exception for instance-local disposable observation state and overlay-only signatures, not for package-global registries or shared product/machine settings. Materialize pinned fork source outside the Go module cache for overlay builds; do not modify cached modules, shared checkouts or shipped module dependencies.

Record native calls, offered message counts, validated accepted prefixes and failures separately, including an observed multi-message native operation for any claimed engagement. Uncertain or invalid native progress remains an error observation, never inferred acceptance. Keep ordinary attempts and successful messages separate. Snapshots retain their actual monotonic spans and in-flight boundary uncertainty; associate them with run, endpoint, selected local/remote resource, wrapper, ownership/lease generation and requested/supported mode. Write one bounded JSON sidecar per endpoint through the existing capture owner, with the normal identity/hash manifest and copy/readback checks. No hot-path file I/O, polling goroutine, tracing privileges or global machine setting changes are required.

Use the same observer binary and build settings in both comparison members; change only `QUIC_GO_DISABLE_SENDMSG_X` (`1` for control, `0` for candidate) before any QUIC initialization. For the existing remote runner, which accepts binary paths but no per-endpoint environment field, identical copies may use the two exact manifest-declared control/candidate executable basenames. The overlay's startup selects the corresponding process-local switch value from those names, records it and rejects an unrecognized campaign basename; it adds no general configuration parser or machine-wide environment change. Freeze that launch mapping and require the admission polarity check to verify its effect. Freeze overlay hashes, source hashes, module graph and executable digests before collection. Do not infer that identical instrumentation cancels overhead: absent a supported overhead bound, CPU/allocation observations describe the instrumented pair and cannot support a default-enablement benefit. Preserve the existing finite campaign and permitted inconclusive/opt-in termination; no extra overhead campaign, passing-number search or reduction of correctness/engagement requirements is authorized. Evidence from an observer-equipped binary is explicitly attributed to that binary, not relabeled as an uninstrumented release measurement.

**Observation evidence matrix:** These finite checks establish fitness for this receipt, not a maintained analyzer or universal observer guarantee. The [Darwin receipt](../research/e02-d-darwin.md) records the completed admission checks and unavailable performance cells; missing or contradictory observations keep affected future evidence unavailable/blocked under E01.

| Declared case | Expected observation and owner | Terminating evidence |
| --- | --- | --- |
| Direct full Wire, native enabled | Exact selected wrapper/socket; positive multi-message native calls and valid accepted prefixes at the fork submission owner | One native engagement admission through existing full-Wire delivery; distinguish ordinary tails/fallback calls |
| Same direct path, native disabled | Zero native calls; positive ordinary calls and correct delivery | One matched polarity check using the frozen existing switch; failure to observe this difference rejects the observer |
| Managed full Wire | Exact registered lease generation; native send observed, ordinary receive retained | One managed engagement case plus existing repeated-lease/return/failure/TURN correctness cases; no managed performance cross-product |
| Attribution and progress | Unregistered self-check traffic excluded; generation change cannot reuse a prior identity; uncertain/invalid progress never counted as accepted | One focused attribution check and source inspection of the existing progress classifier; reuse existing progress/lease regressions |
| Receipt lifecycle | Actual snapshot span, bounded sidecar, run/role/resource identity and successful hash-checked artifact recovery | One source receipt readback through the existing capture owner; missing/partial sidecar is unavailable evidence |

**Evidence budget and TDD:** One final paired comparison under the revised E01 protocol and one representative lifecycle/compatibility case per admitted mode, mixed upstream/fork peers, managed reuse and TURN preservation. No product implementation fixes hidden in this evidence PR. The disposable observer and its finite admission checks above are admitted evidence collection, not a fork product change. First require full-Wire engagement to distinguish enabled from disabled; an absent observation must fail that admission. No observer guard mutation or recursive closure matrix is required. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and current E01 evidence policy and reused adoption receipts, merged W/R/P contracts, existing full-Wire harness, dependency source audit and the named observation seams above. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Per-platform evidence is independently publishable. Every listed implementation dependency is exercised by this assembled matrix. Keep a disposable exact-source observer and its receipts in this evidence PR: a separate product diagnostics slice would introduce an unnecessary maintained API, while folding any runtime repair into E02-D would violate this boundary. No neighboring platform contract is changed.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### E02 — Publish assembled support and default-enablement decision

**Current state:** Complete. The [assembled support decision](../research/e02-support.md) reconciles all three platform receipts and R03: correct opt-in support, ordinary defaults, unavailable performance, retained selected-peer wrapper and managed reuse without raw handback. The ADR-0003 dependency re-audit is recorded there. Releases, consumers, rollback and Z01 are complete; see the [aggregate closeout](../research/z01-program-closeout.md).

**What it delivers and acceptance criteria:** Reconcile the three platform receipts and raw-handback disposition. Publish supported platform/socket/feature/reuse/peer-owner/fallback matrix, default or opt-in decisions and remaining explicit limitations. Re-audit the selected QUIC dependency against ADR-0003. Required native correctness cannot be waived for absent environments; insufficient measured benefit may choose ordinary defaults.

**Blocked by:** E02-L, E02-W, E02-D, R03.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Support document owns accepted product claims; trackers own live blockers.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to Three current E02 platform receipts, R03 decision, ADR-0003 and current source audit. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Documentation, protocols, receipts and dependency records: process/traceability metadata. Existing tests and measurement tools: verification aids; no new maintained framework or parser is authorized.

**Representation contract:** Exactly the named support matrix cells; claims limited to their recorded evidence.

**Contract closure:** Not triggered: metadata consolidation, no new runtime owner.

**Evidence budget and TDD:** Cross-check every declared matrix cell against its receipt once; no repeated measurement or new harness proof. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and Three current E02 platform receipts, R03 decision, ADR-0003 and current source audit. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Splitting default decisions from support would permit contradictory release claims; platform work is already separate.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### L02 — Release upstream-compatible wiremux integration

**Current state:** Complete. [v0.2.2 is published](https://github.com/GridSwarm/wiremux/releases/tag/v0.2.2); the [verified L02 receipt](https://github.com/GridSwarm/wiremux/issues/1533#issuecomment-5706947357) records final tags, assets and independent archive verification. Downstream compatibility, release and application adoption are complete through [C01](../research/c01-consumer-coverage.md); Z01 is complete; see the [aggregate closeout](../research/z01-program-closeout.md).

**What it delivers and acceptance criteria:** Follow wiremux's compatibility and release runbooks after L01. Retain upstream in the ordinary graph; publish optional fork selection, managed endpoint example, peer policy, fallback and ordinary-upstream rollback. Update public compatibility manifests for new facade. Choose actual version at execution and validate published archive.

**Blocked by:** L01.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Wiremux release workflow owns artifacts; public compatibility document owns supported API.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to docs/RELEASE.md, docs/COMPATIBILITY.md, release runbooks, E02 support matrix; affected API manifest. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Documentation, protocols, receipts and dependency records: process/traceability metadata. Existing tests and measurement tools: verification aids; no new maintained framework or parser is authorized.

**Representation contract:** Exact wiremux archive and its advertised optional fork version; module tooling owns selection.

**Contract closure:** Existing release and compatibility enforcement; new API constructor was covered in R02, no new runtime authority.

**Evidence budget and TDD:** The current documented wiremux release gate; archive smoke with upstream and exact fork replacement; no duplicate external release. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and docs/RELEASE.md, docs/COMPATIBILITY.md, release runbooks, E02 support matrix; affected API manifest. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** L01 is needed for a real immutable optional version. Release is separate from downstream replacement which does not propagate.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### C01-C — Qualify codemux against released wiremux

**What it delivers and acceptance criteria:** In GridSwarm/codemux, update wiremux pin and compatibility documentation to the released version as needed. Preserve PAKE, auth context, rendezvous consumption and error identities. Validate ordinary upstream selection and an isolated fork consumer module. This library does not impose a downstream replacement. One codemux PR; issue/plan ownership stays with wiremux program.

**Blocked by:** L02.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Codemux owns dependency selection and PAKE composition; wiremux owns packet lifecycle.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to codemux go.mod:8,23 at inventory revision; root facade and PAKE composition tests; codemux AGENTS/review policy; L02 release contract. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Runtime API and diagnostics: shipped behavior. Admission, progress and lifecycle guards: required safety enforcement. Tests: verification aids; no maintained-aid exception.

**Representation contract:** The standard-library packet/address and explicit registration domain in the design contract; universal enforcement within that domain, finite regression evidence.

**Contract closure:** Use the matching owner row in the design contract semantic matrix; write the named positive and distinct failure regressions first.

**Evidence budget and TDD:** Existing task verify plus dependency gate; consumer-shaped successful/failed PAKE and teardown; upstream/fork fixture selection. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and codemux go.mod:8,23 at inventory revision; root facade and PAKE composition tests; codemux AGENTS/review policy; L02 release contract. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Library compatibility can merge before application adoption. Pin/documentation and affected caller fixture are one behavior.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### C01-CR — Release qualified codemux compatibility

**What it delivers and acceptance criteria:** Publish an immutable codemux compatibility release through its release procedure if C01-C changed the published module; otherwise commit a reasoned no-release-needed receipt in wiremux. Record exact artifact and version for application selection. One release-note/receipt PR in the owning repository.

**Blocked by:** C01-C.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Codemux release workflow owns artifact; receipt owns no-release disposition.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to Codemux release runbook and merged C01-C; no unrelated API work. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Documentation, protocols, receipts and dependency records: process/traceability metadata. Existing tests and measurement tools: verification aids; no new maintained framework or parser is authorized.

**Representation contract:** One exact library release or source-backed non-applicability disposition.

**Contract closure:** Not triggered for metadata; existing release enforcement remains required.

**Evidence budget and TDD:** Existing release-gate and module download if released; otherwise compare C01-C against actual existing archive. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and Codemux release runbook and merged C01-C; no unrelated API work. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Separate compatibility code from release administration. Applications need a real selected version or verified unchanged published API.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### C01-G — Adopt qualified libraries in GridCastIO/gridcast

**What it delivers and acceptance criteria:** In GridCastIO/gridcast, update released wiremux/codemux pins and explicit main-module fork replacement. Keep optional acceleration policy consistent with E02; exercise production connection setup, traffic, idle/cancel/teardown and ordinary-upstream rollback in an isolated fixture. Document how to disable any fork-only managed path before rollback. No production deployment is required by this PR.

**Blocked by:** L02, C01-CR.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Application main module owns actual QUIC selection and runtime policy; underlying library owners retain transport/identity contracts.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to Application go.mod, connection construction and existing workload fixtures; repository AGENTS/review/release policy; L01/L02/C01-CR versions. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Runtime API and diagnostics: shipped behavior. Admission, progress and lifecycle guards: required safety enforcement. Tests: verification aids; no maintained-aid exception.

**Representation contract:** The standard-library packet/address and explicit registration domain in the design contract; universal enforcement within that domain, finite regression evidence.

**Contract closure:** Use the matching owner row in the design contract semantic matrix; write the named positive and distinct failure regressions first.

**Evidence budget and TDD:** One production-shaped success and distinct failure/idle/teardown cases; actual module graph and artifact build; upstream rollback selection; current repository local/hosted gates. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and Application go.mod, connection construction and existing workload fixtures; repository AGENTS/review/release policy; L01/L02/C01-CR versions. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Each application is independent after library releases; combining them violates one repository/PR context. No dependency on sibling application.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### C01-T — Adopt qualified libraries in SwarmCast/tapmux

**What it delivers and acceptance criteria:** In SwarmCast/tapmux, update released wiremux/codemux pins and explicit main-module fork replacement. Keep optional acceleration policy consistent with E02; exercise production connection setup, traffic, idle/cancel/teardown and ordinary-upstream rollback in an isolated fixture. Document how to disable any fork-only managed path before rollback. No production deployment is required by this PR.

**Blocked by:** L02, C01-CR.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Application main module owns actual QUIC selection and runtime policy; underlying library owners retain transport/identity contracts.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to Application go.mod, connection construction and existing workload fixtures; repository AGENTS/review/release policy; L01/L02/C01-CR versions. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Runtime API and diagnostics: shipped behavior. Admission, progress and lifecycle guards: required safety enforcement. Tests: verification aids; no maintained-aid exception.

**Representation contract:** The standard-library packet/address and explicit registration domain in the design contract; universal enforcement within that domain, finite regression evidence.

**Contract closure:** Use the matching owner row in the design contract semantic matrix; write the named positive and distinct failure regressions first.

**Evidence budget and TDD:** One production-shaped success and distinct failure/idle/teardown cases; actual module graph and artifact build; upstream rollback selection; current repository local/hosted gates. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and Application go.mod, connection construction and existing workload fixtures; repository AGENTS/review/release policy; L01/L02/C01-CR versions. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Each application is independent after library releases; combining them violates one repository/PR context. No dependency on sibling application.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### C01 — Reconcile consumer coverage and reusable example

**Current state:** Complete. The [consumer inventory and reusable example](../research/c01-consumer-coverage.md) record the six-module recheck, selected releases, adoption/rollback receipts and bounded example evidence. C01-CR, C01-G and C01-T are complete; no new consumer child is required. Z01 is complete and owns the [aggregate closeout](../research/z01-program-closeout.md).

**What it delivers and acceptance criteria:** Recheck the inventoried portfolio modules. Link consumer PRs, exact selected module versions and rollback receipts. Record keymux/current SwarmCast as dormant/not consumers unless their source changed; legacy migration stays excluded unless separately authorized. Retain a standard-type external-wrapper/managed example usable outside wiremux, without claiming nonexistent deployment. Any newly active in-scope consumer receives an audited named adoption child before Z01.

**Blocked by:** C01-G, C01-T, C01-CR.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Consumer inventory document owns coverage/dispositions; each main module owns its selection.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to Inventory table, completed consumer contracts, fork optional interface example and release artifacts. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Documentation, protocols, receipts and dependency records: process/traceability metadata. Existing tests and measurement tools: verification aids; no new maintained framework or parser is authorized.

**Representation contract:** Inventoried owned active modules; no universal claim over all GitHub repositories.

**Contract closure:** Not triggered for inventory metadata; ordinary example is a verification aid.

**Evidence budget and TDD:** Read current module manifests and example compile in upstream/fork isolated modules; one readback per receipt. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and Inventory table, completed consumer contracts, fork optional interface example and release artifacts. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Reconciliation must follow actual adopters. New consumers cannot be silently excluded or added as unbounded code work.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

### Z01 — Close the complete cross-repository program

**Current state:** Complete. The [aggregate closeout ledger](../research/z01-program-closeout.md) reconciles all 32 stable IDs, native support, release/adoption and rollback receipts, R03/P02 decisions and retired experimental seams. No successor remains. Both program parents and the tracker close through Z01 after merge and journal. Ordinary defaults and performance non-claims remain unchanged.

**What it delivers and acceptance criteria:** Every remaining mandatory row and expanded consumer child must be done with merged revision/release/evidence links. Verify E01-L/W/D have explicit superseded dispositions, not invented measurement receipts. R03 and P02 must have explicit outcomes; blocked native support cannot be silently called complete. Publish one support matrix covering platform, socket class, active feature, reuse contract, selected-peer owner and fallback reason, plus ordinary upstream and fork rollback instructions. Verify all temporary experimental seams have been removed or adopted deliberately. Reconcile both parent trackers against this ledger. Only this row may close the program parent.

**Blocked by:** C01.

**Existing-work disposition:** New slice. Prior local design commits are replaced by this audited plan; no unmerged implementation is adopted. See audit for source/history disposition.

**Single owner after merge:** Program tracker owns completion transition; normative plans own contracts and evidence files own receipts.

**Authority completeness:** No new persisted fact or restart format. For in-memory authority, construction, validation, failure cleanup and each destructive/security-sensitive consumer named in this slice land together. Unregistered existing behavior retains its current owner.

**Transitional-seam budget:** No temporary duplicate owner. Ordinary upstream/fallback paths remain supported permanently.

**Blast radius:** Limited to Current overview, support matrix, release/adoption receipts and live trackers only. Shared/global state changes are forbidden. The ownership, concurrency, public interface, failure, security, performance and dependency effects are those explicitly named in delivery and tests; any newly found effect outside these owners is a stop condition, not an accepted unknown.

**Artifact classification:** Documentation, protocols, receipts and dependency records: process/traceability metadata. Existing tests and measurement tools: verification aids; no new maintained framework or parser is authorized.

**Representation contract:** Finite audited slice ledger and named consumer expansion; universal bookkeeping over those IDs.

**Contract closure:** Not triggered: process metadata; no runtime owner.

**Evidence budget and TDD:** Check one-to-one slices/issues/PRs/tasks; all required capability and release receipts, R03/P02 decisions, and rollback. No repeated runtime campaign. One positive per materially distinct behavior and one negative per failure mode; at most one discriminating guard-bypass per new owner when necessary, no mutation required for prose. Only E02-L/W/D run the final assembled performance comparison; this slice adds no standalone adoption campaign. One initial review and at most one replacement. Terminate when named evidence passes or records an allowed negative design disposition; missing required environment stays blocked.

**Dispatch context budget:** This slice, referenced design subsections/matrix rows and Current overview, support matrix, release/adoption receipts and live trackers only. Load at most these named owners and their focused tests (target under 25k source/context tokens, no whole historical plan); reserve the rest of a fresh context for implementation, review fixes and verification. If the relevant diff cannot fit, re-audit before implementation rather than overflow into a second implicit PR. No unresolved implementation history is inherited.

**Slice decision audit:** Only this aggregate closes both programs. C01 transitively includes every mandatory platform/reuse/release branch.

**Stop conditions:** Stop on unsupported representation, second mutation owner, missing full reader/writer join where this slice requires it, a newly required public topology or capability bypass, untraced blast radius, or inability to fit the accepted outcome in this PR. Use the shared precise-root comparison before declaring repeated review roots. Missing native access blocks only dependent evidence; do not weaken required correctness or inflate repetitions.

## Operating discipline and validation

The shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice` govern directly, composed with [this repository overlay](../REVIEW-LOOP.md). They own representation/artifact gates, finite evidence/review budgets, semantic-family closure and review/verification-aware approach stops. Use exact-head local certification, same-head applicable hosted CI, matched-head squash merge, then append-dev-journal and pointer reconciliation. Diagnose before any rerun. Keep audit history out of this current contract.

Wiremux code slices run `task verify` and named focused/native gates after the installed Go floor audit; documentation-only slices use `task docs-check`, matching the documented Taskfile routing. Consumer PRs use their own repository gates and overlays after reading their AGENTS.md; this plan never substitutes wiremux checks for consumer checks.

Before any Go subcommand beyond approved environment/version auditing, enforce the repository installed-toolchain floor. Never treat skipped hosted jobs as required success. Each child updates only live state/pointers; no child closes a program parent. Z01 is the sole full-program closeout. The plans may be revised through scoped audit, but no mandatory outcome may disappear.
