# Architecture Deepening Program — 2026-08-25

**Status:** Tracks 1 and 2 implemented by PRs #1336 and #1338; program complete

## What this is

This is the dispatch index for the 2026-08-25 architecture review and delegated grilling of all four candidates. The two linked track plans are the normative source of truth; this index records stable program identity, dependencies, frontier, sizes, outcomes closed without code, and binding rules. Review chronology and temporary report artifacts are intentionally not mirrored here.

## Outcomes that require no implementation

- Do not create a generic `wiremuxtest` paired-operation envelope now. `wiremuxtest/pair_results.go:20-209` already owns bounded close, completed-result preference at timeout, late-result disposal, and resource ownership; `PairStreams` at `wiremuxtest/pair.go:54-113` and `DialPair` at `wiremuxtest/dial.go:51-104` retain meaningfully different success, failure-publication, partial-resource, and relay-health policies. Reconsider only after a third paired operation or a concrete lifecycle defect must be fixed in both helpers.
- Do not create another waiting-peer transport-lifetime module. `pairSession` and `pairProxySession` already own accepted-connection I/O choreography at `relay/pair_session.go:8-25,118-194,213-290`, the rendezvous ledger owns resolution and pairing accounting at `relay/ledger.go:317-400,562-568,627-703`, and `TakeWaiter` at `relay/ledger.go:659-670` joins the waiter's watcher defined at `relay/waiter_watcher.go:125-180` before handing the connection plus an immutable prefix snapshot to proxying. ADR-0004 and `2026-07-05-relay-pair-session-plan.md` remain binding; reconsider only upon a concrete race or ownership defect that the existing seam cannot enforce.
- Do not merge Candidate wire codes or validators into the Candidate-kind semantic authority. ADR-0012's v1 and TURN-retry adapters remain separate representation owners.
- Do not redesign the direct-upgrade classifier, transition table, or terminal fallback exchange. Track 2 deletes only result projections around the existing authority.
- No new domain term is required. `CONTEXT.md` already defines Candidate, Host candidate, Reflexive candidate, Relay candidate, Candidate policy, Selected candidate pair, and Carrier topology; direct-control event names remain implementation vocabulary.

## Tracks, dependencies, and frontier

| # | Track | Plan | Parent issue | Blocked by | Slices | Size | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Candidate-kind semantic authority | [`2026-08-25-candidate-kind-semantic-authority-plan.md`](2026-08-25-candidate-kind-semantic-authority-plan.md) | #1328 | None | 1 | Medium | COMPLETE |
| 2 | Direct-control event projection deletion | [`2026-08-25-direct-control-event-projection-deletion-plan.md`](2026-08-25-direct-control-event-projection-deletion-plan.md) | #1329 | None | 1 | Small | COMPLETE |

The slices are parallel-safe at the production-code level and have no cross-track blocking edge because they touch disjoint implementation files and invariants. Track 1 is implemented by PR #1336 and Track 2 by PR #1338; no implementation frontier remains in this program.

## Rules that bind every track

- Preserve the v0.1.x public interface, wire protocol, documented errors, Candidate and fallback semantics, transition behavior, lifecycle ordering, packet ownership, Datagram behavior, and downstream compatibility unless a track plan explicitly authorizes a change; neither does.
- Each domain fact, protocol classification, and lifecycle transition touched by a slice has one named owner after merge. Permanent v1/TURN adapters may translate distinct representations but must not become a shared domain state machine.
- Neither slice budgets a temporary compatibility path, duplicate representation, generic mutation path, or double-open lifetime. If implementation requires one, stop for a decision rather than widening the slice.
- Universal claims use the supported domain, representation owner, guarantee level, and finite terminating evidence in the exact plan slice. Verification aids do not recursively strengthen shipped behavior.
- Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) and [`docs/CI.md`](../CI.md). Diagnose failures before reruns; perform exact-head local certification and same-head hosted CI before merge.
- Public/wire changes, a second semantic authority, or a required change to ADR-0004, ADR-0006, or ADR-0012 are approach stops. Route a changed representation owner, topology, adjacent scope, product decision, irreversible authority, or one-PR boundary back through `$architecture-handoff`.
- Post-merge ritual for each slice: bounded review loop → exact-head certification and same-head hosted CI → merge → `$append-dev-journal` → complete its OmniFocus slice task → reconcile the tracking issue and frontier.
