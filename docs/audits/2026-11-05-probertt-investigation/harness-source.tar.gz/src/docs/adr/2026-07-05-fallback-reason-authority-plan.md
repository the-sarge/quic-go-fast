# One Fallback-Reason Authority — Implementation Plan

**Date:** 2026-07-05
**Status:** Accepted; implemented by PR #467
**Track:** 2 of 3 in the 2026-07-05 upgrade deepening program
**Follow-up verification:** PR #504
**Related:** ADR-0006 D2/D4 (this track implements them)

## Goal

Make the upgrade fallback reason table a deep module: one public reason type,
one package-local table, one deterministic resolver, and hidden wire encoding
plus phase-validity helpers. The implemented module directly tests the
deterministic precedence rules used by terminal fallback exchanges
(CONTEXT.md) and by first-phase fallback settlement.

## Completion Note

PR #467 implemented this plan: the upgrade-fallback-reason authority now lives
in `connect/fallback_reason.go`, keyed directly by `UpgradeFallbackReason`.
The former `connect/internal/fallbackreason` package and delegation shims are
gone, and production call sites resolve through the package-private
`resolveFallbackReason(phase, local, peer)` helper.

Symmetric fallback exchanges use `resolveFallbackReason(phase, local, peer)`
so both peers converge on the same coarse reason from their local and peer
inputs. The one-sided first-phase peer fallback path validates with
`firstPhasePeerFallbackReason`, because that path is accepting a peer fallback
without a local fallback reason to resolve against.

Unknown wire values are owned by the upgrade-control codec tests in
`connect/control_codec_test.go`: malformed or unknown fallback wire payloads
decode as protocol mismatch at the frame boundary. The fallback reason table
tests own registry lookup, phase membership, precedence resolution, and the
wire-code mapping used by the codec; they do not duplicate every codec-path
malformation assertion.

## Historical Starting Shape (verified 2026-07-05)

This section records the pre-implementation shape that motivated the plan; it
is not the current layout.

- `connect/internal/fallbackreason/reason.go` (125 lines): string
  constants, wire uint64 constants, `Phase` bitmask, the `definitions`
  table (`reason.go:36-79`), `Resolve` (`reason.go:108-121`),
  `ValidForPhase`. **No test file exists for this package** — it is
  exercised only transitively.
- `connect/upgrade_fallback.go` (36 lines): six functions, each a one-line
  delegation into `fallbackreason`. Deletion test passes — removing the
  file concentrates nothing anywhere new.
- `connect/upgrade_types.go:34-43`: public `UpgradeFallback*` constants
  defined by aliasing the `fallbackreason` string constants.
- After Track 1, the codec (now in `connect`) was the only other consumer
  of the wire constants.

Load-bearing rules to preserve exactly:

- **Precedence ranks** (lower wins): `protocol_mismatch` 0,
  `not_requested` 1, `transport_mismatch` 2, `policy_excluded` 3,
  `no_candidates` 4, `transport_failed` 5, `probe_failed` 6
  (`reason.go:36-79`). Ranks are unique, so the `<=` tie-break in
  `Resolve` (`reason.go:117`) only equalizes identical reasons.
- **Phase validity**: `not_requested`/`no_candidates` first-phase only;
  `transport_mismatch`/`probe_failed` terminal only;
  `policy_excluded`/`protocol_mismatch`/`transport_failed` both
  (`reason.go:36-79`).
- **Fail-to-mismatch**: an unknown or phase-invalid reason (local or peer)
  resolves to `protocol_mismatch` (`reason.go:110-115`); an unknown wire
  code decodes to `protocol_mismatch`, never an error.

## Decision

Fold `connect/internal/fallbackreason` into `connect/fallback_reason.go`:

- `UpgradeFallbackReason` (the existing public string type) becomes the
  only reason representation; the definition table is keyed on it
  directly.
- Interface (package-private): `resolveFallbackReason(phase, local, peer)`,
  a phase-validity check, and wire encode/decode helpers used only by the
  codec. The `upgrade_fallback.go` shims are deleted; call sites use the
  resolver with an explicit phase.
- Direct tests at the table's interface: full precedence matrix, phase
  validity per reason, wire round-trip, unknown-value and phase-invalid
  defaulting.
- Public constants in `upgrade_types.go` keep their names and string
  values (public API frozen).

**Rejected alternative (do not do this):** keep the internal package and
add tests there. It preserves the three-representation split and the
delegation shims; the package has one consumer and fails the deletion
test as a boundary (ADR-0006 D4).

Non-goals were changing any precedence rank, phase assignment, wire code, or
string value; touching how the state machine chooses which phase to resolve in
(Track 3).

## Historical Implementation Slice

### PR 1 — Freeze behavior, fold, delete

This was the implementation order:

1. **First** write the direct table tests against the *current* internal
   package: a 7×7 precedence matrix per phase (expected winner for every
   pair), phase-validity table, wire round-trip for all seven reasons,
   unknown-string → `protocol_mismatch`, unknown-wire →
   `protocol_mismatch`, phase-invalid input → `protocol_mismatch`. Land
   them green — this freezes today's behavior.
2. Move table + resolver into `connect/fallback_reason.go` keyed on
   `UpgradeFallbackReason`; re-point the tests; delete
   `connect/internal/fallbackreason/` and `connect/upgrade_fallback.go`;
   update the codec's reason encode/decode to the folded helpers.

## Completed Verification

- `connect/internal/fallbackreason/` and `connect/upgrade_fallback.go` no
  longer exist; `grep -rn "fallbackreason" --include="*.go" .` returns
  nothing (excluding `.git-worktrees/`, `.ras/`).
- Exactly one reason representation remains (`UpgradeFallbackReason`);
  wire codes appear only inside the codec/table file.
- The precedence matrix, phase-validity, round-trip, and defaulting tests
  exist and pass.
- No exported identifier of package `connect` added, removed, or changed.

## Validation Gates

```bash
GOTOOLCHAIN=local go test ./connect/...
task verify
```

## Operating Discipline

The implementation followed `docs/REVIEW-LOOP.md`. The planned stop condition
was: if any matrix cell in the frozen-behavior tests surprised the implementer
(differed from the ranks listed above), stop and check with the operator before
folding. That would have meant the verified historical starting shape was
wrong, an approach-level finding.

Vocabulary: **upgrade fallback reason** and **terminal fallback exchange**
per CONTEXT.md; reasons are coarse result metadata, not peer blame.
