# TURN Composite Publication Implementation Plan

**Date:** 2026-09-04
**Status:** Complete
**Track:** 1 of 2 in the [2026-09-04 architecture deepening program](2026-09-04-architecture-deepening-program.md)
**Depends on:** Nothing
**Related:** [ADR-0012](adr-0012-turn-udp-relay-candidates.md), [TURN carrier prerequisites](2026-08-09-turn-carrier-prerequisites-plan.md), [conventions](../CONVENTIONS.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** [Handoff audit](../research/2026-09-04-architecture-handoff-audit.md)
**Implementation evidence:** [Publication characterization receipt](../research/2026-09-05-turn-publication-characterization.md)

## Goal

Concentrate the successful TURN packet composite publication transition in the existing composite module, so production and lifecycle fixtures no longer assemble its registration/publication/launch protocol. Characterize the suspected base-reader failure interval before changing behavior; any demonstrated correction must preserve one construction/terminal owner and be explicitly distinguished from the refactor.

## Current Shape (verified 2026-09-04)

- `connect/pionturn/allocate.go:72-95` creates unpublished composite state, starts the base source guard before allocation, and owns no-allocation failure cleanup.
- `allocate.go:98-118` assigns an existing allocation for rejected-construction disposal; its address/context validation failures reuse the terminal lifecycle without publishing.
- `allocate.go:121-130` installs allocation/address, registers consumer work, stores publication, and launches the consumer pump. `conn.go:142-159` exposes registration and launch separately. `forced_close_test.go:64-71` and `self_seal_test.go:146-154` repeat the recipe.
- The forced-close fixture deliberately omits the base source guard; the self-seal fixture runs it. Successful-publication consolidation must preserve this difference.
- `conn.go:218-242` exits on an unpublished base read error without retaining it. Allocation success can already have been delivered when this occurs; the success path has no explicit reconciliation before publication. This is an unverified interleaving hypothesis, not a reproduced defect or a frequency claim.
- `conn.go:20-29` defines the existing `relayAllocation` seam, satisfied by the real fork allocation and lifecycle fakes. `conn.go:575-580` requires a non-nil allocation before running its terminal executor.

## Decision

1. Keep the immutable allocator, concrete client creation, network allocation, early base-guard startup, and partial-construction policy in their current modules. Deepen only the existing composite's publication seam. No new package or public interface is needed.
2. Introduce one private successful-publication operation on `packetConn` that adopts a successful non-nil allocation and validated immutable relayed address, registers the consumer pump before publication, publishes, then launches the registered pump. Production and the two fake-allocation fixtures use it; independently callable consumer register/launch methods disappear from callers. Simplify the unpublished constructor's allocation/address inputs where this removes success-state preinstallation.
3. Internal publication enables concurrent terminal routing; public ownership transfers on non-nil Allocate return. Preserve official Allocate's nil-on-error contract after complete partial-resource cleanup/join. Never publish rejected construction merely to reuse a success operation.
4. Write a controlled characterization of a base-reader failure after allocation success-response delivery and before internal publication first. A bounded, private, nil-in-production `test`-prefixed barrier is permitted if the existing socket seam cannot order the event; no new general scheduler or external dependency seam is permitted. Repetition/sleep-based probability is not the evidence.
5. If that characterization demonstrates the interval, the accepted correction is precise: a base-reader failure recorded before publication must prevent successful publication, retain its cause, and dispose/join the existing allocation through the sole terminal lifecycle. A failure recorded after publication uses the existing published terminal route. Record and compare failure/publication under one synchronization authority; an atomic publication bit checked separately from an uncoordinated failure store is insufficient. Do not claim the carrier stays alive until first use.
6. Preserve address-validation-before-context precedence and exact cancellation cause. When rejection and an independently observed base failure coexist, retain the rejection cause and independent fault evidence without duplicating a cause or creating a second close. Before an allocation exists, do not invoke the allocation-requiring terminal executor; retain the current Allocate transaction cancellation/wait and cleanup policy. This change does not make base failure cancel a pending Allocate transaction earlier.
7. Preserve one dedicated-socket close authority, exact configured-server admission, immutable relayed/selected-peer values, logical deadlines, the existing two-second graceful-transition budget plus subsequent joins, induced-error normalization, and the existing stable terminal aggregate. Construction cleanup with an allocation still uses the existing graceful/forced lifecycle; recorded base death may take its existing forced path.
8. A failure characterization that cannot demonstrate a supported lost-fault history is a decision checkpoint: retain existing behavior, record the finite result, and use the same child for a scoped re-audit of the behavior-preserving publication consolidation if its outcome and one-PR scope remain intact. Do not invent a defect, add unused failure machinery, or leave a failing regression merged. A changed owner, broader failure family, or additional PR requires architecture-handoff.

**Rejected alternatives (do not do this):** Introduce a construction builder or typestate hierarchy; absorb the entire already-coherent allocator into another module; start the base guard unconditionally in the constructor; abstract the whole TURN client for fixture convenience; add a second terminal executor; or rename three independently callable publication steps without removing caller sequencing.

**Non-goals:** No TURN wire/protocol, retry, candidate, transport profile, public interface, dependency, credential, source-admission, or operator behavior redesign. No universal network liveness claim. No new overall Close deadline, broad stress profile, fixture framework, or guaranteed cancellation of arbitrary blocked I/O.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| T1.S1 | Complete | Characterized, centrally owned TURN publication through production and lifecycle fixtures | None | n/a; no transitional production seam |

## Implementation Slices

### Slice 1 — Own TURN composite publication and its fault handoff

**What it delivers:** One complete publication operation used by the official allocator and existing fake-allocation callers, with characterization first and the precisely bounded demonstrated fault correction, if required, in the same independently green PR. Tests distinguish correction from behavior-preserving consolidation.

**Existing-work disposition:** New slice. The handoff audit found no open PR or open issue implementing this track; historical merged TURN work is preserved. Retain the existing composite and allocation adapter, replace caller publication recipes, and close the unsupported broad-construction direction without code.

**Blocked by:** None. Auth observer ownership is independent.

**Single owner after merge:** `packetConn` owns successful publication, consumer registration/launch, and any recorded base-failure/publication ordering fact. The allocator owns incomplete construction and its outcome selection. The existing terminal executor remains the sole allocated-resource disposer; the once-backed base remains the sole physical close authority. A rejected-construction allocation assignment is not a second success-publication transition.

**Authority completeness:** If a recorded pre-publication fault becomes authoritative, this slice covers initialization, base-guard production, publication validation, address/context rejection consumers, terminal cleanup, and the two fixture constructors. No persistence or restart representation exists; each Allocate creates fresh state. No partially initialized allocation may reach the executor.

**Transitional-seam budget:** None. Real and fake allocation adapters are permanent representations at an existing seam, not transitional owners. Any private test barrier is a verification observation, nil in production, not a second mutation or close authority.

**Blast radius:** `connect/pionturn` construction, composite synchronization, and its tests. The only possible intended runtime change is retaining and settling a demonstrated pre-publication base-reader failure, including independent evidence on a competing construction rejection. Packet deadlines, selected-peer/source enforcement, library dependency, protocol and public method sets remain unchanged. Performance impact is bounded to construction/fault coordination, not a new per-datagram policy; preserve the hot-path source guard. No external infrastructure changes. Untraced effects are approach stops.

**Artifact classification:** Publication code is shipped behavior; registration-before-publication, cause retention and disposal ordering are required safety enforcement. Characterization tests, private barriers and existing fixtures are verification aids. Plan and diagnostic receipt are process metadata. No verification aid is approved as a separately maintained blocking deliverable; required focused test results demonstrate the accepted behavior, without recursive harness certification.

**Representation contract:** Supported domain is one official, internally owned dedicated TURN/UDP socket and one allocation per immutable allocator call, the existing validated canonical server/relayed addresses, and base-reader outcome observations ordered before/after publication. The dependency owns TURN parsing; existing validators own address canonicalization. `packetConn` owns publication/fault state and the allocator owns construction outcome. Guarantee is canonical-subset preservation over these constructors and resource paths, plus example-level deterministic evidence for the investigated interleaving, not arbitrary PacketConn implementations or physical fault frequency. Quantified acceptance below is limited to this finite caller/state census.

**Contract closure:** Not triggered. Broken lifecycle has material consequences, but the changed success/rejection/publication ordering fits the bounded focused cases below; routine ordering and multiple callers alone do not satisfy the shared second trigger. No formal exhaustiveness claim or mandatory mutation matrix is introduced.

**Evidence budget:** Four planned controlled cases: success with an already self-sealed allocation; reader failure recorded before publication; reader failure ordered after publication; and competing context rejection with independent recorded fault. Add at most one invalid-address competition only if it differs semantically from the existing rejection route; the maximum is five new controlled cases. Retain existing canceled-allocation, invalid-address, concurrent allocation, forced-close, source-guard, self-seal and worker-join tests. One caller/store audit. No required mutations, new platform cells, statistical repetitions, or new hosted experiments. One initial fully briefed review and at most one replacement; terminate at passing named evidence plus repository gates and no unresolved stop-for-decision.

**TDD and preservation evidence:** First characterize the pre-publication history through the existing socket seam and permitted barrier; record its observed behavior before edits. A demonstrated failure gets a failing regression for nil/error plus joined cleanup before the central fix. Keep `TestAllocateCancellationDuringBlockedEstablishment`, `TestAllocateRejectsInvalidRelayedAddress`, `TestAllocateConcurrentIndependentComposites`, `TestForcedCloseInterruptsBlockedPionIO`, `TestBaseDeathForcesTerminalPath`, `TestAllocationSelfSealTerminalizesAndWakesConsumers`, `TestCloseJoinsAllCompositeOwnedWork`, and `TestBaseSourceGuardDiscardsSecondSender`. Preserve the distinct fixture pump arrangements. The existing invalid-address case is dependency rejection, not sole evidence of the composite's defensive branch.

**Dispatch context budget:** This current plan and program rules; ADR-0012's carrier decision and the prerequisite plan's current construction/disposal bullets only; `connect/pionturn/{allocate,conn,pionturn}.go`; `allocator_test.go`, `forced_close_test.go`, `self_seal_test.go`, `census_test.go`, `source_guard_test.go`, `fixture_test.go`; root go.mod's exact TURN pin and the pinned dependency's `Client.Allocate`/`HandleInbound` only for the characterization. No retry engine, full historical plan copies, or broad repo review. One narrow module and two fixture callers fit implementation, local review fixes and verification in one fresh context. Size: Small implementation, Medium concurrency risk.

**Slice decision audit:** Strongest split is a characterization-only PR before publication. Rejected because the regression and its central owner can be completed in one context, and a separate test/receipt PR either pins a known failure as desired behavior or leaves the successor's accepted behavior unresolved. Characterization still occurs first; a material assumption failure stops/scoped-re-audits rather than widening the PR. Separating production migration from fixture migration would leave the exact caller recipe being removed and yields no independent outcome. Merging with auth is rejected because it combines unrelated owners and timing contracts. There are no genuine blocking edges.

**Stop conditions:** No supported deterministic characterization for the proposed correction; a need to change pending-Allocate cancellation policy, external syntax parsing, source admission, public error guarantees outside the named observed-fault case, disposal ownership, retry/transport behavior, or the one-PR boundary; missing worker join; or scope/evidence expansion. Apply scoped re-audit only while the accepted owner/outcome/one-PR contract remains intact; otherwise return for handoff. A merely unreproduced hypothesis is never silently promoted to a bug.

## Acceptance Criteria

- [x] T1.S1's supported production and two fake-allocation success callers use one publication operation; no caller separately sets publication or registers/launches the consumer pump.
- [x] Consumer registration precedes publication and consumer launch follows it in that owner; existing distinct base-pump arrangements remain intact.
- [x] The suspected fault history has a bounded characterization receipt. Any demonstrated correction enforces the declared construction-versus-published disposition, preserves primary rejection/cancellation cause and independent fault evidence, and joins owned cleanup before official Allocate returns nil/error.
- [x] No-allocation construction never invokes the allocated terminal executor; rejected allocated construction never gains successful publication; the declared constructor paths retain one physical socket close and stable terminal results.
- [x] The named preservation tests and repository gates pass without expanding protocol, public interface, dependency or ownership scope.

The representation contract and evidence budget bound every quantified criterion; the caller/store audit and focused outcome cases terminate verification.

## Validation Gates

Audit the installed/base Go toolchain under AGENTS.md before any build/test command. Run `go test ./connect/pionturn`, then `GOMAXPROCS=1 GOTOOLCHAIN=local go test -race ./connect/pionturn` once for the changed lifecycle paths, then `task verify`. Use any narrower named new-case match only after verifying it matches tests. Required hosted `ci-*` jobs certify the same final head; do not add ad hoc platform or timing matrices.

## Operating Discipline

The shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice` govern, composed with repository [review-loop](../REVIEW-LOOP.md), [CI](../CI.md), [conventions](../CONVENTIONS.md), and root AGENTS.md. No repository-specific contract-closure overlay exists. Those shared baselines own representation/artifact gates, semantic-family classification, precise-root history comparisons, finite evidence/review budgets, diagnosis before reruns and approach stops. Repository gates provide exact-head local certification and same-head hosted CI. After exact-head merge: append-dev-journal, complete the child task, reconcile the parent/tracker frontier. Metadata readiness is not code-head certification. Do not reopen settled ADRs or broaden an invariant to manufacture a repeated root.
