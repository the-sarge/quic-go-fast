# Relay Abuse Signals Program — 2026-08-12

**Status:** Implemented by PR #1135; no remaining implementation frontier

## What this is

This is the dispatch index for the scoped 2026-08-12 architecture handoff covering one grilled candidate from the 2026-08-12 architecture review: deepening the relay's ephemeral abuse-signal policy into one module. The linked track plan is the normative source of truth for implementation; this index records stable identity, dependencies, the frontier, and review outcomes deliberately left outside this program.

## Outcomes that require no implementation in this program

- The 2026-08-12 review's other candidates are not packaged here and are neither authorized nor closed by this program. In particular: the upgrade terminal-executor disposal-plan candidate is a sequencing decision against the TURN/UDP program's Track 2 Slice 2.3 lifecycle rebaseline ([`2026-08-09-turn-udp-architecture-program.md`](2026-08-09-turn-udp-architecture-program.md)) and must not be dispatched independently of it; the serve-flag descriptor-table and wiremuxtest fixture-operation candidates await their own grillings and scoped handoffs.
- Do not change the exported ephemeral abuse configuration or flag surface (`relay/abuse_backoff.go:10-184`); the serve-flag mirror candidate owns that territory if and when it is packaged.
- Do not merge the backoff tracker mechanism into the policy module; composition is the accepted shape.
- ADR-0004 (rendezvous ledger owns pair resolution) and the 2026-07-05 pair-session strategy-fields shape remain settled; this program changes neither.

## Tracks, dependencies, and frontier

| # | Track | Plan | Parent issue | Blocked by | Slices | Status |
|---|---|---|---|---|---|---|
| 1 | Relay abuse signals | [`2026-08-12-relay-abuse-signals-plan.md`](2026-08-12-relay-abuse-signals-plan.md) | #1130 | None | 1 | COMPLETE |

The single child slice is implemented by PR #1135. No implementation frontier remains in this program.

## Rules that bind every track

- Preserve the v0.1.x public interface, wire protocol, documented error identities, and every observable abuse-control behavior; this program is a behavior-preserving deepening with no compatibility path or shadow owner budgeted.
- Each production fact or transition touched has one owner after merge: the signals module for abuse-signal judgment, suppression, and park admission; the tracker for windowed counting and delay; the runtime for the closing fact.
- Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) and the certification lanes in [`docs/CI.md`](../CI.md).
- Public-interface changes are stop conditions. If a plan assumption fails outside the accepted one-PR boundary, stop for a decision rather than broadening the slice.
- Post-merge ritual: review → exact-head certification/same-head CI → merge → append-dev-journal → complete the OmniFocus task → update the tracker and frontier.
