# Candidate-Kind Semantic Authority Implementation Plan

**Date:** 2026-08-25
**Status:** Accepted; implemented by PR #1336
**Track:** 1 of 2 in the 2026-08-25 architecture deepening program
**Depends on:** nothing — safe to start first
**Related:** ADR-0006, ADR-0012, [`2026-08-12-session-consumption-selected-pair-program.md`](2026-08-12-session-consumption-selected-pair-program.md), issue #1087 and PRs #1242/#1243
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** none

## Goal

Give the three Candidate kinds one unexported semantic authority inside `connect` so validity, stable preference, direct-path eligibility, relay role, topology classification, and policy kind validation have one local source of truth, while Candidate-policy list membership narrows to a `CandidateKind` input and the compatibility-frozen v1 and TURN-retry wire adapters continue to own their separate numeric representations and frame validation.

## Current Shape (verified 2026-08-25 at `31d2be75de614950e6b104a447886a4dbd5a3667`)

- `CandidateKind` and its host, reflexive, and relay constants are defined at `connect/gather.go:15-27`; `Candidate` carries the kind and address at `connect/gather.go:29-33`.
- Stable kind preference is a switch in `connect/gather.go:515-526`, while policy validation separately recognizes the same finite kind set in `connect/upgrade_types.go:355-403`.
- Candidate-policy evaluation legitimately inspects interfaces and address prefixes at `connect/candidate_plan.go:49-63,193-201`, but its kind-list helper alone takes a whole `Candidate` even though it compares only `Kind` at `connect/candidate_plan.go:203-205`; TURN retry consequently constructs a synthetic relay Candidate solely to ask whether relay is excluded at `connect/turn_retry_entry.go:27-34`.
- Candidate policy also treats a reflexive Candidate with no attributed local interface as matching an interface exclusion/deprioritization rule at `connect/candidate_plan.go:49-58`. That is retained Candidate-policy interface-attribution semantics, deliberately outside the classifier's recognized/preference/direct/relay facts.
- The v1 planner derives kind ordering through `candidateKindOrder` and admits probe candidates by asking the v1 wire encoder whether the entire Candidate can be encoded at `connect/candidate_plan.go:106-161,170-190` and `connect/probe_engine.go:138-150`.
- Carrier topology independently defines `{host, reflexive}` as direct and relay/relay as relay-assisted at `connect/carrier_topology.go:26-56`.
- The authenticated probe layer already has one parameterized implementation with dialect-specific kind adapters at `connect/probe.go:63-106,280-298`. The v1 control codec maps only host/reflexive at `connect/control_codec.go:260-279,332-353,384-408,891-900`; the TURN-retry codec admits only relay at `connect/turn_retry_codec.go:224-252,465-495`. Those separate mappings are required protocol-adapter responsibilities, not duplicate domain authority.
- Issue #1087 was completed by PRs #1242/#1243 and consolidated the probe implementation and CBOR scanner without merging the two wire dialects. No open issue, PR, or implementation branch owns this residual semantic-authority work. The 2026-08-12 program explicitly recorded candidate-kind locality as not packaged.

## Decision

- Add one unexported `connect` module, expected to live in `connect/candidate_kind.go`, whose narrow interface classifies a `CandidateKind` into stable domain facts: recognized/valid, preference rank, direct-path eligibility, and relay role. The implementation may use one finite lookup or switch and must return fail-closed facts for an unknown value.
- Keep `CandidateKind`, its constants, `Candidate`, and every exported method or option unchanged. Do not introduce a Go interface, exported classifier, builder, registry, or extension mechanism.
- Route policy kind validation, stable kind ordering, the kind half of direct Candidate eligibility used by planning, and `UpgradeResult.CarrierTopology` through that authority. Direct planning eligibility remains conjunctive: the semantic authority must admit the kind and the existing probe adapter must still accept the full Candidate/address. Preserve address validity and address-family checks at their existing owners, and forbid replacing `probeCandidateSupported` with a kind-only predicate.
- Change the policy-owned kind membership helper to accept `CandidateKind` rather than a whole `Candidate`; update local/remote policy consumers and TURN-retry relay exclusion so no synthetic Candidate is needed. List membership remains owned by Candidate policy and does not become another classifier fact.
- Keep v1 probe bytes, v1 control codes, TURN-retry probe bytes, TURN-retry control codes, and decode validation in their dialect adapters. Their numeric codes and accepted frame shapes must not enter the domain semantic authority.
- Preserve current ordering exactly: host before reflexive before relay before unknown. Preserve direct eligibility exactly for host/reflexive, relay role exactly for relay, and invalid/fail-closed treatment for every other value.
- Add a single table-driven semantic matrix over host, reflexive, relay, and unknown. Retain dialect-specific codec/probe golden and rejection tests, Candidate-policy behavior tests, and Carrier-topology shape tests; remove or consolidate only assertions made redundant by the new semantic matrix.

**Rejected alternative (do not do this):** Build one universal Candidate metadata table containing v1/TURN wire codes, frame validators, or encoded representations. That would couple stable domain meaning to two separately frozen dialect adapters and contradict ADR-0012's representation split.

**Rejected alternative (do not do this):** Export the semantic classifier or add a pluggable Candidate-kind registry. v0.1.x has a closed three-kind domain; extension authority would be a public contract change with no accepted consumer.

**Rejected alternative (do not do this):** Treat wire encodability as the sole domain classifier. Address validity and dialect representation are adapter concerns; using encoder success as the only definition of direct eligibility obscures the domain rule and keeps topology, policy, and planning coupled to a wire format.

**Non-goals:** no new Candidate kind; no public API, option, error identity/tree, fallback reason, ordering, selected-pair shape, Carrier topology, probe scheduling, packet ownership, wire byte, codec validation, or downstream migration change; no codec consolidation follow-up; no changes to candidate address validity or address-family policy.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | implemented by PR #1336 | One Candidate-kind semantic authority used by every in-scope domain consumer while protocol adapters remain separate | None | n/a — no temporary seam introduced |

## Implementation Slices

### Slice 1 — Concentrate Candidate-kind domain semantics

**What it delivers:** A behavior-identical `connect` package in which one unexported classifier owns the recognized set, preference rank, direct-path eligibility, and relay role; policy matching is kind-level; planning and topology consume the shared facts; and v1/TURN adapters retain only representation-specific mappings and validation.

**Existing-work disposition:** New residual slice. Retain the completed #1087 codec consolidation and the implemented ADR-0012 TURN work unchanged; this slice packages the candidate-kind locality item that the 2026-08-12 program explicitly left unowned. No open PR, issue, or competing branch was found.

**Blocked by:** None.

**Single owner after merge:** The unexported Candidate-kind semantic module owns recognized membership, preference, the kind half of direct eligibility, and relay role. Candidate-policy code owns caller-supplied kind-list membership, inclusion/deprioritization choices, and the retained reflexive-without-interface attribution rule. The probe adapter continues to own full Candidate/address encodability. Carrier topology owns whole-result shape validation. Each v1 or TURN adapter owns its own numeric code and frame representation.

**Authority completeness:** No persisted fact is introduced. The finite reference census must route policy kind validation, preference, the kind half of direct planning eligibility, and topology role through the classifier; retain `connect/candidate_plan.go:51` as policy-owned interface attribution rather than a fifth classifier fact; require policy list membership to take a kind without becoming a classifier consumer; and separately prove that full Candidate/address encodability and every protocol representation remain owned by their current adapters.

**Transitional-seam budget:** None. The classifier and all in-scope migrations land atomically. The retained v1/TURN representation switches are permanent adapters with distinct representation contracts, not a temporary duplicate semantic authority.

**Blast radius:** The production blast radius is limited to Candidate planning, policy, topology derivation, and kind predicates inside `connect`; no concurrency or lifecycle owner changes. Public interface and string values are frozen. Error identity/text, Candidate order, fallback classification, selected-pair validity, and wire acceptance are material preservation obligations. No performance, security, dependency, platform, or downstream effect is accepted. Untraced effects: none after the required reference census.

**Artifact classification:** The semantic classifier and migrated consumers are shipped behavior with intentionally unchanged observation. The semantic matrix, retained protocol vectors, focused policy/topology tests, and reference census are verification aids; none becomes an independently maintained product deliverable. This plan, issues, review receipts, and task mirrors are process/traceability metadata.

**Representation contract:** Supported input domain = every Go `CandidateKind` string, partitioned into the three canonical constants and the unknown/default class. Representation owner = the unexported classifier for domain facts; the v1 and TURN codec/probe adapters for their separate wire codes and frames. Guarantee = universal for domain classification because one switch or lookup with a default owns the whole Go string domain; canonical-subset preservation for protocol frames as already enforced by each adapter. Terminating evidence = the four-row semantic matrix, a reference census, existing adapter golden/rejection tests, focused policy/topology/planning tests, and the repository gate.

**Contract closure:** Not triggered. Incorrect Candidate classification can change compatibility-visible behavior, but the accepted domain has four finite semantic classes and ordinary focused tests plus the existing adapter vectors reasonably cover them; multiple consumers alone do not meet the shared closure trigger. A new Candidate kind or inability to preserve adapter ownership is a stop condition rather than a reason to expand evidence.

**Evidence budget:** One semantic-matrix row each for host, reflexive, relay, and one arbitrary unknown value; one representative policy membership/exclusion case for each recognized role and unknown rejection; existing valid and invalid topology shapes; the invalid-address planner characterization in `connect/probe_engine_test.go:23-74,77-146`; existing v1 and TURN codec/probe golden and wrong-kind rejection cases; one before/after reference census of the named semantic helpers and direct kind switches that records `connect/candidate_plan.go:51` as retained policy-owned interface attribution. No mutation harness, fuzzing, new platform matrix, timing run, or repetition profile. Review budget = one initial review plus at most one fully briefed replacement review. Terminate when the matrix and focused tests pass, invalid Candidate addresses remain excluded, the reference census shows the intended single owner and explicit policy exception, adapter mappings remain dialect-local, and `task verify` passes.

**TDD and preservation evidence:** Write the four-row semantic matrix first, including the unknown fail-closed row, then migrate one consumer family at a time while keeping `TestUpgradeResultCarrierTopologyClassifiesCanonicalShapes`, Candidate-policy/planner tests, the valid/invalid Candidate address matrix in `connect/probe_engine_test.go:23-146`, probe wrong-kind tests, control-codec tests, TURN-retry codec tests, and TURN relay-policy tests green. The pre-edit characterization is current observable behavior; no test may be weakened merely to accommodate the refactor.

**Dispatch context budget:** This exact slice contract; ADR-0012; the Candidate and glossary definitions; `connect/gather.go`, `connect/upgrade_types.go`, `connect/candidate_plan.go`, `connect/probe_engine.go`, `connect/carrier_topology.go`, `connect/turn_retry_entry.go`, and their focused tests; only the kind-mapping sections of `connect/probe.go`, `connect/control_codec.go`, and `connect/turn_retry_codec.go` as adapter guardrails; issue #1087's closure note if history is needed. This bounded context fits implementation, one review/fix cycle, and verification in one fresh agent context.

**Slice decision audit:** Splitting classifier introduction from consumer migration would leave two semantic owners or dead abstraction, so the slice is atomic. Splitting policy/topology/planning into separate PRs would widen a transitional seam without reducing any individual risk enough to justify it. Merging the direct-control projection track would combine unrelated invariants and review surfaces. There are no genuine blocking edges.

**Stop conditions:** Stop if the refactor requires a public API or Candidate-kind extension change, moves wire codes or frame validation into the semantic module, changes any accepted/rejected wire shape, changes Candidate order or topology/fallback outcomes, creates a second semantic table, or cannot separate domain eligibility from address validity without changing behavior.

## Acceptance Criteria

- [x] One unexported Candidate-kind classifier owns recognized membership, preference rank, direct-path eligibility, and relay role for the supported `CandidateKind` domain.
- [x] The finite semantic matrix records host as recognized/direct/rank 0, reflexive as recognized/direct/rank 1, relay as recognized/relay/rank 2, and unknown as invalid/neither/rank 3.
- [x] Policy kind validation, kind ordering, the kind half of direct planning eligibility, and Carrier-topology role checks consume that authority; the reference census finds no second domain-fact switch in those consumers.
- [x] Direct planning eligibility remains the conjunction of shared kind admission and existing full Candidate/address encodability; every currently invalid address remains excluded.
- [x] Candidate-policy kind-list matching accepts a `CandidateKind`, remains policy-owned rather than classifier-owned, and TURN-retry relay exclusion no longer constructs a synthetic `Candidate`.
- [x] Every v1 and TURN numeric mapping, frame validator, golden vector, and wrong-kind rejection remains owned and preserved by its existing protocol adapter.
- [x] Public API, Candidate string values, errors, ordering, policy outcomes, selected-pair validity, topology, fallback behavior, wire bytes, and downstream consumers remain unchanged.

Universal-criterion representation note: “every” and “one” above range over the three canonical `CandidateKind` constants plus the single default class covering all other Go string values, owned by the unexported classifier; protocol claims range only over each adapter's already enforced canonical frame subset. The guarantee and finite terminating evidence are the representation contract and evidence budget above.

## Validation Gates

Run the new Candidate-kind semantic matrix; focused Candidate policy/planner, Carrier-topology, probe, v1 control-codec, TURN-retry codec, and TURN relay-policy tests; `./scripts/check-gofmt.sh`; `task docs-check`; and `task verify`. Follow the repository Go toolchain supply-chain audit before any Go command.

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) and the certification lanes in [`docs/CI.md`](../CI.md). Treat adapter drift, a second semantic owner, or any public/wire/behavior difference as an approach stop rather than refactor latitude.
