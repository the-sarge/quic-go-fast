# ADR-0008: Root Dial Supports Immediate Packet-Socket Ownership Transfer

## Status

Accepted.

## Context

`WithPacketConn` deliberately has an outcome-dependent ownership contract: the
caller retains the socket after setup error or relay fallback, while direct
success, post-commit transport failure, and failure after any non-nil
Dial/Accept stream transfer cleanup into wiremux. That
contract supports callers that pool or reuse packet sockets, but it forces a
caller that simply wants wiremux to manage the socket to classify every `Dial`
outcome before deciding whether to close it. The concrete consumer evidence is
tapmux's `cleanupOwnedPacketConnAfterWireDial`, which checks both
`ErrUpgradeTransportNotConverged` and `Wire.Direct` solely to reproduce this
truth table.

## Decision

Add `WithTransferredPacketConn(conn net.PacketConn)` to the root
`wiremux.Dial` interface. The option atomically selects the packet socket and
transfers exclusive lifecycle responsibility when `Dial` applies it as the
effective packet-connection option. The caller must not close or reuse the
socket from that point onward, including while `Dial` is still running. The
effective option and its socket are single-use: a retry or concurrent dial
requires a fresh socket. Merely constructing the option does not transfer
ownership, so the caller remains responsible for failures that happen before
it invokes `Dial`.

The existing `WithPacketConn` root option-selection policy remains unchanged;
its outcomes follow the lower non-nil-stream boundary in the matrix below.
If callers compose more than one packet-connection option, the last determines
both the effective socket and its ownership mode; an overridden socket does not
transfer. This follows the existing functional-option replacement behavior and
avoids an error path with contradictory ownership claims.

| Terminal path | `WithPacketConn` | `WithTransferredPacketConn` |
| --- | --- | --- |
| Option or input validation failure | Caller closes | wiremux closes before return |
| Setup or other error before commit and before any non-nil `Dial`/`Accept` stream | Caller closes | wiremux closes before return |
| Relay fallback before commit and before any non-nil `Dial`/`Accept` stream | Caller closes | wiremux closes before returning the relay wire |
| Non-nil `Dial`/`Accept` stream, with nil or non-nil error, then pre-confirmation validation or transport failure | Materialized transport stream synchronously closes the supplied socket exactly once; no relay result | Materialized transport stream synchronously closes the exact socket exactly once; no relay result |
| Transport failure after local commit (the post-commit subset) | wiremux closes | wiremux closes |
| Direct success | Returned wire closes | Returned wire closes |

Immediate ownership transfer remains root-dial policy. The lower `connect.WithUpgradePacketConn` contract has two transfer boundaries: local commit, or any non-nil stream returned by `Session.Dial` or `TransportListener.Accept`, including a stream returned with an error. After either boundary, ownership never returns and later failure returns `ErrUpgradeTransportNotConverged`, a zero result, and no relay path. An internally acquired default packet socket is already wiremux-owned and is unaffected.

Root packet settlement is state-only. The monotonic transfer fact records local commit or a non-nil Dial/Accept stream; root closes under its configured lifecycle policy only when that fact is false and relinquishes whenever it is true. Error-tree traversal may preserve error identity, classification, sanitization, and retryability, but malformed or traversal-truncated error trees never determine packet ownership or suppress/trigger packet Close.

For non-direct terminal paths, cleanup is synchronous and idempotent before
`Dial` returns. A close failure does not replace, wrap, or manufacture a dial
error, and does not turn relay fallback into failure; this preserves existing
error identities and the behavior of internally owned sockets. On direct
success, existing returned-wire and transport cleanup behavior continues to
govern close timing and observable close errors.

## Considered Options

- Change `WithPacketConn` to always transfer ownership. Rejected because it
  breaks callers that intentionally retain and reuse sockets after pre-commit
  failure or relay fallback.
- Name the option `WithOwnedPacketConn`. Rejected because the owner is
  ambiguous at the call site; tapmux already uses "owned packet conn" to mean a
  socket owned by tapmux. "Transferred" names the lifecycle event and makes it
  harder for callers to assume they should still close the socket.
- Add a separate ownership flag or exported ownership enum. Rejected because
  it creates invalid or order-sensitive configurations in which ownership is
  detached from the socket selection, while adding public concepts for only
  two stable modes.
- Add the policy to `connect.Upgrade` or `connect.Gather`. Rejected because the
  consumer problem is root `Dial` cleanup; changing the lower-level frozen
  contract would broaden W3 without benefit.
- Transfer only after upgrade preparation. Rejected because callers would
  still need outcome-sensitive cleanup for earlier validation and rendezvous
  failures, defeating the purpose of the option.

## Consequences

- Unmarked and `WithPacketConn` callers retain their outcome-dependent root
  policy, subject to the lower non-nil-stream ownership boundary above.
- The new option uses the same packet-socket validation, option-conflict error
  identities, and error text as `WithPacketConn`; ownership does not create a
  second validation surface.
- Root `wiremux.Dial` tests cover the effective `WithTransferredPacketConn` ownership classes and the consumer-shaped non-nil-`Accept`-before-commit ordering. [`wiremux_accept_before_commit_test.go`](../../wiremux_accept_before_commit_test.go) proves that both packet-socket ownership modes close the exact supplied socket once after the ownership boundary, return no relay-path Wire, and preserve `ErrUpgradeTransportNotConverged`; [issue #721](https://github.com/GridSwarm/wiremux/issues/721) is closed. Lower `connect` handoff tests remain the focused state-machine evidence. Option-order tests pin that the final packet-connection option selects both the socket and its ownership mode.
- The implementation must pass the exact caller-supplied `net.PacketConn` through to `connect` and custom transports. Idempotence belongs in one unexported lifecycle authority shared by config validation, early `Dial` returns, and `packetConnLifecycle.settle(ownershipView)`, not in a wrapper that changes the socket's concrete type or identity.
- tapmux can use the new option only for sockets it creates exclusively for a
  dial. Injected or shared sockets must continue to use `WithPacketConn`.
- The wiremux public-interface addition must be called out in the implementing
  PR, with consumer adoption handled in a separate tapmux PR.
