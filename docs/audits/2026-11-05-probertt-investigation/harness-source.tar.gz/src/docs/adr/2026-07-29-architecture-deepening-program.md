# Architecture Deepening Program — 2026-07-29

**Status:** All four tracks complete; Track 4 closed 2026-08-01 through #833. No open frontier remains; this index is now historical.

## What This Is

The dispatch index for the 2026-07-29 architecture review's accepted work. Track plans are normative for current slice contracts; this index records stable identity, dependencies, frontier, and outcomes closed without code. Review chronology and stopped implementation history remain behind linked PR receipts.

All four tracks are complete. Track 4's attempt-bound probe runtime landed through #884. A scoped 2026-08-01 rebaseline split the former four-row direct-evidence slice into an EIM+EIF production tracer (#832) and a direct filtering/table completion slice (#887); the remaining slices closed the same day through #833 with the accepted nine-row outcome, fabric ownership, exact-socket requirement, production path, and release-evidence boundary unchanged.

## Outcomes That Require No Implementation

- Old track 3 resource-owner issue #827 moved to Track 2 as the bounded persistent-owner/operation-finality integration component and closed when #825 published the composition.
- Stopped candidates remained unmerged evidence linked from Track 2, not dependencies or continuation baselines. The completed receive prerequisite and #839 inspected only their bounded governing diffs and did not cherry-pick a stopped range.
- Declaration-only producer/wrapper scanning and literal-string documentation scanning are removed from the Track 2 product gate. Component 5 also retires component 1's inherited constructor/entry AST census. Focused owner-local behavior, one bounded typed-request call/reference census, a one-time deletion/call-site review, current public-doc review, and repository docs checks replace them.
- Terminal fallback remains a separate blocking mini-protocol; folding it into the table would recreate the ADR-0006 mega-table.
- The sequencer remains the single relay-read authority; absorbing it would combine ordering and transport mechanics without removing a second authority.
- ADR-0011 keeps the frozen `io.ReadWriteCloser` method set, makes any non-nil Dial/Accept stream the transfer boundary even with an error, and strengthens its existing Close behavior so post-transfer disposal is synchronous and exactly once. No public method, return type, Wire method, ownership enum, result field, option, error wrapper, protocol frame, packet wrapper, or test hook is added.
- Probe-runtime work remains only the enabling part of approved deterministic restricted-NAT release evidence; kernel smoke, JSON aggregation/schema, and workflow wiring stay in the release program.
- `Transport stream` is the one new durable domain term and ADR-0011 is the one new decision record; both name the exclusive post-transfer disposal capability revealed by the second approach stop.

## Tracks, Dependencies, and Frontier

| # | Track | Plan | Parent issue | Blocked by | Slices | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Establishment settlement | `docs/adr/2026-07-29-establishment-settlement-plan.md` | #817 | None | 1 (#818) | COMPLETE |
| 2 | Transport finality and direct-attempt terminal ownership | `docs/adr/2026-07-29-packet-socket-ownership-fact-plan.md` | #824 | None | 8 (#836 listener finality, #837 disposal substrate, #827 owner/finality, #838 executor, #861 materialized-result representation, #867 receive completion, #839 replacement activation, #825 certification) | COMPLETE |
| 3 | ADR-0006 D3 transition-engine conformance | `docs/adr/2026-07-29-direct-upgrade-transition-conformance-plan.md` | #826 | #825 complete | 2 (#828, #829) | COMPLETE |
| 4 | Probe runtime and deterministic restricted-NAT evidence | `docs/adr/2026-07-29-probe-runtime-restricted-nat-evidence-plan.md` | #830 | None | 4 (#831, #832, #887, #833) | COMPLETE |

Completed graph: #836 → #837 → #827 → #838 → #861 → #867 → #839 → #825 → #828 → #829, then Track 4 sequentially #831 → #832 → #887 → #833, all four closed 2026-08-01. Old Track 4 Slice 2 maps to new Slices 2 and 3; old Slice 3 / #833 maps to new Slice 4. No dispatchable work remains in this program.

## Rules That Bind Every Track

- Track plans contain outcomes, boundaries, invariants, representation contracts, artifact classes, row-level terminating evidence, blockers, context budgets, and stop conditions; GitHub/OmniFocus mirrors contain pointers and live state only.
- Shared review-loop and contract-closure baselines referenced by dispatch skills govern; `docs/REVIEW-LOOP.md` is the repository overlay and no contract-closure copy is created.
- Single-owner/authority-complete invariants apply after each slice. Adapters may classify/translate but cannot become second transition, lifecycle, result, or cleanup owners.
- Every temporary seam names removal without tolerating a broken intermediate invariant. Listener finality makes Accept definitive. Integration component 1 adds only behavior-preserving shared cleanup state; moved #827 leaves a shadow owner only there and establishes the explicit Dial/Listen finality contract; component 3 adds a complete but unwired terminal executor only there; component 4 distinguishes all three materialized-result shapes while preserving production behavior; the receive prerequisite closes E1-E8 while leaving ownership inactive; component 5 / #839 atomically activates synchronous Close and every caller while removing all legacy seams; #825 certifies that safe exact head before its only `main` merge; #828/#829 remove role-driver transition seams.
- Track 2 integration components used one issue/one PR each against `integration/825-terminal-disposition`, carried immutable receipts, remained open/incomplete as `integrated, awaiting #825`, and were published only through #825. Those completed integration-branch constraints are historical and do not govern Track 4.
- Universal claims name domain, owner, guarantee, and finite evidence. Verification aids cannot recursively expand product scope.
- Stopped-candidate receipts are unresolved-history evidence, not code to merge, continue, or require later slices to load beyond their bounded governing diffs.
- Public interface/semantic changes are called out in implementing PRs; downstream custom-transport audits/adaptations occur in separate consumer PRs.
- Vocabulary uses `CONTEXT.md`; the new `Transport stream` term and ADR-0011 bind every affected slice.
- Post-merge ritual: review → exact-head certification/same-head CI → merge → append-dev-journal → complete OmniFocus slice → update tracker and `ready-for-agent` frontier.
