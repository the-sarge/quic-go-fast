# Wiremuxtest Transfer Requirements Implementation Plan

**Date:** 2026-07-30
**Status:** Governance authorized; the codemux roadmap deferral and wiremux v0.1.0 Phase 1A admission are recorded, and dispatch additionally requires the program index's published-owner-plan audit gate
**Stable identity:** `ADP-2026-07-30-T1`
**Track:** 1 of 2 in the 2026-07-30 cross-repository architecture deepening program
**Depends on:** No remaining governance blocker for `ADP-2026-07-30-T1-S1`; before dispatch, the program index's published-owner-plan comparison and replacement-audit gate must be satisfied; `ADP-2026-07-30-T1-S2` depends on `T1-S1`
**Related:** [codemux ADR-0006](https://github.com/GridSwarm/codemux/blob/main/docs/adr/adr-0006-public-test-support-ownership.md), [cross-repository program index](https://github.com/GridSwarm/codemux/blob/main/docs/adr/2026-07-30-architecture-deepening-program.md), [codemux transfer-adoption plan](https://github.com/GridSwarm/codemux/blob/main/docs/adr/2026-07-30-wiremuxtest-transfer-adoption-plan.md), [`docs/ARCHITECTURE.md`](../ARCHITECTURE.md), [`docs/RELEASE.md`](../RELEASE.md)
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** [2026-07-30 cross-repository slice-decision audit](https://github.com/GridSwarm/codemux/blob/main/docs/adr/2026-07-30-architecture-deepening-slice-audit.md)

## Goal

Deepen the supported public `wiremuxtest` module with two direct successful-transfer requirements. A private runner owns concurrent send/receive scheduling, bounded observation, counterpart draining, panic containment, exact-byte comparison, short-write detection, and payload-redacted diagnostics; callers learn only the stream or framed-channel entry point. This gives consumer tests leverage and gives wiremux one locality for transfer-assertion policy without importing identity behavior.

## Current Shape (verified 2026-07-30)

`wiremuxtest` is already a supported consumer-importable compatibility surface whose fixture and harness diagnostics use finite private timing and exclude arbitrary errors, rendezvous IDs, identity secrets, cryptographic material, certificates, and payload bytes (`wiremuxtest/doc.go:1-44`). Datagram contract runners retain their separate diagnostic behavior and are outside this policy statement. The package exports relay, pairing, Dial, cleanup, Datagram contract, and relay-session-consumption support, but no successful stream or framed-channel transfer requirement.

The package's own external contract suite retains an unbounded local `assertTransfer` with seven callers: four in `wiremuxtest/relay_contract_test.go` and three in `wiremuxtest/dial_contract_test.go`. The helper starts only the write asynchronously, does not detect short writes, renders arbitrary underlying errors, and prints payload bytes on mismatch (`wiremuxtest/relay_contract_test.go:150-168`).

The root external suite has 20 callers of a private sequential bidirectional `assertWirePayloads`; that helper duplicates one-way write/read scheduling twice, has separate two-second read timers, does not bound the synchronous writes, and prints arbitrary errors and payload bytes (`wiremux_test.go:5186-5242`).

The Datagram contract's simultaneous full-duplex reliable exchange owns different semantics: four operations run concurrently, it closes the pair on failure, and it returns errors to a contract runner (`wiremuxtest/datagrams.go:225-265`). It is not a caller of the proposed one-way fatal requirement.

Lower white-box packages also contain transfer helpers, but `relay` and `connect` sit below `wiremuxtest`; importing the public fixture there would invert dependencies or create cycles. The direct-upgrade integration helper uses repeated writes rather than the proposed single-`Write` contract. Those implementations are not migration targets.

Codemux independently duplicates the same identity-agnostic mechanics in `codemuxtest/dial_test.go`, `codemuxtest/handshake_test.go`, `pake/keys_test.go`, `pake/authenticator_test.go`, and `pake/wiremux_integration_test.go`; the separate consumer plan owns their adoption. Its `ADP-2026-07-30-T2-S1` slice is the one-PR adoption that removes those codemux-local successful-transfer helpers and inline mechanics after Slice 1 and a containing dependency pin land.

No matching open wiremux pull request, issue, or implementation branch existed in the 2026-07-30 census. Unrelated open work, including PRs #834 and #843, is not an implementation baseline and must be rechecked for overlap at dispatch.

Wiremux has not cut its first tag (`docs/RELEASE.md:1-5`). The current release path stabilizes the public surface before publication and makes source-compatible additions subject to compatibility-manifest evidence (`docs/CI.md`). The 2026-07-30 maintainer disposition admitted the two transfer requirements before the first release; `docs/RELEASE.md` and the compatibility manifests require both declarations to join the v0.1.x baseline, exported-declaration inventory, and active API evidence.

## Decision

The public interface is exactly:

```go
func RequireStreamTransfer(t testing.TB, sender io.Writer, receiver io.Reader, payload []byte)
func RequireChannelTransfer(t testing.TB, sender, receiver *channel.Channel, payload []byte)
```

Both exported requirements call `t.Helper()` before validation or execution so fatal output attributes the failure to the consumer call site rather than `wiremuxtest/transfer.go`. The private runner returns a disposition without reporting through `testing.TB`; only the marked exported frame renders and reports that disposition.

`Require` truthfully names fatal test behavior and matches `RequireSessionConsumed`. `Stream` covers raw relay streams, `wiremux.Wire`, `net.Conn`, and `channel.Stream` without misnaming them all as Wires. `Channel` names the owner-native framed abstraction. `Transfer` is one successful direction; “round trip” would be inaccurate.

Each call starts send and receive concurrently before waiting. Workers report through buffered private channels and never call `testing.TB`. One absolute private observation bound covers both operations; an early failure does not create a fresh timeout, and outcomes already buffered at the bound are drained before a stable disposition is rendered. The proposed two-second private bound follows the root `assertWirePayloads` precedent and newly bounds the seven formerly unbounded `wiremuxtest.assertTransfer` callers. It is one package-owned fixture policy rather than a caller-controlled compatibility promise, so no public widening option is introduced.

The private runner contains panics from either worker and reports a coarse send- or receive-panic category. It cannot cancel arbitrary `io.Writer` or `io.Reader` operations and must not close caller-owned endpoints; cleanup registered before the requirement remains responsible for releasing a worker that is still blocked after the fatal result.

`RequireStreamTransfer` rejects an interface-nil endpoint and an interface whose dynamic value is nil for a nil-able Go kind before invoking it, in both sender and receiver positions, and rejects an empty payload. It snapshots the payload into separate send and comparison copies before either worker starts, performs one `Write`, treats every `n != len(payload)` as failure, and uses `io.ReadFull` for exactly the expected byte count. It proves that exact prefix crossed the reliable byte stream; it does not prove that no later bytes exist.

`RequireChannelTransfer` accepts two non-nil `*channel.Channel` endpoints and one payload no larger than `channel.MaxPayloadSize`. Empty payloads remain valid because `channel.Channel` explicitly supports authenticated empty data frames (`channel/channel.go:144-157`). One `Send` and one `Receive` preserve frame atomicity and compare the complete returned payload.

Callers retain endpoint ownership, deadlines, and lifecycle. They must not perform a competing operation in the same send or receive direction during the requirement. The functions do not create a relay, consume or observe a relay session, classify an identity result, close a Wire, or change a transport deadline.

Diagnostics use the stable `wiremuxtest:` prefix, adapter and operation names, and allowlisted categories such as invalid input, failed operation, short write, panic, timeout/pending side, and payload mismatch. Slice 1 deliberately amends the fixture/harness allowlist in `wiremuxtest/doc.go` to permit expected/received lengths and the first differing offset while retaining every sensitive-data exclusion. Transfer diagnostics never render payload bytes, arbitrary underlying error text, panic values, rendezvous identifiers, certificates, or identity/key/exporter material. When both operations fail, categories render in stable send-then-receive order. Datagram runner diagnostics do not change.

The private runner is an internal seam with exactly two real adapters. No public adapter type or generic operation representation is introduced.

**Rejected alternative (do not do this):** Do not expose `PayloadTransfer`, callback constructors, variadic full-duplex execution, generic sender/receiver interfaces, custom comparators, labels, timeout options, results, cleanup hooks, or a configuration object. Those additions make the public compatibility interface as complex as the implementation and serve no demonstrated third adapter or timing policy.

**Rejected alternative (do not do this):** Do not add a bidirectional convenience function. Existing callers deliberately perform ordered one-way transfers, often with different payloads; simultaneous full duplex is a different behavior already owned where required by the Datagram contract.

**Rejected alternative (do not do this):** Do not make the requirements methods on `Relay`. The transfer seam also serves caller-owned pipes, raw streams, Channels, and Wires that need no fixture instance.

**Rejected alternative (do not do this):** Do not migrate the `relay` or `connect` white-box helpers upward, and do not replace the direct-upgrade integration helper that intentionally uses repeated writes. Dependency direction and behavioral equivalence take priority over superficial duplication.

**Non-goals:** No production Wire, channel, relay, transport, protocol, identity, Datagram, cleanup, muxcode-spending, or relay-session-consumption behavior changes. No public timing value. No codemux dependency. No candidate selection, tag creation, or release publication. No attempt to make arbitrary blocking I/O cancellable.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| `ADP-2026-07-30-T1-S1` | New; pending required merged-plan audit | Public stream and Channel transfer requirements with owner contract evidence | Program index's published-owner-plan comparison and replacement-audit gate | Deletes `wiremuxtest_test.assertTransfer` and all seven calls; codemux and root wiremux duplicates remain coherent callers of their existing local helpers |
| `ADP-2026-07-30-T1-S2` | New; blocked | Root external wiremux tests consume the owner interface | `T1-S1` merged | Deletes `assertWirePayloads` and its 20-call static seam |

After Slice 1, Slice 2 and the codemux adoption slice are parallel-safe once their independent external blockers are satisfied. Slice 2 is not a blocker for codemux because Slice 1 already establishes the complete supported interface.

## Implementation Slices

### Slice 1 — Add Bounded Redacted Transfer Requirements

**What it delivers:** One public `wiremuxtest` interface for successful reliable-stream and framed-channel transfer, its private concurrency engine, owner contract/meta-tests, exact package/architecture/release documentation, and migration of all seven package-external callers in `relay_contract_test.go` and `dial_contract_test.go` away from their shared local helper. `wiremuxtest/doc.go` describes both requirements, endpoint ownership, the controlled diagnostic-allowlist amendment, and finite private timing policy; `docs/ARCHITECTURE.md` records `wiremuxtest` as the owner of successful-transfer assertion policy and names the stream and Channel adapters; `docs/RELEASE.md` already records the resolved release-surface disposition and both exported symbols, and Slice 1 keeps that supported-surface documentation consistent when the declarations land. At dispatch, if `docs/COMPATIBILITY.md` exists, Slice 1 also records both declarations there and keeps that inventory consistent with `wiremuxtest/contract_inventory_test.go` and the active API evidence. If it does not exist, the release disposition must assign both declarations to Phase 1A compatibility-baseline creation before candidate commit `C`.

**Existing-work disposition:** New slice. The matching-issue/PR/branch census found no work to retain. At dispatch, re-fetch open work and stop if another branch has added or changed the same public interface.

**Blocked by:** No remaining governance blocker. Codemux PR [#404](https://github.com/GridSwarm/codemux/pull/404) records the program-specific release-readiness deferral, and the wiremux release record admits both declarations into v0.1.0 Phase 1A before candidate commit `C`. Before dispatch, satisfy the program index's standing requirement to compare the published owner plan with the immutable audited snapshot and record a replacement slice audit because contract content drifted during publication review.

**Single owner after merge:** `wiremuxtest` owns successful-transfer requirement policy and diagnostic rendering. `io.Writer`/`io.Reader` and `channel.Channel` remain owners of their operation behavior; callers remain endpoint-lifecycle owners. No durable production fact or lifecycle transition changes owner.

**Authority completeness:** No persisted or production fact becomes authoritative. The slice covers both constructors of the public behavior, validation of their complete admitted input domains, all private terminal dispositions, and documentation of endpoint ownership in the same PR.

**Transitional-seam budget:** Codemux helpers and root `wiremux_test.go`'s private helper temporarily coexist but do not become alternative public authorities; they retain their existing local behavior until `T1-S2` and codemux adoption slice `ADP-2026-07-30-T2-S1` remove them. Slice 1 introduces no shim, re-export, duplicate public representation, generic adapter, or double-owned endpoint lifetime.

**Blast radius:** The additive supported public test interface receives compatibility protection. Concurrency changes are confined to test-support calls and use two workers plus buffered results per requirement. The seven local contract callers across `relay_contract_test.go` and `dial_contract_test.go` adopt the new stream requirement and the shared helper is deleted. Slice 1 newly bounds those formerly unbounded calls by one total private duration; panic behavior becomes a fatal assertion instead of a process-wide worker panic. Diagnostics become less detailed and adopt the controlled fixture/harness allowlist amendment above. Success performs two payload copies and one receive allocation, acceptable for test support; the large stream case must remain supported. No production package, wire behavior, dependency, secret lifetime, relay state, platform-specific implementation, or external service changes. No untraced effect is accepted.

**Artifact classification:** `wiremuxtest/transfer.go`, its exported declarations, Godoc, and diagnostic behavior are shipped supported test behavior. Input validation and diagnostic redaction are required safety enforcement for that public test behavior. Contract tests, private runner tests, expected-failure subprocess fixtures, and race execution are verification aids; they are not recursively completeness-gated maintained products. The plan, release/architecture text, issue links, review receipts, and journal are process or traceability metadata.

**Representation contract:** The supported stream domain is one live `testing.TB`, sender and receiver interfaces that are neither interface-nil nor dynamically nil for a nil-able Go kind, one non-empty byte slice, and exclusive use of the supplied directions for the call. The supported Channel domain replaces those endpoints with two non-nil owner-native Channel pointers and admits payload lengths from zero through `channel.MaxPayloadSize`. The Go type system, explicit precondition validation, and `channel.MaxPayloadSize` own representation. The interface guarantee is universal over validated calls for launch/order, single-operation invocation, pre-launch payload snapshotting, exact comparison, bounded observation, endpoint non-ownership, panic containment, and diagnostic redaction; arbitrary endpoint progress or correctness is not guaranteed. Terminating evidence is the finite semantic outcome budget below, public compilation, the exported-declaration inventory, race execution owned by `task verify`, repository gates, and the conditional live release-surface evidence assigned by the release disposition.

**Contract closure:** Not triggered. Public compatibility and redaction are material, but the accepted interface has two adapters and a small closed set of private terminal categories that ordinary focused tests can reasonably cover inside the evidence budget; there is no persisted authority, open external grammar, protocol state space, or independently evolving caller-owned lifecycle matrix.

**Evidence budget:** At most 23 semantic rows, not executable subtests; adapter-table variants count once under their parent semantic row. The rows are three positives for a stream payload strictly larger than `channel.MaxPayloadSize` (use `channel.MaxPayloadSize+1024`), a real Channel payload exactly `channel.MaxPayloadSize`, and an empty Channel; six endpoint-validation rows for interface-nil and typed-nil stream endpoints in both positions plus nil Channel endpoints in both positions; two payload-validation rows for empty stream and oversized Channel payloads; one short-write row; three operation-error rows for send, receive, and both failing with stable send-then-receive rendering; one exact-byte mismatch row; two panic rows; three pending rows for send, receive, and both; one observation-bound drain row with outcomes already buffered when a private injected boundary signal wins selection; and one payload-ownership row in which the sending adapter mutates only its supplied snapshot while comparison retains the independently captured expected snapshot. The send-error and receive-error rows are adapter tables: each covers the private stream fake and a real `*channel.Channel` backed by a failing transport, proving bounded disposition, stable Channel `Send`/`Receive` labels, and absence of underlying-error and payload canaries; the complete terminal-disposition matrix remains owned once at the private runner seam. The stream and real-Channel operation-error and pending rows incorporate lifecycle spies that require zero endpoint closes and zero deadline mutations before caller-controlled cleanup, plus post-requirement usability where the fixture can meaningfully continue. A controlled close-on-timeout mutation and a controlled deadline-mutation variant must each make an existing lifecycle-spy row fail; they are one-time checks of the owned assertion and do not add semantic rows or become a general mutation campaign. Error, panic, and mismatch rows carry canaries proving underlying values and payload bytes do not appear. Expected-failure subprocess evidence for both exported helpers also asserts the reported location is a known consumer call site and never `wiremuxtest/transfer.go`. Operation counters, lifecycle counters, and the private injected boundary signal provide deterministic, non-wall-clock evidence; no public clock or timeout seam is permitted. The semantic-row total remains `3+6+2+1+3+1+2+3+1+1 = 23`. Use no general mutation campaign, timing-boundary repetition, fuzzing, external service, or extra platform matrix. Run one initial review and at most one replacement review; stop when those rows, conditional release evidence, and `task verify` pass.

**TDD and preservation evidence:** Add the public success tests, private runner failure/redaction rows, real-Channel send/receive failure rows, lifecycle-spy assertions, and caller-attribution checks before the implementation. Reuse the repository's expected-failure subprocess pattern so real `testing.TB` fatal output, completion bounds, operation labels, caller location, lifecycle counters, and canary absence are observed without exporting a reporter seam. Update `wiremuxtest/contract_inventory_test.go` with the two exact declarations, update `wiremuxtest/doc.go`, `docs/ARCHITECTURE.md`, and `docs/RELEASE.md` with the exact statements specified by this slice, satisfy the conditional `docs/COMPATIBILITY.md` obligation, then migrate the four `relay_contract_test.go` and three `dial_contract_test.go` callers only after both public adapters pass; delete `assertTransfer` after the seventh caller moves. Existing relay pairing, Dial, cleanup, consumption, and Datagram contract tests preserve adjacent behavior.

**Dispatch context budget:** Give the implementing agent this slice contract; `wiremuxtest/doc.go`; `wiremuxtest/contract_inventory_test.go`; the seven-call `assertTransfer` census in `relay_contract_test.go` and `dial_contract_test.go` plus its definition at `relay_contract_test.go:150-168`; the package's expected-failure meta-test pattern; `channel.NewChannel` at `channel/channel.go:101`; `errInjectedWrite` at `channel/channel_test.go:22`; `partialFailReadWriter` at `channel/channel_test.go:913`; `channel/channel.go:144-157`; the relevant `docs/ARCHITECTURE.md`, `docs/RELEASE.md`, and live compatibility-baseline sections; codemux ADR-0006; and both current gate dispositions. The Channel test identifiers are unexported shape references, so Slice 1 creates bounded `wiremuxtest`-local fakes rather than importing them. Do not load unrelated transport, settlement, NAT, or release-automation history. The change is one new module file, focused tests, seven local caller replacements, one local helper deletion, the inventory update, and the bounded documentation/compatibility updates, leaving room for review fixes in one fresh context.

**Slice decision audit:** Splitting stream and Channel would publish a partial interface, duplicate the private runner work, and leave the second real adapter unresolved. Merging Slice 2 would add 20 root call sites and a large unrelated external test file to the public-contract review. The former codemux roadmap and wiremux release-surface edges were governance blockers and are now resolved by their recorded dispositions. The program's replacement-audit gate must now confirm that publication-review contract drift preserves the audited slice graph; Slice 2 remains blocked because its calls do not compile before Slice 1.

**Stop conditions:** Stop if either recorded governance disposition is withdrawn or contradicted; if the program's required merged-plan replacement audit is absent or does not pass; if a third public adapter or configurable policy is required; if either endpoint must be closed, canceled, or deadline-mutated by the helper; if success requires repeated writes; if diagnostics must expose underlying errors or payload bytes; if Datagram, identity, authenticated-close, relay-consumption, or production behavior enters scope; if candidate commit `C` is captured before this slice and its compatibility evidence land; if an overlapping public implementation exists; or if focused implementation plus review no longer fits one PR.

### Slice 2 — Migrate Root Wiremux Transfer Checks

**What it delivers:** All 20 current `wiremux_test.go` callers express their existing ordered bidirectional success checks as two `RequireStreamTransfer` calls, and the local `assertWirePayloads` implementation is deleted.

**Existing-work disposition:** New mechanical migration. Recheck the exact static caller census and any overlapping open PR before editing; unrelated current PRs are not a baseline.

**Blocked by:** `ADP-2026-07-30-T1-S1` merged. The public declaration and its behavior must exist before callers adopt it.

**Single owner after merge:** `wiremuxtest` is the only owner of generic successful-transfer scheduling, timeout, short-write, comparison, panic, and redaction policy for these root external tests. Individual tests retain ownership of scenario setup, route/outcome assertions, payload choice, resource cleanup, and lifecycle conclusions.

**Authority completeness:** No persisted or production fact becomes authoritative. Each changed test retains its complete arrange/act/assert scenario and delegates only the generic transfer requirement.

**Transitional-seam budget:** None after merge for the exact root helper census. Lower-package and behaviorally distinct integration helpers remain intentionally local and are named non-goals rather than temporary seams.

**Blast radius:** Test imports and 20 static call sites change; each former helper call becomes two ordered one-way calls with the same payloads. Writes become concurrently bounded and short-write-aware, panics become controlled failures, and diagnostics become redacted. Test scenario order, production setup, selected route, resource ownership, cleanup, and wire behavior remain unchanged. No production files, exported declarations, dependencies, or external services change. No untraced effect is accepted.

**Artifact classification:** The migrated root tests are verification aids. The deleted private helper is a verification aid. The public behavior remains owned and tested by Slice 1; this slice creates no maintained verification-aid exception. Issue, review, and journal records are process or traceability metadata.

**Representation contract:** The supported domain is the exact 20 static `assertWirePayloads` calls and its one definition in `wiremux_test.go` at the slice base. The Go compiler owns call/type representation; the migration guarantees universal replacement over that finite static census and example-level preservation of each scenario's existing conclusions. Terminating evidence is a zero-result identifier census, the root package tests, race execution, and repository gates.

**Contract closure:** Not triggered. This is a finite mechanical verification-aid migration with no new authority, public declaration, security boundary, production lifecycle, or open representation.

**Evidence budget:** One before/after static census, the existing root test package once normally and once with `-race`, and the repository validation gate. No new test scenario, mutation, repetition, platform matrix, or full-duplex stress is authorized. One initial review and at most one replacement review terminate the review budget.

**TDD and preservation evidence:** Run the existing root suite as characterization before editing. Replace each call positionally with `RequireStreamTransfer(t, left, right, payload)` followed by `RequireStreamTransfer(t, right, left, reply)`, regardless of endpoint type or host/client role, then delete the helper. Review all 20 replacements against that exact positional and payload order, with explicit attention to the asymmetric `left.wire`/`right.stream` calls at the slice base. The same named tests plus full validation are the regression gate.

**Dispatch context budget:** Give the implementing agent this slice contract, the merged Slice 1 public Godoc/tests, the static `rg` caller list, `wiremux_test.go:5186-5242`, and any current overlapping diff only. Do not load Slice 1 implementation history or whole architecture programs. The edit is mechanical inside one test file plus imports and fits one fresh context with review.

**Slice decision audit:** Splitting relay/direct/long-lived callers would leave the same private helper as a transitional authority across multiple PRs without reducing per-batch semantic risk. Merging with Slice 1 would obscure public-interface review with 20 call sites. The sole blocking edge is compile-time and therefore necessary.

**Stop conditions:** Stop rather than migrate any call that requires simultaneous full duplex, repeated writes, endpoint closure, a custom timeout, or error return instead of fatal test behavior. Stop if the import creates a cycle, if a production file must change, if the static census no longer matches, or if an overlapping PR changes the helper semantics.

## Acceptance Criteria

- [ ] The supported `wiremuxtest` package adds exactly `RequireStreamTransfer(testing.TB, io.Writer, io.Reader, []byte)` and `RequireChannelTransfer(testing.TB, *channel.Channel, *channel.Channel, []byte)` for this module, and `wiremuxtest/contract_inventory_test.go` records both exact declarations; the supported domain, representation owner, universal guarantee, and terminating evidence are Slice 1's representation contract and 23-semantic-row maximum, with adapter variants counted inside their parent rows rather than as additional rows.
- [ ] Both exported requirements call `t.Helper()` before validation or execution, the private runner returns a disposition without calling `testing.TB`, and only the marked exported frame reports it; expected-failure subprocess evidence for each reports a known consumer call site and never `wiremuxtest/transfer.go`.
- [ ] Successful admitted calls invoke send and receive exactly once, begin both before waiting, return only after both succeed and exact bytes match, and never close or mutate endpoint lifecycle; the guarantee is universal over Slice 1's validated domain and terminates through the positive rows—including exact successful stream receipt of `channel.MaxPayloadSize+1024` bytes and exact successful real-Channel receipt of `channel.MaxPayloadSize` bytes—plus injected operation/lifecycle counters, post-requirement usability where meaningful, race run, and public contract tests.
- [ ] Stream empty payload, interface-nil and dynamically typed-nil stream endpoints in either position, nil Channel endpoints in either position, Channel oversize payload, short write, send/receive failure, panic, timeout/pending, and mismatch fail through bounded payload-redacted categories; real-Channel send and receive failures additionally prove the stable adapter operation labels and canary absence, while the complete terminal matrix remains at the private runner seam.
- [ ] `wiremuxtest/doc.go` describes both requirements, caller endpoint ownership, the controlled diagnostic-allowlist amendment, and finite private timing; `docs/ARCHITECTURE.md` records `wiremuxtest` ownership plus both adapters; `docs/RELEASE.md` already records the resolved release-surface disposition and both symbols, and Slice 1 keeps that supported-surface documentation consistent when the declarations land. If `docs/COMPATIBILITY.md` exists at dispatch, it records both declarations consistently with the contract inventory and active API evidence; otherwise the release disposition assigns both to Phase 1A baseline creation before candidate `C`. The eventual Slice 1 diff contains every applicable file and passes the documentation and live release-surface gates.
- [ ] `wiremuxtest_test.assertTransfer` and all seven slice-base calls across `relay_contract_test.go` and `dial_contract_test.go` are absent after Slice 1; the guarantee is universal over the exact identifier census in the tracked package and terminates with a status-aware static census that accepts only `rg` exit status `1`, plus compilation.
- [ ] `wiremux_test.assertWirePayloads` and all 20 slice-base calls are absent after Slice 2; the guarantee is universal over the finite static census owned by `wiremux_test.go` and terminates with a status-aware static census that accepts only `rg` exit status `1`, compilation, named tests, and the full gate.
- [ ] Datagram contract helpers, `relay`/`connect` white-box helpers, the repeated-write direct-upgrade helper, endpoint cleanup ownership, production packages, and dependency versions remain unchanged except for mechanical import cleanup; these are bounded diff and named-test preservation claims rather than assertions over unknown future code.

## Validation Gates

Before any Go command, run the toolchain audit required by `AGENTS.md`.

Slice 1:

```bash
if rg -n -F 'assertTransfer' wiremuxtest/relay_contract_test.go wiremuxtest/dial_contract_test.go; then
  echo "error: assertTransfer remains" >&2
  exit 1
else
  rg_status=$?
  test "$rg_status" -eq 1
fi
go test ./wiremuxtest/...
go test -race ./wiremuxtest
go test -race .
task verify
git diff --check
```

Slice 2:

```bash
if rg -n -F 'assertWirePayloads' wiremux_test.go; then
  echo "error: assertWirePayloads remains" >&2
  exit 1
else
  rg_status=$?
  test "$rg_status" -eq 1
fi
go test .
go test -race .
task verify
git diff --check
```

At dispatch, inspect whether `docs/COMPATIBILITY.md` exists and read the live release disposition. The accepted disposition admits Slice 1 before v0.1.0 candidate capture: update the existing compatibility baseline or, while Phase 1A is still creating it, ensure that work explicitly captures both declarations before candidate `C`. Run every release-plan API/compatibility manifest and exact-head release-surface gate assigned by the live release tracker. Diagnose every failure before rerunning.

## Operating Discipline

The shared review-loop and contract-closure baselines referenced by `$architecture-handoff` and `$implement-architecture-slice` govern both slices. [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md) adds wiremux-specific policy; wiremux has no repository contract-closure overlay. A representation mismatch, second behaviorally distinct counterexample at the same invariant and enforcement owner, release-surface conflict, new adapter/configuration requirement, endpoint-ownership expansion, production behavior change, or one-PR overflow stops dispatch and returns to `$architecture-handoff`.
