# Control-Frame Sequencer `recv` Implementation Plan

**Date:** 2026-07-05
**Status:** Accepted; implemented (PR #536); amended 2026-07-08 (issue #535)
**Track:** 1 of 4 in the 2026-07-05 third architecture deepening program
**Depends on:** nothing — safe to start first
**Related:** ADR-0002 (framing untouched), ADR-0006 (frozen upgrade contracts)

## Goal

Deepen the control-frame sequencer: one `recv(ctx, timeout)` call absorbs
the await/timeout/cancel-drain discipline that five call sites currently
re-implement around `next()`'s raw channel. Leverage: one interface method
serves every sequential consumer of upgrade-control frames. Locality: the
pending-frame-after-cancel rule lives in one module instead of every
caller.

## Historical Shape (pre-#536 baseline, verified 2026-07-05, main@49d8cb3)

*This section describes the code before PR #536 landed; it is preserved
as historical context. For the live contract, see the Amendment below
and the doc comments in `connect/control_sequencer.go`.*

- `connect/control_sequencer.go` (128 lines): `next()` returns
  `<-chan controlFrameReadResult` (:40-69); `pending()` (:71-85);
  `unread()` panics if a read is in flight (:87-95); `abort()` (:97-109).
- `abort()` is production-dead: its only caller is
  `control_sequencer_test.go`. Real exchange teardown is
  `attemptResources.abortControlExchange`
  (`connect/upgrade_resources.go:28-40`), which deadlines and closes the
  relay channel. Verified by grep: no non-test `.abort()` caller.
- Five call sites re-implement the await select: `awaitControlFrame`
  (`connect/upgrade.go:423-444`; timer → `ErrUpgradeControlTimeout`),
  `awaitControlFrameUntilContext` + `pendingControlFrameAfterContextDone`
  + `controlFrameResult` (`upgrade.go:446-483`), the
  `exchangeFirstPhaseControlFrame` loop (`upgrade.go:533+`), the
  `exchangeWithClassifier` loop
  (`connect/upgrade_terminal_fallback.go:123+`), and the probe race
  (`upgrade.go:358-382`).
- The probe race is a genuine two-event select (control frame vs probe
  completion) and is the only production `unread()` caller
  (`upgrade.go:369`).

## Decision

*This section is the original accepted design, preserved as written.
The `next()`-caller scope described here was superseded by the
Amendment (2026-07-08) below; `unread()` remains probe-race-only.*

New sequencer method:

```go
func (s *controlFrameSequencer) recv(ctx context.Context, timeout time.Duration) (controlFrameReadResult, error)
```

- `timeout > 0` arms a timer; expiry returns `ErrUpgradeControlTimeout`
  (frozen error identity preserved).
- Context cancellation drains an already-arrived pending frame before
  deciding between frame and `ctx.Err()`, with exactly today's
  `pendingControlFrameAfterContextDone` semantics — that logic moves
  inside the sequencer.
- Read-error vs context-error precedence identical to today's
  `controlFrameResult`.
- `next()` and `unread()` remain package-internal primitives used ONLY by
  the probe race site. `pending()` folds into `recv` and is removed from
  the surface. `abort()`, `errControlFrameSequencerAborted`, and the
  `abortCh`/`abortOne`/`aborted` state are deleted; their tests are
  deleted with them (replace, don't layer).
- `awaitControlFrame`, `awaitControlFrameUntilContext`,
  `pendingControlFrameAfterContextDone`, and `controlFrameResult` are
  deleted; call sites call `recv` directly (protocol-engine adapter
  closures pass timeout 0; pre-commit sites pass `a.cfg.controlTimeout`).

**Rejected alternative (do not do this):** one blocking `recv` for every
caller. The probe race must select frame-vs-probe-completion; wrapping
`recv` in a goroutine there re-creates pushback complexity in the caller.
Keep `next()`/`unread()` for that one site.

**Rejected alternative (do not do this):** expressing the control timeout
via `context.WithTimeout` in callers. That returns
`context.DeadlineExceeded` where today's callers return
`ErrUpgradeControlTimeout` — a frozen error-identity change.

**Non-goals:** the write-side helpers (`writeUpgradeControlFrame` /
`writeUpgradeControlFrameUntilContext`) may be unified opportunistically
but are not this track's obligation. No change to the frame codec,
classification tables, or the protocol engine.

## Implementation Slices

**PR 1 (only PR).** Write `recv` unit tests first, at the sequencer
interface: frame-before-timeout; timer expiry → `ErrUpgradeControlTimeout`;
ctx cancel with nothing pending → `ctx.Err()`; ctx cancel with an
already-arrived frame → frame returned; read error raced with ctx error.
Pin current behavior by keeping the existing sequencer and helper tests
green before deleting anything. Then implement `recv`, migrate all
sequential call sites, delete the four helpers and the abort machinery.
The PR description must map every deleted helper/abort test scenario to a
replacement `recv` test.

## Acceptance Criteria

- `grep -rn "awaitControlFrame\|pendingControlFrameAfterContextDone\|controlFrameResult(" connect/` (excluding `recv`'s own internals) returns nothing.
- `grep -rn "\.abort()\|errControlFrameSequencerAborted" connect/` returns nothing.
- `unread()` has exactly one production caller (the probe race in
  `upgrade.go`); `next()` has exactly three, each a documented frame-vs-work
  race (see Amendment 2026-07-08). Audit:

  ```bash
  # Exactly five hits: probeCandidatePairsWithTerminalFallback,
  # awaitListenerListen, awaitListenerCommitFirst, and the two TURN retry
  # race helpers turnRetryEngine.raceWorkAgainstControl and
  # turnRetryEngine.raceHandoffWorkAgainstControl (Amendment 2026-08-18).
  # The receiver-qualified pattern excludes the protocol cursor's
  # unrelated next() and recv's internal s.next() call in
  # control_sequencer.go (a sequential consume, not a race site).
  rg -n '(controlFrames|sequencer)\.next\(' connect --glob '!*_test.go'
  # Exactly one hit: probeCandidatePairsWithTerminalFallback.
  rg -n '\.unread\(' connect --glob '!*_test.go'
  ```
- All existing upgrade scenario tests pass unchanged; golden frame bytes untouched.

## Validation Gates

```bash
GOTOOLCHAIN=local go test ./connect/...
GOTOOLCHAIN=local go test -race -run 'ReadyCommit|ListenerEngine|Handoff' ./connect/
task verify
```

## Operating Discipline

Follow `docs/REVIEW-LOOP.md` for every PR. STOP condition: if any call
site turns out to need `pending()`-style non-blocking inspection that
`recv` cannot express, stop and check with the operator — that is an
approach-level finding.

## Amendment (2026-07-08, issue #535)

During implementation (PR #536), two more call sites turned out to be
genuine frame-vs-work races, not sequential awaits:

- `directUpgradeProtocolEngine.awaitListenerListen` (`connect/upgrade_protocol_engine_listener.go`): transport `Listen` completion vs peer terminal-fallback frame.
- `directUpgradeProtocolEngine.awaitListenerCommitFirst` (`connect/upgrade_protocol_engine_listener.go`): transport `Accept` completion vs peer abort frame.

Wrapping `recv` in a goroutine at either site would consume — and drop —
a control frame after the transport case wins. `next()` does not have
this problem by construction: it only arms a read and returns the result
channel, so a frame is consumed only when the caller actually receives.
A select arm that loses its race leaves the frame buffered for the next
consumer.

**Decision:** reframe `next()` from "grudging exception" to the
sequencer's race primitive. `recv` is the sequential-await primitive;
`next()` is sanctioned for frame-vs-work select races and nothing else;
`unread()` remains probe-race-only. The full production contract has
exactly three sanctioned usage patterns:

1. Direct sequential `recv`.
2. Goroutine-wrapped `recv`, where the owning exchange loop retains the
   result through a buffered handoff channel and drains or handles it
   before returning: the duplex exchange loops
   (`exchangeFirstPhaseControlFrame` in `connect/upgrade.go`,
   `exchangeWithClassifier` in `connect/upgrade_terminal_fallback.go`)
   and the commit-await goroutines in `connect/upgrade_protocol_engine_listener.go`.
3. `next()`, only for the three frame-vs-work races listed under the
   revised acceptance criterion below.

No new cancellable/peekable
primitive: it would re-implement select-over-`next()` with more
machinery, and the race sites have 3–4 select arms, so a two-way helper
does not fit. No handoff redesign: unifying transport and frame events
into one stream is a large change for no behavioral gain.

**Revised acceptance criterion:** `unread()` has exactly one production caller — `probeCandidatePairsWithTerminalFallback` (the probe race, `connect/upgrade.go`). `next()` has exactly three production callers — `probeCandidatePairsWithTerminalFallback` (`connect/upgrade.go`), `directUpgradeProtocolEngine.awaitListenerListen`, and `directUpgradeProtocolEngine.awaitListenerCommitFirst` (both in `connect/upgrade_protocol_engine_listener.go`) — each carrying a comment explaining why `recv` cannot be used there. `recv`'s internal `s.next()` call in `connect/control_sequencer.go` is a sequential consume, not a fourth race site. Any new `next()` caller must be a frame-vs-work race and must be added to this list and to the audit recipe under Acceptance Criteria.

Callers that receive from `next()` must handle the frame — or, in the
probe race only, `unread()` it — and callers that lose the race must not
receive at all; never receive-and-drop. At most one goroutine may select
on `next()` at a time (upgrade phases are sequential, which guarantees
this today).

## Amendment (2026-08-18, Slice 2.3 TURN retry activation)

The TURN retry engine (`connect/turn_retry_engine.go`) adds two sanctioned frame-vs-work race helpers, both selecting the next authenticated control frame against in-flight retry work and a budget boundary:

- `turnRetryEngine.raceWorkAgainstControl`: allocation completion, peer preparation, or retry-probe completion vs a peer retry Fallback or malformed frame vs the role-local retry deadline.
- `turnRetryEngine.raceHandoffWorkAgainstControl`: transport Listen/Accept completion vs a peer frame vs the materialization handoff budget.

Wrapping `recv` in a goroutine at either site would consume — and drop — a frame when the work arm wins, exactly the failure mode the 2026-07-08 amendment names. Both helpers follow the existing contract: a losing frame stays buffered, a received frame is always handled, and upgrade phases remain sequential so at most one goroutine selects on `next()` at a time. `unread()` gains no new callers. The acceptance-criteria audit recipe now expects five receiver-qualified `next()` hits.
