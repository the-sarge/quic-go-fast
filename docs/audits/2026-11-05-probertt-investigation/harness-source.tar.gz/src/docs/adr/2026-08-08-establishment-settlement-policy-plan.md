# Establishment Settlement Policy Consolidation Implementation Plan

**Date:** 2026-08-08
**Status:** Accepted; not yet implemented
**Track:** 4 of 5 in the 2026-08-08 architecture deepening program
**Depends on:** nothing — safe to start first
**Related:** Existing child issue #1013; historical implementation evidence in [`2026-07-29-establishment-settlement-plan.md`](2026-07-29-establishment-settlement-plan.md); ADR-0008, ADR-0009, ADR-0010
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** Final architecture-review convergence and grilling on 2026-08-08; independent slice audit PASS on 2026-08-08; synchronization of existing issue #1013 is administratively pending the accepted docs commit

## Goal

Give each closed `establishmentFailureKind` one coherent internal policy declaration for failure stage, Session consumption action, and rendezvous-spending behavior. The settlement module remains the single outcome owner, while three parallel switches collapse into one inspectable descriptor/evaluator with no observable Wire dial change.

## Current Shape (verified 2026-08-08 at `7f574a5a8b7ffff64fa69a10dd57b1b46e3ee78c`)

- The settlement module already owns ordered failure obligations and success transfer; the original deepening landed and is covered by `TestEstablishmentSettlementReachableMatrix` at `establishment_settlement_test.go:110`.
- Each failure kind is independently classified three times: consumption action in `establishment_settlement.go:121-137`, rendezvous spending in `:139-150`, and public stage in `:152-165`.
- Identity failure and nil-auth-context share a dynamic rule: authentication returning without error plus `successSpends` selects post-identity-success consumption and spends rendezvous; otherwise identity-failure consumption applies.
- The existing reachable matrix has 27 behaviorally distinct scenarios: 26 failure scenarios plus one success-transfer scenario. Its only structural guard is `len(tests) == 27`; it does not mechanically census the seven declared `establishmentFailureKind` constants. The scenario expectations are the behavioral oracle, while enum completeness must be added by this slice.
- Issue #1013 is open and unassigned with no implementation PR or blocker. Its prior `ready-for-agent` label was removed while this plan and thin child body are synchronized; readiness is restored only after that administrative update.

## Decision

- Introduce one closed internal policy representation or evaluator keyed by `establishmentFailureKind` that provides stage, consumption action family, and static/dynamic spending rule together.
- Keep the identity/nil-auth dynamic predicate explicit and centralized; do not flatten it to a static enum value that hides `authReturnedWithoutErr && successSpends`.
- Keep settlement ordering, caller interface, error construction, cleanup, carrier close, and success path unchanged.
- Treat the 2026-07-29 plan as historical implementation evidence, not a second normative authority. This current plan carries the binding preservation obligations: nil-auth post-success spending versus retryable context-error behavior; `ErrChannel` retryability unless one-shot; the relay-connection to relay-stream close switch at negotiator construction; upgrade cleanup before the nil-stream check; relay-path `consume.gateRelayWin`; non-transfer release-observer publication before `Dial` returns; and release/consume overlap in which async revocation starts before blocking consume/close while synchronous release publication completes before return.

**Rejected alternative (do not do this):** Leave three switches and add a synchronization test. That verifies duplication rather than removing the chance that one switch changes without the others.

**Rejected alternative (do not do this):** Generalize the policy into a public error/settlement registry. The kind set and consequences are private to one module and gain no second consumer.

**Non-goals:** no new failure kind; no success-path change; no public interface, wire, error-tree, cleanup-order, Session consumption, rendezvous-disposition, or downstream migration change; no generated table or maintained external schema.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | rework existing #1013 | One closed settlement failure-policy authority | None | Removes three parallel kind switches |

## Implementation Slices

### Slice 1 — Consolidate settlement failure policy

**What it delivers:** One closed policy declaration/evaluator for every existing failure kind, consumed by settlement to derive the same stage, consumption action, and spending result as today.

**Existing-work disposition:** Rework issue #1013 into this audited child contract. Retain its outcome and acceptance intent; replace its mirrored details with a pointer to this plan. No open PR, branch, comments, or unresolved review findings exist.

**Blocked by:** None.

**Single owner after merge:** The settlement policy evaluator owns kind-to-stage/action/spending classification. `establishmentSettlement` owns execution order and state. `consumeCoordinator` retains Session-consumption mechanics and `markSpentAfterOneShotSuccess` retains error shaping.

**Authority completeness:** The closed failure-kind declaration, all construction sites, the policy evaluator, and every destructive consumer (Session consumption and rendezvous spending) are covered. No persisted or restart fact is introduced.

**Transitional-seam budget:** None. All three switches disappear in the same PR; no compatibility mapper or second table remains.

**Blast radius:** Root settlement implementation and focused tests only. Material risks are irreversible Session consumption, one-shot rendezvous spending, error stage identity, auth-release/cleanup order, and carrier ownership. Concurrency and performance should be neutral; no dependency or public change is accepted.

**Artifact classification:** The consolidated evaluator is shipped behavior with unchanged observation and required safety enforcement for settlement classification. The 26-failure-plus-one-success behavioral scenarios and new closed-kind completeness assertion are verification aids maintained in the ordinary Go suite. This plan is process/traceability metadata.

**Representation contract:** Supported domain = every value of the seven-member closed `establishmentFailureKind` enum and the reachable dynamic inputs represented by the 26 failure scenarios; the one success-transfer scenario is preserved outside the failure evaluator. Representation owner = the single settlement policy evaluator for failure and `establishmentSettlement.succeed` for success. Guarantee = universal over the finite failure enum/reachable-state model and example-level preservation of success transfer. Terminating evidence = a new mechanical enum-to-policy completeness assertion, unchanged expectations for all 26 failure scenarios and the one success scenario, focused settlement tests, and `task verify`.

**Contract closure:** Triggered because a wrong rule can irreversibly consume a Session or spend rendezvous and the outcome has multiple independently reachable failure kinds/states. Invariant: each declared failure kind and reachable dynamic state derives exactly one existing stage, consumption action, and spending disposition from one evaluator. Representation and enforcement owner: the settlement policy evaluator.

| Semantic class | Expected disposition | Enforcement owner/location | Terminating evidence | Guard mutation | Status |
| --- | --- | --- | --- | --- | --- |
| Pairing failure | `ErrRendezvous`; no Session consume; never spend | Settlement policy evaluator | Existing pairing scenario plus new enum completeness assertion | n/a | covered |
| Identity or nil-auth without `authReturnedWithoutErr && successSpends` | `ErrIdentity`; identity-failure consume action; never spend | Settlement policy evaluator | Existing ordinary identity/nil-auth scenarios | n/a | covered |
| Identity or nil-auth with `authReturnedWithoutErr && successSpends` | `ErrIdentity`; post-identity-success consume action; spend rendezvous | Settlement policy evaluator | Existing post-success identity and nil-auth scenarios | n/a | covered |
| Auth-validation failure | `ErrIdentity`; auth-validation consume action; spend iff `successSpends` | Settlement policy evaluator | Existing conn/stream and consume/spend scenarios | n/a | covered |
| Channel failure | `ErrChannel`; post-identity-success consume action; spend iff `successSpends` | Settlement policy evaluator | Existing channel scenarios | n/a | covered |
| Upgrade failure or nil returned stream | `ErrUpgrade`; post-identity-success consume action; spend iff `successSpends` | Settlement policy evaluator | Existing upgrade/nil-stream scenarios | Delete/bypass the central kind lookup only if needed to prove inherited coverage | covered |
| Undeclared or out-of-domain failure kind, including zero | Preserve current order: start failed-auth release and upgrade cleanup, then panic at policy lookup before consume, carrier close, spending, or stage return; never accept a zero-value policy | Settlement policy evaluator at the current post-release/post-cleanup lookup point | Focused `establishmentFailureKind(0)` characterization, separate from declared-kind completeness | n/a | rejected |
| Successful establishment | Transfer through `establishmentSettlement.succeed`; no failure policy lookup | `establishmentSettlement.succeed` | Existing success-transfer scenario and success-panic release test | n/a | non-goal/preserved |

**Evidence budget:** Preserve expected outcomes for all 26 failure scenarios and the one success scenario; add one mechanical assertion that each of the seven declared failure kinds maps exactly once through the evaluator; add one separate invalid-zero characterization proving failed-auth release and upgrade cleanup occur before panic while consume, carrier close, spending, and stage return do not; allow one guard-deletion mutation of the central lookup only if needed to demonstrate inherited coverage; run focused settlement tests and applicable root race coverage. No new platform, repetition, fuzz, or external fixture matrix. Review budget = one initial review plus at most one fully briefed replacement review. Terminate when the three switches are absent, every declared failure kind maps once, invalid zero preserves current fail-closed ordering, all 27 scenario expectations are unchanged, and `task verify` passes.

**TDD and preservation evidence:** First add a mechanical closed-kind completeness assertion that fails when any declared `establishmentFailureKind` lacks exactly one evaluator mapping; the current row-count guard is insufficient. Separately characterize the current invalid-zero order: failed-auth release and upgrade cleanup precede the panic, while consume, carrier close, spending, and stage return are not reached. Keep all 27 scenario expectations unchanged as the behavioral red/green oracle except for mechanical access required by the new representation. Preserve success-panic release and root integration tests.

**Dispatch context budget:** This plan; `establishment_settlement.go`, `establishment_settlement_test.go`, and issue #1013. The historical plan is optional evidence only because every binding frozen behavior is repeated above. No broader program history is needed. One PR fits one fresh context.

**Slice decision audit:** Splitting stage/action/spending migration would preserve parallel authorities between PRs, so consolidation is atomic. Merging success settlement or error-tree cleanup would widen unrelated ownership. No blocker is necessary.

**Stop conditions:** Stop if one descriptor cannot express the identity/nil-auth dynamic rule without callbacks or secondary switches; if any matrix expectation, error tree, cleanup order, Session action, or spending outcome changes; or if the design expands beyond private settlement code.

## Acceptance Criteria

- [ ] One closed policy representation/evaluator covers every existing `establishmentFailureKind` and declares stage, Session consumption action family, and spending rule.
- [ ] The three parallel kind switches are absent.
- [ ] Identity failure and nil-auth context retain the exact dynamic `authReturnedWithoutErr && successSpends` behavior.
- [ ] A new mechanical completeness assertion proves that each of the seven declared failure kinds maps exactly once through the evaluator.
- [ ] An undeclared `establishmentFailureKind(0)` preserves the existing fail-closed order: failed-auth release and upgrade cleanup occur before panic; consume, carrier close, spending, and stage return do not occur.
- [ ] All 26 failure scenarios plus the one success-transfer scenario pass with unchanged expected outcomes.
- [ ] Settlement caller interface, error identities/trees, cleanup ordering, Session consumption, rendezvous disposition, and success behavior remain unchanged.
- [ ] Public interface, wire protocol, and downstream consumers require no migration.

## Validation Gates

Run `TestEstablishmentSettlementSuccessConstructionPanicReleasesAuth`, `TestEstablishmentSettlementReachableMatrix`, applicable focused root auth/settlement race tests from the repository gate, `./scripts/check-gofmt.sh`, and `task verify`. Follow the Go toolchain supply-chain audit before any Go command.

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md). The 26 failure scenarios, one success scenario, and seven-kind completeness obligation are both floor and ceiling; do not invent new settlement policy.
