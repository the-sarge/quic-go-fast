# E02-D scoped observation re-audit

## Disposition

Retain E02-D, its Darwin qualification outcome and one evidence PR. Admit an exact-source disposable observation overlay under the [current E02-D contract](2026-09-15-wiremux-packet-io-plan.md#e02-d--darwin-assembled-wire-qualification). No new child, product API, shipped diagnostic owner, native algorithm, platform, workload or performance campaign is required. The existing measurement protocol's missing-evidence and inconclusive-result rules remain in force. This audit changes collection feasibility, not a support or performance verdict.

The [initial preflight stop](https://github.com/GridSwarm/wiremux/issues/1531#issuecomment-5700816962) correctly identified an observation gap but escalated to architecture handoff before evaluating a disposable aid. The operator authorized this scoped re-audit. There are no RAS findings or repeated semantic roots to resolve, and no product correctness failure has been demonstrated. No captures were collected before this revision.

## Source reconstruction

The inspected wiremux source is `20c9a4a6563cb36dbdea63f3d435758de2cd7e80`; fork source is Q05's merged `415680ac177dcac7e090c8541707ee3478bcc037`. These identify this audit, not the future campaign pair. Freeze current Wc/Fc and compare changed owners before collection. The runtime polarity mechanism is the existing `QUIC_GO_DISABLE_SENDMSG_X`; the plan spells out identical binaries and a bounded startup mapping for the existing remote launcher. Go overlay inputs use isolated source outside the module cache.

- Wiremux `transport/internal/adapter/packet_permission.go` binds its exact checked native writer or factory-proven managed lease before initialization. `packet_conn_oob.go` retains the selected-peer check for ordinary and batch writes. `internal/measurement/comparison_transport.go` and `transport.go` establish production Wire but expose no native-send observations.
- Fork `send_conn_sendmsg_x_darwin.go` owns actual native submission at the invocation of `sendmsgXSubmit` inside `darwinBatch.submit`'s raw-write callback; `sys_conn_sendmsg_x_qual_darwin.go` classifies returned progress at `sendmsgXSubmit`. Its process-wide private counters do not provide resource/window attribution or count all ordinary calls.
- `ordinaryUDPBatchWriter` in `external_packet_io.go` owns ordinary submissions within the registered callback. `basicConn.WritePacket` in `sys_conn.go` and `oobConn.WritePacket` in `sys_conn_oob.go` own ordinary sends outside that callback. These disjoint paths admit observations without bypassing the wrapper or changing retry ownership.
- One overlay-only scalar-observation handle travels from measurement setup through the existing Dial/session context and `session.newPacketTransport`/`adapter.NewQUICTransport` to exact fork writer/managed registration. The measurement owner retains its handle for snapshot and post-join cleanup. Cross-package handle/accessor symbols and context plumbing exist only in evidence builds; no package-global registry is needed. Exact external/managed registration provides resource association. The source already exposes the native descriptor to the trusted submission owner; an observation there needs neither DTrace nor a public descriptor accessor. Associate descriptors only while the identified socket/generation is live; do not confuse native qualification self-check traffic with the selected socket.
- Existing measurement boundaries, `profiler`/`CaptureFile` artifact handling and remote copy/hash checks can carry a bounded JSON sidecar. The overlay adds observations to these seams without inventing a configuration language, subprocess driver or capture framework.

## Gates and limits

| Gate | Re-audit conclusion |
| --- | --- |
| Accepted outcome and one-PR boundary | Unchanged Darwin evidence and compatibility PR; audit publication remains separate from the implementation diff |
| Representation | Go compiler, existing standard UDP values and existing measurement JSON owners; overlay input limited to exact source blobs; example-level observations |
| Artifacts | Disposable observer/tests are verification aids; plan, source snapshots, manifest and receipts are traceability metadata; no maintained-aid exception |
| Single owner and authority | Existing wrapper, fork submission/progress and endpoint lifecycle owners retain all decisions; observer only counts returned facts |
| Authority completeness and restart | No persisted product state, restart format, acquisition authority or changed teardown; observations end with the endpoint run |
| Transitional seams | No production seam; overlay is opt-in for frozen evidence builds and retired after the slice, with source archived for reproduction |
| Preservation | Forward original calls/results unchanged; bounded synchronized scalar observations, no packet retention, hot-path I/O or independent artifact channel; permit post-window sidecar creation, hashing, existing remote copy and readback through the capture owner; disclose measurement overhead rather than assume cancellation |
| Blast radius | Named fork write/registration seams, existing Wire context/adapter bridge and measurement startup/boundary/artifact seams; admit overlay-only handle/accessor signatures and per-process selection of the existing runtime switch, with no shipped dependency/API mutation, new syscall, security-setting change or adjacent platform work |
| Contract closure | Not triggered for receipts or the disposable aid; no recursive safety completeness claim; existing shipped safety contracts remain unchanged |
| Evidence/context budgets | Existing three workloads and ten scheduled pairs each; finite admission/attribution/readback checks replace the unavailable observation path; no repeated campaign or stress escalation; named owners fit the existing under-25k target |
| Split/merge case | A new supported diagnostic API would justify separate product work, but is unnecessary for this exact-source receipt. Runtime repairs remain outside E02-D |

The current plan owns the finite observation matrix and unresolved evidence cells. This audit does not mark those cells covered. Native engagement, disabled polarity, managed attribution and receipt recovery still have to be demonstrated. Performance conclusions are limited to the actual instrumented binaries; without a supported instrumentation-overhead bound, CPU/allocation observations cannot establish release default-enablement benefit. No additional calibration campaign is implied.

An observer that needs to change a runtime decision, widen the source/representation domain, retain sockets or packet buffers, become a supported API, or grow beyond these concrete observation seams fails this scoped repair and returns to a decision. Other untraced effects are not accepted silently. A failed disposable-aid check calls for a local evidence-method correction within this budget, not recursive proof of a framework.

The [initial review dispositions](https://github.com/GridSwarm/wiremux/pull/1557#issuecomment-5701091519) clarify the overlay-only instance handle, post-window receipt I/O and single native counting point. They change no shipped behavior or campaign budget. The shared documentation-only correction policy applies; native admission remains pending.

## Publication and resume

Merge this documentation revision through the repository's normal PR path, then synchronize only E02-D's child plan pointer to the authoritative docs commit. Refresh mutable mirrors with current state and this audit pointer; do not propagate plan SHAs. Reconcile the clean E02-D implementation branch with that default head, emit the revised execution preflight, and resume observer admission and source audit before freezing or collecting the campaign. This revision neither closes E02-D nor predicts E02 readiness; its remaining prerequisites and other platform work remain independently tracked.
