# ADR-0003: QUIC v1 Binds to the Selected Candidate Pair

## Status

Accepted.

## Context

wiremux v1 direct upgrade selects exactly one candidate pair before
starting the transport phase. Authenticated probing proves reachability
for that pair, upgrade control synchronizes that selected pair, and
fallback semantics explain why no direct path was selected.

QUIC supports connection migration and NAT rebinding in general. Those
features let the peer address change while preserving a QUIC connection,
but wiremux v1 does not authenticate or announce an evolving set of
direct paths. Allowing implicit QUIC path changes would make the
transport layer broader than the path selected by the wiremux protocol.

## Decision

`transport/quic` must keep the returned stream bound to the selected
candidate pair for its lifetime. QUIC connection migration and NAT
rebinding are disabled or filtered so packets from non-selected sources
cannot establish, replace, or confuse the returned stream.

A future ADR may add explicit path migration, but it must be a wiremux
protocol feature with authenticated validation and policy handling
rather than an implicit QUIC transport behavior.

## Consequences

- The v1 QUIC implementation must enforce the selected remote address
  before establishment and for the lifetime of the returned connection.
- A NAT rebinding or peer address change may break a v1 direct QUIC path
  instead of silently authorizing a new path.
- Future multipath, migration, or failback work needs protocol-level
  design rather than transport-local behavior.

## Amendment (2026-08, [#1317](https://github.com/GridSwarm/wiremux/issues/1317))

The Decision above is unchanged. This amendment records how it is enforced now that the selected-remote packet adapter exposes quic-go's out-of-band socket surface on kernel UDP sockets, which quic-go needs for GSO, ECN, DF and batched reads.

Two kinds of surface are distinguished:

- **Filtered packet methods** — `ReadFrom`, `WriteTo`, `ReadMsgUDP`, `WriteMsgUDP`, and `ReadBatch`. The invariant is enforced on what reads return and what writes accept: every returned message originates from the selected remote, and a write to any other destination is rejected before any syscall. The adapter implements `ReadBatch` itself so that quic-go never unwraps the descriptor through `golang.org/x/net`, which would read around the filter. Absence of the interfaces is no longer the enforcement mechanism.
- **Privileged descriptor access** — `SyscallConn`. This is not a filtered method: a raw descriptor permits unfiltered I/O. It is entrusted to quic-go as a pinned dependency on the strength of the [quic-go v0.62.0 source audit](../research/quic-go-v0.62-source-audit.md) showing `RawConn` use through `Control` only (socket options: DF, ECN, packet info, GSO detection, buffer sizes). The adapter returns a `RawConn` that forwards `Control` and rejects `Read`/`Write` as a guard against accidental packet I/O by trusted code; `Control` still hands the descriptor to that code, so this is not a filter and is not claimed as one.

The capable wrapper is selected only for a concrete `*net.UDPConn`, where the adapter is the last thing above the kernel. Any other `net.PacketConn` — including caller-supplied wrappers that may carry their own filters — keeps the plain wrapper with no out-of-band surface.

Obligation: every quic-go version bump must re-audit all `SyscallConn`, `RawConn`, `ReadBatch`, packet-read and packet-write call paths in the new version before the pin moves. Compile-time assertions in `transport/internal/adapter` fail the build if quic-go's `OOBCapablePacketConn` grows, forcing that audit rather than a silent fallback to the slow path.

Consequence: on kernel UDP sockets, quic-go now sets DF and enables ECN and, on Linux, GSO and `recvmmsg`. Socket-option setup that fails for both address families aborts transport initialisation instead of running unoptimised; this is intended.

## Wrapper retained after P02 evaluation

The Decision and its enforcement mechanism remain unchanged. The [P02 evaluation](../research/p02-fixed-peer.md) compared the wrapper with the fork's acknowledged immutable fixed-peer policy on direct concrete UDP sockets. Performance preservation was inconclusive, and fallback cases would still require the wrapper. The owner chose to retain wiremux's wrapper and exclude the experimental native-selection path from the product. The fork capability remains documented for reference; wiremux exposes no new selection option. Existing descriptor-access audits, receive-format permissions, authentication and packet ownership remain in force.

## Optional packet-I/O integration audit

The [E02 assembled support decision and dependency re-audit](../research/e02-support.md#adr-0003-dependency-re-audit) records the retained wrapper’s filtered native and managed paths, exact-resource permissions, and private checked Darwin writer. Upstream remains the default dependency. The optional writer is a separate explicitly registered capability; the original upstream socket-option-only descriptor audit must not be read as a claim about every fork-internal descriptor operation. The selected-pair invariant and per-dependency-revision audit obligation remain unchanged.
