# Upgrade-Plan Ownership Implementation Plan

**Date:** 2026-08-08
**Status:** Accepted; not yet implemented
**Track:** 1 of 5 in the 2026-08-08 architecture deepening program
**Depends on:** nothing — safe to start first
**Related:** [`2026-07-05-dial-upgrade-plan-plan.md`](2026-07-05-dial-upgrade-plan-plan.md), ADR-0008, ADR-0009
**Normative scope:** Current outcome, boundaries, invariants, acceptance evidence, blockers, and stop conditions
**Audit history:** Final architecture-review convergence and grilling on 2026-08-08; independent slice audit PASS on 2026-08-08

## Goal

Make `upgradePlan` the sole mutable owner of root direct-upgrade configuration from the moment public `Option` closures run. This removes the field-for-field `dialConfig` mirror and `newUpgradePlan` copier while keeping resource preparation, validation, defaults, errors, and packet-socket ownership observably unchanged.

## Current Shape (verified 2026-08-08 at `7f574a5a8b7ffff64fa69a10dd57b1b46e3ee78c`)

- `dialConfig` owns relay settings and root lifecycle settings, but also mirrors direct-upgrade choices across `options.go:27-52`: transport, packet connection and transfer choice, STUN selection, probe/control settings, relay-only mode, and candidate policy. It already contains an `upgradePlan` field at `options.go:61`, but that field is populated only after option application and validation.
- Public direct-upgrade options mutate those mirror fields in `options.go:94-224`; `newDialConfig` applies all options, performs conflict checks in `options.go:283-329`, then passes the complete config to `newUpgradePlan`.
- `newDialConfig` constructs `packetConnLifecycle` from the config-only `packetConn` and `packetConnTransferred` facts at `options.go:293` before calling `newUpgradePlan`; `newUpgradePlan` then copies the remaining mirrored fields into `upgradePlan` at `upgrade_plan.go:112-137`. The transfer flag is not copied into the plan. The comment at `upgrade_plan.go:83-85` identifies the mirror/copy path as transitional debt.
- `upgradePlan.prepare` orchestrates preparation at `upgrade_plan.go:144-177`; `validatePrepared` is at `:179-192`, the default packet listener helper at `:198-212`, and default STUN resolution at `:214-267`.
- `upgradePlanOptionSet` at `upgrade_plan.go:346-387` is not the same debt: `optionsWithResources` materializes a derived snapshot only after actual packet/STUN resources are known. Tests at `upgrade_plan_test.go:190` and `upgrade_plan_test.go:288` currently reflect the plan back through that snapshot and should be replaced with behavior-facing assertions where circular.
- Test-only options in `export_test.go:13-38` split by ownership: the packet-listener and STUN-resolver options at `:13-24` mutate dependencies used exclusively by plan preparation, while consume-session and channel-decorator options at `:26-38` are genuinely root-owned.

## Decision

- Initialize and retain the existing `dialConfig.upgradePlan` before public options run; direct-upgrade option closures mutate that nested plan directly.
- Seed plan-owned dependencies with the current defaults before options run. Route the packet-listener and STUN-resolver test options into that plan-owned state; keep only consume-session and channel-decorator test hooks on `dialConfig`. After options, reapply plan-owned `withDefaults()` normalization before static validation so a nil test override preserves today's fallback-to-default behavior.
- Keep relay pin/TLS, channel options, establishment timeout, consume/session handling, auth-release handling, and other root lifecycle dependencies on `dialConfig`.
- Move direct-upgrade conflict validation and default initialization behind `upgradePlan` methods called by `newDialConfig`. Preserve option application order and current last-write behavior.
- Run post-option `withDefaults()` and `validateStatic()` through the plan after options and lifecycle construction at the same validation boundary as today. No config-to-plan dependency/default/validation copier remains.
- Move `packetConnTransferred` with the packet selection into plan-owned option state. Construct the packet-connection lifecycle once from that plan state at the same post-option validation boundary as today, then associate it with the plan without recreating a mirror or a second mutation path.
- Retain `upgradePlanOptionSet` as the derived prepared representation for this slice. It may be removed by later work only if all callers and behavioral tests show that doing so reduces an authority without adding callbacks, flags, or duplicated validation.
- Replace tests that prove only equality between two plan-derived representations with assertions at the validated option/preparation seam. Preserve every current resource cleanup test.

**Rejected alternative (do not do this):** Introduce an exported builder or change `Option` from `func(*dialConfig)`. That would change a stable public construction pattern to solve an internal ownership problem.

**Rejected alternative (do not do this):** Force `upgradePlanOptionSet` deletion in the same PR. It represents prepared resources, not caller configuration, and deleting it without a proven narrower replacement would widen the change while obscuring the actual duplicate authority.

**Non-goals:** no public option additions or removals; no change to option order, conflicts, defaults, validation timing, error identity/tree, direct-vs-relay choice, packet-socket transfer, STUN lookup, `connect.UpgradeOption`, or downstream consumers; no rewrite of `preparedUpgradePlan`.

## Slice Graph

| Slice | Status/disposition | Delivers | Blocked by | Removes temporary seam |
| --- | --- | --- | --- | --- |
| 1 | new residual deepening | Direct-upgrade options mutate one plan-owned representation and the `dialConfig` mirror/copier disappears | None | n/a — no new seam introduced |

## Implementation Slices

### Slice 1 — Move direct-upgrade option state behind `upgradePlan`

**What it delivers:** A behavior-identical root configuration path in which the existing nested plan is initialized before options run, public direct-upgrade options write through plan-owned methods, plan validation owns conflicts/defaults, the transfer choice remains plan-owned until one lifecycle is constructed, and `newUpgradePlan(dialConfig, ...)` plus the mirrored `dialConfig` fields are removed.

**Existing-work disposition:** New residual slice. The 2026-07-05 dial-upgrade-plan program remains completed historical work; this slice finishes the explicitly documented mirror debt rather than reopening its implemented scope. No open PR or competing branch exists.

**Blocked by:** None.

**Single owner after merge:** `upgradePlan` owns all mutable direct-upgrade choices, packet/STUN preparation dependencies and defaults, and their conflict/static validation. `dialConfig` owns root-only dial concerns and root-only test hooks. `upgradePlanOptionSet` is a read-only derived prepared snapshot, never an option mutation authority.

**Authority completeness:** No new persisted fact is introduced. Every public direct-upgrade option constructor, plan dependency override/default, conflict/static validation, packet ownership selection, lifecycle construction, and packet/STUN preparation consumer must route through the plan; a reference audit must find no removed mirror/dependency field and no second direct-upgrade option or dependency mutation path.

**Transitional-seam budget:** None. The mirror and copier disappear in this slice. The retained derived snapshot is not transitional and must remain non-mutable from public options.

**Blast radius:** Root package configuration and tests only. Concurrency is unchanged because options are applied synchronously before dial work begins. Packet ownership, acquisition cleanup, STUN lookup, validation timing, and returned errors are material preservation obligations. No wire, protocol, transport, dependency, or performance change is accepted.

**Artifact classification:** The production refactor is shipped behavior with intentionally unchanged observation. Focused option/preparation tests are verification aids under the ordinary Go test suite. This plan is process/traceability metadata.

**Representation contract:** Supported domain = every root `Option` sequence built from the repository's exported option constructors plus test-only root dependency options, including repeated options and current conflict combinations. Representation owner = `upgradePlan` for direct-upgrade choices and `dialConfig` for root-only choices. Guarantee = canonical-subset preservation over those constructors, not arbitrary third-party functions that mutate unexported fields. Terminating evidence = constructor/reference census, focused option/conflict/default/preparation tests, and the repository gate.

**Contract closure:** Not triggered. Packet ownership is material, but the accepted refactor does not change the closed ownership rules and the finite public-option/preparation surface is reasonably covered by focused tests. Any observed ownership or validation behavior change is an approach failure, not a reason to expand a matrix.

**Evidence budget:** One positive case for each behaviorally distinct direct-upgrade option family (transport, packet ownership choice, STUN mode, timing/concurrency, relay-only, candidate policy), one representative conflict per existing conflict rule, explicit default-resource and cleanup cases, and one reference audit. No mutation harness, new platform matrix, or repetition profile. Review budget = one initial review plus at most one fully briefed replacement review. Terminate when focused tests and `task verify` pass and no mirror/copy reference remains.

**TDD and preservation evidence:** First rewrite or add assertions that observe validated options, defaults, conflict errors, and resource cleanup without comparing a plan to its own derived snapshot. Then move each option family and keep `TestNewDialConfigValidatesUpgradePlanOptions`, `TestUpgradePlanMapsDefaultTransportForNonRelayPlans`, `TestUpgradePlanMapsPreparedDirectOptions`, `TestUpgradePlanFeedsLivePreparedOptions`, and all `TestUpgradePlanPrepare*`/`TestPreparedUpgradePlanOptions*` cases green.

**Dispatch context budget:** This plan; `options.go`, `upgrade_plan.go`, `export_test.go`, and `upgrade_plan_test.go`; ADR-0008/0009 ownership constraints; the bounded diff of the historical plan only if intent is unclear. The work and review fit one fresh context and one PR.

**Slice decision audit:** Splitting option mutation from validation would temporarily create two owners, so the move is atomic. Merging `upgradePlanOptionSet` removal would add unrelated prepared-resource representation risk. There are no genuine blockers or cross-track edges.

**Stop conditions:** Stop if preserving behavior requires an exported API change, delayed validation, a generic field mutator, a second config mirror, different packet ownership, or a change to current option precedence/conflicts. Stop if `upgradePlanOptionSet` must be removed to make the chosen design compile; that indicates the slice boundary needs a new decision.

## Acceptance Criteria

- [ ] Every supported direct-upgrade public option constructor mutates the existing nested `upgradePlan`; the finite constructor/reference census finds no mirrored direct-upgrade field on `dialConfig` and no `newUpgradePlan` copier.
- [ ] Packet selection and `packetConnTransferred` remain plan-owned until exactly one packet lifecycle is constructed at the current post-option validation boundary.
- [ ] Root-only options plus consume-session/channel-decorator test hooks remain on `dialConfig`; packet-listener and STUN-resolver test dependencies are plan-owned and seeded with defaults before options run.
- [ ] Plan-owned `withDefaults()` normalization runs again after options and before `validateStatic()`, preserving nil-override fallback with no residual config-to-plan copy path.
- [ ] Current option ordering, defaults, conflict errors, validation timing, resource acquisition cleanup, packet ownership, and prepared `connect.UpgradeOption` behavior remain unchanged.
- [ ] `upgradePlanOptionSet` remains derived-only and is not exposed as a second mutation authority.
- [ ] Circular representation-equality tests are replaced where necessary with behavior-facing validation/preparation assertions.
- [ ] The public interface, wire protocol, and downstream consumers require no migration.

## Validation Gates

Run focused root tests for `TestNewDialConfigValidatesUpgradePlanOptions|TestUpgradePlan|TestPreparedUpgradePlan`, the root package test suite, `./scripts/check-gofmt.sh`, `task docs-check`, and `task verify`. Follow the repository's Go toolchain supply-chain audit before any Go command.

## Operating Discipline

Follow the shared review-loop and contract-closure baselines supplied by `$implement-architecture-slice`, composed with [`docs/REVIEW-LOOP.md`](../REVIEW-LOOP.md). Treat any public, error, timing, or ownership difference as a stop condition rather than refactor latitude.
