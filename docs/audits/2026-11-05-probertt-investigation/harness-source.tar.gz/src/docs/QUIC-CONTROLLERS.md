# QUIC sender and ACK policy

The v0.3.1 APIs below add explicit local Reno/BBRv3 selection for native endpoints and the built-in upgraded QUIC transport. Reno remains the default. Existing constructors, exported struct layouts, consumer interfaces, CLI and wire encodings are unchanged. Controller selection is local, immutable at construction and independent of the peer's controller and dialing/listening orientation.

## Module selection

Use installed Go 1.27.3 or newer after the repository toolchain audit. In the application's main module:

```sh
go get github.com/GridSwarm/wiremux@v0.3.1
go mod edit -replace=github.com/quic-go/quic-go=github.com/the-sarge/quic-go-fast@v0.62.1-fast.9
go mod tidy
```

Library replacements do not propagate. Wiremux's root module still selects ordinary upstream quic-go v0.62.0. The application must own the explicit replacement. [The fast.9 adoption record](research/quic-go-fast-v0.62.1-fast.9-native-adoption.md) pins the fork source, sums, platform scope and inherited limitations.

## Endpoint configuration

```go
import (
    "github.com/GridSwarm/wiremux"
    wirequic "github.com/GridSwarm/wiremux/transport/quic"
)

policy := wirequic.EndpointConfig{
    CongestionController: wirequic.CongestionBBRv3,
    ACKPolicy:            wirequic.ACKConservative,
}

// Native: pass the existing binding/listen/deadline settings unchanged.
endpoint, err := wiremux.NewNativeEndpointWithQUIC(ctx, nativeConfig, policy)
if err != nil { return err }
defer endpoint.Close()
// Both endpoint.Dial / DialInterface and endpoint.Accept use this policy.
// candidate.CongestionController() reads the actual connection's local sender.

// Upgraded QUIC: retain the existing keepalive/idle configuration.
transport, err := wirequic.NewConfiguredTransport(wirequic.Transport{}, policy)
if err != nil { return err }
// Initial Dial: append wiremux.WithTransport(transport).
// EstablishAuthenticated: append wiremux.WithManagedQUICTransport(transport).
// PrepareMigration: append wiremux.WithMigrationQUICTransport(transport).
// At connect.Session level: transport.NewSession(ctx, auth), then Dial or Listen.
```

Check errors before dialing or starting rendezvous. Native BBR construction and the transport factory reject missing config-selector or connection-readout capabilities with `wirequic.ErrCongestionControlUnsupported` (use `errors.Is`); neither opens a socket or sends packets first. Invalid controller/ACK values also fail construction. Native establishment separately requires the native capability set and can return `wiremux.ErrNativeUnsupported`. `wirequic.BBRv3Supported()` checks structural integration capability without I/O; it does not replace constructor error handling or performance qualification. Native readout on older forks without the optional readout is empty; explicit BBR requires it.

For GridCast, apply the policy to every endpoint or transport constructor used for initial establishment, Resume and secondary paths on **both peers**, including a peer that usually listens. A native endpoint configured with Listen also uses the same policy when it dials. Every session from a configured transport inherits the policy, including selected-interface, managed-packet and TURN profiles. A copied ConfiguredTransport keeps its settings; changing the original EndpointConfig afterwards has no effect. A preexisting Wire keeps its controller; migration settings affect only the fresh candidate. GridCast's Resume is an application operation: this API does not enable native TLS resumption, session tickets or 0-RTT. Reliable relay fallback is not QUIC and has no BBR controller. Wiremux does not select a controller on behalf of a custom transport.

## ACK policy and mixed controllers

ACK policy controls the **local receiver**, which acknowledges the remote sender. Local controller selection cannot establish the remote sender's requirements, and no controller or ACK-frequency negotiation is added. Use ACKConservative at both peers whenever either sender is BBRv3 or its controller is unknown. This leaves the QUIC implementation's ordinary ACK behavior (normally every second Application Data ack-eliciting packet, subject to its timers, gaps and ECN rules); it does not force every packet to be acknowledged.

| Local controller | Local ACK policy | Native receiver | Upgraded receiver |
| --- | --- | --- | --- |
| zero or Reno | zero / ACKDefault | Existing ACK16 optimization when optional capabilities confirm Reno; ordinary behavior otherwise | Ordinary QUIC |
| BBRv3 | zero / ACKDefault | Ordinary QUIC | Ordinary QUIC |
| zero, Reno or BBRv3 | ACKConservative | Ordinary QUIC | Ordinary QUIC |

Default native Reno retains the historical assumption that peers are known to tolerate ACK16. A Reno endpoint in a mixed deployment must explicitly use ACKConservative even though its own sender is Reno. BBR locally disables ACK16 by default as a conservative safeguard, but cannot disable the peer's ACK16. There is no supported aggressive ACK override for BBR. Ordinary upstream supports explicit Reno and ACKConservative on upgraded QUIC; native establishment remains unsupported. Explicit BBR never falls back to Reno.

## Support and rollback

BBRv3 remains experimental and unqualified for production performance, fairness, latency or throughput across platforms and networks. The focused tests establish functional selection, connection activation, role coverage and ACK behavior with exact fast.9; existing Reno certification is not BBR qualification. [Native throughput limits](NATIVE-THROUGHPUT.md), CPU-headroom requirements and historical platform evidence still apply, with no new throughput promise. Wiremux's private distribution and existing security/identity boundaries are unchanged.

To roll back, first configure Reno (or use the existing constructors), remove the application replacement with `go mod edit -dropreplace=github.com/quic-go/quic-go`, then run `go mod tidy`. Optional native endpoints still require a compatible native fork; an application requiring native establishment cannot remove that dependency and expect native fallback. Upgraded QUIC continues to operate with ordinary upstream. Preserve the application module files and test initial, Resume and secondary-path construction in its own deployment.
