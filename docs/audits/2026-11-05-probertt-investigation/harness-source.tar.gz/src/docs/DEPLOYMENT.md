# Deploying wiremux-server

`wiremux-server` is the operator-facing binary for running a wiremux relay and
STUN responder. Clients connect with `wiremux://host:port` endpoints.

## Private relay (self-signed or operator-provided TLS)

Use explicit PEM certificate and key files when operating a private relay:

```bash
wiremux-server serve \
  --relay-listen :443 \
  --stun-listen :3478 \
  --tls-cert /path/to/server.crt \
  --tls-key /path/to/server.key
```

On startup the binary prints a `sha256:<hex>` relay TLS fingerprint. Distribute
that fingerprint to clients through their pin configuration. Clients without a
pin for the endpoint use Web PKI verification instead.

Client code can convert the distributed fingerprint into a pinned TLS config:

```go
// ctx, endpoint, and sessionID come from caller setup.
pin, err := relayurl.ParsePin("sha256:<hex>")
if err != nil {
	return err
}

tlsConfig := relayurl.PrivateRelayTLSConfig(pin)
conn, err := relay.Dial(
	ctx,
	endpoint,
	relay.ModeEphemeral,
	sessionID,
	relay.WithDialTLSConfig(tlsConfig),
)
if err != nil {
	return err
}
defer conn.Close()
```

The helper uses the pin as the trust anchor for private relays, so callers do
not need to combine `InsecureSkipVerify` with `PinVerifier` manually.

### Split deployments

- Relay only: `wiremux-server serve --no-stun --tls-cert ... --tls-key ...`
- STUN only: `wiremux-server serve --no-relay --stun-listen :3478`

STUN-only mode does not load relay TLS material.

Root `wiremux.Dial` assumes co-location by default: when callers omit
`WithSTUNServer` and `WithoutSTUN`, it resolves the relay endpoint host and
uses UDP `relay_host:3478` for best-effort reflexive discovery when that lookup
is ready by upgrade negotiation. Slow or failed default DNS does not block relay
rendezvous; Dial skips default STUN and continues with host candidates.
Relay-only or split deployments should configure clients with `WithoutSTUN` or
an explicit `WithSTUNServer` for the real STUN responder. Otherwise clients may
spend the STUN gather timeout probing a UDP service that is not deployed before
continuing with host candidates.

For ephemeral SessionID rendezvous, `wiremux.Dial` starts a bounded best-effort
consume request after local upgrade success, eligible identity failure, or
one-shot post-success failure. Identity disposition markers override the default
identity-failure heuristic: spent consumes, retryable does not, and unknown uses
the heuristic. Unmarked terminal identity failure can wait for a bounded consume
attempt capped by the lesser of the default consume timeout and the remaining
Dial/establish deadline. Marked-spent identity failures and one-shot
post-success failures use the without-cancel default consume budget and may
outlive Dial/establish cancellation or deadline. Operationally, direct success
can leave a short re-pairing window until the consume request reaches the relay,
mixed lower-level `connect.Negotiator` peers can close the relay path first, and
failed best-effort consume can leave the SessionID reusable until normal expiry.
Use `WithConsumeSessionErrorHandler` when operators need telemetry for consume
failures. See the `Dial` godoc and PRD-0001 for the full consume and
retryability contract.

### Shutdown behavior

`wiremux-server serve` handles SIGINT and SIGTERM as graceful shutdown
requests. The relay, STUN responder, and ACME HTTP listener share one bounded
shutdown phase controlled by `--shutdown-timeout`:

```bash
wiremux-server serve \
  --relay-listen :443 \
  --stun-listen :3478 \
  --tls-cert /path/to/server.crt \
  --tls-key /path/to/server.key \
  --shutdown-timeout 5s
```

The default shutdown timeout is `5s`. During shutdown the relay closes its
listener and in-flight relay work through `relay.ServeContext`, STUN stops by
closing the owned UDP socket, and the ACME HTTP listener uses graceful HTTP
shutdown. Clean signal-triggered shutdown exits 0. A service error or shutdown
timeout exits 1 and prints the error to stderr.

### STUN rate limits

`wiremux-server` rate-limits STUN packets at the socket-owning layer before the stateless STUN responder parses Binding requests. The default fixed window is `1s`, with a global packet budget of `4096`, a per-source bucket budget of `128`, and IPv6 source buckets grouped by `/64`.

Tune these with `--stun-rate-window`, `--stun-max-global-per-window`, `--stun-max-source-per-window`, and `--stun-rate-ipv6-prefix-bits`. Over-budget packets are silently dropped so the responder does not generate additional reflection traffic.

Enable periodic aggregate drop reports with `--stun-rate-drop-report-interval`,
for example:

```bash
wiremux-server serve \
  --no-relay \
  --stun-listen :3478 \
  --stun-rate-drop-report-interval 30s
```

The report is written to stderr as cumulative process-local counters:

```text
stun rate-limit drops: global=12 source=34 total=46
```

`global` counts packets dropped because the server-wide STUN packet budget was
already exhausted for the fixed window. `source` counts packets dropped because
the observed source bucket was already exhausted. The global budget is checked
first, so once it is exhausted for a window, further drops are attributed to
`global` regardless of per-source bucket state. If `source` grows while `global`
remains low, inspect the per-source budget and IPv6 prefix grouping for shared
egress clients. If `global` grows, the whole responder is saturated for the
configured window and the global budget, window, or surrounding network
filtering may need adjustment. The reporter is disabled by default and reports
only aggregate counts, not per-packet or per-address logs.

For internet-facing deployments, keep host firewall or edge filtering in place and size the per-source budget for expected NAT, CGNAT, proxy, and IPv6 prefix sharing. Lower per-source budgets reduce abusive reflection from one observed source bucket but can also throttle many legitimate clients behind the same egress address or IPv6 prefix. Lower global budgets cap total responder work but can reject legitimate bursts across unrelated sources.

### Relay abuse controls

Public relays should combine network-wide connection caps with per-SessionID
ephemeral backoff. Source-bucket and global connection caps throttle broad scans
and connection floods before relay protocol work. Per-SessionID backoff handles
repeated probes against one known SessionID or ephemeral rendezvous code,
including waiter disconnects, protocol failures, pair/expiry timeouts, failed
pair status writes, and paired relay streams that close before the configured
minimum duration.

Enable per-SessionID backoff with:

```bash
wiremux-server serve \
  --relay-listen :443 \
  --stun-listen :3478 \
  --tls-cert /path/to/server.crt \
  --tls-key /path/to/server.key \
  --relay-ephemeral-abuse-backoff
```

The default window is `1m`, with a threshold of `10` suspicious events, an
initial backoff of `1s`, a maximum backoff of `30s`, and a short-pair threshold
of `3s`; the default tracker budget is `16384` SessionID keys. Tune these with
`--relay-ephemeral-abuse-window`, `--relay-ephemeral-abuse-threshold`,
`--relay-ephemeral-abuse-initial-backoff`,
`--relay-ephemeral-abuse-max-backoff`, and
`--relay-ephemeral-abuse-min-pair-duration`. Tune the tracker budget with
`--relay-ephemeral-abuse-max-tracked-sessions`. The tracker is owned by a
`relay.Relay` and survives clean restarts of `Serve` or `ServeContext` on the
same value. At the tracker cap, unthrottled keys are evicted before keys that
are currently backed off; if every retained key is backed off, the oldest
backed-off key may still be evicted to preserve the memory cap.

Lower thresholds and longer backoffs make repeated failed PAKE-like handshakes
against one known SessionID more expensive, but they can also penalize
legitimate clients that repeatedly reconnect with the same SessionID. The delay
is applied before a peer is registered as waiting, so throttled attempts do not
reveal whether the matching peer is already present. Broad cross-code guessing
still relies on global and source-bucket connection caps. Backoff-parked
connections are counted separately from registered relay waiters: the global
parked-connection cap equals the relay's `WithMaxWaitingSessions` setting
(`4096` by default), and each SessionID can have at most two parked
connections. Size file-descriptor and goroutine budgets for both registered
waiters and backoff-parked connections when the feature is enabled.
Successful ephemeral `wiremux.Dial` calls, marked-spent identity failures,
unmarked heuristic terminal identity failures, and one-shot post-success
failures can also open a short second relay connection to mark the SessionID
consumed. Marked-spent and one-shot post-success consumes use the without-cancel
default consume budget even after Dial/establish cancellation or deadline;
include that consume connection in connection-cap and file-descriptor budgets.
If an ordinary peer disconnects or cancels its dial while parked in backoff, the relay records another suspicious event for that SessionID. Repeated cancel-and-retry loops for the same SessionID therefore ratchet the delay up to `MaxBackoff` and keep it there while enough events remain inside `EventWindow`; after the window passes without fresh events, the retained count falls and the delay is reduced or cleared. Managed shutdown is the exception: releasing parked work while `Relay.ServeContext` is shutting down does not record another suspicious event, and `wiremux-server serve` uses `ServeContext` for the relay lifecycle.

Direct-upgrade consumers can close successful relay fallback streams quickly
after moving traffic to the direct path. If a product intentionally reuses the
same SessionID across those attempts, a low event threshold plus the default
`3s` short-pair threshold can treat fast successful upgrades as suspicious.
Raise `--relay-ephemeral-abuse-threshold`, lower
`--relay-ephemeral-abuse-min-pair-duration`, or leave per-SessionID backoff
disabled for those deployments until they rely on `wiremux.Dial`'s SessionID
consume contract.

Late partners, aborted rendezvous attempts, and clients that repeatedly retry
the same SessionID after pair or expiry timeouts can also cross the abuse
threshold. Raise `--relay-ephemeral-abuse-threshold`, shorten
`--relay-ephemeral-abuse-window`, or disable per-SessionID backoff for products
that intentionally permit repeated reuse before wiremux consumes the
SessionID. Failed pair status writes count as suspicious because they often mean
a peer abandoned the relay path immediately after pairing; if an environment
sees infrastructure-induced status write timeouts, use a higher threshold so a
single transient relay write failure does not throttle the SessionID.

### Pending long-lived dials

For each registered PeerID, pending long-lived dials are capped at `128` by default. One network source bucket can occupy at most one quarter of that cap (`32` by default), with a minimum of one slot. Excess dials receive the existing resource-limit protocol error before entering the queue or notifying the listener. Held connections retain their source quota until accepted, timed out, disconnected, or unregistered; crossing an arrival-rate window does not renew their capacity. Replacing removed waits cannot increase the source's share.

`relay.WithMaxPendingLongLivedDialsPerPeer` adjusts the total per-peer cap and its derived source quota. Buckets use full IPv4 addresses and `relay.WithConnectionRateLimitIPv6PrefixBits` (default `/64`), ignoring ports, IPv6 zones, and IPv4-mapped address spelling. Clients behind NAT, proxies, or a shared IPv6 prefix share a quota. A per-peer cap of one cannot reserve capacity for another source. Multiple independent attacking buckets can still fill the peer queue, and the global `relay.WithMaxWaitingSessions` cap continues to bound all pending rendezvous state.

### Pending relay connections

The relay also caps connections still completing TLS or sending their first relay request: `256` globally and `32` per network source bucket by default, in both PEM and ACME modes. These concurrency budgets are independent of the fixed-window arrival-rate caps and never reset while a connection is pending. Excess sockets are closed before a handler starts; no admission queue or waiting goroutine is created. A permit is released after failure, timeout, managed shutdown, or completion of the first request read, before rendezvous handling uses its separate waiting, registration, and pairing budgets.

Library consumers can tune these positive limits with `relay.WithMaxGlobalPendingConnections` and `relay.WithMaxSourcePendingConnections`; these settings have no serve flags. Source buckets use the same IPv4 address and configured IPv6 prefix normalization as connection arrival-rate limits. Keep the source limit below the global limit to leave capacity for other sources, and account for clients sharing NAT, proxies, or an IPv6 prefix. Distributed sources can still saturate the global pool; these caps bound retained resources rather than guaranteeing admission under every flood.

`relay.WithPendingConnectionLimitEvents` exposes best-effort concurrency rejection events with the raw remote address, source bucket, scope, occupied count, limit, and timestamp. Events never block admission and are dropped if the caller's sink is unavailable; they are visibility hints rather than exact rejection counters. The server retains ACME's longer TLS timeout for certificate bootstrap, while the pending budgets bound simultaneous stalled work. A TLS certificate callback that outlives the socket deadline continues holding its permit until it returns.

### Long-lived registration admission

Long-lived listeners occupy at most `4096` global slots and `128` slots per network source bucket by default. IPv4 buckets use the full address; IPv6 buckets use `relay.WithConnectionRateLimitIPv6PrefixBits` (default `/64`). `relay.WithMaxSourceLongLivedRegistrations` configures a positive source quota. Its effective value is capped at half the global budget, rounded down with a minimum of one, even if a larger source quota is requested. This preserves capacity for other buckets when the global budget exceeds one. Both proof-backed and explicitly proof-free registrations use these quotas, and excess registrations receive `relay.ErrResourceLimitExceeded`.

Every registration also has a finite absolute lease, defaulting to one hour and configurable with the positive `relay.WithLongLivedRegistrationLease` duration. Keepalives refresh only the idle deadline and cannot extend the lease. On lease expiry the relay unregisters the listener, invalidates its accept token, fails pending dials, and releases its source quota. Already paired streams continue. Clients receive `relay.ErrRegistrationLost` and must call `relay.Listen` again, completing a fresh proof and admission check. These library options have no serve flags.

`relay.WithLongLivedRegistrationLimitEvents` exposes best-effort rejection events with the rejected scope, effective limit, source bucket, raw remote address, and source/global occupancy at rejection. Sends never block and events are dropped when the sink is nil, full, or closed; they are visibility hints rather than exact rejection counters.

The default Ed25519 proof establishes key ownership and prevents PeerID takeover; callers can generate unlimited valid keys. Source quotas bound one observed network bucket rather than identifying a person or tenant. NAT, proxies, and shared IPv6 prefixes share a quota, while an actor controlling many buckets can still fill the global pool. Public services needing admission guarantees across distributed sources must add trusted admission at their service boundary, such as an authenticated admission proxy or a custom proof verifier backed by authorized credentials. Size network quotas for expected shared egress populations.

### Relay-assist shaping

Relay-assist shaping bounds the bytes the relay forwards on the TLS fallback path. It applies to the relay-assist stream — one rendezvous pairing, both directions summed — and never to a source address, because CGNAT and IPv6 rotation make an address a poor proxy for a person. Shaping degrades a stream and never terminates it: a stream over its ceiling is slowed by read-side backpressure, a throttled stream is not treated as idle, and no pairing is closed for exceeding a ceiling. Every knob defaults to `0` (unlimited), so an upgrade changes nothing until a value is set.

```bash
wiremux-server serve \
  --relay-listen :443 \
  --stun-listen :3478 \
  --tls-cert /path/to/server.crt \
  --tls-key /path/to/server.key \
  --relay-assist-stream-rate 262144 \
  --relay-assist-global-rate 8388608
```

`--relay-assist-stream-rate` caps one relay-assist stream in bytes per second. `--relay-assist-global-rate` caps the relay as a whole: it is one shared budget charged at the same instant as each stream's own ceiling, with the stream waiting for the longer refill, so when the sum of active streams exceeds it every stream slows together in arrival order and none is refused. Each ceiling admits a burst of one second's worth of bytes (at least one 32 KiB copy chunk) before it applies, so a per-stream value below 32 KiB/s still moves every chunk and simply waits longer between them. A binding ceiling converts excess demand into parked pairs rather than refusals: a throttled pair stays paired, is deliberately not treated as idle, and keeps holding its active-pair slot (`relay.WithMaxActivePairs`, default `4096`; the cap has no serve flag), its two sockets, and its forwarding goroutines until its bytes have moved. Size the active-pair cap and file-descriptor limits for the number of pairs a ceiling can park, not only for unshaped throughput. If a peer disappears while its pair is parked, the relay notices once it next reads that socket, so teardown can lag by up to two 32 KiB chunks of outstanding debt at the configured rate (for example about a minute at 1 KiB/s) — comparable to the paired-idle timeout that already bounds vanished peers. Ceilings never refuse rendezvous or close a pair; when parked pairs fill the active-pair budget, new pairings have relay assist withheld (see Shedding order below). Library consumers set the same values with `relay.WithRelayAssistStreamRateLimit` and `relay.WithRelayAssistGlobalRateLimit`, and can observe throttle decisions best-effort through `relay.WithShapingEvents`; the data path never blocks on that sink. Calibrated values are a per-deployment decision measured from observed traffic; the defaults are deliberately unlimited.

### Relay-assist egress breaker

The egress breaker is the financial circuit breaker for the free relay: it counts relay-assist bytes the relay forwards (rendezvous, STUN, and TLS overhead are not counted) over the UTC calendar month the hosting bill is denominated in, and trips once the running total reaches a budget. Counting runs whenever a state file is configured, with or without a budget, so calibration data accumulates before enforcement is turned on:

```bash
wiremux-server serve \
  --relay-listen :443 \
  --stun-listen :3478 \
  --tls-cert /path/to/server.crt \
  --tls-key /path/to/server.key \
  --relay-assist-egress-state /var/lib/wiremux/egress.json \
  --relay-assist-egress-budget 1099511627776
```

`--relay-assist-egress-state` names a private versioned JSON file written by this binary and read by nothing else. The relay writes it by temp-file-and-rename every ten seconds and at shutdown, so a crash never leaves a torn total; accounting since the last successful periodic write may be lost (a transient write failure is retried at the next interval rather than reported). The directory must exist and be writable, and the path must be absolute. On startup the total resumes when the file's period is the current UTC month and otherwise starts fresh; a file with an unknown version, unknown fields, trailing content, or malformed content is a startup failure (exit 1) rather than a silent reset, and so is a path the relay cannot write (the relay proves the path writable before accepting its first connection). The document is an additive surface:

```json
{"version":1,"period_start":"2026-08-01T00:00:00Z","bytes_forwarded":123456789,"budget_bytes":1099511627776,"trip_announced":false}
```

`--relay-assist-egress-budget` is the monthly budget in bytes and requires the state file, because a breaker that forgets its total on restart is not a breaker. When the total reaches the budget the breaker is tripped for the rest of the period and a `breaker-tripped` shaping event is emitted once; the file records that the period was announced (`trip_announced`) so restarts and budget changes never repeat it. The tripped state is derived from the budget in force, not the one recorded in the file: restarting with a higher budget releases a trip, and a lower one can trip immediately; while tripped, new pairings have relay assist withheld (see Shedding order below); existing streams finish and rendezvous is untouched. Library consumers use `relay.WithRelayAssistEgressStatePath` and `relay.WithRelayAssistEgressBudget`; a failed final write at shutdown surfaces as `relay.ErrEgressStatePersist` from `ServeContext`.

### Shedding order

Under pressure the relay sheds load in a fixed order that is encoded in the server, so it is never operator judgment during an incident: (1) the per-stream ceiling slows a stream, (2) the global ceiling slows all streams together, (3) new pairings have relay assist *withheld* while the egress breaker is tripped or the active-pair budget (`relay.WithMaxActivePairs`) is full, and (4) only then do the pre-existing rendezvous limits apply. Rung 3 still completes rendezvous: both peers receive the pairing reply status `0x02` ("paired, relay assist withheld") instead of OK, get a small allowance (256 KiB summed across both directions, and 15 s) to exchange direct-upgrade candidates, and are then closed by the relay. A current client sees `relay.ErrRelayAssistWithheld` in the stream's close error, so a `wiremux.Dial` that would otherwise have kept the relay fallback reports that relay assist was unavailable rather than a generic disconnect; a client older than this status treats the reply as a protocol error (the accepted wire break in ADR-0013). Withheld pairings take no active-pair slot, and rendezvous requests are never refused by the breaker. An `assist-withheld` shaping event is emitted for each withheld pairing.

### Runtime reload of shaping values

An abuse incident is exactly when a restart is least affordable, so the shaping knobs can be changed at runtime. `--relay-shaping-file` names a private versioned JSON file whose values override the shaping flags; the relay reads it at startup and re-reads it on `SIGHUP`:

```bash
wiremux-server serve \
  --relay-listen :443 \
  --stun-listen :3478 \
  --tls-cert /path/to/server.crt \
  --tls-key /path/to/server.key \
  --relay-assist-egress-state /var/lib/wiremux/egress.json \
  --relay-shaping-file /etc/wiremux/shaping.json
kill -HUP <pid>   # the wiremux-server process ID, as reported by your supervisor
```

The document is an additive surface. Every field is optional; an absent field keeps the value the relay started with (its flag), so a file can override one knob without restating the others:

```json
{"version":1,"relay_assist_stream_rate":262144,"relay_assist_global_rate":8388608,"relay_assist_egress_budget":1099511627776}
```

A reload applies all-or-nothing: the per-stream ceiling changes for new *and already-active* streams (each keeps its current balance, so a reload neither grants a free burst nor forgives outstanding debt), the global ceiling is re-rated in place, and the egress budget is replaced with the breaker state re-derived against the current period's total (a reload that first crosses the budget emits the `breaker-tripped` event) — no pairing is dropped. A chunk that is already sleeping on a wait computed under the old ceiling finishes that wait first; the stream adopts the new rate from its next chunk. A file that is missing or unreadable, or has an unknown version, unknown fields, trailing content, malformed JSON, or a negative value, is rejected: at startup that is a startup failure (exit 1) — unlike the egress state file, whose absence is a fresh start, a configured shaping file must exist; on `SIGHUP` the relay logs `relay shaping reload failed; keeping running values: ...` and keeps running unchanged, so an incident-time typo can never take the relay down. A successful reload logs `relay shaping reloaded`. The egress budget from the file still requires `--relay-assist-egress-state` at startup. Without `--relay-shaping-file`, `SIGHUP` is ignored. There is no file watching; reload is signal-driven only, and the signal is unavailable on Windows (the file is still applied at startup there). Library consumers use `relay.WithShapingFile` and call `(*relay.Relay).ReloadShaping` from their own signal handling.

### Mode restrictions

- Ephemeral rendezvous only: `--ephemeral-only`
- Long-lived rendezvous only: `--longlived-only`
- Disable long-lived registration proof (closed deployments only):
  `--longlived-proof=none`

## Public relay (ACME / Let's Encrypt)

Public relays can provision TLS automatically with ACME (TLS-ALPN-01 on the relay listener, HTTP-01 on an optional `:80` listener):

The v0.1.0 release evidence validates the in-process ACME configuration, listener lifecycle, supervision, and bounded shutdown only. It does not claim live public-CA issuance, renewal, Web PKI client validation, or hosted-topology operation; those operator-controlled checks are deferred to [issue #924](https://github.com/GridSwarm/wiremux/issues/924).

```bash
wiremux-server serve \
  --relay-listen :443 \
  --stun-listen :3478 \
  --acme \
  --acme-domain relay.example.com \
  --acme-cache-dir /var/lib/wiremux/acme \
  --relay-ephemeral-abuse-backoff
```

The cache directory must be an absolute path. Relative paths are rejected.

### Operator prerequisites

1. DNS for each `--acme-domain` must resolve to the host running
   `wiremux-server`.
2. Port `443/tcp` must reach the relay listener (`--relay-listen`, default
   `:443`). `autocert` may also attempt TLS-ALPN-01 on this listener before
   falling back to HTTP-01.
3. Port `80/tcp` is required only when the HTTP-01 listener is enabled
   (`--acme-http-listen`, default `:80`); another process bound to that
   address then prevents startup. Pass `--acme-http-listen ""` to disable it
   (see the 443-only posture below).
4. The ACME cache directory must be writable and persistent across restarts so
   renewed certificates are reused.

On first start with an empty cache, the first successful TLS handshake may take longer while certificates are issued. `wiremux-server` uses a longer TLS socket-I/O handshake timeout in ACME mode while preserving the tighter post-handshake relay request-read deadline. ACME certificate issuance runs inside `autocert`'s certificate callback and may continue under `autocert`'s own issuance timeout after a client connection reaches the relay handshake deadline; operators should retry client connections if the first attempt times out during bootstrap.

v1 uses `golang.org/x/crypto/acme/autocert`, which prefers TLS-ALPN-01 when
possible and falls back to HTTP-01. DNS-01 challenge automation is not
implemented.

In the intended public deployment shape, once an operator has successfully obtained a publicly trusted certificate, an unpinned client uses Web PKI verification and does not require out-of-band fingerprint distribution. Live validation of that operator-controlled path remains deferred to [issue #924](https://github.com/GridSwarm/wiremux/issues/924).

`--acme` cannot be combined with `--tls-cert` / `--tls-key`.

### 443-only (TLS-ALPN-01)

Where only `443/tcp` is reachable, or the process may not bind `:80`, disable the HTTP-01 listener explicitly so a port the deployment never uses cannot fail startup:

```bash
wiremux-server serve \
  --relay-listen :443 \
  --acme \
  --acme-domain relay.example.com \
  --acme-cache-dir /var/lib/wiremux/acme \
  --acme-http-listen ""
```

The startup line then reads `relay TLS: ACME for domains relay.example.com (HTTP-01 disabled; TLS-ALPN-01 only on :443)`, nothing is bound on `:80`, and the `:80` firewall rule and the container `:80` port publish can be dropped. `CAP_NET_BIND_SERVICE` is not port-specific: an unprivileged service still needs it to bind `--relay-listen :443`, and the capability lines are removable only when the relay also listens on a high port. Issuance and renewal complete over TLS-ALPN-01 on the relay listener; the certificate manager does not fall back to HTTP-01.

### Rehearse against Let's Encrypt staging

Every issuance against Let's Encrypt production spends rate-limit budget (five duplicate certificates per week). Rehearse a cutover against the staging directory first; it exercises the same DNS, port, and cache prerequisites but issues certificates from an untrusted staging root:

```bash
wiremux-server serve \
  --relay-listen :443 \
  --acme \
  --acme-domain relay.example.com \
  --acme-cache-dir /var/lib/wiremux/acme-staging \
  --acme-directory-url https://acme-staging-v02.api.letsencrypt.org/directory
```

Use a separate cache directory for the rehearsal: `autocert` stores the ACME account key and issued certificates in the cache without recording which directory issued them, so a cache populated against one CA must not be reused with another. The same applies whenever `--acme-directory-url` changes — start from a fresh cache directory. The startup line names the directory in use (`relay TLS: ACME for domains relay.example.com via https://acme-staging-v02.api.letsencrypt.org/directory (...)`); the default production line is unchanged. The same flag points the relay at any other ACME CA, such as an internal step-ca.

### CAs that require External Account Binding

Some CAs (for example ZeroSSL or Google Trust Services) require an External Account Binding: a key identifier and an HMAC key issued from the CA's account console. Pass the identifier as a flag and the HMAC key as an absolute path to a file containing its base64url encoding (padded or unpadded); the key is never accepted as a flag value, so it stays out of `ps` output, shell history, and unit files:

```bash
wiremux-server serve \
  --relay-listen :443 \
  --acme \
  --acme-domain relay.example.com \
  --acme-cache-dir /var/lib/wiremux/acme-example-ca \
  --acme-directory-url https://acme.example-ca.com/directory \
  --acme-eab-kid <key-id> \
  --acme-eab-hmac-key-file /run/credentials/wiremux-server.service/eab-hmac-key
```

Under systemd, deliver the file with `LoadCredential=eab-hmac-key:/etc/wiremux/eab-hmac-key`, the same pattern the explicit-certificate unit uses for `--tls-key`. Both EAB flags must be set together; a missing, unreadable, or undecodable key file fails startup with exit 1 and a diagnostic that names the path but never the key. As with staging, give each CA its own cache directory.

## Installing a release binary

Every command, unit file, Dockerfile, and firewall fragment in this section and the packaging sections below is an untested operator example: adapt it to the deployment and validate it there.

Among its eight release assets, each release publishes two static Linux binaries, `wiremux-server_linux_amd64` and `wiremux-server_linux_arm64`, alongside compatibility manifests and release evidence records; `checksums.txt` verifies every other asset. No other platform, container image, or package-manager artifact is published or claimed; other platforms build from source with `go build ./cmd/wiremux-server`. Releases are private, so download through an authenticated `gh`, substituting the release tag (for example `v0.1.6`) for `<version>` here and in the container examples below:

```bash
gh release download "<version>" --repo GridSwarm/wiremux \
  --pattern 'wiremux-server_linux_amd64' --pattern checksums.txt
sha256sum --check --ignore-missing checksums.txt
sudo install -m 0755 wiremux-server_linux_amd64 /usr/local/bin/wiremux-server
wiremux-server --version
```

`wiremux-server --version` prints one line in the frozen format `wiremux-server version=<version> revision=<commit>`; for a release binary the version and revision match the release record.

## Running under systemd

The unit below is an untested operator example for the private-relay recipe; adapt paths and flags to the deployment. It follows the shutdown contract above: systemd stops the service with SIGTERM, `wiremux-server` drains within `--shutdown-timeout`, and a clean shutdown exits 0, which `Restart=on-failure` does not treat as a failure.

```ini
[Unit]
Description=wiremux relay and STUN responder
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/local/bin/wiremux-server serve \
    --relay-listen :443 \
    --stun-listen :3478 \
    --tls-cert ${CREDENTIALS_DIRECTORY}/tls.crt \
    --tls-key ${CREDENTIALS_DIRECTORY}/tls.key
LoadCredential=tls.crt:/etc/wiremux/server.crt
LoadCredential=tls.key:/etc/wiremux/server.key
DynamicUser=yes
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
PrivateTmp=yes
Restart=on-failure
RestartSec=2s

[Install]
WantedBy=multi-user.target
```

Notes:

- `DynamicUser=yes` runs the service without a provisioned account, so the root-owned TLS key is handed in through `LoadCredential` instead of file-permission juggling; systemd exposes each credential read-only under `${CREDENTIALS_DIRECTORY}`.
- `AmbientCapabilities=CAP_NET_BIND_SERVICE` is what lets the unprivileged service bind `:443` (and `:80` in ACME mode). Deployments that listen only on high ports can drop both capability lines.
- Keep systemd's `TimeoutStopSec` (default `90s`) above `--shutdown-timeout` (default `5s`); if the stop timeout is shorter, systemd SIGKILLs a process that is still draining cleanly.
- For the ACME recipe, drop the `--tls-cert`/`--tls-key` flags and `LoadCredential` lines, add `StateDirectory=wiremux`, and pass `--acme --acme-domain <name> --acme-http-listen :80 --acme-cache-dir /var/lib/wiremux/acme`. `StateDirectory` creates `/var/lib/wiremux` owned by the dynamic user, satisfying the writable, persistent cache-directory prerequisite. For the 443-only posture, pass `--acme-http-listen ""` instead of `:80`.
- All diagnostics go to stderr, so journald captures them: `journalctl -u wiremux-server` shows the startup TLS fingerprint line and any shutdown error.

## Running in a container

No container image is published; the Dockerfile below is an untested operator example over the release binary. `gcr.io/distroless/static-debian12` ships CA roots, which ACME mode needs for outbound calls to the certificate authority; a `FROM scratch` image also works for private relays that never dial out, but breaks ACME issuance.

```dockerfile
FROM gcr.io/distroless/static-debian12
COPY --chmod=0755 wiremux-server_linux_amd64 /usr/local/bin/wiremux-server
ENTRYPOINT ["/usr/local/bin/wiremux-server"]
```

`--chmod` needs BuildKit (the default builder in current Docker) and matters because downloaded release assets are not executable; a plain `COPY` preserves that mode and the entrypoint then fails with a permission error. This image runs as root inside the container, which is what lets it bind `:443` under host networking; the `:nonroot` image variant works for high-port listeners, but binding ports below 1024 with it needs extra capability configuration. Mount TLS material read-only either way.

Serve STUN with host networking. STUN's response is the client's source address and port as the responder observed them, so any address-rewriting layer between the internet and the responder — container bridge NAT, a userland proxy, hairpin paths — can corrupt the reflexive candidates clients gather. Host networking removes that layer:

```bash
docker build -t "wiremux-server:<version>" .
docker run -d --name wiremux-server --network host \
  -v /etc/wiremux:/etc/wiremux:ro \
  "wiremux-server:<version>" serve \
  --relay-listen :443 \
  --stun-listen :3478 \
  --tls-cert /etc/wiremux/server.crt \
  --tls-key /etc/wiremux/server.key
```

Relay-only mode (`--no-stun`) does not depend on client source addresses for rendezvous and can run behind ordinary port publishing (`-p 443:443`). Source-bucket connection caps then bucket clients by whatever source address the container network presents, so proxied paths can group unrelated clients into one bucket. Per-SessionID abuse backoff is keyed by SessionID, not source address, and is unaffected.

For ACME mode, mount a persistent volume for `--acme-cache-dir`, writable by the container user, and publish or host-network `:80` for HTTP-01 (or pass `--acme-http-listen ""` and publish only `:443`). `docker stop` sends SIGTERM, matching the graceful shutdown contract; keep the stop timeout (default `10s`) above `--shutdown-timeout`.

## Firewall configuration

`wiremux-server` needs at most three inbound ports, all overridable by flags:

| Purpose | Default port | Protocol | Direction | Needed when |
| --- | --- | --- | --- | --- |
| Relay listener (`--relay-listen`) | 443 | TCP | inbound | relay enabled (no `--no-relay`) |
| STUN responder (`--stun-listen`) | 3478 | UDP | inbound | STUN enabled (no `--no-stun`) |
| ACME HTTP-01 (`--acme-http-listen`) | 80 | TCP | inbound | `--acme` with HTTP-01 enabled (default) |
| ACME issuance to the CA | 443 | TCP | outbound | `--acme` only |

With `ufw`:

```bash
ufw allow 443/tcp
ufw allow 3478/udp
ufw allow 80/tcp   # ACME with HTTP-01 enabled only
```

Or as an nftables input-chain fragment:

```text
tcp dport 443 accept
udp dport 3478 accept
tcp dport 80 accept   # ACME with HTTP-01 enabled only
```

STUN responses leave from the same socket the request arrived on, so stateful firewalls need no separate outbound rule. Split deployments open only the ports their enabled services use, and STUN-only mode needs no TCP rule at all. Keep the edge filtering advice from the security notes below in place for public deployments: the port being open does not remove the need to size rate limits and abuse controls for internet traffic.

## Observability

`wiremux-server serve` is deliberately quiet: every diagnostic it emits goes to stderr (only `--version` writes to stdout), and there is no metrics endpoint, health or readiness HTTP endpoint, structured log format, or systemd readiness notification in v0.1.x; the only diagnostic HTTP surface is the opt-in loopback pprof debug listener below (the ACME HTTP-01 challenge listener remains a certificate-provisioning surface, not an observability one). Operator monitoring works with the following surface:

- **Startup lines.** Explicit-certificate mode prints the frozen `relay TLS fingerprint: sha256:<hex>` line; ACME mode instead prints a `relay TLS: ACME for domains ...` line, since certificates are issued later. Absence of the expected line in the journal or container log means the relay never finished configuring TLS.
- **Version identity.** `wiremux-server --version` prints the frozen `wiremux-server version=<version> revision=<commit>` line to stdout for inventory and fleet audits.
- **STUN pressure.** Enable `--stun-rate-drop-report-interval` to get periodic cumulative `stun rate-limit drops: global=<n> source=<n> total=<n>` counters; the [STUN rate limits](#stun-rate-limits) section explains how to read the split. This is the only recurring runtime telemetry the server emits.
- **Exit codes.** Clean signal-triggered shutdown (and `--help`) exits 0. A startup failure, service error, or shutdown timeout exits 1; a usage error — unknown command, bad flag, or invalid flag combination — exits 2, both with the error on stderr. Under systemd, `Restart=on-failure` restarts every nonzero exit, so a misconfigured unit that exits 2 immediately will restart-loop at `RestartSec` until systemd's start-rate limit intervenes; read the journal before assuming a service problem.
- **Liveness probing.** A TCP connect to the relay listen address confirms the listener is accepting; the relay tolerates probes that disconnect before the TLS handshake, and it does not log per-connection activity, so probes stay quiet. Probe the STUN responder with any STUN client's Binding request against the listen port; probe traffic consumes the same rate-limit budgets as real clients, so keep probe frequency well under the per-source budget.
- **Client-side telemetry.** Session-consume failures surface on clients through `WithConsumeSessionErrorHandler`, not on the server; see the consume contract discussion above.
- **Debug profiling.** `--debug-pprof-listen 127.0.0.1:6060` serves the Go runtime profiling endpoints (`/debug/pprof/`) on a dedicated listener for operator diagnosis under load. The flag is off by default and accepts only a loopback IP host:port — a hostname, non-loopback address, or empty port is a validation error — so the listener is never reachable from other hosts; reach it remotely through an SSH port forward (`ssh -L 6060:127.0.0.1:6060 <host>`). The boundary is the host, not a service account: the endpoints are unauthenticated, so any local process that can reach loopback can read the command line, stacks, heap statistics, and CPU profiles; on hosts running untrusted local processes, enable the listener only for the diagnosis window. On shutdown the debug listener is force-closed rather than drained, truncating any in-flight profile or trace capture, so a long capture can never hold up or fail the bounded shutdown. The startup line (`debug pprof on http://<addr>/debug/pprof/`) is informational, not part of the frozen machine-relevant output contract.

The pinned Go toolchain also exposes the native goroutine leak profile through that listener. Capture its binary form and inspect it with the pinned Go toolchain:

```bash
curl http://127.0.0.1:6060/debug/pprof/goroutineleak > leak.prof
GOTOOLCHAIN=local go tool pprof leak.prof
```

For a panic-style text dump after the same leak-detection cycle, request `http://127.0.0.1:6060/debug/pprof/goroutineleak?debug=2`; unlike the default binary profile, this form includes all goroutine stacks, not only those classified as leaked. Collection runs a leak-detection GC cycle that is heavier than an ordinary GC cycle and can take quadratic work in the goroutine count in a pathological dependency chain. Leaked goroutines remain observable later in the same process, so collect hours apart rather than in a tight polling loop; a four-hour periodic interval is a reasonable starting point.

For a live relay profiling session, enable the loopback listener temporarily through the same systemd drop-in or service configuration used for CPU and heap capture, forward it over SSH, and include one `goroutineleak` capture in the session. Remove the temporary configuration afterward, restart the release service, and confirm the loopback port is closed. Future periodic profiling of a GridSwarm-operated relay should likewise retain one leak profile per interval as standing evidence alongside CPU and heap profiles.

## Security notes

- Relay traffic is TLS 1.3 only. There is no plain-TCP relay mode.
- Long-lived registration proof defaults to `ed25519-keyhash`. Disabling proof
  accepts PeerID squatting risk and should be limited to closed networks.
- Direct-upgrade remote candidates are authenticated as peer offers, but valid private, LAN, VPN, loopback, link-local, ULA, and reflexive unicast ranges are not default-blocked. Each upgrading peer sends probes toward the other peer's offered addresses on its own network stack and applies its own `CandidatePolicy` before probing, so a peer-offered loopback or private address can steer local probes unless policy excludes it. Client deployments that must avoid UDP probes to specific remote ranges should configure `CandidatePolicy.ExcludeRemotePrefixes` via `connect.WithCandidatePolicy`, for example `127.0.0.0/8`, RFC1918 ranges, `169.254.0.0/16`, VPN prefixes, `::1/128`, `fc00::/7`, or `fe80::/10`; use `CandidatePolicy.DeprioritizeRemotePrefixes` when the range is allowed but should be tried after preferred paths.
- STUN responders are unauthenticated UDP services. `wiremux-server` applies fixed-window global and source-bucket rate limits before STUN parsing, but surrounding network policy should still filter abusive traffic for public deployments.

## Related documents

- [PRD-0001: Connectivity Kernel](prd/prd-0001-connectivity-kernel.md)
- [ADR-0001: Vision and Scope](adr/adr-0001-vision-and-scope.md)
- [ADR-0005: Runtime Shutdown Supervision](adr/adr-0005-runtime-shutdown-supervision.md)
