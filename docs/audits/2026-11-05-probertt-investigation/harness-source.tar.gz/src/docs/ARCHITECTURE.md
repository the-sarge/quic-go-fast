# wiremux Architecture

## Current State

wiremux is a released v0.1.x connectivity kernel, built through the `wmx.S1` bootstrap, `wmx.S2` design-review amendments, and follow-up implementation work. The repository currently contains:

- Vision and scope ADR ([`adr/adr-0001-vision-and-scope.md`](adr/adr-0001-vision-and-scope.md)).
- Upgrade-control encoding ADR
  ([`adr/adr-0002-upgrade-control-cbor.md`](adr/adr-0002-upgrade-control-cbor.md)).
- QUIC selected-path binding ADR
  ([`adr/adr-0003-quic-selected-path-binding.md`](adr/adr-0003-quic-selected-path-binding.md)).
- Rendezvous-ledger pair-resolution ADR
  ([`adr/adr-0004-rendezvous-ledger-owns-pair-resolution.md`](adr/adr-0004-rendezvous-ledger-owns-pair-resolution.md)).
- Runtime shutdown supervision ADR
  ([`adr/adr-0005-runtime-shutdown-supervision.md`](adr/adr-0005-runtime-shutdown-supervision.md)).
- Immediate packet-socket ownership-transfer ADR
  ([`adr/adr-0008-immediate-packet-socket-ownership-transfer.md`](adr/adr-0008-immediate-packet-socket-ownership-transfer.md)).
- Optional carrier-bound Datagram capability ADR
  ([`adr/adr-0009-optional-datagram-capability.md`](adr/adr-0009-optional-datagram-capability.md)).
- v1 connectivity-kernel PRD ([`prd/prd-0001-connectivity-kernel.md`](prd/prd-0001-connectivity-kernel.md)).
- Go module and package implementation for the root `wiremux` entry point,
  `connect`, `relayurl`, `channel`, `relay`, `stun`, `transport/quic`, and the
  supported public test fixture `wiremuxtest`.
- STUN Binding client/responder behavior in `stun`.
- Host/reflexive candidate gathering, authenticated probing, direct upgrade
  negotiation, candidate policy, packet-socket handoff, and relay fallback in
  `connect`.
- Change-routed CI and local validation lanes (`task verify`), documented in
  [`CI.md`](CI.md).
- Consumer-facing `wiremux.Dial` that owns relay dial, identity handshake,
  channel construction, upgrade negotiation, and packet-socket lifecycle for
  one established wire.
- Onboarding scaffolding (this file, [`AGENTS.md`](../AGENTS.md), [`CLAUDE.md`](../CLAUDE.md), [`docs/DEV-JOURNAL.md`](DEV-JOURNAL.md), [`memory/MEMORY.md`](../memory/MEMORY.md)).
- Deployable `cmd/wiremux-server` binary with co-located relay, STUN, and
  socket-owner STUN rate limiting.

Private immutable v0.1.x releases are published; [`RELEASE.md`](RELEASE.md) is the release record and [`COMPATIBILITY.md`](COMPATIBILITY.md) is the normative compatibility contract for the released v0.1.x and v0.2.x lines. Deterministic restricted-NAT evidence shipped with the v0.1.x line; stable-version consumer migrations are handed to their owning repositories and are not wiremux release work; operator packaging and live public-CA ACME validation ([#924](https://github.com/GridSwarm/wiremux/issues/924)) remain follow-up work.

## Intended Architecture

wiremux v1 is composed of the following packages, per
[`prd/prd-0001-connectivity-kernel.md`](prd/prd-0001-connectivity-kernel.md):

```
wiremux/
├── wiremux                 # Consumer wire dialer entry point
├── wiremuxtest/            # Supported identity-agnostic test fixture
├── relay/                  # TLS-over-TCP relay client + server, dual-mode
├── relayurl/               # Endpoint URL parsing, fingerprints
├── stun/                   # STUN client + responder
├── connect/                # Candidate exchange, hole-punch, transport
│                           #   upgrade negotiation, auth-context +
│                           #   transport contracts
├── transport/
│   └── quic/               # Default QUIC transport implementation
├── channel/                # Encrypted byte-stream over auth context
└── cmd/
    └── wiremux-server/     # Relay + STUN server binary
```

The architectural seams worth naming:

- **Consumer connectivity test seam** (`wiremuxtest`). Consumer tests can start
  a real OS-ready TLS 1.3 relay restricted to IPv4 loopback and ephemeral
  rendezvous, obtain fresh fixture-pinned production `wiremux.Dial` options,
  pair raw Host and Client relay streams, preserve both paired-Dial outcomes,
  and explicitly consume and observe relay-session state. Successful resources
  transfer to automatic plus explicit concurrency-safe cleanup; setup,
  harness-timeout, unexpected serve-exit, late completion, and non-benign
  cleanup failures report through `testing.TB`. Completed owner operations keep
  owner-native types and error trees. The package is test-only in intent but is
  a supported public compatibility surface. It contains no codemux, muxcode,
  PAKE, or application behavior. Physical relay-session consumption remains
  distinct from identity-layer muxcode spending. The cross-repository ownership
  decision and owner-first consumer-adoption order are canonical in
  [codemux ADR-0006](https://github.com/GridSwarm/codemux/blob/main/docs/adr/adr-0006-public-test-support-ownership.md); wiremux links to that decision rather
  than duplicating it.

  Successful-transfer assertion policy is also owned by `wiremuxtest`: `RequireStreamTransfer` adapts reliable byte streams, `RequireChannelTransfer` adapts owner-native framed Channels, and one private bounded runner owns concurrent observation and payload-redacted diagnostics while callers retain endpoint lifecycle.

- **Wire dialer** (`wiremux.Dial`). The consumer entry point for one outbound
  wire. It parses the relay endpoint, infers rendezvous mode from
  `relay.SessionID` or `relay.PeerID`, pairs through the relay, invokes the
  caller's identity handshake on the paired relay stream, constructs the
  encrypted channel, runs `connect.Negotiator.Upgrade`, and returns a `Wire`
  whose stream is direct when upgrade converged and relayed otherwise. Direct
  upgrade defaults to `transport/quic` and an internally owned UDP socket.
  `WithPacketConn` preserves the outcome-dependent
  `connect.WithUpgradePacketConn` ownership contract.
  `WithTransferredPacketConn` instead transfers exclusive lifecycle
  responsibility to the wire dialer when it is the effective final
  packet-connection option: the upgrade-plan module closes the exact supplied
  socket on option or input validation, setup error, and relay fallback, then
  relinquishes to existing `connect` or returned-wire cleanup after the
  applicable boundary—local commit or any non-nil Dial/Accept stream,
  including stream-plus-error—and on direct success. A post-materialization
  pre-confirmation failure closes the accepted path and cannot return relay.
  The lifecycle authority is out-of-band, so custom
  transports receive the original socket without a wrapper. For
  ephemeral SessionIDs, `Dial` also owns bounded best-effort consume after local
  upgrade success, paired terminal identity failure, or a post-success failure
  for authenticators that implement `connect.OneShotRendezvous`. PRD-0001 and
  the `Dial` godoc are the authoritative consume/retryability contract. Failed
  wire-establishment error trees expose rendezvous reuse semantics
  through `connect.RendezvousDisposition`. Identity layers may declare
  identity-stage outcomes with `connect.MarkRendezvousSpent` and
  `connect.MarkRendezvousRetryable`; `Dial` also synthesizes spent disposition
  when a successful one-shot identity handshake is followed by auth-context
  validation, channel, upgrade, or nil-stream failure. Spent consumes with the
  without-cancel budget, while retryable never consumes. Unknown retains the
  default identity-failure consume heuristic on applicable identity and
  non-one-shot auth-context validation paths. Non-one-shot channel, upgrade,
  and nil-stream failures remain reusable unless one-shot success-spend
  applies. If context cancellation or deadline expiry is observed after a
  non-one-shot authenticator returns `(nil, nil)`, the identity-stage error
  retains both the context error and `connect.ErrNilAuthContext`, while
  disposition remains unknown and the ephemeral SessionID remains reusable.
  Disposition is independent of failure stage; callers combine it
  with `errors.Is` checks for `ErrIdentity`, `ErrChannel`, or `ErrUpgrade`.
  Malformed, cyclic, or traversal-truncated unmarked identity error trees
  consume only when a non-I/O domain/authentication leaf is confirmed; relay-only
  or ambiguous malformed trees remain retryable. Identity error sanitization
  preserves `errors.Is` classification, but may omit `errors.As` exposure of
  unsafe concrete wrappers such as `*net.OpError` or `*os.SyscallError`. The
  optional `connect.OneShotRendezvous` capability lives on the `Authenticator`
  value and must be forwarded by decorators.

- **Post-authentication establishment** (internal `establishAuthenticated`). Initial `Dial` prepares packet/discovery resources before pairing and retains authentication and rendezvous-consumption policy. The shared core validates the registered auth context, constructs the encrypted channel, negotiates the selected carrier, validates topology, and returns the settlement-owned Wire. `establishmentSettlement` remains the single failure-cleanup and success-transfer owner; its carrier registration and success settlement adapt the existing consumption coordinator so direct success retains the obsolete relay and relay success retains its close barrier. The core accepts no rendezvous identifier or consumption callback. This is an internal extraction; a public managed authenticated entrypoint and strict negotiation outcomes belong to later Direct Resume slices.

- **Auth-context lifecycle** (`connect/AuthContext`). This is the load-bearing
  contract between identity layers (codemux, keymux, BYO-auth) and wiremux.
  Identity layers produce; root `Dial` exclusively owns every non-nil result,
  including partial `(auth, err)` results, until failure cleanup or successful
  transfer to `Wire`. Optional `ChannelUseClaimer` enforces one irreversible
  encrypted-channel initialization; optional `AuthContextReleaser` opts retained
  material into deterministic cleanup without treating incidental `io.Closer`
  as consent. `Wire.Auth` exposes a stable non-releasing view that revokes at
  aggregate teardown. Transports receive the narrower revocable
  `connect.TransportAuth`, which cannot expose directional channel keys.
  `connect.DirectionalKeys` snapshots and validates directional keys and
  supplies the canonical orientation used by channel framing and direct-upgrade
  role assignment. ADR-0010 is the lifecycle and migration contract; PRD-0001
  remains the base connectivity contract.

- **Dual-mode rendezvous.** `relay` supports both ephemeral session-ID
  rendezvous (16-byte SID, default 15-min expiry, consumed after successful
  local upgrade, spent or heuristically terminal identity failure, or one-shot
  post-success failure — for codemux/muxcode) and long-lived peer-ID rendezvous
  (durable peer identifier, registered until disconnect or server-enforced idle/absolute lease expiry — for keymux/muxkey).
  The two modes share byte-forwarding, pair-timeout, and rate-limiting machinery.
  See
  [`adr/adr-0001-vision-and-scope.md`](adr/adr-0001-vision-and-scope.md)
  DP3.
  The current implementation has landed the TLS-only server/client surface,
  ephemeral session-ID rendezvous with bounded waiting, consumed, and active
  paired-session state, proof-disabled and default proof-backed long-lived
  `PeerID` registration with one registration and many accepted pairings,
  paired-session idle timeout cleanup, separate blocked-write timeouts, and
  accepted-connection rate caps. Operators can disable ephemeral or long-lived
  rendezvous independently via `WithEphemeralDisabled` and
  `WithLongLivedDisabled`; disabling both modes is rejected at startup.
  PEM-backed server TLS loading and startup fingerprint helpers live in
  `LoadServerTLSConfig` and `ServerTLSFingerprint`. ACME HTTP-01 provisioning
  for public relays lives in `ACMEServerTLSConfig`. Disabled-mode peers receive
  wire status `0x0e` for ephemeral-unavailable responses; older clients decode
  unknown status codes as `ErrProtocol`, which is expected additive behavior.
  `Relay.ServeContext` provides bounded relay-package shutdown by closing
  accepted relay work, draining waiters, preserving consumed tombstones, and
  reporting terminal shutdown errors. The deployable `wiremux-server` process
  uses this API for signal-driven shutdown.

- **Pluggable transport.** `connect.Transport` is a small interface that
  consumers and alternate transports implement; it is defined in
  `connect` (the consuming package) so implementations under
  `transport/` import `connect` without a cycle. Default is
  `transport/quic` over quic-go; alternate implementations (DTLS, MASQUE,
  WebRTC data channels) plug in without forking wiremux.
  The current
  `connect.Negotiator.Upgrade(ctx context.Context, opts ...UpgradeOption) (UpgradeResult, error)`
  surface is the PRD-0001 v1 API shape. The implementation currently
  validates direct-upgrade options, synchronizes first-phase fallback
  to the relay path, and exchanges first-phase direct offers carrying
  transport handshake material, probe nonce, and gathered candidates.
  Local candidate policy exclusions and deprioritization are applied
  before offer encoding, and valid offers are capped at the v1
  64-candidate bound. When both peers exchange valid offers, `Upgrade`
  orders candidate pairs, runs bounded UDP request/response probes, and
  falls back to the relay path with `probe_failed` metadata when no pair
  succeeds before the probe deadline. The byte-exact authenticated UDP
  probe codec is present for candidate-pair tokens, request/response
  datagrams, HMAC verification, observed-source matching, and stateless
  packet acceptance. Codec acceptance does not reject replays by
  itself; replay exposure is bounded by per-upgrade probe keys, random
  probe IDs, and probe deadlines. Successful probes continue through
  dialer-selected pair announcement, listener `ready`, dialer `commit`,
  listener `accepted`, dialer `converged`, listener `confirmed`, and exact
  packet-socket handoff to the configured transport. After preparing `Listen`
  on the selected pair, the listener begins transport `Accept` concurrently
  with signaling `ready` and awaiting `commit`; both wiremux QUIC ALPN profiles
  prime the client stream with an initial `0x00` byte so the listener's
  `AcceptStream` completes on reused probe sockets, and strip that byte before
  returning the application stream. The `WithUpgradePacketConn` packet-socket
  ownership contract leaves a dialer's socket caller-owned until local commit
  and a listener's socket caller-owned until local commit or any non-nil
  Dial/Accept stream.
  A non-nil stream transfers cleanup immediately even with an accompanying
  error and before observed commit. After the applicable boundary,
  `ErrUpgradeTransportNotConverged` closes the supplied socket and relay
  fallback is not available; direct success transfers cleanup to the returned
  stream.
  Extracting the QUIC-local accept-once listener state machine into the adapter
  kit remains deferred until a second production `connect.Transport`
  implementation is planned; the trigger is tracked in
  [issue #418](https://github.com/GridSwarm/wiremux/issues/418).
  See ADR-0001 DP1.

- **QUIC receive completion.** The QUIC adapter owns one coherent final-offset/delivered-offset observation. Native EOF remains EOF; a normal remote parent close becomes EOF only after final-offset publication and complete caller delivery, while unknown final state, unread payload, reset, nonzero close, deadline, cancellation, and other nonqualifying errors preserve their identities.

- **Optional Datagram plane.** ADR-0009 adds an implemented
  optional, carrier-bound unreliable-unordered atomic-message plane without
  changing the required `Transport`, `Session`, or `TransportListener` method
  sets. A supporting transport-native stream returned directly by
  `Session.Dial` or `TransportListener.Accept` implements
  `connect.DatagramCapable` before reliable-only wrapping; each role validates
  and retains its `DatagramCarrier` immediately when that transport result
  arrives, before wrapping or the role's next control transition. `connect`
  intersects the two validated results through
  the existing post-commit
  `"wiremux.datagram/1"` extension in accepted/converged/confirmed, so
  mixed-version or one-sided optional exposure becomes absence on both roles.
  Only agreed presence is carried in `UpgradeResult.Datagrams`. Root `newWire`
  snapshots that field rather than rediscovering an optional interface on the
  decorated stream, and `Wire.Datagrams()` exposes the resulting concrete
  borrowed handle. The handle reports one lifetime-fixed exact
  consumer payload ceiling, provides context-bearing send and receive, and is
  safe for concurrent callers. The lower carrier also exposes one cause-bearing
  lifetime context, which root wiremux monitors so idle peer or transport
  teardown closes the admission gate before any later send can succeed. A
  supporting carrier owns a bounded, context-cancellable send-admission queue
  for lower-level callers; the root handle keeps its separate consumer-level
  queue and error boundary.
  Both upgrade roles strip `DatagramCapable` from `UpgradeResult.Stream`, which
  never exposes the optional interface after extraction;
  `UpgradeResult.Datagrams` is the exclusive lower capability surface. Classified
  reliable-read outcomes close the Datagram gate and release its workers but do
  not initiate aggregate teardown or change reliable half-close behavior while
  carrier lifetime remains active; other direction-local errors retain today's
  independent-plane behavior.
  `Wire.Close` remains the sole lifetime owner; both planes share one carrier,
  congestion authority, security boundary, and aggregate owner. Local
  capability validity is negotiated by the selected transport, final exposure
  is synchronized by the post-commit extension, and neither is inferred from
  transport name or directness. The current
  TLS/TCP relay and stream-only custom transports report absence while the
  reliable Wire behaves exactly as today. The first implementation maps the
  carrier to RFC 9221 on the existing QUIC connection. Relay reliable bytes use
  wiremux encrypted-channel framing; direct reliable bytes and Datagrams use
  QUIC packet protection, and Datagrams never use channel framing.
  Datagram-capable peers select `wiremux-quic/2`, which commits both endpoints
  to `max_datagram_frame_size >= 1195`; legacy `wiremux-quic/1` remains
  stream-only. The mapping uses a one-octet wiremux envelope and an explicit
  1232-byte initial packet-size invariant (the IPv6-safe floor, required
  so the class stays valid once the transport honours DF, #1317).
  Upgrade-control remains version 1
  with the same transitions; only its existing ignore-unknown extension map is
  populated. See
  [ADR-0009](adr/adr-0009-optional-datagram-capability.md) and its
  [implementation handoff](adr/2026-07-11-datagram-capability-implementation-plan.md)
  and [QUIC conformance evidence](research/issue-624-quic-datagram-conformance.md).
  When the built-in QUIC session receives the official `connect/pionturn`
  relay composite it selects the exclusive `wiremux-quic/3` relay profile
  instead: a fixed 1200-byte packet class with path MTU discovery disabled and
  a 1160-byte lower Datagram ceiling, certified through real TURN ChannelData
  on IPv4 and IPv6-minimum paths per
  [ADR-0012](adr/adr-0012-turn-udp-relay-candidates.md). The session selects
  `/3` from the packet marker alone; `internal/relayprofile` also owns a
  sealed transport-shape eligibility check that admits only the built-in
  transport value or its pointer, applied by the relay retry consumer before
  handing a composite to any session. The eligible identity is owned by the
  detector package itself: the production mint seals only the built-in
  transport's package-scope defined type, so no other in-module provider can
  bless its own dynamic type (a function-local type in that package could
  share the reflected name but cannot declare methods, and embedding shapes
  are rejected before the mint runs), and test doubles use an explicit
  test-only seam that panics outside a test binary.
  The public root retry path is additionally certified against the exact pinned coturn 4.16.0-r0 Linux TURN/UDP fixture for authenticated `/3` streams, the 1159-byte public Datagram boundary in both directions, an IPv6 `udp6`/`[::1]` Allocate leg whose relayed addresses are non-loopback IPv6, and reliable fallback on credential, permission, and unavailable-server failures; this is example-level independent-server evidence rather than a runtime dependency or universal coturn claim.

- **Deployable kit.** `cmd/wiremux-server` ships relay + STUN as a single
  binary by default (`--no-stun`, `--no-relay` flags allow split
  deployments). Private relays use explicit PEM TLS plus startup fingerprint
  output; public relays may use ACME HTTP-01. Operator setup is documented in
  [`docs/DEPLOYMENT.md`](DEPLOYMENT.md). SIGINT/SIGTERM cancellation runs a
  bounded shutdown phase controlled by `--shutdown-timeout` for relay, STUN,
  ACME HTTP, and opt-in debug pprof services.
  See ADR-0001 DP4 and DP7.

## Invariants

- Long-lived registrations have atomic global/source-bucket admission budgets and a finite absolute lease (one hour by default). The default source quota is 128, capped at half the global budget with a minimum of one; source buckets share the connection-rate limiter's IPv4/IPv6 normalization. Keepalives cannot renew the absolute lease, and an owned expiry timer interrupts the raw control transport even when TLS Read is blocked on output. Expiry reclaims registration capacity, invalidates tokens and resolves pending dials while existing paired streams continue. Clients re-register with `Listen`; best-effort `LongLivedRegistrationLimitEvent` notifications report rejection occupancy.
- Before starting a connection handler, the relay acquires one global and one source-bucket pending-connection permit. The default caps are `256` globally and `32` per source, independently of arrival-rate windows. Permits cover TLS and the first relay request read and release on every exit or before rendezvous dispatch; stalled ACME handshakes therefore cannot create an unbounded handler population. The source cap leaves capacity for other buckets, and best-effort `PendingConnectionLimitEvent` notifications expose saturation.
- For each registered long-lived PeerID, one normalized network source bucket may hold at most `max(1, per-peer pending cap/4)` pending dials (`32` by default). The ledger rejects excess attempts before queue entry or listener notification, and queue removal releases the source's share under the same lock. Buckets use the connection limiters' IPv4 and configured IPv6 prefix normalization; NAT, proxy, and loopback callers can share a quota. Independent buckets retain capacity subject to the existing per-peer and global caps; a per-peer cap of one cannot reserve another slot.
- The relay treats payloads as opaque and never learns auth secrets.
- The relay pairs only peers that present the same rendezvous identifier
  in the same mode.
- Guess-limiting is keyed by rendezvous identifier, not source IP. Current relay
  protections are bounded unpaired waits, consumed-session records, active
  paired sessions, request deadlines, long-lived notification write deadlines,
  long-lived control idle timeout and opcode validation, per-peer pending
  long-lived dial caps, paired-session idle timeout, periodic expiry cleanup,
  and fixed-window accepted-connection caps at global and
  per-source network-bucket scope (ADR-0001:DP3). Source buckets are
  pre-auth network observations, not user or identity limits: IPv4 is keyed
  by full address, IPv6 is keyed by a configurable prefix (`/64` by
  default), and shared egress populations must size the source cap
  accordingly. The global accepted-connection cap also bounds new-pair ramp-up:
  a typical completed pairing consumes two accepted relay connections, while a
  long-lived listener also consumes one accepted control registration
  connection. Operators can subscribe to lossy, best-effort rate-limit
  rejection events without taking a logging dependency; events expose only
  pre-auth network metadata (remote address string, normalized source bucket,
  rejected scope, count, limit, window, and timestamp) and are dropped when the
  sink is not ready. Events are visibility hints, not exact rejection-volume
  accounting: `ConnectionRateLimitEvent.Count` reports consumed accepted
  capacity at the cap rather than rejected-attempt volume.
  Public ephemeral relays can additionally enable per-SessionID backoff:
  repeated suspicious outcomes for one known SessionID delay later dials for
  that same ID before the peer is registered as waiting. The tracker has a hard
  cap on abuse keys and evicts unthrottled keys before currently backed-off
  keys, preserving the cap even if every retained key is already throttled.
  Detailed tuning lives in
  [`docs/DEPLOYMENT.md`](DEPLOYMENT.md).
- `stun.Client.Reflexive` and `stun.Server.Serve` operate on
  caller-supplied `net.PacketConn` values. They do not close those sockets.
  `Reflexive` temporarily owns reads and read deadlines while it is running,
  then clears its read deadline before returning. Callers must pass a
  cancellable or deadlined context for reflexive discovery. Closing the STUN
  responder's packet socket stops `Serve` and returns nil. This keeps the same
  socket available for later candidate probing and transport upgrade, where NAT
  mappings must be reused rather than recreated on a fresh socket.
- The minimal STUN responder is stateless and unauthenticated. `cmd/wiremux-server` applies fixed-window global and source-bucket rate limits at the socket-owning layer before `stun.Server` parses packets. Operators can enable periodic cumulative drop reports split by global and source-bucket rejection scope; the report is aggregate-only and does not emit per-packet or per-address logs. Public deployments should still use surrounding network policy for broader abuse controls.
- `wiremux-server serve` supervises relay, STUN, ACME HTTP, and the opt-in
  debug pprof listener as one process lifecycle. On SIGINT/SIGTERM or service
  failure it starts bounded shutdown: relay stops through `Relay.ServeContext`,
  STUN stops by closing the owned UDP packet socket, ACME HTTP stops through
  graceful `http.Server.Shutdown`, and the debug pprof listener stops through
  `http.Server.Close`, deliberately truncating in-flight captures so a long
  profile can never exhaust the bounded shutdown budget. Clean cancellation
  exits 0; service errors or shutdown timeout exit 1.
- Long-lived registration requires proof of PeerID possession by default
  (ADR-0001:DP9). The default relay verifier is `ed25519-keyhash`: a client
  proves possession of the private key whose public key hashes to the claimed
  `PeerID`, over a domain-separated, length-prefixed transcript bound to the
  registrant-to-relay TLS 1.3 exporter. Operators can explicitly configure
  `WithLongLivedProofNone` for proof-free registration, which carries PeerID
  squatting risk. Ephemeral mode does not require registration proof.
- `connect/AuthContext` admits PAKE-derived (codemux), Noise-IK-derived
  (keymux when implemented), and externally-supplied auth contexts without
  modification. Directional keys must be non-empty, distinct, AES-sized, and
  mirrored across peers (`peerA.SendKey == peerB.ReceiveKey`). Changes to the
  interface require a reviewed wiremux ADR.
- Transports make no identity decisions of their own and receive only
  `connect.TransportAuth` binding/exporter authority, never directional channel
  keys. They enforce the channel-bound handshake material delivered by the
  negotiator (ADR-0001:DP8 — for QUIC, mutual
  ephemeral-certificate pinning, since Go's `crypto/tls` has no
  external-PSK API).
- Direct transports run over the selected candidate pair only. For
  QUIC v1, connection migration and NAT rebinding are disabled or
  filtered so packets from non-selected sources cannot establish,
  replace, or confuse the returned stream (ADR-0003).
- Remote direct-upgrade candidates arrive inside authenticated upgrade-control offers, but wiremux treats authentication as peer provenance rather than an egress allowlist. v1 filters invalid, unspecified, multicast, zero-port, unsupported, and incompatible candidates, but it does not default-block valid private, LAN, VPN, loopback, link-local, ULA, or reflexive unicast ranges because those are legitimate direct paths for local and closed deployments. Products that need stricter egress controls set `CandidatePolicy.ExcludeRemotePrefixes`; products that only want those paths later in the order use `CandidatePolicy.DeprioritizeRemotePrefixes`.
- The encrypted channel uses `connect.DirectionalKeys` for key validation and orientation, per-direction counter nonces with strict sequence enforcement, and an authenticated close frame; replay, reordering, mid-stream gaps, and stream-end truncation (raw EOF before the close frame) are fatal channel errors that stop both directions. A send-side transport write failure is terminal for `Send` and `Close` only; `Receive` keeps draining frames the peer already delivered until its own EOF, close frame, or error.
- The encrypted byte-stream adapter treats authenticated empty data frames as `ErrStreamEmptyDataFrame` by default, a terminal read-side no-progress stream error; the write side remains independent. `AllowEmptyDataFrames` makes `Stream.Read` skip authenticated empty frames for channel-shaped traffic. `Stream.Close` is graceful, serializes with in-flight writes so a close frame cannot split a multi-frame write, and is not an abort path for a write stuck in the underlying transport.
- New code must arrive with its build, test, lint, and CI gate in the same
  PR.

## Family Position

wiremux is the dependency floor for the GridSwarm family. codemux v1
(ephemeral muxcode/PAKE identity), keymux v1 (persistent muxkey/Noise
identity, deferred), and meshmux (mesh coordination, deferred) all depend
on wiremux. External consumers (tapmux, swarmcast, the file-sync tool, and
non-identity consumers like Kubernetes peering or IoT fleet tools) consume
wiremux directly for connectivity and indirectly through codemux/keymux
for identity.

See
[`GridSwarm/org-docs/docs/decisions/adr-0001-four-product-family.md`](https://github.com/GridSwarm/org-docs/blob/main/docs/decisions/adr-0001-four-product-family.md)
for the full family taxonomy.

## Glossary

Shared domain vocabulary — **Candidate**, **Host candidate**, **Reflexive candidate**, **Authenticated probe**, **Candidate policy**, **Packet-socket ownership transfer**, and the rest of the Wire language — is defined once in [CONTEXT.md](../CONTEXT.md). This glossary defines only terms this architecture snapshot uses that CONTEXT.md does not.

- **STUN Binding:** The unauthenticated STUN request/response used by wiremux
  to discover a reflexive address.
- **XOR-MAPPED-ADDRESS:** The STUN response attribute carrying the observed
  source address XORed with the STUN magic cookie and transaction ID.
