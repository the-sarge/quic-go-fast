# Review Loop Protocol

This repository's overlay on the shared review-loop baseline that ships with the
agent skills (`_shared/REVIEW-LOOP.md`, reachable from any skill directory as
`../_shared/REVIEW-LOOP.md`).

**Read the baseline.** It owns the loop itself: finding-family classification, the
precise invariant-and-owner history check, the approach-stop policy, low/nit loop
control, exact-head local certification, same-head hosted CI, merge, journal, and
tracking.

Implementation plan docs reference this file from their Operating Discipline
sections; do not restate the loop inline.

Everything the baseline covers is deliberately left out below. This file used to
restate it, and the copy fell three rules behind its source: the approach-stop
policy, the finding-family policy, and the step comparing a blocking synthesis
against every prior fresh review. Only repository-specific rules belong here —
stated as additions, or, where they deliberately conflict with the baseline, as
explicit overrides with their reason.

## PR bodies and closing directives

Genuinely single-line PR descriptions may use `gh pr create --body`. When
physical multiline content is intended, write it to a Markdown file and pass
that file to `gh pr create --body-file`. Do not embed escaped `\n` text in a
`--body` argument: GitHub stores the backslash and `n` as two characters rather
than a line break, so a following intended closing keyword can remain part of
adjacent text and fail to populate `closingIssuesReferences`. Use
`gh pr edit <pr> --body-file <file>` for every later multiline body change too.

After every PR creation or body edit, regardless of the body mechanism, inspect
the decoded stored body and its base branch plus closing-issue references:

```bash
gh pr view <pr> --json body --jq '.body' | sed -n 'l'
gh repo view --json defaultBranchRef --jq '.defaultBranchRef.name'
gh pr view <pr> --json baseRefName,closingIssuesReferences
```

Raw JSON escapes physical newlines as `\n`; that spelling is not itself a
failure. In the decoded `sed` listing, `$` marks a physical line ending; a
trailing backslash on a display-wrapped listing line is a `sed` artifact, and
`\t` may represent a tab. A `\r` immediately before `$` represents a stored
CRLF ending and still counts as a physical line break. Display rows ending in a
backslash continue the same physical line; join them until the row ending in
`$` before judging the record.

A body is broken when an intended line break — in particular, one before a
closing directive — remains the two literal characters `\n` instead of
appearing as a physical line ending. Intentionally discussing literal `\n`
text in prose is valid. BSD `sed` commonly displays that literal sequence as
`\n`, while GNU `sed` commonly displays it as `\\n`; classify both the same
way. Under repository policy, a closing directive must be the sole
non-whitespace content of its reconstructed physical line:

```text
Closes #639$                 good: one complete physical record
Summary\nCloses #639$        broken: one record with an escaped break
```

When `baseRefName` equals the reported default branch,
`closingIssuesReferences` must exactly match the issues intentionally named by
canonical repository closing directives: `Closes`, `Fixes`, or `Resolves`.
Missing references require repairing the directive structure; unexpected
references require removing accidental closing-keyword use. Other GitHub
keyword variants may work, but do not use them in this repository. GitHub may
leave the reference list empty for a correctly formatted PR targeting a
non-default base, so inspect the decoded body there and repeat the
closing-reference check after retargeting to the default branch. If any
applicable check fails, repair the body with
`gh pr edit <pr> --body-file <file>` and repeat verification.
