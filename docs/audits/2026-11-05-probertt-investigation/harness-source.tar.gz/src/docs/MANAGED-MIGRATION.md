# Managed authenticated migration

`PrepareMigration(ctx, old, raw, freshAuth, relayURL, opts...)` prepares a fresh authenticated direct carrier while a live reliable relay wire continues application I/O. `old` must be a `*Wire` from `Dial` or a `*ManagedWire` from `EstablishAuthenticated`, with reliable relay path metadata. Zero, closed, direct, TURN and external wrapper handles are rejected. Both facades share the underlying Wire's exclusive migration slot.

The caller owns migration request/acceptance, fresh authentication and same-transfer admission, and bilateral cutover. The fresh bootstrap is already paired and authenticated, with full-duplex I/O and an interrupting `Close`. Its carrier and auth ownership transfer at invocation, even on invalid input, busy rejection, cancellation or failure. The old wire is borrowed until commit. Never supply its auth, a borrowed auth view, or previously used channel material as fresh auth. Generic AuthContexts cannot prove identity continuity or cryptographic freshness; these remain caller preconditions, with existing channel-use claims enforced when available.

On Linux, macOS, and Windows, `WithMigrationSelection(handle)` constrains only the fresh candidate. The raw input must be the exact final carrier minted by `relay.Dial(..., relay.WithSelection(handle))`, and the migration option must receive the identical opaque handle. Invalid, absent, wrapped or mismatched provenance fails before fresh negotiation or UDP construction; a stale handle fails when fresh UDP construction validates it and disposes fresh raw/auth inputs through the existing establishment settlement; it does not retire an otherwise live old wire. The old carrier may be unrestricted, and no whole-session confinement claim covers its pre-commit traffic.

Preparation reuses strict managed establishment, default discovery and built-in QUIC. It adds no control bytes to the old application stream. There are no TURN, custom transport, packet socket, relay-only or Datagram configuration options. The ready `MigrationSession` exposes only `Info`, `Done`, `Commit` and `Abort`; it offers no application I/O, auth or raw carrier. The obsolete bootstrap has been released before readiness. The session keeps the fresh candidate private under its existing Wire lifetime owner until publication or disposal.

`WithMigrationSelection` supplies the explicit fresh routing authority. `WithMigrationControlTimeout` and `WithMigrationProbeTimeout` override the positive per-phase budgets (three seconds by default). `WithMigrationTimeout` bounds preparation and the ready handle until local seal or abort, to 30 seconds by default. The caller context also bounds preparation and readiness; nil means `context.Background`. The earlier deadline wins. A committed wire has an independent lifetime.

```go
session, err := wiremux.PrepareMigration(ctx, old, raw, freshAuth, relayURL)
if err != nil {
    // Fresh inputs are already disposed; inspect *wiremux.MigrationError.
    return err
}
// Continue old relay I/O while arranging application-owned bilateral cutover.
// On refusal, call session.Abort(). Otherwise, at the local cutover boundary:
result := session.Commit()
switch result.Outcome() {
case wiremux.MigrationCommitted:
    next := result.Wire()
    // next is the sole local application carrier. Err may contain retirement
    // diagnostics, including an expected abort-induced old-carrier error.
    return runFreshAttempt(next)
case wiremux.MigrationInterrupted:
    // The old carrier was sealed. There is no relay rollback.
    return recoverInterruptedAttempt(result.Err())
default:
    // Local preparation did not retire the old carrier. Its independent
    // lifetime and the remote peer's cutover status still need consideration.
    return result.Err()
}
```

Commit first checks the operation context, candidate and old-wire eligibility at the exclusive slot. It seals old application I/O, detaches its session from the old teardown join, interrupts the carrier using `Wire.Abort`, and joins the existing bounded auth release and initial rendezvous-consumption obligations. Only then does it publish a distinct `ManagedWire`. The old object's stream and metadata are never swapped. Old I/O fails closed and old borrowed auth is revoked. New auth belongs to the new wire and cannot be revoked by later old-wire teardown.

| Local outcome | Carrier authority |
|---|---|
| `MigrationCommitted` | `Wire()` returns the distinct direct managed wire. Old relay is retired. `Err()` may retain retirement diagnostics. |
| `MigrationAborted` | Explicit abort won; fresh resources are disposed. A still-live old wire remains usable. |
| `MigrationPreserved` | A failure won before local seal; no new wire is published and this operation did not retire the old wire. Independent old-wire closure may already have occurred. |
| `MigrationInterrupted` | Failure after local seal; candidate is disposed and old relay is unusable. No rollback. |

One worker serializes commit, abort, cancellation, deadlines and old-wire teardown. Every repeated terminal call observes the same outcome, error and wire. A losing abort cannot dispose a committed wire. `Done` closes after terminal cleanup or publication. Old-wire teardown cancels and joins an uncommitted session; commit detaches before retiring the old wire to avoid a cyclic join. Commit wins terminal arbitration at the local seal. Later preparation cancellation or expiry is retained as a diagnostic and does not dispose a healthy candidate; actual candidate death before publication produces interruption. Initial carrier interruption may first wait for its protected bounded rendezvous-consumption attempt, but never for a graceful application write.

Preparation errors expose `MigrationError.Kind`: `local`, `busy`, `no_direct`, `failed_probe`, `protocol`, `transport`, `transient_transport`, `canceled`, `deadline`, or `old_closed`. Safe negotiated fallback is no-direct; a negotiated failed probe is distinguished. Strict protocol and transport failures retain the current establishment owner's classification and underlying error identities. Post-seal termination uses `interrupted_after_seal`. No local result establishes atomic two-peer commit or proves that a remote relay remains usable.

The bounded migration evidence covers real direct preparation/commit, relay continuity on abort and failure, strict fallback/probe/invalid-control outcomes, both old-wire forms, exclusive slot disposal, auth independence, old-close joining, concurrent terminal calls, post-seal context diagnostics and candidate failure. Selected-migration evidence additionally covers exact fresh forwarding, invalid/mismatched/stale provenance disposal, abort preservation and commit publication over one real Linux selected path. In-flight old I/O retains its actual byte count and safe underlying error identities when it overlaps the seal; subsequent old I/O fails before touching the carrier. Existing establishment, initial consumption, graceful close, abort and compatibility suites remain the preservation gate. Bilateral cutover and GridCast admission belong to the downstream [G1 slice](https://github.com/GridCastIO/gridcast/issues/1152); migration does not introduce persistent state or restart semantics.

## Configured built-in QUIC

`WithMigrationQUICTransport(transport)` selects the module-owned `*quic.ConfiguredTransport` returned by `quic.NewConfiguredTransport` for the fresh candidate only, in either dialing/listening orientation. It retains built-in selected-interface eligibility and does not admit arbitrary custom transports. Nil fails fresh establishment preflight through the existing fresh-input disposal path and preserves the old Wire. The old Wire's settings are unchanged. Configure both peers explicitly for each fresh path; [controller adoption](QUIC-CONTROLLERS.md) gives exact fast.9 and conservative ACK settings and experimental support limits.
