# wiremux

Pairwise peer-to-peer connectivity primitive for the [GridSwarm](https://github.com/GridSwarm) product family.

wiremux gets two parties a wire between them: TLS-over-TCP relay rendezvous, STUN, UDP hole-punching, transport upgrade, and pluggable transport (default QUIC). It is **identity-agnostic** — codemux's PAKE-derived ephemeral identity, keymux's Noise-IK persistent peer identity, and bring-your-own-auth consumers all plug in via the same `AuthContext` interface. Root `Dial` owns each returned auth context through failure cleanup or aggregate `Wire` teardown; opt-in claim and release capabilities enforce single channel initialization and deterministic retained-material cleanup.

Consumers that already pair and authenticate peers can use [`EstablishAuthenticated`](docs/MANAGED-ESTABLISHMENT.md) for managed direct or relay establishment without rendezvous consumption. Its owning result supports abort and graceful close; initial `Dial` retains its consumption policy.

## Status

wiremux's current release is the private, immutable [v0.3.0](https://github.com/GridSwarm/wiremux/releases/tag/v0.3.0), published 2026-10-27 (America/New_York). The [notes](docs/release/v0.3.0/notes.md) record native packet-I/O improvements, native receive-drop snapshots and relay admission/lease hardening, including the source and behavioral changes in the [compatibility contract](docs/COMPATIBILITY.md); [CHANGELOG.md](CHANGELOG.md) indexes every release.

Ordinary upstream quic-go v0.62.0 remains the default, with explicit unsupported-native behavior. Native consumers select application-owned optional quic-go-fast v0.62.1-fast.9; the notes show replacement, capability validation and upstream rollback. Installed Go 1.27.3 or newer is required. [Native throughput](docs/NATIVE-THROUGHPUT.md) preserves actual measured cells, fork revisions and limitations, including Windows misses and Arm pending.

The [v0.3.0 publication record](docs/RELEASE.md#v030-release-record) verifies the frozen source, immutable Release, binaries, inventories, native packaged-server smoke, NAT evidence and independent published-source/module/upstream/fork/rollback checks. The reviewed [v0.1.0 notes](docs/release/v0.1.0/notes.md) retain inherited scope/non-claims. Downstream version adoption remains separately owned.

The Go module,
root `wiremux.Dial` entry point, package layout, CI validation gate, relay
rendezvous behavior, STUN, candidate gathering, authenticated probing,
transport upgrade negotiation, QUIC transport, encrypted channel, and
deployable `wiremux-server` are implemented and covered by the local
validation gate. Direct QUIC Wires also expose the optional carrier-bound
Datagram capability; relay and stream-only paths retain reliable service with
the capability absent. The relay supports
ephemeral SessionID rendezvous and long-lived PeerID rendezvous with the
default `ed25519-keyhash` registration proof. Relay state budgets,
source-bucket/global connection caps in the `relay` package, optional
per-SessionID ephemeral abuse backoff in the `relay` package and
`wiremux-server`, and STUN rate limiting in the deployable `wiremux-server`
are present. Integration tests in `internal/integration` cover consumer-shaped
relay-to-direct QUIC upgrades using host-candidate loopback and deterministic
STUN/reflexive candidates.

The supported public `wiremuxtest` package provides consumer tests with a real
ephemeral-only TLS 1.3 loopback relay, fixture-scoped production Dial options,
raw relay pairing, paired `wiremux.Dial`, bounded cleanup, and explicit
relay-session consumption and observation. It is test-only in intent but
covered by normal public compatibility protection.

Root `wiremux.Dial` supports two explicit caller-supplied packet-socket contracts. `WithPacketConn` preserves the lower-level `WithUpgradePacketConn` behavior: callers retain the socket for fallback or setup errors only before local direct-transport commit or any non-nil stream returned by `Session.Dial`/`TransportListener.Accept`. A non-nil stream transfers cleanup even with an accompanying error and before listener commit is observed, so later validation failure closes only that accepted path and cannot return relay. Direct success transfers the same stream-owned claim to the returned Wire. After local commit with a definitive nil-stream result, `ErrUpgradeTransportNotConverged` closes the supplied raw socket before returning no stream; relay fallback is unavailable. Root reads only the monotonic transfer fact, never the error tree, to choose its configured pre-transfer lifecycle or relinquish. `WithTransferredPacketConn` transfers exclusive lifecycle responsibility when it is the effective final packet-connection option. After transfer the caller must not close, reuse, read from, or write to the single-use socket; `Dial` closes it on every early error and relay fallback, while the transport stream or post-commit raw owner handles later failure and direct success.

The optional fork packet-I/O integration retains the selected-peer wrapper and supports managed endpoint reuse. The [assembled support matrix](docs/research/e02-support.md) records the qualified Linux, Windows and macOS domains, ordinary defaults and performance limitations. Upstream quic-go remains the default dependency; raw socket return after receive coalescing is unsupported.

Direct QUIC reads report a normal remote parent close as `io.EOF` only after QUIC has published the final receive offset and the caller has received every byte through it. If parent teardown wins before final-offset publication or complete delivery, the underlying non-EOF transport error is preserved.

Root `wiremux.Dial` direct upgrade defaults to `transport/quic`, an internally
owned UDP packet socket, and best-effort STUN at `relay_host:3478` unless the
caller sets `WithSTUNServer` or `WithoutSTUN`. The default relay-host lookup
runs without blocking relay rendezvous; slow DNS, DNS failure, address-family
mismatch, or an invalid default-derived STUN address skips default STUN and
continues with host candidates. If the default UDP socket cannot be opened,
`Dial` can still return a relay-path wire without error; inspect
`Wire.Direct()` or `Wire.Info()` for the selected path. A reachable default STUN
address with no STUN responder can still add up to the STUN gather timeout
before host-candidate probing continues; split relay/STUN deployments should
pass the real STUN address explicitly or disable reflexive gathering with
`WithoutSTUN`.
For ephemeral SessionID rendezvous, `Dial` starts a bounded best-effort
`ConsumeSession` after local upgrade success, eligible identity failure, or
one-shot post-success failure. Identity layers can override the default
identity-failure heuristic with `connect.MarkRendezvousSpent` or
`connect.MarkRendezvousRetryable`: spent consumes with the without-cancel budget,
retryable never consumes, and unknown keeps the heuristic. Authenticator values
that implement `connect.OneShotRendezvous` also trigger a bounded consume
attempt after post-success auth-context validation, channel, upgrade, or
nil-stream failure.
Pure cancellation, deadline, and relay I/O failures during unmarked identity
remain retryable. Malformed, cyclic, or traversal-truncated unmarked identity
error trees consume only when a non-I/O domain/authentication leaf is confirmed;
relay-only or ambiguous malformed trees remain retryable. Identity error
sanitization preserves `errors.Is` classification, but may omit `errors.As`
exposure of unsafe malformed concrete wrappers such as `*net.OpError` or
`*os.SyscallError`.
This unilateral consume attempt can leave a short re-pairing window until it
reaches the relay, and failed best-effort consume can also leave the SessionID
reusable until normal expiry. Identity/authentication failures, including
wrong-secret failures, should be returned as domain errors. Consume failures are
non-fatal and ignored by default; `WithConsumeSessionErrorHandler` exposes them
for logging or metrics. See the `Dial` godoc and PRD-0001 for the full consume
and retryability contract.

Private v0.3.0 is released with twelve public packages, including `selection`, `binding` and `discovery`. Every exported declaration in these packages and the `wiremux-server` CLI contract are protected by [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md), including the waiter-observation seam shipped in v0.1.1 ([#987](https://github.com/GridSwarm/wiremux/issues/987)), the QUIC keepalive/idle-timeout options shipped in v0.1.2 ([#1001](https://github.com/GridSwarm/wiremux/issues/1001)), the bounded probe-rerace correction shipped in v0.1.3 ([#1006](https://github.com/GridSwarm/wiremux/issues/1006)), the prior-pass probe-success settlement correction shipped in v0.1.4 ([#1134](https://github.com/GridSwarm/wiremux/issues/1134)), the additive opt-in TURN/UDP relay fallback (`WithTURN`, `connect/pionturn`, carrier topology, the exclusive `wiremux-quic/3` relay profile) shipped in v0.1.5 ([#1049](https://github.com/GridSwarm/wiremux/issues/1049), [#1051](https://github.com/GridSwarm/wiremux/issues/1051)), the relay proxy drain correction shipped in v0.1.6 ([#1286](https://github.com/GridSwarm/wiremux/issues/1286)), the relay shaping knobs, ACME options, and OOB-capable adapter shipped in v0.2.0 ([#1255](https://github.com/GridSwarm/wiremux/issues/1255), [#1251](https://github.com/GridSwarm/wiremux/issues/1251), [#1317](https://github.com/GridSwarm/wiremux/issues/1317)) under the three recorded v0.2.0 exceptions, the opt-in pprof flag plus the `channel.Receive` payload-lifetime exception shipped in v0.2.1, the additive managed and packet-I/O APIs shipped in v0.2.2, `ManagedWire.Datagrams` shipped in v0.2.3, managed migration plus selected-interface APIs shipped in v0.2.4, ordered selection shipped in v0.2.6, the binding, discovery, paired-relay and native APIs shipped in v0.2.7, and the native packet-I/O/snapshot and relay admission changes shipped in v0.3.0. Downstream stable-version migrations are handed to their owning repositories, live public-CA ACME validation is deferred to [#924](https://github.com/GridSwarm/wiremux/issues/924), and hosted-relay operation, a bundled or hosted TURN server, and operator packaging (container image, package-manager distribution) remain non-claims. The vision and v1 API surface are scoped in:

- [ADR-0001: Vision and Scope](docs/adr/adr-0001-vision-and-scope.md)
- [ADR-0008: Immediate Packet-Socket Ownership Transfer](docs/adr/adr-0008-immediate-packet-socket-ownership-transfer.md)
- [ADR-0009: Optional Carrier-Bound Datagram Capability](docs/adr/adr-0009-optional-datagram-capability.md)
- [PRD-0001: Connectivity Kernel](docs/prd/prd-0001-connectivity-kernel.md)

ADR-0009's optional Datagram APIs and `wiremux-quic/2` profile are implemented
for supporting direct carriers; relay and stream-only paths remain reliable-only.

## Start Here

- [AGENTS.md](AGENTS.md) has contributor and agent setup for this repository.
- [CONTEXT.md](CONTEXT.md) defines wiremux domain language for contributors and agents.
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) captures the current architecture state.
- [P02 fixed-peer evaluation](docs/research/p02-fixed-peer.md) records the decision to retain wiremux's wrapper and the bounded experimental evidence.
- [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) documents `wiremux-server` operator setup.
- [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md) defines the normative compatibility contract for the released v0.1.x, v0.2.x and v0.3.x lines.
- [`docs/NATIVE-THROUGHPUT.md`](docs/NATIVE-THROUGHPUT.md) states native Wire throughput targets, the processor headroom they assume and measured effects of a busy consumer.
- [docs/RELEASE.md](docs/RELEASE.md) records the current release record and downstream pinning order.
- [docs/release/](docs/release/) holds each release's reviewed narrative ([v0.1.0](docs/release/v0.1.0/notes.md), [v0.1.1](docs/release/v0.1.1/notes.md), [v0.1.2](docs/release/v0.1.2/notes.md), [v0.1.3](docs/release/v0.1.3/notes.md), [v0.1.4](docs/release/v0.1.4/notes.md), [v0.1.5](docs/release/v0.1.5/notes.md), [v0.1.6](docs/release/v0.1.6/notes.md), [v0.2.0](docs/release/v0.2.0/notes.md), [v0.2.1](docs/release/v0.2.1/notes.md), [v0.2.2](docs/release/v0.2.2/notes.md), [v0.2.3](docs/release/v0.2.3/notes.md), [v0.2.4](docs/release/v0.2.4/notes.md), [v0.2.5](docs/release/v0.2.5/notes.md), [v0.2.6](docs/release/v0.2.6/notes.md), [v0.2.7](docs/release/v0.2.7/notes.md), [v0.3.0](docs/release/v0.3.0/notes.md)).
- [docs/DEV-JOURNAL.md](docs/DEV-JOURNAL.md) records wiremux sessions.
- [memory/MEMORY.md](memory/MEMORY.md) is the project memory index.

## Consumer test support

Direct carriers may optionally expose unreliable-unordered atomic Datagrams.
Discover the borrowed handle on each established Wire and size complete
messages against its fixed ceiling:

```go
if datagrams, ok := wire.Datagrams(); ok && len(record) <= datagrams.MaxPayload() {
	if err := datagrams.Send(ctx, record); err != nil {
		// Handle local cancellation, ErrDatagramTooLarge, or aggregate teardown.
	}
}
```

`Send` copies on admission; success does not mean the message reached the
socket or peer. The handle has no `Close` because `Wire.Close` owns both planes.
Reliable `Read` and `Write` remain available whether the capability is present
or absent. Transport authors can run the capable, absence, and malformed
production-Wire conformance runners in `wiremuxtest`; non-observable security,
path-binding, retransmission, and congestion properties still require a
transport evidence record.

`github.com/GridSwarm/wiremux/wiremuxtest` owns identity-agnostic connectivity
test support. It starts only a loopback, TLS 1.3, ephemeral relay and keeps its
private trust material fixture-scoped. The returned URL and fresh
`[]wiremux.Option` values remain usable until registered fixture cleanup. Raw
streams and Wires remain open on whole success and have automatic plus explicit
idempotent cleanup.

This lower-level example is compiled and exercised by
`TestREADMEWiremuxtestExample`:

```go
func TestIdentityOverRealRelay(t *testing.T) {
	env := wiremuxtest.StartRelay(t)
	sid := relay.SessionID{0x01, 0x02, 0x03, 0x04}

	streams := env.PairStreams(t, sid)
	// Run the consumer-owned identity protocol over streams.Host and
	// streams.Client. Successful streams remain open until Close or test cleanup.

	env.ConsumeSession(t, sid)
	env.RequireSessionConsumed(t, sid)
	streams.Close()
}
```

`ConsumeSession` and `RequireSessionConsumed` prove physical relay state; they
do not classify identity or muxcode spending. Codemux-specific orchestration
belongs to `codemuxtest`. The ownership rationale and landing order are
canonical in
[codemux ADR-0006](https://github.com/GridSwarm/codemux/blob/main/docs/adr/adr-0006-public-test-support-ownership.md).
Call `ConsumeSession` while the relay session is still paired, before closing
either stream or Wire. Repeating it succeeds only while the relay retains the
consumed tombstone, normally for the configured ephemeral-expiry window.
`RequireSessionConsumed` performs one real rendezvous Dial, so do not run it
concurrently with another dialer using the same Session ID.

## Position in the GridSwarm family

```
                          meshmux  (deferred)
                             │
                             ▼
                          keymux   (deferred-implementation)
                             │
                  ┌──────────┴──────────┐
codemux  ─────────┤                     │
                  ▼                     ▼
                          wiremux  ←  YOU ARE HERE
                             │
                             ▼
                  pluggable transport (default QUIC)
```

See the [GridSwarm family ADR](https://github.com/GridSwarm/org-docs/blob/main/docs/decisions/adr-0001-four-product-family.md) for the full taxonomy.

### Explicit QUIC controller selection

The forthcoming v0.3.1 adds supported per-endpoint Reno/BBRv3 configuration for native and upgraded QUIC connections, preserving existing Reno defaults. [Exact configuration and GridCast adoption](docs/QUIC-CONTROLLERS.md) cover initial, Resume and secondary paths, conservative ACK policy at both peers, explicit fast.9 application replacement and capability failures. BBR remains experimental and unqualified for production performance. Publication state is recorded in [release status](docs/RELEASE.md).
