package wiremux

import (
	"context"
	"errors"
	"io"
	"sync"

	"github.com/GridSwarm/wiremux/connect"
)

var (
	// ErrNilAuthenticator reports Dial without an identity handshake.
	ErrNilAuthenticator = errors.New("wiremux: authenticator is nil")

	// ErrAuthContextReused reports a second StaticAuth use.
	ErrAuthContextReused = errors.New("wiremux: auth context already used")
)

// Authenticator turns a paired relay stream into the auth context used by the
// encrypted channel and direct-upgrade negotiator. Implementations must honor
// ctx for non-I/O work; Dial wakes relayConn I/O when the establishment context
// expires and closes relayConn during cleanup. A nil error must be accompanied
// by a non-nil AuthContext.
//
// Every non-nil AuthContext result transfers exclusively to the caller,
// including a partial context returned with an error. When Dial is the caller,
// it owns that result immediately, defensively releases partial and failed
// results, and transfers successful ownership to the returned Wire. An
// implementation must not retain, reuse, or schedule cleanup of a transferred
// context. Release-capable contexts implement connect.AuthContextReleaser;
// claim-enforcing contexts implement connect.ChannelUseClaimer. Decorators that
// preserve key authority must deliberately forward both optional capabilities.
//
// One-shot rendezvous schemes may use connect.MarkRendezvousSpent,
// connect.MarkRendezvousRetryable, and connect.OneShotRendezvous to declare
// rendezvous disposition without changing this interface. For ephemeral
// SessionID rendezvous, Dial consumes marked-spent identity failures, leaves
// marked-retryable identity failures reusable, and attempts best-effort consume
// after post-success auth-context validation, channel setup, upgrade, or
// nil-stream failures for authenticators that satisfy connect.OneShotRendezvous.
// A one-shot authenticator that returns a nil AuthContext with a nil error has
// violated the result contract after signaling success; Dial marks the
// ErrNilAuthContext failure spent and attempts best-effort consumption.
// If context cancellation or deadline expiry is observed after a non-one-shot
// authenticator returns (nil, nil), Dial reports both the context error and
// ErrNilAuthContext while leaving the rendezvous disposition unknown and the
// SessionID reusable.
// Authenticator decorators and adapters that wrap a one-shot scheme must forward
// connect.OneShotRendezvous so the consume policy can observe it.
type Authenticator interface {
	Authenticate(ctx context.Context, relayConn io.ReadWriteCloser) (connect.AuthContext, error)
}

// AuthenticatorFunc adapts a function to Authenticator.
//
// AuthenticatorFunc does not implement the optional connect.OneShotRendezvous
// capability, and callers cannot add methods to it, so wrapping a one-shot
// authenticator in an AuthenticatorFunc closure drops post-success one-shot
// SessionID consume. Failure-side disposition markers still work: errors
// returned from the function may carry connect.MarkRendezvousSpent or
// connect.MarkRendezvousRetryable and the ephemeral SessionID consume policy
// honors them.
// One-shot schemes that need post-success consume use a named authenticator
// type implementing both interfaces; decorators must be named wrapper types
// that forward connect.OneShotRendezvous by delegating SuccessSpendsRendezvous
// to the wrapped authenticator.
type AuthenticatorFunc func(context.Context, io.ReadWriteCloser) (connect.AuthContext, error)

// Authenticate calls f.
func (f AuthenticatorFunc) Authenticate(ctx context.Context, relayConn io.ReadWriteCloser) (connect.AuthContext, error) {
	if f == nil {
		return nil, ErrNilAuthenticator
	}
	return f(ctx, relayConn)
}

type staticAuthenticator struct {
	mu   sync.Mutex
	auth connect.AuthContext
	used bool
}

// StaticAuth returns an authenticator for callers that already have a complete
// AuthContext. The returned authenticator is single-use and returns that
// context at most once, preventing accidental reuse through a repeated Dial with the
// same authenticator. Callers must not create multiple StaticAuth wrappers for
// the same AuthContext or key material, because channel nonces start at zero.
// Constructing StaticAuth does not transfer ownership. Once Authenticate
// returns a non-nil context, its direct caller owns that context; when used with
// Dial, callers must stop all use and cleanup as soon as authentication returns
// it and leave release to Dial or the resulting Wire.
func StaticAuth(auth connect.AuthContext) Authenticator {
	return &staticAuthenticator{auth: auth}
}

func (a *staticAuthenticator) Authenticate(context.Context, io.ReadWriteCloser) (connect.AuthContext, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.used {
		return nil, ErrAuthContextReused
	}
	if a.auth == nil {
		return nil, connect.ErrNilAuthContext
	}
	a.used = true
	auth := a.auth
	a.auth = nil
	return auth, nil
}
