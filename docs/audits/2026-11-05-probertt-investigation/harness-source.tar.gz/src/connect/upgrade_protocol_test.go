package connect

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net/netip"
	"slices"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func nextDirectUpgradeDialerPhaseTransition(
	cursor *directUpgradeProtocolCursor,
) (directUpgradeProtocolTransition, bool) {
	if cursor.role != upgradeRoleDial {
		return directUpgradeProtocolTransition{}, false
	}
	return nextDirectUpgradePhaseTransition(cursor)
}

func nextDirectUpgradeDialerTransition(row directUpgradeDialerRow) (directUpgradeProtocolTransition, bool) {
	for _, transition := range directUpgradeProtocolTransitions {
		if transition.role == upgradeRoleDial && transition.dialerRow == row {
			return transition, true
		}
	}
	return directUpgradeProtocolTransition{}, false
}

func TestDialerEngineBranchMatrix(t *testing.T) {
	tests := []struct {
		name string
		row  directUpgradeDialerRow
		want directUpgradeProtocolAction
	}{
		{
			name: "selected_encode_failure",
			row:  directUpgradeDialerRowD01,
			want: directUpgradeProtocolAction{
				kind:           directUpgradeProtocolActionCoordinateFallback,
				fallback:       directUpgradeFallbackWithSession,
				fallbackReason: UpgradeFallbackTransportFailed,
			},
		},
		{
			name: "selected_write_failure",
			row:  directUpgradeDialerRowD02,
			want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortBeforeOwnedResources},
		},
		{
			name: "ready_timeout",
			row:  directUpgradeDialerRowD03,
			want: directUpgradeProtocolAction{
				kind:           directUpgradeProtocolActionCoordinateFallback,
				fallback:       directUpgradeFallbackSkippingReady,
				fallbackReason: UpgradeFallbackTransportFailed,
			},
		},
		{
			name: "ready_control_error",
			row:  directUpgradeDialerRowD04,
			want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortBeforeOwnedResources},
		},
		{
			name: "ready_peer_fallback",
			row:  directUpgradeDialerRowD05,
			want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionCoordinateFallback, fallback: directUpgradeFallbackWithPeer},
		},
		{
			name: "ready_phase_mismatch",
			row:  directUpgradeDialerRowD06,
			want: directUpgradeProtocolAction{
				kind:           directUpgradeProtocolActionCoordinateFallback,
				fallback:       directUpgradeFallbackWithSession,
				fallbackReason: UpgradeFallbackProtocolMismatch,
			},
		},
		{
			name: "commit_encode_failure",
			row:  directUpgradeDialerRowD07,
			want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: retainForOuterSettlement},
		},
		{
			name: "commit_write_failure",
			row:  directUpgradeDialerRowD08,
			want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortBeforeOwnedResources},
		},
		{
			name: "commit_success_registers_dial",
			row:  directUpgradeDialerRowD09,
			want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionCommitAndStartDial},
		},
		{name: "dial_success_or_completed_success", row: directUpgradeDialerRowD10, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionObserveDial}},
		{name: "dial_stream_with_error", row: directUpgradeDialerRowD11M, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "dial_datagram_validation_error", row: directUpgradeDialerRowD11V, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "dial_error_or_completed_error", row: directUpgradeDialerRowD11, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "dial_nil_stream_or_completed_nil", row: directUpgradeDialerRowD12, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "cancel_materialized", row: directUpgradeDialerRowD13M, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "cancel_pending_failure", row: directUpgradeDialerRowD13F, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "cancel_pending_success", row: directUpgradeDialerRowD13S, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "cancel_pending_stream_error", row: directUpgradeDialerRowD13E, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "budget_materialized", row: directUpgradeDialerRowD14M, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "budget_pending_failure", row: directUpgradeDialerRowD14F, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "budget_pending_success", row: directUpgradeDialerRowD14S, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "budget_pending_stream_error", row: directUpgradeDialerRowD14E, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "send_failure_materialized", row: directUpgradeDialerRowD15M, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "send_failure_pending_failure", row: directUpgradeDialerRowD15F, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "send_failure_pending_success", row: directUpgradeDialerRowD15S, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "send_failure_pending_stream_error", row: directUpgradeDialerRowD15E, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "read_failure_materialized", row: directUpgradeDialerRowD16M, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "read_failure_pending_failure", row: directUpgradeDialerRowD16F, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "read_failure_pending_success", row: directUpgradeDialerRowD16S, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "read_failure_pending_stream_error", row: directUpgradeDialerRowD16E, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "wrong_phase_materialized", row: directUpgradeDialerRowD17M, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "wrong_phase_pending_failure", row: directUpgradeDialerRowD17F, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "wrong_phase_pending_success", row: directUpgradeDialerRowD17S, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "wrong_phase_pending_stream_error", row: directUpgradeDialerRowD17E, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "accepted_frame_completed_or_ordinary", row: directUpgradeDialerRowD18, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionRecordAccepted}},
		{name: "converged_datagram_agreement_completed_or_ordinary", row: directUpgradeDialerRowD19, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionSendConverged}},
		{name: "datagram_mismatch", row: directUpgradeDialerRowD20, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "completed_confirmed_wins", row: directUpgradeDialerRowD21, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionSucceedDirect}},
		{name: "ordinary_confirmed_path", row: directUpgradeDialerRowD22, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionSucceedDirect}},
		{name: "unexpected_materialized", row: directUpgradeDialerRowD23M, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "unexpected_pending_failure", row: directUpgradeDialerRowD23F, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "unexpected_pending_success", row: directUpgradeDialerRowD23S, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
		{name: "unexpected_pending_stream_error", row: directUpgradeDialerRowD23E, want: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}},
	}
	if len(tests) != 43 {
		t.Fatalf("dialer primary cases = %d, want 43", len(tests))
	}
	seenRows := make(map[directUpgradeDialerRow]bool, len(tests))
	for _, transition := range directUpgradeProtocolTransitions {
		if transition.dialerRow == "" {
			continue
		}
		if seenRows[transition.dialerRow] {
			t.Fatalf("duplicate dialer row %s", transition.dialerRow)
		}
		seenRows[transition.dialerRow] = true
	}
	if len(seenRows) != len(tests) {
		t.Fatalf("dialer transition rows = %d, want exactly %d", len(seenRows), len(tests))
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			transition, ok := nextDirectUpgradeDialerTransition(test.row)
			if !ok {
				t.Fatalf("dialer row %s is missing", test.row)
			}
			if transition.action != test.want {
				t.Fatalf("dialer row %s action = %#v, want %#v", test.row, transition.action, test.want)
			}
			exerciseDialerEngineRow(t, transition)
		})
	}
}

func TestDialerEngineTerminalActionOutcomes(t *testing.T) {
	for _, transition := range directUpgradeProtocolTransitions {
		if transition.role != upgradeRoleDial || transition.dialerRow == "" {
			continue
		}
		switch transition.action.kind {
		case directUpgradeProtocolActionCoordinateFallback:
			t.Run(string(transition.dialerRow), func(t *testing.T) {
				exerciseDialerFallbackOutcome(t, transition)
			})
		case directUpgradeProtocolActionFailClosed:
			t.Run(string(transition.dialerRow), func(t *testing.T) {
				exerciseDialerEngineRow(t, transition)
			})
		default:
			// Only the two terminal actions have outcome rows to exercise here.
		}
	}
}

func exerciseDialerFallbackOutcome(t *testing.T, transition directUpgradeProtocolTransition) {
	t.Helper()
	reason := transition.action.fallbackReason
	if reason == UpgradeFallbackNone {
		reason = UpgradeFallbackTransportFailed
	}
	peerFrame, err := encodeUpgradeControlFallback(reason)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	channel := newScriptedControlChannel(peerFrame, false)
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:41501")}}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg:           upgradeConfig{packetConn: packetConn, controlTimeout: time.Second},
	})
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, concreteDialerStateForTest(transition.from))
	engine := directUpgradeProtocolEngine{
		role:    upgradeRoleDial,
		attempt: attempt,
		session: &terminalTestSession{},
		cursor:  &cursor,
	}
	input := directUpgradeProtocolActionInput{
		fallbackReason: reason,
		peerFallback: &terminalFallbackReadResult{
			peer: upgradeControlFallback{Reason: reason},
		},
	}
	if transition.action.fallback != directUpgradeFallbackWithPeer {
		input.peerFallback = nil
	}
	outcome := engine.dispatchDialerEvent(context.Background(), transition.event, input, &directUpgradeProtocolRuntime{})
	if !outcome.terminal || outcome.err != nil {
		t.Fatalf("fallback outcome = terminal %v, error %v", outcome.terminal, outcome.err)
	}
	if outcome.result.Path != UpgradePathRelay || outcome.result.FallbackReason != reason {
		t.Fatalf("fallback result = path %q, reason %q; want relay and %q", outcome.result.Path, outcome.result.FallbackReason, reason)
	}
	attempt.resources().mu.Lock()
	disposition := attempt.resources().terminalDisposition
	attempt.resources().mu.Unlock()
	if disposition != attemptTerminalSettleRelay {
		t.Fatalf("fallback disposition = %v, want settle-relay", disposition)
	}
	if outcome.result.Stream != nil {
		_ = outcome.result.Stream.Close()
	}
}

func exerciseDialerEngineRow(t *testing.T, transition directUpgradeProtocolTransition) {
	t.Helper()
	channel := &terminalTestChannel{}
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:41001")}}
	session := &terminalTestSession{dialErr: errors.New("matrix Dial failure")}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			controlTimeout: 20 * time.Millisecond,
		},
	})
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, concreteDialerStateForTest(transition.from))
	observed := make([]directUpgradeDialerRow, 0, 1)
	engine := directUpgradeProtocolEngine{
		role:          upgradeRoleDial,
		attempt:       attempt,
		session:       session,
		peer:          localUpgradeOffer{handshakeMaterial: []byte("matrix-peer-material")},
		localProbeRTT: time.Millisecond,
		selected: selectedPair{
			dialer:   Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:41001")},
			listener: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:41002")},
		},
		cursor: &cursor,
		testDialerTrace: func(row directUpgradeDialerRow) {
			observed = append(observed, row)
		},
	}
	runtime := directUpgradeProtocolRuntime{postCommitCtx: context.Background()}
	operationCause := errors.New("matrix operation failure")
	transport := dialerRowTransportForTest(transition.dialerRow, packetConn, operationCause)
	pending := dialerRowHasPendingOwnerForTest(transition.dialerRow)
	completed := dialerRowHasCompletedOwnerForTest(transition.dialerRow)
	var pendingOperation *ownedDialOperation
	if pending {
		pendingOperation = seedPendingDialerOwnerForTest(attempt.resources(), session)
	} else if completed {
		seedCompletedDialerOwnerForTest(attempt.resources(), session, transport)
		runtime.transport = transport
		runtime.transportReady = true
	}
	input := directUpgradeProtocolActionInput{
		cause:          operationCause,
		fallbackReason: UpgradeFallbackTransportFailed,
		peerFallback: &terminalFallbackReadResult{
			peer: upgradeControlFallback{Reason: UpgradeFallbackTransportFailed},
		},
		transport:     transport,
		peerDatagrams: transition.dialerRow == directUpgradeDialerRowD18,
	}
	dispatch := func() directUpgradeProtocolDispatchResult {
		return engine.dispatchDialerEvent(
			context.Background(),
			transition.event,
			input,
			&runtime,
		)
	}
	var outcome directUpgradeProtocolDispatchResult
	if pending {
		done := make(chan directUpgradeProtocolDispatchResult, 1)
		go func() { done <- dispatch() }()
		waitForTerminalSeal(t, attempt.resources())
		publishPendingDialerResultForTest(attempt.resources(), pendingOperation, transport)
		outcome = <-done
	} else {
		outcome = dispatch()
	}
	if len(observed) != 1 || observed[0] != transition.dialerRow {
		t.Fatalf("managed dispatch trace = %v, want exactly %s", observed, transition.dialerRow)
	}
	wantTerminal := transition.action.kind == directUpgradeProtocolActionCoordinateFallback ||
		transition.action.kind == directUpgradeProtocolActionFailClosed ||
		transition.action.kind == directUpgradeProtocolActionSucceedDirect
	if outcome.terminal != wantTerminal {
		t.Fatalf("managed dispatch terminal = %v, want %v", outcome.terminal, wantTerminal)
	}
	if !wantTerminal && outcome.err != nil {
		t.Fatalf("managed continuation error = %v", outcome.err)
	}
	if transition.action.kind == directUpgradeProtocolActionFailClosed {
		if !errors.Is(outcome.err, operationCause) {
			t.Fatalf("fail-closed error = %v, want exact operation cause", outcome.err)
		}
		if attempt.resources().packetOwnershipTransferred() && !errors.Is(outcome.err, ErrUpgradeTransportNotConverged) {
			t.Fatalf("owned fail-closed error = %v, want transport-not-converged", outcome.err)
		}
		attempt.resources().mu.Lock()
		disposition := attempt.resources().terminalDisposition
		control := attempt.resources().terminalControl
		attempt.resources().mu.Unlock()
		if disposition != attemptTerminalFailClosed || control != transition.action.control {
			t.Fatalf("fail-closed terminal state = disposition %v, control %v; want %v and %v", disposition, control, attemptTerminalFailClosed, transition.action.control)
		}
	}
	if transition.action.kind == directUpgradeProtocolActionObserveDial &&
		(!runtime.transportReady || runtime.transport.stream != transport.stream) {
		t.Fatal("D10 did not record the exact materialized Dial result")
	}
	if transition.action.kind == directUpgradeProtocolActionRecordAccepted && !runtime.peerDatagrams {
		t.Fatal("D18 did not record the peer Datagram capability")
	}
	if transition.action.kind == directUpgradeProtocolActionCommitAndStartDial {
		snapshot := attempt.resources().snapshot()
		if !snapshot.committed || snapshot.dial == attemptOperationUnregistered || runtime.transportCh == nil {
			t.Fatalf("D09 owner state = committed %v, Dial %v, channel nil %v", snapshot.committed, snapshot.dial, runtime.transportCh == nil)
		}
	}
	if transition.action.kind == directUpgradeProtocolActionSendConverged &&
		cursor.state != directUpgradeProtocolStatePostCommitConverged {
		t.Fatalf("D19 cursor state = %v, want converged", cursor.state)
	}
	if transition.action.kind == directUpgradeProtocolActionSucceedDirect && outcome.result.Stream != nil {
		_ = outcome.result.Stream.Close()
	}
	if runtime.postCommitCancel != nil {
		runtime.postCommitCancel()
	}
	if !outcome.terminal && attempt.resources().snapshot().dial != attemptOperationUnregistered {
		_, _ = attempt.resources().failClosed(operationCause, abortAfterOwnedResources)
	}
}

func concreteDialerStateForTest(state directUpgradeProtocolState) directUpgradeProtocolState {
	switch state {
	case directUpgradeProtocolStateDialerPostCommit,
		directUpgradeProtocolStateDialerPostCommitBeforeConverged,
		directUpgradeProtocolStateDialerPostCommitAwaitingFrame:
		return directUpgradeProtocolStatePostCommitStart
	default:
		return state
	}
}

func dialerRowTransportForTest(
	row directUpgradeDialerRow,
	packetConn *terminalTestPacketConn,
	operationCause error,
) postCommitTransportResult {
	stream := &terminalTestStream{packetConn: packetConn}
	switch row {
	case directUpgradeDialerRowD11,
		directUpgradeDialerRowD13F,
		directUpgradeDialerRowD14F,
		directUpgradeDialerRowD15F,
		directUpgradeDialerRowD16F,
		directUpgradeDialerRowD17F,
		directUpgradeDialerRowD23F:
		return postCommitTransportResult{err: operationCause}
	case directUpgradeDialerRowD12:
		return postCommitTransportResult{}
	case directUpgradeDialerRowD11M,
		directUpgradeDialerRowD13E,
		directUpgradeDialerRowD14E,
		directUpgradeDialerRowD15E,
		directUpgradeDialerRowD16E,
		directUpgradeDialerRowD17E,
		directUpgradeDialerRowD23E:
		return postCommitTransportResult{stream: stream, err: operationCause}
	case directUpgradeDialerRowD11V:
		return postCommitTransportResult{stream: stream, err: operationCause, datagramCarrierValidationErr: true}
	default:
		return postCommitTransportResult{stream: stream}
	}
}

func dialerRowHasPendingOwnerForTest(row directUpgradeDialerRow) bool {
	switch row {
	case directUpgradeDialerRowD13F, directUpgradeDialerRowD13S, directUpgradeDialerRowD13E,
		directUpgradeDialerRowD14F, directUpgradeDialerRowD14S, directUpgradeDialerRowD14E,
		directUpgradeDialerRowD15F, directUpgradeDialerRowD15S, directUpgradeDialerRowD15E,
		directUpgradeDialerRowD16F, directUpgradeDialerRowD16S, directUpgradeDialerRowD16E,
		directUpgradeDialerRowD17F, directUpgradeDialerRowD17S, directUpgradeDialerRowD17E,
		directUpgradeDialerRowD23F, directUpgradeDialerRowD23S, directUpgradeDialerRowD23E:
		return true
	default:
		return false
	}
}

func dialerRowHasCompletedOwnerForTest(row directUpgradeDialerRow) bool {
	switch row {
	case directUpgradeDialerRowD10,
		directUpgradeDialerRowD11M, directUpgradeDialerRowD11V, directUpgradeDialerRowD11, directUpgradeDialerRowD12,
		directUpgradeDialerRowD13M, directUpgradeDialerRowD14M, directUpgradeDialerRowD15M,
		directUpgradeDialerRowD16M, directUpgradeDialerRowD17M,
		directUpgradeDialerRowD19, directUpgradeDialerRowD20,
		directUpgradeDialerRowD21, directUpgradeDialerRowD22, directUpgradeDialerRowD23M:
		return true
	default:
		return false
	}
}

func seedPendingDialerOwnerForTest(
	owner *attemptResources,
	session Session,
) *ownedDialOperation {
	owner.registerSession(session)
	owner.registerCommit()
	operation := &ownedDialOperation{
		cancel: func() {},
		ready:  make(chan struct{}),
		done:   make(chan transportStreamResult, 1),
	}
	owner.mu.Lock()
	owner.dial = operation
	owner.dialState = attemptOperationRunning
	owner.mu.Unlock()
	return operation
}

func publishPendingDialerResultForTest(
	owner *attemptResources,
	operation *ownedDialOperation,
	result postCommitTransportResult,
) {
	owner.mu.Lock()
	operation.result = result
	if result.stream != nil {
		owner.stream = result.stream
	}
	owner.recordTransportResultLocked(result)
	owner.dialState = attemptOperationComplete
	owner.mu.Unlock()
	close(operation.ready)
}

func seedCompletedDialerOwnerForTest(
	owner *attemptResources,
	session Session,
	result postCommitTransportResult,
) {
	owner.registerSession(session)
	owner.registerCommit()
	ready := make(chan struct{})
	close(ready)
	operation := &ownedDialOperation{
		cancel: func() {},
		ready:  ready,
		done:   make(chan transportStreamResult, 1),
		result: result,
	}
	owner.mu.Lock()
	owner.dial = operation
	owner.dialState = attemptOperationComplete
	if result.stream != nil {
		owner.stream = result.stream
	}
	owner.recordTransportResultLocked(result)
	owner.mu.Unlock()
}

func TestDialerEngineD09MutationCannotPublishCommit(t *testing.T) {
	index := -1
	for i := range directUpgradeProtocolTransitions {
		if directUpgradeProtocolTransitions[i].dialerRow == directUpgradeDialerRowD09 {
			index = i
			break
		}
	}
	if index < 0 {
		t.Fatal("D09 transition is missing")
	}
	original := directUpgradeProtocolTransitions[index]
	directUpgradeProtocolTransitions[index].action = directUpgradeProtocolAction{}
	t.Cleanup(func() { directUpgradeProtocolTransitions[index] = original })

	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode Ready: %v", err)
	}
	channel := newScriptedControlChannel(readyFrame, false)
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:42001")}}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			controlTimeout: time.Second,
		},
	})
	probeResult := candidatePairProbeResult{
		succeeded: true,
		pair: probeCandidatePair{
			local:  Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:42001")},
			remote: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:42002")},
		},
	}
	engine := newDialerDirectUpgradeProtocolEngine(
		attempt,
		&terminalTestSession{},
		localUpgradeOffer{handshakeMaterial: []byte("mutation-peer-material")},
		probeResult,
	)
	_, err = engine.runDialer(context.Background(), context.Background())
	if !errors.Is(err, errUnexpectedPostCommitPhaseOrder) {
		t.Fatalf("runDialer error = %v, want internal transition failure", err)
	}
	snapshot := attempt.resources().snapshot()
	if snapshot.committed || snapshot.dial != attemptOperationUnregistered {
		t.Fatalf("mutated D09 published owner state: committed %v, Dial %v", snapshot.committed, snapshot.dial)
	}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selectedPairFromProbeResult(probeResult))
	if err != nil {
		t.Fatalf("encode Selected: %v", err)
	}
	channel.mu.Lock()
	written := append([]byte(nil), channel.writes.Bytes()...)
	channel.mu.Unlock()
	if !bytes.Equal(written, selectedFrame) {
		t.Fatalf("published control bytes = %x, want only Selected %x", written, selectedFrame)
	}
	attempt.resources().mu.Lock()
	disposition := attempt.resources().terminalDisposition
	attempt.resources().mu.Unlock()
	if disposition != attemptTerminalFailClosed {
		t.Fatalf("terminal disposition = %v, want one table-selected fail-closed", disposition)
	}
}

func TestDialerEngineReadyTimeoutSkipsLateReady(t *testing.T) {
	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode late Ready: %v", err)
	}
	fallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	release := make(chan struct{})
	channel := newReleasedReadControlChannel(append(readyFrame, fallbackFrame...), release)
	writes := make(chan struct{}, 2)
	channel.observeWrite = func([]byte, int, error) { writes <- struct{}{} }
	go func() {
		<-writes
		<-writes
		close(release)
	}()
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:42501")}}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			controlTimeout: 20 * time.Millisecond,
		},
	})
	probeResult := candidatePairProbeResult{
		succeeded: true,
		pair: probeCandidatePair{
			local:  Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:42501")},
			remote: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:42502")},
		},
	}
	trace := make([]directUpgradeDialerRow, 0, 1)
	engine := newDialerDirectUpgradeProtocolEngine(
		attempt,
		&terminalTestSession{},
		localUpgradeOffer{handshakeMaterial: []byte("late-ready-peer-material")},
		probeResult,
	)
	engine.testDialerTrace = func(row directUpgradeDialerRow) { trace = append(trace, row) }

	result, err := engine.runDialer(context.Background(), context.Background())
	if err != nil {
		t.Fatalf("runDialer after late Ready: %v", err)
	}
	if result.Path != UpgradePathRelay || result.FallbackReason != UpgradeFallbackTransportFailed {
		t.Fatalf("late-Ready result = path %q, reason %q; want relay transport-failed", result.Path, result.FallbackReason)
	}
	if !slices.Equal(trace, []directUpgradeDialerRow{directUpgradeDialerRowD03}) {
		t.Fatalf("late-Ready trace = %v, want exactly D03", trace)
	}
	if result.Stream != nil {
		_ = result.Stream.Close()
	}
}

func TestDialerEngineCompletedBoundaryPreference(t *testing.T) {
	newEngine := func(
		t *testing.T,
		channel io.ReadWriteCloser,
		state directUpgradeProtocolState,
	) (directUpgradeProtocolEngine, *attemptResources, *terminalTestPacketConn, *[]directUpgradeDialerRow) {
		t.Helper()
		packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:43001")}}
		attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
			channel:       channel,
			controlFrames: newControlFrameSequencer(channel),
			cfg: upgradeConfig{
				packetConn:     packetConn,
				controlTimeout: time.Second,
			},
		})
		cursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, state)
		trace := make([]directUpgradeDialerRow, 0, 3)
		engine := directUpgradeProtocolEngine{
			role:          upgradeRoleDial,
			attempt:       attempt,
			session:       &terminalTestSession{},
			localProbeRTT: time.Millisecond,
			selected: selectedPair{
				dialer:   Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:43001")},
				listener: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:43002")},
			},
			cursor:          &cursor,
			testDialerTrace: func(row directUpgradeDialerRow) { trace = append(trace, row) },
		}
		return engine, attempt.resources(), packetConn, &trace
	}

	t.Run("completed Dial result precedes cancellation classification", func(t *testing.T) {
		channel := &terminalTestChannel{}
		engine, owner, packetConn, trace := newEngine(t, channel, directUpgradeProtocolStatePostCommitStart)
		stream := &terminalTestStream{packetConn: packetConn}
		transport := postCommitTransportResult{stream: stream}
		seedCompletedDialerOwnerForTest(owner, engine.session, transport)
		transportCh := make(chan postCommitTransportResult, 1)
		transportCh <- transport
		callerCtx, cancelCaller := context.WithCancel(context.Background())
		cancelCaller()
		runtime := directUpgradeProtocolRuntime{postCommitCtx: context.Background(), transportCh: transportCh}
		engine.runtime = &runtime
		_, err := engine.run(runtime.postCommitCtx, callerCtx)
		if !errors.Is(err, context.Canceled) || !errors.Is(err, ErrUpgradeTransportNotConverged) {
			t.Fatalf("completed Dial race error = %v, want canceled transport failure", err)
		}
		want := []directUpgradeDialerRow{directUpgradeDialerRowD10, directUpgradeDialerRowD13M}
		if !slices.Equal(*trace, want) {
			t.Fatalf("completed Dial trace = %v, want %v", *trace, want)
		}
	})

	t.Run("buffered Accepted frame is admitted at cancellation", func(t *testing.T) {
		channel := &terminalTestChannel{}
		engine, _, _, trace := newEngine(t, channel, directUpgradeProtocolStatePostCommitStart)
		callerCtx, cancelCaller := context.WithCancel(context.Background())
		cancelCaller()
		postCommitCtx, cancelPostCommit := context.WithCancel(context.Background())
		cancelPostCommit()
		runtime := directUpgradeProtocolRuntime{postCommitCtx: postCommitCtx}
		done := make(chan controlFrameReadResult, 1)
		done <- controlFrameReadResult{payload: postCommitPhasePayload(t, upgradeControlPhaseAccepted)}
		frame, completed, outcome, terminal := engine.awaitEnginePhaseFromDone(callerCtx, &runtime, done)
		if terminal || outcome.err != nil || !completed {
			t.Fatalf("Accepted completion = terminal %v, completed %v, error %v", terminal, completed, outcome.err)
		}
		phase, _ := decodeUpgradeControlPhasePayload(frame.payload, upgradeControlPhaseAccepted)
		transition, ok := nextDirectUpgradeDialerPhaseTransition(engine.cursor)
		if !ok {
			t.Fatal("Accepted transition is missing")
		}
		outcome = engine.executeDialerTransition(callerCtx, transition, directUpgradeProtocolActionInput{peerDatagrams: phase.Datagrams}, &runtime)
		if outcome.err != nil || !slices.Equal(*trace, []directUpgradeDialerRow{directUpgradeDialerRowD18}) {
			t.Fatalf("Accepted dispatch = trace %v, error %v", *trace, outcome.err)
		}
	})

	t.Run("successful Converged send precedes cancellation", func(t *testing.T) {
		callerCtx, cancelCaller := context.WithCancel(context.Background())
		channel := newScriptedControlChannel(nil, false)
		channel.writeScript = func(p []byte) (int, error) {
			cancelCaller()
			return len(p), nil
		}
		engine, owner, packetConn, trace := newEngine(t, channel, directUpgradeProtocolStatePostCommitAccepted)
		stream := &terminalTestStream{packetConn: packetConn}
		transport := postCommitTransportResult{stream: stream}
		seedCompletedDialerOwnerForTest(owner, engine.session, transport)
		runtime := directUpgradeProtocolRuntime{
			postCommitCtx:   callerCtx,
			transport:       transport,
			transportReady:  true,
			peerDatagrams:   false,
			datagramsAgreed: false,
		}
		transition, ok := nextDirectUpgradeDialerPhaseTransition(engine.cursor)
		if !ok {
			t.Fatal("Converged transition is missing")
		}
		outcome := engine.executeDialerTransition(callerCtx, transition, directUpgradeProtocolActionInput{}, &runtime)
		if outcome.err != nil || callerCtx.Err() == nil {
			t.Fatalf("Converged dispatch error = %v, context error = %v", outcome.err, callerCtx.Err())
		}
		engine.runtime = &runtime
		_, err := engine.run(runtime.postCommitCtx, callerCtx)
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("post-Converged error = %v, want cancellation", err)
		}
		want := []directUpgradeDialerRow{directUpgradeDialerRowD19, directUpgradeDialerRowD13M}
		if !slices.Equal(*trace, want) {
			t.Fatalf("Converged completion trace = %v, want %v", *trace, want)
		}
	})

	t.Run("blocked Converged send does not join without bound", func(t *testing.T) {
		writeGate := newUncancelableScriptedOperationGate()
		channel := newScriptedControlChannel(nil, false)
		channel.writeGate = writeGate
		channel.writeScript = func(p []byte) (int, error) { return len(p), nil }
		ctx, cancel := context.WithCancel(context.Background())
		attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel})
		engine := directUpgradeProtocolEngine{attempt: attempt}
		done := make(chan error, 1)
		go func() {
			done <- engine.sendPostCommit(ctx, upgradeControlPhaseConverged, false)
		}()
		writeGate.waitStarted(t)
		cancel()
		select {
		case err := <-done:
			if !errors.Is(err, context.Canceled) {
				t.Fatalf("blocked Converged send error = %v, want cancellation", err)
			}
		case <-time.After(time.Second):
			t.Fatal("blocked Converged send joined the writer without bound")
		}
		writeGate.release()
	})

	t.Run("buffered Confirmed frame wins cancellation", func(t *testing.T) {
		channel := &terminalTestChannel{}
		engine, owner, packetConn, trace := newEngine(t, channel, directUpgradeProtocolStatePostCommitConverged)
		stream := &terminalTestStream{packetConn: packetConn}
		transport := postCommitTransportResult{stream: stream}
		seedCompletedDialerOwnerForTest(owner, engine.session, transport)
		callerCtx, cancelCaller := context.WithCancel(context.Background())
		cancelCaller()
		postCommitCtx, cancelPostCommit := context.WithCancel(context.Background())
		cancelPostCommit()
		runtime := directUpgradeProtocolRuntime{postCommitCtx: postCommitCtx, transport: transport, transportReady: true}
		done := make(chan controlFrameReadResult, 1)
		done <- controlFrameReadResult{payload: postCommitPhasePayload(t, upgradeControlPhaseConfirmed)}
		_, completed, outcome, terminal := engine.awaitEnginePhaseFromDone(callerCtx, &runtime, done)
		if terminal || outcome.err != nil || !completed {
			t.Fatalf("Confirmed completion = terminal %v, completed %v, error %v", terminal, completed, outcome.err)
		}
		outcome = engine.dispatchDialerEvent(callerCtx, directUpgradeProtocolEventDialerConfirmedCompleted, directUpgradeProtocolActionInput{transport: transport}, &runtime)
		if !outcome.terminal || outcome.err != nil || outcome.result.Stream == nil {
			t.Fatalf("Confirmed outcome = terminal %v, result %+v, error %v", outcome.terminal, outcome.result, outcome.err)
		}
		if !slices.Equal(*trace, []directUpgradeDialerRow{directUpgradeDialerRowD21}) {
			t.Fatalf("Confirmed completion trace = %v, want D21", *trace)
		}
		_ = outcome.result.Stream.Close()
	})
}

func TestDialerEngineContradictoryConfirmedFrameUsesD20OwnerPath(t *testing.T) {
	confirmed, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseConfirmed, true)
	if err != nil {
		t.Fatalf("encode contradictory Confirmed frame: %v", err)
	}
	channel := newScriptedControlChannel(confirmed, false)
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:44001")}}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg:           upgradeConfig{packetConn: packetConn, controlTimeout: time.Second},
	})
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, directUpgradeProtocolStatePostCommitConverged)
	trace := make([]directUpgradeDialerRow, 0, 1)
	engine := directUpgradeProtocolEngine{
		role:    upgradeRoleDial,
		attempt: attempt,
		session: &terminalTestSession{},
		selected: selectedPair{
			dialer:   Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:44001")},
			listener: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:44002")},
		},
		cursor:          &cursor,
		testDialerTrace: func(row directUpgradeDialerRow) { trace = append(trace, row) },
	}
	stream := &terminalTestStream{packetConn: packetConn}
	transport := postCommitTransportResult{stream: stream}
	seedCompletedDialerOwnerForTest(attempt.resources(), engine.session, transport)
	runtime := directUpgradeProtocolRuntime{
		postCommitCtx:   context.Background(),
		transport:       transport,
		transportReady:  true,
		datagramsAgreed: false,
	}
	engine.runtime = &runtime

	_, err = engine.run(runtime.postCommitCtx, context.Background())
	if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, errDatagramExposureAgreementMismatch) {
		t.Fatalf("contradictory Confirmed error = %v, want transport-not-converged with agreement mismatch", err)
	}
	if !slices.Equal(trace, []directUpgradeDialerRow{directUpgradeDialerRowD20}) {
		t.Fatalf("contradictory Confirmed trace = %v, want exactly D20", trace)
	}
	attempt.resources().mu.Lock()
	disposition := attempt.resources().terminalDisposition
	attempt.resources().mu.Unlock()
	if disposition != attemptTerminalFailClosed {
		t.Fatalf("contradictory Confirmed disposition = %v, want fail-closed", disposition)
	}
}

func TestDialerEnginePendingTerminalSourceClassification(t *testing.T) {
	operationErr := errors.New("pending Dial operation failed")
	readErr := errors.New("Accepted read failed")
	internalErr := errors.New("internal transition failed")
	type sourceCase struct {
		name      string
		wantCause error
		row       func(transportStreamResultClass) directUpgradeDialerRow
		run       func(
			*testing.T,
			directUpgradeProtocolEngine,
			*directUpgradeProtocolRuntime,
		) (UpgradeResult, error)
	}
	sources := []sourceCase{
		{
			name:      "caller_cancel",
			wantCause: context.Canceled,
			row: func(class transportStreamResultClass) directUpgradeDialerRow {
				return pendingDialerSourceRowForTest(class, directUpgradeDialerRowD13F, directUpgradeDialerRowD13S, directUpgradeDialerRowD13E)
			},
			run: func(_ *testing.T, engine directUpgradeProtocolEngine, runtime *directUpgradeProtocolRuntime) (UpgradeResult, error) {
				callerCtx, cancel := context.WithCancel(context.Background())
				cancel()
				return engine.run(runtime.postCommitCtx, callerCtx)
			},
		},
		{
			name:      "budget_expiry",
			wantCause: context.Canceled,
			row: func(class transportStreamResultClass) directUpgradeDialerRow {
				return pendingDialerSourceRowForTest(class, directUpgradeDialerRowD14F, directUpgradeDialerRowD14S, directUpgradeDialerRowD14E)
			},
			run: func(_ *testing.T, engine directUpgradeProtocolEngine, runtime *directUpgradeProtocolRuntime) (UpgradeResult, error) {
				postCommitCtx, cancel := context.WithCancel(context.Background())
				cancel()
				runtime.postCommitCtx = postCommitCtx
				return engine.run(postCommitCtx, context.Background())
			},
		},
		{
			name:      "read_failure",
			wantCause: readErr,
			row: func(class transportStreamResultClass) directUpgradeDialerRow {
				return pendingDialerSourceRowForTest(class, directUpgradeDialerRowD16F, directUpgradeDialerRowD16S, directUpgradeDialerRowD16E)
			},
			run: func(_ *testing.T, engine directUpgradeProtocolEngine, runtime *directUpgradeProtocolRuntime) (UpgradeResult, error) {
				engine.attempt.controlFrames = newControlFrameSequencerWithRead(func() controlFrameReadResult {
					return controlFrameReadResult{err: readErr}
				})
				return engine.run(runtime.postCommitCtx, context.Background())
			},
		},
		{
			name: "wrong_phase",
			row: func(class transportStreamResultClass) directUpgradeDialerRow {
				return pendingDialerSourceRowForTest(class, directUpgradeDialerRowD17F, directUpgradeDialerRowD17S, directUpgradeDialerRowD17E)
			},
			run: func(t *testing.T, engine directUpgradeProtocolEngine, runtime *directUpgradeProtocolRuntime) (UpgradeResult, error) {
				payload := postCommitPhasePayload(t, upgradeControlPhaseConverged)
				engine.attempt.controlFrames = newControlFrameSequencerWithRead(func() controlFrameReadResult {
					return controlFrameReadResult{payload: payload}
				})
				return engine.run(runtime.postCommitCtx, context.Background())
			},
		},
		{
			name:      "internal_failure",
			wantCause: internalErr,
			row: func(class transportStreamResultClass) directUpgradeDialerRow {
				return pendingDialerSourceRowForTest(class, directUpgradeDialerRowD23F, directUpgradeDialerRowD23S, directUpgradeDialerRowD23E)
			},
			run: func(_ *testing.T, engine directUpgradeProtocolEngine, runtime *directUpgradeProtocolRuntime) (UpgradeResult, error) {
				outcome := engine.dispatchUnexpectedDialerEvent(
					context.Background(),
					directUpgradeProtocolActionInput{cause: internalErr},
					runtime,
				)
				return outcome.result, outcome.err
			},
		},
	}
	results := []struct {
		name   string
		result func(*terminalTestPacketConn) postCommitTransportResult
	}{
		{
			name: "failure",
			result: func(*terminalTestPacketConn) postCommitTransportResult {
				return postCommitTransportResult{err: operationErr}
			},
		},
		{
			name: "success",
			result: func(packetConn *terminalTestPacketConn) postCommitTransportResult {
				return postCommitTransportResult{stream: &terminalTestStream{packetConn: packetConn}}
			},
		},
		{
			name: "stream_error",
			result: func(packetConn *terminalTestPacketConn) postCommitTransportResult {
				return postCommitTransportResult{stream: &terminalTestStream{packetConn: packetConn}, err: operationErr}
			},
		},
	}

	for _, source := range sources {
		for _, resultCase := range results {
			t.Run(source.name+"/"+resultCase.name, func(t *testing.T) {
				channel := &terminalTestChannel{}
				packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:45001")}}
				attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
					channel: channel,
					cfg:     upgradeConfig{packetConn: packetConn},
				})
				cursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, directUpgradeProtocolStatePostCommitStart)
				trace := make([]directUpgradeDialerRow, 0, 1)
				engine := directUpgradeProtocolEngine{
					role:            upgradeRoleDial,
					attempt:         attempt,
					session:         &terminalTestSession{},
					cursor:          &cursor,
					testDialerTrace: func(row directUpgradeDialerRow) { trace = append(trace, row) },
				}
				cancelObserved := make(chan struct{}, 1)
				operation := seedPendingDialerOwnerForSourceTest(attempt.resources(), engine.session, cancelObserved)
				result := resultCase.result(packetConn)
				go func() {
					<-cancelObserved
					publishPendingDialerResultForTest(attempt.resources(), operation, result)
					operation.done <- result
				}()
				runtime := directUpgradeProtocolRuntime{
					postCommitCtx: context.Background(),
					transportCh:   operation.done,
				}
				engine.runtime = &runtime

				_, err := source.run(t, engine, &runtime)
				if !errors.Is(err, ErrUpgradeTransportNotConverged) {
					t.Fatalf("source outcome error = %v, want transport-not-converged", err)
				}
				if source.wantCause != nil && !errors.Is(err, source.wantCause) {
					t.Fatalf("source outcome error = %v, want source cause %v", err, source.wantCause)
				}
				class := classifyTransportStreamResult(result)
				want := []directUpgradeDialerRow{source.row(class)}
				if !slices.Equal(trace, want) {
					t.Fatalf("source trace = %v, want %v", trace, want)
				}
				attempt.resources().mu.Lock()
				disposition := attempt.resources().terminalDisposition
				attempt.resources().mu.Unlock()
				if disposition != attemptTerminalFailClosed {
					t.Fatalf("terminal disposition = %v, want fail-closed", disposition)
				}
			})
		}
	}
}

func TestDialerEnginePendingReadErrorContextOverlap(t *testing.T) {
	readErr := errors.New("armed Accepted read failure")
	operationErr := errors.New("pending Dial operation failed")
	type contextCase struct {
		name string
		row  func(transportStreamResultClass) directUpgradeDialerRow
		run  func(directUpgradeProtocolEngine, *directUpgradeProtocolRuntime) (UpgradeResult, error)
	}
	contexts := []contextCase{
		{
			name: "caller_cancel",
			row: func(class transportStreamResultClass) directUpgradeDialerRow {
				return pendingDialerSourceRowForTest(class, directUpgradeDialerRowD13F, directUpgradeDialerRowD13S, directUpgradeDialerRowD13E)
			},
			run: func(engine directUpgradeProtocolEngine, runtime *directUpgradeProtocolRuntime) (UpgradeResult, error) {
				callerCtx := newErrAfterCallsTestContext(0, context.Canceled)
				return engine.run(runtime.postCommitCtx, callerCtx)
			},
		},
		{
			name: "budget_expiry",
			row: func(class transportStreamResultClass) directUpgradeDialerRow {
				return pendingDialerSourceRowForTest(class, directUpgradeDialerRowD14F, directUpgradeDialerRowD14S, directUpgradeDialerRowD14E)
			},
			run: func(engine directUpgradeProtocolEngine, runtime *directUpgradeProtocolRuntime) (UpgradeResult, error) {
				postCommitCtx := newErrAfterCallsTestContext(1, context.Canceled)
				runtime.postCommitCtx = postCommitCtx
				return engine.run(postCommitCtx, context.Background())
			},
		},
	}
	results := []struct {
		name   string
		result func(*terminalTestPacketConn) postCommitTransportResult
	}{
		{
			name: "failure",
			result: func(*terminalTestPacketConn) postCommitTransportResult {
				return postCommitTransportResult{err: operationErr}
			},
		},
		{
			name: "success",
			result: func(packetConn *terminalTestPacketConn) postCommitTransportResult {
				return postCommitTransportResult{stream: &terminalTestStream{packetConn: packetConn}}
			},
		},
		{
			name: "stream_error",
			result: func(packetConn *terminalTestPacketConn) postCommitTransportResult {
				return postCommitTransportResult{stream: &terminalTestStream{packetConn: packetConn}, err: operationErr}
			},
		},
	}

	for _, contextCase := range contexts {
		for _, resultCase := range results {
			t.Run(contextCase.name+"/"+resultCase.name, func(t *testing.T) {
				channel := &terminalTestChannel{}
				packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:45201")}}
				attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
					channel:       channel,
					controlFrames: newBufferedControlFrameSequencer(controlFrameReadResult{err: readErr}),
					cfg:           upgradeConfig{packetConn: packetConn},
				})
				cursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, directUpgradeProtocolStatePostCommitStart)
				trace := make([]directUpgradeDialerRow, 0, 1)
				session := &terminalTestSession{}
				engine := directUpgradeProtocolEngine{
					role:            upgradeRoleDial,
					attempt:         attempt,
					session:         session,
					cursor:          &cursor,
					testDialerTrace: func(row directUpgradeDialerRow) { trace = append(trace, row) },
				}
				var cancelCalls atomic.Int32
				cancelObserved := make(chan struct{}, 1)
				operation := seedPendingDialerOwnerForCallbackTest(attempt.resources(), session, func() {
					cancelCalls.Add(1)
					select {
					case cancelObserved <- struct{}{}:
					default:
					}
				})
				result := resultCase.result(packetConn)
				go func() {
					<-cancelObserved
					publishPendingDialerResultForTest(attempt.resources(), operation, result)
					operation.done <- result
				}()
				runtime := directUpgradeProtocolRuntime{
					postCommitCtx: context.Background(),
					transportCh:   operation.done,
				}
				engine.runtime = &runtime

				_, err := contextCase.run(engine, &runtime)
				if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, context.Canceled) {
					t.Fatalf("overlap error = %v, want transport-not-converged with context cancellation", err)
				}
				want := []directUpgradeDialerRow{contextCase.row(classifyTransportStreamResult(result))}
				if !slices.Equal(trace, want) {
					t.Fatalf("overlap trace = %v, want %v", trace, want)
				}
				if got := cancelCalls.Load(); got != 1 {
					t.Fatalf("overlap Dial cancellations = %d, want 1", got)
				}
				if got := session.closeCalls.Load(); got != 1 {
					t.Fatalf("overlap Session.Close calls = %d, want 1", got)
				}
			})
		}
	}
}

func TestDialerEngineProductionFailClosedCauses(t *testing.T) {
	datagramErr := errors.New("Datagram carrier validation failed")
	tests := []struct {
		name      string
		row       directUpgradeDialerRow
		result    func(*terminalTestPacketConn) postCommitTransportResult
		wantCause error
	}{
		{
			name: "nil_transport_stream",
			row:  directUpgradeDialerRowD12,
			result: func(*terminalTestPacketConn) postCommitTransportResult {
				return postCommitTransportResult{}
			},
			wantCause: errNilTransportStream,
		},
		{
			name: "datagram_validation",
			row:  directUpgradeDialerRowD11V,
			result: func(packetConn *terminalTestPacketConn) postCommitTransportResult {
				return postCommitTransportResult{
					stream:                       &terminalTestStream{packetConn: packetConn},
					err:                          datagramErr,
					datagramCarrierValidationErr: true,
				}
			},
			wantCause: datagramErr,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			channel := &terminalTestChannel{}
			packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:45401")}}
			attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
				channel: channel,
				cfg:     upgradeConfig{packetConn: packetConn},
			})
			result := test.result(packetConn)
			session := &terminalTestSession{}
			seedCompletedDialerOwnerForTest(attempt.resources(), session, result)
			cursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, directUpgradeProtocolStatePostCommitStart)
			trace := make([]directUpgradeDialerRow, 0, 1)
			engine := directUpgradeProtocolEngine{
				role:            upgradeRoleDial,
				attempt:         attempt,
				session:         session,
				cursor:          &cursor,
				testDialerTrace: func(row directUpgradeDialerRow) { trace = append(trace, row) },
			}
			runtime := directUpgradeProtocolRuntime{postCommitCtx: context.Background()}

			outcome := engine.observeDialerTransport(context.Background(), &runtime, result)
			if !outcome.terminal || !errors.Is(outcome.err, ErrUpgradeTransportNotConverged) || !errors.Is(outcome.err, test.wantCause) {
				t.Fatalf("production cause outcome = terminal %v, error %v; want transport-not-converged with %v", outcome.terminal, outcome.err, test.wantCause)
			}
			if !slices.Equal(trace, []directUpgradeDialerRow{test.row}) {
				t.Fatalf("production cause trace = %v, want %s", trace, test.row)
			}
			attempt.resources().mu.Lock()
			disposition := attempt.resources().terminalDisposition
			attempt.resources().mu.Unlock()
			if disposition != attemptTerminalFailClosed {
				t.Fatalf("production cause disposition = %v, want fail-closed", disposition)
			}
		})
	}
}

func TestDialerEngineConvergedSendRequiresMaterializedDial(t *testing.T) {
	writeObserved := make(chan struct{}, 1)
	channel := newObservedWriteControlChannel(writeObserved, nil, false)
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:45501")}}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg:           upgradeConfig{packetConn: packetConn},
	})
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, directUpgradeProtocolStatePostCommitAccepted)
	engine := directUpgradeProtocolEngine{
		role:    upgradeRoleDial,
		attempt: attempt,
		session: &terminalTestSession{},
		cursor:  &cursor,
	}
	operation := seedPendingDialerOwnerForTest(attempt.resources(), engine.session)
	runtime := directUpgradeProtocolRuntime{
		postCommitCtx:   context.Background(),
		transportCh:     operation.done,
		peerDatagrams:   false,
		datagramsAgreed: false,
	}
	engine.runtime = &runtime
	callerCtx := newObservableDoneTestContext()
	done := make(chan error, 1)
	go func() {
		_, err := engine.run(runtime.postCommitCtx, callerCtx)
		done <- err
	}()
	select {
	case <-callerCtx.doneObserved:
	case <-time.After(time.Second):
		t.Fatal("engine did not wait for pending Dial before Converged")
	}
	select {
	case <-writeObserved:
		t.Fatal("Converged was written while Dial remained pending")
	default:
	}
	transport := postCommitTransportResult{stream: &terminalTestStream{packetConn: packetConn}}
	publishPendingDialerResultForTest(attempt.resources(), operation, transport)
	operation.done <- transport
	select {
	case <-writeObserved:
	case <-time.After(time.Second):
		t.Fatal("Converged was not written after definitive Dial success")
	}
	select {
	case err := <-done:
		if !errors.Is(err, ErrUpgradeTransportNotConverged) {
			t.Fatalf("post-Converged terminal error = %v, want transport-not-converged", err)
		}
	case <-time.After(time.Second):
		t.Fatal("engine did not settle after the post-Converged read failure")
	}
}

func pendingDialerSourceRowForTest(
	class transportStreamResultClass,
	failure directUpgradeDialerRow,
	success directUpgradeDialerRow,
	streamError directUpgradeDialerRow,
) directUpgradeDialerRow {
	switch class {
	case transportStreamResultNoMaterialization:
		return failure
	case transportStreamResultSuccess:
		return success
	case transportStreamResultMaterializedError:
		return streamError
	default:
		panic("unexpected transport result class")
	}
}

func seedPendingDialerOwnerForSourceTest(
	owner *attemptResources,
	session Session,
	cancelObserved chan<- struct{},
) *ownedDialOperation {
	return seedPendingDialerOwnerForCallbackTest(owner, session, func() {
		select {
		case cancelObserved <- struct{}{}:
		default:
		}
	})
}

func seedPendingDialerOwnerForCallbackTest(
	owner *attemptResources,
	session Session,
	cancel func(),
) *ownedDialOperation {
	owner.registerSession(session)
	owner.registerCommit()
	operation := &ownedDialOperation{
		cancel: cancel,
		ready:  make(chan struct{}),
		done:   make(chan transportStreamResult, 1),
	}
	owner.mu.Lock()
	owner.dial = operation
	owner.dialState = attemptOperationRunning
	owner.mu.Unlock()
	return operation
}

func TestSendPostCommitFailedWriteAtCancellationReturnsWithoutGrace(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	writeErr := make(chan error, 1)
	writeErr <- errors.New("control write failed")
	started := time.Now()
	err := awaitPostCommitWrite(ctx, writeErr)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("write arbitration error = %v, want cancellation", err)
	}
	if elapsed := time.Since(started); elapsed >= postCommitWritePublicationGrace/2 {
		t.Fatalf("failed write arbitration took %v, consumed publication grace %v", elapsed, postCommitWritePublicationGrace)
	}
}

func TestDirectUpgradeProtocolTransitionCompleteness(t *testing.T) {
	seen := make(map[struct {
		role  upgradeRole
		state directUpgradeProtocolState
		event directUpgradeProtocolEvent
	}]bool)
	listenerRows := make(map[directUpgradeListenerRow]struct{}, 82)
	dialerRows := make(map[directUpgradeDialerRow]struct{}, 43)
	for _, transition := range directUpgradeProtocolTransitions {
		key := struct {
			role  upgradeRole
			state directUpgradeProtocolState
			event directUpgradeProtocolEvent
		}{role: transition.role, state: transition.from, event: transition.event}
		if seen[key] {
			t.Fatalf("duplicate transition row for (%v, %v, %v)", transition.role, transition.from, transition.event)
		}
		seen[key] = true
		if transition.action.kind == 0 {
			t.Fatalf("transition (%v, %v, %v) has no engine action", transition.role, transition.from, transition.event)
		}
		if transition.listenerRow != "" {
			if transition.role != upgradeRoleListen {
				t.Fatalf("listener row %s belongs to role %v", transition.listenerRow, transition.role)
			}
			if _, duplicate := listenerRows[transition.listenerRow]; duplicate {
				t.Fatalf("duplicate listener row %s", transition.listenerRow)
			}
			listenerRows[transition.listenerRow] = struct{}{}
		}
		if transition.dialerRow != "" {
			if transition.role != upgradeRoleDial {
				t.Fatalf("dialer row %s belongs to role %v", transition.dialerRow, transition.role)
			}
			if _, duplicate := dialerRows[transition.dialerRow]; duplicate {
				t.Fatalf("duplicate dialer row %s", transition.dialerRow)
			}
			dialerRows[transition.dialerRow] = struct{}{}
		}
	}
	if got, want := len(listenerRows), 82; got != want {
		t.Fatalf("listener rows = %d, want %d", got, want)
	}
	if got, want := len(dialerRows), 43; got != want {
		t.Fatalf("dialer rows = %d, want %d", got, want)
	}
	if err := validateDirectUpgradeProtocolConcreteMappingsForTest(directUpgradeProtocolTransitions[:]); err != nil {
		t.Fatal(err)
	}
}

func TestDirectUpgradeProtocolTransitionCompletenessRejectsMissingAndOverlap(t *testing.T) {
	missing := append([]directUpgradeProtocolTransition(nil), directUpgradeProtocolTransitions[:]...)
	missingIndex := directUpgradeProtocolTransitionIndexForListenerRow(t, missing, directUpgradeListenerRowL34)
	missing[missingIndex].event = directUpgradeProtocolEventListenerUnexpectedMaterialized
	if err := validateDirectUpgradeProtocolConcreteMappingsForTest(missing); err == nil || !strings.Contains(err.Error(), "reachable mapping") {
		t.Fatalf("concrete completeness missing-mapping error = %v, want reachable mapping rejection", err)
	}
	overlap := append([]directUpgradeProtocolTransition(nil), directUpgradeProtocolTransitions[:]...)
	overlapIndex := directUpgradeProtocolTransitionIndexForListenerRow(t, overlap, directUpgradeListenerRowL40)
	overlap[overlapIndex].event = directUpgradeProtocolEventListenerPostcommitCanceled
	if err := validateDirectUpgradeProtocolConcreteMappingsForTest(overlap); err == nil || !strings.Contains(err.Error(), "has 2 matches") {
		t.Fatalf("concrete completeness overlap error = %v, want concrete two-match rejection", err)
	}
}

func directUpgradeProtocolTransitionIndexForListenerRow(
	t *testing.T,
	transitions []directUpgradeProtocolTransition,
	row directUpgradeListenerRow,
) int {
	t.Helper()
	for index, transition := range transitions {
		if transition.listenerRow == row {
			return index
		}
	}
	t.Fatalf("listener row %s not found", row)
	return -1
}

func validateDirectUpgradeProtocolConcreteMappingsForTest(transitions []directUpgradeProtocolTransition) error {
	listenerRows := make(map[directUpgradeListenerRow]struct{}, 82)
	dialerRows := make(map[directUpgradeDialerRow]struct{}, 43)
	for _, transition := range transitions {
		if transition.listenerRow != "" {
			if _, duplicate := listenerRows[transition.listenerRow]; duplicate {
				return fmt.Errorf("duplicate listener row %s", transition.listenerRow)
			}
			listenerRows[transition.listenerRow] = struct{}{}
		}
		if transition.dialerRow != "" {
			if _, duplicate := dialerRows[transition.dialerRow]; duplicate {
				return fmt.Errorf("duplicate dialer row %s", transition.dialerRow)
			}
			dialerRows[transition.dialerRow] = struct{}{}
		}
	}
	if len(listenerRows) != 82 || len(dialerRows) != 43 {
		return fmt.Errorf("row census = listener %d, dialer %d; want 82 and 43", len(listenerRows), len(dialerRows))
	}
	for _, role := range []upgradeRole{upgradeRoleListen, upgradeRoleDial} {
		for _, state := range directUpgradeProtocolConcreteStatesForTest() {
			expected := directUpgradeProtocolExpectedEventsForTest(role, state)
			for event := directUpgradeProtocolEventNoEvent; event <= directUpgradeProtocolEventListenerUnexpectedMaterialized; event++ {
				matches := 0
				for _, transition := range transitions {
					if transition.role == role && transition.event == event && directUpgradeProtocolStateMatches(transition, state) {
						matches++
					}
				}
				want := slices.Contains(expected, event)
				if want && matches != 1 {
					return fmt.Errorf("reachable mapping (%v, %v, %v) has %d matches, want exactly one", role, state, event, matches)
				}
				if !want && matches != 0 {
					return fmt.Errorf("explicitly impossible mapping (%v, %v, %v) has %d matches", role, state, event, matches)
				}
			}
		}
	}
	return nil
}

func directUpgradeProtocolConcreteStatesForTest() []directUpgradeProtocolState {
	return []directUpgradeProtocolState{
		directUpgradeProtocolStateListenerSelected,
		directUpgradeProtocolStateListenerListenPending,
		directUpgradeProtocolStateListenerAwaitingAcceptOrCommit,
		directUpgradeProtocolStateListenerAcceptFirst,
		directUpgradeProtocolStateListenerCommitFirst,
		directUpgradeProtocolStateDialerAwaitReady,
		directUpgradeProtocolStateDialerCommit,
		directUpgradeProtocolStatePostCommitStart,
		directUpgradeProtocolStatePostCommitAccepted,
		directUpgradeProtocolStatePostCommitConverged,
		directUpgradeProtocolStateTerminal,
	}
}

func directUpgradeProtocolExpectedEventsForTest(role upgradeRole, state directUpgradeProtocolState) []directUpgradeProtocolEvent {
	if state == directUpgradeProtocolStateTerminal {
		return nil
	}
	if role == upgradeRoleDial {
		return directUpgradeDialerExpectedEventsForStateForTest(state)
	}
	if role != upgradeRoleListen {
		return nil
	}
	switch state {
	case directUpgradeProtocolStateListenerSelected:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventListenerSelectedTimedOut,
			directUpgradeProtocolEventListenerSelectedControlError,
			directUpgradeProtocolEventListenerSelectedPeerFallback,
			directUpgradeProtocolEventListenerSelectedInvalid,
			directUpgradeProtocolEventListenerSelectedAdmitted,
		}
	case directUpgradeProtocolStateListenerListenPending:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventListenerListenSequencerRelayFailure,
			directUpgradeProtocolEventListenerListenSequencerRelayMaterialized,
			directUpgradeProtocolEventListenerListenControlFailure,
			directUpgradeProtocolEventListenerListenControlMaterialized,
			directUpgradeProtocolEventListenerListenCancelFailure,
			directUpgradeProtocolEventListenerListenCancelMaterialized,
			directUpgradeProtocolEventListenerListenBudgetFailure,
			directUpgradeProtocolEventListenerListenBudgetMaterialized,
			directUpgradeProtocolEventListenerListenFailure,
			directUpgradeProtocolEventListenerListenMaterializedError,
			directUpgradeProtocolEventListenerListenSucceeded,
		}
	case directUpgradeProtocolStateListenerAwaitingAcceptOrCommit:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventListenerReadyEncodeAcceptFailure,
			directUpgradeProtocolEventListenerReadyEncodeAcceptSuccess,
			directUpgradeProtocolEventListenerReadyEncodeAcceptMaterializedError,
			directUpgradeProtocolEventListenerReadyWriteAcceptFailure,
			directUpgradeProtocolEventListenerReadyWriteAcceptSuccess,
			directUpgradeProtocolEventListenerReadyWriteAcceptMaterializedError,
			directUpgradeProtocolEventListenerPrecommitAcceptFailure,
			directUpgradeProtocolEventListenerPrecommitAcceptMaterializedError,
			directUpgradeProtocolEventListenerPrecommitAcceptSuccess,
			directUpgradeProtocolEventListenerAcceptDatagramValidationFailed,
			directUpgradeProtocolEventListenerCommitFirst,
			directUpgradeProtocolEventListenerPeerFallbackAcceptFailure,
			directUpgradeProtocolEventListenerPeerFallbackAcceptSuccess,
			directUpgradeProtocolEventListenerPeerFallbackAcceptMaterializedError,
			directUpgradeProtocolEventListenerControlErrorAcceptFailure,
			directUpgradeProtocolEventListenerControlErrorAcceptSuccess,
			directUpgradeProtocolEventListenerControlErrorAcceptMaterializedError,
			directUpgradeProtocolEventListenerTimeoutAcceptFailure,
			directUpgradeProtocolEventListenerTimeoutAcceptSuccess,
			directUpgradeProtocolEventListenerTimeoutAcceptMaterializedError,
			directUpgradeProtocolEventListenerTimeoutCommitAcceptFailure,
			directUpgradeProtocolEventListenerTimeoutCommitAcceptSuccess,
			directUpgradeProtocolEventListenerTimeoutCommitAcceptMaterializedError,
			directUpgradeProtocolEventListenerTimeoutWireFallback,
			directUpgradeProtocolEventListenerTimeoutControlError,
			directUpgradeProtocolEventListenerCancelAcceptFailure,
			directUpgradeProtocolEventListenerCancelAcceptSuccess,
			directUpgradeProtocolEventListenerCancelAcceptMaterializedError,
			directUpgradeProtocolEventListenerCancelCommitAcceptFailure,
			directUpgradeProtocolEventListenerCancelCommitAcceptSuccess,
			directUpgradeProtocolEventListenerCancelCommitAcceptMaterializedError,
			directUpgradeProtocolEventListenerCancelEmptyAcceptFailure,
			directUpgradeProtocolEventListenerCancelEmptyAcceptSuccess,
			directUpgradeProtocolEventListenerCancelEmptyAcceptMaterializedError,
			directUpgradeProtocolEventListenerUnexpectedPreAcceptFailure,
			directUpgradeProtocolEventListenerUnexpectedPreAcceptSuccess,
			directUpgradeProtocolEventListenerUnexpectedPreAcceptMaterializedError,
		}
	case directUpgradeProtocolStateListenerAcceptFirst:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventListenerAcceptFirstCommit,
			directUpgradeProtocolEventListenerAcceptFirstControlError,
			directUpgradeProtocolEventListenerAcceptFirstNoncommit,
			directUpgradeProtocolEventListenerAcceptFirstBudgetExpired,
			directUpgradeProtocolEventListenerAcceptFirstCanceled,
			directUpgradeProtocolEventListenerUnexpectedMaterialized,
		}
	case directUpgradeProtocolStateListenerCommitFirst:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventListenerAcceptDatagramValidationFailed,
			directUpgradeProtocolEventListenerCommitFirstAcceptSuccess,
			directUpgradeProtocolEventListenerCommitFirstAcceptFailure,
			directUpgradeProtocolEventListenerCommitFirstAcceptMaterializedError,
			directUpgradeProtocolEventListenerPeerAbortAcceptFailure,
			directUpgradeProtocolEventListenerPeerAbortAcceptSuccess,
			directUpgradeProtocolEventListenerPeerAbortAcceptMaterializedError,
			directUpgradeProtocolEventListenerAcceptBudgetFailure,
			directUpgradeProtocolEventListenerAcceptBudgetSuccess,
			directUpgradeProtocolEventListenerAcceptBudgetMaterializedError,
			directUpgradeProtocolEventListenerCommitFirstCancelAcceptFailure,
			directUpgradeProtocolEventListenerCommitFirstCancelAcceptSuccess,
			directUpgradeProtocolEventListenerCommitFirstCancelAcceptMaterializedError,
			directUpgradeProtocolEventListenerUnexpectedCommitAcceptFailure,
			directUpgradeProtocolEventListenerUnexpectedCommitAcceptSuccess,
			directUpgradeProtocolEventListenerUnexpectedCommitAcceptMaterializedError,
		}
	case directUpgradeProtocolStatePostCommitStart:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventPostCommitAdvance,
			directUpgradeProtocolEventListenerAcceptedSendFailed,
			directUpgradeProtocolEventListenerPostcommitCanceled,
			directUpgradeProtocolEventListenerPostcommitBudgetExpired,
			directUpgradeProtocolEventListenerUnexpectedMaterialized,
		}
	case directUpgradeProtocolStatePostCommitAccepted:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventPostCommitAdvance,
			directUpgradeProtocolEventListenerConvergedReadFailed,
			directUpgradeProtocolEventListenerConvergedWrongPhase,
			directUpgradeProtocolEventListenerDatagramMismatch,
			directUpgradeProtocolEventListenerPostcommitCanceled,
			directUpgradeProtocolEventListenerPostcommitBudgetExpired,
			directUpgradeProtocolEventListenerUnexpectedMaterialized,
		}
	case directUpgradeProtocolStatePostCommitConverged:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventListenerConfirmedSendFailed,
			directUpgradeProtocolEventListenerPostcommitCanceled,
			directUpgradeProtocolEventListenerPostcommitBudgetExpired,
			directUpgradeProtocolEventListenerConfirmed,
			directUpgradeProtocolEventListenerUnexpectedMaterialized,
		}
	default:
		return nil
	}
}

func directUpgradeDialerExpectedEventsForStateForTest(state directUpgradeProtocolState) []directUpgradeProtocolEvent {
	commonTerminal := []directUpgradeProtocolEvent{
		directUpgradeProtocolEventDialerCallerCanceledMaterialized,
		directUpgradeProtocolEventDialerCallerCanceledPendingFailure,
		directUpgradeProtocolEventDialerCallerCanceledPendingSuccess,
		directUpgradeProtocolEventDialerCallerCanceledPendingMaterializedError,
		directUpgradeProtocolEventDialerBudgetExpiredMaterialized,
		directUpgradeProtocolEventDialerBudgetExpiredPendingFailure,
		directUpgradeProtocolEventDialerBudgetExpiredPendingSuccess,
		directUpgradeProtocolEventDialerBudgetExpiredPendingMaterializedError,
		directUpgradeProtocolEventDialerUnexpectedMaterialized,
		directUpgradeProtocolEventDialerUnexpectedPendingFailure,
		directUpgradeProtocolEventDialerUnexpectedPendingSuccess,
		directUpgradeProtocolEventDialerUnexpectedPendingMaterializedError,
	}
	dialResult := []directUpgradeProtocolEvent{
		directUpgradeProtocolEventDialerDialSucceeded,
		directUpgradeProtocolEventDialerDialMaterializedError,
		directUpgradeProtocolEventDialerDialDatagramValidationFailed,
		directUpgradeProtocolEventDialerDialFailed,
		directUpgradeProtocolEventDialerDialNilResult,
	}
	readFailure := []directUpgradeProtocolEvent{
		directUpgradeProtocolEventDialerReadFailedMaterialized,
		directUpgradeProtocolEventDialerReadFailedPendingFailure,
		directUpgradeProtocolEventDialerReadFailedPendingSuccess,
		directUpgradeProtocolEventDialerReadFailedPendingMaterializedError,
		directUpgradeProtocolEventDialerWrongPhaseMaterialized,
		directUpgradeProtocolEventDialerWrongPhasePendingFailure,
		directUpgradeProtocolEventDialerWrongPhasePendingSuccess,
		directUpgradeProtocolEventDialerWrongPhasePendingMaterializedError,
	}
	switch state {
	case directUpgradeProtocolStateDialerAwaitReady:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventDialerReadyAccepted,
			directUpgradeProtocolEventDialerSelectedEncodeFailed,
			directUpgradeProtocolEventDialerSelectedWriteFailed,
			directUpgradeProtocolEventDialerReadyTimedOut,
			directUpgradeProtocolEventDialerReadyControlFailed,
			directUpgradeProtocolEventDialerReadyFallback,
			directUpgradeProtocolEventDialerReadyPhaseMismatch,
			directUpgradeProtocolEventDialerUnexpectedPreCommit,
		}
	case directUpgradeProtocolStateDialerCommit:
		return []directUpgradeProtocolEvent{
			directUpgradeProtocolEventDialerCommitEncodeFailed,
			directUpgradeProtocolEventDialerCommitWriteFailed,
			directUpgradeProtocolEventDialerCommitPublished,
			directUpgradeProtocolEventDialerUnexpectedPreCommit,
		}
	case directUpgradeProtocolStatePostCommitStart:
		return slices.Concat(commonTerminal, dialResult, readFailure, []directUpgradeProtocolEvent{directUpgradeProtocolEventDialerAccepted})
	case directUpgradeProtocolStatePostCommitAccepted:
		return slices.Concat(commonTerminal, dialResult, []directUpgradeProtocolEvent{
			directUpgradeProtocolEventDialerSendFailedMaterialized,
			directUpgradeProtocolEventDialerSendFailedPendingFailure,
			directUpgradeProtocolEventDialerSendFailedPendingSuccess,
			directUpgradeProtocolEventDialerSendFailedPendingMaterializedError,
			directUpgradeProtocolEventDialerConverged,
		})
	case directUpgradeProtocolStatePostCommitConverged:
		return slices.Concat(commonTerminal, readFailure, []directUpgradeProtocolEvent{
			directUpgradeProtocolEventDialerDatagramMismatch,
			directUpgradeProtocolEventDialerConfirmedCompleted,
			directUpgradeProtocolEventDialerConfirmed,
		})
	default:
		return nil
	}
}

func TestDirectUpgradeProtocolPostCommitCursor(t *testing.T) {
	tests := []struct {
		name string
		role upgradeRole
		want []struct {
			to     directUpgradeProtocolState
			step   directUpgradePostCommitStep
			action directUpgradePostCommitPhaseAction
		}
	}{
		{
			name: "listener sends accepted awaits converged sends confirmed",
			role: upgradeRoleListen,
			want: []struct {
				to     directUpgradeProtocolState
				step   directUpgradePostCommitStep
				action directUpgradePostCommitPhaseAction
			}{
				{
					to:     directUpgradeProtocolStatePostCommitAccepted,
					step:   directUpgradePostCommitStepAccepted,
					action: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitSend, phase: upgradeControlPhaseAccepted},
				},
				{
					to:     directUpgradeProtocolStatePostCommitConverged,
					step:   directUpgradePostCommitStepConverged,
					action: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitAwait, phase: upgradeControlPhaseConverged},
				},
				{
					to:     directUpgradeProtocolStateTerminal,
					step:   directUpgradePostCommitStepConfirmed,
					action: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitSend, phase: upgradeControlPhaseConfirmed},
				},
			},
		},
		{
			name: "dialer awaits accepted sends converged awaits confirmed",
			role: upgradeRoleDial,
			want: []struct {
				to     directUpgradeProtocolState
				step   directUpgradePostCommitStep
				action directUpgradePostCommitPhaseAction
			}{
				{
					to:     directUpgradeProtocolStatePostCommitAccepted,
					step:   directUpgradePostCommitStepAccepted,
					action: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitAwait, phase: upgradeControlPhaseAccepted},
				},
				{
					to:     directUpgradeProtocolStatePostCommitConverged,
					step:   directUpgradePostCommitStepConverged,
					action: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitSend, phase: upgradeControlPhaseConverged},
				},
				{
					to:     directUpgradeProtocolStateTerminal,
					step:   directUpgradePostCommitStepConfirmed,
					action: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitAwait, phase: upgradeControlPhaseConfirmed},
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cursor := newDirectUpgradeProtocolCursor(tt.role, directUpgradeProtocolStatePostCommitStart)
			for i, want := range tt.want {
				transition, ok := cursor.next(directUpgradePostCommitEvent(tt.role, directUpgradePostCommitStep(i)))
				if !ok {
					t.Fatalf("step %d missing", i)
				}
				if transition.to != want.to {
					t.Fatalf("step %d state = %v, want %v", i, transition.to, want.to)
				}
				if transition.postCommitStep != want.step {
					t.Fatalf("step %d protocol step = %v, want %v", i, transition.postCommitStep, want.step)
				}
				if transition.postCommitAction != want.action {
					t.Fatalf("step %d action = %#v, want %#v", i, transition.postCommitAction, want.action)
				}
			}
			if _, ok := cursor.next(directUpgradeProtocolEventPostCommitAdvance); ok {
				t.Fatal("post-commit cursor advanced after terminal state")
			}
		})
	}
}
