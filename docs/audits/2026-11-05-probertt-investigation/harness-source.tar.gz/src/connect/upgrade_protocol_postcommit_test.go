package connect

import (
	"errors"
	"testing"
)

func directUpgradePostCommitPhase(
	role upgradeRole,
	step directUpgradePostCommitStep,
	local directUpgradePostCommitLocalAction,
) (upgradeControlPhase, bool) {
	order, ok := directUpgradePostCommitPhaseOrder(role)
	if !ok || int(step) >= len(order) {
		return 0, false
	}
	action := order[step]
	return action.phase, action.local == local
}

func TestDirectUpgradePostCommitPhaseOrder(t *testing.T) {
	tests := []struct {
		name string
		role upgradeRole
		want []directUpgradePostCommitPhaseAction
	}{
		{
			name: "listener sends accepted awaits converged sends confirmed",
			role: upgradeRoleListen,
			want: []directUpgradePostCommitPhaseAction{
				{local: directUpgradePostCommitSend, phase: upgradeControlPhaseAccepted},
				{local: directUpgradePostCommitAwait, phase: upgradeControlPhaseConverged},
				{local: directUpgradePostCommitSend, phase: upgradeControlPhaseConfirmed},
			},
		},
		{
			name: "dialer awaits accepted sends converged awaits confirmed",
			role: upgradeRoleDial,
			want: []directUpgradePostCommitPhaseAction{
				{local: directUpgradePostCommitAwait, phase: upgradeControlPhaseAccepted},
				{local: directUpgradePostCommitSend, phase: upgradeControlPhaseConverged},
				{local: directUpgradePostCommitAwait, phase: upgradeControlPhaseConfirmed},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, ok := directUpgradePostCommitPhaseOrder(tt.role)
			if !ok {
				t.Fatalf("post-commit phase order missing for role %v", tt.role)
			}
			if len(got) != len(tt.want) {
				t.Fatalf("post-commit phase order length = %d, want %d", len(got), len(tt.want))
			}
			for i := range tt.want {
				if got[i] != tt.want[i] {
					t.Fatalf("post-commit phase order[%d] = %#v, want %#v", i, got[i], tt.want[i])
				}
			}
		})
	}
}

func TestDirectUpgradePostCommitPhaseActionLookup(t *testing.T) {
	tests := []struct {
		name      string
		role      upgradeRole
		step      directUpgradePostCommitStep
		local     directUpgradePostCommitLocalAction
		wantPhase upgradeControlPhase
		wantOK    bool
	}{
		{
			name:      "listener sends accepted",
			role:      upgradeRoleListen,
			step:      directUpgradePostCommitStepAccepted,
			local:     directUpgradePostCommitSend,
			wantPhase: upgradeControlPhaseAccepted,
			wantOK:    true,
		},
		{
			name:      "listener does not await accepted",
			role:      upgradeRoleListen,
			step:      directUpgradePostCommitStepAccepted,
			local:     directUpgradePostCommitAwait,
			wantPhase: upgradeControlPhaseAccepted,
		},
		{
			name:      "dialer sends converged",
			role:      upgradeRoleDial,
			step:      directUpgradePostCommitStepConverged,
			local:     directUpgradePostCommitSend,
			wantPhase: upgradeControlPhaseConverged,
			wantOK:    true,
		},
		{
			name:      "dialer awaits confirmed",
			role:      upgradeRoleDial,
			step:      directUpgradePostCommitStepConfirmed,
			local:     directUpgradePostCommitAwait,
			wantPhase: upgradeControlPhaseConfirmed,
			wantOK:    true,
		},
		{
			name:   "unknown role is not accepted",
			role:   upgradeRole(99),
			step:   directUpgradePostCommitStepAccepted,
			local:  directUpgradePostCommitSend,
			wantOK: false,
		},
		{
			name:   "unknown step is not accepted",
			role:   upgradeRoleDial,
			step:   directUpgradePostCommitStep(99),
			local:  directUpgradePostCommitAwait,
			wantOK: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotPhase, gotOK := directUpgradePostCommitPhase(tt.role, tt.step, tt.local)
			if gotOK != tt.wantOK {
				t.Fatalf("ok = %v, want %v", gotOK, tt.wantOK)
			}
			if gotPhase != tt.wantPhase {
				t.Fatalf("phase = %v, want %v", gotPhase, tt.wantPhase)
			}
		})
	}
}

func TestEncodeUpgradeControlPostCommitPhaseRejectsPreCommitPhase(t *testing.T) {
	got, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseReady, false)
	if err == nil {
		t.Fatal("encodeUpgradeControlPostCommitPhase() error = nil, want unexpected phase order")
	}
	if got != nil {
		t.Fatalf("encoded frame = %x, want nil", got)
	}
	if !errors.Is(err, errUnexpectedPostCommitPhaseOrder) {
		t.Fatalf("encodeUpgradeControlPostCommitPhase() error = %v, want %v", err, errUnexpectedPostCommitPhaseOrder)
	}
}
