package connect

import (
	"errors"
	"fmt"
	"net"
	"os"
	"sync/atomic"
	"testing"
	"time"
)

func TestRendezvousDispositionUnknownForNilAndUnmarkedErrors(t *testing.T) {
	if got := RendezvousDisposition(nil); got != DispositionUnknown {
		t.Fatalf("RendezvousDisposition(nil) = %v, want %v", got, DispositionUnknown)
	}
	if got := MarkRendezvousSpent(nil); got != nil {
		t.Fatalf("MarkRendezvousSpent(nil) = %v, want nil", got)
	}
	if got := MarkRendezvousRetryable(nil); got != nil {
		t.Fatalf("MarkRendezvousRetryable(nil) = %v, want nil", got)
	}

	err := errors.New("identity handshake failed")
	if got := RendezvousDisposition(err); got != DispositionUnknown {
		t.Fatalf("RendezvousDisposition(unmarked) = %v, want %v", got, DispositionUnknown)
	}
}

func TestDispositionString(t *testing.T) {
	tests := []struct {
		disposition Disposition
		want        string
	}{
		{disposition: DispositionUnknown, want: "unknown"},
		{disposition: DispositionSpent, want: "spent"},
		{disposition: DispositionRetryable, want: "retryable"},
		{disposition: Disposition(99), want: "unknown(99)"},
	}

	for _, tt := range tests {
		if got := tt.disposition.String(); got != tt.want {
			t.Fatalf("Disposition(%d).String() = %q, want %q", uint8(tt.disposition), got, tt.want)
		}
	}
}

func TestOneShotRendezvousCapability(t *testing.T) {
	var oneShot OneShotRendezvous = oneShotRendezvousTestAuthenticator{spends: true}

	if !oneShot.SuccessSpendsRendezvous() {
		t.Fatal("SuccessSpendsRendezvous() = false, want true")
	}
}

// TestRendezvousDispositionErrorsAsObservesOuterMarker pins the godoc
// anti-example: errors.As stops at the first carrier it reaches (here, the
// outer marker), while RendezvousDisposition aggregates the whole tree and
// spent wins.
func TestRendezvousDispositionErrorsAsObservesOuterMarker(t *testing.T) {
	cause := errors.New("identity handshake failed")
	err := MarkRendezvousRetryable(MarkRendezvousSpent(cause))

	if got := RendezvousDisposition(err); got != DispositionSpent {
		t.Fatalf("RendezvousDisposition = %v, want %v", got, DispositionSpent)
	}

	var carrier interface{ RendezvousDisposition() Disposition }
	if !errors.As(err, &carrier) {
		t.Fatal("errors.As(err, disposition carrier) = false, want outer carrier found")
	}
	if got := carrier.RendezvousDisposition(); got != DispositionRetryable {
		t.Fatalf("errors.As carrier disposition = %v, want node-local %v from the outer marker", got, DispositionRetryable)
	}
}

func TestRendezvousDispositionMarkersAreTransparentWrappers(t *testing.T) {
	cause := rendezvousDispositionTestError{message: "identity handshake failed"}
	tests := []struct {
		name string
		mark func(error) error
		want Disposition
	}{
		{
			name: "spent",
			mark: MarkRendezvousSpent,
			want: DispositionSpent,
		},
		{
			name: "retryable",
			mark: MarkRendezvousRetryable,
			want: DispositionRetryable,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			marked := tt.mark(cause)
			if marked.Error() != cause.Error() {
				t.Fatalf("marked Error() = %q, want %q", marked.Error(), cause.Error())
			}
			if !errors.Is(marked, cause) {
				t.Fatalf("errors.Is(marked, cause) = false, want true")
			}
			wrapped := fmt.Errorf("wiremux: identity failed: %w", marked)
			if !errors.Is(wrapped, cause) {
				t.Fatalf("errors.Is(wrapped, cause) = false, want true")
			}
			var gotCause rendezvousDispositionTestError
			if !errors.As(wrapped, &gotCause) || gotCause != cause {
				t.Fatalf("errors.As(wrapped) = %#v, want %#v", gotCause, cause)
			}
			if got := RendezvousDisposition(wrapped); got != tt.want {
				t.Fatalf("RendezvousDisposition(wrapped) = %v, want %v", got, tt.want)
			}
		})
	}
}

type rendezvousDispositionTestError struct {
	message string
}

func (e rendezvousDispositionTestError) Error() string {
	return e.message
}

func TestRendezvousDispositionMarkersWrapTypedNilErrors(t *testing.T) {
	var typedNilOp *net.OpError
	var typedNilSyscall *os.SyscallError
	tests := []struct {
		name            string
		mark            func(error) error
		err             error
		want            Disposition
		assertNoAsMatch func(*testing.T, error)
	}{
		{
			name: "spent typed nil op error",
			mark: MarkRendezvousSpent,
			err:  typedNilOp,
			want: DispositionSpent,
			assertNoAsMatch: func(t *testing.T, marked error) {
				t.Helper()
				var target *net.OpError
				if errors.As(marked, &target) {
					t.Fatalf("errors.As(marked, *net.OpError) = true with target %v, want typed-nil cause hidden", target)
				}
			},
		},
		{
			name: "retryable typed nil syscall error",
			mark: MarkRendezvousRetryable,
			err:  typedNilSyscall,
			want: DispositionRetryable,
			assertNoAsMatch: func(t *testing.T, marked error) {
				t.Helper()
				var target *os.SyscallError
				if errors.As(marked, &target) {
					t.Fatalf("errors.As(marked, *os.SyscallError) = true with target %v, want typed-nil cause hidden", target)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			marked := tt.mark(tt.err)
			if marked == nil {
				t.Fatal("marked typed-nil error = nil, want non-nil marker")
			}
			if got := RendezvousDisposition(marked); got != tt.want {
				t.Fatalf("RendezvousDisposition(marked typed-nil) = %v, want %v", got, tt.want)
			}
			assertErrorStringDoesNotPanic(t, marked)
			if got := marked.Error(); got != "" {
				t.Fatalf("marked typed-nil Error() = %q, want defensively empty message", got)
			}
			if errors.Is(marked, tt.err) {
				t.Fatal("errors.Is(marked, typed-nil cause) = true, want typed-nil cause hidden")
			}
			if errors.Is(marked, os.ErrClosed) {
				t.Fatal("errors.Is(marked typed-nil cause, os.ErrClosed) = true, want false")
			}
			tt.assertNoAsMatch(t, marked)
		})
	}
}

// TestRendezvousDispositionMarkerTypedNilStdlibProbesAreSafe pins the marker
// boundary: typed-nil causes do not enter stdlib traversal, while the marker's
// declared disposition remains observable.
func TestRendezvousDispositionMarkerTypedNilStdlibProbesAreSafe(t *testing.T) {
	marked := MarkRendezvousSpent((*net.OpError)(nil))

	if got := RendezvousDisposition(marked); got != DispositionSpent {
		t.Fatalf("RendezvousDisposition(marked typed-nil cause) = %v, want %v without panic", got, DispositionSpent)
	}
	if errors.Is(marked, os.ErrClosed) {
		t.Fatal("errors.Is(marked typed-nil cause, os.ErrClosed) = true, want false")
	}

	var matching *net.OpError
	if errors.As(marked, &matching) {
		t.Fatalf("errors.As(marked, *net.OpError) = true with target %v, want typed-nil cause hidden", matching)
	}
	var mismatched *os.SyscallError
	if errors.As(marked, &mismatched) {
		t.Fatalf("errors.As(marked, *os.SyscallError) = true with target %v, want false", mismatched)
	}
}

// TestRendezvousDispositionErrorsAsBindingMechanics pins the godoc mechanics
// for direct errors.As probing: binding a panicking carrier does not panic
// (the panic fires only when the caller invokes the bound method), while
// traversing a panicking Unwrap panics inside errors.As itself.
func TestRendezvousDispositionErrorsAsBindingMechanics(t *testing.T) {
	var carrier interface{ RendezvousDisposition() Disposition }
	if !errors.As(error(panickingDispositionCarrierError{}), &carrier) {
		t.Fatal("errors.As(panicking carrier) = false, want clean bind without invoking the method")
	}
	invokePanicked := func() (panicked bool) {
		defer func() { panicked = recover() != nil }()
		_ = carrier.RendezvousDisposition()
		return false
	}()
	if !invokePanicked {
		t.Fatal("bound carrier RendezvousDisposition() did not panic; the godoc mechanics wording needs review")
	}

	traversePanicked := func() (panicked bool) {
		defer func() { panicked = recover() != nil }()
		var target *net.OpError
		_ = errors.As(panickingUnwrapDispositionError{hidden: errors.New("hidden")}, &target)
		return false
	}()
	if !traversePanicked {
		t.Fatal("errors.As over a panicking Unwrap did not panic; the godoc mechanics wording needs review")
	}
}

func TestRendezvousDispositionSpentWinsConflictingMarkers(t *testing.T) {
	cause := errors.New("identity handshake failed")
	conflicting := errors.Join(
		MarkRendezvousRetryable(cause),
		fmt.Errorf("later: %w", MarkRendezvousSpent(cause)),
	)

	if got := RendezvousDisposition(conflicting); got != DispositionSpent {
		t.Fatalf("RendezvousDisposition(conflicting) = %v, want %v", got, DispositionSpent)
	}
}

func TestRendezvousDispositionIgnoresBroadCustomIs(t *testing.T) {
	cause := errors.New("identity handshake failed")
	tests := []struct {
		name string
		err  error
		want Disposition
	}{
		{
			name: "broad Is alone",
			err:  alwaysIsDispositionError{},
			want: DispositionUnknown,
		},
		{
			name: "broad Is sibling does not hide marker",
			err:  errors.Join(alwaysIsDispositionError{}, MarkRendezvousRetryable(cause)),
			want: DispositionRetryable,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := RendezvousDisposition(tt.err); got != tt.want {
				t.Fatalf("RendezvousDisposition() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRendezvousDispositionIgnoresPanickingCarrier(t *testing.T) {
	cause := errors.New("identity handshake failed")
	tests := []struct {
		name string
		err  error
		want Disposition
	}{
		{
			name: "panicking carrier alone",
			err:  panickingDispositionCarrierError{},
			want: DispositionUnknown,
		},
		{
			name: "panicking carrier sibling does not hide marker",
			err:  errors.Join(panickingDispositionCarrierError{}, MarkRendezvousSpent(cause)),
			want: DispositionSpent,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := RendezvousDisposition(tt.err); got != tt.want {
				t.Fatalf("RendezvousDisposition() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRendezvousDispositionMalformedNodesFailClosedForRetryable(t *testing.T) {
	cause := errors.New("identity handshake failed")
	tests := []struct {
		name string
		err  error
		want Disposition
	}{
		{
			name: "panicking carrier after retryable",
			err:  errors.Join(MarkRendezvousRetryable(cause), panickingDispositionCarrierError{}),
			want: DispositionUnknown,
		},
		{
			name: "panicking unwrap can hide spent",
			err: errors.Join(
				MarkRendezvousRetryable(cause),
				panickingUnwrapDispositionError{hidden: MarkRendezvousSpent(cause)},
			),
			want: DispositionUnknown,
		},
		{
			name: "reached spent sibling still wins",
			err: errors.Join(
				MarkRendezvousRetryable(cause),
				panickingDispositionCarrierError{},
				MarkRendezvousSpent(cause),
			),
			want: DispositionSpent,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := RendezvousDisposition(tt.err); got != tt.want {
				t.Fatalf("RendezvousDisposition() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRendezvousDispositionHandlesTypedNilBranches(t *testing.T) {
	cause := errors.New("identity handshake failed")
	var typedNilOp *net.OpError
	var typedNilSyscall *os.SyscallError

	tests := []struct {
		name string
		err  error
		want Disposition
	}{
		{
			name: "typed nil op error alone",
			err:  typedNilOp,
			want: DispositionUnknown,
		},
		{
			name: "typed nil syscall error alone",
			err:  typedNilSyscall,
			want: DispositionUnknown,
		},
		{
			name: "retryable marker before typed nil op error",
			err:  errors.Join(MarkRendezvousRetryable(cause), typedNilOp),
			want: DispositionRetryable,
		},
		{
			name: "retryable marker after typed nil op error",
			err:  errors.Join(typedNilOp, MarkRendezvousRetryable(cause)),
			want: DispositionRetryable,
		},
		{
			name: "spent marker before typed nil syscall error",
			err:  errors.Join(MarkRendezvousSpent(cause), typedNilSyscall),
			want: DispositionSpent,
		},
		{
			name: "spent marker after typed nil syscall error",
			err:  errors.Join(typedNilSyscall, MarkRendezvousSpent(cause)),
			want: DispositionSpent,
		},
		{
			name: "wrapped join with typed nil branch",
			err:  fmt.Errorf("identity: %w", errors.Join(typedNilOp, MarkRendezvousRetryable(cause))),
			want: DispositionRetryable,
		},
		{
			name: "spent wins with retryable and typed nil branches",
			err:  errors.Join(MarkRendezvousRetryable(cause), typedNilOp, MarkRendezvousSpent(cause)),
			want: DispositionSpent,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := RendezvousDisposition(tt.err); got != tt.want {
				t.Fatalf("RendezvousDisposition() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRendezvousDispositionHandlesCyclicErrorTrees(t *testing.T) {
	cause := errors.New("identity handshake failed")
	selfCycle := &selfUnwrappingDispositionError{}
	leftCycle := &linkedDispositionError{message: "left"}
	rightCycle := &linkedDispositionError{message: "right"}
	leftCycle.next = rightCycle
	rightCycle.next = leftCycle

	tests := []struct {
		name string
		err  error
		want Disposition
	}{
		{
			name: "self cycle alone",
			err:  selfCycle,
			want: DispositionUnknown,
		},
		{
			name: "two node cycle alone",
			err:  leftCycle,
			want: DispositionUnknown,
		},
		{
			name: "retryable marker wraps self cycle",
			err:  MarkRendezvousRetryable(selfCycle),
			want: DispositionRetryable,
		},
		{
			name: "marker with cyclic sibling",
			err:  errors.Join(leftCycle, MarkRendezvousSpent(cause)),
			want: DispositionSpent,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := make(chan Disposition, 1)
			go func() {
				result <- RendezvousDisposition(tt.err)
			}()
			select {
			case got := <-result:
				if got != tt.want {
					t.Fatalf("RendezvousDisposition() = %v, want %v", got, tt.want)
				}
			case <-time.After(200 * time.Millisecond):
				t.Fatal("RendezvousDisposition did not return for cyclic error tree")
			}
		})
	}
}

func TestRendezvousDispositionCyclicBranchDoesNotStarveSiblingMarker(t *testing.T) {
	cause := errors.New("identity handshake failed")
	cycle := nonComparableMultiCycleDispositionError{payload: []int{1}}
	tests := []struct {
		name string
		err  error
	}{
		{
			name: "cycle before marker",
			err:  errors.Join(cycle, MarkRendezvousSpent(cause)),
		},
		{
			name: "marker before cycle",
			err:  errors.Join(MarkRendezvousSpent(cause), cycle),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := make(chan Disposition, 1)
			go func() {
				result <- RendezvousDisposition(tt.err)
			}()
			select {
			case got := <-result:
				if got != DispositionSpent {
					t.Fatalf("RendezvousDisposition() = %v, want %v", got, DispositionSpent)
				}
			case <-time.After(200 * time.Millisecond):
				t.Fatal("RendezvousDisposition did not return for non-comparable cyclic branch")
			}
		})
	}
}

func TestRendezvousDispositionHighFanoutCycleIsBounded(t *testing.T) {
	cause := errors.New("identity handshake failed")
	// The root enqueues the 256-child cap. Thirty-one child nodes expand
	// fully; the next child fills the remaining 32 queue slots and closes
	// enqueueing. The root plus those 32 expanding nodes therefore make
	// exactly 33 Unwrap calls; the final 32 enqueued children never expand.
	const boundedCycleUnwraps int64 = 33
	tests := []struct {
		name             string
		withSpentSibling bool
		want             Disposition
		wantUnwraps      int64
	}{
		{
			name:        "high fanout cycle alone",
			want:        DispositionUnknown,
			wantUnwraps: boundedCycleUnwraps,
		},
		{
			name:             "high fanout cycle before marker",
			withSpentSibling: true,
			want:             DispositionSpent,
			wantUnwraps:      1,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var unwraps atomic.Int64
			cycle := highFanoutNonComparableDispositionError{
				payload: []int{1},
				fanout:  maxRendezvousDispositionChildren + 1,
				unwraps: &unwraps,
			}
			var err error = cycle
			if tt.withSpentSibling {
				err = errors.Join(cycle, MarkRendezvousSpent(cause))
			}
			result := make(chan Disposition, 1)
			go func() {
				result <- RendezvousDisposition(err)
			}()
			select {
			case got := <-result:
				if got != tt.want {
					t.Fatalf("RendezvousDisposition() = %v, want %v", got, tt.want)
				}
			case <-time.After(testCausalObservationTimeout):
				t.Fatal("RendezvousDisposition did not return within diagnostic watchdog")
			}
			if got := unwraps.Load(); got != tt.wantUnwraps {
				t.Fatalf("high-fanout cycle Unwrap calls = %d, want %d", got, tt.wantUnwraps)
			}
		})
	}
}

func TestRendezvousDispositionTruncatedRetryableReturnsUnknown(t *testing.T) {
	cause := errors.New("identity handshake failed")
	retryable := MarkRendezvousRetryable(cause)
	spent := MarkRendezvousSpent(cause)

	tests := []struct {
		name          string
		err           error
		checkErrorsAs bool
	}{
		{
			name: "spent beyond child cap",
			err: fixedChildrenDispositionError{
				children: append(
					append([]error{retryable}, repeatedDispositionErrors(maxRendezvousDispositionChildren)...),
					spent,
				),
			},
		},
		{
			name: "spent one unwrap behind queued wrapper after queue cap",
			err: errors.Join(retryable, fanoutThenSpentDispositionError{
				cycle: highFanoutNonComparableDispositionError{
					payload: []int{1},
					fanout:  maxRendezvousDispositionChildren,
				},
				spent: spent,
			}),
		},
		{
			name:          "spent beyond depth cap",
			err:           errors.Join(retryable, wrapDispositionError(spent, maxRendezvousDispositionTreeDepth+1)),
			checkErrorsAs: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := make(chan Disposition, 1)
			go func() {
				result <- RendezvousDisposition(tt.err)
			}()
			select {
			case got := <-result:
				if got != DispositionUnknown {
					t.Fatalf("RendezvousDisposition() = %v, want %v", got, DispositionUnknown)
				}
			case <-time.After(200 * time.Millisecond):
				t.Fatal("RendezvousDisposition did not return for truncated retryable tree")
			}

			if tt.checkErrorsAs {
				// Pins the godoc contrast on a cycle-free tree: direct
				// errors.As reaches a retryable carrier while the fail-closed
				// truncation rule keeps the aggregate at DispositionUnknown.
				var carrier interface{ RendezvousDisposition() Disposition }
				if !errors.As(tt.err, &carrier) {
					t.Fatal("errors.As(truncated tree, disposition carrier) = false, want retryable carrier found")
				}
				if got := carrier.RendezvousDisposition(); got != DispositionRetryable {
					t.Fatalf("errors.As carrier disposition = %v, want node-local %v", got, DispositionRetryable)
				}
			}
		})
	}
}

type selfUnwrappingDispositionError struct{}

func (*selfUnwrappingDispositionError) Error() string {
	return "self cycle"
}

func (e *selfUnwrappingDispositionError) Unwrap() error {
	return e
}

type linkedDispositionError struct {
	message string
	next    error
}

func (e *linkedDispositionError) Error() string {
	return e.message
}

func (e *linkedDispositionError) Unwrap() error {
	return e.next
}

type nonComparableMultiCycleDispositionError struct {
	payload []int
}

func (e nonComparableMultiCycleDispositionError) Error() string {
	return fmt.Sprintf("non-comparable cycle %d", len(e.payload))
}

func (e nonComparableMultiCycleDispositionError) Unwrap() []error {
	return []error{e}
}

type highFanoutNonComparableDispositionError struct {
	payload []int
	fanout  int
	unwraps *atomic.Int64
}

func (e highFanoutNonComparableDispositionError) Error() string {
	return fmt.Sprintf("high-fanout non-comparable cycle %d", len(e.payload))
}

func (e highFanoutNonComparableDispositionError) Unwrap() []error {
	if e.unwraps != nil {
		e.unwraps.Add(1)
	}
	children := make([]error, e.fanout)
	for i := range children {
		children[i] = e
	}
	return children
}

type fixedChildrenDispositionError struct {
	children []error
}

func (fixedChildrenDispositionError) Error() string {
	return "fixed children"
}

func (e fixedChildrenDispositionError) Unwrap() []error {
	return e.children
}

type fanoutThenSpentDispositionError struct {
	cycle error
	spent error
}

func (fanoutThenSpentDispositionError) Error() string {
	return "fanout then spent"
}

func (e fanoutThenSpentDispositionError) Unwrap() []error {
	children := repeatedDispositionErrors(maxRendezvousDispositionChildren - 1)
	for i := range children {
		children[i] = e.cycle
	}
	return append(children, dispositionWrapperError{err: e.spent})
}

type dispositionWrapperError struct {
	err error
}

func (dispositionWrapperError) Error() string {
	return "disposition wrapper"
}

func (e dispositionWrapperError) Unwrap() error {
	return e.err
}

func repeatedDispositionErrors(count int) []error {
	errs := make([]error, count)
	for i := range errs {
		errs[i] = errors.New("padding")
	}
	return errs
}

func wrapDispositionError(err error, depth int) error {
	for range depth {
		err = dispositionWrapperError{err: err}
	}
	return err
}

type alwaysIsDispositionError struct{}

func (alwaysIsDispositionError) Error() string {
	return "always Is"
}

func (alwaysIsDispositionError) Is(error) bool {
	return true
}

type panickingDispositionCarrierError struct{}

func (panickingDispositionCarrierError) Error() string {
	return "panicking disposition"
}

func (panickingDispositionCarrierError) RendezvousDisposition() Disposition {
	panic("boom")
}

type panickingUnwrapDispositionError struct {
	hidden error
}

func (panickingUnwrapDispositionError) Error() string {
	return "panicking unwrap"
}

func (e panickingUnwrapDispositionError) Unwrap() error {
	panic(e.hidden)
}

type oneShotRendezvousTestAuthenticator struct {
	spends bool
}

func (a oneShotRendezvousTestAuthenticator) SuccessSpendsRendezvous() bool {
	return a.spends
}

func assertErrorStringDoesNotPanic(t *testing.T, err error) {
	t.Helper()
	defer func() {
		if recovered := recover(); recovered != nil {
			t.Fatalf("Error() panicked: %v", recovered)
		}
	}()
	_ = err.Error()
}
