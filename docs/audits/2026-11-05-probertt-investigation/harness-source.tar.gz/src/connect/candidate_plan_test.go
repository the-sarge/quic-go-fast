package connect

import (
	"net/netip"
	"testing"
)

func TestPlanLocalCandidatesClassifiesEmptyAndPolicyExcluded(t *testing.T) {
	empty := planLocalCandidates(nil, CandidatePolicy{})
	if empty.fallback != UpgradeFallbackNoCandidates {
		t.Fatalf("empty local plan fallback = %q, want %q", empty.fallback, UpgradeFallbackNoCandidates)
	}
	if len(empty.candidates) != 0 {
		t.Fatalf("empty local plan candidates = %#v, want none", empty.candidates)
	}

	candidate := gatheredCandidate{
		candidate:      Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:10000")},
		localInterface: "eth0",
	}
	excluded := planLocalCandidates([]gatheredCandidate{candidate}, CandidatePolicy{
		ExcludeLocalPrefixes: []netip.Prefix{netip.MustParsePrefix("192.0.2.0/24")},
	})
	if excluded.fallback != UpgradeFallbackPolicyExcluded {
		t.Fatalf("policy-excluded local plan fallback = %q, want %q", excluded.fallback, UpgradeFallbackPolicyExcluded)
	}
	if len(excluded.candidates) != 0 {
		t.Fatalf("policy-excluded local plan candidates = %#v, want none", excluded.candidates)
	}
}

func TestPlanLocalCandidatesOrdersBeforeCap(t *testing.T) {
	candidates := make([]gatheredCandidate, 0, upgradeControlMaxCandidates+10)
	for i := 1; i <= upgradeControlMaxCandidates; i++ {
		candidates = append(candidates, gatheredCandidate{
			candidate:      Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, netip.AddrPortFrom(netip.AddrFrom4([4]byte{10, 0, 1, byte(i)}), 10000).String())},
			localInterface: "eth0",
		})
	}
	for i := 1; i <= 10; i++ {
		candidates = append(candidates, gatheredCandidate{
			candidate:      Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, netip.AddrPortFrom(netip.AddrFrom4([4]byte{10, 0, 0, byte(i)}), 10000).String())},
			localInterface: "vpn0",
		})
	}

	plan := planLocalCandidates(candidates, CandidatePolicy{
		DeprioritizeLocalInterfaces: []string{"vpn0"},
	})
	if plan.fallback != UpgradeFallbackNone {
		t.Fatalf("local plan fallback = %q, want none", plan.fallback)
	}
	if len(plan.candidates) != upgradeControlMaxCandidates {
		t.Fatalf("local plan candidates = %d, want %d", len(plan.candidates), upgradeControlMaxCandidates)
	}
	// The fixture maps 10.0.0.x candidates to vpn0, which is deprioritized,
	// and 10.0.1.x candidates to eth0, which is preferred.
	for _, candidate := range plan.candidates {
		if netip.MustParsePrefix("10.0.0.0/24").Contains(candidate.Addr.Addr()) {
			t.Fatalf("deprioritized candidate survived cap: %#v", candidate)
		}
	}
}

func TestPlanLocalCandidatesKeepsDeprioritizedCandidatesBelowCap(t *testing.T) {
	candidates := []gatheredCandidate{
		{
			candidate:      Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.1:10000")},
			localInterface: "vpn0",
		},
		{
			candidate:      Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.1.1:10000")},
			localInterface: "eth0",
		},
		{
			candidate:      Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.2:10000")},
			localInterface: "vpn0",
		},
		{
			candidate:      Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.1.2:10000")},
			localInterface: "eth0",
		},
	}

	plan := planLocalCandidates(candidates, CandidatePolicy{
		DeprioritizeLocalInterfaces: []string{"vpn0"},
	})
	if plan.fallback != UpgradeFallbackNone {
		t.Fatalf("local plan fallback = %q, want none", plan.fallback)
	}
	if len(plan.candidates) != len(candidates) {
		t.Fatalf("local plan candidates = %d, want %d", len(plan.candidates), len(candidates))
	}
	// The fixture maps 10.0.0.x candidates to vpn0, which is deprioritized,
	// and 10.0.1.x candidates to eth0, which is preferred.
	deprioritizedPrefix := netip.MustParsePrefix("10.0.0.0/24")
	for i, candidate := range plan.candidates[:2] {
		if deprioritizedPrefix.Contains(candidate.Addr.Addr()) {
			t.Fatalf("candidate[%d] = %#v, want preferred candidate before deprioritized", i, candidate)
		}
	}
	for i, candidate := range plan.candidates[2:] {
		if !deprioritizedPrefix.Contains(candidate.Addr.Addr()) {
			t.Fatalf("candidate[%d] = %#v, want deprioritized candidate after preferred", i+2, candidate)
		}
	}
}

func TestPlanProbeCandidatePairsClassifiesEmptyPairs(t *testing.T) {
	local := []Candidate{{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:10000")}}
	remote := []Candidate{{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.9:20000")}}

	policyExcluded := planProbeCandidatePairs(local, remote, CandidatePolicy{
		ExcludeRemotePrefixes: []netip.Prefix{netip.MustParsePrefix("10.0.0.0/8")},
	}, upgradeRoleDial)
	if policyExcluded.fallback != UpgradeFallbackPolicyExcluded {
		t.Fatalf("policy-excluded pair plan fallback = %q, want %q", policyExcluded.fallback, UpgradeFallbackPolicyExcluded)
	}

	mixedFamily := planProbeCandidatePairs(
		local,
		[]Candidate{{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[2001:db8::20]:20000")}},
		CandidatePolicy{},
		upgradeRoleDial,
	)
	if mixedFamily.fallback != UpgradeFallbackProbeFailed {
		t.Fatalf("mixed-family pair plan fallback = %q, want %q", mixedFamily.fallback, UpgradeFallbackProbeFailed)
	}
}

func TestPlanProbeCandidatePairsAllowsSelectedPairByRole(t *testing.T) {
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:10000")}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.20:20000")}
	listenerPlan := planProbeCandidatePairs(
		[]Candidate{listenerCandidate},
		[]Candidate{dialerCandidate},
		CandidatePolicy{},
		upgradeRoleListen,
	)
	if listenerPlan.fallback != UpgradeFallbackNone {
		t.Fatalf("listener pair plan fallback = %q, want none", listenerPlan.fallback)
	}

	selected := selectedPair{
		dialer:   dialerCandidate,
		listener: listenerCandidate,
	}
	if !listenerPlan.allowsSelectedPair(selected) {
		t.Fatalf("listener pair plan rejected selected pair %#v", selected)
	}

	swapped := selectedPair{
		dialer:   listenerCandidate,
		listener: dialerCandidate,
	}
	if listenerPlan.allowsSelectedPair(swapped) {
		t.Fatalf("listener pair plan allowed swapped selected pair %#v", swapped)
	}

	dialerPlan := planProbeCandidatePairs(
		[]Candidate{dialerCandidate},
		[]Candidate{listenerCandidate},
		CandidatePolicy{},
		upgradeRoleDial,
	)
	if dialerPlan.fallback != UpgradeFallbackNone {
		t.Fatalf("dialer pair plan fallback = %q, want none", dialerPlan.fallback)
	}
	if !dialerPlan.allowsSelectedPair(selected) {
		t.Fatalf("dialer pair plan rejected selected pair %#v", selected)
	}
	if dialerPlan.allowsSelectedPair(swapped) {
		t.Fatalf("dialer pair plan allowed swapped selected pair %#v", swapped)
	}

	invalidRolePlan := candidatePairPlan{
		role:  upgradeRole(99),
		pairs: []probeCandidatePair{{local: dialerCandidate, remote: listenerCandidate}},
	}
	if invalidRolePlan.allowsSelectedPair(selected) {
		t.Fatalf("invalid-role pair plan allowed selected pair %#v", selected)
	}
}
