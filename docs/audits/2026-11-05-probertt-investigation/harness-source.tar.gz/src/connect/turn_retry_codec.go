package connect

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"time"
)

const (
	turnRetryVersion = uint64(1)

	turnRetryMessageStart     = uint64(1)
	turnRetryMessageOffer     = uint64(2)
	turnRetryMessageFallback  = uint64(3)
	turnRetryMessageSelected  = uint64(4)
	turnRetryMessageReady     = uint64(5)
	turnRetryMessageCommit    = uint64(6)
	turnRetryMessageAccepted  = uint64(7)
	turnRetryMessageConverged = uint64(8)
	turnRetryMessageConfirmed = uint64(9)

	turnRetryKeyType              = uint64(0)
	turnRetryKeyVersion           = uint64(1)
	turnRetryKeyExtensions        = uint64(2)
	turnRetryKeyCandidate         = uint64(10)
	turnRetryKeyPacketProfile     = uint64(11)
	turnRetryKeyProbeNonce        = uint64(12)
	turnRetryKeyFallbackReason    = uint64(20)
	turnRetryKeyDialerCandidate   = uint64(30)
	turnRetryKeyListenerCandidate = uint64(31)
	turnRetryKeyProbeRTTNanos     = uint64(32)

	turnRetryCandidateKindRelayCode = uint64(3)
	turnRetryPacketProfileQUIC3     = uint64(1)

	turnRetryMaxPayload  = 8192
	turnRetryMaxMapPairs = 8
)

var (
	errTurnRetryFrameEmpty                = errors.New("connect: turn-retry frame is empty")
	errTurnRetryFrameOversize             = errors.New("connect: turn-retry frame is too large")
	errUnsupportedTurnRetryFallbackReason = errors.New("connect: unsupported turn-retry fallback reason")
)

type turnRetryOffer struct {
	candidate     Candidate
	packetProfile uint64
	probeNonce    []byte
}

type turnRetrySelected struct {
	dialer   Candidate
	listener Candidate
	rtt      time.Duration
}

type turnRetryFallback struct {
	Reason UpgradeFallbackReason
}

func encodeTurnRetryStart() ([]byte, error) {
	return encodeTurnRetryEmptyMessage(turnRetryMessageStart)
}

func encodeTurnRetryReady() ([]byte, error) {
	return encodeTurnRetryEmptyMessage(turnRetryMessageReady)
}

func encodeTurnRetryCommit() ([]byte, error) {
	return encodeTurnRetryEmptyMessage(turnRetryMessageCommit)
}

func encodeTurnRetryAccepted(datagrams bool) ([]byte, error) {
	return encodeTurnRetryPostCommitMessage(turnRetryMessageAccepted, datagrams)
}

func encodeTurnRetryConverged(datagrams bool) ([]byte, error) {
	return encodeTurnRetryPostCommitMessage(turnRetryMessageConverged, datagrams)
}

func encodeTurnRetryConfirmed(datagrams bool) ([]byte, error) {
	return encodeTurnRetryPostCommitMessage(turnRetryMessageConfirmed, datagrams)
}

func encodeTurnRetryEmptyMessage(messageType uint64) ([]byte, error) {
	switch messageType {
	case turnRetryMessageStart, turnRetryMessageReady, turnRetryMessageCommit:
	default:
		return nil, fmt.Errorf("connect: unsupported turn-retry empty message type %d", messageType)
	}
	payload, err := encMode.Marshal(map[uint64]uint64{
		turnRetryKeyType:    messageType,
		turnRetryKeyVersion: turnRetryVersion,
	})
	if err != nil {
		return nil, err
	}
	return encodeTurnRetryFramePayload(payload)
}

func encodeTurnRetryPostCommitMessage(messageType uint64, datagrams bool) ([]byte, error) {
	switch messageType {
	case turnRetryMessageAccepted, turnRetryMessageConverged, turnRetryMessageConfirmed:
	default:
		return nil, fmt.Errorf("connect: unsupported turn-retry post-commit message type %d", messageType)
	}
	message := map[uint64]any{
		turnRetryKeyType:    messageType,
		turnRetryKeyVersion: turnRetryVersion,
	}
	if datagrams {
		message[turnRetryKeyExtensions] = map[string]bool{upgradeControlDatagramExtension: true}
	}
	payload, err := encMode.Marshal(message)
	if err != nil {
		return nil, err
	}
	return encodeTurnRetryFramePayload(payload)
}

func encodeTurnRetryOffer(offer turnRetryOffer) ([]byte, error) {
	if err := validateTurnRetryOffer(offer); err != nil {
		return nil, err
	}
	candidate, err := encodeTurnRetryCandidate(offer.candidate)
	if err != nil {
		return nil, err
	}
	payload, err := encMode.Marshal(map[uint64]any{
		turnRetryKeyType:          turnRetryMessageOffer,
		turnRetryKeyVersion:       turnRetryVersion,
		turnRetryKeyCandidate:     candidate,
		turnRetryKeyPacketProfile: offer.packetProfile,
		turnRetryKeyProbeNonce:    append([]byte(nil), offer.probeNonce...),
	})
	if err != nil {
		return nil, err
	}
	return encodeTurnRetryFramePayload(payload)
}

func encodeTurnRetryFallback(reason UpgradeFallbackReason) ([]byte, error) {
	wire, ok := fallbackReasonToWireForPhase(reason, fallbackReasonPhaseRetryTerminal)
	if !ok {
		return nil, fmt.Errorf("%w: %q", errUnsupportedTurnRetryFallbackReason, reason)
	}
	payload, err := encMode.Marshal(map[uint64]uint64{
		turnRetryKeyType:           turnRetryMessageFallback,
		turnRetryKeyVersion:        turnRetryVersion,
		turnRetryKeyFallbackReason: wire,
	})
	if err != nil {
		return nil, err
	}
	return encodeTurnRetryFramePayload(payload)
}

func encodeTurnRetrySelected(selected turnRetrySelected) ([]byte, error) {
	if err := validateTurnRetrySelected(selected); err != nil {
		return nil, err
	}
	dialer, err := encodeTurnRetryCandidate(selected.dialer)
	if err != nil {
		return nil, err
	}
	listener, err := encodeTurnRetryCandidate(selected.listener)
	if err != nil {
		return nil, err
	}
	fields := map[uint64]any{
		turnRetryKeyType:              turnRetryMessageSelected,
		turnRetryKeyVersion:           turnRetryVersion,
		turnRetryKeyDialerCandidate:   dialer,
		turnRetryKeyListenerCandidate: listener,
	}
	if selected.rtt > 0 {
		fields[turnRetryKeyProbeRTTNanos] = positiveDurationNanos(selected.rtt)
	}
	payload, err := encMode.Marshal(fields)
	if err != nil {
		return nil, err
	}
	return encodeTurnRetryFramePayload(payload)
}

func encodeTurnRetryFramePayload(payload []byte) ([]byte, error) {
	if len(payload) == 0 {
		return nil, errTurnRetryFrameEmpty
	}
	if len(payload) > turnRetryMaxPayload {
		return nil, errTurnRetryFrameOversize
	}
	frame := make([]byte, 4+len(payload))
	binary.BigEndian.PutUint32(frame[:4], uint32(len(payload))) // #nosec G115 -- bounded by turnRetryMaxPayload.
	copy(frame[4:], payload)
	return frame, nil
}

func validateTurnRetryOffer(offer turnRetryOffer) error {
	if offer.packetProfile != turnRetryPacketProfileQUIC3 {
		return fmt.Errorf("connect: unsupported turn-retry packet profile %d", offer.packetProfile)
	}
	if len(offer.probeNonce) != upgradeControlProbeNonceBytes {
		return fmt.Errorf("connect: turn-retry probe nonce must be %d bytes", upgradeControlProbeNonceBytes)
	}
	if _, err := encodeTurnRetryCandidate(offer.candidate); err != nil {
		return err
	}
	return nil
}

func validateTurnRetrySelected(selected turnRetrySelected) error {
	if _, err := encodeTurnRetryCandidate(selected.dialer); err != nil {
		return fmt.Errorf("connect: turn-retry dialer candidate: %w", err)
	}
	if _, err := encodeTurnRetryCandidate(selected.listener); err != nil {
		return fmt.Errorf("connect: turn-retry listener candidate: %w", err)
	}
	if selected.rtt < 0 {
		return fmt.Errorf("connect: turn-retry selected pair probe RTT must not be negative")
	}
	if selected.rtt > 0 && positiveDurationNanos(selected.rtt) > upgradeControlMaxProbeRTTNanos {
		return fmt.Errorf("connect: turn-retry selected pair probe RTT is out of range")
	}
	return nil
}

func encodeTurnRetryCandidate(candidate Candidate) (map[uint64]any, error) {
	if candidate.Kind != CandidateKindRelay {
		return nil, fmt.Errorf("connect: unsupported turn-retry candidate kind: %w: %q", errUnsupportedCandidateKind, candidate.Kind)
	}
	addrPort, ok := encodeCandidateAddrPort(candidate.Addr)
	if !ok {
		return nil, fmt.Errorf("connect: invalid turn-retry candidate address %s", candidate.Addr)
	}
	return map[uint64]any{
		upgradeControlCandidateKeyKind:     turnRetryCandidateKindRelayCode,
		upgradeControlCandidateKeyAddrPort: addrPort,
	}, nil
}

func decodeTurnRetryStart(payload []byte) bool {
	return decodeTurnRetryEmptyMessage(payload, turnRetryMessageStart)
}

func decodeTurnRetryReady(payload []byte) bool {
	return decodeTurnRetryEmptyMessage(payload, turnRetryMessageReady)
}

func decodeTurnRetryCommit(payload []byte) bool {
	return decodeTurnRetryEmptyMessage(payload, turnRetryMessageCommit)
}

func decodeTurnRetryEmptyMessage(payload []byte, wantType uint64) bool {
	fieldValues, messageType, ok := decodeTurnRetryCommonFields(payload)
	if !ok || messageType != wantType {
		return false
	}
	return keysAreExactly(fieldValues, map[uint64]struct{}{
		turnRetryKeyType:    {},
		turnRetryKeyVersion: {},
	})
}

func decodeTurnRetryAccepted(payload []byte) (bool, bool) {
	return decodeTurnRetryPostCommit(payload, turnRetryMessageAccepted)
}

func decodeTurnRetryConverged(payload []byte) (bool, bool) {
	return decodeTurnRetryPostCommit(payload, turnRetryMessageConverged)
}

func decodeTurnRetryConfirmed(payload []byte) (bool, bool) {
	return decodeTurnRetryPostCommit(payload, turnRetryMessageConfirmed)
}

func decodeTurnRetryPostCommit(payload []byte, wantType uint64) (datagrams bool, ok bool) {
	fieldValues, messageType, ok := decodeTurnRetryCommonFields(payload)
	if !ok || messageType != wantType {
		return false, false
	}
	if !keysAreAllowed(fieldValues, map[uint64]struct{}{
		turnRetryKeyType:       {},
		turnRetryKeyVersion:    {},
		turnRetryKeyExtensions: {},
	}) {
		return false, false
	}
	extensions, present := fieldValues[turnRetryKeyExtensions]
	if !present {
		return false, true
	}
	return decodeTurnRetryDatagramExtensionExact(extensions)
}

func decodeTurnRetryOffer(payload []byte) (turnRetryOffer, bool) {
	fieldValues, messageType, ok := decodeTurnRetryCommonFields(payload)
	if !ok || messageType != turnRetryMessageOffer {
		return turnRetryOffer{}, false
	}
	if !keysAreExactly(fieldValues, map[uint64]struct{}{
		turnRetryKeyType:          {},
		turnRetryKeyVersion:       {},
		turnRetryKeyCandidate:     {},
		turnRetryKeyPacketProfile: {},
		turnRetryKeyProbeNonce:    {},
	}) {
		return turnRetryOffer{}, false
	}
	candidate, ok := decodeTurnRetryCandidate(fieldValues[turnRetryKeyCandidate])
	if !ok {
		return turnRetryOffer{}, false
	}
	profile, ok := decodeUint(fieldValues[turnRetryKeyPacketProfile])
	if !ok || profile != turnRetryPacketProfileQUIC3 {
		return turnRetryOffer{}, false
	}
	nonce, ok := decodeBytes(fieldValues[turnRetryKeyProbeNonce], upgradeControlProbeNonceBytes)
	if !ok || len(nonce) != upgradeControlProbeNonceBytes {
		return turnRetryOffer{}, false
	}
	return turnRetryOffer{
		candidate:     candidate,
		packetProfile: profile,
		probeNonce:    append([]byte(nil), nonce...),
	}, true
}

func decodeTurnRetryFallback(payload []byte) (turnRetryFallback, bool) {
	fieldValues, messageType, ok := decodeTurnRetryCommonFields(payload)
	if !ok || messageType != turnRetryMessageFallback {
		return turnRetryFallback{}, false
	}
	if !keysAreExactly(fieldValues, map[uint64]struct{}{
		turnRetryKeyType:           {},
		turnRetryKeyVersion:        {},
		turnRetryKeyFallbackReason: {},
	}) {
		return turnRetryFallback{}, false
	}
	reasonValue, ok := decodeUint(fieldValues[turnRetryKeyFallbackReason])
	if !ok {
		return turnRetryFallback{}, false
	}
	reason, ok := fallbackReasonFromWireForPhase(reasonValue, fallbackReasonPhaseRetryTerminal)
	if !ok {
		return turnRetryFallback{}, false
	}
	return turnRetryFallback{Reason: reason}, true
}

func decodeTurnRetrySelected(payload []byte) (turnRetrySelected, bool) {
	fieldValues, messageType, ok := decodeTurnRetryCommonFields(payload)
	if !ok || messageType != turnRetryMessageSelected {
		return turnRetrySelected{}, false
	}
	if !keysAreAllowed(fieldValues, map[uint64]struct{}{
		turnRetryKeyType:              {},
		turnRetryKeyVersion:           {},
		turnRetryKeyDialerCandidate:   {},
		turnRetryKeyListenerCandidate: {},
		turnRetryKeyProbeRTTNanos:     {},
	}) {
		return turnRetrySelected{}, false
	}
	if _, ok := fieldValues[turnRetryKeyDialerCandidate]; !ok {
		return turnRetrySelected{}, false
	}
	if _, ok := fieldValues[turnRetryKeyListenerCandidate]; !ok {
		return turnRetrySelected{}, false
	}
	if _, ok := fieldValues[turnRetryKeyExtensions]; ok {
		return turnRetrySelected{}, false
	}
	dialer, ok := decodeTurnRetryCandidate(fieldValues[turnRetryKeyDialerCandidate])
	if !ok {
		return turnRetrySelected{}, false
	}
	listener, ok := decodeTurnRetryCandidate(fieldValues[turnRetryKeyListenerCandidate])
	if !ok {
		return turnRetrySelected{}, false
	}
	selected := turnRetrySelected{dialer: dialer, listener: listener}
	if rttPayload, present := fieldValues[turnRetryKeyProbeRTTNanos]; present {
		rtt, ok := decodeUint(rttPayload)
		if !ok || rtt == 0 || rtt > upgradeControlMaxProbeRTTNanos {
			return turnRetrySelected{}, false
		}
		selected.rtt = time.Duration(rtt)
	}
	required := 4
	if _, present := fieldValues[turnRetryKeyProbeRTTNanos]; present {
		required = 5
	}
	if len(fieldValues) != required {
		return turnRetrySelected{}, false
	}
	return selected, true
}

// decodeTurnRetryCommonFields is the single owner of the retry profile's
// payload bound: every retry decoder enters through it, so no payload longer
// than turnRetryMaxPayload reaches retry semantics. Callers do not repeat the
// check.
func decodeTurnRetryCommonFields(payload []byte) (map[uint64][]byte, uint64, bool) {
	if len(payload) == 0 || len(payload) > turnRetryMaxPayload {
		return nil, 0, false
	}
	if err := decMode.Wellformed(payload); err != nil {
		return nil, 0, false
	}
	entries, end, err := scanCBORMapEntries(payload, 0, turnRetryScanOptions(), 0)
	if err != nil || end != len(payload) {
		return nil, 0, false
	}
	fieldValues := make(map[uint64][]byte, len(entries))
	for _, field := range entries {
		fieldValues[field.key] = field.valueRaw
	}
	messageType, ok := decodeUint(fieldValues[turnRetryKeyType])
	if !ok {
		return nil, 0, false
	}
	version, ok := decodeUint(fieldValues[turnRetryKeyVersion])
	if !ok || version != turnRetryVersion {
		return nil, 0, false
	}
	return fieldValues, messageType, true
}

func decodeTurnRetryCandidate(payload []byte) (Candidate, bool) {
	entries, end, err := scanCBORMapEntries(payload, 0, cborScanOptions{
		maxArrayElements: 0,
		maxMapPairs:      2,
		maxStringBytes:   upgradeControlMaxStringBytes,
		maxNest:          maxPayloadNest,
	}, 0)
	if err != nil || end != len(payload) {
		return Candidate{}, false
	}
	fieldValues := make(map[uint64][]byte, len(entries))
	for _, entry := range entries {
		fieldValues[entry.key] = entry.valueRaw
	}
	if len(fieldValues) != 2 {
		return Candidate{}, false
	}
	kindValue, ok := decodeUint(fieldValues[upgradeControlCandidateKeyKind])
	if !ok || kindValue != turnRetryCandidateKindRelayCode {
		return Candidate{}, false
	}
	addrPort, ok := decodeBytes(fieldValues[upgradeControlCandidateKeyAddrPort], candidateAddrPortIPv6Bytes)
	if !ok {
		return Candidate{}, false
	}
	addr, ok := decodeCandidateAddrPort(addrPort)
	if !ok {
		return Candidate{}, false
	}
	return Candidate{Kind: CandidateKindRelay, Addr: addr}, true
}

func decodeTurnRetryDatagramExtensionExact(payload []byte) (bool, bool) {
	entries, end, err := scanCBORRawMapEntries(payload, 0, cborScanOptions{
		maxArrayElements: 0,
		maxMapPairs:      1,
		maxStringBytes:   maxExtensionMapBytes,
		maxNest:          maxExtensionValueNest,
	}, 0)
	if err != nil || end != len(payload) || len(entries) != 1 {
		return false, false
	}
	key, ok := decodeText(entries[0].keyRaw, maxExtensionMapBytes)
	if !ok || key != upgradeControlDatagramExtension {
		return false, false
	}
	if !bytes.Equal(entries[0].valueRaw, []byte{0xf5}) {
		return false, false
	}
	return true, true
}

func turnRetryScanOptions() cborScanOptions {
	return cborScanOptions{
		maxArrayElements: 0,
		maxMapPairs:      turnRetryMaxMapPairs,
		maxStringBytes:   upgradeControlMaxStringBytes,
		maxNest:          maxPayloadNest,
	}
}

func keysAreExactly(fieldValues map[uint64][]byte, required map[uint64]struct{}) bool {
	if len(fieldValues) != len(required) {
		return false
	}
	return keysAreAllowed(fieldValues, required)
}
