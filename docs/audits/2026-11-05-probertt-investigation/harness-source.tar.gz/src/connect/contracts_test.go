package connect

import (
	"bytes"
	"errors"
	"testing"
)

func TestTransportAuthExposesNoDirectionalChannelKeys(t *testing.T) {
	binding := []byte("transport-auth-binding")
	auth := transportAuthFixture{
		binding: binding,
		exporter: NewHKDFKeyExporter(
			[]byte("transport-auth-master-secret"),
			binding,
		),
	}
	var transportAuth TransportAuth = auth

	if _, ok := any(transportAuth).(AuthContext); ok {
		t.Fatal("TransportAuth unexpectedly satisfies AuthContext")
	}
	got, err := transportAuth.SessionBinding()
	if err != nil {
		t.Fatalf("SessionBinding: %v", err)
	}
	if !bytes.Equal(got, binding) {
		t.Fatalf("SessionBinding = %q, want %q", got, binding)
	}
	if transportAuth.Exporter() == nil {
		t.Fatal("Exporter returned nil")
	}
}

func TestLegacyTransportAuthExporterIsAlwaysNonNil(t *testing.T) {
	auth := testAuthContext()
	auth.exporter = nil
	transportAuth := transportAuthFor(auth)
	exporter := transportAuth.Exporter()
	if exporter == nil {
		t.Fatal("TransportAuth.Exporter = nil")
	}
	if _, err := exporter.Derive("malformed", nil, 16); !errors.Is(err, ErrNilKeyExporter) {
		t.Fatalf("TransportAuth exporter error = %v, want %v", err, ErrNilKeyExporter)
	}
}

type transportAuthFixture struct {
	binding  []byte
	exporter KeyExporter
}

func (a transportAuthFixture) SessionBinding() ([]byte, error) {
	return append([]byte(nil), a.binding...), nil
}

func (a transportAuthFixture) Exporter() KeyExporter {
	return a.exporter
}
