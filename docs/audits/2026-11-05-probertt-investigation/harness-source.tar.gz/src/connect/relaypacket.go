package connect

import (
	"context"
	"net"
	"net/netip"
)

// RelayPacketAllocator produces relay-backed packet connections. An
// implementation is immutable and concurrently reusable; each Allocate call
// owns an independent underlying socket and relay allocation.
//
// Any non-nil Allocate result is caller-owned even when accompanied by a
// non-nil error and must be closed. An in-flight Allocate observes context
// cancellation promptly but returns only after all partial work is disposed
// and joined; the official implementation returns nil on every error and
// preserves the exact cancellation cause in its error tree.
type RelayPacketAllocator interface {
	Allocate(context.Context) (RelayPacketConn, error)
}

// RelayPacketConn is a relay-backed packet connection restricted to exactly
// one prepared peer.
//
// PreparePeer atomically selects one canonical peer: it accepts only a valid
// nonzero-port address that is neither unspecified nor multicast and has no
// zone, canonicalizes IPv4-mapped input, coalesces same-peer callers, and
// rejects a different peer. Canceling one waiter wakes only that waiter with
// its exact cause. PreparePeer never transfers ownership.
//
// Close is idempotent and concurrent-safe: it seals new operations, unblocks
// and joins all registered work, and always returns one stable aggregate
// result. Close may consume the implementation's bounded graceful window
// plus forced/intermediate join time.
type RelayPacketConn interface {
	net.PacketConn
	PreparePeer(context.Context, netip.AddrPort) error
}
