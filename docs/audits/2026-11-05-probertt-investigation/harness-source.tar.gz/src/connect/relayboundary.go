package connect

import (
	"errors"
	"net"

	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// ErrRelayProfileDirectPath reports that an official wiremux relay packet
// composite was offered to a generic direct packet path: exported Gather,
// the upgrade packet-conn option, or a root direct option. The composite is
// reserved for the exclusive relay transport profile and must not be
// classified as a direct host candidate; the built-in QUIC session consumes
// the same marker to select that profile.
var ErrRelayProfileDirectPath = errors.New("connect: official relay composite cannot be used as a direct packet path")

// packetConnBearsRelayProfile reports whether conn is an official relay
// packet composite. relayprofile owns marker validity.
func packetConnBearsRelayProfile(conn net.PacketConn) bool {
	return relayprofile.IsTURNQUIC3(conn)
}
