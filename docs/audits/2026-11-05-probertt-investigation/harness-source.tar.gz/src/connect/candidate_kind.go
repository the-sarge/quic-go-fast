package connect

type candidateKindSemantics struct {
	recognized     bool
	preferenceRank int
	direct         bool
	relay          bool
}

func classifyCandidateKind(kind CandidateKind) candidateKindSemantics {
	switch kind {
	case CandidateKindHost:
		return candidateKindSemantics{recognized: true, preferenceRank: 0, direct: true}
	case CandidateKindReflexive:
		return candidateKindSemantics{recognized: true, preferenceRank: 1, direct: true}
	case CandidateKindRelay:
		return candidateKindSemantics{recognized: true, preferenceRank: 2, relay: true}
	default:
		return candidateKindSemantics{preferenceRank: 3}
	}
}
