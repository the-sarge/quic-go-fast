package connect

import (
	"context"
	"errors"
	"strings"
	"testing"
	"time"
)

// TestTurnRetryStageErrorPreservesChainAndNamesStage pins the stage-label
// contract: nil passes through, sentinel and context matching survive the
// wrap, and the message names the stage so a #1218-style stall report
// identifies the step that consumed the retry budget.
func TestTurnRetryStageErrorPreservesChainAndNamesStage(t *testing.T) {
	if err := turnRetryStageError(turnRetryStageProbe, nil); err != nil {
		t.Fatalf("turnRetryStageError(nil) = %v, want nil", err)
	}

	wrapped := turnRetryStageError(turnRetryStagePeerPreparation, ErrUpgradeControlTimeout)
	if !errors.Is(wrapped, ErrUpgradeControlTimeout) {
		t.Fatalf("wrapped error = %v, want errors.Is ErrUpgradeControlTimeout", wrapped)
	}
	if !strings.Contains(wrapped.Error(), string(turnRetryStagePeerPreparation)) {
		t.Fatalf("wrapped error = %q, want stage %q in message", wrapped.Error(), turnRetryStagePeerPreparation)
	}

	deadline := turnRetryStageError(turnRetryStageAllocation, context.DeadlineExceeded)
	if !errors.Is(deadline, context.DeadlineExceeded) {
		t.Fatalf("wrapped deadline error = %v, want errors.Is context.DeadlineExceeded", deadline)
	}
}

// TestTurnRetryStageErrorGuardedLeavesOuterCancellationUnlabeled pins the
// outer-cancellation rule at its enforcement owner: caller-driven
// termination returns the bare context error with no stage label, while a
// retry-path failure under a live outer context is labeled.
func TestTurnRetryStageErrorGuardedLeavesOuterCancellationUnlabeled(t *testing.T) {
	e := &turnRetryEngine{stage: turnRetryStageOfferExchange}

	canceled, cancel := context.WithCancel(context.Background())
	cancel()
	got := e.stageErrorGuarded(canceled, ErrUpgradeControlTimeout)
	if !errors.Is(got, context.Canceled) {
		t.Fatalf("guarded error under canceled outer context = %v, want context.Canceled", got)
	}
	if strings.Contains(got.Error(), "turn retry failed during") {
		t.Fatalf("guarded error under canceled outer context = %q, want no stage label", got.Error())
	}

	live := context.Background()
	got = e.stageErrorGuarded(live, ErrUpgradeControlTimeout)
	if !errors.Is(got, ErrUpgradeControlTimeout) {
		t.Fatalf("guarded error under live outer context = %v, want errors.Is ErrUpgradeControlTimeout", got)
	}
	if !strings.Contains(got.Error(), string(turnRetryStageOfferExchange)) {
		t.Fatalf("guarded error under live outer context = %q, want stage %q labeled", got.Error(), turnRetryStageOfferExchange)
	}
}

// TestTurnRetryFamilySentinelsWrapTransportNotConverged pins the two internal
// family causes that replaced nil-cause fail-closed exits (issue #1270): each
// is stable, unexported, and wraps the public sentinel so existing
// ErrUpgradeTransportNotConverged matches keep holding once a stage label is
// layered on top.
func TestTurnRetryFamilySentinelsWrapTransportNotConverged(t *testing.T) {
	for name, sentinel := range map[string]error{
		"convergence malformed": errTurnRetryConvergenceMalformed,
		"transferred resource":  errTurnRetryTransferredResource,
	} {
		t.Run(name, func(t *testing.T) {
			if !errors.Is(sentinel, ErrUpgradeTransportNotConverged) {
				t.Fatalf("family sentinel = %v, want errors.Is ErrUpgradeTransportNotConverged", sentinel)
			}
			if !strings.HasPrefix(sentinel.Error(), "connect: ") {
				t.Fatalf("family sentinel = %q, want connect: prefix", sentinel.Error())
			}
			labeled := turnRetryStageError(turnRetryStagePostCommit, sentinel)
			if !errors.Is(labeled, sentinel) || !errors.Is(labeled, ErrUpgradeTransportNotConverged) {
				t.Fatalf("labeled family error = %v, want both the family sentinel and ErrUpgradeTransportNotConverged", labeled)
			}
			if !strings.Contains(labeled.Error(), string(turnRetryStagePostCommit)) {
				t.Fatalf("labeled family error = %q, want stage %q in message", labeled.Error(), turnRetryStagePostCommit)
			}
		})
	}
}

// TestTurnRetryMismatchStageLabelKeepsSentinelWithoutNotConverged pins the
// Datagram exposure mismatch wrapping rule: the stage label is additive, the
// phase-specific sentinel still matches, and the chain does not newly gain
// ErrUpgradeTransportNotConverged.
func TestTurnRetryMismatchStageLabelKeepsSentinelWithoutNotConverged(t *testing.T) {
	e := &turnRetryEngine{stage: turnRetryStagePostCommit}
	got := e.stageError(errDatagramExposureAgreementMismatch)
	if !errors.Is(got, errDatagramExposureAgreementMismatch) {
		t.Fatalf("labeled mismatch = %v, want errors.Is errDatagramExposureAgreementMismatch", got)
	}
	if errors.Is(got, ErrUpgradeTransportNotConverged) {
		t.Fatalf("labeled mismatch = %v, want no ErrUpgradeTransportNotConverged in chain", got)
	}
	if !strings.Contains(got.Error(), string(turnRetryStagePostCommit)) {
		t.Fatalf("labeled mismatch = %q, want stage %q in message", got.Error(), turnRetryStagePostCommit)
	}
}

// TestTurnRetrySettlePreemptedLabelsRetryInternalFailuresOnly pins the
// preempted-settlement rule (issue #1270): the encode and Fallback-write
// failure exits carry the caller-supplied stage while an ended outer context
// still returns the bare context error.
func TestTurnRetrySettlePreemptedLabelsRetryInternalFailuresOnly(t *testing.T) {
	newAttempt := func(t *testing.T, write func([]byte) (int, error)) directUpgradeAttempt {
		t.Helper()
		channel := newScriptedControlChannel(nil, true)
		channel.writeScript = write
		t.Cleanup(func() { _ = channel.Close() })
		return directUpgradeAttempt{
			channel:       channel,
			cfg:           testUpgradeConfig(t, WithUpgradeControlTimeout(50*time.Millisecond)),
			controlFrames: newControlFrameSequencer(channel),
			owner:         newAttemptResources(channel, nil),
		}
	}
	const stage = turnRetryStagePeerPreparation
	assertLabeled := func(t *testing.T, err error, sentinel error) {
		t.Helper()
		if !errors.Is(err, sentinel) {
			t.Fatalf("settle error = %v, want errors.Is %v", err, sentinel)
		}
		if !strings.Contains(err.Error(), string(stage)) {
			t.Fatalf("settle error = %q, want stage %q labeled", err.Error(), stage)
		}
	}

	t.Run("write failure is labeled", func(t *testing.T) {
		writeFailure := errors.New("scripted write failure")
		a := newAttempt(t, func([]byte) (int, error) { return 0, writeFailure })
		_, err := a.turnRetrySettlePreempted(context.Background(), stage, UpgradeFallbackNone, UpgradeFallbackProbeFailed)
		assertLabeled(t, err, writeFailure)
	})

	t.Run("blocked write control timeout is labeled", func(t *testing.T) {
		release := make(chan struct{})
		t.Cleanup(func() { close(release) })
		a := newAttempt(t, func(p []byte) (int, error) { <-release; return len(p), nil })
		_, err := a.turnRetrySettlePreempted(context.Background(), stage, UpgradeFallbackNone, UpgradeFallbackProbeFailed)
		assertLabeled(t, err, ErrUpgradeControlTimeout)
	})

	t.Run("encode failure is labeled", func(t *testing.T) {
		a := newAttempt(t, func(p []byte) (int, error) { return len(p), nil })
		_, err := a.turnRetrySettlePreempted(context.Background(), stage, UpgradeFallbackReason("unencodable-reason"), UpgradeFallbackProbeFailed)
		if err == nil {
			t.Fatal("settle with unencodable reason succeeded, want encode failure")
		}
		if !strings.Contains(err.Error(), string(stage)) {
			t.Fatalf("encode failure = %q, want stage %q labeled", err.Error(), stage)
		}
	})

	t.Run("ended outer context stays bare", func(t *testing.T) {
		writeFailure := errors.New("scripted write failure")
		a := newAttempt(t, func([]byte) (int, error) { return 0, writeFailure })
		ctx, cancel := context.WithCancel(context.Background())
		cancel()
		_, err := a.turnRetrySettlePreempted(ctx, stage, UpgradeFallbackNone, UpgradeFallbackProbeFailed)
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("settle error under canceled outer context = %v, want context.Canceled", err)
		}
		if strings.Contains(err.Error(), "turn retry failed during") {
			t.Fatalf("settle error under canceled outer context = %q, want no stage label", err.Error())
		}
	})
}

// TestTurnRetryTerminalFallbackExchangeLabelsEncodeFailureOnly pins the
// terminal-exchange rule (issue #1280): the Fallback encode failure exit
// carries the caller-supplied stage while preserving the underlying error
// and still disposing the composite, and an ended outer context still
// returns the bare context error.
func TestTurnRetryTerminalFallbackExchangeLabelsEncodeFailureOnly(t *testing.T) {
	newAttempt := func(t *testing.T) directUpgradeAttempt {
		t.Helper()
		channel := newScriptedControlChannel(nil, true)
		channel.writeScript = func(p []byte) (int, error) { return len(p), nil }
		t.Cleanup(func() { _ = channel.Close() })
		return directUpgradeAttempt{
			channel:       channel,
			cfg:           testUpgradeConfig(t, WithUpgradeControlTimeout(50*time.Millisecond)),
			controlFrames: newControlFrameSequencer(channel),
			owner:         newAttemptResources(channel, nil),
		}
	}
	const stage = turnRetryStagePeerPreparation
	const unencodable = UpgradeFallbackReason("unencodable-reason")

	t.Run("encode failure is labeled and disposes", func(t *testing.T) {
		a := newAttempt(t)
		disposed := 0
		_, err := a.turnRetryTerminalFallbackExchange(context.Background(), stage, unencodable, UpgradeFallbackProbeFailed, func() { disposed++ })
		if !errors.Is(err, errUnsupportedTurnRetryFallbackReason) {
			t.Fatalf("exchange with unencodable reason = %v, want errors.Is errUnsupportedTurnRetryFallbackReason", err)
		}
		if !strings.Contains(err.Error(), string(stage)) {
			t.Fatalf("encode failure = %q, want stage %q labeled", err.Error(), stage)
		}
		if disposed != 1 {
			t.Fatalf("dispose calls = %d, want 1", disposed)
		}
	})

	t.Run("ended outer context stays bare", func(t *testing.T) {
		a := newAttempt(t)
		ctx, cancel := context.WithCancel(context.Background())
		cancel()
		_, err := a.turnRetryTerminalFallbackExchange(ctx, stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {})
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("exchange error under canceled outer context = %v, want context.Canceled", err)
		}
		if strings.Contains(err.Error(), "turn retry failed during") {
			t.Fatalf("exchange error under canceled outer context = %q, want no stage label", err.Error())
		}
	})
}

// TestTurnRetryStagePostCommitCauseLabelsBudgetNotOuterCancellation pins the
// post-commit cause selection: outer-context termination stays unlabeled,
// while post-commit budget expiry and observed internal failures carry the
// post-commit stage label.
func TestTurnRetryStagePostCommitCauseLabelsBudgetNotOuterCancellation(t *testing.T) {
	e := &turnRetryEngine{stage: turnRetryStagePostCommit}
	observed := errors.New("observed transport failure")

	outer, cancelOuter := context.WithCancel(context.Background())
	budget, cancelBudget := context.WithCancel(outer)
	defer cancelBudget()
	cancelOuter()
	got := e.stagePostCommitCause(outer, budget, observed)
	if !errors.Is(got, context.Canceled) || strings.Contains(got.Error(), "turn retry failed during") {
		t.Fatalf("post-commit cause under canceled outer context = %v, want bare context.Canceled", got)
	}

	liveOuter := context.Background()
	expiredBudget, cancelExpired := context.WithCancel(liveOuter)
	cancelExpired()
	got = e.stagePostCommitCause(liveOuter, expiredBudget, nil)
	if !errors.Is(got, context.Canceled) {
		t.Fatalf("post-commit cause under expired budget = %v, want errors.Is context.Canceled", got)
	}
	if !strings.Contains(got.Error(), string(turnRetryStagePostCommit)) {
		t.Fatalf("post-commit cause under expired budget = %q, want stage %q labeled", got.Error(), turnRetryStagePostCommit)
	}

	liveBudget, cancelLive := context.WithCancel(liveOuter)
	defer cancelLive()
	got = e.stagePostCommitCause(liveOuter, liveBudget, observed)
	if !errors.Is(got, observed) {
		t.Fatalf("post-commit cause with live contexts = %v, want errors.Is observed cause", got)
	}
	if !strings.Contains(got.Error(), string(turnRetryStagePostCommit)) {
		t.Fatalf("post-commit cause with live contexts = %q, want stage %q labeled", got.Error(), turnRetryStagePostCommit)
	}
}
