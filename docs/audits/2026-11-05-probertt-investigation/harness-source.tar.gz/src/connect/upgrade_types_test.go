package connect

import (
	"errors"
	"testing"
)

func TestErrUpgradeTransportNotConvergedDisplayText(t *testing.T) {
	const want = "connect: direct transport did not converge after ownership transfer"
	if got := ErrUpgradeTransportNotConverged.Error(); got != want {
		t.Fatalf("ErrUpgradeTransportNotConverged.Error() = %q, want %q", got, want)
	}
}

func TestValidateUpgradeOptionsRejectsInvalidOptions(t *testing.T) {
	err := ValidateUpgradeOptions(WithProbeTimeout(0))
	if !errors.Is(err, ErrInvalidProbeTimeout) {
		t.Fatalf("ValidateUpgradeOptions error = %v, want %v", err, ErrInvalidProbeTimeout)
	}
}
