package connect

import (
	"bytes"
	"crypto/sha256"
	"errors"
	"testing"
)

func TestHKDFKeyExporterDeriveDeterministic(t *testing.T) {
	exporter := NewHKDFKeyExporter([]byte("master secret"), []byte("session binding"))

	first, err := exporter.Derive("wiremux v1 fake-key", []byte("context"), 32)
	if err != nil {
		t.Fatalf("Derive first: %v", err)
	}

	second, err := exporter.Derive("wiremux v1 fake-key", []byte("context"), 32)
	if err != nil {
		t.Fatalf("Derive second: %v", err)
	}

	if !bytes.Equal(first, second) {
		t.Fatalf("Derive not deterministic:\nfirst:  %x\nsecond: %x", first, second)
	}
}

func TestHKDFKeyExporterDeriveIndependentInputs(t *testing.T) {
	exporter := NewHKDFKeyExporter([]byte("master secret"), []byte("session binding"))

	base, err := exporter.Derive("wiremux v1 fake-key", []byte("context"), 32)
	if err != nil {
		t.Fatalf("Derive base: %v", err)
	}

	otherLabel, err := exporter.Derive("wiremux v1 other-key", []byte("context"), 32)
	if err != nil {
		t.Fatalf("Derive other label: %v", err)
	}

	otherContext, err := exporter.Derive("wiremux v1 fake-key", []byte("other context"), 32)
	if err != nil {
		t.Fatalf("Derive other context: %v", err)
	}

	otherBinding := NewHKDFKeyExporter([]byte("master secret"), []byte("other binding"))
	otherSession, err := otherBinding.Derive("wiremux v1 fake-key", []byte("context"), 32)
	if err != nil {
		t.Fatalf("Derive other session binding: %v", err)
	}

	for name, got := range map[string][]byte{
		"label":           otherLabel,
		"context":         otherContext,
		"session binding": otherSession,
	} {
		if bytes.Equal(base, got) {
			t.Fatalf("Derive output did not change for different %s", name)
		}
	}
}

func TestHKDFKeyExporterDeriveLengthHandling(t *testing.T) {
	exporter := NewHKDFKeyExporter([]byte("master secret"), []byte("session binding"))

	for _, length := range []int{0, 1, 16, 32, 64, 255 * sha256.Size} {
		got, err := exporter.Derive("wiremux v1 fake-key", []byte("context"), length)
		if err != nil {
			t.Fatalf("Derive length %d: %v", length, err)
		}
		if len(got) != length {
			t.Fatalf("Derive length %d returned %d bytes", length, len(got))
		}
	}
}

func TestHKDFKeyExporterRejectsTooLongLength(t *testing.T) {
	exporter := NewHKDFKeyExporter([]byte("master secret"), []byte("session binding"))

	_, err := exporter.Derive("wiremux v1 fake-key", []byte("context"), 255*sha256.Size+1)
	if !errors.Is(err, ErrExporterLengthTooLong) {
		t.Fatalf("Derive too-long length error = %v, want %v", err, ErrExporterLengthTooLong)
	}
}

func TestHKDFKeyExporterRejectsEmptyMasterSecret(t *testing.T) {
	for _, masterSecret := range [][]byte{nil, {}} {
		exporter := NewHKDFKeyExporter(masterSecret, []byte("session binding"))

		_, err := exporter.Derive("wiremux v1 fake-key", []byte("context"), 32)
		if !errors.Is(err, ErrEmptyMasterSecret) {
			t.Fatalf("Derive empty master secret error = %v, want %v", err, ErrEmptyMasterSecret)
		}
	}
}

func TestHKDFKeyExporterLengthIsNotDomainSeparator(t *testing.T) {
	exporter := NewHKDFKeyExporter([]byte("master secret"), []byte("session binding"))

	shortKey, err := exporter.Derive("wiremux v1 fake-key", []byte("context"), 16)
	if err != nil {
		t.Fatalf("Derive short key: %v", err)
	}

	longKey, err := exporter.Derive("wiremux v1 fake-key", []byte("context"), 32)
	if err != nil {
		t.Fatalf("Derive long key: %v", err)
	}

	if !bytes.Equal(shortKey, longKey[:len(shortKey)]) {
		t.Fatalf("short key is not a prefix of long key:\nshort: %x\nlong:  %x", shortKey, longKey)
	}
}

func TestHKDFKeyExporterRejectsNULLabel(t *testing.T) {
	exporter := NewHKDFKeyExporter([]byte("master secret"), []byte("session binding"))

	_, err := exporter.Derive("wiremux v1\x00fake-key", []byte("context"), 32)
	if !errors.Is(err, ErrInvalidExporterLabel) {
		t.Fatalf("Derive NUL label error = %v, want %v", err, ErrInvalidExporterLabel)
	}
}

func TestHKDFKeyExporterRejectsNegativeLength(t *testing.T) {
	exporter := NewHKDFKeyExporter([]byte("master secret"), []byte("session binding"))

	_, err := exporter.Derive("wiremux v1 fake-key", []byte("context"), -1)
	if !errors.Is(err, ErrNegativeExporterLength) {
		t.Fatalf("Derive negative length error = %v, want %v", err, ErrNegativeExporterLength)
	}
}
