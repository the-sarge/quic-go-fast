package connect

import (
	"context"
	"errors"
	"io"
	"net"
	"net/netip"
	"sync"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// blockedIOComposite is an owned relay composite whose ReadFrom blocks until
// Close: logical read deadlines and context cancellation are deliberately
// powerless, exactly like work blocked in the composite's synchronous
// prepared write or Pion-internal socket I/O. Only composite disposal's base
// interruption wakes it.
type blockedIOComposite struct {
	closeOnce  sync.Once
	closed     chan struct{}
	closeCount int
	mu         sync.Mutex
}

func newBlockedIOComposite() *blockedIOComposite {
	return &blockedIOComposite{closed: make(chan struct{})}
}

func (c *blockedIOComposite) WiremuxRelayProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3()
}

func (c *blockedIOComposite) ReadFrom(p []byte) (int, net.Addr, error) {
	<-c.closed
	return 0, nil, net.ErrClosed
}

func (c *blockedIOComposite) WriteTo(p []byte, addr net.Addr) (int, error) {
	select {
	case <-c.closed:
		return 0, net.ErrClosed
	default:
		return len(p), nil
	}
}

func (c *blockedIOComposite) Close() error {
	c.mu.Lock()
	c.closeCount++
	c.mu.Unlock()
	c.closeOnce.Do(func() { close(c.closed) })
	return nil
}

func (c *blockedIOComposite) closeCalls() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.closeCount
}

func (c *blockedIOComposite) LocalAddr() net.Addr {
	return net.UDPAddrFromAddrPort(netip.MustParseAddrPort("198.51.100.7:3478"))
}

func (c *blockedIOComposite) SetDeadline(time.Time) error      { return nil }
func (c *blockedIOComposite) SetReadDeadline(time.Time) error  { return nil }
func (c *blockedIOComposite) SetWriteDeadline(time.Time) error { return nil }

func (c *blockedIOComposite) PreparePeer(context.Context, netip.AddrPort) error { return nil }

// compositeBlockedDialSession is a transport session whose Dial blocks in
// composite I/O and ignores context cancellation and session Close, modeling
// transport work that only composite disposal can wake.
type compositeBlockedDialSession struct {
	dialReturned chan struct{}
}

func (s *compositeBlockedDialSession) HandshakeMaterial() []byte { return []byte("m") }

func (s *compositeBlockedDialSession) Dial(_ context.Context, conn net.PacketConn, _ net.Addr, _ []byte) (io.ReadWriteCloser, error) {
	buf := make([]byte, 16)
	_, _, err := conn.ReadFrom(buf)
	close(s.dialReturned)
	return nil, errors.Join(errors.New("composite dial failed"), err)
}

func (s *compositeBlockedDialSession) Listen(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
	return nil, errors.New("unused")
}

func (s *compositeBlockedDialSession) Close() error { return nil }

// TestOwnedCompositeTerminalDisposalPrecedesOperationJoin is the Slice 2.3
// disposal-ordering regression: a terminal path holding an owned composite
// must invoke the composite's Close before awaiting any operation join that
// can depend on the composite's socket. Reordering the disposal invocation
// after the await deadlocks this test.
func TestOwnedCompositeTerminalDisposalPrecedesOperationJoin(t *testing.T) {
	t.Parallel()

	composite := newBlockedIOComposite()
	session := &compositeBlockedDialSession{dialReturned: make(chan struct{})}
	turn := newOwnedTURNPathClaim(noopReadWriteCloser{}, composite)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	turn.registerCommit()
	dialDone := turn.startDial(ctx, session, composite, composite.LocalAddr(), []byte("peer"))

	// Let the dial goroutine reach its blocking composite read.
	time.Sleep(20 * time.Millisecond)
	select {
	case <-session.dialReturned:
		t.Fatal("dial returned before terminal disposal")
	default:
	}

	type terminalOutcome struct {
		result UpgradeResult
		err    error
	}
	done := make(chan terminalOutcome, 1)
	go func() {
		result, err := turn.failClosed(errors.New("postcommit failure"), abortAfterOwnedResources)
		done <- terminalOutcome{result: result, err: err}
	}()

	select {
	case outcome := <-done:
		if !errors.Is(outcome.err, ErrUpgradeTransportNotConverged) {
			t.Fatalf("failClosed error = %v, want %v", outcome.err, ErrUpgradeTransportNotConverged)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("terminal path deadlocked: operation join awaited before composite disposal invocation")
	}

	select {
	case <-session.dialReturned:
	default:
		t.Fatal("dial operation was not joined")
	}
	<-dialDone

	if composite.closeCalls() == 0 {
		t.Fatal("composite Close was never invoked")
	}

	turn.mu.Lock()
	claim := turn.claim
	turn.mu.Unlock()
	if claim != packetClaimDisposed {
		t.Fatalf("claim = %v, want %v", claim, packetClaimDisposed)
	}
}
