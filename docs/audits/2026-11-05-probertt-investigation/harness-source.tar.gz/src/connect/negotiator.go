package connect

import (
	"errors"
	"io"
)

// Negotiator coordinates candidate exchange, role assignment, and transport
// upgrade over an authenticated relay channel.
type Negotiator struct {
	channel       io.ReadWriteCloser
	auth          AuthContext
	transportAuth TransportAuth

	// The construction-time key orientation drives deterministic dial/listen
	// role assignment during direct upgrade. AuthContext methods may return
	// mutable caller-owned slices, so the negotiator stores the stable
	// orientation rather than consulting auth again during upgrade.
	directionalKeyOrientation DirectionalKeyOrientation
}

// Package-level sentinel errors.
var (
	ErrNilChannel       = errors.New("connect: channel is nil")
	ErrNilAuthContext   = errors.New("connect: auth context is nil")
	ErrNilTransportAuth = errors.New("connect: transport auth is nil")
	ErrNilKeyExporter   = errors.New("connect: key exporter is nil")
	ErrNilContext       = errors.New("connect: context is nil")
	ErrNilTransport     = errors.New("connect: transport is nil")
)

// NewNegotiator constructs a negotiator over an authenticated relay channel.
//
// The channel must support full-duplex use while Upgrade runs. If Upgrade must
// abort after entering upgrade-control mode, in-flight reads or writes must
// unblock promptly when Close is called or when a supported deadline is
// advanced. net.Conn satisfies this relay-channel contract.
//
// Construction fails if auth exposes invalid SendKey or ReceiveKey values. The
// negotiator enforces directional-key validity at its own boundary so BYO auth
// contexts that omit direction keys, reuse one symmetric key, or supply keys
// that cannot be used by wiremux/channel cannot reach candidate exchange or
// transport negotiation.
func NewNegotiator(channel io.ReadWriteCloser, auth AuthContext) (*Negotiator, error) {
	return NewNegotiatorWithTransportAuth(channel, auth, transportAuthFor(auth))
}

// NewNegotiatorWithTransportAuth constructs a negotiator whose direct
// transport receives the supplied least-privilege authentication view. Root
// wiremux uses this form to bind transport access to Wire lifetime; lower-level
// callers that use NewNegotiator retain ownership of their AuthContext.
func NewNegotiatorWithTransportAuth(channel io.ReadWriteCloser, auth AuthContext, transportAuth TransportAuth) (*Negotiator, error) {
	if channel == nil {
		return nil, ErrNilChannel
	}
	if auth == nil {
		return nil, ErrNilAuthContext
	}
	if transportAuth == nil {
		return nil, ErrNilTransportAuth
	}
	if auth.Exporter() == nil {
		return nil, ErrNilKeyExporter
	}

	keys, err := NewDirectionalKeys(auth)
	if err != nil {
		return nil, err
	}
	defer keys.Clear()

	return &Negotiator{
		channel:                   channel,
		auth:                      auth,
		transportAuth:             transportAuth,
		directionalKeyOrientation: keys.Orientation(),
	}, nil
}
