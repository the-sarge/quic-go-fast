package connect

import (
	"bytes"
	"crypto/sha256"
	"errors"
	"fmt"
)

// DirectionalKeyOrientation is the canonical orientation derived from an
// AuthContext's directional channel keys.
type DirectionalKeyOrientation uint8

const (
	// DirectionalKeyOrientationReceiveHashGreaterOrEqual means
	// SHA-256(ReceiveKey()) sorts at or above SHA-256(SendKey()).
	DirectionalKeyOrientationReceiveHashGreaterOrEqual DirectionalKeyOrientation = iota + 1

	// DirectionalKeyOrientationSendHashGreater means SHA-256(SendKey()) sorts
	// above SHA-256(ReceiveKey()).
	DirectionalKeyOrientationSendHashGreater
)

var (
	// ErrEmptyDirectionalKey reports an empty SendKey or ReceiveKey.
	ErrEmptyDirectionalKey = errors.New("connect: send and receive keys must be non-empty")

	// ErrEqualDirectionalKeys reports identical SendKey and ReceiveKey values.
	ErrEqualDirectionalKeys = errors.New("connect: send and receive keys must differ")

	// ErrInvalidDirectionalKeySize reports keys that cannot be used directly as AES keys.
	ErrInvalidDirectionalKeySize = errors.New("connect: directional keys must be 16, 24, or 32 bytes")
)

// DirectionalKeys is a validated, stable snapshot of an AuthContext's
// directional channel keys.
type DirectionalKeys struct { //nolint:recvcheck // String, GoString, and Format take value receivers so redaction also covers a dereferenced value; only Clear mutates and needs a pointer.
	material    *directionalKeyMaterial
	orientation DirectionalKeyOrientation
}

type directionalKeyMaterial struct {
	sendKey    []byte
	receiveKey []byte
}

// NewDirectionalKeys snapshots and validates auth's directional channel keys.
//
// The keys must be non-empty, distinct, and valid AES key sizes: 16, 24, or
// 32 bytes. SendKey and ReceiveKey return caller-owned copies of the validated
// key material. Orientation returns the single hash-ordering decision used by
// channel framing and transport-upgrade role assignment.
//
// Cross-peer mirror invariant: for a successful two-peer session, peer A's
// SendKey must equal peer B's ReceiveKey, and peer A's ReceiveKey must equal
// peer B's SendKey. That property cannot be proven from one local AuthContext;
// non-mirrored peers may derive either local orientation and will fail channel
// authentication when frames are opened.
//
// On success, NewDirectionalKeys returns a DirectionalKeys value that owns a
// copied key snapshot. It returns ErrNilAuthContext for nil auth,
// ErrEmptyDirectionalKey for empty send or receive keys, ErrEqualDirectionalKeys
// for equal keys, and ErrInvalidDirectionalKeySize for keys outside the AES
// sizes. Invalid-size errors wrap ErrInvalidDirectionalKeySize with the
// offending key length.
//
// DirectionalKeys contains sensitive material. Do not copy a DirectionalKeys
// value before calling Clear; typical use is:
//
//	keys, err := NewDirectionalKeys(auth)
//	if err != nil {
//		return err
//	}
//	defer keys.Clear()
func NewDirectionalKeys(auth AuthContext) (DirectionalKeys, error) {
	if auth == nil {
		return DirectionalKeys{}, ErrNilAuthContext
	}

	sendKey := auth.SendKey()
	receiveKey := auth.ReceiveKey()
	if len(sendKey) == 0 || len(receiveKey) == 0 {
		clear(sendKey)
		clear(receiveKey)
		return DirectionalKeys{}, ErrEmptyDirectionalKey
	}
	if bytes.Equal(sendKey, receiveKey) {
		clear(sendKey)
		clear(receiveKey)
		return DirectionalKeys{}, ErrEqualDirectionalKeys
	}
	if !validDirectionalKeySize(len(sendKey)) {
		clear(sendKey)
		clear(receiveKey)
		return DirectionalKeys{}, fmt.Errorf("%w: send key is %d bytes", ErrInvalidDirectionalKeySize, len(sendKey))
	}
	if !validDirectionalKeySize(len(receiveKey)) {
		clear(sendKey)
		clear(receiveKey)
		return DirectionalKeys{}, fmt.Errorf("%w: receive key is %d bytes", ErrInvalidDirectionalKeySize, len(receiveKey))
	}

	keys := DirectionalKeys{
		material: &directionalKeyMaterial{
			sendKey:    append([]byte(nil), sendKey...),
			receiveKey: append([]byte(nil), receiveKey...),
		},
		orientation: directionalKeyOrientation(sendKey, receiveKey),
	}
	clear(sendKey)
	clear(receiveKey)
	return keys, nil
}

// Clear zeroizes the key snapshot and resets the orientation. Do not copy a
// DirectionalKeys value before calling Clear; copies share the same underlying
// key material, and Clear only resets the receiver's struct fields.
func (k *DirectionalKeys) Clear() {
	if k.material != nil {
		clear(k.material.sendKey)
		clear(k.material.receiveKey)
		k.material.sendKey = nil
		k.material.receiveKey = nil
	}
	k.material = nil
	k.orientation = 0
}

// SendKey returns a caller-owned copy of the validated outbound channel key.
func (k DirectionalKeys) SendKey() []byte {
	if k.material == nil {
		return nil
	}
	return append([]byte(nil), k.material.sendKey...)
}

// ReceiveKey returns a caller-owned copy of the validated inbound channel key.
func (k DirectionalKeys) ReceiveKey() []byte {
	if k.material == nil {
		return nil
	}
	return append([]byte(nil), k.material.receiveKey...)
}

// Orientation returns the canonical hash-ordering decision for these keys.
func (k DirectionalKeys) Orientation() DirectionalKeyOrientation {
	return k.orientation
}

// String returns a redacted diagnostic representation.
func (k DirectionalKeys) String() string {
	return fmt.Sprintf(
		"DirectionalKeys{sendKey:<redacted len=%d>, receiveKey:<redacted len=%d>, orientation:%d}",
		len(k.sendKey()),
		len(k.receiveKey()),
		k.orientation,
	)
}

// GoString returns a redacted Go-syntax diagnostic representation.
func (k DirectionalKeys) GoString() string {
	return fmt.Sprintf(
		"connect.DirectionalKeys{sendKey:<redacted len=%d>, receiveKey:<redacted len=%d>, orientation:%d}",
		len(k.sendKey()),
		len(k.receiveKey()),
		k.orientation,
	)
}

// Format redacts key material for all fmt verbs, including %+v and %#v.
func (k DirectionalKeys) Format(state fmt.State, verb rune) {
	switch verb {
	case 'v':
		if state.Flag('#') {
			_, _ = fmt.Fprint(state, k.GoString())
			return
		}
		_, _ = fmt.Fprint(state, k.String())
	case 's':
		_, _ = fmt.Fprint(state, k.String())
	case 'q':
		_, _ = fmt.Fprintf(state, "%q", k.String())
	default:
		_, _ = fmt.Fprintf(state, "%%!%c(%s)", verb, k.String())
	}
}

func validDirectionalKeySize(size int) bool {
	switch size {
	case 16, 24, 32:
		return true
	default:
		return false
	}
}

func (k DirectionalKeys) sendKey() []byte {
	if k.material == nil {
		return nil
	}
	return k.material.sendKey
}

func (k DirectionalKeys) receiveKey() []byte {
	if k.material == nil {
		return nil
	}
	return k.material.receiveKey
}

func directionalKeyOrientation(sendKey, receiveKey []byte) DirectionalKeyOrientation {
	sendHash := sha256.Sum256(sendKey)
	receiveHash := sha256.Sum256(receiveKey)
	if bytes.Compare(sendHash[:], receiveHash[:]) > 0 {
		return DirectionalKeyOrientationSendHashGreater
	}
	return DirectionalKeyOrientationReceiveHashGreaterOrEqual
}
