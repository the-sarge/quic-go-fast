package connect

import (
	"go/ast"
	"go/parser"
	"go/token"
	"path/filepath"
	"testing"

	"github.com/GridSwarm/wiremux/internal/compatmanifest"
)

// TestPinnedVectorReferencesExist proves every upgrade-control and
// authenticated-probe golden test referenced by the wire-vectors manifest
// still exists in this package under its referenced name, so renaming or
// deleting a pinned golden fails a drift test instead of silently orphaning
// the manifest reference.
func TestPinnedVectorReferencesExist(t *testing.T) {
	for _, ref := range compatmanifest.PinnedVectorReferences() {
		if dir := filepath.Dir(ref.File); dir != "connect" {
			t.Fatalf("pinned reference %q points outside the connect package: %s", ref.Profile, ref.File)
		}
		file := filepath.Base(ref.File)

		fset := token.NewFileSet()
		parsed, err := parser.ParseFile(fset, file, nil, parser.SkipObjectResolution)
		if err != nil {
			t.Fatalf("parse referenced file %s: %v", ref.File, err)
		}
		declared := make(map[string]bool)
		for _, decl := range parsed.Decls {
			if fn, ok := decl.(*ast.FuncDecl); ok && fn.Recv == nil {
				declared[fn.Name.Name] = true
			}
		}

		for _, test := range ref.Tests {
			if !declared[test] {
				t.Fatalf("pinned %s golden %s is referenced by the wire-vectors manifest but does not exist in %s", ref.Profile, test, ref.File)
			}
		}
	}
}
