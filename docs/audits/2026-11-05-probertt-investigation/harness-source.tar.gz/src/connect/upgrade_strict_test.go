package connect

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"net/netip"
	"strings"
	"sync"
	"syscall"
	"testing"
	"time"
)

func TestNegotiatorUpgradeStrictMalformedFirstPhase(t *testing.T) {
	local, peer := net.Pipe()
	defer local.Close()
	defer peer.Close()
	n, err := NewNegotiator(local, testAuthContext())
	if err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	go func() {
		if _, err := readUpgradeControlFrame(peer); err != nil {
			done <- err
			return
		}
		done <- writeFull(peer, []byte{0, 0, 0, 0})
	}()
	result, err := n.UpgradeStrict(context.Background())
	var failure *UpgradeError
	if result.Stream != nil || !errors.As(err, &failure) || failure.Kind() != UpgradeErrorProtocol {
		t.Fatalf("strict malformed result: got %#v, %v, want no stream and protocol error", result, err)
	}
	if err := <-done; err != nil {
		t.Fatal(err)
	}
	if _, err := peer.Write([]byte{1}); err == nil {
		t.Fatal("peer write: got success, want closed carrier")
	}
}

// strictFailureTransport changes only the transport boundary, preserving the
// real authenticated probe and control negotiation on both peers.
type strictFailureTransport struct {
	inner *directHandoffTransport
	cause error
}

func (s strictFailureTransport) Name() string { return s.inner.Name() }
func (s strictFailureTransport) NewSession(ctx context.Context, auth TransportAuth) (Session, error) {
	session, err := s.inner.NewSession(ctx, auth)
	if err != nil {
		return nil, err
	}
	return &strictFailureSession{Session: session, cause: s.cause}, nil
}

type strictFailureSession struct {
	Session
	cause error
}

func (s *strictFailureSession) Dial(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
	return nil, s.cause
}

func TestNegotiatorUpgradeStrictTransportFailures(t *testing.T) {
	unknown := errors.New("custom transport failure")
	for _, tc := range []struct {
		name  string
		cause error
		kind  UpgradeErrorKind
	}{
		{"outage", &net.OpError{Op: "dial", Net: "udp", Err: syscall.ENETUNREACH}, UpgradeErrorTransientTransport},
		{"unknown", unknown, UpgradeErrorTransport},
	} {
		t.Run(tc.name, func(t *testing.T) {
			alice, bob, _, _ := newPipeNegotiatorPair(t)
			aConn, bConn := listenPacket(t, "127.0.0.1:0"), listenPacket(t, "127.0.0.1:0")
			defer aConn.Close()
			defer bConn.Close()
			aTransport, bTransport := newDirectHandoffTransports("fake-stream")
			defer aTransport.streams.dialStream.Close()
			defer aTransport.streams.listenStream.Close()
			ctx, cancel := context.WithTimeout(context.Background(), testCausalObservationTimeout)
			defer cancel()
			aDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
				return alice.UpgradeStrict(ctx, WithTransport(strictFailureTransport{aTransport, tc.cause}), WithUpgradePacketConn(aConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
			})
			bResult, bErr := bob.UpgradeStrict(ctx, WithTransport(strictFailureTransport{bTransport, tc.cause}), WithUpgradePacketConn(bConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
			aResult := <-aDone
			outcome := aResult
			if assignUpgradeRole(bob.directionalKeyOrientation) == upgradeRoleDial {
				outcome = upgradeTestOutcome{result: bResult, err: bErr}
			}
			var failure *UpgradeError
			if outcome.result.Stream != nil || !errors.As(outcome.err, &failure) || failure.Kind() != tc.kind || !errors.Is(outcome.err, tc.cause) || !errors.Is(outcome.err, ErrUpgradeTransportNotConverged) {
				t.Fatalf("strict dial failure: got %#v, %v, want %s retaining cause and ownership", outcome.result, outcome.err, tc.kind)
			}
		})
	}
}

// strictPeerControl is the authenticated-peer boundary. It changes one complete
// outgoing control frame while the real negotiators own protocol progression.
type strictPeerControl struct {
	io.ReadWriteCloser
	message     uint64
	replacement []byte
}

func (s *strictPeerControl) Write(p []byte) (int, error) {
	if len(p) >= 4 && payloadHasMessageType(p[4:], s.message) {
		if err := writeFull(s.ReadWriteCloser, s.replacement); err != nil {
			return 0, err
		}
		return len(p), nil
	}
	return s.ReadWriteCloser.Write(p)
}

func TestNegotiatorUpgradeStrictPeerPhases(t *testing.T) {
	contradictory, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseConfirmed, true)
	if err != nil {
		t.Fatal(err)
	}
	fallback, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		name        string
		message     uint64
		target      upgradeRole
		replacement []byte
		kind        UpgradeErrorKind
	}{
		{"selected", upgradeControlMessageSelectedPair, upgradeRoleListen, []byte{0, 0, 0, 0}, UpgradeErrorProtocol},
		{"ready", upgradeControlMessageReady, upgradeRoleDial, []byte{0, 0, 0, 0}, UpgradeErrorProtocol},
		{"commit", upgradeControlMessageCommit, upgradeRoleListen, []byte{0, 0, 0, 0}, UpgradeErrorProtocol},
		{"postcommit", upgradeControlMessageAccepted, upgradeRoleDial, []byte{0, 0, 0, 0}, UpgradeErrorProtocol},
		{"contradictory", upgradeControlMessageConfirmed, upgradeRoleDial, contradictory, UpgradeErrorProtocol},
		{"postcommit_valid_fallback", upgradeControlMessageAccepted, upgradeRoleDial, fallback, UpgradeErrorTransport},
	} {
		t.Run(tc.name, func(t *testing.T) {
			for _, strict := range []bool{false, true} {
				t.Run(fmt.Sprint(strict), func(t *testing.T) {
					alice, bob, _, _ := newPipeNegotiatorPair(t)
					target, peer := alice, bob
					if assignUpgradeRole(alice.directionalKeyOrientation) != tc.target {
						target, peer = bob, alice
					}
					peer.channel = &strictPeerControl{ReadWriteCloser: peer.channel, message: tc.message, replacement: tc.replacement}
					targetConn, peerConn := listenPacket(t, "127.0.0.1:0"), listenPacket(t, "127.0.0.1:0")
					defer targetConn.Close()
					defer peerConn.Close()
					targetTransport, peerTransport := newDirectHandoffTransports("fake-stream")
					defer targetTransport.streams.dialStream.Close()
					defer targetTransport.streams.listenStream.Close()
					ctx, cancel := context.WithTimeout(context.Background(), testCausalObservationTimeout)
					defer cancel()
					run := func(n *Negotiator, tr Transport, pc net.PacketConn) (UpgradeResult, error) {
						opts := []UpgradeOption{WithTransport(tr), WithUpgradePacketConn(pc), WithProbeTimeout(testRunnerSafeProbeTimeout)}
						if strict {
							return n.UpgradeStrict(ctx, opts...)
						}
						return n.Upgrade(ctx, opts...)
					}
					done := runNegotiatorUpgrade(func() (UpgradeResult, error) { return run(peer, peerTransport, peerConn) })
					result, err := run(target, targetTransport, targetConn)
					other := <-done
					if result.Stream != nil {
						defer result.Stream.Close()
					}
					if other.result.Stream != nil {
						defer other.result.Stream.Close()
					}
					var failure *UpgradeError
					if strict {
						if result.Stream != nil || !errors.As(err, &failure) || failure.Kind() != tc.kind {
							t.Fatalf("strict phase: got %#v, %v, want %s failure", result, err, tc.kind)
						}
						if tc.kind == UpgradeErrorTransport && !errors.Is(err, ErrUpgradeTransportNotConverged) {
							t.Fatalf("lost ownership boundary: %v", err)
						}
					} else if errors.As(err, &failure) {
						t.Fatalf("legacy phase: got strict error %v", err)
					}
				})
			}
		})
	}
}

func TestNegotiatorUpgradeStrictLocalState(t *testing.T) {
	n, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatal(err)
	}
	conn := listenPacket(t, "127.0.0.1:0")
	defer conn.Close()
	transport := &fakeTransport{name: "invalid\x00"}
	result, err := n.UpgradeStrict(context.Background(), WithTransport(transport), WithUpgradePacketConn(conn))
	var failure *UpgradeError
	if result.Stream != nil || !errors.As(err, &failure) || failure.Kind() != UpgradeErrorLocal {
		t.Fatalf("local invalid state: got %#v, %v, want local error", result, err)
	}
	result, err = n.UpgradeStrict(context.Background(), WithTURNRetryTimeout(time.Second))
	if result.Stream != nil || !errors.As(err, &failure) || failure.Kind() != UpgradeErrorLocal || !errors.Is(err, ErrStrictUpgradeTURNUnsupported) {
		t.Fatalf("strict TURN: got %#v, %v, want preflight rejection", result, err)
	}
}

func TestNegotiatorUpgradeStrictCallerContext(t *testing.T) {
	for _, tc := range []struct {
		name  string
		ctx   func() (context.Context, context.CancelFunc)
		kind  UpgradeErrorKind
		cause error
	}{
		{"cancel", func() (context.Context, context.CancelFunc) {
			ctx, cancel := context.WithCancel(context.Background())
			cancel()
			return ctx, cancel
		}, UpgradeErrorCanceled, context.Canceled},
		{"deadline", func() (context.Context, context.CancelFunc) {
			return context.WithDeadline(context.Background(), time.Unix(1, 0))
		}, UpgradeErrorDeadline, context.DeadlineExceeded},
	} {
		t.Run(tc.name, func(t *testing.T) {
			n, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
			if err != nil {
				t.Fatal(err)
			}
			ctx, cancel := tc.ctx()
			defer cancel()
			result, err := n.UpgradeStrict(ctx)
			var failure *UpgradeError
			if result.Stream != nil || !errors.As(err, &failure) || failure.Kind() != tc.kind || !errors.Is(err, tc.cause) {
				t.Fatalf("caller context: got %#v, %v, want %s preserving context", result, err, tc.kind)
			}
		})
	}
}

func TestNegotiatorUpgradeStrictPeerProtocolFallback(t *testing.T) {
	local, peer := net.Pipe()
	defer local.Close()
	defer peer.Close()
	n, err := NewNegotiator(local, testAuthContext())
	if err != nil {
		t.Fatal(err)
	}
	frame, err := encodeUpgradeControlFallback(UpgradeFallbackProtocolMismatch)
	if err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	go func() {
		if _, err := readUpgradeControlFrame(peer); err != nil {
			done <- err
			return
		}
		done <- writeFull(peer, frame)
	}()
	result, err := n.UpgradeStrict(context.Background())
	assertRelayFallbackResult(t, "strict peer fallback", upgradeTestOutcome{result, err}, local, UpgradeFallbackProtocolMismatch)
	if err := <-done; err != nil {
		t.Fatal(err)
	}
}

type strictDiscardProbeConn struct{ net.PacketConn }

func (s strictDiscardProbeConn) WriteTo(p []byte, _ net.Addr) (int, error) { return len(p), nil }

func TestNegotiatorUpgradeStrictUsableResults(t *testing.T) {
	for _, probeFails := range []bool{false, true} {
		t.Run(fmt.Sprint(probeFails), func(t *testing.T) {
			alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)
			var aConn net.PacketConn = listenPacket(t, "127.0.0.1:0")
			var bConn net.PacketConn = listenPacket(t, "127.0.0.1:0")
			defer aConn.Close()
			defer bConn.Close()
			aTransport, bTransport := newDirectHandoffTransports("fake-stream")
			defer aTransport.streams.dialStream.Close()
			defer aTransport.streams.listenStream.Close()
			if probeFails {
				// Keep Alice in probe construction until Bob's fallback joins
				// her probe, so cancellation must preserve Bob's probe reason.
				aConn = &runtimeProviderPacketConn{
					runtime: newScriptedProbeRuntime(time.Now()), local: netip.MustParseAddrPort(aConn.LocalAddr().String()),
					onNewProbeRuntime: func(probeCtx context.Context) { <-probeCtx.Done() },
				}
				bConn = strictDiscardProbeConn{bConn}
			}
			ctx, cancel := context.WithTimeout(context.Background(), testCausalObservationTimeout)
			defer cancel()
			done := runNegotiatorUpgrade(func() (UpgradeResult, error) {
				return alice.UpgradeStrict(ctx, WithTransport(aTransport), WithUpgradePacketConn(aConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
			})
			bResult, bErr := bob.UpgradeStrict(ctx, WithTransport(bTransport), WithUpgradePacketConn(bConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
			aResult := <-done
			if aResult.result.Stream != nil {
				defer aResult.result.Stream.Close()
			}
			if bResult.Stream != nil {
				defer bResult.Stream.Close()
			}
			if probeFails {
				assertRelayFallbackResult(t, "alice", aResult, aliceRelay, UpgradeFallbackProbeFailed)
				assertRelayFallbackResult(t, "bob", upgradeTestOutcome{bResult, bErr}, bobRelay, UpgradeFallbackProbeFailed)
			} else if aResult.err != nil || bErr != nil || aResult.result.Path != UpgradePathDirect || bResult.Path != UpgradePathDirect {
				t.Fatalf("strict direct: got %#v, %#v/%v, want bilateral direct", aResult, bResult, bErr)
			}
			bytesDone := make(chan error, 1)
			go func() { _, err := aResult.result.Stream.Write([]byte("ok")); bytesDone <- err }()
			var got [2]byte
			if _, err := io.ReadFull(bResult.Stream, got[:]); err != nil || string(got[:]) != "ok" {
				t.Fatalf("reliable result: got %q, %v, want ok", got, err)
			}
			if err := <-bytesDone; err != nil {
				t.Fatal(err)
			}
		})
	}
}

func TestNegotiatorUpgradeStrictCleanupPreservesWinner(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	cause := errors.New("carrier read failed before cleanup")
	channel := newScriptedControlChannel(nil, false)
	channel.readScript = func([]byte) (int, error) { return 0, cause }
	channel.closeScript = func() error { cancel(); return nil }
	n, err := NewNegotiator(channel, testAuthContext())
	if err != nil {
		t.Fatal(err)
	}
	result, err := n.UpgradeStrict(ctx)
	assertStrictFailure(t, result, err, UpgradeErrorTransport, cause)
	if ctx.Err() != context.Canceled || !channel.closed.Load() {
		t.Fatal("cleanup did not cancel caller and close carrier")
	}
}

func TestNegotiatorUpgradeStrictRejectsStaleClassification(t *testing.T) {
	previous := newScriptedControlChannel(nil, true)
	n, err := NewNegotiator(previous, testAuthContext())
	if err != nil {
		t.Fatal(err)
	}
	result, prior := n.UpgradeStrict(context.Background(), WithUpgradeControlTimeout(time.Millisecond))
	assertStrictFailure(t, result, prior, UpgradeErrorTransientTransport, ErrUpgradeControlTimeout)
	channel := newScriptedControlChannel(nil, false)
	channel.readScript = func([]byte) (int, error) { return 0, fmt.Errorf("new carrier failure: %w", prior) }
	n, err = NewNegotiator(channel, testAuthContext())
	if err != nil {
		t.Fatal(err)
	}
	result, err = n.UpgradeStrict(context.Background())
	assertStrictFailure(t, result, err, UpgradeErrorTransport, prior)
}

func TestNegotiatorUpgradeStrictMissingFallbackReason(t *testing.T) {
	for _, strict := range []bool{false, true} {
		t.Run(fmt.Sprint(strict), func(t *testing.T) {
			target, peer, targetRelay, _ := newPipeNegotiatorPair(t)
			peer.channel = &strictPeerControl{ReadWriteCloser: peer.channel, message: upgradeControlMessageFallback, replacement: []byte{0, 0, 0, 5, 0xa2, 0, 2, 1, 1}}
			targetConn, peerConn := listenPacket(t, "127.0.0.1:0"), listenPacket(t, "127.0.0.1:0")
			defer targetConn.Close()
			defer peerConn.Close()
			ctx, cancel := context.WithTimeout(context.Background(), testCausalObservationTimeout)
			defer cancel()
			run := func(n *Negotiator, name string, pc net.PacketConn) (UpgradeResult, error) {
				opts := []UpgradeOption{WithTransport(&fakeTransport{name: name}), WithUpgradePacketConn(pc)}
				if strict {
					return n.UpgradeStrict(ctx, opts...)
				}
				return n.Upgrade(ctx, opts...)
			}
			done := runNegotiatorUpgrade(func() (UpgradeResult, error) { return run(peer, "peer", peerConn) })
			result, err := run(target, "target", targetConn)
			other := <-done
			if other.result.Stream != nil {
				defer other.result.Stream.Close()
			}
			if strict {
				assertStrictFailure(t, result, err, UpgradeErrorProtocol, errMalformedUpgradeControl)
				if _, err := targetRelay.Write([]byte{1}); err == nil {
					t.Fatal("carrier remains open")
				}
			} else {
				assertRelayFallbackResult(t, "legacy", upgradeTestOutcome{result, err}, targetRelay, UpgradeFallbackProtocolMismatch)
				defer result.Stream.Close()
			}
		})
	}
}

type strictProbeFailureConn struct {
	net.PacketConn
	cause error
}

func (s strictProbeFailureConn) ReadFrom([]byte) (int, net.Addr, error) { return 0, nil, s.cause }

func TestNegotiatorUpgradeStrictProbeFailureOrigins(t *testing.T) {
	for _, local := range []bool{false, true} {
		t.Run(fmt.Sprint(local), func(t *testing.T) {
			target, peer, targetRelay, peerRelay := newPipeNegotiatorPair(t)
			var targetConn net.PacketConn = listenPacket(t, "127.0.0.1:0")
			peerConn := listenPacket(t, "127.0.0.1:0")
			defer targetConn.Close()
			defer peerConn.Close()
			cause := error(syscall.ENETUNREACH)
			var exporter *blockingErrorExporter
			probeContext := make(chan context.Context, 1)
			if local {
				cause = errors.New("local probe key preparation failed")
				exporter = &blockingErrorExporter{started: make(chan struct{}), release: make(chan struct{}), err: cause}
				auth := testAuthContext()
				auth.exporter = exporter
				target.auth = auth
				targetConn = &runtimeProviderPacketConn{
					runtime:           newScriptedProbeRuntime(time.Now()),
					local:             netip.MustParseAddrPort(targetConn.LocalAddr().String()),
					onNewProbeRuntime: func(ctx context.Context) { probeContext <- ctx },
				}
			} else {
				targetConn = strictProbeFailureConn{targetConn, cause}
			}
			ctx, cancel := context.WithTimeout(context.Background(), testCausalObservationTimeout)
			defer cancel()
			peerDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
				return peer.UpgradeStrict(ctx, WithTransport(&fakeTransport{name: "test"}), WithUpgradePacketConn(peerConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
			})
			targetDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
				return target.UpgradeStrict(ctx, WithTransport(&fakeTransport{name: "test"}), WithUpgradePacketConn(targetConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
			})
			if local {
				release := sync.OnceFunc(func() { close(exporter.release) })
				defer release()
				awaitBlockingExporterStarted(t, exporter)
				ownedCtx := <-probeContext
				select {
				case <-ownedCtx.Done():
					if ctx.Err() != nil || ownedCtx.Err() != context.Canceled {
						t.Fatalf("probe join: got %v, caller %v; want independent join cancellation", ownedCtx.Err(), ctx.Err())
					}
				case <-ctx.Done():
					t.Fatal("peer fallback did not join the blocked probe")
				}
				release()
			}
			result := <-targetDone
			other := <-peerDone
			if other.result.Stream != nil {
				defer other.result.Stream.Close()
			}
			if local {
				assertStrictFailure(t, result.result, result.err, UpgradeErrorLocal, cause)
			} else {
				assertRelayFallbackResult(t, "target", result, targetRelay, UpgradeFallbackTransportFailed)
				assertRelayFallbackResult(t, "peer", other, peerRelay, UpgradeFallbackTransportFailed)
				defer result.result.Stream.Close()
			}
		})
	}
}

func assertStrictFailure(t *testing.T, result UpgradeResult, err error, kind UpgradeErrorKind, cause error) {
	t.Helper()
	var failure *UpgradeError
	if result.Stream != nil || !errors.As(err, &failure) || failure.Kind() != kind || !errors.Is(err, cause) {
		t.Fatalf("strict failure: got %#v, %v; want %s retaining %v", result, err, kind, cause)
	}
}

func TestNegotiatorUpgradeStrictListenerOwnedExpiry(t *testing.T) {
	for _, phase := range []string{"commit-observed-handoff", "materialized-handoff/context-select", "materialized-handoff/commit-context", "materialized-handoff/commit-timer", "accept-first-commit/receive", "accept-first-commit/context"} {
		t.Run(phase, func(t *testing.T) {
			engine, runtime, packetConn, channel := newStrictListenerOwnerFixture(t, strings.HasPrefix(phase, "accept-first-commit"))
			ctx, cancel := context.WithDeadline(context.Background(), time.Unix(1, 0))
			defer cancel()
			var result UpgradeResult
			var err error
			cause := context.DeadlineExceeded
			switch {
			case strings.HasPrefix(phase, "materialized-handoff/commit-"):
				runtime.handoffCtx = ctx
				expiry := commitAwaitResult{err: ctx.Err()}
				if strings.HasSuffix(phase, "timer") {
					control := newScriptedControlChannel(nil, true)
					defer control.Close()
					sequencer := newControlFrameSequencer(control, engine.attempt.resources().strictToken)
					expiry.frame, expiry.err = sequencer.recv(context.Background(), time.Millisecond)
					cause = ErrUpgradeControlTimeout
				}
				result, err = engine.handleListenerFirstCommit(context.Background(), runtime, expiry)
			case strings.HasPrefix(phase, "accept-first-commit"):
				// Both the receive result and select expiry must enter the same
				// owner-tagged terminal route; the refreshed phase owns ctx.
				runtime.commitBudgetCtx = ctx
				expiry := commitAwaitResult{err: ctx.Err()}
				if strings.HasSuffix(phase, "/receive") {
					expiry.frame, expiry.err = engine.attempt.controlFrames.recv(ctx, 0)
				}
				result, err = engine.handleListenerAcceptFirstCommit(context.Background(), runtime, expiry)
			default:
				runtime.handoffCtx = ctx
				commitCh := make(chan commitAwaitResult, 1)
				runtime.commitCh = commitCh
				if phase == "commit-observed-handoff" {
					commitCh <- commitResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseCommit) })
				}
				result, err = engine.handleListenerHandoffTimeout(context.Background(), runtime)
			}
			assertStrictFailure(t, result, err, UpgradeErrorTransientTransport, cause)
			if !errors.Is(err, ErrUpgradeTransportNotConverged) {
				t.Fatalf("lost ownership boundary: %v", err)
			}
			if packetConn.closeCalls.Load() != 1 || channel.closeCalls.Load() != 1 {
				t.Fatalf("cleanup counts packet=%d carrier=%d", packetConn.closeCalls.Load(), channel.closeCalls.Load())
			}
		})
	}
}

func TestNegotiatorUpgradeStrictAcceptFirstValidFallback(t *testing.T) {
	engine, runtime, packetConn, channel := newStrictListenerOwnerFixture(t, true)
	commit := commitResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlFallback(UpgradeFallbackTransportFailed) })
	result, err := engine.handleListenerAcceptFirstCommit(context.Background(), runtime, commit)
	assertStrictFailure(t, result, err, UpgradeErrorTransport, ErrUpgradeTransportNotConverged)
	if packetConn.closeCalls.Load() != 1 || channel.closeCalls.Load() != 1 {
		t.Fatalf("cleanup counts packet=%d carrier=%d", packetConn.closeCalls.Load(), channel.closeCalls.Load())
	}
}

func newStrictListenerOwnerFixture(t *testing.T, acceptFirst bool) (directUpgradeProtocolEngine, *directUpgradeProtocolRuntime, *terminalTestPacketConn, *terminalTestChannel) {
	t.Helper()
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47001")}}
	channel := &terminalTestChannel{}
	n, err := NewNegotiator(channel, testAuthContext())
	if err != nil {
		t.Fatal(err)
	}
	attempt := newDirectUpgradeAttempt(n, upgradeConfig{strict: true, packetConn: packetConn})
	session := &terminalTestSession{}
	listener := &terminalTestDefinitiveAcceptListener{}
	acceptResult := transportAcceptResult{stream: &terminalTestStream{}}
	registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, acceptResult)
	state := directUpgradeProtocolStateListenerAwaitingAcceptOrCommit
	if acceptFirst {
		state = directUpgradeProtocolStateListenerAcceptFirst
	}
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, state)
	return directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor}, &directUpgradeProtocolRuntime{acceptCh: make(chan transportAcceptResult), acceptResult: acceptResult}, packetConn, channel
}
