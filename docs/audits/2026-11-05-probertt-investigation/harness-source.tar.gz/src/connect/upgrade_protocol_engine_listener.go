package connect

import (
	"context"
	"errors"
	"net"
	"time"
)

// listenerAcceptSelectedObserver is a narrow test hook for proving ordering at
// the listener engine's successful-Accept boundary. Production listeners do
// not implement it, so it is otherwise inert.
type listenerAcceptSelectedObserver interface {
	ListenerAcceptSelectedForTest()
}

func notifyListenerAcceptSelected(listener TransportListener) {
	if observer, ok := listener.(listenerAcceptSelectedObserver); ok {
		observer.ListenerAcceptSelectedForTest()
	}
}

// listenerAcceptBudgetObserver is a narrow test hook for proving the budget
// assigned to the listener engine's commit-first Accept wait. Production
// listeners do not implement it, so it is otherwise inert.
type listenerAcceptBudgetObserver interface {
	testListenerAcceptBudget(time.Time)
}

func notifyListenerAcceptBudget(listener TransportListener, ctx context.Context) {
	observer, ok := listener.(listenerAcceptBudgetObserver)
	if !ok {
		return
	}
	deadline, _ := ctx.Deadline()
	observer.testListenerAcceptBudget(deadline)
}

// heldSuccessListenerEntryObserver is a narrow test hook for proving that a
// bilateral listener holding local direct success entered
// runHeldSuccessListener rather than discarding that success through the
// probe-race Retry Start entry. It is checked on the attempt's selected packet
// socket; production packet conns do not implement it, so it is otherwise
// inert.
type heldSuccessListenerEntryObserver interface {
	testHeldSuccessListenerEntered()
}

func notifyHeldSuccessListenerEntered(conn net.PacketConn) {
	if observer, ok := conn.(heldSuccessListenerEntryObserver); ok {
		observer.testHeldSuccessListenerEntered()
	}
}

func newListenerDirectUpgradeProtocolEngine(
	attempt directUpgradeAttempt,
	session Session,
	peer localUpgradeOffer,
	pairPlan candidatePairPlan,
	localProbeRTT time.Duration,
) directUpgradeProtocolEngine {
	_ = attempt.resources()
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerSelected)
	return directUpgradeProtocolEngine{
		role:          upgradeRoleListen,
		attempt:       attempt,
		session:       session,
		peer:          peer,
		pairPlan:      pairPlan,
		localProbeRTT: localProbeRTT,
		cursor:        &cursor,
	}
}

func (d directUpgradeProtocolEngine) runListener(ctx, handoffCtx context.Context) (UpgradeResult, error) {
	runtime := directUpgradeProtocolRuntime{handoffCtx: handoffCtx}
	selectedFrame, err := d.attempt.controlFrames.recv(handoffCtx, d.attempt.cfg.controlTimeout)
	return d.runListenerFromSelectedFrame(ctx, &runtime, selectedFrame, err)
}

// runHeldSuccessListener is the bilateral held-success entry. The
// pre-Selected await for the dialer's Selected/Start/Fallback is bounded by
// the outer context and the control timeout alone, exactly like the
// held-failure hold in the probe race, so an asymmetric probe timeout cannot
// shorten the retry-entry window. The transport handoff budget is derived
// only after that frame is consumed and keeps its normal size.
func (d directUpgradeProtocolEngine) runHeldSuccessListener(ctx context.Context, handoffBudget time.Duration) (UpgradeResult, error) {
	notifyHeldSuccessListenerEntered(d.attempt.selectedPacketConn())
	selectedFrame, err := d.attempt.controlFrames.recv(ctx, d.attempt.cfg.controlTimeout)
	handoffCtx, cancel := context.WithTimeout(ctx, handoffBudget)
	defer cancel()
	runtime := directUpgradeProtocolRuntime{handoffCtx: handoffCtx}
	return d.runListenerFromSelectedFrame(ctx, &runtime, selectedFrame, err)
}

func (d directUpgradeProtocolEngine) runListenerFromSelectedFrame(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
	selectedFrame controlFrameReadResult,
	err error,
) (UpgradeResult, error) {
	if err != nil {
		event := directUpgradeProtocolEventListenerSelectedControlError
		if isPreCommitControlTimeout(err) {
			event = directUpgradeProtocolEventListenerSelectedTimedOut
		}
		return d.terminalListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: err}, runtime)
	}

	if d.turnRetryStart != nil && decodeTurnRetryStart(selectedFrame.payload) {
		// Authenticated Retry Start reached a bilateral listener holding local
		// direct success: discard the held success and enter retry.
		return d.turnRetryStart(ctx)
	}
	selectedPhase, payloadCause := decodeUpgradeControlSelectedPairPhasePayload(selectedFrame.payload)
	if d.attempt.cfg.strict && payloadCause != nil {
		return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerSelectedControlError, directUpgradeProtocolActionInput{cause: payloadCause}, runtime)
	}
	if selectedPhase.HasFallback {
		var peerFallback *terminalFallbackReadResult
		if selectedPhase.WireFallback {
			peerFallback = &terminalFallbackReadResult{peer: upgradeControlFallback{Reason: selectedPhase.FallbackReason}}
		}
		return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerSelectedPeerFallback, directUpgradeProtocolActionInput{
			fallbackReason: selectedPhase.FallbackReason,
			peerFallback:   peerFallback,
		}, runtime)
	}
	if !selectedPhase.HasSelectedPair || !d.pairPlan.allowsSelectedPair(selectedPhase.SelectedPair) {
		if d.attempt.cfg.strict {
			return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerSelectedControlError, directUpgradeProtocolActionInput{cause: errMalformedUpgradeControl}, runtime)
		}

		return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerSelectedInvalid, directUpgradeProtocolActionInput{}, runtime)
	}

	outcome := d.dispatchListenerEvent(ctx, directUpgradeProtocolEventListenerSelectedAdmitted, directUpgradeProtocolActionInput{
		selected: selectedPhase.SelectedPair,
	}, runtime)
	if outcome.terminal || outcome.err != nil {
		return d.finishEngineOutcome(outcome)
	}
	return d.awaitListenerListen(ctx, runtime)
}

func (d directUpgradeProtocolEngine) terminalListenerEvent(
	ctx context.Context,
	event directUpgradeProtocolEvent,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	outcome := d.dispatchListenerEvent(ctx, event, input, runtime)
	if !outcome.terminal && outcome.err == nil {
		return UpgradeResult{}, errUnexpectedListenerHandoffState
	}
	return outcome.result, outcome.err
}

func (d directUpgradeProtocolEngine) dispatchListenerEvent(
	ctx context.Context,
	event directUpgradeProtocolEvent,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolDispatchResult {
	transition, ok := d.cursor.resolve(event)
	if !ok {
		panic("connect: listener transition table lacks its internal-error row")
	}
	return d.executeListenerTransition(ctx, transition, input, runtime)
}

func (d directUpgradeProtocolEngine) executeListenerTransition(
	ctx context.Context,
	transition directUpgradeProtocolTransition,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolDispatchResult {
	if d.testListenerTrace != nil && transition.listenerRow != "" {
		d.testListenerTrace(transition.listenerRow)
	}
	action := transition.action
	resources := d.attempt.resources()
	if action.commitsTransport ||
		action.kind == directUpgradeProtocolActionRecordListenerCommit ||
		action.kind == directUpgradeProtocolActionEnterListenerPostCommit {
		resources.registerCommit()
	}
	switch action.kind {
	case directUpgradeProtocolActionCoordinateFallback, directUpgradeProtocolActionFailClosed:
		d.cursor.apply(transition)
		return d.executeListenerTerminalAction(ctx, action, input, runtime)
	case directUpgradeProtocolActionStartListenerTransport:
		runtime.selected = input.selected
		drainPacketConn(runtime.handoffCtx, d.attempt.selectedPacketConn())
		runtime.listenCh = resources.startListen(
			runtime.handoffCtx,
			d.session,
			d.attempt.selectedPacketConn(),
			netUDPAddr(input.selected.remote(upgradeRoleListen).Addr),
			d.peer.handshakeMaterial,
		)
		d.cursor.apply(transition)
		return directUpgradeProtocolDispatchResult{}
	case directUpgradeProtocolActionStartListenerAccept:
		runtime.listener = input.listenResult.listener
		runtime.acceptCancel, runtime.acceptCh = resources.startAccept(ctx, runtime.listener)
		d.cursor.apply(transition)
		readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
		if err != nil {
			return d.dispatchListenerReadyFailure(ctx, runtime, err, true)
		}
		if err := d.attempt.writeUpgradeControlFrame(ctx, readyFrame); err != nil {
			return d.dispatchListenerReadyFailure(ctx, runtime, err, false)
		}
		commitCtx, cancelCommit := context.WithCancel(runtime.handoffCtx)
		runtime.commitCancel = cancelCommit
		runtime.commitBudgetCtx = commitCtx
		commitCh := make(chan commitAwaitResult, 1)
		runtime.commitCh = commitCh
		go func() {
			frame, awaitErr := d.attempt.controlFrames.recv(commitCtx, d.attempt.cfg.controlTimeout)
			commitCh <- commitAwaitResult{frame: frame, err: awaitErr}
		}()
		return directUpgradeProtocolDispatchResult{}
	case directUpgradeProtocolActionAdvance:
		if input.acceptResult.stream != nil || input.acceptResult.err != nil {
			runtime.acceptResult = input.acceptResult
		}
		d.cursor.apply(transition)
		if transition.listenerRow == directUpgradeListenerRowL11 {
			notifyListenerAcceptSelected(runtime.listener)
		}
		return directUpgradeProtocolDispatchResult{}
	case directUpgradeProtocolActionRecordListenerCommit:
		runtime.commitCh = nil
		d.cursor.apply(transition)
		return directUpgradeProtocolDispatchResult{}
	case directUpgradeProtocolActionSucceedDirect:
		transport := runtime.transport
		if !runtime.datagramsAgreed {
			transport.datagrams = nil
		}
		d.cursor.apply(transition)
		result, err := resources.succeedDirect(
			runtime.selected.candidatePair(upgradeRoleListen),
			selectedProbeRTT(runtime.selected, d.localProbeRTT),
			transport.datagrams,
		)
		return directUpgradeProtocolDispatchResult{result: result, err: err, terminal: true}
	case directUpgradeProtocolActionEnterListenerPostCommit:
		if input.acceptResult.stream != nil || input.acceptResult.err != nil {
			runtime.acceptResult = input.acceptResult
		}
		runtime.transport = runtime.acceptResult
		runtime.transportReady = true
		runtime.transportCh = nil
		d.cursor.apply(transition)
		return directUpgradeProtocolDispatchResult{}
	default:
		return directUpgradeProtocolDispatchResult{err: errUnexpectedListenerHandoffState}
	}
}

func (d directUpgradeProtocolEngine) executeListenerTerminalAction(
	ctx context.Context,
	action directUpgradeProtocolAction,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolDispatchResult {
	if d.attempt.cfg.strict && action.kind == directUpgradeProtocolActionCoordinateFallback && d.attempt.resources().strictTerminalCause(input.cause) {
		control := abortAfterOwnedResources
		// Before Listen/Accept exists the ordinary pre-operation executor owns cleanup.
		if action.fallback == directUpgradeFallbackWithSession {
			control = abortBeforeOwnedResources
		}
		result, err := d.attempt.resources().failClosed(input.cause, control)
		return directUpgradeProtocolDispatchResult{result: result, err: err, terminal: true}
	}
	switch action.kind {
	case directUpgradeProtocolActionCoordinateFallback:
		reason := action.fallbackReason
		if reason == UpgradeFallbackNone {
			reason = input.fallbackReason
		}
		fallback := newTerminalFallbackExchange(d.attempt)
		var result UpgradeResult
		var err error
		switch action.fallback {
		case directUpgradeFallbackWithSession:
			result, err = fallback.withSessionCleanup(ctx, d.session, reason)
		case directUpgradeListenerFallbackWithSessionAndPeer:
			result, err = fallback.withSessionCleanupUsingPeerFallback(ctx, d.session, reason, input.peerFallback)
		case directUpgradeListenerFallbackWithAcceptedSessionAndPeer:
			result, err = fallback.withAcceptedSessionCleanupUsingPeerFallback(ctx, d.session, reason, input.peerFallback)
		case directUpgradeListenerFallbackAfterPreCommitAcceptFailure:
			result, err = fallback.afterPreCommitAcceptFailure(ctx, d.session, runtime.commitCh)
		case directUpgradeListenerFallbackAfterHandoffTimeout:
			result, err = fallback.afterListenerHandoffTimeout(ctx, d.session, runtime.commitCh)
		default:
			panic("connect: listener fallback action has no execution plan")
		}
		return directUpgradeProtocolDispatchResult{result: result, err: err, terminal: true}
	case directUpgradeProtocolActionFailClosed:
		result, err := d.attempt.resources().failClosed(input.cause, action.control)
		return directUpgradeProtocolDispatchResult{result: result, err: err, terminal: true}
	default:
		panic("connect: listener terminal source resolved a nonterminal action")
	}
}

func (d directUpgradeProtocolEngine) executePendingListenerTerminalSource(
	ctx context.Context,
	failureEvent directUpgradeProtocolEvent,
	materializedEvent directUpgradeProtocolEvent,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolDispatchResult {
	failureTransition, failureOK := d.cursor.resolve(failureEvent)
	materializedTransition, materializedOK := d.cursor.resolve(materializedEvent)
	if !failureOK || !materializedOK || failureTransition.action != materializedTransition.action {
		panic("connect: pending Listen outcome rows do not share one terminal action")
	}
	outcome := d.executeListenerTerminalAction(ctx, failureTransition.action, input, runtime)
	transition := failureTransition
	if d.attempt.resources().joinedListenResult().listener != nil {
		transition = materializedTransition
	}
	if d.testListenerTrace != nil {
		d.testListenerTrace(transition.listenerRow)
	}
	d.cursor.apply(transition)
	return outcome
}

func (d directUpgradeProtocolEngine) awaitListenerListen(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	for {
		// Keep this as a raw sequencer race: recv could consume and drop a peer
		// fallback after Listen wins, while next leaves the losing frame buffered.
		select {
		case result := <-runtime.listenCh:
			return d.handleListenerListenCompletion(ctx, runtime, result)
		case frame := <-d.attempt.controlFrames.next():
			input := directUpgradeProtocolActionInput{cause: frame.err}
			failureEvent := directUpgradeProtocolEventListenerListenControlFailure
			materializedEvent := directUpgradeProtocolEventListenerListenControlMaterialized
			if frame.err == nil {
				peerFallback := terminalFallbackFromControlFrame(frame, d.attempt.cfg.strict)
				input.fallbackReason = peerFallback.peer.Reason
				input.peerFallback = &peerFallback
				failureEvent = directUpgradeProtocolEventListenerListenSequencerRelayFailure
				materializedEvent = directUpgradeProtocolEventListenerListenSequencerRelayMaterialized
			}
			outcome := d.executePendingListenerTerminalSource(ctx, failureEvent, materializedEvent, input, runtime)
			return d.finishEngineOutcome(outcome)
		case <-ctx.Done():
			outcome := d.executePendingListenerTerminalSource(
				ctx,
				directUpgradeProtocolEventListenerListenCancelFailure,
				directUpgradeProtocolEventListenerListenCancelMaterialized,
				directUpgradeProtocolActionInput{cause: ctx.Err()},
				runtime,
			)
			return d.finishEngineOutcome(outcome)
		case <-runtime.handoffCtx.Done():
			if ctx.Err() != nil {
				outcome := d.executePendingListenerTerminalSource(
					ctx,
					directUpgradeProtocolEventListenerListenCancelFailure,
					directUpgradeProtocolEventListenerListenCancelMaterialized,
					directUpgradeProtocolActionInput{cause: ctx.Err()},
					runtime,
				)
				return d.finishEngineOutcome(outcome)
			}
			outcome := d.executePendingListenerTerminalSource(
				ctx,
				directUpgradeProtocolEventListenerListenBudgetFailure,
				directUpgradeProtocolEventListenerListenBudgetMaterialized,
				directUpgradeProtocolActionInput{cause: d.attempt.phaseTimeoutCause(runtime.handoffCtx.Err())},
				runtime,
			)
			return d.finishEngineOutcome(outcome)
		}
	}
}

func (d directUpgradeProtocolEngine) handleListenerListenCompletion(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
	result transportListenResult,
) (UpgradeResult, error) {
	if ctxErr := ctx.Err(); ctxErr != nil {
		outcome := d.executePendingListenerTerminalSource(
			ctx,
			directUpgradeProtocolEventListenerListenCancelFailure,
			directUpgradeProtocolEventListenerListenCancelMaterialized,
			directUpgradeProtocolActionInput{cause: ctxErr},
			runtime,
		)
		return d.finishEngineOutcome(outcome)
	}
	if handoffErr := runtime.handoffCtx.Err(); handoffErr != nil {
		outcome := d.executePendingListenerTerminalSource(
			ctx,
			directUpgradeProtocolEventListenerListenBudgetFailure,
			directUpgradeProtocolEventListenerListenBudgetMaterialized,
			directUpgradeProtocolActionInput{cause: handoffErr},
			runtime,
		)
		return d.finishEngineOutcome(outcome)
	}

	event := directUpgradeProtocolEventListenerListenFailure
	switch {
	case result.listener != nil && result.err != nil:
		event = directUpgradeProtocolEventListenerListenMaterializedError
	case result.listener != nil:
		event = directUpgradeProtocolEventListenerListenSucceeded
	}
	outcome := d.dispatchListenerEvent(ctx, event, directUpgradeProtocolActionInput{listenResult: result, cause: result.err}, runtime)
	if outcome.terminal || outcome.err != nil {
		return d.finishEngineOutcome(outcome)
	}
	defer runtime.acceptCancel()
	defer runtime.commitCancel()
	return d.awaitListenerWaitingBoth(ctx, runtime)
}

func (d directUpgradeProtocolEngine) dispatchListenerReadyFailure(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
	cause error,
	encode bool,
) directUpgradeProtocolDispatchResult {
	failureEvent := directUpgradeProtocolEventListenerReadyWriteAcceptFailure
	successEvent := directUpgradeProtocolEventListenerReadyWriteAcceptSuccess
	materializedEvent := directUpgradeProtocolEventListenerReadyWriteAcceptMaterializedError
	if encode {
		failureEvent = directUpgradeProtocolEventListenerReadyEncodeAcceptFailure
		successEvent = directUpgradeProtocolEventListenerReadyEncodeAcceptSuccess
		materializedEvent = directUpgradeProtocolEventListenerReadyEncodeAcceptMaterializedError
	}
	return d.executePendingListenerAcceptTerminalSource(ctx, failureEvent, successEvent, materializedEvent, directUpgradeProtocolActionInput{cause: cause}, runtime)
}

func (d directUpgradeProtocolEngine) executePendingListenerAcceptTerminalSource(
	ctx context.Context,
	failureEvent directUpgradeProtocolEvent,
	successEvent directUpgradeProtocolEvent,
	materializedEvent directUpgradeProtocolEvent,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolDispatchResult {
	failureTransition, failureOK := d.cursor.resolve(failureEvent)
	successTransition, successOK := d.cursor.resolve(successEvent)
	materializedTransition, materializedOK := d.cursor.resolve(materializedEvent)
	if !failureOK || !successOK || !materializedOK ||
		failureTransition.action != successTransition.action ||
		failureTransition.action != materializedTransition.action {
		panic("connect: pending Accept outcome rows do not share one terminal action")
	}
	outcome := d.executeListenerTerminalAction(ctx, failureTransition.action, input, runtime)
	transition := failureTransition
	switch classifyTransportStreamResult(d.attempt.resources().joinedAcceptResult()) {
	case transportStreamResultSuccess:
		transition = successTransition
	case transportStreamResultMaterializedError:
		transition = materializedTransition
	case transportStreamResultNoMaterialization:
		// Nothing materialized; keep the failure transition.
	}
	if d.testListenerTrace != nil {
		d.testListenerTrace(transition.listenerRow)
	}
	d.cursor.apply(transition)
	return outcome
}

func (d directUpgradeProtocolEngine) awaitListenerWaitingBoth(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	select {
	case acceptResult := <-runtime.acceptCh:
		return d.handleListenerFirstAccept(ctx, runtime, acceptResult)
	case commitResult := <-runtime.commitCh:
		return d.handleListenerFirstCommit(ctx, runtime, commitResult)
	case <-runtime.handoffCtx.Done():
		if ctx.Err() != nil {
			return d.handleListenerCancellationBoundary(ctx, runtime)
		}
		return d.handleListenerHandoffTimeout(ctx, runtime)
	case <-ctx.Done():
		return d.handleListenerCancellationBoundary(ctx, runtime)
	}
}

func (d directUpgradeProtocolEngine) handleListenerFirstAccept(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
	acceptResult transportAcceptResult,
) (UpgradeResult, error) {
	if acceptResult.datagramCarrierValidationErr {
		cause := acceptResult.err
		if ctx.Err() != nil {
			cause = errors.Join(ctx.Err(), cause)
		}
		return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerAcceptDatagramValidationFailed, directUpgradeProtocolActionInput{cause: cause, acceptResult: acceptResult}, runtime)
	}
	if classifyTransportStreamResult(acceptResult) == transportStreamResultNoMaterialization {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerCancelAcceptFailure, directUpgradeProtocolActionInput{cause: ctxErr, acceptResult: acceptResult}, runtime)
		}
	}
	event := directUpgradeProtocolEventListenerPrecommitAcceptFailure
	if acceptResult.stream != nil && acceptResult.err == nil {
		event = directUpgradeProtocolEventListenerPrecommitAcceptSuccess
	} else if acceptResult.stream != nil {
		event = directUpgradeProtocolEventListenerPrecommitAcceptMaterializedError
	}
	outcome := d.dispatchListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: acceptResult.err, acceptResult: acceptResult}, runtime)
	if outcome.terminal || outcome.err != nil {
		return d.finishEngineOutcome(outcome)
	}
	return d.awaitListenerAcceptFirst(ctx, runtime)
}

func (d directUpgradeProtocolEngine) handleListenerFirstCommit(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
	commitResult commitAwaitResult,
) (UpgradeResult, error) {
	event := d.listenerCommitEvent(ctx, runtime, commitResult, false)
	if event.kind == directUpgradeControlEventCommitObserved {
		outcome := d.dispatchListenerEvent(ctx, directUpgradeProtocolEventListenerCommitFirst, directUpgradeProtocolActionInput{commitResult: commitResult}, runtime)
		if outcome.terminal || outcome.err != nil {
			return d.finishEngineOutcome(outcome)
		}
		return d.awaitListenerCommitFirst(ctx, runtime)
	}

	acceptResult := d.attempt.resources().joinPendingAcceptForClassification()
	input := directUpgradeProtocolActionInput{acceptResult: acceptResult, commitResult: commitResult}
	switch event.kind {
	case directUpgradeControlEventRelayFallback:
		input.fallbackReason = event.fallbackReason
		input.cause = ErrUpgradeTransportNotConverged
		if d.attempt.cfg.strict && event.cause != nil {
			input.cause = event.cause
		}
		if event.wireFallback {
			input.peerFallback = &terminalFallbackReadResult{peer: upgradeControlFallback{Reason: event.fallbackReason}}
		}
		event := listenerJoinedAcceptEvent(
			acceptResult,
			directUpgradeProtocolEventListenerPeerFallbackAcceptFailure,
			directUpgradeProtocolEventListenerPeerFallbackAcceptSuccess,
			directUpgradeProtocolEventListenerPeerFallbackAcceptMaterializedError,
		)
		return d.terminalListenerEvent(ctx, event, input, runtime)
	case directUpgradeControlEventControlError:
		input.cause = event.cause
		event := listenerJoinedAcceptEvent(
			acceptResult,
			directUpgradeProtocolEventListenerControlErrorAcceptFailure,
			directUpgradeProtocolEventListenerControlErrorAcceptSuccess,
			directUpgradeProtocolEventListenerControlErrorAcceptMaterializedError,
		)
		return d.terminalListenerEvent(ctx, event, input, runtime)
	default:
		return d.dispatchUnexpectedListenerState(ctx, runtime)
	}
}

func (d directUpgradeProtocolEngine) handleListenerCancellationBoundary(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	select {
	case acceptResult := <-runtime.acceptCh:
		if acceptResult.datagramCarrierValidationErr {
			return d.handleListenerFirstAccept(ctx, runtime, acceptResult)
		}
		event := directUpgradeProtocolEventListenerCancelAcceptFailure
		cause := ctx.Err()
		switch classifyTransportStreamResult(acceptResult) {
		case transportStreamResultSuccess:
			event = directUpgradeProtocolEventListenerCancelAcceptSuccess
		case transportStreamResultMaterializedError:
			event = directUpgradeProtocolEventListenerCancelAcceptMaterializedError
			cause = acceptResult.err
		case transportStreamResultNoMaterialization:
			// Nothing materialized; keep the failure event and the context cause.
		}
		return d.terminalListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: cause, acceptResult: acceptResult}, runtime)
	default:
	}

	select {
	case commitResult := <-runtime.commitCh:
		controlEvent := d.listenerCommitEvent(ctx, runtime, commitResult, false)
		if controlEvent.kind != directUpgradeControlEventCommitObserved {
			return d.handleListenerFirstCommit(ctx, runtime, commitResult)
		}
		acceptResult := d.attempt.resources().joinPendingAcceptForClassification()
		event := directUpgradeProtocolEventListenerCancelCommitAcceptFailure
		switch classifyTransportStreamResult(acceptResult) {
		case transportStreamResultSuccess:
			event = directUpgradeProtocolEventListenerCancelCommitAcceptSuccess
		case transportStreamResultMaterializedError:
			event = directUpgradeProtocolEventListenerCancelCommitAcceptMaterializedError
		case transportStreamResultNoMaterialization:
			// Nothing materialized; keep the failure event.
		}
		return d.terminalListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: ctx.Err(), acceptResult: acceptResult, commitResult: commitResult}, runtime)
	default:
	}

	acceptResult := d.attempt.resources().joinPendingAcceptForClassification()
	event := directUpgradeProtocolEventListenerCancelEmptyAcceptFailure
	switch classifyTransportStreamResult(acceptResult) {
	case transportStreamResultSuccess:
		event = directUpgradeProtocolEventListenerCancelEmptyAcceptSuccess
	case transportStreamResultMaterializedError:
		event = directUpgradeProtocolEventListenerCancelEmptyAcceptMaterializedError
	case transportStreamResultNoMaterialization:
		// Nothing materialized; keep the failure event.
	}
	return d.terminalListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: ctx.Err(), acceptResult: acceptResult}, runtime)
}

func (d directUpgradeProtocolEngine) handleListenerHandoffTimeout(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	select {
	case acceptResult := <-runtime.acceptCh:
		return d.handleListenerFirstAccept(ctx, runtime, acceptResult)
	default:
	}
	if ctx.Err() != nil {
		return d.handleListenerCancellationBoundary(ctx, runtime)
	}

	acceptResult := d.attempt.resources().joinPendingAcceptForClassification()
	class := classifyTransportStreamResult(acceptResult)
	var commitResult commitAwaitResult
	commitReady := false
	select {
	case commitResult = <-runtime.commitCh:
		if commitResult.err == nil || !d.listenerCommitTimedOut(ctx, runtime, commitResult.err) {
			commitReady = true
		} else {
			runtime.commitCh = nil
		}
	default:
	}

	if commitReady {
		controlEvent := d.listenerCommitEvent(ctx, runtime, commitResult, false)
		if controlEvent.kind == directUpgradeControlEventCommitObserved {
			event := listenerJoinedAcceptEvent(
				acceptResult,
				directUpgradeProtocolEventListenerTimeoutCommitAcceptFailure,
				directUpgradeProtocolEventListenerTimeoutCommitAcceptSuccess,
				directUpgradeProtocolEventListenerTimeoutCommitAcceptMaterializedError,
			)
			return d.terminalListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: d.attempt.phaseTimeoutCause(runtime.handoffCtx.Err()), acceptResult: acceptResult, commitResult: commitResult}, runtime)
		}
		if class == transportStreamResultNoMaterialization && controlEvent.kind == directUpgradeControlEventRelayFallback && controlEvent.wireFallback {
			peerFallback := &terminalFallbackReadResult{peer: upgradeControlFallback{Reason: controlEvent.fallbackReason}}
			return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerTimeoutWireFallback, directUpgradeProtocolActionInput{fallbackReason: controlEvent.fallbackReason, peerFallback: peerFallback, acceptResult: acceptResult}, runtime)
		}
		if controlEvent.kind == directUpgradeControlEventControlError {
			if class == transportStreamResultNoMaterialization {
				return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerTimeoutControlError, directUpgradeProtocolActionInput{cause: controlEvent.cause, acceptResult: acceptResult}, runtime)
			}
			event := listenerJoinedAcceptEvent(
				acceptResult,
				directUpgradeProtocolEventListenerControlErrorAcceptFailure,
				directUpgradeProtocolEventListenerControlErrorAcceptSuccess,
				directUpgradeProtocolEventListenerControlErrorAcceptMaterializedError,
			)
			return d.terminalListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: controlEvent.cause, acceptResult: acceptResult, commitResult: commitResult}, runtime)
		}
		if class == transportStreamResultNoMaterialization && controlEvent.kind == directUpgradeControlEventRelayFallback {
			runtime.commitCh = nil
		}
	}

	event := listenerJoinedAcceptEvent(
		acceptResult,
		directUpgradeProtocolEventListenerTimeoutAcceptFailure,
		directUpgradeProtocolEventListenerTimeoutAcceptSuccess,
		directUpgradeProtocolEventListenerTimeoutAcceptMaterializedError,
	)
	return d.terminalListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: d.attempt.phaseTimeoutCause(runtime.handoffCtx.Err()), acceptResult: acceptResult}, runtime)
}

func (d directUpgradeProtocolEngine) awaitListenerAcceptFirst(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	runtime.commitCancel()
	commitResult := <-runtime.commitCh
	if commitResult.err == nil || !d.listenerCommitStopped(ctx, runtime, commitResult.err) {
		return d.handleListenerAcceptFirstCommit(ctx, runtime, commitResult)
	}

	commitCtx, cancel := d.attempt.newOwnedTransportBudgetContext(ctx)
	runtime.commitBudgetCtx = commitCtx
	defer cancel()
	commitCh := make(chan commitAwaitResult, 1)
	go func() {
		frame, err := d.attempt.controlFrames.recv(commitCtx, 0)
		commitCh <- commitAwaitResult{frame: frame, err: err}
	}()
	select {
	case commitResult := <-commitCh:
		return d.handleListenerAcceptFirstCommit(ctx, runtime, commitResult)
	case <-ctx.Done():
		return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerAcceptFirstCanceled, directUpgradeProtocolActionInput{cause: ctx.Err()}, runtime)
	case <-commitCtx.Done():
		if ctx.Err() != nil {
			return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerAcceptFirstCanceled, directUpgradeProtocolActionInput{cause: ctx.Err()}, runtime)
		}
		if d.attempt.cfg.strict {
			return d.handleListenerAcceptFirstCommit(ctx, runtime, commitAwaitResult{err: commitCtx.Err()})
		}
		return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerAcceptFirstBudgetExpired, directUpgradeProtocolActionInput{cause: commitCtx.Err()}, runtime)
	}
}

func (d directUpgradeProtocolEngine) handleListenerAcceptFirstCommit(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
	commitResult commitAwaitResult,
) (UpgradeResult, error) {
	controlEvent := d.listenerCommitEvent(ctx, runtime, commitResult, true)
	event := directUpgradeProtocolEventListenerAcceptFirstNoncommit
	cause := ErrUpgradeTransportNotConverged
	switch {
	case controlEvent.kind == directUpgradeControlEventCommitObserved:
		event = directUpgradeProtocolEventListenerAcceptFirstCommit
		cause = nil
	case controlEvent.kind == directUpgradeControlEventControlError:
		event = directUpgradeProtocolEventListenerAcceptFirstControlError
		cause = controlEvent.cause
	case controlEvent.cause != nil:
		cause = controlEvent.cause
	}
	outcome := d.dispatchListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: cause, acceptResult: runtime.acceptResult, commitResult: commitResult}, runtime)
	if outcome.terminal || outcome.err != nil {
		return d.finishEngineOutcome(outcome)
	}
	return d.runListenerPostCommit(ctx, runtime)
}

func (d directUpgradeProtocolEngine) awaitListenerCommitFirst(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	acceptCtx, cancel := d.attempt.newOwnedTransportBudgetContext(ctx)
	defer cancel()
	notifyListenerAcceptBudget(runtime.listener, acceptCtx)
	// Keep this as a raw sequencer race: recv could consume and drop a peer
	// abort after Accept wins, while next leaves the losing frame buffered.
	select {
	case acceptResult := <-runtime.acceptCh:
		return d.handleListenerCommitFirstAccept(ctx, runtime, acceptResult)
	case peerAbort := <-d.attempt.controlFrames.next():
		acceptResult := d.attempt.resources().joinPendingAcceptForClassification()
		cause := peerAbort.err
		if cause == nil {
			// No semantic decode preceded this raw-frame race. Validate only
			// after joining Accept, preserving the original classification point.
			var payloadCause error
			if d.attempt.cfg.strict {
				_, payloadCause = decodeUpgradeControlFallbackPayload(peerAbort.payload)
			}
			cause = d.attempt.terminalControlCause(payloadCause, ErrUpgradeTransportNotConverged)
		}
		return d.terminalListenerEvent(ctx, listenerJoinedAcceptEvent(
			acceptResult,
			directUpgradeProtocolEventListenerPeerAbortAcceptFailure,
			directUpgradeProtocolEventListenerPeerAbortAcceptSuccess,
			directUpgradeProtocolEventListenerPeerAbortAcceptMaterializedError,
		), directUpgradeProtocolActionInput{cause: cause, acceptResult: acceptResult}, runtime)
	case <-ctx.Done():
		acceptResult := d.attempt.resources().joinPendingAcceptForClassification()
		return d.terminalListenerEvent(ctx, listenerJoinedAcceptEvent(
			acceptResult,
			directUpgradeProtocolEventListenerCommitFirstCancelAcceptFailure,
			directUpgradeProtocolEventListenerCommitFirstCancelAcceptSuccess,
			directUpgradeProtocolEventListenerCommitFirstCancelAcceptMaterializedError,
		), directUpgradeProtocolActionInput{cause: ctx.Err(), acceptResult: acceptResult}, runtime)
	case <-acceptCtx.Done():
		if ctx.Err() != nil {
			continueEvent := listenerJoinedAcceptEvent
			acceptResult := d.attempt.resources().joinPendingAcceptForClassification()
			return d.terminalListenerEvent(ctx, continueEvent(
				acceptResult,
				directUpgradeProtocolEventListenerCommitFirstCancelAcceptFailure,
				directUpgradeProtocolEventListenerCommitFirstCancelAcceptSuccess,
				directUpgradeProtocolEventListenerCommitFirstCancelAcceptMaterializedError,
			), directUpgradeProtocolActionInput{cause: ctx.Err(), acceptResult: acceptResult}, runtime)
		}
		acceptResult := d.attempt.resources().joinPendingAcceptForClassification()
		return d.terminalListenerEvent(ctx, listenerJoinedAcceptEvent(
			acceptResult,
			directUpgradeProtocolEventListenerAcceptBudgetFailure,
			directUpgradeProtocolEventListenerAcceptBudgetSuccess,
			directUpgradeProtocolEventListenerAcceptBudgetMaterializedError,
		), directUpgradeProtocolActionInput{cause: d.attempt.phaseTimeoutCause(acceptCtx.Err()), acceptResult: acceptResult}, runtime)
	}
}

func listenerJoinedAcceptEvent(
	result transportAcceptResult,
	failure directUpgradeProtocolEvent,
	success directUpgradeProtocolEvent,
	materializedError directUpgradeProtocolEvent,
) directUpgradeProtocolEvent {
	switch classifyTransportStreamResult(result) {
	case transportStreamResultSuccess:
		return success
	case transportStreamResultMaterializedError:
		return materializedError
	default:
		return failure
	}
}

func (d directUpgradeProtocolEngine) handleListenerCommitFirstAccept(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
	acceptResult transportAcceptResult,
) (UpgradeResult, error) {
	if acceptResult.datagramCarrierValidationErr {
		return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerAcceptDatagramValidationFailed, directUpgradeProtocolActionInput{cause: acceptResult.err, acceptResult: acceptResult}, runtime)
	}
	event := directUpgradeProtocolEventListenerCommitFirstAcceptFailure
	if acceptResult.stream != nil && acceptResult.err == nil {
		event = directUpgradeProtocolEventListenerCommitFirstAcceptSuccess
	} else if acceptResult.stream != nil {
		event = directUpgradeProtocolEventListenerCommitFirstAcceptMaterializedError
	}
	outcome := d.dispatchListenerEvent(ctx, event, directUpgradeProtocolActionInput{cause: acceptResult.err, acceptResult: acceptResult}, runtime)
	if outcome.terminal || outcome.err != nil {
		return d.finishEngineOutcome(outcome)
	}
	return d.runListenerPostCommit(ctx, runtime)
}

func (d directUpgradeProtocolEngine) runListenerPostCommit(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	postCommitCtx, cancel := d.attempt.newOwnedTransportBudgetContext(ctx)
	defer cancel()
	runtime.postCommitCtx = postCommitCtx
	runtime.postCommitCancel = cancel
	d.runtime = runtime
	return d.run(postCommitCtx, ctx)
}

func (d directUpgradeProtocolEngine) dispatchUnexpectedListenerState(
	ctx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	state := d.cursor.state
	if state == directUpgradeProtocolStateListenerAwaitingAcceptOrCommit ||
		state == directUpgradeProtocolStateListenerCommitFirst {
		acceptResult := d.attempt.resources().joinPendingAcceptForClassification()
		failure := directUpgradeProtocolEventListenerUnexpectedPreAcceptFailure
		success := directUpgradeProtocolEventListenerUnexpectedPreAcceptSuccess
		materialized := directUpgradeProtocolEventListenerUnexpectedPreAcceptMaterializedError
		if state == directUpgradeProtocolStateListenerCommitFirst {
			failure = directUpgradeProtocolEventListenerUnexpectedCommitAcceptFailure
			success = directUpgradeProtocolEventListenerUnexpectedCommitAcceptSuccess
			materialized = directUpgradeProtocolEventListenerUnexpectedCommitAcceptMaterializedError
		}
		return d.terminalListenerEvent(ctx, listenerJoinedAcceptEvent(acceptResult, failure, success, materialized), directUpgradeProtocolActionInput{cause: errUnexpectedListenerHandoffState, acceptResult: acceptResult}, runtime)
	}
	return d.terminalListenerEvent(ctx, directUpgradeProtocolEventListenerUnexpectedMaterialized, directUpgradeProtocolActionInput{cause: errUnexpectedListenerHandoffState}, runtime)
}
