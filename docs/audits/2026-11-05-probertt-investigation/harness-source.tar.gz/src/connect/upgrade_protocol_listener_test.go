package connect

import (
	"context"
	"errors"
	"net/netip"
	"slices"
	"testing"
	"time"
)

func TestListenerEngineBranchMatrix(t *testing.T) {
	tests := []struct {
		name         string
		row          directUpgradeListenerRow
		from         directUpgradeProtocolState
		event        directUpgradeProtocolEvent
		wantState    directUpgradeProtocolState
		wantAction   directUpgradeProtocolActionKind
		wantControl  failClosedControlDisposition
		wantFallback directUpgradeProtocolFallback
		wantReason   UpgradeFallbackReason
	}{
		{name: "selected_timeout", row: "L01", from: directUpgradeProtocolStateListenerSelected, event: directUpgradeProtocolEventListenerSelectedTimedOut, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeFallbackWithSession, wantReason: UpgradeFallbackTransportFailed},
		{name: "selected_control_error", row: "L02", from: directUpgradeProtocolStateListenerSelected, event: directUpgradeProtocolEventListenerSelectedControlError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortBeforeOwnedResources},
		{name: "selected_peer_fallback", row: "L03", from: directUpgradeProtocolStateListenerSelected, event: directUpgradeProtocolEventListenerSelectedPeerFallback, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeListenerFallbackWithSessionAndPeer},
		{name: "selected_invalid", row: "L04", from: directUpgradeProtocolStateListenerSelected, event: directUpgradeProtocolEventListenerSelectedInvalid, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeFallbackWithSession, wantReason: UpgradeFallbackProtocolMismatch},
		{name: "selected_starts_registered_listen", row: "L05-P", from: directUpgradeProtocolStateListenerSelected, event: directUpgradeProtocolEventListenerSelectedAdmitted, wantState: directUpgradeProtocolStateListenerListenPending, wantAction: directUpgradeProtocolActionStartListenerTransport},
		{name: "listen_sequencer_relay_failure", row: "L05-F", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenSequencerRelayFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeListenerFallbackWithSessionAndPeer},
		{name: "listen_sequencer_relay_materialized", row: "L05-S", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenSequencerRelayMaterialized, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeListenerFallbackWithSessionAndPeer},
		{name: "listen_control_error_failure", row: "L05-EF", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenControlFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortBeforeOwnedResources},
		{name: "listen_control_error_materialized", row: "L05-ES", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenControlMaterialized, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortBeforeOwnedResources},
		{name: "listen_caller_cancel_failure", row: "L05-CF", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenCancelFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortBeforeOwnedResources},
		{name: "listen_caller_cancel_materialized", row: "L05-CS", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenCancelMaterialized, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortBeforeOwnedResources},
		{name: "listen_handoff_budget_failure", row: "L05-TF", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenBudgetFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeFallbackWithSession, wantReason: UpgradeFallbackTransportFailed},
		{name: "listen_handoff_budget_materialized", row: "L05-TS", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenBudgetMaterialized, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeFallbackWithSession, wantReason: UpgradeFallbackTransportFailed},
		{name: "listen_failure_without_listener", row: "L06-F", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeFallbackWithSession, wantReason: UpgradeFallbackTransportFailed},
		{name: "listen_listener_with_error", row: "L06-E", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeFallbackWithSession, wantReason: UpgradeFallbackTransportFailed},
		{name: "listen_success_registers_accept_before_ready", row: "L07", from: directUpgradeProtocolStateListenerListenPending, event: directUpgradeProtocolEventListenerListenSucceeded, wantState: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, wantAction: directUpgradeProtocolActionStartListenerAccept},
		{name: "ready_encode_accept_failure", row: "L08-F", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerReadyEncodeAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: retainForOuterSettlement},
		{name: "ready_encode_accept_success", row: "L08-S", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerReadyEncodeAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: retainForOuterSettlement},
		{name: "ready_encode_accept_stream_error", row: "L08-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerReadyEncodeAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: retainForOuterSettlement},
		{name: "ready_write_accept_failure", row: "L09-F", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerReadyWriteAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "ready_write_accept_success", row: "L09-S", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerReadyWriteAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "ready_write_accept_stream_error", row: "L09-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerReadyWriteAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "precommit_accept_failure_or_completed_timeout_failure", row: "L10-F", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerPrecommitAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeListenerFallbackAfterPreCommitAcceptFailure, wantReason: UpgradeFallbackTransportFailed},
		{name: "precommit_accept_stream_error_or_completed_timeout_stream_error", row: "L10-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerPrecommitAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "accept_before_commit_or_completed_timeout_success", row: "L11", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerPrecommitAcceptSuccess, wantState: directUpgradeProtocolStateListenerAcceptFirst, wantAction: directUpgradeProtocolActionAdvance},
		{name: "accepted_datagram_validation", row: "L12", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerAcceptDatagramValidationFailed, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "commit_before_accept", row: "L13", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCommitFirst, wantState: directUpgradeProtocolStateListenerCommitFirst, wantAction: directUpgradeProtocolActionRecordListenerCommit},
		{name: "peer_fallback_accept_failure", row: "L14-F", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerPeerFallbackAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeListenerFallbackWithAcceptedSessionAndPeer},
		{name: "peer_fallback_accept_success", row: "L14-S", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerPeerFallbackAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "peer_fallback_accept_stream_error", row: "L14-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerPeerFallbackAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "control_error_accept_failure", row: "L15-F", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerControlErrorAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "control_error_accept_success", row: "L15-S", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerControlErrorAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "control_error_accept_stream_error", row: "L15-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerControlErrorAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "timeout_accept_failure", row: "L16-F", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerTimeoutAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeListenerFallbackAfterHandoffTimeout, wantReason: UpgradeFallbackTransportFailed},
		{name: "timeout_accept_success", row: "L16-S", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerTimeoutAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "timeout_accept_stream_error", row: "L16-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerTimeoutAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "timeout_commit_accept_failure", row: "L17-F", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerTimeoutCommitAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "timeout_commit_accept_success", row: "L17-S", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerTimeoutCommitAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "timeout_commit_accept_stream_error", row: "L17-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerTimeoutCommitAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "handoff_timeout_wire_fallback", row: "L18", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerTimeoutWireFallback, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionCoordinateFallback, wantFallback: directUpgradeListenerFallbackWithAcceptedSessionAndPeer},
		{name: "handoff_timeout_control_error", row: "L19", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerTimeoutControlError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "cancel_failed_accept_wins", row: "L20", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCancelAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "cancel_successful_accept_wins", row: "L21", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCancelAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "cancel_accept_stream_error_wins", row: "L21-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCancelAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "cancel_commit_accept_failure", row: "L22-F", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCancelCommitAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "cancel_commit_accept_success", row: "L22-S", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCancelCommitAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "cancel_commit_accept_stream_error", row: "L22-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCancelCommitAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "cancel_poll_empty_accept_failure", row: "L23-F", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCancelEmptyAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "cancel_poll_empty_accept_success", row: "L23-S", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCancelEmptyAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "cancel_poll_empty_accept_stream_error", row: "L23-E", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerCancelEmptyAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "accept_first_commit", row: "L24", from: directUpgradeProtocolStateListenerAcceptFirst, event: directUpgradeProtocolEventListenerAcceptFirstCommit, wantState: directUpgradeProtocolStatePostCommitStart, wantAction: directUpgradeProtocolActionEnterListenerPostCommit},
		{name: "accept_first_control_error", row: "L25", from: directUpgradeProtocolStateListenerAcceptFirst, event: directUpgradeProtocolEventListenerAcceptFirstControlError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "accept_first_noncommit", row: "L26", from: directUpgradeProtocolStateListenerAcceptFirst, event: directUpgradeProtocolEventListenerAcceptFirstNoncommit, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "accept_first_budget_expiry", row: "L27", from: directUpgradeProtocolStateListenerAcceptFirst, event: directUpgradeProtocolEventListenerAcceptFirstBudgetExpired, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "accept_first_caller_cancel", row: "L28", from: directUpgradeProtocolStateListenerAcceptFirst, event: directUpgradeProtocolEventListenerAcceptFirstCanceled, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "commit_first_accept_success", row: "L29", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerCommitFirstAcceptSuccess, wantState: directUpgradeProtocolStatePostCommitStart, wantAction: directUpgradeProtocolActionEnterListenerPostCommit},
		{name: "commit_first_accept_failure_without_stream", row: "L30-F", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerCommitFirstAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "commit_first_accept_stream_with_error", row: "L30-E", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerCommitFirstAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "peer_abort_accept_failure", row: "L31-F", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerPeerAbortAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "peer_abort_accept_success", row: "L31-S", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerPeerAbortAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "peer_abort_accept_stream_error", row: "L31-E", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerPeerAbortAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "accept_budget_failure_result", row: "L32-F", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerAcceptBudgetFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "accept_budget_success_result", row: "L32-S", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerAcceptBudgetSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "accept_budget_stream_error_result", row: "L32-E", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerAcceptBudgetMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "commit_first_cancel_accept_failure", row: "L33-F", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerCommitFirstCancelAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "commit_first_cancel_accept_success", row: "L33-S", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerCommitFirstCancelAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "commit_first_cancel_accept_stream_error", row: "L33-E", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerCommitFirstCancelAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "accepted_send_failure", row: "L34", from: directUpgradeProtocolStatePostCommitStart, event: directUpgradeProtocolEventListenerAcceptedSendFailed, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "converged_control_error", row: "L35", from: directUpgradeProtocolStatePostCommitAccepted, event: directUpgradeProtocolEventListenerConvergedReadFailed, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "converged_wrong_phase", row: "L36", from: directUpgradeProtocolStatePostCommitAccepted, event: directUpgradeProtocolEventListenerConvergedWrongPhase, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "datagram_mismatch", row: "L37", from: directUpgradeProtocolStatePostCommitAccepted, event: directUpgradeProtocolEventListenerDatagramMismatch, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "confirmed_send_failure", row: "L38", from: directUpgradeProtocolStatePostCommitConverged, event: directUpgradeProtocolEventListenerConfirmedSendFailed, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "postcommit_caller_cancel", row: "L39", from: directUpgradeProtocolStatePostCommitAccepted, event: directUpgradeProtocolEventListenerPostcommitCanceled, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "postcommit_budget_expiry", row: "L40", from: directUpgradeProtocolStatePostCommitAccepted, event: directUpgradeProtocolEventListenerPostcommitBudgetExpired, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "confirmed_success", row: "L41", from: directUpgradeProtocolStatePostCommitConverged, event: directUpgradeProtocolEventListenerConfirmed, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionSucceedDirect},
		{name: "unexpected_pre_accept_failure", row: "L42-PF", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerUnexpectedPreAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "unexpected_pre_accept_success", row: "L42-PS", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerUnexpectedPreAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "unexpected_pre_accept_stream_error", row: "L42-PE", from: directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, event: directUpgradeProtocolEventListenerUnexpectedPreAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "unexpected_commit_accept_failure", row: "L42-CF", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerUnexpectedCommitAcceptFailure, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "unexpected_commit_accept_success", row: "L42-CS", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerUnexpectedCommitAcceptSuccess, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "unexpected_commit_accept_stream_error", row: "L42-CE", from: directUpgradeProtocolStateListenerCommitFirst, event: directUpgradeProtocolEventListenerUnexpectedCommitAcceptMaterializedError, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
		{name: "unexpected_materialized", row: "L42-M", from: directUpgradeProtocolStateListenerAcceptFirst, event: directUpgradeProtocolEventListenerUnexpectedMaterialized, wantState: directUpgradeProtocolStateTerminal, wantAction: directUpgradeProtocolActionFailClosed, wantControl: abortAfterOwnedResources},
	}

	if got, want := len(tests), 82; got != want {
		t.Fatalf("listener branch cases = %d, want %d", got, want)
	}
	seen := make(map[directUpgradeListenerRow]struct{}, len(tests))
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			transition, ok := nextDirectUpgradeProtocolTransition(upgradeRoleListen, test.from, test.event)
			if !ok {
				t.Fatalf("listener engine has no %s transition", test.row)
			}
			if transition.listenerRow != test.row {
				t.Fatalf("listener row = %q, want %q", transition.listenerRow, test.row)
			}
			if transition.to != test.wantState {
				t.Fatalf("listener state = %v, want %v", transition.to, test.wantState)
			}
			if transition.action.kind != test.wantAction {
				t.Fatalf("listener action = %v, want %v", transition.action.kind, test.wantAction)
			}
			if transition.action.control != test.wantControl {
				t.Fatalf("listener control disposition = %v, want %v", transition.action.control, test.wantControl)
			}
			if transition.action.fallback != test.wantFallback {
				t.Fatalf("listener fallback mode = %v, want %v", transition.action.fallback, test.wantFallback)
			}
			if transition.action.fallbackReason != test.wantReason {
				t.Fatalf("listener fallback reason = %q, want %q", transition.action.fallbackReason, test.wantReason)
			}
			if _, duplicate := seen[test.row]; duplicate {
				t.Fatalf("listener row %s appears more than once", test.row)
			}
			seen[test.row] = struct{}{}
			exerciseListenerEngineRow(t, transition)
		})
	}
}

func exerciseListenerEngineRow(t *testing.T, transition directUpgradeProtocolTransition) {
	t.Helper()
	peerFallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:46901")}}
	channel := &terminalTestChannel{}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(controlFrameReadResult{payload: peerFallbackFrame[4:]}),
		cfg:           upgradeConfig{packetConn: packetConn, controlTimeout: 20 * time.Millisecond, probeTimeout: 20 * time.Millisecond},
	})
	session := &terminalTestSession{}
	listener := &terminalTestDefinitiveAcceptListener{}
	operationCause := errors.New("listener semantic matrix cause")
	acceptOperationCause := errors.New("listener semantic matrix Accept result")
	acceptResult := listenerRowAcceptResultForTest(transition.listenerRow, packetConn, acceptOperationCause)
	runtime := directUpgradeProtocolRuntime{
		handoffCtx: context.Background(),
		selected: selectedPair{
			dialer:   Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:46902")},
			listener: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:46901")},
		},
		listener:       listener,
		acceptResult:   acceptResult,
		transport:      acceptResult,
		transportReady: true,
		postCommitCtx:  context.Background(),
	}
	input := directUpgradeProtocolActionInput{
		cause:          operationCause,
		fallbackReason: UpgradeFallbackTransportFailed,
		peerFallback: &terminalFallbackReadResult{
			peer: upgradeControlFallback{Reason: UpgradeFallbackTransportFailed},
		},
		selected:     runtime.selected,
		acceptResult: acceptResult,
		transport:    acceptResult,
	}

	seedListenerOwnerForRowTest(t, attempt.resources(), session, listener, transition.listenerRow, acceptResult, &runtime, &input)
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, concreteListenerStateForTest(transition))
	var observed []directUpgradeListenerRow
	engine := directUpgradeProtocolEngine{
		role:              upgradeRoleListen,
		attempt:           attempt,
		session:           session,
		peer:              localUpgradeOffer{handshakeMaterial: []byte("matrix-peer-material")},
		localProbeRTT:     time.Millisecond,
		cursor:            &cursor,
		testListenerTrace: func(row directUpgradeListenerRow) { observed = append(observed, row) },
	}

	outcome := engine.dispatchListenerEvent(context.Background(), transition.event, input, &runtime)
	if !slices.Equal(observed, []directUpgradeListenerRow{transition.listenerRow}) {
		t.Fatalf("managed dispatch trace = %v, want exactly %s", observed, transition.listenerRow)
	}
	wantTerminal := transition.action.kind == directUpgradeProtocolActionCoordinateFallback ||
		transition.action.kind == directUpgradeProtocolActionFailClosed ||
		transition.action.kind == directUpgradeProtocolActionSucceedDirect
	if outcome.terminal != wantTerminal {
		t.Fatalf("managed dispatch terminal = %v, want %v", outcome.terminal, wantTerminal)
	}
	if !wantTerminal && outcome.err != nil {
		t.Fatalf("managed continuation error = %v", outcome.err)
	}
	owner := attempt.resources()
	if transition.action.kind == directUpgradeProtocolActionFailClosed {
		if !errors.Is(outcome.err, operationCause) {
			t.Fatalf("fail-closed error = %v, want exact operation cause", outcome.err)
		}
		owner.mu.Lock()
		disposition, control := owner.terminalDisposition, owner.terminalControl
		owner.mu.Unlock()
		if disposition != attemptTerminalFailClosed || control != transition.action.control {
			t.Fatalf("fail-closed terminal state = (%v, %v), want (%v, %v)", disposition, control, attemptTerminalFailClosed, transition.action.control)
		}
	}
	if transition.action.kind == directUpgradeProtocolActionCoordinateFallback {
		if outcome.err != nil || outcome.result.Path != UpgradePathRelay {
			t.Fatalf("fallback outcome = %#v, %v; want relay", outcome.result, outcome.err)
		}
		owner.mu.Lock()
		disposition := owner.terminalDisposition
		owner.mu.Unlock()
		if disposition != attemptTerminalSettleRelay {
			t.Fatalf("fallback disposition = %v, want settle-relay", disposition)
		}
	}
	if transition.action.kind == directUpgradeProtocolActionSucceedDirect {
		if outcome.err != nil || outcome.result.Path != UpgradePathDirect || outcome.result.Stream == nil {
			t.Fatalf("direct outcome = %#v, %v; want direct stream", outcome.result, outcome.err)
		}
		if outcome.result.ProbeRTT != time.Millisecond {
			t.Fatalf("direct ProbeRTT = %s, want local probe fallback %s", outcome.result.ProbeRTT, time.Millisecond)
		}
		owner.mu.Lock()
		disposition := owner.terminalDisposition
		owner.mu.Unlock()
		if disposition != attemptTerminalSucceedDirect {
			t.Fatalf("success disposition = %v, want succeed-direct", disposition)
		}
		_ = outcome.result.Stream.Close()
	}
	cleanupListenerContinuationForTest(t, transition, attempt.resources(), &runtime, operationCause)
}

func seedListenerOwnerForRowTest(
	t *testing.T,
	owner *attemptResources,
	session *terminalTestSession,
	listener *terminalTestDefinitiveAcceptListener,
	row directUpgradeListenerRow,
	acceptResult transportAcceptResult,
	runtime *directUpgradeProtocolRuntime,
	input *directUpgradeProtocolActionInput,
) {
	t.Helper()
	switch {
	case listenerRowPreOperationForTest(row):
		return
	case listenerRowPendingListenForTest(row):
		result := transportListenResult{err: errors.New("matrix Listen failure")}
		if row == directUpgradeListenerRowL05S || row == directUpgradeListenerRowL05ES || row == directUpgradeListenerRowL05CS || row == directUpgradeListenerRowL05TS {
			result = transportListenResult{listener: &terminalTestReturnedListener{}}
		}
		ready := make(chan struct{})
		close(ready)
		owner.registerSession(session)
		owner.mu.Lock()
		owner.listen = &ownedListenOperation{cancel: func() {}, ready: ready, done: make(chan transportListenResult, 1), result: result}
		owner.listenState = attemptOperationRunning
		owner.mu.Unlock()
		return
	case row == directUpgradeListenerRowL06F || row == directUpgradeListenerRowL06E || row == directUpgradeListenerRowL07:
		result := transportListenResult{err: errors.New("matrix Listen failure")}
		if row == directUpgradeListenerRowL06E {
			result.listener = &terminalTestReturnedListener{}
		}
		if row == directUpgradeListenerRowL07 {
			result = transportListenResult{listener: listener}
		}
		ready := make(chan struct{})
		close(ready)
		owner.registerSession(session)
		owner.mu.Lock()
		owner.listen = &ownedListenOperation{cancel: func() {}, ready: ready, done: make(chan transportListenResult, 1), result: result}
		owner.listenState = attemptOperationComplete
		owner.listener = result.listener
		owner.mu.Unlock()
		input.listenResult = result
		return
	}

	if listenerRowUsesPendingAcceptForTest(row) || row == directUpgradeListenerRowL13 {
		pendingListener := newTerminalTestAcceptListener(nil, acceptResult.stream, acceptResult.err)
		owner.registerSession(session)
		_, runtime.acceptCh = owner.startAccept(context.Background(), pendingListener)
		runtime.listener = pendingListener
		<-pendingListener.acceptStarted
	} else {
		registerCompletedTestAcceptAttempt(owner, session, listener, acceptResult)
		acceptResult = owner.snapshot().acceptResult
		runtime.acceptResult = acceptResult
		runtime.transport = acceptResult
		input.acceptResult = acceptResult
		input.transport = acceptResult
	}
	if listenerRowCommittedBeforeActionForTest(row) {
		owner.registerCommit()
	}
}

func cleanupListenerContinuationForTest(t *testing.T, transition directUpgradeProtocolTransition, owner *attemptResources, runtime *directUpgradeProtocolRuntime, cause error) {
	t.Helper()
	if transition.action.kind == directUpgradeProtocolActionStartListenerTransport {
		result := <-runtime.listenCh
		if result.listener == nil && result.err == nil {
			t.Fatal("L05-P Listen produced nil/nil")
		}
		_, _ = owner.settleRelay(UpgradeFallbackTransportFailed)
		return
	}
	if transition.action.kind == directUpgradeProtocolActionStartListenerAccept {
		if runtime.acceptCancel != nil {
			runtime.acceptCancel()
		}
		if runtime.commitCancel != nil {
			runtime.commitCancel()
		}
		<-runtime.acceptCh
		_, _ = owner.failClosed(cause, abortAfterOwnedResources)
		return
	}
	if !transitionActionTerminalForTest(transition.action.kind) && owner.snapshot().accept != attemptOperationUnregistered {
		_, _ = owner.failClosed(cause, abortAfterOwnedResources)
	}
}

func transitionActionTerminalForTest(kind directUpgradeProtocolActionKind) bool {
	return kind == directUpgradeProtocolActionCoordinateFallback || kind == directUpgradeProtocolActionFailClosed || kind == directUpgradeProtocolActionSucceedDirect
}

func listenerRowPreOperationForTest(row directUpgradeListenerRow) bool {
	return row == directUpgradeListenerRowL01 || row == directUpgradeListenerRowL02 || row == directUpgradeListenerRowL03 || row == directUpgradeListenerRowL04 || row == directUpgradeListenerRowL05P
}

func listenerRowPendingListenForTest(row directUpgradeListenerRow) bool {
	switch row {
	case directUpgradeListenerRowL05F, directUpgradeListenerRowL05S, directUpgradeListenerRowL05EF, directUpgradeListenerRowL05ES,
		directUpgradeListenerRowL05CF, directUpgradeListenerRowL05CS, directUpgradeListenerRowL05TF, directUpgradeListenerRowL05TS:
		return true
	default:
		return false
	}
}

func listenerRowUsesPendingAcceptForTest(row directUpgradeListenerRow) bool {
	switch row {
	case directUpgradeListenerRowL08F, directUpgradeListenerRowL08S, directUpgradeListenerRowL08E,
		directUpgradeListenerRowL09F, directUpgradeListenerRowL09S, directUpgradeListenerRowL09E,
		directUpgradeListenerRowL14F, directUpgradeListenerRowL14S, directUpgradeListenerRowL14E,
		directUpgradeListenerRowL15F, directUpgradeListenerRowL15S, directUpgradeListenerRowL15E,
		directUpgradeListenerRowL16F, directUpgradeListenerRowL16S, directUpgradeListenerRowL16E,
		directUpgradeListenerRowL17F, directUpgradeListenerRowL17S, directUpgradeListenerRowL17E,
		directUpgradeListenerRowL22F, directUpgradeListenerRowL22S, directUpgradeListenerRowL22E,
		directUpgradeListenerRowL23F, directUpgradeListenerRowL23S, directUpgradeListenerRowL23E,
		directUpgradeListenerRowL31F, directUpgradeListenerRowL31S, directUpgradeListenerRowL31E,
		directUpgradeListenerRowL32F, directUpgradeListenerRowL32S, directUpgradeListenerRowL32E,
		directUpgradeListenerRowL33F, directUpgradeListenerRowL33S, directUpgradeListenerRowL33E,
		directUpgradeListenerRowL42PF, directUpgradeListenerRowL42PS, directUpgradeListenerRowL42PE,
		directUpgradeListenerRowL42CF, directUpgradeListenerRowL42CS, directUpgradeListenerRowL42CE:
		return true
	default:
		return false
	}
}

func listenerRowCommittedBeforeActionForTest(row directUpgradeListenerRow) bool {
	switch row {
	case directUpgradeListenerRowL29, directUpgradeListenerRowL30F, directUpgradeListenerRowL30E,
		directUpgradeListenerRowL31F, directUpgradeListenerRowL31S, directUpgradeListenerRowL31E,
		directUpgradeListenerRowL32F, directUpgradeListenerRowL32S, directUpgradeListenerRowL32E,
		directUpgradeListenerRowL33F, directUpgradeListenerRowL33S, directUpgradeListenerRowL33E,
		directUpgradeListenerRowL34, directUpgradeListenerRowL35, directUpgradeListenerRowL36,
		directUpgradeListenerRowL37, directUpgradeListenerRowL38, directUpgradeListenerRowL39,
		directUpgradeListenerRowL40, directUpgradeListenerRowL41,
		directUpgradeListenerRowL42CF, directUpgradeListenerRowL42CS, directUpgradeListenerRowL42CE:
		return true
	default:
		return false
	}
}

func listenerRowAcceptResultForTest(row directUpgradeListenerRow, packetConn *terminalTestPacketConn, operationCause error) transportAcceptResult {
	stream := &terminalTestStream{packetConn: packetConn}
	switch row {
	case directUpgradeListenerRowL08F, directUpgradeListenerRowL09F, directUpgradeListenerRowL10F,
		directUpgradeListenerRowL14F, directUpgradeListenerRowL15F, directUpgradeListenerRowL16F,
		directUpgradeListenerRowL17F, directUpgradeListenerRowL18, directUpgradeListenerRowL19,
		directUpgradeListenerRowL20, directUpgradeListenerRowL22F, directUpgradeListenerRowL23F,
		directUpgradeListenerRowL30F, directUpgradeListenerRowL31F, directUpgradeListenerRowL32F,
		directUpgradeListenerRowL33F, directUpgradeListenerRowL42PF, directUpgradeListenerRowL42CF,
		directUpgradeListenerRowL13:
		return transportAcceptResult{err: operationCause}
	case directUpgradeListenerRowL08E, directUpgradeListenerRowL09E, directUpgradeListenerRowL10E,
		directUpgradeListenerRowL14E, directUpgradeListenerRowL15E, directUpgradeListenerRowL16E,
		directUpgradeListenerRowL17E, directUpgradeListenerRowL21E, directUpgradeListenerRowL22E,
		directUpgradeListenerRowL23E, directUpgradeListenerRowL30E, directUpgradeListenerRowL31E,
		directUpgradeListenerRowL32E, directUpgradeListenerRowL33E, directUpgradeListenerRowL42PE,
		directUpgradeListenerRowL42CE:
		return transportAcceptResult{stream: stream, err: operationCause}
	case directUpgradeListenerRowL12:
		return transportAcceptResult{stream: stream, err: operationCause, datagramCarrierValidationErr: true}
	default:
		return transportAcceptResult{stream: stream}
	}
}

func concreteListenerStateForTest(transition directUpgradeProtocolTransition) directUpgradeProtocolState {
	switch transition.from {
	case directUpgradeProtocolStateListenerAcceptPending:
		return directUpgradeProtocolStateListenerAwaitingAcceptOrCommit
	case directUpgradeProtocolStateListenerMaterialized:
		return directUpgradeProtocolStateListenerAcceptFirst
	case directUpgradeProtocolStateListenerPostCommit:
		switch transition.listenerRow {
		case directUpgradeListenerRowL35, directUpgradeListenerRowL36, directUpgradeListenerRowL37:
			return directUpgradeProtocolStatePostCommitAccepted
		case directUpgradeListenerRowL38:
			return directUpgradeProtocolStatePostCommitConverged
		default:
			return directUpgradeProtocolStatePostCommitStart
		}
	default:
		return transition.from
	}
}

func TestListenerEngineSelectedTimeout(t *testing.T) {
	peerFallback, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	channel := newWriteTriggeredControlChannel(peerFallback, 1)
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			controlTimeout: 10 * time.Millisecond,
			probeTimeout:   time.Second,
		},
	})
	session := &directHandoffSession{}
	engine := newListenerDirectUpgradeProtocolEngine(
		attempt,
		session,
		localUpgradeOffer{},
		candidatePairPlan{},
		0,
	)
	var rows []directUpgradeListenerRow
	engine.testListenerTrace = func(row directUpgradeListenerRow) {
		rows = append(rows, row)
	}
	result, err := engine.runListener(context.Background(), context.Background())
	if err != nil {
		t.Fatalf("listener engine selected timeout: %v", err)
	}
	if result.Path != UpgradePathRelay || result.FallbackReason != UpgradeFallbackTransportFailed {
		t.Fatalf("listener engine result = %#v, want transport_failed relay fallback", result)
	}
	if len(rows) != 1 || rows[0] != directUpgradeListenerRowL01 {
		t.Fatalf("listener engine rows = %v, want [%s]", rows, directUpgradeListenerRowL01)
	}
}

func TestListenerEngineHandoffTimeoutNonWireFallbackUsesSequencer(t *testing.T) {
	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	peerFallback, err := encodeUpgradeControlFallback(UpgradeFallbackTransportMismatch)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	channel := newScriptedControlChannel(nil, false)
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(controlFrameReadResult{payload: peerFallback[4:]}),
		cfg:           upgradeConfig{controlTimeout: 20 * time.Millisecond},
	})
	session := &directHandoffSession{}
	listener := &directHandoffListener{}
	registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, transportAcceptResult{err: errors.New("Accept failed")})
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit)
	var rows []directUpgradeListenerRow
	engine := directUpgradeProtocolEngine{
		role:              upgradeRoleListen,
		attempt:           attempt,
		session:           session,
		cursor:            &cursor,
		testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) },
	}
	commitCh := make(chan commitAwaitResult, 1)
	commitCh <- commitAwaitResult{frame: controlFrameReadResult{payload: readyFrame[4:]}}
	handoffCtx, cancelHandoff := context.WithCancel(context.Background())
	cancelHandoff()

	result, err := engine.handleListenerHandoffTimeout(context.Background(), &directUpgradeProtocolRuntime{
		handoffCtx: handoffCtx,
		acceptCh:   make(chan transportAcceptResult),
		commitCh:   commitCh,
	})
	if err != nil {
		t.Fatalf("handoff timeout non-wire fallback: %v", err)
	}
	if result.Path != UpgradePathRelay || result.FallbackReason != UpgradeFallbackTransportMismatch {
		t.Fatalf("result = %#v, want transport_mismatch relay fallback", result)
	}
	if !slices.Equal(rows, []directUpgradeListenerRow{directUpgradeListenerRowL16F}) {
		t.Fatalf("rows = %v, want [L16-F]", rows)
	}
	if errors.Is(err, ErrUpgradeControlTimeout) {
		t.Fatalf("result retained control timeout: %v", err)
	}
}

func TestListenerEngineHandoffTimeoutCompletedControlAcrossAcceptShapes(t *testing.T) {
	controlErr := errors.New("completed commit control read failed")
	operationErr := errors.New("Accept failed")
	tests := []struct {
		name       string
		result     func(*terminalTestPacketConn) transportAcceptResult
		wantRow    directUpgradeListenerRow
		wantStream bool
	}{
		{name: "failure", result: func(*terminalTestPacketConn) transportAcceptResult { return transportAcceptResult{err: operationErr} }, wantRow: directUpgradeListenerRowL19},
		{name: "success", result: func(packetConn *terminalTestPacketConn) transportAcceptResult {
			return transportAcceptResult{stream: &terminalTestStream{packetConn: packetConn}}
		}, wantRow: directUpgradeListenerRowL15S, wantStream: true},
		{name: "stream_error", result: func(packetConn *terminalTestPacketConn) transportAcceptResult {
			return transportAcceptResult{stream: &terminalTestStream{packetConn: packetConn}, err: operationErr}
		}, wantRow: directUpgradeListenerRowL15E, wantStream: true},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47001")}}
			channel := &terminalTestChannel{}
			attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel, cfg: upgradeConfig{packetConn: packetConn}})
			session := &terminalTestSession{}
			listener := &terminalTestDefinitiveAcceptListener{}
			acceptResult := test.result(packetConn)
			registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, acceptResult)
			cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit)
			var rows []directUpgradeListenerRow
			engine := directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor, testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) }}
			commitCh := make(chan commitAwaitResult, 1)
			commitCh <- commitAwaitResult{err: controlErr}
			handoffCtx, cancelHandoff := context.WithCancel(context.Background())
			cancelHandoff()

			result, err := engine.handleListenerHandoffTimeout(context.Background(), &directUpgradeProtocolRuntime{
				handoffCtx: handoffCtx,
				acceptCh:   make(chan transportAcceptResult),
				commitCh:   commitCh,
			})
			if result != (UpgradeResult{}) {
				t.Fatalf("result = %#v, want zero", result)
			}
			if !errors.Is(err, controlErr) {
				t.Fatalf("error = %v, want completed control cause %v", err, controlErr)
			}
			if test.wantStream && !errors.Is(err, ErrUpgradeTransportNotConverged) {
				t.Fatalf("materialized error = %v, want transport-not-converged", err)
			}
			if !slices.Equal(rows, []directUpgradeListenerRow{test.wantRow}) {
				t.Fatalf("rows = %v, want [%s]", rows, test.wantRow)
			}
			owner := attempt.resources()
			owner.mu.Lock()
			disposition, control := owner.terminalDisposition, owner.terminalControl
			owner.mu.Unlock()
			if disposition != attemptTerminalFailClosed || control != abortAfterOwnedResources {
				t.Fatalf("terminal state = (%v, %v), want fail-closed/abort-after", disposition, control)
			}
		})
	}
}

func TestListenerEngineAcceptFirstControlErrorUsesL25(t *testing.T) {
	controlErr := errors.New("accept-first control read failed")
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47101")}}
	channel := &terminalTestChannel{}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel, cfg: upgradeConfig{packetConn: packetConn}})
	session := &terminalTestSession{}
	listener := &terminalTestDefinitiveAcceptListener{}
	registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, transportAcceptResult{stream: &terminalTestStream{packetConn: packetConn}})
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerAcceptFirst)
	var rows []directUpgradeListenerRow
	engine := directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor, testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) }}

	result, err := engine.handleListenerAcceptFirstCommit(context.Background(), &directUpgradeProtocolRuntime{}, commitAwaitResult{err: controlErr})
	if result != (UpgradeResult{}) {
		t.Fatalf("result = %#v, want zero", result)
	}
	if !errors.Is(err, controlErr) || !errors.Is(err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("error = %v, want control cause and transport-not-converged", err)
	}
	if !slices.Equal(rows, []directUpgradeListenerRow{directUpgradeListenerRowL25}) {
		t.Fatalf("rows = %v, want [L25]", rows)
	}
	owner := attempt.resources()
	owner.mu.Lock()
	disposition, control := owner.terminalDisposition, owner.terminalControl
	owner.mu.Unlock()
	if disposition != attemptTerminalFailClosed || control != abortAfterOwnedResources {
		t.Fatalf("terminal state = (%v, %v), want fail-closed/abort-after", disposition, control)
	}
}

func TestListenerEngineAcceptFirstTransportFailureUsesL26(t *testing.T) {
	tests := []struct {
		name      string
		result    func(*testing.T) commitAwaitResult
		wantCause error
	}{
		{
			name: "nil cause retains transport not converged",
			result: func(t *testing.T) commitAwaitResult {
				return commitResultWithPayload(t, func() ([]byte, error) {
					return encodeUpgradeControlPhase(upgradeControlPhaseReady)
				})
			},
			wantCause: ErrUpgradeTransportNotConverged,
		},
		{
			name:      "timeout cause is preserved",
			result:    func(*testing.T) commitAwaitResult { return commitAwaitResult{err: ErrUpgradeControlTimeout} },
			wantCause: ErrUpgradeControlTimeout,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47102")}}
			channel := &terminalTestChannel{}
			attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel, cfg: upgradeConfig{packetConn: packetConn}})
			session := &terminalTestSession{}
			listener := &terminalTestDefinitiveAcceptListener{}
			registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, transportAcceptResult{stream: &terminalTestStream{packetConn: packetConn}})
			cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerAcceptFirst)
			var rows []directUpgradeListenerRow
			engine := directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor, testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) }}

			result, err := engine.handleListenerAcceptFirstCommit(context.Background(), &directUpgradeProtocolRuntime{}, tt.result(t))
			if result != (UpgradeResult{}) {
				t.Fatalf("result = %#v, want zero", result)
			}
			if !errors.Is(err, tt.wantCause) {
				t.Fatalf("error = %v, want cause %v", err, tt.wantCause)
			}
			if !slices.Equal(rows, []directUpgradeListenerRow{directUpgradeListenerRowL26}) {
				t.Fatalf("rows = %v, want [L26]", rows)
			}
		})
	}
}

func TestListenerEngineReadyFailureRowsUsePendingOwner(t *testing.T) {
	encodeErr := errors.New("Ready encode failed")
	operationErr := errors.New("Accept failed")
	tests := []struct {
		name    string
		result  func(*terminalTestPacketConn) transportAcceptResult
		wantRow directUpgradeListenerRow
	}{
		{name: "failure", result: func(*terminalTestPacketConn) transportAcceptResult { return transportAcceptResult{err: operationErr} }, wantRow: directUpgradeListenerRowL08F},
		{name: "success", result: func(packetConn *terminalTestPacketConn) transportAcceptResult {
			return transportAcceptResult{stream: &terminalTestStream{packetConn: packetConn}}
		}, wantRow: directUpgradeListenerRowL08S},
		{name: "stream_error", result: func(packetConn *terminalTestPacketConn) transportAcceptResult {
			return transportAcceptResult{stream: &terminalTestStream{packetConn: packetConn}, err: operationErr}
		}, wantRow: directUpgradeListenerRowL08E},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47151")}}
			channel := &terminalTestChannel{}
			attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel, cfg: upgradeConfig{packetConn: packetConn}})
			session := &terminalTestSession{}
			acceptResult := test.result(packetConn)
			listener := newTerminalTestAcceptListener(nil, acceptResult.stream, acceptResult.err)
			attempt.resources().registerSession(session)
			_, _ = attempt.resources().startAccept(context.Background(), listener)
			<-listener.acceptStarted
			cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit)
			var rows []directUpgradeListenerRow
			engine := directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor, testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) }}

			outcome := engine.dispatchListenerReadyFailure(context.Background(), &directUpgradeProtocolRuntime{}, encodeErr, true)
			if !outcome.terminal || !errors.Is(outcome.err, encodeErr) {
				t.Fatalf("outcome = terminal %v, error %v; want terminal encode cause", outcome.terminal, outcome.err)
			}
			if errors.Is(outcome.err, errInvalidAttemptTerminalDisposition) {
				t.Fatalf("Ready failure used an invalid owner disposition: %v", outcome.err)
			}
			if !slices.Equal(rows, []directUpgradeListenerRow{test.wantRow}) {
				t.Fatalf("rows = %v, want [%s]", rows, test.wantRow)
			}
			owner := attempt.resources()
			owner.mu.Lock()
			disposition, control := owner.terminalDisposition, owner.terminalControl
			owner.mu.Unlock()
			if disposition != attemptTerminalFailClosed || control != retainForOuterSettlement {
				t.Fatalf("terminal state = (%v, %v), want fail-closed/retain", disposition, control)
			}
		})
	}
}

func TestListenerEnginePendingListenSimultaneousCancellation(t *testing.T) {
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47201")}}
	channel := &terminalTestChannel{}
	listenStarted := make(chan struct{})
	listenRelease := make(chan struct{})
	session := &terminalTestSession{listenErr: context.Canceled, listenStarted: listenStarted, listenRelease: listenRelease}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel, controlFrames: newBufferedControlFrameSequencer(), cfg: upgradeConfig{packetConn: packetConn}})
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerSelected)
	var rows []directUpgradeListenerRow
	engine := directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor, testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) }}
	ctx, cancel := context.WithCancel(context.Background())
	runtime := &directUpgradeProtocolRuntime{handoffCtx: ctx}
	selected := selectedPair{dialer: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:47202")}, listener: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:47201")}}
	outcome := engine.dispatchListenerEvent(ctx, directUpgradeProtocolEventListenerSelectedAdmitted, directUpgradeProtocolActionInput{selected: selected}, runtime)
	if outcome.terminal || outcome.err != nil {
		t.Fatalf("start Listen outcome = terminal %v, error %v", outcome.terminal, outcome.err)
	}
	<-listenStarted
	cancel()

	done := make(chan error, 1)
	go func() {
		_, err := engine.awaitListenerListen(ctx, runtime)
		done <- err
	}()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("pending Listen cancellation error = %v, want context canceled", err)
		}
	case <-time.After(time.Second):
		t.Fatal("pending Listen simultaneous cancellation did not complete")
	}
	if !slices.Equal(rows, []directUpgradeListenerRow{directUpgradeListenerRowL05P, directUpgradeListenerRowL05CF}) {
		t.Fatalf("rows = %v, want [L05-P L05-CF]", rows)
	}
	snapshot := attempt.resources().snapshot()
	if snapshot.listen != attemptOperationJoined {
		t.Fatalf("Listen lifecycle = %v, want joined", snapshot.listen)
	}
	if got := session.closeCalls.Load(); got != 1 {
		t.Fatalf("Session.Close calls = %d, want 1", got)
	}
}

func TestListenerEngineListenCompletionPrefersCancellation(t *testing.T) {
	testListenerEngineListenCompletionPrefersContext(t, true, directUpgradeListenerRowL05CS)
}

func TestListenerEngineListenCompletionPrefersHandoffExpiry(t *testing.T) {
	testListenerEngineListenCompletionPrefersContext(t, false, directUpgradeListenerRowL05TS)
}

func testListenerEngineListenCompletionPrefersContext(
	t *testing.T,
	cancelCaller bool,
	wantRow directUpgradeListenerRow,
) {
	t.Helper()
	peerFallback, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	channel := newWriteTriggeredControlChannel(peerFallback, 1)
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47251")}}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel, controlFrames: newControlFrameSequencer(channel), cfg: upgradeConfig{packetConn: packetConn, controlTimeout: time.Second}})
	listener := &terminalTestReturnedListener{}
	session := &terminalTestSession{listenListener: listener}
	listenCh := attempt.resources().startListen(context.Background(), session, packetConn, nil, nil)
	<-attempt.resources().listen.ready
	listenResult := <-listenCh
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerListenPending)
	var rows []directUpgradeListenerRow
	engine := directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor, testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) }}
	callerCtx, cancelCallerCtx := context.WithCancel(context.Background())
	handoffCtx, cancelHandoffCtx := context.WithCancel(context.Background())
	if cancelCaller {
		cancelCallerCtx()
	} else {
		cancelHandoffCtx()
	}
	defer cancelCallerCtx()
	defer cancelHandoffCtx()

	result, err := engine.handleListenerListenCompletion(callerCtx, &directUpgradeProtocolRuntime{handoffCtx: handoffCtx}, listenResult)
	if cancelCaller {
		if result != (UpgradeResult{}) || !errors.Is(err, context.Canceled) {
			t.Fatalf("canceled completion result = %#v, error = %v; want zero with context canceled", result, err)
		}
	} else {
		if err != nil || result.Path != UpgradePathRelay || result.FallbackReason != UpgradeFallbackTransportFailed {
			t.Fatalf("expired completion result = %#v, error = %v; want transport-failed relay", result, err)
		}
		_ = result.Stream.Close()
	}
	if !slices.Equal(rows, []directUpgradeListenerRow{wantRow}) {
		t.Fatalf("rows = %v, want [%s]", rows, wantRow)
	}
	if snapshot := attempt.resources().snapshot(); snapshot.listen != attemptOperationJoined || snapshot.accept != attemptOperationUnregistered {
		t.Fatalf("operation lifecycle = Listen %v, Accept %v; want joined and unregistered", snapshot.listen, snapshot.accept)
	}
	if got := listener.closeCalls.Load(); got != 1 {
		t.Fatalf("Listener.Close calls = %d, want 1", got)
	}
	if got := session.closeCalls.Load(); got != 1 {
		t.Fatalf("Session.Close calls = %d, want 1", got)
	}
	if got := channel.closeCalls.Load(); got != 1 {
		t.Fatalf("control Close calls = %d, want 1", got)
	}
	if got := packetConn.closeCalls.Load(); got != 0 {
		t.Fatalf("PacketConn.Close calls = %d, want 0 before commit", got)
	}
	select {
	case observation := <-channel.writeObserved:
		if ready, _ := decodeUpgradeControlPhasePayload(observation.payload[4:], upgradeControlPhaseReady); ready.Is(upgradeControlPhaseReady) {
			t.Fatal("Listen completion published Ready after context completion")
		}
	default:
	}
}

func TestListenerEnginePrecommitAcceptFailureCancellationDoesNotWriteFallback(t *testing.T) {
	operationErr := errors.New("Accept failed before commit")
	writeObserved := make(chan struct{}, 1)
	channel := newObservedWriteControlChannel(writeObserved, nil, false)
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47261")}}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel, controlFrames: newBufferedControlFrameSequencer(), cfg: upgradeConfig{packetConn: packetConn, controlTimeout: time.Second}})
	session := &terminalTestSession{}
	listener := &terminalTestDefinitiveAcceptListener{}
	acceptResult := transportAcceptResult{err: operationErr}
	registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, acceptResult)
	acceptCh := make(chan transportAcceptResult, 1)
	acceptCh <- acceptResult
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit)
	var rows []directUpgradeListenerRow
	engine := directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor, testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) }}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	result, err := engine.handleListenerHandoffTimeout(ctx, &directUpgradeProtocolRuntime{handoffCtx: ctx, acceptCh: acceptCh})
	if result != (UpgradeResult{}) || !errors.Is(err, context.Canceled) {
		t.Fatalf("result = %#v, error = %v; want zero with context canceled", result, err)
	}
	if !slices.Equal(rows, []directUpgradeListenerRow{directUpgradeListenerRowL20}) {
		t.Fatalf("rows = %v, want [L20]", rows)
	}
	owner := attempt.resources()
	owner.mu.Lock()
	disposition, control := owner.terminalDisposition, owner.terminalControl
	owner.mu.Unlock()
	if disposition != attemptTerminalFailClosed || control != abortAfterOwnedResources {
		t.Fatalf("terminal state = (%v, %v), want fail-closed/abort-after", disposition, control)
	}
	if snapshot := owner.snapshot(); snapshot.accept != attemptOperationJoined {
		t.Fatalf("Accept lifecycle = %v, want joined", snapshot.accept)
	}
	if got := listener.closeCalls.Load(); got != 1 {
		t.Fatalf("Listener.Close calls = %d, want 1", got)
	}
	if got := session.closeCalls.Load(); got != 1 {
		t.Fatalf("Session.Close calls = %d, want 1", got)
	}
	if got := channel.closeCalls.Load(); got != 1 {
		t.Fatalf("control Close calls = %d, want 1", got)
	}
	if got := packetConn.closeCalls.Load(); got != 0 {
		t.Fatalf("PacketConn.Close calls = %d, want 0 before commit", got)
	}
	select {
	case <-writeObserved:
		t.Fatal("canceled pre-commit Accept failure attempted fallback write")
	case <-time.After(10 * time.Millisecond):
	}
}

func TestListenerEngineDefinitiveAcceptFailureClosesCommittedPacketConn(t *testing.T) {
	acceptErr := errors.New("definitive Accept failed")
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47501")}}
	channel := &terminalTestChannel{}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel, cfg: upgradeConfig{packetConn: packetConn}})
	session := &terminalTestSession{}
	listener := &terminalTestDefinitiveAcceptListener{}
	acceptResult := transportAcceptResult{err: acceptErr}
	registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, acceptResult)
	attempt.resources().registerCommit()
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerCommitFirst)
	var rows []directUpgradeListenerRow
	engine := directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor, testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) }}

	result, err := engine.handleListenerCommitFirstAccept(context.Background(), &directUpgradeProtocolRuntime{}, acceptResult)
	if result != (UpgradeResult{}) || !errors.Is(err, acceptErr) || !errors.Is(err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("result = %#v, error = %v; want zero with Accept cause and transport-not-converged", result, err)
	}
	if !slices.Equal(rows, []directUpgradeListenerRow{directUpgradeListenerRowL30F}) {
		t.Fatalf("rows = %v, want [L30-F]", rows)
	}
	if got := packetConn.closeCalls.Load(); got != 1 {
		t.Fatalf("PacketConn.Close calls = %d, want 1", got)
	}
	if got := listener.closeCalls.Load(); got != 1 {
		t.Fatalf("Listener.Close calls = %d, want 1", got)
	}
	if got := session.closeCalls.Load(); got != 1 {
		t.Fatalf("Session.Close calls = %d, want 1", got)
	}
	if got := channel.closeCalls.Load(); got != 1 {
		t.Fatalf("control Close calls = %d, want 1", got)
	}
}

func TestListenerEngineConvergenceTimeoutClosesMaterializedPacketConn(t *testing.T) {
	packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47601")}}
	channel := &terminalTestChannel{}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(),
		cfg:           upgradeConfig{packetConn: packetConn, probeTimeout: 10 * time.Millisecond},
	})
	session := &terminalTestSession{}
	listener := &terminalTestDefinitiveAcceptListener{}
	stream := &terminalTestStream{}
	registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, transportAcceptResult{stream: stream})
	attempt.resources().registerCommit()
	acceptResult := attempt.resources().snapshot().acceptResult
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStatePostCommitStart)
	var rows []directUpgradeListenerRow
	engine := directUpgradeProtocolEngine{role: upgradeRoleListen, attempt: attempt, session: session, cursor: &cursor, testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) }}
	runtime := &directUpgradeProtocolRuntime{acceptResult: acceptResult, transport: acceptResult, transportReady: true}

	result, err := engine.runListenerPostCommit(context.Background(), runtime)
	if result != (UpgradeResult{}) || !errors.Is(err, context.DeadlineExceeded) || !errors.Is(err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("result = %#v, error = %v; want zero with deadline and transport-not-converged", result, err)
	}
	if len(rows) == 0 || rows[len(rows)-1] != directUpgradeListenerRowL40 {
		t.Fatalf("rows = %v, want terminal L40", rows)
	}
	if got := stream.closeCalls.Load(); got != 1 {
		t.Fatalf("Stream.Close calls = %d, want 1", got)
	}
	if got := packetConn.closeCalls.Load(); got != 1 {
		t.Fatalf("PacketConn.Close calls = %d, want 1", got)
	}
	if got := listener.closeCalls.Load(); got != 1 {
		t.Fatalf("Listener.Close calls = %d, want 1", got)
	}
	if got := session.closeCalls.Load(); got != 1 {
		t.Fatalf("Session.Close calls = %d, want 1", got)
	}
	if got := channel.closeCalls.Load(); got != 1 {
		t.Fatalf("control Close calls = %d, want 1", got)
	}
}

func TestListenerEnginePendingAcceptClassificationUsesOwnerJoin(t *testing.T) {
	operationErr := errors.New("pending Accept failed")
	tests := []struct {
		name string
		make func(*terminalTestPacketConn) transportAcceptResult
		want transportStreamResultClass
	}{
		{name: "failure", make: func(*terminalTestPacketConn) transportAcceptResult { return transportAcceptResult{err: operationErr} }, want: transportStreamResultNoMaterialization},
		{name: "success", make: func(packetConn *terminalTestPacketConn) transportAcceptResult {
			return transportAcceptResult{stream: &terminalTestStream{packetConn: packetConn}}
		}, want: transportStreamResultSuccess},
		{name: "stream_error", make: func(packetConn *terminalTestPacketConn) transportAcceptResult {
			return transportAcceptResult{stream: &terminalTestStream{packetConn: packetConn}, err: operationErr}
		}, want: transportStreamResultMaterializedError},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			packetConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:47701")}}
			channel := &terminalTestChannel{}
			owner := newAttemptResources(channel, packetConn)
			session := &terminalTestSession{}
			acceptResult := test.make(packetConn)
			listener := newTerminalTestAcceptListener(nil, acceptResult.stream, acceptResult.err)
			owner.registerSession(session)
			_, _ = owner.startAccept(context.Background(), listener)
			<-listener.acceptStarted

			joined := owner.joinPendingAcceptForClassification()
			if got := classifyTransportStreamResult(joined); got != test.want {
				t.Fatalf("joined class = %v, want %v", got, test.want)
			}
			if snapshot := owner.snapshot(); snapshot.accept != attemptOperationJoined {
				t.Fatalf("Accept lifecycle = %v, want joined", snapshot.accept)
			}
			if got := listener.closeCalls.Load(); got != 1 {
				t.Fatalf("Listener.Close calls = %d, want 1", got)
			}
			result, err := owner.failClosed(operationErr, abortAfterOwnedResources)
			if result != (UpgradeResult{}) || !errors.Is(err, operationErr) {
				t.Fatalf("failClosed result = %#v, error = %v; want zero with operation cause", result, err)
			}
			if got := listener.closeCalls.Load(); got != 1 {
				t.Fatalf("post-terminal Listener.Close calls = %d, want 1", got)
			}
			if got := session.closeCalls.Load(); got != 1 {
				t.Fatalf("Session.Close calls = %d, want 1", got)
			}
			if got := channel.closeCalls.Load(); got != 1 {
				t.Fatalf("control Close calls = %d, want 1", got)
			}
			wantMaterialized := acceptResult.stream != nil
			if got := packetConn.closeCalls.Load(); got != boolToInt32(wantMaterialized) {
				t.Fatalf("PacketConn.Close calls = %d, want %d", got, boolToInt32(wantMaterialized))
			}
			if stream, ok := acceptResult.stream.(*terminalTestStream); ok {
				if got := stream.closeCalls.Load(); got != 1 {
					t.Fatalf("Stream.Close calls = %d, want 1", got)
				}
			}
			if wantMaterialized != errors.Is(err, ErrUpgradeTransportNotConverged) {
				t.Fatalf("failClosed error = %v; transport-not-converged presence = %t, want %t", err, errors.Is(err, ErrUpgradeTransportNotConverged), wantMaterialized)
			}
		})
	}
}
