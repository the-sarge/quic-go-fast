package connect

import (
	"bytes"
	"context"
	"errors"
	"net"
	"net/netip"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// probeResponseDroppingConn drops every outbound v1 probe response so the
// remote peer's direct probe fails while this peer's own probe succeeds:
// deterministic held-success asymmetry. It counts the inbound probe
// responses this peer receives, which is the observable that its own direct
// probe had a response to hold, and it witnesses the listener's
// runHeldSuccessListener entry through the engine's test-only observer so
// the two-peer regressions cannot silently degrade to the probe-race Start
// entry, which produces the same TURN outcome without the engine hold.
type probeResponseDroppingConn struct {
	net.PacketConn
	inboundResponses   atomic.Int32
	heldSuccessEntries atomic.Int32
	enteredOnce        sync.Once
	entered            chan struct{}
}

func newProbeResponseDroppingConn(conn net.PacketConn) *probeResponseDroppingConn {
	return &probeResponseDroppingConn{PacketConn: conn, entered: make(chan struct{})}
}

// testHeldSuccessListenerEntered implements
// heldSuccessListenerEntryObserver.
func (c *probeResponseDroppingConn) testHeldSuccessListenerEntered() {
	c.heldSuccessEntries.Add(1)
	c.enteredOnce.Do(func() { close(c.entered) })
}

// Keep this below the fixture's two-second control timeout so a missing held-success entry fails its explicit assertion instead of surfacing as a dialer control-write timeout.
const turnRetryStartGateBound = time.Second

// gateTurnRetryStartOnHeldSuccessEntry installs the Start gate on the dialer's
// relay channel, released by the listener conn's engine-entry witness.
func gateTurnRetryStartOnHeldSuccessEntry(dialer *turnRetryTestPeer, listenerConn *probeResponseDroppingConn) {
	delegate := dialer.negotiate.channel
	channel := newScriptedControlChannel(nil, false)
	channel.delegate = delegate
	channel.writeScript = func(p []byte) (int, error) {
		if len(p) > 4 && decodeTurnRetryStart(p[4:]) {
			select {
			case <-listenerConn.entered:
			case <-time.After(turnRetryStartGateBound):
			}
		}
		return delegate.Write(p)
	}
	dialer.negotiate.channel = channel
}

func assertHeldSuccessListenerEnteredOnce(t *testing.T, listenerConn *probeResponseDroppingConn) {
	t.Helper()
	if got := listenerConn.inboundResponses.Load(); got == 0 {
		t.Fatal("listener received no direct probe response: fixture did not produce held success")
	}
	if got := listenerConn.heldSuccessEntries.Load(); got != 1 {
		t.Fatalf("held-success listener engine entries = %d, want exactly 1: the regression degraded to the probe-race Start entry", got)
	}
}

func isProbeResponseDatagram(p []byte) bool {
	return len(p) == probeDatagramBytes && bytes.Equal(p[:4], probeDatagramMagic[:]) && p[5] == byte(probeMessageResponse)
}

func (c *probeResponseDroppingConn) WriteTo(p []byte, addr net.Addr) (int, error) {
	if isProbeResponseDatagram(p) {
		return len(p), nil
	}
	return c.PacketConn.WriteTo(p, addr)
}

func (c *probeResponseDroppingConn) ReadFrom(p []byte) (int, net.Addr, error) {
	n, addr, err := c.PacketConn.ReadFrom(p)
	if err == nil && isProbeResponseDatagram(p[:n]) {
		c.inboundResponses.Add(1)
	}
	return n, addr, err
}

func TestTurnRetryHeldSuccessListenerDiscardsDirectAndAllocatesAfterStart(t *testing.T) {
	dialer, listener := newTurnRetryLoopbackDirectPeers(t)
	// Loopback traffic really flows: the listener's own probe receives the
	// dialer's response, but the listener's responses to the dialer are
	// dropped, so the dialer's direct probe fails while the listener holds a
	// local direct success.
	listenerConn := newProbeResponseDroppingConn(listener.conn)
	listener.conn = listenerConn
	// Both peers share the fixture's probe timeout, so the listener's held
	// success is reported at the same instant the dialer's probe fails; the
	// gate keeps the dialer's Start behind the listener's engine entry.
	gateTurnRetryStartOnHeldSuccessEntry(dialer, listenerConn)

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	if dialerOutcome.err != nil || listenerOutcome.err != nil {
		t.Fatalf("upgrade errors = %v / %v, want nil", dialerOutcome.err, listenerOutcome.err)
	}
	assertHeldSuccessListenerEnteredOnce(t, listenerConn)
	for name, outcome := range map[string]turnRetryTestOutcome{"dialer": dialerOutcome, "listener": listenerOutcome} {
		if outcome.result.Path != UpgradePathDirect {
			t.Fatalf("%s path = %q, want TURN carrier", name, outcome.result.Path)
		}
		if outcome.result.SelectedPair == nil || outcome.result.SelectedPair.Local.Kind != CandidateKindRelay {
			t.Fatalf("%s selected pair = %#v, want relay/relay: held direct success must be discarded", name, outcome.result.SelectedPair)
		}
	}
	// The held-success listener allocated exactly once, and only after Start.
	if calls := listener.allocator.callCount(); calls != 1 {
		t.Fatalf("held-success listener allocator calls = %d, want exactly 1", calls)
	}
	if count := dialer.relay.turnRetryStartCount(); count != 1 {
		t.Fatalf("retry Start frames = %d, want 1", count)
	}
}

func TestTurnRetryHeldSuccessListenerWaitsThroughProbeTimeoutForStart(t *testing.T) {
	dialer, listener := newTurnRetryLoopbackDirectPeers(t)
	listenerConn := newProbeResponseDroppingConn(listener.conn)
	listener.conn = listenerConn
	gateTurnRetryStartOnHeldSuccessEntry(dialer, listenerConn)
	// The listener's probe timeout expires long before the dialer's direct
	// probe fails and sends Retry Start; the held-success hold must last
	// under the control timeout alone, not the shorter transport handoff
	// budget, so the Start still enters retry.
	listener.extraOpts = []UpgradeOption{
		WithProbeTimeout(100 * time.Millisecond),
		WithUpgradeControlTimeout(2 * time.Second),
	}
	dialer.extraOpts = []UpgradeOption{
		WithProbeTimeout(400 * time.Millisecond),
		WithUpgradeControlTimeout(2 * time.Second),
	}

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	if dialerOutcome.err != nil || listenerOutcome.err != nil {
		t.Fatalf("upgrade errors = %v / %v, want nil", dialerOutcome.err, listenerOutcome.err)
	}
	assertHeldSuccessListenerEnteredOnce(t, listenerConn)
	for name, outcome := range map[string]turnRetryTestOutcome{"dialer": dialerOutcome, "listener": listenerOutcome} {
		if outcome.result.Path != UpgradePathDirect {
			t.Fatalf("%s path = %q, want TURN carrier", name, outcome.result.Path)
		}
		if outcome.result.SelectedPair == nil || outcome.result.SelectedPair.Local.Kind != CandidateKindRelay {
			t.Fatalf("%s selected pair = %#v, want relay/relay: held direct success must be discarded", name, outcome.result.SelectedPair)
		}
	}
	if calls := listener.allocator.callCount(); calls != 1 {
		t.Fatalf("held-success listener allocator calls = %d, want exactly 1", calls)
	}
	if count := dialer.relay.turnRetryStartCount(); count != 1 {
		t.Fatalf("retry Start frames = %d, want 1", count)
	}
}

func TestTurnRetryCrossedStartAndLateV1FallbackConvergeOnProbeFailed(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	// The listener's hold expires before the slow dialer's direct probe
	// fails, so it sends its v1 terminal Fallback first; delayed delivery
	// makes that Fallback cross the dialer's Retry Start, and the crossed
	// Start reaches a listener already exclusively in the v1 exchange.
	listenerDelegate := listener.negotiate.channel
	delayedListenerChannel := newScriptedControlChannel(nil, false)
	delayedListenerChannel.delegate = listenerDelegate
	delayedListenerChannel.writeScript = func(p []byte) (int, error) {
		if len(p) > 4 {
			if _, ok := decodeCanonicalV1TerminalFallback(p[4:]); ok {
				time.Sleep(450 * time.Millisecond)
			}
		}
		return listenerDelegate.Write(p)
	}
	listener.negotiate.channel = delayedListenerChannel
	dialer.extraOpts = []UpgradeOption{
		WithProbeTimeout(800 * time.Millisecond),
		WithUpgradeControlTimeout(800 * time.Millisecond),
	}
	listener.extraOpts = []UpgradeOption{
		WithProbeTimeout(50 * time.Millisecond),
		WithUpgradeControlTimeout(600 * time.Millisecond),
	}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackProbeFailed)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), delayedListenerChannel, UpgradeFallbackProbeFailed)

	if count := dialer.relay.turnRetryStartCount(); count != 1 {
		t.Fatalf("crossed retry Start frames = %d, want 1", count)
	}
	// The listener ignored the crossed Start and never entered retry.
	if calls := listener.allocator.callCount(); calls != 0 {
		t.Fatalf("listener allocator calls = %d, want 0 after ignoring crossed Start", calls)
	}
	// The dialer began its single allocation at Start and closed it on v1
	// selection.
	if calls := dialer.allocator.callCount(); calls != 1 {
		t.Fatalf("dialer allocator calls = %d, want 1", calls)
	}
	if dialerComposite.closeCount() == 0 {
		t.Fatal("dialer composite not closed after late v1 selection")
	}
}

func TestTurnRetryDialerPreselectionExpiryResolvesRetryFallbackSix(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(ctx context.Context) (RelayPacketConn, error) {
		// The listener's Offer arrives only after the dialer's retry budget
		// expired: preselection expiry records probe_failed without emission
		// and the later retry Offer selection resolves retry Fallback 6.
		select {
		case <-time.After(400 * time.Millisecond):
		case <-ctx.Done():
			return nil, ctx.Err()
		}
		return listenerComposite, nil
	}
	dialer.extraOpts = []UpgradeOption{WithTURNRetryTimeout(100 * time.Millisecond)}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackProbeFailed)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackProbeFailed)

	reasons := dialer.relay.turnRetryFallbackReasons()
	if len(reasons) != 1 || reasons[0] != UpgradeFallbackProbeFailed {
		t.Fatalf("dialer retry fallback reasons = %v, want exactly [probe_failed]", reasons)
	}
	if dialerComposite.closeCount() == 0 {
		t.Fatal("dialer composite not closed on preselection-expiry resolution")
	}
	if listenerComposite.closeCount() == 0 {
		t.Fatal("listener composite not closed on synchronized fallback")
	}
}

func TestTurnRetryListenerExpirySendsRetryFallbackSix(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	listenerComposite := newFakeRelayComposite(t)
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }
	dialer.allocator.allocate = func(ctx context.Context) (RelayPacketConn, error) {
		// The dialer's allocation hangs until preempted, so the listener's
		// role-local retry budget expires while awaiting the dialer Offer.
		<-ctx.Done()
		return nil, ctx.Err()
	}
	listener.extraOpts = []UpgradeOption{WithTURNRetryTimeout(200 * time.Millisecond)}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackProbeFailed)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackProbeFailed)

	reasons := listener.relay.turnRetryFallbackReasons()
	if len(reasons) != 1 || reasons[0] != UpgradeFallbackProbeFailed {
		t.Fatalf("listener retry fallback reasons = %v, want exactly [probe_failed]", reasons)
	}
	// The preempted dialer echoed the authenticated peer reason.
	reasons = dialer.relay.turnRetryFallbackReasons()
	if len(reasons) != 1 || reasons[0] != UpgradeFallbackProbeFailed {
		t.Fatalf("dialer echoed retry fallback reasons = %v, want exactly [probe_failed]", reasons)
	}
	if listenerComposite.closeCount() == 0 {
		t.Fatal("listener composite not closed after its own expiry")
	}
}

func TestTurnRetryConcurrentDistinctReasonsRetainMappedCodesAndConverge(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	dialerComposite.failPrepare = errors.New("permission preparation refused")
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }
	// The listener excludes the dialer's relay prefix at Offer receipt while
	// the dialer independently fails preparation right after sending that
	// Offer: two concurrent distinct local reasons.
	listener.extraOpts = []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
		ExcludeRemotePrefixes: []netip.Prefix{netip.MustParsePrefix("127.0.0.0/8")},
	})}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	// policy_excluded outranks probe_failed under the existing precedence
	// owner regardless of role order.
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackPolicyExcluded)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackPolicyExcluded)

	listenerReasons := listener.relay.turnRetryFallbackReasons()
	if len(listenerReasons) != 1 || listenerReasons[0] != UpgradeFallbackPolicyExcluded {
		t.Fatalf("listener retry fallback reasons = %v, want exactly [policy_excluded]", listenerReasons)
	}
	dialerReasons := dialer.relay.turnRetryFallbackReasons()
	if len(dialerReasons) != 1 {
		t.Fatalf("dialer retry fallback reasons = %v, want exactly one", dialerReasons)
	}
	// The dialer keeps its independently reached code when its preparation
	// failure completed before the peer preemption arrived; an echo of the
	// peer reason is the only other admissible frame.
	if dialerReasons[0] != UpgradeFallbackProbeFailed && dialerReasons[0] != UpgradeFallbackPolicyExcluded {
		t.Fatalf("dialer retry fallback reason = %v, want probe_failed (independent) or policy_excluded (echo)", dialerReasons[0])
	}
}

// datagramDirectHandoffTransports returns handoff transports whose accepted
// and dialed streams both expose a Datagram carrier.
func datagramDirectHandoffTransports(t *testing.T, name string) (*directHandoffTransport, *directHandoffTransport) {
	t.Helper()
	dialTransport, listenTransport := newDirectHandoffTransports(name)
	carrier := &stubDatagramCarrier{maxPayload: 1159, lifetime: openDatagramLifetime(t)}
	dialTransport.streams.dialStream = asymmetricDatagramCapableStream{
		ReadWriteCloser: dialTransport.streams.dialStream,
		carrier:         carrier,
	}
	listenTransport.streams.listenStream = asymmetricDatagramCapableStream{
		ReadWriteCloser: listenTransport.streams.listenStream,
		carrier:         carrier,
	}
	return dialTransport, listenTransport
}

func TestTurnRetryDatagramCapabilityIntersection(t *testing.T) {
	cases := []struct {
		name          string
		bothCapable   bool
		wantDatagrams bool
	}{
		{name: "bilateral capability exposes carriers", bothCapable: true, wantDatagrams: true},
		{name: "one-sided capability retains reliable stream only", bothCapable: false, wantDatagrams: false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dialer, listener := newTurnRetryFailingDirectPeers(t)
			dialerComposite := newFakeRelayComposite(t)
			listenerComposite := newFakeRelayComposite(t)
			dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
			listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

			var dialTransport, listenTransport *directHandoffTransport
			if tc.bothCapable {
				dialTransport, listenTransport = datagramDirectHandoffTransports(t, "fake-stream")
			} else {
				dialTransport, listenTransport = newDirectHandoffTransports("fake-stream")
				carrier := &stubDatagramCarrier{maxPayload: 1159, lifetime: openDatagramLifetime(t)}
				dialTransport.streams.dialStream = asymmetricDatagramCapableStream{
					ReadWriteCloser: dialTransport.streams.dialStream,
					carrier:         carrier,
				}
			}

			dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
			listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

			dialerOutcome := <-dialerDone
			listenerOutcome := <-listenerDone
			if dialerOutcome.err != nil || listenerOutcome.err != nil {
				t.Fatalf("upgrade errors = %v / %v, want nil", dialerOutcome.err, listenerOutcome.err)
			}
			for name, outcome := range map[string]turnRetryTestOutcome{"dialer": dialerOutcome, "listener": listenerOutcome} {
				if outcome.result.Path != UpgradePathDirect {
					t.Fatalf("%s path = %q, want TURN carrier", name, outcome.result.Path)
				}
				if got := outcome.result.Datagrams != nil; got != tc.wantDatagrams {
					t.Fatalf("%s datagram carrier presence = %v, want %v", name, got, tc.wantDatagrams)
				}
			}
		})
	}
}

// blockingCloseRelayConn is an unmarked non-nil allocator result whose
// context-free Close blocks until released: the nonconforming boundary case.
// connect waits for the contractual Close and cannot force cancellation, so
// liveness during the block is explicitly outside the universal guarantee.
type blockingCloseRelayConn struct {
	net.PacketConn
	release    chan struct{}
	mu         sync.Mutex
	closeCalls int
}

func (c *blockingCloseRelayConn) PreparePeer(context.Context, netip.AddrPort) error { return nil }

func (c *blockingCloseRelayConn) Close() error {
	c.mu.Lock()
	c.closeCalls++
	c.mu.Unlock()
	<-c.release
	return c.PacketConn.Close()
}

func TestTurnRetryNonconformingBlockingCloseHoldsFallbackUntilCloseReturns(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	release := make(chan struct{})
	blocking := &blockingCloseRelayConn{
		PacketConn: listenPacketNetwork(t, "udp4", "127.0.0.1:0"),
		release:    release,
	}
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return blocking, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	// The dialer must be blocked awaiting the nonconforming Close.
	select {
	case outcome := <-dialerDone:
		t.Fatalf("dialer completed while nonconforming Close blocked: %+v", outcome)
	case <-time.After(300 * time.Millisecond):
	}
	close(release)

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackProbeFailed)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackProbeFailed)

	blocking.mu.Lock()
	closeCalls := blocking.closeCalls
	blocking.mu.Unlock()
	if closeCalls != 1 {
		t.Fatalf("unmarked result close calls = %d, want exactly 1", closeCalls)
	}
}

// TestTurnRetryOfferPublicationStaysInsideRetryBudget is the C-007
// regression: Retry Offer publication shares the role-local retry budget, so
// a write that completes only after expiry is joined and mapped to
// synchronized code 6 without starting peer preparation.
func TestTurnRetryOfferPublicationStaysInsideRetryBudget(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	dialerDelegate := dialer.negotiate.channel
	delaying := newScriptedControlChannel(nil, false)
	delaying.delegate = dialerDelegate
	delaying.writeScript = func(p []byte) (int, error) {
		if len(p) > 4 {
			if _, ok := decodeTurnRetryOffer(p[4:]); ok {
				time.Sleep(600 * time.Millisecond)
			}
		}
		return dialerDelegate.Write(p)
	}
	dialer.negotiate.channel = delaying
	dialer.extraOpts = []UpgradeOption{WithTURNRetryTimeout(200 * time.Millisecond)}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), delaying, UpgradeFallbackProbeFailed)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackProbeFailed)

	// The dialer's retry budget expired during Offer publication: it must not
	// begin peer preparation and must resolve synchronized retry Fallback 6.
	dialerComposite.mu.Lock()
	prepareCalls := dialerComposite.prepareCalls
	dialerComposite.mu.Unlock()
	if prepareCalls != 0 {
		t.Fatalf("dialer PreparePeer calls = %d, want 0 after budget expiry during Offer publication", prepareCalls)
	}
	reasons := dialer.relay.turnRetryFallbackReasons()
	if len(reasons) != 1 || reasons[0] != UpgradeFallbackProbeFailed {
		t.Fatalf("dialer retry fallback reasons = %v, want exactly [probe_failed]", reasons)
	}
	if dialerComposite.closeCount() == 0 {
		t.Fatal("dialer composite not closed after budget-expired Offer publication")
	}
}

// TestTurnRetryOfferWriteCompletionAtDeadlineReportsExpired pins the exact
// budget boundary: a write whose completion is selectable while the retry
// deadline has already passed must still report the budget as expired.
func TestTurnRetryOfferWriteCompletionAtDeadlineReportsExpired(t *testing.T) {
	t.Parallel()

	relayA, relayB := net.Pipe()
	t.Cleanup(func() {
		_ = relayA.Close()
		_ = relayB.Close()
	})
	go func() {
		buf := make([]byte, 64)
		for {
			if _, err := relayB.Read(buf); err != nil {
				return
			}
		}
	}()

	auth := testAuthContext()
	negotiator, err := NewNegotiator(relayA, auth)
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	attempt := newDirectUpgradeAttempt(negotiator, testUpgradeConfig(t,
		WithTransport(turnEligibleTransport{}),
		WithTURNAllocator(optionStubRelayAllocator{}),
	))

	retryCtx, cancelRetry := context.WithTimeout(context.Background(), time.Nanosecond)
	defer cancelRetry()
	<-retryCtx.Done()

	engine := &turnRetryEngine{attempt: attempt, retryCtx: retryCtx, cancelRetry: cancelRetry}
	frame, err := encodeTurnRetryStart()
	if err != nil {
		t.Fatalf("encode frame: %v", err)
	}
	expired, err := engine.writeOfferUnderRetryBudget(context.Background(), frame)
	if err != nil {
		t.Fatalf("writeOfferUnderRetryBudget error = %v, want nil", err)
	}
	if !expired {
		t.Fatal("completed write with an already-expired retry budget reported expired = false")
	}
}
