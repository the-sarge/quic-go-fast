package connect

import (
	"errors"
	"fmt"
	"io"
	"reflect"
)

var errMalformedDatagramCapability = errors.New("connect: malformed Datagram capability")

func datagramCarrierFromStream(stream io.ReadWriteCloser) (DatagramCarrier, error) {
	capable, ok := stream.(DatagramCapable)
	if !ok {
		//nolint:nilnil // (nil, nil) is this function's "stream exposes no Datagram capability" result; callers distinguish it from an error.
		return nil, nil
	}
	carrier, present := capable.DatagramCarrier()
	carrierNil := isNilDatagramCarrier(carrier)
	if !present {
		if carrierNil {
			//nolint:nilnil // (nil, nil) is this function's "carrier absent" result; callers distinguish it from an error.
			return nil, nil
		}
		return nil, fmt.Errorf("%w: absent result returned a carrier", errMalformedDatagramCapability)
	}
	if carrierNil {
		return nil, fmt.Errorf("%w: present result returned a nil carrier", errMalformedDatagramCapability)
	}
	lifetime := carrier.Lifetime()
	if isNilInterface(lifetime) {
		return nil, fmt.Errorf("%w: carrier lifetime is nil", errMalformedDatagramCapability)
	}
	if lifetime.Done() == nil {
		return nil, fmt.Errorf("%w: carrier lifetime cannot signal termination", errMalformedDatagramCapability)
	}
	if maxPayload := carrier.MaxDatagramPayload(); maxPayload <= 1 {
		return nil, fmt.Errorf("%w: maximum payload %d must exceed the wiremux envelope", errMalformedDatagramCapability, maxPayload)
	}
	return carrier, nil
}

func isNilDatagramCarrier(carrier DatagramCarrier) bool {
	return isNilInterface(carrier)
}

func isNilInterface(value any) bool {
	if value == nil {
		return true
	}
	reflected := reflect.ValueOf(value)
	switch reflected.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
		return reflected.IsNil()
	default:
		return false
	}
}
