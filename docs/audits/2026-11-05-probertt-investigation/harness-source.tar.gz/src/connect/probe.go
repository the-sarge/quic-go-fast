package connect

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha256"
	"errors"
	"fmt"
	"net/netip"
)

type (
	probeDirection   byte
	probeMessageType byte
)

type probeDatagram struct {
	MessageType probeMessageType
	Direction   probeDirection
	ProbeID     [probeIDBytes]byte
	Token       [probeCandidatePairTokenSize]byte
	Tag         [sha256.Size]byte
}

const (
	probeKeyBytes = 32

	probeKeyExporterLabel          = "wiremux v1 probe-hmac"
	turnRetryProbeKeyExporterLabel = "wiremux turn-retry/1 probe-hmac"

	probeContextVersion              = byte(0x01)
	probeTokenVersion                = byte(0x01)
	probeTranscriptVersion           = byte(0x01)
	probeDatagramVersion             = byte(0x01)
	probeIDBytes                     = 8
	probeDatagramBytes               = 63
	probeCandidatePairTokenSize      = 16
	probeCandidateKindHost           = byte(0x01)
	probeCandidateKindReflexive      = byte(0x02)
	turnRetryProbeCandidateKindRelay = byte(0x03)

	probeDirectionDialerToListener probeDirection = 0x01
	probeDirectionListenerToDialer probeDirection = 0x02

	probeMessageRequest  probeMessageType = 0x01
	probeMessageResponse probeMessageType = 0x02
)

var (
	probeDatagramMagic          = [...]byte{'W', 'M', 'X', 'P'}
	turnRetryProbeDatagramMagic = [...]byte{'W', 'M', 'T', 'R'}
)

var (
	errUnsupportedProbeCandidateKind = errors.New("connect: unsupported probe candidate kind")
	errInvalidProbeCandidateAddress  = errors.New("connect: invalid probe candidate address")
	errInvalidProbeNonce             = errors.New("connect: invalid probe nonce")
	errInvalidProbeKey               = errors.New("connect: invalid probe key")
	errInvalidProbeDirection         = errors.New("connect: invalid probe direction")
	errInvalidProbeMessageType       = errors.New("connect: invalid probe message type")
)

// probeWireParams is the whole Probe dialect: everything that distinguishes
// the v1 direct probe from the TURN-retry probe on the wire. It owns the
// datagram magic, the exporter label that domain-separates the probe key, the
// candidate kinds the dialect admits, and whether a valid datagram from the
// other dialect is rejected or ignored. Every other wire offset, transcript
// layout, and authentication rule is the single shared implementation on this
// type, and the bounded probe scheduler consumes one descriptor value.
type probeWireParams struct {
	magic         [4]byte
	exporterLabel string
	candidateKind func(CandidateKind) (byte, bool)
	// crossProfile, when non-nil, detects a valid datagram from the other
	// Probe dialect; such traffic surfaces as an error instead of being
	// silently ignored. The v1 dialect leaves it nil, preserving its existing
	// ignore-unknown datagram behavior.
	crossProfile func(datagram []byte) bool
}

func v1ProbeWireParams() probeWireParams {
	return probeWireParams{
		magic:         probeDatagramMagic,
		exporterLabel: probeKeyExporterLabel,
		candidateKind: probeCandidateKind,
	}
}

func turnRetryProbeWireParams() probeWireParams {
	return probeWireParams{
		magic:         turnRetryProbeDatagramMagic,
		exporterLabel: turnRetryProbeKeyExporterLabel,
		candidateKind: turnRetryProbeCandidateKind,
		crossProfile: func(datagram []byte) bool {
			// A use-time call, not a package-init dependency: the foreign
			// dialect is whatever the v1 decoder accepts.
			_, ok := v1ProbeWireParams().decodeDatagram(datagram)
			return ok
		},
	}
}

func probeCandidateKind(kind CandidateKind) (byte, bool) {
	switch kind {
	case CandidateKindHost:
		return probeCandidateKindHost, true
	case CandidateKindReflexive:
		return probeCandidateKindReflexive, true
	default:
		return 0, false
	}
}

func turnRetryProbeCandidateKind(kind CandidateKind) (byte, bool) {
	if kind != CandidateKindRelay {
		return 0, false
	}
	return turnRetryProbeCandidateKindRelay, true
}

func (p probeWireParams) deriveKey(exporter KeyExporter, dialerNonce, listenerNonce []byte) ([]byte, error) {
	if len(dialerNonce) != upgradeControlProbeNonceBytes || len(listenerNonce) != upgradeControlProbeNonceBytes {
		return nil, errInvalidProbeNonce
	}

	context := make([]byte, 0, 1+len(dialerNonce)+len(listenerNonce))
	context = append(context, probeContextVersion)
	context = append(context, dialerNonce...)
	context = append(context, listenerNonce...)
	return exporter.Derive(p.exporterLabel, context, probeKeyBytes)
}

func (p probeWireParams) encodeDatagram(
	probeKey []byte,
	messageType probeMessageType,
	direction probeDirection,
	probeID [probeIDBytes]byte,
	source Candidate,
	destination Candidate,
) ([]byte, error) {
	token, tag, err := p.authenticateDatagram(probeKey, messageType, direction, probeID, source, destination)
	if err != nil {
		return nil, err
	}

	datagram := make([]byte, 0, probeDatagramBytes)
	datagram = append(datagram, p.magic[:]...)
	datagram = append(datagram, probeDatagramVersion)
	datagram = append(datagram, byte(messageType))
	datagram = append(datagram, byte(direction))
	datagram = append(datagram, probeID[:]...)
	datagram = append(datagram, token...)
	datagram = append(datagram, tag...)
	return datagram, nil
}

// acceptDatagram authenticates one observed UDP packet. It is deliberately
// stateless and does not reject replays by itself; replay exposure is bounded
// by the per-upgrade probe scheduler's nonce-derived key, random probe IDs,
// and deadline.
func (p probeWireParams) acceptDatagram(
	probeKey []byte,
	datagram []byte,
	wantMessageType probeMessageType,
	wantDirection probeDirection,
	source Candidate,
	destination Candidate,
	observedSource netip.AddrPort,
) (probeDatagram, bool) {
	decoded, ok := p.decodeDatagram(datagram)
	if !ok {
		return probeDatagram{}, false
	}
	if decoded.MessageType != wantMessageType || decoded.Direction != wantDirection {
		return probeDatagram{}, false
	}
	if !probeObservedSourceMatches(source, observedSource) {
		return probeDatagram{}, false
	}

	token, tag, err := p.authenticateDatagram(probeKey, decoded.MessageType, decoded.Direction, decoded.ProbeID, source, destination)
	if err != nil {
		return probeDatagram{}, false
	}
	if !hmac.Equal(decoded.Token[:], token) || !hmac.Equal(decoded.Tag[:], tag) {
		return probeDatagram{}, false
	}
	return decoded, true
}

func (p probeWireParams) decodeDatagram(datagram []byte) (probeDatagram, bool) {
	if len(datagram) != probeDatagramBytes {
		return probeDatagram{}, false
	}
	if !bytes.Equal(datagram[:4], p.magic[:]) {
		return probeDatagram{}, false
	}
	if datagram[4] != probeDatagramVersion {
		return probeDatagram{}, false
	}

	messageType := probeMessageType(datagram[5])
	if !validProbeMessageType(messageType) {
		return probeDatagram{}, false
	}
	direction := probeDirection(datagram[6])
	if !validProbeDirection(direction) {
		return probeDatagram{}, false
	}

	var decoded probeDatagram
	decoded.MessageType = messageType
	decoded.Direction = direction
	copy(decoded.ProbeID[:], datagram[7:15])
	copy(decoded.Token[:], datagram[15:31])
	copy(decoded.Tag[:], datagram[31:63])
	return decoded, true
}

func (p probeWireParams) authenticateDatagram(
	probeKey []byte,
	messageType probeMessageType,
	direction probeDirection,
	probeID [probeIDBytes]byte,
	source Candidate,
	destination Candidate,
) ([]byte, []byte, error) {
	if len(probeKey) != probeKeyBytes {
		return nil, nil, errInvalidProbeKey
	}
	if !validProbeMessageType(messageType) {
		return nil, nil, errInvalidProbeMessageType
	}
	if !validProbeDirection(direction) {
		return nil, nil, errInvalidProbeDirection
	}

	token, err := p.candidatePairToken(probeKey, direction, source, destination)
	if err != nil {
		return nil, nil, err
	}
	sourceEncoded, err := p.encodeCandidate(source)
	if err != nil {
		return nil, nil, err
	}
	destinationEncoded, err := p.encodeCandidate(destination)
	if err != nil {
		return nil, nil, err
	}

	transcript := make([]byte, 0, 3+probeIDBytes+probeCandidatePairTokenSize+len(sourceEncoded)+len(destinationEncoded))
	transcript = append(transcript, probeTranscriptVersion)
	transcript = append(transcript, byte(messageType))
	transcript = append(transcript, byte(direction))
	transcript = append(transcript, probeID[:]...)
	transcript = append(transcript, token...)
	transcript = append(transcript, sourceEncoded...)
	transcript = append(transcript, destinationEncoded...)

	mac := hmac.New(sha256.New, probeKey)
	_, _ = mac.Write(transcript)
	return token, mac.Sum(nil), nil
}

func (p probeWireParams) candidatePairToken(probeKey []byte, direction probeDirection, source, destination Candidate) ([]byte, error) {
	if len(probeKey) != probeKeyBytes {
		return nil, errInvalidProbeKey
	}
	if !validProbeDirection(direction) {
		return nil, errInvalidProbeDirection
	}
	sourceEncoded, err := p.encodeCandidate(source)
	if err != nil {
		return nil, err
	}
	destinationEncoded, err := p.encodeCandidate(destination)
	if err != nil {
		return nil, err
	}

	transcript := make([]byte, 0, 2+len(sourceEncoded)+len(destinationEncoded))
	transcript = append(transcript, probeTokenVersion)
	transcript = append(transcript, byte(direction))
	transcript = append(transcript, sourceEncoded...)
	transcript = append(transcript, destinationEncoded...)

	mac := hmac.New(sha256.New, probeKey)
	_, _ = mac.Write(transcript)
	tag := mac.Sum(nil)
	return append([]byte(nil), tag[:probeCandidatePairTokenSize]...), nil
}

func (p probeWireParams) encodeCandidate(candidate Candidate) ([]byte, error) {
	kind, ok := p.candidateKind(candidate.Kind)
	if !ok {
		return nil, fmt.Errorf("%w: %q", errUnsupportedProbeCandidateKind, candidate.Kind)
	}
	// The wire encoding is zone-less, so validity must judge the zone-stripped
	// address: IsUnspecified compares with the zone included, and a zoned
	// unspecified address would otherwise encode as all-zero bytes instead of
	// rejecting.
	stripped := netip.AddrPortFrom(candidate.Addr.Addr().WithZone(""), candidate.Addr.Port())
	addrPort, ok := encodeCandidateAddrPort(stripped)
	if !ok {
		return nil, fmt.Errorf("%w: %s", errInvalidProbeCandidateAddress, candidate.Addr)
	}

	encoded := make([]byte, 0, 1+len(addrPort))
	encoded = append(encoded, kind)
	encoded = append(encoded, addrPort...)
	return encoded, nil
}

func probeObservedSourceMatches(candidate Candidate, observed netip.AddrPort) bool {
	if !candidate.Addr.IsValid() || !observed.IsValid() {
		return false
	}
	candidateAddr := candidate.Addr.Addr().Unmap().WithZone("")
	observedAddr := observed.Addr().Unmap().WithZone("")
	return candidate.Addr.Port() == observed.Port() && candidateAddr == observedAddr
}

func validProbeMessageType(messageType probeMessageType) bool {
	switch messageType {
	case probeMessageRequest, probeMessageResponse:
		return true
	default:
		return false
	}
}

func validProbeDirection(direction probeDirection) bool {
	switch direction {
	case probeDirectionDialerToListener, probeDirectionListenerToDialer:
		return true
	default:
		return false
	}
}
