package connect

import (
	"errors"
	"fmt"
	"io"
	"sync"
	"time"
)

type failClosedControlDisposition uint8

const (
	retainForOuterSettlement failClosedControlDisposition = iota + 1
	abortBeforeOwnedResources
	abortAfterOwnedResources
)

type attemptTerminalDispositionKind uint8

const (
	attemptTerminalSettleRelay attemptTerminalDispositionKind = iota + 1
	attemptTerminalFailClosed
	attemptTerminalSucceedDirect
)

type attemptTerminalStateClass uint8

const (
	attemptTerminalStatePreOperation attemptTerminalStateClass = iota + 1
	attemptTerminalStateListenPending
	attemptTerminalStateListenDefinitive
	attemptTerminalStateAcceptPendingUntransferred
	attemptTerminalStateAcceptPendingTransferred
	attemptTerminalStateAcceptDefinitiveUntransferred
	attemptTerminalStateAcceptStreamOwned
	attemptTerminalStateAcceptRawOwned
	attemptTerminalStateDialPending
	attemptTerminalStateDialStreamOwned
	attemptTerminalStateDialRawOwned
	// Composite state classes classify owned-relay-composite claims
	// (newOwnedTURNPathClaim). Their fail-closed executors invoke the
	// composite's Close before awaiting any composite-dependent operation
	// join (rebaseline #1066); stream-owned composite failure closes only the
	// stream, whose Close owns exact packet closure.
	attemptTerminalStateCompositeDialPending
	attemptTerminalStateCompositeDialStreamOwned
	attemptTerminalStateCompositeDialRawOwned
	attemptTerminalStateCompositeAcceptPending
	attemptTerminalStateCompositeAcceptStreamOwned
	attemptTerminalStateCompositeAcceptRawOwned
)

type attemptTerminalLegalityRow struct {
	state       attemptTerminalStateClass
	disposition attemptTerminalDispositionKind
	control     failClosedControlDisposition
}

var attemptTerminalLegalityTable = [...]attemptTerminalLegalityRow{
	{attemptTerminalStatePreOperation, attemptTerminalSettleRelay, 0},
	{attemptTerminalStatePreOperation, attemptTerminalFailClosed, abortBeforeOwnedResources},
	{attemptTerminalStatePreOperation, attemptTerminalFailClosed, retainForOuterSettlement},
	{attemptTerminalStateListenPending, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateListenPending, attemptTerminalFailClosed, abortBeforeOwnedResources},
	{attemptTerminalStateListenDefinitive, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateListenDefinitive, attemptTerminalFailClosed, abortBeforeOwnedResources},
	{attemptTerminalStateAcceptPendingUntransferred, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateAcceptPendingUntransferred, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateAcceptPendingUntransferred, attemptTerminalFailClosed, retainForOuterSettlement},
	{attemptTerminalStateAcceptPendingTransferred, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateAcceptPendingTransferred, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateAcceptDefinitiveUntransferred, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateAcceptDefinitiveUntransferred, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateAcceptStreamOwned, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateAcceptStreamOwned, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateAcceptStreamOwned, attemptTerminalSucceedDirect, 0},
	{attemptTerminalStateAcceptRawOwned, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateAcceptRawOwned, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateDialPending, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateDialPending, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateDialStreamOwned, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateDialStreamOwned, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateDialStreamOwned, attemptTerminalSucceedDirect, 0},
	{attemptTerminalStateDialRawOwned, attemptTerminalSettleRelay, 0},
	{attemptTerminalStateDialRawOwned, attemptTerminalFailClosed, abortAfterOwnedResources},
	// Composite claims never settle relay through their own executor: a
	// precommit retry failure disposes the composite and the reliable
	// fallback settles through the direct claim's exchange.
	{attemptTerminalStateCompositeDialPending, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateCompositeDialStreamOwned, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateCompositeDialStreamOwned, attemptTerminalSucceedDirect, 0},
	{attemptTerminalStateCompositeDialRawOwned, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateCompositeAcceptPending, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateCompositeAcceptStreamOwned, attemptTerminalFailClosed, abortAfterOwnedResources},
	{attemptTerminalStateCompositeAcceptStreamOwned, attemptTerminalSucceedDirect, 0},
	{attemptTerminalStateCompositeAcceptRawOwned, attemptTerminalFailClosed, abortAfterOwnedResources},
}

var errInvalidAttemptTerminalDisposition = errors.New("connect: invalid attempt terminal disposition")

func (r *attemptResources) settleRelay(reason UpgradeFallbackReason) (UpgradeResult, error) {
	return r.executeTerminal(attemptTerminalSettleRelay, 0, nil, func() bool {
		_, ok := lookupFallbackReason(reason)
		return ok
	}, func(state attemptTerminalStateClass) (UpgradeResult, error) {
		r.mu.Lock()
		session := r.session
		r.mu.Unlock()

		switch state {
		case attemptTerminalStatePreOperation:
			if session != nil {
				_ = closeTransportSessionWithTimeout(session)
			}
			r.markTerminalClaimReleasedBorrow()
			return relayFallbackResult(r.channel, reason), nil
		case attemptTerminalStateListenPending, attemptTerminalStateListenDefinitive:
			result := r.joinListenForTerminal(state == attemptTerminalStateListenPending)
			r.closeListenerForTerminal(result.listener)
			r.markTerminalClaimReleasedBorrow()
			return relayFallbackResult(r.channel, reason), nil
		case attemptTerminalStateAcceptPendingUntransferred,
			attemptTerminalStateAcceptPendingTransferred,
			attemptTerminalStateAcceptDefinitiveUntransferred,
			attemptTerminalStateAcceptStreamOwned,
			attemptTerminalStateAcceptRawOwned:
			pending := state == attemptTerminalStateAcceptPendingUntransferred ||
				state == attemptTerminalStateAcceptPendingTransferred
			result := r.joinAcceptForTerminal(pending)
			r.mu.Lock()
			committed := r.committed
			r.mu.Unlock()
			if !pending {
				r.mu.Lock()
				listener := r.listener
				r.mu.Unlock()
				r.closeListenerForTerminal(listener)
			}
			if session != nil {
				_ = session.Close()
			}
			if result.stream != nil {
				_ = result.stream.Close()
				r.abortControlExchange()
				r.markTerminalClaimDisposed()
				var cause error
				if !committed &&
					classifyTransportStreamResult(result) == transportStreamResultMaterializedError {
					cause = result.err
				}
				return UpgradeResult{}, ownedTransportNotConvergedError(cause)
			}
			if committed {
				r.closeCommittedPacketConn()
				r.abortControlExchange()
				r.markTerminalClaimDisposed()
				return UpgradeResult{}, ownedTransportNotConvergedError(nil)
			}
			r.markTerminalClaimReleasedBorrow()
			return relayFallbackResult(r.channel, reason), nil
		case attemptTerminalStateDialPending:
			result := r.joinDialForTerminal(true)
			if result.stream != nil {
				_ = result.stream.Close()
			} else {
				r.closeCommittedPacketConn()
			}
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(nil)
		case attemptTerminalStateDialStreamOwned, attemptTerminalStateDialRawOwned:
			result := r.joinDialForTerminal(false)
			if result.stream != nil {
				_ = result.stream.Close()
				if session != nil {
					_ = session.Close()
				}
			} else {
				if session != nil {
					_ = session.Close()
				}
				r.closeCommittedPacketConn()
			}
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(nil)
		default:
			panic("connect: sealed relay disposition has no execution plan")
		}
	})
}

func (r *attemptResources) failClosed(
	cause error,
	disposition failClosedControlDisposition,
) (UpgradeResult, error) {
	if cause == nil {
		cause = ErrUpgradeTransportNotConverged
	}
	return r.executeTerminal(attemptTerminalFailClosed, disposition, cause, func() bool {
		return true
	}, func(state attemptTerminalStateClass) (UpgradeResult, error) {
		r.mu.Lock()
		session := r.session
		r.mu.Unlock()

		switch state {
		case attemptTerminalStatePreOperation:
			if disposition == abortBeforeOwnedResources {
				r.abortControlExchange()
			}
			if session != nil {
				_ = closeTransportSessionWithTimeout(session)
			}
			r.markTerminalClaimReleasedBorrow()
			return UpgradeResult{}, cause
		case attemptTerminalStateListenPending, attemptTerminalStateListenDefinitive:
			r.abortControlExchange()
			result := r.joinListenForTerminal(state == attemptTerminalStateListenPending)
			r.closeListenerForTerminal(result.listener)
			r.markTerminalClaimReleasedBorrow()
			return UpgradeResult{}, cause
		case attemptTerminalStateAcceptPendingUntransferred,
			attemptTerminalStateAcceptPendingTransferred:
			result := r.joinAcceptForTerminal(true)
			if session != nil {
				_ = session.Close()
			}
			transferred := result.stream != nil
			if transferred {
				_ = result.stream.Close()
				r.markTerminalClaimDisposed()
			} else {
				r.mu.Lock()
				committed := r.committed
				r.mu.Unlock()
				if committed {
					r.closeCommittedPacketConn()
					r.markTerminalClaimDisposed()
					transferred = true
				} else {
					r.markTerminalClaimReleasedBorrow()
				}
			}
			if disposition == abortAfterOwnedResources {
				r.abortControlExchange()
			}
			if transferred {
				return UpgradeResult{}, ownedTransportNotConvergedError(cause)
			}
			return UpgradeResult{}, cause
		case attemptTerminalStateAcceptDefinitiveUntransferred:
			result := r.joinAcceptForTerminal(false)
			r.mu.Lock()
			listener := r.listener
			r.mu.Unlock()
			if result.stream != nil {
				panic("connect: definitive untransferred Accept materialized a stream")
			}
			r.closeListenerForTerminal(listener)
			if session != nil {
				_ = session.Close()
			}
			if disposition == abortAfterOwnedResources {
				r.abortControlExchange()
			}
			r.markTerminalClaimReleasedBorrow()
			return UpgradeResult{}, cause
		case attemptTerminalStateAcceptStreamOwned, attemptTerminalStateAcceptRawOwned:
			result := r.joinAcceptForTerminal(false)
			r.mu.Lock()
			listener := r.listener
			r.mu.Unlock()
			if result.stream != nil {
				_ = result.stream.Close()
				r.closeListenerForTerminal(listener)
				if session != nil {
					_ = session.Close()
				}
			} else {
				r.closeListenerForTerminal(listener)
				if session != nil {
					_ = session.Close()
				}
				r.closeCommittedPacketConn()
			}
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(cause)
		case attemptTerminalStateDialPending:
			result := r.joinDialForTerminal(true)
			if result.stream != nil {
				_ = result.stream.Close()
			} else {
				r.closeCommittedPacketConn()
			}
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(cause)
		case attemptTerminalStateDialStreamOwned, attemptTerminalStateDialRawOwned:
			result := r.joinDialForTerminal(false)
			if result.stream != nil {
				_ = result.stream.Close()
				r.closeDialSessionForTerminal(session)
			} else {
				r.closeDialSessionForTerminal(session)
				r.closeCommittedPacketConn()
			}
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(cause)
		case attemptTerminalStateCompositeDialPending:
			// Rebaseline #1066: dispose the owned composite before awaiting the
			// dial join; nothing else can wake dial work blocked in composite
			// socket I/O.
			r.closeCommittedPacketConn()
			result := r.joinDialForTerminal(true)
			if result.stream != nil {
				_ = result.stream.Close()
			}
			r.closeDialSessionForTerminal(session)
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(cause)
		case attemptTerminalStateCompositeDialRawOwned:
			r.closeCommittedPacketConn()
			_ = r.joinDialForTerminal(false)
			r.closeDialSessionForTerminal(session)
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(cause)
		case attemptTerminalStateCompositeDialStreamOwned:
			// Stream-owned composite failure closes only the stream; the
			// stream's Close owns exact packet closure of the composite.
			result := r.joinDialForTerminal(false)
			if result.stream != nil {
				_ = result.stream.Close()
			}
			r.closeDialSessionForTerminal(session)
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(cause)
		case attemptTerminalStateCompositeAcceptPending:
			r.closeCommittedPacketConn()
			result := r.joinAcceptForTerminal(true)
			if result.stream != nil {
				_ = result.stream.Close()
			}
			if session != nil {
				_ = session.Close()
			}
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(cause)
		case attemptTerminalStateCompositeAcceptRawOwned:
			r.closeCommittedPacketConn()
			_ = r.joinAcceptForTerminal(false)
			r.mu.Lock()
			listener := r.listener
			r.mu.Unlock()
			r.closeListenerForTerminal(listener)
			if session != nil {
				_ = session.Close()
			}
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(cause)
		case attemptTerminalStateCompositeAcceptStreamOwned:
			result := r.joinAcceptForTerminal(false)
			r.mu.Lock()
			listener := r.listener
			r.mu.Unlock()
			if result.stream != nil {
				_ = result.stream.Close()
			}
			r.closeListenerForTerminal(listener)
			if session != nil {
				_ = session.Close()
			}
			r.abortControlExchange()
			r.markTerminalClaimDisposed()
			return UpgradeResult{}, ownedTransportNotConvergedError(cause)
		default:
			panic("connect: sealed fail-closed disposition has no execution plan")
		}
	})
}

func (r *attemptResources) succeedDirect(
	pair CandidatePair,
	rtt time.Duration,
	datagrams DatagramCarrier,
) (UpgradeResult, error) {
	return r.executeTerminal(attemptTerminalSucceedDirect, 0, nil, r.directSuccessRequestValidLocked, func(state attemptTerminalStateClass) (UpgradeResult, error) {
		var result transportStreamResult
		switch state {
		case attemptTerminalStateAcceptStreamOwned, attemptTerminalStateCompositeAcceptStreamOwned:
			result = r.awaitAcceptPublicationForTerminal()
		case attemptTerminalStateDialStreamOwned, attemptTerminalStateCompositeDialStreamOwned:
			result = r.joinDialForTerminal(false)
		default:
			panic("connect: sealed direct-success disposition has no execution plan")
		}

		r.mu.Lock()
		session := r.session
		listener := r.listener
		r.mu.Unlock()

		if classifyTransportStreamResult(result) != transportStreamResultSuccess {
			panic("connect: sealed direct-success result is inconsistent")
		}
		if session != nil {
			_ = session.Close()
		}
		r.closeDirectUpgradeRelay()

		stream := result.stream
		r.mu.Lock()
		if state == attemptTerminalStateAcceptStreamOwned || state == attemptTerminalStateCompositeAcceptStreamOwned {
			r.acceptState = attemptOperationJoined
			stream = newTerminalListenerOwnedStream(stream, func() {
				r.closeListenerForTerminal(listener)
			})
		} else {
			r.dialState = attemptOperationJoined
		}
		r.claim = packetClaimSuccessTransferred
		r.mu.Unlock()

		return directUpgradeResult(stream, datagrams, pair, rtt), nil
	})
}

// terminalListenerOwnedStream extends the accepted transport stream's terminal
// Close boundary to include the listener while preserving the stream Close
// error as the public result.
type terminalListenerOwnedStream struct {
	stream        io.ReadWriteCloser
	closeListener func()
	once          sync.Once
	err           error
}

func newTerminalListenerOwnedStream(
	stream io.ReadWriteCloser,
	closeListener func(),
) io.ReadWriteCloser {
	return &terminalListenerOwnedStream{stream: stream, closeListener: closeListener}
}

func (s *terminalListenerOwnedStream) Read(p []byte) (int, error) {
	return s.stream.Read(p)
}

func (s *terminalListenerOwnedStream) Write(p []byte) (int, error) {
	return s.stream.Write(p)
}

// Abort interrupts the accepted stream without waiting behind graceful Close.
// Close still joins stream disposal and releases the listener exactly once.
func (s *terminalListenerOwnedStream) Abort() error {
	if aborter, ok := s.stream.(interface{ Abort() error }); ok {
		return aborter.Abort()
	}
	return fmt.Errorf("connect: accepted transport stream does not support abort: %w", errors.ErrUnsupported)
}

func (s *terminalListenerOwnedStream) Close() error {
	s.once.Do(func() {
		s.err = s.stream.Close()
		s.closeListener()
	})
	return s.err
}

func (r *attemptResources) executeTerminal(
	disposition attemptTerminalDispositionKind,
	control failClosedControlDisposition,
	cause error,
	requestValidLocked func() bool,
	execute func(attemptTerminalStateClass) (UpgradeResult, error),
) (UpgradeResult, error) {
	r.mu.Lock()
	if r.terminalSealed {
		done := r.terminalDone
		r.mu.Unlock()
		<-done
		r.mu.Lock()
		result, err := r.terminalResult, r.terminalErr
		r.mu.Unlock()
		return result, err
	}
	state := r.terminalStateClassLocked()
	if !requestValidLocked() || !terminalDispositionLegal(state, disposition, control) {
		r.mu.Unlock()
		return UpgradeResult{}, errInvalidAttemptTerminalDisposition
	}
	if r.terminalDone == nil {
		r.terminalDone = make(chan struct{})
	}
	r.terminalSealed = true
	r.terminalDisposition = disposition
	r.terminalState = state
	r.terminalControl = control
	r.terminalCause = cause
	var kind UpgradeErrorKind
	if r.strict {
		kind = r.strictFailureKind(cause)
	}
	done := r.terminalDone
	r.mu.Unlock()

	result, err := execute(state)
	if r.strict && err != nil {
		err = &UpgradeError{kind, err}
	}
	r.mu.Lock()
	r.terminalResult, r.terminalErr = result, err
	close(done)
	r.mu.Unlock()
	return result, err
}

func (r *attemptResources) directSuccessRequestValidLocked() bool {
	if r.claim != packetClaimStreamOwned {
		return false
	}
	switch {
	case r.acceptState == attemptOperationComplete || r.acceptState == attemptOperationJoined:
		return classifyTransportStreamResult(r.acceptResult) == transportStreamResultSuccess
	case r.dialState == attemptOperationComplete || r.dialState == attemptOperationJoined:
		return classifyTransportStreamResult(r.dial.result) == transportStreamResultSuccess
	default:
		return false
	}
}

func terminalDispositionLegal(
	state attemptTerminalStateClass,
	disposition attemptTerminalDispositionKind,
	control failClosedControlDisposition,
) bool {
	for _, row := range attemptTerminalLegalityTable {
		if row.state == state && row.disposition == disposition && row.control == control {
			return true
		}
	}
	return false
}

func (r *attemptResources) terminalStateClassLocked() attemptTerminalStateClass {
	if r.ownedComposite {
		return r.compositeTerminalStateClassLocked()
	}
	if r.acceptState != attemptOperationUnregistered {
		if r.acceptState == attemptOperationRunning {
			if r.transfer.Transferred() {
				return attemptTerminalStateAcceptPendingTransferred
			}
			return attemptTerminalStateAcceptPendingUntransferred
		}
		switch r.claim {
		case packetClaimStreamOwned:
			return attemptTerminalStateAcceptStreamOwned
		case packetClaimRawOwned:
			return attemptTerminalStateAcceptRawOwned
		default:
			return attemptTerminalStateAcceptDefinitiveUntransferred
		}
	}
	if r.listenState != attemptOperationUnregistered {
		if r.listenState == attemptOperationRunning {
			return attemptTerminalStateListenPending
		}
		return attemptTerminalStateListenDefinitive
	}
	if r.dialState != attemptOperationUnregistered {
		if r.dialState == attemptOperationRunning {
			if r.transfer.Transferred() {
				return attemptTerminalStateDialPending
			}
			return 0
		}
		switch r.claim {
		case packetClaimStreamOwned:
			return attemptTerminalStateDialStreamOwned
		case packetClaimRawOwned:
			return attemptTerminalStateDialRawOwned
		default:
			return 0
		}
	}
	if !r.transfer.Transferred() {
		return attemptTerminalStatePreOperation
	}
	// The closed matrix has no transferred-without-operation row. Production
	// control flow cannot request terminal disposition between commit publication
	// and its Dial/Accept registration; zero rejects manually assembled state.
	return 0
}

// compositeTerminalStateClassLocked classifies an owned-composite claim.
// Listen-stage and pre-transport composite states are disposed by the retry
// engine through disposeOwnedCompositeBeforeJoin rather than a sealed
// terminal request, so they classify to zero here and reject.
func (r *attemptResources) compositeTerminalStateClassLocked() attemptTerminalStateClass {
	if r.acceptState != attemptOperationUnregistered {
		if r.acceptState == attemptOperationRunning {
			return attemptTerminalStateCompositeAcceptPending
		}
		switch r.claim {
		case packetClaimStreamOwned:
			return attemptTerminalStateCompositeAcceptStreamOwned
		case packetClaimRawOwned:
			return attemptTerminalStateCompositeAcceptRawOwned
		default:
			return 0
		}
	}
	if r.listenState != attemptOperationUnregistered {
		return 0
	}
	if r.dialState != attemptOperationUnregistered {
		if r.dialState == attemptOperationRunning {
			return attemptTerminalStateCompositeDialPending
		}
		switch r.claim {
		case packetClaimStreamOwned:
			return attemptTerminalStateCompositeDialStreamOwned
		case packetClaimRawOwned:
			return attemptTerminalStateCompositeDialRawOwned
		default:
			return 0
		}
	}
	return 0
}

// disposeOwnedCompositeBeforeJoin is the precommit terminal-owner path for an
// owned composite: it invokes the composite's Close first, then cancels and
// joins every registered transport operation, and returns the joined stream
// result so the caller can route a materialized stream to fail-closed instead
// of reliable fallback. When no stream materialized the claim is disposed
// here; a stream-owned claim is left for a fail-closed request.
func (r *attemptResources) disposeOwnedCompositeBeforeJoin() transportStreamResult {
	r.mu.Lock()
	if !r.ownedComposite {
		r.mu.Unlock()
		panic("connect: composite disposal requires an owned-composite claim")
	}
	if r.compositeDisposed {
		r.mu.Unlock()
		panic("connect: owned composite already disposed")
	}
	r.compositeDisposed = true
	acceptOp := r.accept
	acceptState := r.acceptState
	listenOp := r.listen
	listenState := r.listenState
	dialOp := r.dial
	dialState := r.dialState
	listener := r.listener
	r.mu.Unlock()

	// Composite disposal precedes every composite-dependent join (rebaseline
	// #1066): only the composite's bounded graceful-then-forced base
	// interruption is guaranteed to wake work blocked in its socket I/O.
	r.closeCommittedPacketConn()

	var result transportStreamResult
	if acceptOp != nil {
		result = r.joinAcceptForTerminal(acceptState == attemptOperationRunning)
		r.closeListenerForTerminal(listener)
	}
	if listenOp != nil {
		listenResult := r.joinListenForTerminal(listenState == attemptOperationRunning)
		r.closeListenerForTerminal(listenResult.listener)
	}
	if dialOp != nil {
		result = r.joinDialForTerminal(dialState == attemptOperationRunning)
	}
	if result.stream == nil {
		r.markTerminalClaimDisposed()
	}
	return result
}

func (r *attemptResources) joinAcceptForTerminal(
	pending bool,
) transportAcceptResult {
	r.mu.Lock()
	operation := r.accept
	listener := r.listener
	r.mu.Unlock()
	if operation == nil {
		panic("connect: Accept operation is not registered")
	}

	if pending {
		operation.cancel()
		r.closeListenerForTerminal(listener)
	}
	return r.awaitAcceptPublicationForTerminal()
}

func (r *attemptResources) awaitAcceptPublicationForTerminal() transportAcceptResult {
	r.mu.Lock()
	operation := r.accept
	r.mu.Unlock()
	if operation == nil {
		panic("connect: Accept operation is not registered")
	}

	<-operation.ready

	r.mu.Lock()
	defer r.mu.Unlock()
	r.acceptState = attemptOperationJoined
	return r.acceptResult
}

func (r *attemptResources) joinListenForTerminal(pending bool) transportListenResult {
	r.mu.Lock()
	operation := r.listen
	session := r.session
	r.mu.Unlock()
	if operation == nil {
		panic("connect: Listen operation is not registered")
	}

	if pending {
		operation.cancel()
	}
	if session != nil {
		_ = session.Close()
	}
	<-operation.ready

	r.mu.Lock()
	defer r.mu.Unlock()
	r.listenState = attemptOperationJoined
	return operation.result
}

func (r *attemptResources) joinDialForTerminal(pending bool) transportStreamResult {
	r.mu.Lock()
	operation := r.dial
	session := r.session
	r.mu.Unlock()
	if operation == nil {
		panic("connect: Dial operation is not registered")
	}

	if pending {
		operation.cancel()
		r.closeDialSessionForTerminal(session)
	}
	<-operation.ready

	r.mu.Lock()
	defer r.mu.Unlock()
	r.dialState = attemptOperationJoined
	return operation.result
}

func (r *attemptResources) joinPendingDialForClassification() transportStreamResult {
	return r.joinDialForTerminal(true)
}

func (r *attemptResources) joinPendingAcceptForClassification() transportAcceptResult {
	return r.joinAcceptForTerminal(true)
}

func (r *attemptResources) joinedListenResult() transportListenResult {
	r.mu.Lock()
	defer r.mu.Unlock()
	if !r.terminalSealed || r.listenState != attemptOperationJoined || r.listen == nil {
		panic("connect: pending Listen terminal action did not join its result")
	}
	return r.listen.result
}

func (r *attemptResources) joinedAcceptResult() transportAcceptResult {
	r.mu.Lock()
	defer r.mu.Unlock()
	if !r.terminalSealed || r.acceptState != attemptOperationJoined || r.accept == nil {
		panic("connect: pending Accept terminal action did not join its result")
	}
	return r.acceptResult
}

func (r *attemptResources) closeDialSessionForTerminal(session Session) {
	if session == nil {
		return
	}
	r.mu.Lock()
	if r.dialSessionClosed {
		r.mu.Unlock()
		return
	}
	r.dialSessionClosed = true
	r.mu.Unlock()
	_ = session.Close()
}

func (r *attemptResources) closeListenerForTerminal(listener TransportListener) {
	if listener == nil {
		return
	}
	r.mu.Lock()
	if r.listenerClosed {
		r.mu.Unlock()
		return
	}
	r.listenerClosed = true
	r.mu.Unlock()
	_ = listener.Close()
}

func (r *attemptResources) markTerminalClaimReleasedBorrow() {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.claim != packetClaimBorrowed {
		panic("connect: released-borrow requires borrowed selected-path claim")
	}
	r.claim = packetClaimReleasedBorrow
}

func (r *attemptResources) markTerminalClaimDisposed() {
	r.mu.Lock()
	defer r.mu.Unlock()
	switch r.claim {
	case packetClaimRawOwned, packetClaimStreamOwned:
		r.claim = packetClaimDisposed
	default:
		panic("connect: disposed requires raw-owned or stream-owned selected-path claim")
	}
}
