package connect

import (
	"bytes"
	"crypto/sha256"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"testing"
)

func TestNewDirectionalKeysValidatesCopiesAndOrientsKeys(t *testing.T) {
	auth := authContextFixture{
		sendKey:        bytes.Repeat([]byte{0x01}, 32),
		receiveKey:     bytes.Repeat([]byte{0x02}, 32),
		sessionBinding: []byte("directional-keys-binding"),
		exporter:       NewHKDFKeyExporter([]byte("directional-keys-master"), []byte("directional-keys-binding")),
	}

	keys, err := NewDirectionalKeys(auth)
	if err != nil {
		t.Fatalf("NewDirectionalKeys: %v", err)
	}
	defer keys.Clear()

	auth.sendKey[0] = 0xff
	auth.receiveKey[0] = 0xee
	if got := keys.SendKey(); !bytes.Equal(got, bytes.Repeat([]byte{0x01}, 32)) {
		t.Fatalf("SendKey after auth mutation = %x, want original send key", got)
	}
	if got := keys.ReceiveKey(); !bytes.Equal(got, bytes.Repeat([]byte{0x02}, 32)) {
		t.Fatalf("ReceiveKey after auth mutation = %x, want original receive key", got)
	}

	sendCopy := keys.SendKey()
	sendCopy[0] = 0xaa
	if got := keys.SendKey()[0]; got != 0x01 {
		t.Fatalf("SendKey returned mutable backing storage; first byte = %x, want 01", got)
	}

	if got, want := keys.Orientation(), expectedDirectionalKeyOrientation(bytes.Repeat([]byte{0x01}, 32), bytes.Repeat([]byte{0x02}, 32)); got != want {
		t.Fatalf("Orientation = %v, want %v", got, want)
	}
}

func TestNewDirectionalKeysAcceptsAESKeySizes(t *testing.T) {
	for _, size := range []int{16, 24, 32} {
		t.Run(fmt.Sprintf("%d bytes", size), func(t *testing.T) {
			auth := testAuthContext()
			auth.sendKey = bytes.Repeat([]byte{0x01}, size)
			auth.receiveKey = bytes.Repeat([]byte{0x02}, size)

			if _, err := NewDirectionalKeys(auth); err != nil {
				t.Fatalf("NewDirectionalKeys with %d-byte keys: %v", size, err)
			}
		})
	}
}

func TestNewDirectionalKeysRejectsInvalidAuth(t *testing.T) {
	tests := []struct {
		name    string
		auth    AuthContext
		wantErr error
	}{
		{
			name:    "nil auth context",
			auth:    nil,
			wantErr: ErrNilAuthContext,
		},
		{
			name:    "empty send key",
			auth:    authContextFixture{sendKey: nil, receiveKey: bytes.Repeat([]byte{0x02}, 32)},
			wantErr: ErrEmptyDirectionalKey,
		},
		{
			name:    "empty receive key",
			auth:    authContextFixture{sendKey: bytes.Repeat([]byte{0x01}, 32), receiveKey: nil},
			wantErr: ErrEmptyDirectionalKey,
		},
		{
			name:    "equal keys",
			auth:    authContextFixture{sendKey: bytes.Repeat([]byte{0x01}, 32), receiveKey: bytes.Repeat([]byte{0x01}, 32)},
			wantErr: ErrEqualDirectionalKeys,
		},
		{
			name:    "invalid send key size",
			auth:    authContextFixture{sendKey: bytes.Repeat([]byte{0x01}, 20), receiveKey: bytes.Repeat([]byte{0x02}, 32)},
			wantErr: ErrInvalidDirectionalKeySize,
		},
		{
			name:    "invalid receive key size",
			auth:    authContextFixture{sendKey: bytes.Repeat([]byte{0x01}, 32), receiveKey: bytes.Repeat([]byte{0x02}, 20)},
			wantErr: ErrInvalidDirectionalKeySize,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := NewDirectionalKeys(tt.auth)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("NewDirectionalKeys error = %v, want %v", err, tt.wantErr)
			}
		})
	}
}

func TestDirectionalKeysFormattingRedactsKeyMaterial(t *testing.T) {
	sendKey := []byte("0123456789abcdef")
	receiveKey := []byte("abcdef0123456789")
	keys, err := NewDirectionalKeys(authContextFixture{sendKey: sendKey, receiveKey: receiveKey})
	if err != nil {
		t.Fatalf("NewDirectionalKeys: %v", err)
	}
	defer keys.Clear()

	tests := []struct {
		name   string
		format string
		value  any
	}{
		{name: "value percent v", format: "%v", value: keys},
		{name: "value plus v", format: "%+v", value: keys},
		{name: "value sharp v", format: "%#v", value: keys},
		{name: "value string", format: "%s", value: keys},
		{name: "value quote", format: "%q", value: keys},
		{name: "value hex", format: "%x", value: keys},
		{name: "value type", format: "%T", value: keys},
		{name: "value pointer", format: "%p", value: keys},
		{name: "address of pointer", format: "%p", value: &keys},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := fmt.Sprintf(tt.format, tt.value)
			for _, forbidden := range []string{
				string(sendKey),
				string(receiveKey),
				rawByteList(sendKey),
				rawByteList(receiveKey),
			} {
				if strings.Contains(got, forbidden) {
					t.Fatalf("fmt.Sprintf(%q, keys) = %q, contains raw key material %q", tt.format, got, forbidden)
				}
			}
		})
	}
}

func rawByteList(key []byte) string {
	parts := make([]string, len(key))
	for i, b := range key {
		parts[i] = strconv.Itoa(int(b))
	}
	return "[" + strings.Join(parts, " ") + "]"
}

func TestDirectionalKeysClearZeroizesSnapshot(t *testing.T) {
	keys, err := NewDirectionalKeys(authContextFixture{
		sendKey:    bytes.Repeat([]byte{0x01}, 32),
		receiveKey: bytes.Repeat([]byte{0x02}, 32),
	})
	if err != nil {
		t.Fatalf("NewDirectionalKeys: %v", err)
	}
	sendSnapshot := keys.material.sendKey
	receiveSnapshot := keys.material.receiveKey

	keys.Clear()
	assertZeroizedBytes(t, "send key", sendSnapshot)
	assertZeroizedBytes(t, "receive key", receiveSnapshot)
	if keys.material != nil {
		t.Fatalf("material after Clear = %#v, want nil", keys.material)
	}
	if keys.orientation != 0 {
		t.Fatalf("orientation after Clear = %v, want zero", keys.orientation)
	}
}

func assertZeroizedBytes(t *testing.T, name string, got []byte) {
	t.Helper()

	for i, b := range got {
		if b != 0 {
			t.Fatalf("%s byte %d after Clear = 0x%02x, want zero", name, i, b)
		}
	}
}

func expectedDirectionalKeyOrientation(sendKey, receiveKey []byte) DirectionalKeyOrientation {
	sendHash := sha256.Sum256(sendKey)
	receiveHash := sha256.Sum256(receiveKey)
	if bytes.Compare(sendHash[:], receiveHash[:]) > 0 {
		return DirectionalKeyOrientationSendHashGreater
	}
	return DirectionalKeyOrientationReceiveHashGreaterOrEqual
}
