package connect

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net"
	"net/netip"
	"slices"
	"sync"
	"syscall"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/proberuntime"
)

func probePairs(ctx context.Context, runtime proberuntime.Runtime, attemptDeadline time.Time, probeKey []byte, role upgradeRole, pairs []probeCandidatePair, concurrency int) (candidatePairProbeResult, error) {
	return probePairsWithRetryDelay(ctx, runtime, attemptDeadline, probeKey, role, pairs, concurrency, probeRetryDelay, v1ProbeWireParams(), false)
}

func TestCandidatePairsHonorsRemotePolicyBeforeTopologyTieBreaks(t *testing.T) {
	local := []Candidate{
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.5:10000")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.6:10000")},
		{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.5:10000")},
		{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "203.0.113.200:10000")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "0.0.0.0:10000")},
	}
	remote := []Candidate{
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "198.51.100.20:20000")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.9:20000")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.20:20000")},
		{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "203.0.113.20:20000")},
		{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "203.0.113.201:20000")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "224.0.0.1:20000")},
	}
	policy := CandidatePolicy{
		ExcludeRemotePrefixes:      []netip.Prefix{netip.MustParsePrefix("192.0.2.0/24")},
		DeprioritizeRemotePrefixes: []netip.Prefix{netip.MustParsePrefix("198.51.100.0/24")},
	}

	got := candidatePairs(local, remote, policy)
	want := []probeCandidatePair{
		{local: local[0], remote: remote[1]},
		{local: local[1], remote: remote[1]},
		{local: local[0], remote: remote[3]},
		{local: local[1], remote: remote[3]},
		{local: local[2], remote: remote[1]},
		{local: local[2], remote: remote[3]},
		{local: local[0], remote: remote[0]},
		{local: local[1], remote: remote[0]},
		{local: local[2], remote: remote[0]},
	}
	if len(got) != len(want) {
		t.Fatalf("candidatePairs length = %d, want %d: %#v", len(got), len(want), got)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("candidatePairs[%d] = %#v, want %#v; all pairs %#v", i, got[i], want[i], got)
		}
	}
	for _, pair := range got {
		if pair.remote.Addr == remote[2].Addr {
			t.Fatalf("candidatePairs included excluded remote candidate %#v", pair.remote)
		}
		if pair.local.Kind == CandidateKindRelay || pair.remote.Kind == CandidateKindRelay {
			t.Fatalf("candidatePairs included unsupported relay probe pair %#v", pair)
		}
		if !probeCandidateSupported(pair.local) || !probeCandidateSupported(pair.remote) {
			t.Fatalf("candidatePairs included invalid probe candidate pair %#v", pair)
		}
	}
}

func TestCandidatePairsAllowsUnicastRemoteRangesUntilPolicyExcludes(t *testing.T) {
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "198.51.100.10:10000")}
	privateHost := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.9:20000")}
	privateReflexive := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "172.16.0.9:20000")}
	loopbackHost := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:20000")}
	lanHost := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.168.1.9:20000")}
	publicReflexive := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "203.0.113.9:20000")}
	invalidRemote := []Candidate{
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "0.0.0.0:20000")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "224.0.0.1:20000")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.60:0")},
	}

	remote := []Candidate{privateHost, privateReflexive, loopbackHost, lanHost, publicReflexive}
	remote = append(remote, invalidRemote...)

	defaultPairs := candidatePairs([]Candidate{local}, remote, CandidatePolicy{})
	wantDefault := []probeCandidatePair{
		{local: local, remote: privateHost},
		{local: local, remote: loopbackHost},
		{local: local, remote: lanHost},
		{local: local, remote: privateReflexive},
		{local: local, remote: publicReflexive},
	}
	assertProbeCandidatePairs(t, defaultPairs, wantDefault)

	policyPairs := candidatePairs([]Candidate{local}, remote, CandidatePolicy{
		ExcludeRemotePrefixes: []netip.Prefix{
			netip.MustParsePrefix("10.0.0.0/8"),
			netip.MustParsePrefix("172.16.0.0/12"),
			netip.MustParsePrefix("127.0.0.0/8"),
			netip.MustParsePrefix("192.168.0.0/16"),
		},
	})
	wantPolicy := []probeCandidatePair{{local: local, remote: publicReflexive}}
	assertProbeCandidatePairs(t, policyPairs, wantPolicy)

	local6 := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[2001:db8::10]:10000")}
	loopbackHost6 := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[::1]:20000")}
	ulaHost6 := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[fd00::9]:20000")}
	linkLocalHost6 := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[fe80::9]:20000")}
	documentationReflexive6 := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "[2001:db8::9]:20000")}
	invalidRemote6 := []Candidate{
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[::]:20000")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[ff02::1]:20000")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[fd00::60]:0")},
	}

	remote6 := []Candidate{loopbackHost6, ulaHost6, linkLocalHost6, documentationReflexive6}
	remote6 = append(remote6, invalidRemote6...)

	defaultPairs6 := candidatePairs([]Candidate{local6}, remote6, CandidatePolicy{})
	wantDefault6 := []probeCandidatePair{
		{local: local6, remote: loopbackHost6},
		{local: local6, remote: ulaHost6},
		{local: local6, remote: linkLocalHost6},
		{local: local6, remote: documentationReflexive6},
	}
	assertProbeCandidatePairs(t, defaultPairs6, wantDefault6)

	policyPairs6 := candidatePairs([]Candidate{local6}, remote6, CandidatePolicy{
		ExcludeRemotePrefixes: []netip.Prefix{
			netip.MustParsePrefix("::1/128"),
			netip.MustParsePrefix("fc00::/7"),
			netip.MustParsePrefix("fe80::/10"),
		},
	})
	wantPolicy6 := []probeCandidatePair{{local: local6, remote: documentationReflexive6}}
	assertProbeCandidatePairs(t, policyPairs6, wantPolicy6)
}

func TestCandidatePairsSkipsMixedAddressFamilies(t *testing.T) {
	local4 := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:10000")}
	local6 := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[2001:db8::10]:10000")}
	remote6 := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[2001:db8::20]:20000")}

	got := candidatePairs([]Candidate{local4, local6}, []Candidate{remote6}, CandidatePolicy{})
	want := []probeCandidatePair{{local: local6, remote: remote6}}
	if len(got) != len(want) {
		t.Fatalf("candidatePairs length = %d, want %d: %#v", len(got), len(want), got)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("candidatePairs[%d] = %#v, want %#v; all pairs %#v", i, got[i], want[i], got)
		}
	}
}

func assertProbeCandidatePairs(t *testing.T, got, want []probeCandidatePair) {
	t.Helper()

	if len(got) != len(want) {
		t.Fatalf("candidatePairs length = %d, want %d: %#v", len(got), len(want), got)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("candidatePairs[%d] = %#v, want %#v; all pairs %#v", i, got[i], want[i], got)
		}
	}
}

func TestProbeCandidatePairsReportsProbeFailedWhenNoCompatiblePairWithoutPolicy(t *testing.T) {
	attempt := directUpgradeAttempt{auth: testAuthContext()}
	local := localUpgradeOffer{
		role:       upgradeRoleDial,
		probeNonce: bytes.Repeat([]byte{0x01}, upgradeControlProbeNonceBytes),
		candidates: []Candidate{
			{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:10000")},
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	peer := localUpgradeOffer{
		probeNonce: bytes.Repeat([]byte{0x02}, upgradeControlProbeNonceBytes),
		candidates: []Candidate{
			{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[2001:db8::20]:20000")},
		},
	}

	pairPlan := planProbeCandidatePairs(local.candidates, peer.candidates, attempt.cfg.candidatePolicy, local.role)
	result, err := attempt.probeCandidatePairPlan(context.Background(), local, peer, pairPlan)
	if err != nil {
		t.Fatalf("probeCandidatePairPlan: %v", err)
	}
	if result.fallback != UpgradeFallbackProbeFailed {
		t.Fatalf("probeCandidatePairPlan fallback = %q, want %q", result.fallback, UpgradeFallbackProbeFailed)
	}
}

func TestProbeCandidatePairsReportsProbeFailedWhenPolicyDidNotExcludePairs(t *testing.T) {
	tests := []struct {
		name       string
		local      []Candidate
		remote     []Candidate
		policy     CandidatePolicy
		wantReason UpgradeFallbackReason
	}{
		{
			name: "deprioritize policy with incompatible address family",
			local: []Candidate{
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:10000")},
			},
			remote: []Candidate{
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[2001:db8::20]:20000")},
			},
			policy: CandidatePolicy{
				DeprioritizeRemotePrefixes: []netip.Prefix{netip.MustParsePrefix("2001:db8::/32")},
			},
			wantReason: UpgradeFallbackProbeFailed,
		},
		{
			name: "exclude policy with only built-in-invalid remotes",
			local: []Candidate{
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:10000")},
			},
			remote: []Candidate{
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "0.0.0.0:20000")},
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "224.0.0.1:20000")},
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.60:0")},
			},
			policy: CandidatePolicy{
				ExcludeRemotePrefixes: []netip.Prefix{netip.MustParsePrefix("10.0.0.0/8")},
			},
			wantReason: UpgradeFallbackProbeFailed,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			attempt := directUpgradeAttempt{
				auth: testAuthContext(),
				cfg:  upgradeConfig{candidatePolicy: tt.policy},
			}
			attempt = newTestDirectUpgradeAttempt(attempt)
			local := localUpgradeOffer{
				role:       upgradeRoleDial,
				probeNonce: bytes.Repeat([]byte{0x01}, upgradeControlProbeNonceBytes),
				candidates: tt.local,
			}
			peer := localUpgradeOffer{
				probeNonce: bytes.Repeat([]byte{0x02}, upgradeControlProbeNonceBytes),
				candidates: tt.remote,
			}

			pairPlan := planProbeCandidatePairs(local.candidates, peer.candidates, attempt.cfg.candidatePolicy, local.role)
			result, err := attempt.probeCandidatePairPlan(context.Background(), local, peer, pairPlan)
			if err != nil {
				t.Fatalf("probeCandidatePairPlan: %v", err)
			}
			if result.fallback != tt.wantReason {
				t.Fatalf("probeCandidatePairPlan fallback = %q, want %q", result.fallback, tt.wantReason)
			}
		})
	}
}

func TestProbeCandidatePairsReportsPolicyExcludedWhenRemotePolicyExhaustsPairs(t *testing.T) {
	tests := []struct {
		name   string
		local  []Candidate
		remote []Candidate
		policy CandidatePolicy
	}{
		{
			name: "remote prefixes",
			local: []Candidate{
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:10000")},
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[2001:db8::10]:10000")},
			},
			remote: []Candidate{
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "10.0.0.9:20000")},
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:20000")},
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[fe80::9]:20000")},
			},
			policy: CandidatePolicy{
				ExcludeRemotePrefixes: []netip.Prefix{
					netip.MustParsePrefix("10.0.0.0/8"),
					netip.MustParsePrefix("127.0.0.0/8"),
					netip.MustParsePrefix("fe80::/10"),
				},
			},
		},
		{
			name: "candidate kind",
			local: []Candidate{
				{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.10:10000")},
			},
			remote: []Candidate{
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.20:20000")},
			},
			policy: CandidatePolicy{
				ExcludeKinds: []CandidateKind{CandidateKindHost},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			attempt := directUpgradeAttempt{
				auth: testAuthContext(),
				cfg:  upgradeConfig{candidatePolicy: tt.policy},
			}
			attempt = newTestDirectUpgradeAttempt(attempt)
			local := localUpgradeOffer{
				role:       upgradeRoleDial,
				probeNonce: bytes.Repeat([]byte{0x01}, upgradeControlProbeNonceBytes),
				candidates: tt.local,
			}
			peer := localUpgradeOffer{
				probeNonce: bytes.Repeat([]byte{0x02}, upgradeControlProbeNonceBytes),
				candidates: tt.remote,
			}

			pairPlan := planProbeCandidatePairs(local.candidates, peer.candidates, attempt.cfg.candidatePolicy, local.role)
			result, err := attempt.probeCandidatePairPlan(context.Background(), local, peer, pairPlan)
			if err != nil {
				t.Fatalf("probeCandidatePairPlan: %v", err)
			}
			if result.fallback != UpgradeFallbackPolicyExcluded {
				t.Fatalf("probeCandidatePairPlan fallback = %q, want %q", result.fallback, UpgradeFallbackPolicyExcluded)
			}
		})
	}
}

func TestProbePairsRetriesAndRequiresMatchingProbeResponseID(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	requests := 0
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		requests++
		probeID := decoded.ProbeID
		if requests == 1 {
			probeID[0] ^= 0xff
		}
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, probeID, remote, local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(remote.Addr), nil)
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(testRunnerSafeProbeTimeout), key, upgradeRoleDial, []probeCandidatePair{{local: local, remote: remote}}, 1)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if !result.succeeded {
		t.Fatal("probePairs did not accept the matching retry response")
	}
	if result.pair.local != local || result.pair.remote != remote {
		t.Fatalf("probePairs pair = %#v, want local %#v remote %#v", result.pair, local, remote)
	}
	if result.rtt <= 0 {
		t.Fatalf("probePairs RTT = %s, want positive", result.rtt)
	}
	if requests != 2 {
		t.Fatalf("probePairs wrote %d requests, want exactly 2 so authenticated success stops the remaining send and later passes", requests)
	}
}

func TestProbePairsPriorityReadySuccessStopsBeforeLowerRankAdmission(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	firstRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	successfulRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10003")}
	sentinelRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10004")}
	pairs := []probeCandidatePair{
		{local: local, remote: firstRemote},
		{local: local, remote: successfulRemote},
		{local: local, remote: sentinelRemote},
	}

	for _, tt := range []struct {
		name string
		role upgradeRole
	}{
		{name: "dialer", role: upgradeRoleDial},
		{name: "listener", role: upgradeRoleListen},
	} {
		t.Run(tt.name, func(t *testing.T) {
			role := tt.role
			start := time.Unix(1, 0)
			runtime := newScriptedProbeRuntime(start)
			var sentinelReached bool
			var sendsAfterReady int
			responseQueued := false
			runtime.onSend = func(packet []byte, addr net.Addr) error {
				if !runtime.Now().Before(start.Add(3 * probeRetryInterval)) {
					sendsAfterReady++
				}
				if addr.String() == sentinelRemote.Addr.String() {
					sentinelReached = true
					return errors.New("lower-ranked sentinel pair was admitted")
				}
				if addr.String() != successfulRemote.Addr.String() || responseQueued {
					return nil
				}
				decoded, ok := decodeProbeDatagram(packet)
				if !ok || decoded.MessageType != probeMessageRequest {
					return nil
				}
				responseQueued = true
				response, err := encodeProbeDatagram(key, probeMessageResponse, peerProbeDirection(role), decoded.ProbeID, successfulRemote, local)
				if err != nil {
					return err
				}
				runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(successfulRemote.Addr), nil)
				return nil
			}

			deadline := start.Add(100 * time.Millisecond)
			result, err := probePairsWithRetryDelay(context.Background(), runtime, deadline, key, role, pairs, 2, func() time.Duration { return probeRetryInterval }, v1ProbeWireParams(), false)
			if err != nil {
				t.Fatalf("probePairsWithRetryDelay: %v", err)
			}
			if !result.succeeded || result.pair != pairs[1] {
				t.Fatalf("result = %#v, want successful second-ranked pair %#v", result, pairs[1])
			}
			if sentinelReached {
				t.Fatal("priority-ready success admitted the lower-ranked sentinel pair")
			}
			if sendsAfterReady != 0 {
				t.Fatalf("probe sends after priority readiness = %d, want 0", sendsAfterReady)
			}
			wantCompletion := start.Add(3 * probeRetryInterval)
			if role == upgradeRoleListen {
				wantCompletion = deadline
			}
			if runtime.Now() != wantCompletion {
				t.Fatalf("completion time = %s, want %s", runtime.Now(), wantCompletion)
			}
		})
	}
}

func TestProbePairsHeldListenerDuplicateResponsePreservesFirstRTT(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionDialerToListener, decoded.ProbeID, remote, local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(remote.Addr), nil)
		runtime.enqueueAfter(500*time.Millisecond, response, net.UDPAddrFromAddrPort(remote.Addr), nil)
		return nil
	}
	deadline := runtime.Now().Add(600 * time.Millisecond)

	result, err := probePairsWithRetryDelay(context.Background(), runtime, deadline, key, upgradeRoleListen, []probeCandidatePair{{local: local, remote: remote}}, 1, func() time.Duration { return probeRetryInterval }, v1ProbeWireParams(), false)
	if err != nil {
		t.Fatalf("probePairsWithRetryDelay: %v", err)
	}
	if !result.succeeded || result.pair != (probeCandidatePair{local: local, remote: remote}) {
		t.Fatalf("result = %#v, want successful listener pair", result)
	}
	if result.rtt != time.Millisecond {
		t.Fatalf("held listener RTT = %s, want first response RTT %s", result.rtt, time.Millisecond)
	}
}

var errProbeResponseSendFailed = errors.New("connect: probe response send failed")

// TestProbePairsHeldListenerResponseSendCancel is the #1283 regression at the
// handleProbePacket error exit: a listener already holding a success answers
// a dialer request, and the response Send observes context cancellation.
// Under heldOnCancel the held success must survive exactly as it does at the
// loop's other cancellation exits; non-cancellation send errors and v1
// callers keep their existing error shape.
func TestProbePairsHeldListenerResponseSendCancel(t *testing.T) {
	tests := []struct {
		name         string
		heldOnCancel bool
		sendErr      error
		wantHeld     bool
		wantErr      error
	}{
		{name: "heldOnCancelReturnsHeldSuccess", heldOnCancel: true, sendErr: context.Canceled, wantHeld: true},
		{name: "heldOnCancelKeepsNonCancelError", heldOnCancel: true, sendErr: errProbeResponseSendFailed, wantErr: errProbeResponseSendFailed},
		{name: "v1ReturnsCancellation", heldOnCancel: false, sendErr: context.Canceled, wantErr: context.Canceled},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
			local := Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "198.51.100.1:10001")}
			remote := Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "198.51.100.2:10002")}
			remoteAddr := net.UDPAddrFromAddrPort(remote.Addr)
			dialect := turnRetryProbeWireParams()
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			runtime := newScriptedProbeRuntime(time.Unix(1, 0))
			responseSends := 0
			runtime.onSend = func(packet []byte, _ net.Addr) error {
				decoded, ok := dialect.decodeDatagram(packet)
				if !ok {
					t.Fatalf("listener sent an undecodable probe datagram")
				}
				switch decoded.MessageType {
				case probeMessageRequest:
					// Answer the listener's own request so it holds a success,
					// then deliver a dialer request that the listener must answer.
					response, err := dialect.encodeDatagram(key, probeMessageResponse, probeDirectionDialerToListener, decoded.ProbeID, remote, local)
					if err != nil {
						return err
					}
					runtime.enqueueAfter(time.Millisecond, response, remoteAddr, nil)
					request, err := dialect.encodeDatagram(key, probeMessageRequest, probeDirectionDialerToListener, [probeIDBytes]byte{0x7f}, remote, local)
					if err != nil {
						return err
					}
					runtime.enqueueAfter(10*time.Millisecond, request, remoteAddr, nil)
					return nil
				case probeMessageResponse:
					responseSends++
					if errors.Is(tt.sendErr, context.Canceled) {
						cancel()
					}
					return tt.sendErr
				default:
					t.Fatalf("listener sent unexpected probe message type %v", decoded.MessageType)
					return nil
				}
			}
			deadline := runtime.Now().Add(time.Second)

			result, err := probePairsWithRetryDelay(ctx, runtime, deadline, key, upgradeRoleListen, []probeCandidatePair{{local: local, remote: remote}}, 1, func() time.Duration { return probeRetryInterval }, dialect, tt.heldOnCancel)
			if responseSends != 1 {
				t.Fatalf("listener response sends = %d, want 1", responseSends)
			}
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("probePairsWithRetryDelay error: got %v, want %v", err, tt.wantErr)
			}
			if tt.wantHeld {
				if !result.succeeded || result.pair != (probeCandidatePair{local: local, remote: remote}) {
					t.Fatalf("result = %#v, want held listener pair", result)
				}
				if result.rtt != time.Millisecond {
					t.Fatalf("held listener RTT: got %s, want locally measured %s", result.rtt, time.Millisecond)
				}
			} else if result.succeeded {
				t.Fatalf("result = %#v, want no success alongside error", result)
			}
		})
	}
}

func TestProbePairsExpiresAtRuntimeDeadlineWithoutWallClockContext(t *testing.T) {
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	runtime := &logicalProbeRuntime{now: time.Unix(1, 0)}
	attemptDeadline := runtime.now.Add(100 * time.Millisecond)

	result, err := probePairs(
		context.Background(),
		runtime,
		attemptDeadline,
		bytes.Repeat([]byte{0x42}, 32),
		upgradeRoleDial,
		[]probeCandidatePair{{local: local, remote: remote}},
		1,
	)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if result.succeeded {
		t.Fatal("probePairs succeeded without a response")
	}
	if runtime.now != attemptDeadline {
		t.Fatalf("runtime time = %s, want attempt deadline %s", runtime.now, attemptDeadline)
	}
	if runtime.sendCalls <= probeRequestAttempts {
		t.Fatalf("probe request sends = %d, want more than one %d-request pass", runtime.sendCalls, probeRequestAttempts)
	}
	if maxSends := 1 + int((attemptDeadline.Sub(time.Unix(1, 0))-time.Nanosecond)/probeRetryInterval); runtime.sendCalls > maxSends {
		t.Fatalf("probe request sends = %d, want at most deadline/retry bound %d", runtime.sendCalls, maxSends)
	}
}

func TestProbePairsStopsSchedulingWhenSendCrossesAttemptDeadline(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	firstRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	secondRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10003")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	attemptDeadline := runtime.Now().Add(100 * time.Millisecond)
	sentinelErr := errors.New("send scheduled after attempt deadline")
	sends := 0
	sentinelObserved := false
	runtime.onSend = func([]byte, net.Addr) error {
		sends++
		if sends == 1 {
			runtime.now = attemptDeadline.Add(time.Nanosecond)
			return nil
		}
		sentinelObserved = true
		return sentinelErr
	}

	result, err := probePairs(
		context.Background(),
		runtime,
		attemptDeadline,
		key,
		upgradeRoleDial,
		[]probeCandidatePair{
			{local: local, remote: firstRemote},
			{local: local, remote: secondRemote},
		},
		2,
	)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if result.succeeded {
		t.Fatal("probePairs succeeded after the attempt deadline")
	}
	if sends != 1 {
		t.Fatalf("probe sends = %d, want 1", sends)
	}
	if sentinelObserved {
		t.Fatal("probePairs called the post-deadline sentinel send")
	}
}

func TestProbeCandidatePairPlanDerivationConsumesAttemptBudget(t *testing.T) {
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	runtime.onSend = func([]byte, net.Addr) error {
		return errors.New("probe sent after derivation exhausted the attempt budget")
	}
	auth := testAuthContext()
	auth.exporter = &advancingProbeKeyExporter{
		exporter: auth.exporter,
		runtime:  runtime,
		advance:  101 * time.Millisecond,
	}
	localCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remoteCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		auth: auth,
		cfg: upgradeConfig{
			packetConn:       &runtimeProviderPacketConn{runtime: runtime, local: localCandidate.Addr},
			probeConcurrency: 1,
			probeTimeout:     100 * time.Millisecond,
		},
	})
	pairPlan := candidatePairPlan{pairs: []probeCandidatePair{{local: localCandidate, remote: remoteCandidate}}}
	local := localUpgradeOffer{
		role:       upgradeRoleDial,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
	}
	peer := localUpgradeOffer{probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes)}

	result, err := attempt.probeCandidatePairPlan(context.Background(), local, peer, pairPlan)
	if err != nil {
		t.Fatalf("probeCandidatePairPlan: %v", err)
	}
	if result.succeeded {
		t.Fatal("probe unexpectedly succeeded after derivation consumed the attempt budget")
	}
	if result.fallback != UpgradeFallbackProbeFailed {
		t.Fatalf("fallback = %q, want %q", result.fallback, UpgradeFallbackProbeFailed)
	}
	if !runtime.isReleased() {
		t.Fatal("probe runtime was not released after exhausted derivation budget")
	}
}

func TestProbePairsPreservesExplicitCancellationAtLogicalDeadline(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	runtime := &logicalProbeRuntime{now: time.Unix(1, 0)}

	_, err := probePairs(ctx, runtime, runtime.Now(), bytes.Repeat([]byte{0x42}, 32), upgradeRoleDial, nil, 1)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("probePairs error = %v, want %v", err, context.Canceled)
	}
}

func TestProbePairsAcceptsDelayedResponseBeforeDeadline(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	responseQueued := false
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest || responseQueued {
			return nil
		}
		responseQueued = true
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, decoded.ProbeID, remote, local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(90*time.Millisecond, response, net.UDPAddrFromAddrPort(remote.Addr), nil)
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(200*time.Millisecond), key, upgradeRoleDial, []probeCandidatePair{{local: local, remote: remote}}, 1)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if !result.succeeded {
		t.Fatal("probePairs did not accept delayed response before the probe deadline")
	}
}

func TestProbePairsCompletesRankedConcurrentPassBeforeRepeating(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remotes := []Candidate{
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10003")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10004")},
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10005")},
	}
	pairs := make([]probeCandidatePair, len(remotes))
	for i := range remotes {
		pairs[i] = probeCandidatePair{local: local, remote: remotes[i]}
	}

	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	requestCounts := make(map[netip.AddrPort]int)
	admissions := make([]netip.AddrPort, 0, len(remotes)+1)
	runtime.onSend = func(packet []byte, addr net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		remoteAddr, err := addrPortFromNetAddr(addr)
		if err != nil {
			return err
		}
		requestCounts[remoteAddr]++
		if requestCounts[remoteAddr] == 1 || remoteAddr == remotes[0].Addr && requestCounts[remoteAddr] == probeRequestAttempts+1 {
			admissions = append(admissions, remoteAddr)
		}
		if remoteAddr != remotes[0].Addr || requestCounts[remoteAddr] != probeRequestAttempts+1 {
			return nil
		}
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, decoded.ProbeID, remotes[0], local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(remotes[0].Addr), nil)
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(time.Second), key, upgradeRoleDial, pairs, 2)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if !result.succeeded || result.pair.remote != remotes[0] {
		t.Fatalf("probe result = %#v, want first-ranked pair on pass two", result)
	}
	wantAdmissions := []netip.AddrPort{remotes[0].Addr, remotes[1].Addr, remotes[2].Addr, remotes[3].Addr, remotes[0].Addr}
	if !slices.Equal(admissions, wantAdmissions) {
		t.Fatalf("probe admissions = %v, want complete rank order before repeat %v", admissions, wantAdmissions)
	}
}

func TestProbePairsPreservesProbeIDsAndRetrySpacingAcrossPasses(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	requestTimes := make([]time.Time, 0, probeRequestAttempts+1)
	var firstProbeID [probeIDBytes]byte
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		requestTimes = append(requestTimes, runtime.Now())
		if len(requestTimes) == 1 {
			firstProbeID = decoded.ProbeID
		}
		if len(requestTimes) != probeRequestAttempts+1 {
			return nil
		}
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, firstProbeID, remote, local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(remote.Addr), nil)
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(time.Second), key, upgradeRoleDial, []probeCandidatePair{{local: local, remote: remote}}, 1)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if !result.succeeded {
		t.Fatal("probePairs did not accept the pass-one probe ID after rollover")
	}
	if len(requestTimes) != probeRequestAttempts+1 {
		t.Fatalf("probe requests = %d, want first request of pass two", len(requestTimes))
	}
	crossPassSpacing := requestTimes[probeRequestAttempts].Sub(requestTimes[probeRequestAttempts-1])
	if crossPassSpacing < probeRetryInterval || crossPassSpacing > probeRetryInterval+probeRetryJitter {
		t.Fatalf("cross-pass request spacing = %s, want within [%s, %s]", crossPassSpacing, probeRetryInterval, probeRetryInterval+probeRetryJitter)
	}
	if result.rtt <= crossPassSpacing {
		t.Fatalf("RTT from pass-one probe ID = %s, want greater than cross-pass spacing %s", result.rtt, crossPassSpacing)
	}
}

func TestProbePairsContinuesAfterRecoverableRequestWriteError(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	unreachableRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	reachableRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10003")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	runtime.onSend = func(packet []byte, addr net.Addr) error {
		remoteAddr, err := addrPortFromNetAddr(addr)
		if err != nil {
			return err
		}
		if remoteAddr == unreachableRemote.Addr {
			return syscall.EHOSTUNREACH
		}
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, decoded.ProbeID, reachableRemote, local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(reachableRemote.Addr), nil)
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(testRunnerSafeProbeTimeout), key, upgradeRoleDial, []probeCandidatePair{
		{local: local, remote: unreachableRemote},
		{local: local, remote: reachableRemote},
	}, 1)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if !result.succeeded {
		t.Fatal("probePairs did not continue to the reachable pair after recoverable write error")
	}
	if result.pair.remote != reachableRemote {
		t.Fatalf("probePairs selected remote = %#v, want reachable remote %#v", result.pair.remote, reachableRemote)
	}
}

func TestProbePairsPermanentlyRetiresRecoverableRequestWriteErrorAcrossPasses(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	unreachableRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	reachableRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10003")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	unreachableRequests := 0
	reachableRequests := 0
	runtime.onSend = func(packet []byte, addr net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		remoteAddr, err := addrPortFromNetAddr(addr)
		if err != nil {
			return err
		}
		if remoteAddr == unreachableRemote.Addr {
			unreachableRequests++
			return syscall.EHOSTUNREACH
		}
		reachableRequests++
		if reachableRequests != probeRequestAttempts+1 {
			return nil
		}
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, decoded.ProbeID, reachableRemote, local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(reachableRemote.Addr), nil)
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(time.Second), key, upgradeRoleDial, []probeCandidatePair{
		{local: local, remote: unreachableRemote},
		{local: local, remote: reachableRemote},
	}, 1)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if !result.succeeded || result.pair.remote != reachableRemote {
		t.Fatalf("probe result = %#v, want reachable pair on a later pass", result)
	}
	if unreachableRequests != 1 {
		t.Fatalf("unreachable pair requests = %d, want one permanent-retirement attempt", unreachableRequests)
	}
	if reachableRequests != probeRequestAttempts+1 {
		t.Fatalf("reachable pair requests = %d, want first request of pass two", reachableRequests)
	}
}

func TestProbePairsResponseWriteRetirementPreservesInboundProcessing(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	retiredRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	reachableRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10003")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	retiredRequests := 0
	retiredResponseAttempts := 0
	reachableRequests := 0
	peerRequest := func(id byte) ([]byte, error) {
		var probeID [probeIDBytes]byte
		probeID[0] = id
		return encodeProbeDatagram(key, probeMessageRequest, probeDirectionListenerToDialer, probeID, retiredRemote, local)
	}
	runtime.onSend = func(packet []byte, addr net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok {
			return nil
		}
		remoteAddr, err := addrPortFromNetAddr(addr)
		if err != nil {
			return err
		}
		if decoded.MessageType == probeMessageResponse && remoteAddr == retiredRemote.Addr {
			retiredResponseAttempts++
			if retiredResponseAttempts == 1 {
				request, err := peerRequest(2)
				if err != nil {
					return err
				}
				runtime.enqueueAfter(time.Millisecond, request, net.UDPAddrFromAddrPort(retiredRemote.Addr), nil)
				return syscall.EHOSTUNREACH
			}
			return nil
		}
		if decoded.MessageType != probeMessageRequest {
			return nil
		}
		if remoteAddr == retiredRemote.Addr {
			retiredRequests++
			if retiredRequests == 1 {
				request, err := peerRequest(1)
				if err != nil {
					return err
				}
				runtime.enqueueAfter(time.Millisecond, request, net.UDPAddrFromAddrPort(retiredRemote.Addr), nil)
			}
			return nil
		}
		reachableRequests++
		if reachableRequests != probeRequestAttempts+1 {
			return nil
		}
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, decoded.ProbeID, reachableRemote, local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(reachableRemote.Addr), nil)
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(time.Second), key, upgradeRoleDial, []probeCandidatePair{
		{local: local, remote: retiredRemote},
		{local: local, remote: reachableRemote},
	}, 1)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if !result.succeeded || result.pair.remote != reachableRemote {
		t.Fatalf("probe result = %#v, want reachable pair on a later pass", result)
	}
	if retiredRequests != 1 {
		t.Fatalf("retired pair outbound requests = %d, want no readmission after response-write retirement", retiredRequests)
	}
	if retiredResponseAttempts != 2 {
		t.Fatalf("retired pair response attempts = %d, want continued inbound processing after retirement", retiredResponseAttempts)
	}
}

func TestProbePairsResponseWriteRetirementPreservesExistingProbeIDs(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	requests := 0
	responseWrites := 0
	var sentProbeID [probeIDBytes]byte
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok {
			return nil
		}
		switch decoded.MessageType {
		case probeMessageRequest:
			requests++
			sentProbeID = decoded.ProbeID
			var peerProbeID [probeIDBytes]byte
			peerProbeID[0] = 0x42
			peerRequest, err := encodeProbeDatagram(key, probeMessageRequest, probeDirectionListenerToDialer, peerProbeID, remote, local)
			if err != nil {
				return err
			}
			runtime.enqueueAfter(time.Millisecond, peerRequest, net.UDPAddrFromAddrPort(remote.Addr), nil)
		case probeMessageResponse:
			responseWrites++
			peerResponse, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, sentProbeID, remote, local)
			if err != nil {
				return err
			}
			runtime.enqueueAfter(time.Millisecond, peerResponse, net.UDPAddrFromAddrPort(remote.Addr), nil)
			return syscall.EHOSTUNREACH
		}
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(time.Second), key, upgradeRoleDial, []probeCandidatePair{{local: local, remote: remote}}, 1)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if !result.succeeded || result.pair.remote != remote {
		t.Fatalf("probe result = %#v, want retired pair authenticated by its existing probe ID", result)
	}
	if requests != 1 {
		t.Fatalf("retired pair requests = %d, want no outbound readmission", requests)
	}
	if responseWrites != 1 {
		t.Fatalf("recoverable response writes = %d, want one retirement trigger", responseWrites)
	}
}

func TestProbePairsWaitsReceiveCapableToDeadlineAfterAllPairsRetire(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	start := runtime.Now()
	deadline := start.Add(80 * time.Millisecond)
	requests := 0
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if ok && decoded.MessageType == probeMessageRequest {
			requests++
		}
		return syscall.EHOSTUNREACH
	}

	result, err := probePairs(context.Background(), runtime, deadline, key, upgradeRoleDial, []probeCandidatePair{{local: local, remote: remote}}, 1)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if result.succeeded {
		t.Fatalf("probe unexpectedly succeeded: %#v", result)
	}
	if runtime.Now() != deadline {
		t.Fatalf("runtime time = %s, want original attempt deadline %s", runtime.Now(), deadline)
	}
	if requests != 1 {
		t.Fatalf("retired pair requests = %d, want exactly one", requests)
	}
	maxReceives := int(deadline.Sub(start) / probeReadInterval)
	if runtime.receiveCalls == 0 || runtime.receiveCalls > maxReceives {
		t.Fatalf("receive calls after retirement = %d, want bounded receive processing in [1, %d]", runtime.receiveCalls, maxReceives)
	}
}

func TestProbePairsSelectsHigherPrioritySuccessOverEarlierLowerPriorityResponse(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	preferredRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	lowerRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10003")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	queued := make(map[netip.AddrPort]bool)
	runtime.onSend = func(packet []byte, addr net.Addr) error {
		remoteAddr, err := addrPortFromNetAddr(addr)
		if err != nil {
			return err
		}
		if queued[remoteAddr] {
			return nil
		}
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		queued[remoteAddr] = true
		remote := lowerRemote
		delay := time.Millisecond
		if remoteAddr == preferredRemote.Addr {
			remote = preferredRemote
			delay = 25 * time.Millisecond
		}
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, decoded.ProbeID, remote, local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(delay, response, net.UDPAddrFromAddrPort(remote.Addr), nil)
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(150*time.Millisecond), key, upgradeRoleDial, []probeCandidatePair{
		{local: local, remote: preferredRemote},
		{local: local, remote: lowerRemote},
	}, 2)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	if !result.succeeded {
		t.Fatal("probePairs did not return a successful pair")
	}
	if result.pair.remote != preferredRemote {
		t.Fatalf("probePairs selected remote = %#v, want preferred remote %#v", result.pair.remote, preferredRemote)
	}
}

func TestProbePairsReturnsFatalAndShortRequestWriteErrors(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	for _, wantErr := range []error{net.ErrClosed, io.ErrShortWrite} {
		t.Run(wantErr.Error(), func(t *testing.T) {
			runtime := newScriptedProbeRuntime(time.Unix(1, 0))
			runtime.onSend = func([]byte, net.Addr) error { return wantErr }
			result, err := probePairs(context.Background(), runtime, runtime.Now().Add(80*time.Millisecond), key, upgradeRoleDial, []probeCandidatePair{{local: local, remote: remote}}, 1)
			if !errors.Is(err, wantErr) {
				t.Fatalf("probePairs error = %v, want %v", err, wantErr)
			}
			if result.succeeded {
				t.Fatal("probePairs succeeded despite request write failure")
			}
		})
	}
}

func TestProbePairsReturnsFatalAndShortResponseWriteErrors(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	for _, wantErr := range []error{net.ErrClosed, io.ErrShortWrite} {
		t.Run(wantErr.Error(), func(t *testing.T) {
			runtime := newScriptedProbeRuntime(time.Unix(1, 0))
			responseQueued := false
			runtime.onSend = func(packet []byte, _ net.Addr) error {
				decoded, ok := decodeProbeDatagram(packet)
				if !ok {
					return nil
				}
				if decoded.MessageType == probeMessageResponse {
					return wantErr
				}
				if responseQueued {
					return nil
				}
				responseQueued = true
				request, err := encodeProbeDatagram(key, probeMessageRequest, probeDirectionListenerToDialer, decoded.ProbeID, remote, local)
				if err != nil {
					return err
				}
				runtime.enqueueAfter(time.Millisecond, request, net.UDPAddrFromAddrPort(remote.Addr), nil)
				return nil
			}
			result, err := probePairs(context.Background(), runtime, runtime.Now().Add(testRunnerSafeProbeTimeout), key, upgradeRoleDial, []probeCandidatePair{{local: local, remote: remote}}, 1)
			if !errors.Is(err, wantErr) {
				t.Fatalf("probePairs error = %v, want %v", err, wantErr)
			}
			if result.succeeded {
				t.Fatal("probePairs succeeded despite response write failure")
			}
		})
	}
}

func TestProbePairsReturnsNonTimeoutTemporaryReadError(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	runtime.onSend = func([]byte, net.Addr) error {
		runtime.enqueueAfter(time.Millisecond, nil, nil, errTemporaryProbeRead)
		return nil
	}

	result, err := probePairs(context.Background(), runtime, runtime.Now().Add(80*time.Millisecond), key, upgradeRoleDial, []probeCandidatePair{{local: local, remote: remote}}, 1)
	if !errors.Is(err, errTemporaryProbeRead) {
		t.Fatalf("probePairs error = %v, want %v", err, errTemporaryProbeRead)
	}
	if result.succeeded {
		t.Fatal("probePairs succeeded despite temporary non-timeout read error")
	}
}

func TestAdvanceProbeScheduleLazilyInitializesActivatedProbeState(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	firstRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	secondRemote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10003")}
	attempts := []probePairAttempt{
		{pair: probeCandidatePair{local: local, remote: firstRemote}},
		{pair: probeCandidatePair{local: local, remote: secondRemote}},
	}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	nextPair := 0

	_, _, _, err := advanceProbeSchedule(context.Background(), runtime, runtime.Now().Add(time.Hour), key, probeDirectionDialerToListener, attempts, 1, &nextPair, runtime.Now(), probeRetryDelay, v1ProbeWireParams())
	if err != nil {
		t.Fatalf("advanceProbeSchedule: %v", err)
	}
	if nextPair != 1 {
		t.Fatalf("nextPair = %d, want 1", nextPair)
	}
	if !attempts[0].inFlight || attempts[0].passAttempts != 1 {
		t.Fatalf("activated attempt state = inFlight %t passAttempts %d, want inFlight true passAttempts 1", attempts[0].inFlight, attempts[0].passAttempts)
	}
	if len(attempts[0].probeIDs) != 1 {
		t.Fatalf("activated probeIDs length = %d, want 1", len(attempts[0].probeIDs))
	}
	if attempts[1].probeIDs != nil {
		t.Fatalf("inactive attempt allocated probeIDs: %#v", attempts[1].probeIDs)
	}
	if attempts[1].passAttempts != 0 || attempts[1].inFlight {
		t.Fatalf("inactive attempt state = inFlight %t passAttempts %d, want untouched", attempts[1].inFlight, attempts[1].passAttempts)
	}
}

func TestHandleProbePacketMatchesPeerRequestForInactiveLazyAttempt(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	local := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	attempts := []probePairAttempt{{pair: probeCandidatePair{local: local, remote: remote}}}
	var probeID [probeIDBytes]byte
	probeID[0] = 0x42
	request, err := encodeProbeDatagram(key, probeMessageRequest, probeDirectionListenerToDialer, probeID, remote, local)
	if err != nil {
		t.Fatalf("encode peer request: %v", err)
	}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	responseWrites := 0
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if ok && decoded.MessageType == probeMessageResponse {
			responseWrites++
		}
		return nil
	}

	result, err := handleProbePacket(context.Background(), runtime, key, probeDirectionDialerToListener, probeDirectionListenerToDialer, attempts, request, remote.Addr, net.UDPAddrFromAddrPort(remote.Addr), v1ProbeWireParams())
	if err != nil {
		t.Fatalf("handleProbePacket: %v", err)
	}
	if result.succeeded {
		t.Fatal("peer request unexpectedly produced a selected pair")
	}
	if responseWrites != 1 {
		t.Fatalf("response writes = %d, want 1", responseWrites)
	}
	if attempts[0].probeIDs != nil {
		t.Fatalf("peer-request response allocated outbound probeIDs: %#v", attempts[0].probeIDs)
	}
}

func TestHandleProbePacketDisambiguatesSharedRemoteByLazyPeerToken(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	firstLocal := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	secondLocal := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	remote := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:20000")}
	var probeID [probeIDBytes]byte
	probeID[0] = 0x99
	sentAt := time.Now().Add(-time.Millisecond)
	attempts := []probePairAttempt{
		{
			pair:          probeCandidatePair{local: firstLocal, remote: remote},
			passExhausted: true,
			probeIDs:      map[[probeIDBytes]byte]time.Time{probeID: sentAt},
		},
		{
			pair:     probeCandidatePair{local: secondLocal, remote: remote},
			inFlight: true,
			probeIDs: map[[probeIDBytes]byte]time.Time{probeID: sentAt},
		},
	}
	response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, probeID, remote, secondLocal)
	if err != nil {
		t.Fatalf("encode peer response: %v", err)
	}
	runtime := newScriptedProbeRuntime(time.Now())

	result, err := handleProbePacket(context.Background(), runtime, key, probeDirectionDialerToListener, probeDirectionListenerToDialer, attempts, response, remote.Addr, net.UDPAddrFromAddrPort(remote.Addr), v1ProbeWireParams())
	if err != nil {
		t.Fatalf("handleProbePacket: %v", err)
	}
	if attempts[0].succeeded {
		t.Fatal("first attempt with shared remote unexpectedly succeeded")
	}
	if !attempts[1].succeeded {
		t.Fatal("second attempt did not accept matching response")
	}
	if !result.succeeded {
		t.Fatal("handleProbePacket did not return the ready shared-remote pair")
	}
	if result.pair.local != secondLocal || result.pair.remote != remote {
		t.Fatalf("result pair = %#v, want local %#v remote %#v", result.pair, secondLocal, remote)
	}
	if result.rtt <= 0 {
		t.Fatalf("result RTT = %s, want positive", result.rtt)
	}
}

func BenchmarkProbePairAttemptMaterializationLargeCandidateSet(b *testing.B) {
	key := mustHex(b, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	pairs := largeProbeCandidatePairSet(64, 64)
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))

	b.ReportAllocs()
	for i := range b.N {
		attempts := newProbePairAttempts(pairs)
		nextPair := 0
		if _, _, _, err := advanceProbeSchedule(context.Background(), runtime, runtime.Now().Add(time.Hour), key, probeDirectionDialerToListener, attempts, 4, &nextPair, time.Unix(1, int64(i)), probeRetryDelay, v1ProbeWireParams()); err != nil {
			b.Fatalf("advanceProbeSchedule: %v", err)
		}
	}
}

var errTemporaryProbeRead = errors.New("temporary probe read error")

type logicalProbeRuntime struct {
	now       time.Time
	sendCalls int
	released  bool
}

func (r *logicalProbeRuntime) Now() time.Time {
	return r.now
}

func (r *logicalProbeRuntime) Send(ctx context.Context, _ []byte, _ net.Addr) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	r.sendCalls++
	return nil
}

func (r *logicalProbeRuntime) Receive(ctx context.Context, _ []byte, deadline time.Time) (int, net.Addr, bool, error) {
	if err := ctx.Err(); err != nil {
		return 0, nil, false, err
	}
	r.now = deadline
	return 0, nil, true, nil
}

func (r *logicalProbeRuntime) Release() {
	r.released = true
}

type advancingProbeKeyExporter struct {
	exporter KeyExporter
	runtime  *scriptedProbeRuntime
	advance  time.Duration
}

func (e *advancingProbeKeyExporter) Derive(label string, context []byte, length int) ([]byte, error) {
	e.runtime.now = e.runtime.now.Add(e.advance)
	return e.exporter.Derive(label, context, length)
}

type scriptedProbeRuntime struct {
	now            time.Time
	onSend         func([]byte, net.Addr) error
	events         []scriptedProbeEvent
	receiveCalls   int
	blockReceive   bool
	blockWhenEmpty bool
	receiveStarted chan struct{}
	startOnce      sync.Once
	releaseOnce    sync.Once
	releaseDone    chan struct{}
	mu             sync.Mutex
	released       bool
}

type scriptedProbeEvent struct {
	at     time.Time
	packet []byte
	addr   net.Addr
	err    error
}

func newScriptedProbeRuntime(now time.Time) *scriptedProbeRuntime {
	return &scriptedProbeRuntime{
		now:            now,
		receiveStarted: make(chan struct{}),
		releaseDone:    make(chan struct{}),
	}
}

func (r *scriptedProbeRuntime) Now() time.Time {
	return r.now
}

func (r *scriptedProbeRuntime) Send(ctx context.Context, packet []byte, addr net.Addr) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if r.onSend == nil {
		return nil
	}
	return r.onSend(append([]byte(nil), packet...), addr)
}

func (r *scriptedProbeRuntime) Receive(ctx context.Context, packet []byte, deadline time.Time) (int, net.Addr, bool, error) {
	if err := ctx.Err(); err != nil {
		return 0, nil, false, err
	}
	r.receiveCalls++
	if r.blockReceive {
		r.startOnce.Do(func() { close(r.receiveStarted) })
		<-ctx.Done()
		return 0, nil, false, ctx.Err()
	}
	eventIndex := -1
	for i := range r.events {
		if r.events[i].at.After(deadline) {
			continue
		}
		if eventIndex == -1 || r.events[i].at.Before(r.events[eventIndex].at) {
			eventIndex = i
		}
	}
	if eventIndex == -1 {
		if r.blockWhenEmpty {
			r.startOnce.Do(func() { close(r.receiveStarted) })
			<-ctx.Done()
			return 0, nil, false, ctx.Err()
		}
		r.now = deadline
		return 0, nil, true, nil
	}
	event := r.events[eventIndex]
	r.events = append(r.events[:eventIndex], r.events[eventIndex+1:]...)
	r.now = event.at
	return copy(packet, event.packet), event.addr, false, event.err
}

func (r *scriptedProbeRuntime) Release() {
	r.releaseOnce.Do(func() {
		r.mu.Lock()
		r.released = true
		r.mu.Unlock()
		close(r.releaseDone)
	})
}

func (r *scriptedProbeRuntime) isReleased() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.released
}

func (r *scriptedProbeRuntime) enqueueAfter(delay time.Duration, packet []byte, addr net.Addr, err error) {
	r.events = append(r.events, scriptedProbeEvent{
		at:     r.now.Add(delay),
		packet: append([]byte(nil), packet...),
		addr:   addr,
		err:    err,
	})
}

func largeProbeCandidatePairSet(localCount, remoteCount int) []probeCandidatePair {
	locals := make([]Candidate, localCount)
	for i := range locals {
		locals[i] = benchmarkHostCandidate([3]byte{10, 0, 0}, i, 10000)
	}
	remotes := make([]Candidate, remoteCount)
	for i := range remotes {
		remotes[i] = benchmarkHostCandidate([3]byte{192, 0, 2}, i, 20000)
	}

	pairs := make([]probeCandidatePair, 0, len(locals)*len(remotes))
	for _, local := range locals {
		for _, remote := range remotes {
			pairs = append(pairs, probeCandidatePair{local: local, remote: remote})
		}
	}
	return pairs
}

func benchmarkHostCandidate(prefix [3]byte, index int, basePort int) Candidate {
	return Candidate{
		Kind: CandidateKindHost,
		Addr: netip.AddrPortFrom(
			netip.AddrFrom4([4]byte{prefix[0], prefix[1], prefix[2], benchmarkHostOctet(index + 1)}),
			benchmarkHostPort(basePort+index),
		),
	}
}

func benchmarkHostOctet(n int) byte {
	if n < 0 || n > 255 {
		panic("benchmark host octet out of range")
	}
	return byte(n) // #nosec G115 -- benchmark helper bounds n to one IPv4 octet.
}

func benchmarkHostPort(n int) uint16 {
	if n < 0 || n > 1<<16-1 {
		panic("benchmark host port out of range")
	}
	return uint16(n) // #nosec G115 -- benchmark helper bounds n to one TCP/UDP port.
}
