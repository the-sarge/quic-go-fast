package connect

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net"
	"net/netip"
	"slices"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestDrainPacketConnReturnsImmediatelyWhenIdle(t *testing.T) {
	conn := listenPacket(t, "127.0.0.1:0")
	defer conn.Close()

	done := make(chan struct{})
	go func() {
		drainPacketConn(context.Background(), conn)
		close(done)
	}()
	select {
	case <-done:
	case <-time.After(200 * time.Millisecond):
		t.Fatal("idle drain did not return promptly")
	}
}

func TestDrainPacketConnReturnsUnderSustainedInput(t *testing.T) {
	conn := &sustainedInputPacketConn{}
	done := make(chan struct{})
	go func() {
		drainPacketConn(context.Background(), conn)
		close(done)
	}()

	select {
	case <-done:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("sustained drain did not return within diagnostic watchdog")
	}
	if conn.reads > upgradePacketDrainMaxPackets {
		t.Fatalf("sustained drain reads = %d, want at most %d", conn.reads, upgradePacketDrainMaxPackets)
	}
	if !conn.readDeadlineCleared {
		t.Fatal("sustained drain did not clear the read deadline")
	}
}

func TestDrainPacketConnHonorsElapsedDeadlineBeforeReading(t *testing.T) {
	conn := &sustainedInputPacketConn{}
	ctx := elapsedDeadlineContext{
		Context:  context.Background(),
		deadline: time.Unix(1, 0),
	}

	drainPacketConn(ctx, conn)

	if conn.reads != 0 {
		t.Fatalf("elapsed-deadline drain reads = %d, want 0", conn.reads)
	}
	if !conn.readDeadlineCleared {
		t.Fatal("elapsed-deadline drain did not clear the read deadline")
	}
}

func TestDrainPacketConnStopsAtInternalElapsedCapAfterReading(t *testing.T) {
	conn := &sustainedInputPacketConn{}
	startedAt := time.Unix(1, 0)
	clockReads := 0
	now := func() time.Time {
		clockReads++
		if clockReads < 3 {
			return startedAt
		}
		return startedAt.Add(upgradePacketDrainMaxElapsed)
	}

	drainPacketConnWithNow(context.Background(), conn, now)

	if conn.reads != 1 {
		t.Fatalf("internally capped drain reads = %d, want 1", conn.reads)
	}
	if !conn.readDeadlineCleared {
		t.Fatal("internally capped drain did not clear the read deadline")
	}
}

func TestDrainPacketConnConsumesQueuedDatagrams(t *testing.T) {
	conn := &queuedInputPacketConn{packets: [][]byte{
		[]byte("probe-1"),
		[]byte("probe-2"),
		[]byte("probe-3"),
	}}

	drainPacketConn(context.Background(), conn)

	if len(conn.packets) != 0 {
		t.Fatalf("queued datagrams remaining = %d, want 0", len(conn.packets))
	}
	if conn.reads != 4 {
		t.Fatalf("queued drain reads = %d, want 3 datagrams plus terminal timeout", conn.reads)
	}
	if !conn.readDeadlineCleared {
		t.Fatal("queued drain did not clear the read deadline")
	}
}

func TestProbeRuntimeReleasePrecedesDrainAndTransportDial(t *testing.T) {
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	packetConn := &runtimeProviderPacketConn{runtime: runtime, local: dialerCandidate.Addr}
	packetConn.onRawAccess = func() {
		if !runtime.isReleased() {
			packetConn.rawAccessBeforeRelease.Store(true)
		}
	}
	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	controlReadRelease := make(chan struct{})
	var controlReadReleaseOnce sync.Once
	releaseControlRead := func() { controlReadReleaseOnce.Do(func() { close(controlReadRelease) }) }
	defer releaseControlRead()
	controlFrames := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		<-controlReadRelease
		return controlFrameReadResult{err: context.Canceled}
	})
	preloadControlFrameSequencer(controlFrames, controlFrameReadResult{payload: readyFrame[4:]})
	channel := &terminalTestChannel{}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		auth:          testAuthContext(),
		channel:       channel,
		controlFrames: controlFrames,
		cfg: upgradeConfig{
			packetConn:       packetConn,
			controlTimeout:   testCausalObservationTimeout,
			probeConcurrency: 1,
			probeTimeout:     100 * time.Millisecond,
		},
	})
	offer := localUpgradeOffer{
		role:       upgradeRoleDial,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
	}
	peer := localUpgradeOffer{
		probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes),
	}
	pairPlan := candidatePairPlan{pairs: []probeCandidatePair{{local: dialerCandidate, remote: listenerCandidate}}}

	result, err := attempt.probeCandidatePairPlan(context.Background(), offer, peer, pairPlan)
	if err != nil {
		t.Fatalf("probeCandidatePairPlan: %v", err)
	}
	if result.succeeded {
		t.Fatal("probe unexpectedly succeeded without a scripted response")
	}
	if !runtime.isReleased() {
		t.Fatal("probe runtime was not released before probeCandidatePairPlan returned")
	}

	wantDialErr := errors.New("dial stage observed")
	observed := make(chan error, 1)
	session := &scriptedSession{
		dial: func(_ context.Context, conn net.PacketConn, _ net.Addr, _ []byte) (io.ReadWriteCloser, error) {
			observedErr := wantDialErr
			switch {
			case conn != packetConn:
				observedErr = errors.New("transport Dial received a different packet connection")
			case !runtime.isReleased():
				observedErr = errors.New("transport Dial overlapped probe runtime ownership")
			case !packetConn.drainComplete.Load():
				observedErr = errors.New("transport Dial started before raw packet drain completed")
			}
			observed <- observedErr
			return nil, observedErr
		},
	}
	engineCtx, cancelEngine := context.WithCancel(context.Background())
	engineDone := make(chan error, 1)
	var observedRowsMu sync.Mutex
	var observedRows []directUpgradeDialerRow
	engine := newDialerDirectUpgradeProtocolEngine(
		attempt,
		session,
		localUpgradeOffer{handshakeMaterial: []byte("fake-handshake-material")},
		candidatePairProbeResult{
			succeeded: true,
			pair:      pairPlan.pairs[0],
		},
	)
	engine.testDialerTrace = func(row directUpgradeDialerRow) {
		observedRowsMu.Lock()
		observedRows = append(observedRows, row)
		observedRowsMu.Unlock()
	}
	go func() {
		_, engineErr := engine.runDialer(engineCtx, engineCtx)
		engineDone <- engineErr
	}()
	var observedDialErr error
	select {
	case observedDialErr = <-observed:
	case engineErr := <-engineDone:
		observedRowsMu.Lock()
		rows := append([]directUpgradeDialerRow(nil), observedRows...)
		observedRowsMu.Unlock()
		t.Fatalf("dialer engine returned before transport Dial: %v; rows %v", engineErr, rows)
	}
	releaseControlRead()
	cancelEngine()
	select {
	case <-engineDone:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("dialer engine did not stop after stage observation")
	}
	if !errors.Is(observedDialErr, wantDialErr) {
		t.Fatalf("transport Dial boundary error = %v, want %v", observedDialErr, wantDialErr)
	}
	if packetConn.rawAccessBeforeRelease.Load() {
		t.Fatal("raw packet drain overlapped probe runtime ownership")
	}
	if !packetConn.drainComplete.Load() {
		t.Fatal("raw packet drain did not clear its deadline before transport Dial")
	}
}

func runDialerEngineForTest(
	ctx context.Context,
	handoffCtx context.Context,
	attempt directUpgradeAttempt,
	session Session,
	peer localUpgradeOffer,
	probeResult candidatePairProbeResult,
) (UpgradeResult, error) {
	return newDialerDirectUpgradeProtocolEngine(attempt, session, peer, probeResult).runDialer(ctx, handoffCtx)
}

func TestDialerEngineRejectsAcceptedPhaseFallbackAfterCommit(t *testing.T) {
	packetConn := &closeTrackingPacketConn{PacketConn: listenPacket(t, "127.0.0.1:0")}
	defer packetConn.Close()
	pipe1, pipe2 := net.Pipe()
	defer pipe2.Close()

	stream := &closeTrackingStream{ReadWriteCloser: pipe1}
	session := &scriptedSession{
		dial: func(_ context.Context, conn net.PacketConn, _ net.Addr, _ []byte) (io.ReadWriteCloser, error) {
			return newTestPacketOwningStream(stream, conn), nil
		},
	}
	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	acceptedFallback, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("encode accepted fallback: %v", err)
	}
	channel := newWriteTriggeredControlChannel(acceptedFallback, 2)
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:41000")}
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:41001")}
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newPrefixedControlFrameSequencer(channel, controlFrameReadResult{payload: readyFrame[4:]}),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			controlTimeout: time.Second,
			probeTimeout:   time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)

	result, err := runDialerEngineForTest(
		context.Background(),
		context.Background(),
		attempt,
		session,
		localUpgradeOffer{handshakeMaterial: []byte("fake-handshake-material")},
		candidatePairProbeResult{
			pair: probeCandidatePair{
				local:  dialerCandidate,
				remote: listenerCandidate,
			},
		},
	)
	if !errors.Is(err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("dialer engine error = %v, want post-commit convergence failure", err)
	}
	if result.Stream != nil {
		t.Fatal("accepted-phase fallback returned a stream")
	}
	if result.Path == UpgradePathRelay {
		t.Fatal("accepted-phase fallback returned relay path after commit")
	}
	if !stream.closed.Load() {
		t.Fatal("direct stream was not closed after accepted-phase fallback")
	}
	if !packetConn.closed.Load() {
		t.Fatal("packet conn was not closed after accepted-phase fallback")
	}
	if !session.wasClosed() {
		t.Fatal("session was not closed after accepted-phase fallback")
	}
	if !channel.closed.Load() {
		t.Fatal("relay channel was not closed after accepted-phase fallback")
	}
}

func TestNegotiatorUpgradeDialerEngineHappyPath(t *testing.T) {
	packetConn := listenPacket(t, "127.0.0.1:0")
	defer packetConn.Close()
	directLocal, directPeer := net.Pipe()
	defer directPeer.Close()
	controlLocal, controlPeer := net.Pipe()
	defer controlPeer.Close()

	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	dialStarted := make(chan struct{}, 1)
	releaseDial := make(chan struct{})
	var releaseDialOnce sync.Once
	releaseTransportDial := func() { releaseDialOnce.Do(func() { close(releaseDial) }) }
	peerDone := make(chan error, 1)
	go func() {
		defer releaseTransportDial()
		selectedPayload, err := readUpgradeControlFrame(controlPeer)
		if err != nil {
			peerDone <- err
			return
		}
		selected, _ := decodeUpgradeControlSelectedPairPhasePayload(selectedPayload)
		if !selected.HasSelectedPair {
			peerDone <- errors.New("peer did not receive selected pair")
			return
		}
		commitPayload, err := readUpgradeControlFrame(controlPeer)
		if err != nil {
			peerDone <- err
			return
		}
		if commit, _ := decodeUpgradeControlPhasePayload(commitPayload, upgradeControlPhaseCommit); !commit.Is(upgradeControlPhaseCommit) {
			peerDone <- errors.New("peer did not receive commit")
			return
		}
		select {
		case <-dialStarted:
		case <-time.After(testCausalObservationTimeout):
			peerDone <- errors.New("transport Dial did not start")
			return
		}
		acceptedFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseAccepted)
		if err != nil {
			peerDone <- err
			return
		}
		if err := controlPeer.SetWriteDeadline(time.Now().Add(testCausalObservationTimeout)); err != nil {
			peerDone <- err
			return
		}
		if err := writeFull(controlPeer, acceptedFrame); err != nil {
			peerDone <- err
			return
		}
		// net.Pipe completes this write only after the dialer has read accepted,
		// proving the control plane progressed while transport Dial was blocked.
		releaseTransportDial()
		if err := controlPeer.SetWriteDeadline(time.Time{}); err != nil {
			peerDone <- err
			return
		}
		convergedPayload, err := readUpgradeControlFrame(controlPeer)
		if err != nil {
			peerDone <- err
			return
		}
		if converged, _ := decodeUpgradeControlPhasePayload(convergedPayload, upgradeControlPhaseConverged); !converged.Is(upgradeControlPhaseConverged) {
			peerDone <- errors.New("peer did not receive converged")
			return
		}
		confirmedFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseConfirmed)
		if err != nil {
			peerDone <- err
			return
		}
		if err := writeFull(controlPeer, confirmedFrame); err != nil {
			peerDone <- err
			return
		}
		peerDone <- nil
	}()

	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:41000")}
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:41001")}
	attempt := directUpgradeAttempt{
		channel:       controlLocal,
		controlFrames: newPrefixedControlFrameSequencer(controlLocal, controlFrameReadResult{payload: readyFrame[4:]}),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			controlTimeout: testRunnerSafeProbeTimeout,
			probeTimeout:   testCausalObservationTimeout,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	session := &scriptedSession{
		dial: func(ctx context.Context, conn net.PacketConn, _ net.Addr, _ []byte) (io.ReadWriteCloser, error) {
			signal(dialStarted)
			select {
			case <-releaseDial:
				return newTestPacketOwningStream(directLocal, conn), nil
			case <-ctx.Done():
				return nil, ctx.Err()
			}
		},
	}

	engine := newDialerDirectUpgradeProtocolEngine(
		attempt,
		session,
		localUpgradeOffer{handshakeMaterial: []byte("fake-handshake-material")},
		candidatePairProbeResult{
			pair: probeCandidatePair{
				local:  dialerCandidate,
				remote: listenerCandidate,
			},
		},
	)
	result, err := engine.runDialer(context.Background(), context.Background())
	if err != nil {
		t.Fatalf("dialer engine error = %v, want direct success", err)
	}
	if result.Stream == nil {
		t.Fatal("dialer engine stream = nil, want direct stream")
	}
	if result.Path != UpgradePathDirect {
		t.Fatalf("dialer engine path = %q, want direct", result.Path)
	}
	select {
	case err := <-peerDone:
		if err != nil {
			t.Fatalf("peer control exchange: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("peer control exchange did not complete")
	}
	_ = result.Stream.Close()
}

func TestDialerEngineRequiresConfirmedFrame(t *testing.T) {
	packetConn := listenPacket(t, "127.0.0.1:0")
	defer packetConn.Close()
	pipe1, pipe2 := net.Pipe()
	defer pipe2.Close()

	stream := &closeTrackingStream{ReadWriteCloser: pipe1}
	session := &scriptedSession{
		dial: func(_ context.Context, conn net.PacketConn, _ net.Addr, _ []byte) (io.ReadWriteCloser, error) {
			return newTestPacketOwningStream(stream, conn), nil
		},
	}
	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	acceptedFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseAccepted)
	if err != nil {
		t.Fatalf("encode accepted: %v", err)
	}
	channel := newWriteTriggeredControlChannel(acceptedFrame, 2)
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:41000")}
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:41001")}
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newPrefixedControlFrameSequencer(channel, controlFrameReadResult{payload: readyFrame[4:]}),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			controlTimeout: time.Second,
			probeTimeout:   time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)

	result, err := runDialerEngineForTest(
		context.Background(),
		context.Background(),
		attempt,
		session,
		localUpgradeOffer{handshakeMaterial: []byte("fake-handshake-material")},
		candidatePairProbeResult{
			pair: probeCandidatePair{
				local:  dialerCandidate,
				remote: listenerCandidate,
			},
		},
	)
	if !errors.Is(err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("dialer engine error = %v, want post-commit convergence failure", err)
	}
	if result.Stream != nil {
		t.Fatal("missing confirmed frame returned a stream")
	}
	if result.Path == UpgradePathRelay {
		t.Fatal("missing confirmed frame returned relay path after commit")
	}
	if !stream.closed.Load() {
		t.Fatal("direct stream was not closed after missing confirmed frame")
	}
	if !session.wasClosed() {
		t.Fatal("session was not closed after missing confirmed frame")
	}
	if !channel.closed.Load() {
		t.Fatal("relay channel was not closed after missing confirmed frame")
	}
}

func TestReadyTimeoutFallbackSkipsLateReadyFrame(t *testing.T) {
	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	peerFallback, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	channel := newWriteTriggeredControlChannel(peerFallback, 1)
	session := &directHandoffSession{}
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newPrefixedControlFrameSequencer(channel, controlFrameReadResult{payload: readyFrame[4:]}),
		cfg: upgradeConfig{
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)

	result, err := newTerminalFallbackExchange(attempt).withSessionCleanupSkippingReady(
		context.Background(),
		session,
		UpgradeFallbackTransportFailed,
	)
	if err != nil {
		t.Fatalf("terminal fallback after late ready error = %v, want nil", err)
	}
	if result.Stream != channel {
		t.Fatalf("terminal fallback stream = %T, want relay channel", result.Stream)
	}
	if result.Path != UpgradePathRelay {
		t.Fatalf("terminal fallback path = %q, want relay", result.Path)
	}
	if result.FallbackReason != UpgradeFallbackTransportFailed {
		t.Fatalf("terminal fallback reason = %q, want transport_failed", result.FallbackReason)
	}
	if !session.closed {
		t.Fatal("session was not closed after terminal fallback")
	}
}

// newHeldSelectedControlChannel parks the first control read until release,
// then delivers exactly one frame, and parks every later read until Close.
// The post-frame park matters: a ready EOF would race the transport start
// the frame triggers, and a fixture must not decide that race.
func newHeldSelectedControlChannel(frame []byte, release <-chan struct{}) *scriptedControlChannel {
	channel := newScriptedControlChannel(frame, false)
	channel.readStarted = make(chan struct{})
	channel.readScript = func(p []byte) (int, error) {
		select {
		case <-release:
		case <-channel.closedCh:
			return 0, io.ErrClosedPipe
		}
		channel.mu.Lock()
		if channel.read.Len() > 0 {
			n, err := channel.read.Read(p)
			channel.mu.Unlock()
			return n, err
		}
		channel.mu.Unlock()
		<-channel.closedCh
		return 0, io.ErrClosedPipe
	}
	channel.writeScript = func(p []byte) (int, error) { return len(p), nil }
	return channel
}

// listenBudgetSnapshot is the state of the Listen context observed inside
// Listen, before the owning operation cancels it on return.
type listenBudgetSnapshot struct {
	err         error
	deadline    time.Time
	hasDeadline bool
	observedAt  time.Time
}

func TestListenerHeldSuccessHandoffBudgetBeginsAtSelectedArrival(t *testing.T) {
	// A bilateral held-success listener holds for the dialer's frame under
	// the control timeout; when Selected arrives after the probe timeout has
	// already elapsed, the transport handoff must still receive its full
	// probe-timeout budget rather than a budget derived at hold entry.
	packetConn := listenPacket(t, "127.0.0.1:0")
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:47401")}
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:47402")}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selectedPair{dialer: dialerCandidate, listener: listenerCandidate})
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}
	const handoffBudget = 50 * time.Millisecond
	release := make(chan struct{})
	channel := newHeldSelectedControlChannel(selectedFrame, release)
	t.Cleanup(func() { _ = channel.Close() })
	listenCtx := make(chan listenBudgetSnapshot, 1)
	session := &scriptedSession{listen: func(ctx context.Context, _ net.PacketConn, _ net.Addr, _ []byte) (TransportListener, error) {
		deadline, ok := ctx.Deadline()
		listenCtx <- listenBudgetSnapshot{err: ctx.Err(), deadline: deadline, hasDeadline: ok, observedAt: time.Now()}
		return nil, errors.New("listen budget probe")
	}}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			probeTimeout:   handoffBudget,
			controlTimeout: 2 * time.Second,
		},
	})
	engine := newListenerDirectUpgradeProtocolEngine(attempt, session, localUpgradeOffer{handshakeMaterial: []byte("peer")}, testListenerCandidatePairPlan(listenerCandidate, dialerCandidate), 0)
	engine.turnRetryStart = func(context.Context) (UpgradeResult, error) {
		return UpgradeResult{}, errors.New("unexpected retry entry")
	}

	done := make(chan error, 1)
	go func() {
		_, err := engine.runHeldSuccessListener(context.Background(), handoffBudget)
		done <- err
	}()
	select {
	case <-channel.readStarted:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("held-success listener did not start awaiting the dialer's frame")
	}
	// Let more than the whole handoff budget elapse during the hold before
	// Selected arrives.
	time.Sleep(3 * handoffBudget)
	releasedAt := time.Now()
	close(release)

	var listen listenBudgetSnapshot
	select {
	case listen = <-listenCtx:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("Selected after the probe timeout did not start the transport listen")
	}
	if listen.err != nil {
		t.Fatalf("listen context already done at Listen: %v; want a fresh handoff budget", listen.err)
	}
	if !listen.hasDeadline {
		t.Fatal("listen context has no deadline; want the probe-timeout handoff budget")
	}
	if remaining := listen.deadline.Sub(listen.observedAt); remaining <= 0 || remaining > handoffBudget {
		t.Fatalf("listen budget remaining at Listen = %s, want within (0, %s]", remaining, handoffBudget)
	}
	if listen.deadline.Before(releasedAt) {
		t.Fatalf("listen deadline %s precedes Selected arrival %s", listen.deadline, releasedAt)
	}
	// The failed transport start coordinates fallback over the parked
	// control channel; closing it releases the listener.
	_ = channel.Close()
	select {
	case <-done:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("listener did not finish after the failed transport listen")
	}
}

func TestNegotiatorUpgradeAcceptedCancelRaceFailsClosed(t *testing.T) {
	packetConn := &closeTrackingPacketConn{PacketConn: listenPacket(t, "127.0.0.1:0")}
	t.Cleanup(func() {
		if !packetConn.closed.Load() {
			_ = packetConn.Close()
		}
	})

	acceptedPipe, peerPipe := net.Pipe()
	defer peerPipe.Close()

	acceptedStream := &closeTrackingStream{ReadWriteCloser: acceptedPipe}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:47301")}
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:47302")}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selectedPair{dialer: dialerCandidate, listener: listenerCandidate})
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}
	ctx, cancelCtx := context.WithCancel(context.Background())
	listener := newTerminalTestAcceptListener(nil, newTestPacketOwningStream(acceptedStream, packetConn), nil)
	session := &terminalTestSession{listenListener: listener}
	writeObserved := make(chan struct{}, 1)
	channel := newObservedWriteControlChannel(writeObserved, selectedFrame, true)
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			probeTimeout:   time.Second,
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	var rows []directUpgradeListenerRow
	engine := newListenerDirectUpgradeProtocolEngine(attempt, session, localUpgradeOffer{handshakeMaterial: []byte("peer")}, testListenerCandidatePairPlan(listenerCandidate, dialerCandidate), 0)
	engine.testListenerTrace = func(row directUpgradeListenerRow) { rows = append(rows, row) }
	done := make(chan upgradeTestOutcome, 1)
	go func() {
		result, err := engine.runListener(ctx, ctx)
		done <- upgradeTestOutcome{result: result, err: err}
	}()
	select {
	case <-writeObserved:
	case <-time.After(time.Second):
		t.Fatal("listener did not publish Ready")
	}
	gate := make(chan struct{})
	go func() {
		<-gate
		cancelCtx()
	}()
	go func() {
		<-gate
		listener.releaseOnce.Do(func() { close(listener.releaseAccept) })
	}()
	close(gate)
	outcome := <-done
	result, err := outcome.result, outcome.err
	if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, context.Canceled) {
		t.Fatalf("caller cancel with accepted stream error = %v, want transport-not-converged with context canceled", err)
	}
	if result.Stream != nil {
		t.Fatal("caller cancel with accepted stream returned a stream")
	}
	if result.Path == UpgradePathRelay {
		t.Fatal("caller cancel with accepted stream returned relay path")
	}
	if !acceptedStream.closed.Load() {
		t.Fatal("accepted stream was not closed after caller cancel")
	}
	if got := listener.closeCalls.Load(); got != 1 {
		t.Fatalf("Listener.Close calls = %d, want 1", got)
	}
	if got := session.closeCalls.Load(); got != 1 {
		t.Fatalf("Session.Close calls = %d, want 1", got)
	}
	if !packetConn.closed.Load() {
		t.Fatal("packet conn was not closed after caller cancel")
	}
	if got := packetConn.closes.Load(); got != 1 {
		t.Fatalf("exact packet Close calls = %d, want 1", got)
	}
	if channel.closeCalls.Load() != 1 {
		t.Fatal("relay channel was not closed after caller cancel")
	}
	terminal := rows[len(rows)-1]
	if terminal != directUpgradeListenerRowL15S && terminal != directUpgradeListenerRowL21 && terminal != directUpgradeListenerRowL23S && terminal != directUpgradeListenerRowL28 {
		t.Fatalf("terminal row = %s, want accepted/cancel race row L15-S, L21, L23-S, or L28; all rows %v", terminal, rows)
	}
}

func TestNegotiatorUpgradeAcceptedControlErrorRaceFailsClosed(t *testing.T) {
	packetConn := &closeTrackingPacketConn{PacketConn: listenPacket(t, "127.0.0.1:0")}
	t.Cleanup(func() {
		if !packetConn.closed.Load() {
			_ = packetConn.Close()
		}
	})

	acceptedPipe, peerPipe := net.Pipe()
	defer peerPipe.Close()

	acceptedStream := &closeTrackingStream{ReadWriteCloser: acceptedPipe}
	controlErr := errors.New("commit read failed")
	acceptSelected := make(chan struct{})
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:47401")}
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:47402")}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selectedPair{dialer: dialerCandidate, listener: listenerCandidate})
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}
	listener := &acceptSelectionListener{
		directHandoffListener: &directHandoffListener{stream: acceptedStream, packetConn: packetConn},
		selected:              acceptSelected,
	}
	session := &terminalTestSession{listenListener: listener}
	channel := &terminalTestChannel{}
	controlFrames := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		<-acceptSelected
		return controlFrameReadResult{err: controlErr}
	})
	preloadControlFrameSequencer(controlFrames, controlFrameReadResult{payload: selectedFrame[4:]})
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: controlFrames,
		cfg: upgradeConfig{
			packetConn:     packetConn,
			probeTimeout:   time.Second,
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	var rows []directUpgradeListenerRow
	engine := newListenerDirectUpgradeProtocolEngine(attempt, session, localUpgradeOffer{handshakeMaterial: []byte("peer")}, testListenerCandidatePairPlan(listenerCandidate, dialerCandidate), 0)
	engine.testListenerTrace = func(row directUpgradeListenerRow) { rows = append(rows, row) }
	result, err := engine.runListener(context.Background(), context.Background())
	if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, controlErr) {
		t.Fatalf("control error with accepted stream = %v, want transport-not-converged with %v", err, controlErr)
	}
	if result != (UpgradeResult{}) {
		t.Fatalf("control error with accepted stream result = %+v, want zero", result)
	}
	if !acceptedStream.closed.Load() {
		t.Fatal("accepted stream was not closed after commit-read control error")
	}
	if !listener.closed {
		t.Fatal("listener was not closed after commit-read control error")
	}
	if got := session.closeCalls.Load(); got != 1 {
		t.Fatalf("Session.Close calls = %d, want 1", got)
	}
	if got := packetConn.closes.Load(); got != 1 {
		t.Fatalf("exact packet Close calls = %d, want 1", got)
	}
	if channel.closeCalls.Load() != 1 {
		t.Fatal("relay channel was not closed after commit-read control error")
	}
	if !slices.Contains(rows, directUpgradeListenerRowL11) || rows[len(rows)-1] != directUpgradeListenerRowL25 {
		t.Fatalf("rows = %v, want L11 Accept selection followed by L25 control failure", rows)
	}
}

type acceptSelectionListener struct {
	*directHandoffListener
	selected chan struct{}
	once     sync.Once
}

func (l *acceptSelectionListener) ListenerAcceptSelectedForTest() {
	l.once.Do(func() { close(l.selected) })
}

func TestNegotiatorUpgradePostCommitAcceptHonorsHandoffTimeout(t *testing.T) {
	aliceRaw, bobRaw := net.Pipe()
	commitFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseCommit)
	if err != nil {
		t.Fatalf("encode commit: %v", err)
	}
	commitWritten := make(chan struct{})
	var commitWrittenOnce sync.Once
	commitWriteReturned := make(chan struct{})
	releaseCommitObservation := make(chan struct{})
	var releaseCommitObservationOnce sync.Once
	releaseCommitObservationGate := func() {
		releaseCommitObservationOnce.Do(func() { close(releaseCommitObservation) })
	}
	t.Cleanup(releaseCommitObservationGate)
	acceptedWaitStarted := make(chan struct{})
	var acceptedWaitStartedOnce sync.Once
	var phaseSequence atomic.Uint64
	var commitObservedAt atomic.Uint64
	var acceptedWaitObservedAt atomic.Uint64
	aliceRelay := &observeCommitChannel{
		ReadWriteCloser:      aliceRaw,
		trigger:              commitFrame,
		commitWritten:        commitWritten,
		commitOnce:           &commitWrittenOnce,
		waitStarted:          acceptedWaitStarted,
		waitOnce:             &acceptedWaitStartedOnce,
		phaseSequence:        &phaseSequence,
		commitObservedAt:     &commitObservedAt,
		acceptedWaitObserved: &acceptedWaitObservedAt,
	}
	bobRelay := &observeCommitChannel{
		ReadWriteCloser:      bobRaw,
		trigger:              commitFrame,
		commitWritten:        commitWritten,
		commitOnce:           &commitWrittenOnce,
		triggerWriteReturned: commitWriteReturned,
		releaseObservation:   releaseCommitObservation,
		waitStarted:          acceptedWaitStarted,
		waitOnce:             &acceptedWaitStartedOnce,
		phaseSequence:        &phaseSequence,
		commitObservedAt:     &commitObservedAt,
		acceptedWaitObserved: &acceptedWaitObservedAt,
	}
	defer aliceRelay.Close()
	defer bobRelay.Close()

	alice, bob := newNegotiatorPair(t, aliceRelay, bobRelay)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport := newBlockingAcceptTransport("fake-stream")
	_, bobTransport := newDirectHandoffTransports("fake-stream")

	const probeTimeout = time.Second
	ctx := context.Background()

	type phasedUpgradeOutcome struct {
		upgradeTestOutcome
		returnedAt uint64
	}
	aliceDone := make(chan phasedUpgradeOutcome, 1)
	bobDone := make(chan phasedUpgradeOutcome, 1)

	go func() {
		result, err := alice.Upgrade(
			ctx,
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(probeTimeout),
		)
		aliceDone <- phasedUpgradeOutcome{
			upgradeTestOutcome: upgradeTestOutcome{result: result, err: err},
			returnedAt:         phaseSequence.Add(1),
		}
	}()
	go func() {
		result, err := bob.Upgrade(
			ctx,
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(probeTimeout),
		)
		bobDone <- phasedUpgradeOutcome{
			upgradeTestOutcome: upgradeTestOutcome{result: result, err: err},
			returnedAt:         phaseSequence.Add(1),
		}
	}()
	receivePhasedOutcome := func(peer string, done <-chan phasedUpgradeOutcome) phasedUpgradeOutcome {
		select {
		case outcome := <-done:
			return outcome
		case <-time.After(testCausalObservationTimeout):
			t.Fatalf("%s Upgrade did not return", peer)
			return phasedUpgradeOutcome{}
		}
	}

	select {
	case <-commitWriteReturned:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("timed out waiting for underlying commit write")
	}
	alicePhased := receivePhasedOutcome("listener", aliceDone)
	releaseCommitObservationGate()
	select {
	case <-commitWritten:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("timed out waiting for commit observation")
	}
	select {
	case <-acceptedWaitStarted:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("timed out waiting for accepted-frame read")
	}

	aliceOutcome := alicePhased.upgradeTestOutcome
	if !errors.Is(aliceOutcome.err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("listener upgrade error = %v, want %v", aliceOutcome.err, ErrUpgradeTransportNotConverged)
	}
	if aliceOutcome.result.Stream != nil {
		t.Fatal("listener returned stream after post-commit accept timeout")
	}
	assertRelayChannelClosed(t, aliceRelay)

	bobPhased := receivePhasedOutcome("dialer", bobDone)
	if observedAt := commitObservedAt.Load(); observedAt == 0 || observedAt >= bobPhased.returnedAt {
		t.Fatalf("dialer returned at phase %d before commit observation phase %d", bobPhased.returnedAt, observedAt)
	}
	if observedAt := acceptedWaitObservedAt.Load(); observedAt == 0 || observedAt >= bobPhased.returnedAt {
		t.Fatalf("dialer returned at phase %d before accepted-wait observation phase %d", bobPhased.returnedAt, observedAt)
	}
	bobOutcome := bobPhased.upgradeTestOutcome
	if !errors.Is(bobOutcome.err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("dialer upgrade error = %v, want %v", bobOutcome.err, ErrUpgradeTransportNotConverged)
	}
	if bobOutcome.result.Stream != nil {
		t.Fatal("dialer returned stream after listener accept timeout")
	}
	if bobOutcome.result.Path == UpgradePathDirect {
		t.Fatal("dialer returned direct path after listener accept timeout")
	}
	assertRelayChannelClosed(t, bobRelay)
}

func TestNegotiatorUpgradeRelayEOFDuringAcceptedWaitReturnsErrors(t *testing.T) {
	aliceRaw, bobRaw := net.Pipe()
	commitFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseCommit)
	if err != nil {
		t.Fatalf("encode commit: %v", err)
	}
	commitWritten := make(chan struct{})
	var commitWrittenOnce sync.Once
	acceptedWaitStarted := make(chan struct{})
	var acceptedWaitStartedOnce sync.Once
	aliceRelay := &observeCommitChannel{
		ReadWriteCloser: aliceRaw,
		trigger:         commitFrame,
		commitWritten:   commitWritten,
		commitOnce:      &commitWrittenOnce,
		waitStarted:     acceptedWaitStarted,
		waitOnce:        &acceptedWaitStartedOnce,
	}
	bobRelay := &observeCommitChannel{
		ReadWriteCloser: bobRaw,
		trigger:         commitFrame,
		commitWritten:   commitWritten,
		commitOnce:      &commitWrittenOnce,
		waitStarted:     acceptedWaitStarted,
		waitOnce:        &acceptedWaitStartedOnce,
	}
	t.Cleanup(func() {
		_ = aliceRelay.Close()
		_ = bobRelay.Close()
	})
	alice, bob := newNegotiatorPair(t, aliceRelay, bobRelay)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport := newBlockingAcceptTransport("fake-stream")
	_, bobTransport := newDirectHandoffTransports("fake-stream")

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(time.Second),
			WithUpgradeControlTimeout(time.Second),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(time.Second),
			WithUpgradeControlTimeout(time.Second),
		)
	})

	select {
	case <-acceptedWaitStarted:
	case outcome := <-aliceDone:
		t.Fatalf("alice Upgrade returned before accepted wait started: error=%v path=%v fallback=%v", outcome.err, outcome.result.Path, outcome.result.FallbackReason)
	case outcome := <-bobDone:
		t.Fatalf("bob Upgrade returned before accepted wait started: error=%v path=%v fallback=%v", outcome.err, outcome.result.Path, outcome.result.FallbackReason)
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("timed out waiting for accepted-frame read")
	}
	_ = aliceRelay.Close()
	_ = bobRelay.Close()

	aliceOutcome := receiveUpgradeOutcome(t, "alice", aliceDone)
	if aliceOutcome.err == nil {
		t.Fatal("alice Upgrade error = nil, want relay EOF failure")
	}
	if aliceOutcome.result.Stream != nil {
		t.Fatal("alice returned stream after relay EOF during accepted wait")
	}
	if aliceOutcome.result.Path == UpgradePathRelay {
		t.Fatal("alice returned relay path after relay EOF during accepted wait")
	}

	bobOutcome := receiveUpgradeOutcome(t, "bob", bobDone)
	if bobOutcome.err == nil {
		t.Fatal("bob Upgrade error = nil, want relay EOF failure")
	}
	if bobOutcome.result.Stream != nil {
		t.Fatal("bob returned stream after relay EOF during accepted wait")
	}
	if bobOutcome.result.Path == UpgradePathRelay {
		t.Fatal("bob returned relay path after relay EOF during accepted wait")
	}
}

func TestNegotiatorUpgradeRelayEOFDuringConvergedWaitReturnsErrors(t *testing.T) {
	aliceRaw, bobRelay := net.Pipe()
	defer aliceRaw.Close()
	defer bobRelay.Close()

	acceptedFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseAccepted)
	if err != nil {
		t.Fatalf("encode accepted: %v", err)
	}
	aliceRelay := newCloseAfterWriteControlChannel(aliceRaw, bobRelay, acceptedFrame)

	alice, bob := newNegotiatorPair(t, aliceRelay, bobRelay)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport, bobTransport := newDirectHandoffTransports("fake-stream")

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(time.Second),
			WithUpgradeControlTimeout(time.Second),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(time.Second),
			WithUpgradeControlTimeout(time.Second),
		)
	})

	aliceOutcome := receiveUpgradeOutcome(t, "alice", aliceDone)
	if aliceOutcome.err == nil {
		t.Fatal("alice Upgrade error = nil, want relay EOF failure")
	}
	if aliceOutcome.result.Stream != nil {
		t.Fatal("alice returned stream after relay EOF during converged wait")
	}
	if aliceOutcome.result.Path == UpgradePathRelay {
		t.Fatal("alice returned relay path after relay EOF during converged wait")
	}

	bobOutcome := receiveUpgradeOutcome(t, "bob", bobDone)
	if bobOutcome.err == nil {
		t.Fatal("bob Upgrade error = nil, want relay EOF failure")
	}
	if bobOutcome.result.Stream != nil {
		t.Fatal("bob returned stream after relay EOF during converged wait")
	}
	if bobOutcome.result.Path == UpgradePathRelay {
		t.Fatal("bob returned relay path after relay EOF during converged wait")
	}
}

func TestNegotiatorUpgradeRelayCloseAfterConvergedWriteReturnsErrors(t *testing.T) {
	aliceRelay, bobRaw := net.Pipe()
	defer aliceRelay.Close()
	defer bobRaw.Close()

	convergedFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseConverged)
	if err != nil {
		t.Fatalf("encode converged: %v", err)
	}
	bobRelay := newCloseAfterWriteControlChannel(bobRaw, aliceRelay, convergedFrame)

	alice, bob := newNegotiatorPair(t, aliceRelay, bobRelay)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport, bobTransport := newDirectHandoffTransports("fake-stream")

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(time.Second),
			WithUpgradeControlTimeout(time.Second),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(time.Second),
			WithUpgradeControlTimeout(time.Second),
		)
	})

	aliceOutcome := receiveUpgradeOutcome(t, "alice", aliceDone)
	if !errors.Is(aliceOutcome.err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("alice Upgrade error = %v, want transport-not-converged", aliceOutcome.err)
	}
	if aliceOutcome.result.Stream != nil {
		t.Fatal("alice returned stream after relay close following converged write")
	}
	if aliceOutcome.result.Path == UpgradePathRelay {
		t.Fatal("alice returned relay path after relay close following converged write")
	}

	bobOutcome := receiveUpgradeOutcome(t, "bob", bobDone)
	if !errors.Is(bobOutcome.err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("bob Upgrade error = %v, want transport-not-converged", bobOutcome.err)
	}
	if bobOutcome.result.Stream != nil {
		t.Fatal("bob returned stream after relay close following converged write")
	}
	if bobOutcome.result.Path == UpgradePathRelay {
		t.Fatal("bob returned relay path after relay close following converged write")
	}
}

func TestNegotiatorUpgradePostCommitDialFailureClosesRelayChannel(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport, _ := newDirectHandoffTransports("fake-stream")
	bobTransport := newBlockingAcceptTransport("fake-stream")

	const probeTimeout = testRunnerSafeProbeTimeout
	ctx := context.Background()

	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			ctx,
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(probeTimeout),
		)
	})

	aliceOutcome, err := alice.Upgrade(
		ctx,
		WithTransport(aliceTransport),
		WithUpgradePacketConn(aliceConn),
		WithProbeTimeout(probeTimeout),
	)
	if err == nil {
		t.Fatalf("listener upgrade error = nil, want post-commit dial failure")
	}
	if aliceOutcome.Stream != nil {
		t.Fatal("listener returned stream after post-commit dial failure")
	}
	assertRelayChannelClosed(t, aliceRelay)

	bobOutcome := <-bobDone
	if bobOutcome.err == nil {
		t.Fatalf("dialer upgrade error = nil, want post-commit dial failure")
	}
	if bobOutcome.result.Stream != nil {
		t.Fatal("dialer returned stream after post-commit dial failure")
	}
	assertRelayChannelClosed(t, bobRelay)
}

func TestNegotiatorUpgradePostCommitAcceptWaitObservesDialerAbort(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport := newBlockingAcceptTransport("fake-stream")
	bobTransport := newBlockingAcceptTransport("fake-stream")

	const probeTimeout = 800 * time.Millisecond
	ctx := context.Background()

	start := time.Now()
	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			ctx,
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(probeTimeout),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			ctx,
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(probeTimeout),
		)
	})

	aliceOutcome := receiveUpgradeOutcome(t, "alice", aliceDone)
	elapsed := time.Since(start)
	if !errors.Is(aliceOutcome.err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("listener Upgrade error = %v, want transport-not-converged", aliceOutcome.err)
	}
	if aliceOutcome.result.Stream != nil {
		t.Fatal("listener returned stream after dialer post-commit abort")
	}
	if elapsed > probeTimeout/2 {
		t.Fatalf("listener returned after %s, want peer-abort path before probe timeout %s", elapsed, probeTimeout)
	}
	assertRelayChannelClosed(t, aliceRelay)

	bobOutcome := receiveUpgradeOutcome(t, "bob", bobDone)
	if bobOutcome.err == nil {
		t.Fatal("dialer Upgrade error = nil, want post-commit dial failure")
	}
	if bobOutcome.result.Stream != nil {
		t.Fatal("dialer returned stream after post-commit dial failure")
	}
	assertRelayChannelClosed(t, bobRelay)
}

func TestNegotiatorUpgradePostCommitUsesFreshTransportBudget(t *testing.T) {
	alice, bob, _, _ := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport, bobTransport := newSlowListenDelayedAcceptHandoffPair("fake-stream", 60*time.Millisecond, 45*time.Millisecond)

	const probeTimeout = 500 * time.Millisecond
	ctx := context.Background()

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			ctx,
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(probeTimeout),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			ctx,
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(probeTimeout),
		)
	})

	aliceOutcome := <-aliceDone
	bobOutcome := <-bobDone
	assertDirectResult(t, "alice", aliceOutcome)
	assertDirectResult(t, "bob", bobOutcome)

	_ = aliceOutcome.result.Stream.Close()
	_ = bobOutcome.result.Stream.Close()
}

func TestNegotiatorUpgradePostConfirmedRelayCloseKeepsDirectStreamsUsable(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport, bobTransport := newDirectHandoffTransports("fake-stream")

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(time.Second),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(time.Second),
		)
	})

	aliceOutcome := receiveUpgradeOutcome(t, "alice", aliceDone)
	bobOutcome := receiveUpgradeOutcome(t, "bob", bobDone)
	assertDirectResult(t, "alice", aliceOutcome)
	assertDirectResult(t, "bob", bobOutcome)

	_ = aliceRelay.Close()
	_ = bobRelay.Close()
	assertStreamTransfer(t, "alice to bob", aliceOutcome.result.Stream, bobOutcome.result.Stream, []byte("after-confirmed alice payload"))
	assertStreamTransfer(t, "bob to alice", bobOutcome.result.Stream, aliceOutcome.result.Stream, []byte("after-confirmed bob payload"))

	_ = aliceOutcome.result.Stream.Close()
	_ = bobOutcome.result.Stream.Close()
}

func TestNegotiatorUpgradePostCommitAcceptedWaitUsesProbeBudget(t *testing.T) {
	aliceRaw, bobRaw := net.Pipe()
	commitFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseCommit)
	if err != nil {
		t.Fatalf("encode commit: %v", err)
	}
	commitWritten := make(chan struct{})
	var commitWrittenOnce sync.Once
	acceptedWaitStarted := make(chan struct{})
	var acceptedWaitStartedOnce sync.Once
	aliceRelay := &observeCommitChannel{
		ReadWriteCloser: aliceRaw,
		trigger:         commitFrame,
		commitWritten:   commitWritten,
		commitOnce:      &commitWrittenOnce,
		waitStarted:     acceptedWaitStarted,
		waitOnce:        &acceptedWaitStartedOnce,
	}
	bobRelay := &observeCommitChannel{
		ReadWriteCloser: bobRaw,
		trigger:         commitFrame,
		commitWritten:   commitWritten,
		commitOnce:      &commitWrittenOnce,
		waitStarted:     acceptedWaitStarted,
		waitOnce:        &acceptedWaitStartedOnce,
	}
	defer aliceRelay.Close()
	defer bobRelay.Close()

	alice, bob := newNegotiatorPair(t, aliceRelay, bobRelay)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	const (
		controlTimeout = 250 * time.Millisecond
		probeTimeout   = 3 * time.Second
	)
	acceptGate := make(chan struct{})
	var releaseAcceptOnce sync.Once
	releaseAccept := func() {
		releaseAcceptOnce.Do(func() { close(acceptGate) })
	}
	t.Cleanup(releaseAccept)
	aliceTransport, bobTransport := newGatedAcceptHandoffPair("fake-stream", acceptGate)
	ctx := context.Background()

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			ctx,
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(probeTimeout),
			WithUpgradeControlTimeout(controlTimeout),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			ctx,
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(probeTimeout),
			WithUpgradeControlTimeout(controlTimeout),
		)
	})

	select {
	case <-commitWritten:
	case outcome := <-aliceDone:
		t.Fatalf("alice Upgrade returned before commit observation: error=%v path=%v fallback=%v", outcome.err, outcome.result.Path, outcome.result.FallbackReason)
	case outcome := <-bobDone:
		t.Fatalf("bob Upgrade returned before commit observation: error=%v path=%v fallback=%v", outcome.err, outcome.result.Path, outcome.result.FallbackReason)
	case <-time.After(probeTimeout):
		t.Fatal("timed out waiting for commit write")
	}

	select {
	case <-acceptedWaitStarted:
	case outcome := <-aliceDone:
		t.Fatalf("alice Upgrade returned before accepted wait started: error=%v path=%v fallback=%v", outcome.err, outcome.result.Path, outcome.result.FallbackReason)
	case outcome := <-bobDone:
		t.Fatalf("bob Upgrade returned before accepted wait started: error=%v path=%v fallback=%v", outcome.err, outcome.result.Path, outcome.result.FallbackReason)
	case <-time.After(probeTimeout):
		t.Fatal("timed out waiting for accepted-frame read")
	}

	requireFreshBudget := func(name string, observed <-chan time.Time) {
		t.Helper()
		select {
		case deadline := <-observed:
			if deadline.IsZero() {
				t.Fatalf("%s context has no deadline", name)
			}
			remaining := time.Until(deadline)
			if remaining <= probeTimeout/2 {
				t.Fatalf("%s budget remaining = %v, want more than half the probe budget %v", name, remaining, probeTimeout)
			}
		case outcome := <-aliceDone:
			t.Fatalf("alice Upgrade returned before %s context was observed: error=%v path=%v fallback=%v", name, outcome.err, outcome.result.Path, outcome.result.FallbackReason)
		case outcome := <-bobDone:
			t.Fatalf("bob Upgrade returned before %s context was observed: error=%v path=%v fallback=%v", name, outcome.err, outcome.result.Path, outcome.result.FallbackReason)
		case <-time.After(testCausalObservationTimeout):
			t.Fatalf("timed out waiting for %s context", name)
		}
	}
	requireFreshBudget("dialer post-commit transport", bobTransport.dialDeadlineObserved)
	requireFreshBudget("listener Accept wait", aliceTransport.acceptBudgetObserved)
	releaseAccept()

	aliceOutcome := receiveUpgradeOutcomeWithin(t, "alice", aliceDone, probeTimeout+time.Second)
	bobOutcome := receiveUpgradeOutcomeWithin(t, "bob", bobDone, probeTimeout+time.Second)
	assertDirectResult(t, "alice", aliceOutcome)
	assertDirectResult(t, "bob", bobOutcome)

	_ = aliceOutcome.result.Stream.Close()
	_ = bobOutcome.result.Stream.Close()
}

func TestObserveCommitChannelSignalsAfterPartialTriggerWrites(t *testing.T) {
	trigger := []byte("commit-frame")
	underlying := newPartialWriteControlChannel(2)
	commitWritten := make(chan struct{})
	waitStarted := make(chan struct{})
	var commitOnce sync.Once
	var waitOnce sync.Once
	channel := &observeCommitChannel{
		ReadWriteCloser: underlying,
		trigger:         trigger,
		commitWritten:   commitWritten,
		commitOnce:      &commitOnce,
		waitStarted:     waitStarted,
		waitOnce:        &waitOnce,
	}

	for offset := 0; offset < len(trigger); {
		n, err := channel.Write(trigger[offset:])
		if err != nil {
			t.Fatalf("Write trigger at offset %d: %v", offset, err)
		}
		if n <= 0 {
			t.Fatalf("Write trigger at offset %d wrote %d bytes", offset, n)
		}
		offset += n
	}

	select {
	case <-commitWritten:
	default:
		t.Fatal("partial trigger writes did not signal commit")
	}
	if got := underlying.written(); !bytes.Equal(got, trigger) {
		t.Fatalf("underlying writes = %q, want %q", got, trigger)
	}
}

func TestObserveCommitChannelTriggerWriteReturnedClosesOnceAfterSharedCommit(t *testing.T) {
	trigger := []byte("commit-frame")
	winnerCommitWritten := make(chan struct{})
	gatedCommitWritten := make(chan struct{})
	triggerWriteReturned := make(chan struct{})
	var commitOnce sync.Once
	winner := &observeCommitChannel{
		ReadWriteCloser: noopReadWriteCloser{},
		trigger:         trigger,
		commitWritten:   winnerCommitWritten,
		commitOnce:      &commitOnce,
	}
	gated := &observeCommitChannel{
		ReadWriteCloser:      noopReadWriteCloser{},
		trigger:              trigger,
		commitWritten:        gatedCommitWritten,
		commitOnce:           &commitOnce,
		triggerWriteReturned: triggerWriteReturned,
	}

	if _, err := winner.Write(trigger); err != nil {
		t.Fatalf("winner Write trigger: %v", err)
	}
	for i := range 3 {
		if _, err := gated.Write(trigger); err != nil {
			t.Fatalf("gated Write trigger %d: %v", i+1, err)
		}
	}

	select {
	case <-winnerCommitWritten:
	default:
		t.Fatal("winning channel did not signal shared commit")
	}
	select {
	case <-triggerWriteReturned:
	default:
		t.Fatal("gated channel did not signal trigger write return")
	}
	select {
	case <-gatedCommitWritten:
		t.Fatal("gated channel won an already-used shared commit Once")
	default:
	}
}

func TestNegotiatorUpgradeListenerCommitsOnEarlyTransportProgress(t *testing.T) {
	aliceRaw, bobRelay := net.Pipe()
	aliceWriteStarted := make(chan struct{}, 1)
	aliceRelay := newObservedControlChannel(aliceRaw, nil, aliceWriteStarted, nil, nil, nil)
	defer aliceRelay.Close()
	defer bobRelay.Close()

	alice, bob := newNegotiatorPair(t, aliceRelay, bobRelay)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport, _ := newDirectHandoffTransports("fake-stream")
	bobTransport, _ := newDirectHandoffTransports("fake-stream")

	const probeTimeout = time.Second
	ctx := context.Background()

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			ctx,
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(probeTimeout),
		)
	})

	select {
	case <-aliceWriteStarted:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("listener did not begin first-phase control write")
	}

	bobOutcome, err := bob.Upgrade(
		ctx,
		WithTransport(bobTransport),
		WithUpgradePacketConn(bobConn),
		WithProbeTimeout(probeTimeout),
	)
	if err != nil {
		t.Fatalf("dialer upgrade error = %v, want direct success after delayed commit", err)
	}
	if bobOutcome.Path != UpgradePathDirect {
		t.Fatalf("dialer path = %v, want direct", bobOutcome.Path)
	}

	aliceOutcome := <-aliceDone
	assertDirectResult(t, "alice", aliceOutcome)

	_ = aliceOutcome.result.Stream.Close()
	_ = bobOutcome.Stream.Close()
}

// The two constructors below name their results instead of returning two
// composite literals from one return statement: go1.27 gofmt and gofumpt
// disagree about how to indent that construct, and each reverts the other.
func newGatedAcceptHandoffPair(name string, acceptGate <-chan struct{}) (accepting *controlledAcceptTransport, direct *directHandoffTransport) {
	dialStream, listenStream := net.Pipe()
	shared := &directHandoffStreams{
		dialStream:   dialStream,
		listenStream: listenStream,
	}
	accepting = &controlledAcceptTransport{
		name:                 name,
		streams:              shared,
		acceptGate:           acceptGate,
		acceptBudgetObserved: make(chan time.Time, 1),
	}
	direct = &directHandoffTransport{
		name:                 name,
		streams:              shared,
		dialDeadlineObserved: make(chan time.Time, 1),
	}
	return accepting, direct
}

func newSlowListenDelayedAcceptHandoffPair(name string, listenDelay, acceptDelay time.Duration) (accepting *controlledAcceptTransport, direct *directHandoffTransport) {
	dialStream, listenStream := net.Pipe()
	shared := &directHandoffStreams{
		dialStream:   dialStream,
		listenStream: listenStream,
	}
	accepting = &controlledAcceptTransport{
		name:        name,
		streams:     shared,
		listenDelay: listenDelay,
		acceptDelay: acceptDelay,
	}
	direct = &directHandoffTransport{
		name:    name,
		streams: shared,
	}
	return accepting, direct
}

type controlledAcceptTransport struct {
	name                 string
	streams              *directHandoffStreams
	listenDelay          time.Duration
	acceptDelay          time.Duration
	acceptGate           <-chan struct{}
	acceptBudgetObserved chan time.Time
	session              *scriptedSession
}

func (t *controlledAcceptTransport) Name() string {
	return t.name
}

func (t *controlledAcceptTransport) NewSession(context.Context, TransportAuth) (Session, error) {
	t.session = &scriptedSession{
		dial: func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
			return nil, errNilTransportStream
		},
		listen: func(ctx context.Context, conn net.PacketConn, _ net.Addr, _ []byte) (TransportListener, error) {
			timer := time.NewTimer(t.listenDelay)
			defer timer.Stop()
			select {
			case <-timer.C:
			case <-ctx.Done():
				return nil, ctx.Err()
			}
			listener := newControlledAcceptListener(t.streams.listenStream, t.acceptGate, conn)
			listener.acceptDelay = t.acceptDelay
			listener.acceptBudgetObserved = t.acceptBudgetObserved
			return listener, nil
		},
	}
	return t.session, nil
}

type controlledAcceptListener struct {
	stream        io.ReadWriteCloser
	acceptDelay   time.Duration
	acceptGate    <-chan struct{}
	closed        bool
	closedSignal  chan struct{}
	acceptStarted chan struct{}

	mu                   sync.Mutex
	acceptDone           chan struct{}
	acceptStream         io.ReadWriteCloser
	acceptErr            error
	packetConn           net.PacketConn
	closeOnce            sync.Once
	closeWaiting         chan struct{}
	acceptBudgetObserved chan time.Time

	beforeReturn func()
}

func newControlledAcceptListener(stream io.ReadWriteCloser, acceptGate <-chan struct{}, packetConn net.PacketConn) *controlledAcceptListener {
	return &controlledAcceptListener{
		stream:        stream,
		acceptGate:    acceptGate,
		packetConn:    packetConn,
		closedSignal:  make(chan struct{}),
		acceptStarted: make(chan struct{}),
	}
}

func (l *controlledAcceptListener) Accept(ctx context.Context) (stream io.ReadWriteCloser, err error) {
	l.mu.Lock()
	l.acceptDone = make(chan struct{})
	acceptDone := l.acceptDone
	l.mu.Unlock()
	close(l.acceptStarted)
	defer func() {
		l.mu.Lock()
		l.acceptStream = stream
		l.acceptErr = err
		l.mu.Unlock()
		close(acceptDone)
	}()

	if l.acceptGate != nil {
		select {
		case <-l.acceptGate:
			stream = l.stream
		case <-l.closedSignal:
			err = net.ErrClosed
		case <-ctx.Done():
			err = ctx.Err()
		}
		if l.beforeReturn != nil {
			l.beforeReturn()
		}
		stream = newTestPacketOwningStream(stream, l.packetConn)
		return stream, err
	}
	timer := time.NewTimer(l.acceptDelay)
	defer timer.Stop()
	select {
	case <-timer.C:
		stream = l.stream
	case <-l.closedSignal:
		err = net.ErrClosed
	case <-ctx.Done():
		err = ctx.Err()
	}
	if l.beforeReturn != nil {
		l.beforeReturn()
	}
	stream = newTestPacketOwningStream(stream, l.packetConn)
	return stream, err
}

func (l *controlledAcceptListener) testListenerAcceptBudget(deadline time.Time) {
	select {
	case l.acceptBudgetObserved <- deadline:
	default:
	}
}

func (l *controlledAcceptListener) Close() error {
	l.closeOnce.Do(func() {
		l.closed = true
		close(l.closedSignal)
	})
	l.mu.Lock()
	acceptDone := l.acceptDone
	l.mu.Unlock()
	if acceptDone != nil {
		signal(l.closeWaiting)
		<-acceptDone
	}
	return nil
}

func TestControlledAcceptListenerCloseJoinsAccept(t *testing.T) {
	listener := newControlledAcceptListener(noopReadWriteCloser{}, make(chan struct{}), nil)
	acceptReleased := make(chan struct{})
	allowAcceptReturn := make(chan struct{})
	closeWaiting := make(chan struct{}, 1)
	listener.closeWaiting = closeWaiting
	listener.beforeReturn = func() {
		close(acceptReleased)
		<-allowAcceptReturn
	}

	accepted := make(chan acceptTestOutcome, 1)
	go func() {
		stream, err := listener.Accept(context.Background())
		accepted <- acceptTestOutcome{stream: stream, err: err}
	}()
	<-listener.acceptStarted

	closeDone := make(chan error, 1)
	go func() {
		closeDone <- listener.Close()
	}()
	<-acceptReleased
	select {
	case <-closeWaiting:
	case err := <-closeDone:
		t.Fatalf("Close returned before joining Accept: %v", err)
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("Close did not reach the Accept join")
	}
	select {
	case err := <-closeDone:
		t.Fatalf("Close returned while Accept was still gated: %v", err)
	default:
	}
	close(allowAcceptReturn)

	result := <-accepted
	if result.stream != nil || !errors.Is(result.err, net.ErrClosed) {
		t.Fatalf("Accept = %T, %v; want nil, %v", result.stream, result.err, net.ErrClosed)
	}
	if err := <-closeDone; err != nil {
		t.Fatalf("Close: %v", err)
	}
}

func assertRelayChannelClosed(t *testing.T, relay io.ReadWriteCloser) {
	t.Helper()
	buf := make([]byte, 1)
	if _, err := relay.Read(buf); err == nil {
		t.Fatal("relay read succeeded, want closed relay channel")
	}
}

func receiveUpgradeOutcome(t *testing.T, peer string, done <-chan upgradeTestOutcome) upgradeTestOutcome {
	return receiveUpgradeOutcomeWithin(t, peer, done, 2*time.Second)
}

func TestRequireReadyWriteBeforeOutcomeHandlesBufferedCompletion(t *testing.T) {
	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	channel := newWriteTriggeredControlChannel(nil, 1)
	channel.writeObserved <- controlWriteObservation{count: 1, payload: readyFrame}
	want := upgradeTestOutcome{err: errors.New("completed after ready")}
	done := make(chan upgradeTestOutcome, 1)
	done <- want

	requireReadyWriteBeforeOutcome(t, channel, done)

	select {
	case got := <-done:
		if !errors.Is(got.err, want.err) {
			t.Fatalf("buffered outcome error = %v, want %v", got.err, want.err)
		}
	default:
		t.Fatal("ready helper consumed buffered outcome")
	}
}

func TestRequireReadyWriteBeforeOutcomeRebuffersOutcomeFirstCompletion(t *testing.T) {
	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	channel := newWriteTriggeredControlChannel(nil, 1)
	want := upgradeTestOutcome{err: errors.New("completed immediately before ready observation")}
	done := make(chan upgradeTestOutcome, 1)
	done <- want

	requireReadyWriteBeforeOutcomeAfterOutcome(t, channel, done, func() {
		channel.writeObserved <- controlWriteObservation{count: 1, payload: readyFrame}
	})

	select {
	case got := <-done:
		if !errors.Is(got.err, want.err) {
			t.Fatalf("re-buffered outcome error = %v, want %v", got.err, want.err)
		}
	default:
		t.Fatal("ready helper did not re-buffer outcome-first completion")
	}
}

func requireReadyWriteBeforeOutcome(
	t *testing.T,
	channel *scriptedControlChannel,
	done chan upgradeTestOutcome,
) {
	t.Helper()
	requireReadyWriteBeforeOutcomeAfterOutcome(t, channel, done, nil)
}

func requireReadyWriteBeforeOutcomeAfterOutcome(
	t *testing.T,
	channel *scriptedControlChannel,
	done chan upgradeTestOutcome,
	afterOutcome func(),
) {
	t.Helper()
	if err := validateReadyWriteObservationFixture(channel); err != nil {
		t.Fatal(err)
	}

	select {
	case observation := <-channel.writeObserved:
		assertReadyWriteObservation(t, observation)
		return
	default:
	}

	select {
	case observation := <-channel.writeObserved:
		assertReadyWriteObservation(t, observation)
	case outcome := <-done:
		if afterOutcome != nil {
			afterOutcome()
		}
		select {
		case observation := <-channel.writeObserved:
			assertReadyWriteObservation(t, observation)
			done <- outcome
			return
		default:
			t.Fatalf("listener handoff returned before ready write: result=%#v err=%v", outcome.result, outcome.err)
		}
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("timed out waiting for listener ready write")
	}
}

func validateReadyWriteObservationFixture(channel *scriptedControlChannel) error {
	if channel == nil || channel.writeObserved == nil {
		return errors.New("ready-write helper requires a scripted control write-observation channel")
	}
	return nil
}

func assertReadyWriteObservation(t *testing.T, observation controlWriteObservation) {
	t.Helper()
	if observation.count != 1 {
		t.Fatalf("control writes before handoff deadline = %d, want ready only", observation.count)
	}
	if len(observation.payload) < 4 {
		t.Fatalf("first control write = %x, want length-prefixed ready frame", observation.payload)
	}
	ready, _ := decodeUpgradeControlPhasePayload(observation.payload[4:], upgradeControlPhaseReady)
	if !ready.Is(upgradeControlPhaseReady) {
		t.Fatalf("first control write = %x, want ready frame", observation.payload)
	}
}

func receiveUpgradeOutcomeWithin(t *testing.T, peer string, done <-chan upgradeTestOutcome, timeout time.Duration) upgradeTestOutcome {
	t.Helper()
	select {
	case outcome := <-done:
		return outcome
	case <-time.After(timeout):
		t.Fatalf("%s Upgrade did not return", peer)
		return upgradeTestOutcome{}
	}
}

func testListenerCandidatePairPlan(listenerCandidate, dialerCandidate Candidate) candidatePairPlan {
	return planProbeCandidatePairs(
		[]Candidate{listenerCandidate},
		[]Candidate{dialerCandidate},
		CandidatePolicy{},
		upgradeRoleListen,
	)
}

func assertStreamTransfer(t *testing.T, name string, from io.ReadWriteCloser, to io.ReadWriteCloser, payload []byte) {
	t.Helper()

	writeDone := make(chan error, 1)
	go func() {
		_, err := from.Write(payload)
		writeDone <- err
	}()

	got := make([]byte, len(payload))
	if _, err := io.ReadFull(to, got); err != nil {
		t.Fatalf("%s read: %v", name, err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("%s payload = %q, want %q", name, got, payload)
	}
	if err := <-writeDone; err != nil {
		t.Fatalf("%s write: %v", name, err)
	}
}

type closeTrackingStream struct {
	io.ReadWriteCloser
	closed atomic.Bool
}

func (s *closeTrackingStream) Close() error {
	s.closed.Store(true)
	return s.ReadWriteCloser.Close()
}

type closeTrackingPacketConn struct {
	net.PacketConn
	closed atomic.Bool
	closes atomic.Int32
}

type sustainedInputPacketConn struct {
	reads               int
	readDeadlineCleared bool
}

func (c *sustainedInputPacketConn) ReadFrom(p []byte) (int, net.Addr, error) {
	c.reads++
	if len(p) > 0 {
		p[0] = 1
	}
	return 1, &net.UDPAddr{}, nil
}

func (*sustainedInputPacketConn) WriteTo(p []byte, _ net.Addr) (int, error) {
	return len(p), nil
}

func (*sustainedInputPacketConn) Close() error { return nil }

func (*sustainedInputPacketConn) LocalAddr() net.Addr { return &net.UDPAddr{} }

func (c *sustainedInputPacketConn) SetDeadline(deadline time.Time) error {
	return c.SetReadDeadline(deadline)
}

func (c *sustainedInputPacketConn) SetReadDeadline(deadline time.Time) error {
	if deadline.IsZero() {
		c.readDeadlineCleared = true
	}
	return nil
}

func (*sustainedInputPacketConn) SetWriteDeadline(time.Time) error { return nil }

type queuedInputPacketConn struct {
	packets             [][]byte
	reads               int
	readDeadlineCleared bool
}

func (c *queuedInputPacketConn) ReadFrom(p []byte) (int, net.Addr, error) {
	c.reads++
	if len(c.packets) == 0 {
		return 0, nil, testPacketTimeoutError{}
	}
	packet := c.packets[0]
	c.packets = c.packets[1:]
	copy(p, packet)
	return len(packet), &net.UDPAddr{}, nil
}

func (*queuedInputPacketConn) WriteTo(p []byte, _ net.Addr) (int, error) {
	return len(p), nil
}

func (*queuedInputPacketConn) Close() error { return nil }

func (*queuedInputPacketConn) LocalAddr() net.Addr { return &net.UDPAddr{} }

func (c *queuedInputPacketConn) SetDeadline(deadline time.Time) error {
	return c.SetReadDeadline(deadline)
}

func (c *queuedInputPacketConn) SetReadDeadline(deadline time.Time) error {
	if deadline.IsZero() {
		c.readDeadlineCleared = true
	}
	return nil
}

func (*queuedInputPacketConn) SetWriteDeadline(time.Time) error { return nil }

// elapsedDeadlineContext isolates drainPacketConn's elapsed-deadline branch
// from the independent context-cancellation branch.
type elapsedDeadlineContext struct {
	context.Context
	deadline time.Time
}

func (ctx elapsedDeadlineContext) Deadline() (time.Time, bool) {
	return ctx.deadline, true
}

func (c *closeTrackingPacketConn) Close() error {
	c.closes.Add(1)
	c.closed.Store(true)
	return c.PacketConn.Close()
}

type scriptedControlChannel struct {
	delegate      io.ReadWriteCloser
	readScript    func([]byte) (int, error)
	writeScript   func([]byte) (int, error)
	closeScript   func() error
	readGate      *scriptedOperationGate
	writeGate     *scriptedOperationGate
	closeReleases []*scriptedOperationGate
	observeRead   func([]byte, int, error)
	observeWrite  func([]byte, int, error)

	mu            sync.Mutex
	writes        bytes.Buffer
	read          *bytes.Reader
	blockRead     bool
	inspectRead   bool
	readCount     int
	writeCount    int
	writeObserved chan controlWriteObservation
	readStarted   chan struct{}
	readStartOnce sync.Once
	closeOnce     sync.Once
	closeErr      error
	closed        atomic.Bool
	closeCalls    atomic.Int32
	closedCh      chan struct{}
}

func newScriptedControlChannel(read []byte, blockRead bool) *scriptedControlChannel {
	return &scriptedControlChannel{
		read:      bytes.NewReader(read),
		blockRead: blockRead,
		closedCh:  make(chan struct{}),
	}
}

func (c *scriptedControlChannel) Read(p []byte) (int, error) {
	if c.readStarted != nil {
		c.readStartOnce.Do(func() { close(c.readStarted) })
	}
	if c.readGate != nil {
		_ = c.readGate.wait(context.Background())
	}
	if c.closed.Load() {
		return c.observeReadResult(p, 0, io.ErrClosedPipe)
	}
	if c.readScript != nil {
		n, err := c.readScript(p)
		return c.observeReadResult(p, n, err)
	}
	if c.delegate != nil {
		n, err := c.delegate.Read(p)
		return c.observeReadResult(p, n, err)
	}
	for {
		c.mu.Lock()
		if c.read != nil && c.read.Len() > 0 {
			n, err := c.read.Read(p)
			c.mu.Unlock()
			return c.observeReadResult(p, n, err)
		}
		if c.closed.Load() {
			c.mu.Unlock()
			return c.observeReadResult(p, 0, io.ErrClosedPipe)
		}
		if !c.blockRead {
			c.mu.Unlock()
			return c.observeReadResult(p, 0, io.EOF)
		}
		closedCh := c.closedCh
		c.mu.Unlock()
		<-closedCh
	}
}

func (c *scriptedControlChannel) Write(p []byte) (int, error) {
	if c.writeGate != nil {
		_ = c.writeGate.wait(context.Background())
	}
	if c.closed.Load() {
		return c.observeWriteResult(p, 0, io.ErrClosedPipe)
	}
	var n int
	var err error
	switch {
	case c.writeScript != nil:
		n, err = c.writeScript(p)
	case c.delegate != nil:
		n, err = c.delegate.Write(p)
	default:
		n, err = c.writeBuffered(p)
	}
	return c.observeWriteResult(p, n, err)
}

func (c *scriptedControlChannel) writeBuffered(p []byte) (int, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.writes.Write(p)
}

func (c *scriptedControlChannel) Close() error {
	c.closeCalls.Add(1)
	c.closeOnce.Do(func() {
		c.closed.Store(true)
		for _, gate := range c.closeReleases {
			gate.release()
		}
		close(c.closedCh)
		switch {
		case c.closeScript != nil:
			c.closeErr = c.closeScript()
		case c.delegate != nil:
			c.closeErr = c.delegate.Close()
		}
	})
	return c.closeErr
}

func (c *scriptedControlChannel) observeReadResult(p []byte, n int, err error) (int, error) {
	c.mu.Lock()
	c.readCount++
	c.mu.Unlock()
	if c.observeRead != nil {
		c.observeRead(p, n, err)
	}
	return n, err
}

func (c *scriptedControlChannel) observeWriteResult(p []byte, n int, err error) (int, error) {
	c.mu.Lock()
	c.writeCount++
	count := c.writeCount
	observed := c.writeObserved
	c.mu.Unlock()
	if observed != nil {
		observation := controlWriteObservation{count: count, payload: append([]byte(nil), p...)}
		select {
		case observed <- observation:
		default:
		}
	}
	if c.observeWrite != nil {
		c.observeWrite(p, n, err)
	}
	return n, err
}

func (c *scriptedControlChannel) written() []byte {
	c.mu.Lock()
	defer c.mu.Unlock()
	return append([]byte(nil), c.writes.Bytes()...)
}

func (c *scriptedControlChannel) wasClosed() bool {
	return c.closed.Load()
}

func (c *scriptedControlChannel) closeCallCount() int {
	return int(c.closeCalls.Load())
}

func (c *scriptedControlChannel) readCallCount() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.readCount
}

func (c *scriptedControlChannel) writeCallCount() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.writeCount
}

func newReleasedReadControlChannel(read []byte, release <-chan struct{}) *scriptedControlChannel {
	channel := newScriptedControlChannel(read, false)
	channel.inspectRead = true
	channel.readStarted = make(chan struct{})
	channel.readScript = func(p []byte) (int, error) {
		select {
		case <-release:
		case <-channel.closedCh:
			return 0, io.ErrClosedPipe
		}
		channel.mu.Lock()
		defer channel.mu.Unlock()
		if channel.closed.Load() {
			return 0, io.ErrClosedPipe
		}
		if channel.read.Len() == 0 {
			return 0, io.EOF
		}
		return channel.read.Read(p)
	}
	return channel
}

func newDelayedWriteControlChannel(read []byte, blockRead bool, delay time.Duration) *scriptedControlChannel {
	channel := newScriptedControlChannel(read, blockRead)
	channel.writeScript = func(p []byte) (int, error) {
		time.Sleep(delay)
		if channel.closed.Load() {
			return 0, io.ErrClosedPipe
		}
		return channel.writeBuffered(p)
	}
	return channel
}

func newObservedWriteControlChannel(writeObserved chan<- struct{}, read []byte, blockRead bool) *scriptedControlChannel {
	channel := newScriptedControlChannel(read, blockRead)
	channel.observeWrite = func([]byte, int, error) {
		writeObserved <- struct{}{}
	}
	return channel
}

func newObservedControlChannel(
	delegate io.ReadWriteCloser,
	readStarted chan<- struct{},
	writeStarted chan<- struct{},
	readReturned chan<- struct{},
	writeReturned chan<- struct{},
	closeCalled chan<- struct{},
) *scriptedControlChannel {
	channel := newScriptedControlChannel(nil, false)
	channel.delegate = delegate
	channel.readScript = func(p []byte) (int, error) {
		notifyControlOperation(readStarted)
		n, err := delegate.Read(p)
		notifyControlOperation(readReturned)
		return n, err
	}
	channel.writeScript = func(p []byte) (int, error) {
		notifyControlOperation(writeStarted)
		n, err := delegate.Write(p)
		notifyControlOperation(writeReturned)
		return n, err
	}
	channel.closeScript = func() error {
		notifyControlOperation(closeCalled)
		return delegate.Close()
	}
	return channel
}

func notifyControlOperation(observed chan<- struct{}) {
	if observed == nil {
		return
	}
	select {
	case observed <- struct{}{}:
	default:
	}
}

func newWriteFailControlChannel(writeErr error) *scriptedControlChannel {
	channel := newScriptedControlChannel(nil, true)
	channel.writeScript = func([]byte) (int, error) { return 0, writeErr }
	return channel
}

func newCloseAfterWriteControlChannel(delegate io.ReadWriteCloser, peer io.Closer, trigger []byte) *scriptedControlChannel {
	channel := newScriptedControlChannel(nil, false)
	channel.delegate = delegate
	var once sync.Once
	channel.observeWrite = func(p []byte, _ int, _ error) {
		if !bytes.Equal(p, trigger) {
			return
		}
		once.Do(func() {
			_ = channel.Close()
			_ = peer.Close()
		})
	}
	return channel
}

type observeCommitChannel struct {
	io.ReadWriteCloser
	trigger                  []byte
	commitWritten            chan struct{}
	commitOnce               *sync.Once
	triggerWriteReturned     chan struct{}
	triggerWriteReturnedOnce sync.Once
	releaseObservation       <-chan struct{}
	waitStarted              chan struct{}
	waitOnce                 *sync.Once
	committed                atomic.Bool
	writeMu                  sync.Mutex
	triggerOffset            int
	phaseSequence            *atomic.Uint64
	commitObservedAt         *atomic.Uint64
	acceptedWaitObserved     *atomic.Uint64
}

func newPartialWriteControlChannel(maxWrite int) *scriptedControlChannel {
	channel := newScriptedControlChannel(nil, false)
	channel.writeScript = func(p []byte) (int, error) {
		if len(p) > maxWrite {
			p = p[:maxWrite]
		}
		return channel.writeBuffered(p)
	}
	return channel
}

func (c *observeCommitChannel) Read(p []byte) (int, error) {
	if c.committed.Load() {
		c.waitOnce.Do(func() {
			if c.phaseSequence != nil && c.acceptedWaitObserved != nil {
				c.acceptedWaitObserved.Store(c.phaseSequence.Add(1))
			}
			close(c.waitStarted)
		})
	}
	return c.ReadWriteCloser.Read(p)
}

func (c *observeCommitChannel) Write(p []byte) (int, error) {
	n, err := c.ReadWriteCloser.Write(p)
	c.observeTriggerWrite(p, n)
	return n, err
}

func (c *observeCommitChannel) observeTriggerWrite(p []byte, n int) {
	if n <= 0 || n > len(p) || c.committed.Load() {
		return
	}

	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	if c.committed.Load() {
		return
	}
	if c.triggerOffset == 0 {
		if !bytes.Equal(p, c.trigger) {
			return
		}
	} else if c.triggerOffset >= len(c.trigger) || !bytes.Equal(p, c.trigger[c.triggerOffset:]) {
		c.triggerOffset = 0
		return
	}
	c.triggerOffset += n
	if c.triggerOffset != len(c.trigger) {
		return
	}
	if c.triggerWriteReturned != nil {
		c.triggerWriteReturnedOnce.Do(func() {
			close(c.triggerWriteReturned)
		})
	}
	if c.releaseObservation != nil {
		<-c.releaseObservation
	}
	c.commitOnce.Do(func() {
		if c.phaseSequence != nil && c.commitObservedAt != nil {
			c.commitObservedAt.Store(c.phaseSequence.Add(1))
		}
		c.committed.Store(true)
		close(c.commitWritten)
	})
}

type controlWriteObservation struct {
	count   int
	payload []byte
}

func newWriteTriggeredControlChannel(read []byte, triggerWrite int) *scriptedControlChannel {
	gate := newUncancelableScriptedOperationGate()
	channel := newScriptedControlChannel(read, false)
	channel.readGate = gate
	channel.closeReleases = []*scriptedOperationGate{gate}
	channel.writeObserved = make(chan controlWriteObservation, triggerWrite)
	channel.observeWrite = func([]byte, int, error) {
		channel.mu.Lock()
		count := channel.writeCount
		channel.mu.Unlock()
		if count >= triggerWrite {
			gate.release()
		}
	}
	return channel
}

func newBlockingAcceptTransport(name string) *blockingAcceptTransport {
	return &blockingAcceptTransport{
		name:    name,
		session: newBlockingAcceptSession(),
	}
}

type blockingAcceptTransport struct {
	name    string
	session *scriptedSession
}

func (t *blockingAcceptTransport) Name() string {
	return t.name
}

func (t *blockingAcceptTransport) NewSession(context.Context, TransportAuth) (Session, error) {
	return t.session, nil
}

func newBlockingAcceptSession() *scriptedSession {
	return &scriptedSession{
		dial: func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
			return nil, errNilTransportStream
		},
		listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
			return newBlockingAcceptListener(), nil
		},
	}
}

type blockingAcceptListener struct {
	closed        bool
	closedSignal  chan struct{}
	acceptStarted chan struct{}

	mu           sync.Mutex
	acceptDone   chan struct{}
	acceptStream io.ReadWriteCloser
	acceptErr    error
	closeOnce    sync.Once
	closeWaiting chan struct{}

	beforeReturn func()
}

func newBlockingAcceptListener() *blockingAcceptListener {
	return &blockingAcceptListener{
		closedSignal:  make(chan struct{}),
		acceptStarted: make(chan struct{}),
	}
}

func (l *blockingAcceptListener) Accept(ctx context.Context) (stream io.ReadWriteCloser, err error) {
	l.mu.Lock()
	l.acceptDone = make(chan struct{})
	acceptDone := l.acceptDone
	l.mu.Unlock()
	close(l.acceptStarted)
	defer func() {
		l.mu.Lock()
		l.acceptStream = stream
		l.acceptErr = err
		l.mu.Unlock()
		close(acceptDone)
	}()

	select {
	case <-l.closedSignal:
		err = net.ErrClosed
	case <-ctx.Done():
		err = ctx.Err()
	}
	if l.beforeReturn != nil {
		l.beforeReturn()
	}
	return nil, err
}

func (l *blockingAcceptListener) Close() error {
	l.closeOnce.Do(func() {
		l.closed = true
		close(l.closedSignal)
	})
	l.mu.Lock()
	acceptDone := l.acceptDone
	l.mu.Unlock()
	if acceptDone != nil {
		signal(l.closeWaiting)
		<-acceptDone
	}
	return nil
}

func TestBlockingAcceptListenerCloseJoinsAccept(t *testing.T) {
	listener := newBlockingAcceptListener()
	acceptReleased := make(chan struct{})
	allowAcceptReturn := make(chan struct{})
	closeWaiting := make(chan struct{}, 1)
	listener.closeWaiting = closeWaiting
	listener.beforeReturn = func() {
		close(acceptReleased)
		<-allowAcceptReturn
	}

	accepted := make(chan acceptTestOutcome, 1)
	go func() {
		stream, err := listener.Accept(context.Background())
		accepted <- acceptTestOutcome{stream: stream, err: err}
	}()
	<-listener.acceptStarted

	closeDone := make(chan error, 1)
	go func() {
		closeDone <- listener.Close()
	}()
	<-acceptReleased
	select {
	case <-closeWaiting:
	case err := <-closeDone:
		t.Fatalf("Close returned before joining Accept: %v", err)
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("Close did not reach the Accept join")
	}
	select {
	case err := <-closeDone:
		t.Fatalf("Close returned while Accept was still gated: %v", err)
	default:
	}
	close(allowAcceptReturn)

	result := <-accepted
	if result.stream != nil || !errors.Is(result.err, net.ErrClosed) {
		t.Fatalf("Accept = %T, %v; want nil, %v", result.stream, result.err, net.ErrClosed)
	}
	if err := <-closeDone; err != nil {
		t.Fatalf("Close: %v", err)
	}
}

func TestNegotiatorUpgradeDirectSuccessClosesDialerSession(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport, bobTransport := newDirectHandoffTransports("fake-stream")
	// This test exercises successful direct handoff and session cleanup, not
	// probe timeout behavior. Leave enough budget for shared CI runners to
	// schedule both peers.
	const probeTimeout = time.Second

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background(), WithTransport(aliceTransport), WithUpgradePacketConn(aliceConn), WithProbeTimeout(probeTimeout))
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background(), WithTransport(bobTransport), WithUpgradePacketConn(bobConn), WithProbeTimeout(probeTimeout))
	})

	aliceOutcome := <-aliceDone
	bobOutcome := <-bobDone
	assertDirectResult(t, "alice", aliceOutcome)
	assertDirectResult(t, "bob", bobOutcome)

	if aliceTransport.session == nil || !aliceTransport.session.closed {
		t.Fatal("alice session was not closed after direct upgrade")
	}
	if bobTransport.session == nil || !bobTransport.session.closed {
		t.Fatal("bob session was not closed after direct upgrade")
	}
	assertRelayChannelClosed(t, aliceRelay)
	assertRelayChannelClosed(t, bobRelay)

	_ = aliceOutcome.result.Stream.Close()
	_ = bobOutcome.result.Stream.Close()
}
