package connect

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/netip"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

func newReadyCorruptingControlChannel(delegate io.ReadWriteCloser) *scriptedControlChannel {
	return newFrameCorruptingControlChannel(delegate, decodeTurnRetryReady)
}

// newFrameCorruptingControlChannel corrupts the first outbound control frame
// whose payload satisfies match, leaving every other write untouched.
func newFrameCorruptingControlChannel(delegate io.ReadWriteCloser, match func(payload []byte) bool) *scriptedControlChannel {
	return newFrameRewritingControlChannel(delegate, func(payload []byte) ([]byte, bool) {
		if !match(payload) {
			return nil, false
		}
		corrupted := append([]byte(nil), payload...)
		corrupted[0] ^= 0xFF
		frame, err := encodeTurnRetryFramePayload(corrupted)
		if err != nil {
			panic("connect: test corrupted frame failed to encode: " + err.Error())
		}
		return frame, true
	})
}

// newFrameRewritingControlChannel replaces the first outbound control frame
// whose payload rewrite accepts with the complete framed message rewrite
// returns (the shape every encodeTurnRetry* helper produces), and leaves every
// other write untouched.
func newFrameRewritingControlChannel(delegate io.ReadWriteCloser, rewrite func(payload []byte) (frame []byte, ok bool)) *scriptedControlChannel {
	channel := newScriptedControlChannel(nil, false)
	channel.delegate = delegate
	var mu sync.Mutex
	done := false
	channel.writeScript = func(p []byte) (int, error) {
		mu.Lock()
		var replacement []byte
		replaced := false
		if !done && len(p) > 4 {
			payloadLen := int(binary.BigEndian.Uint32(p[:4]))
			if 4+payloadLen == len(p) {
				replacement, replaced = rewrite(p[4:])
				done = replaced
			}
		}
		mu.Unlock()
		if replaced {
			if err := writeFull(delegate, replacement); err != nil {
				return 0, err
			}
			return len(p), nil
		}
		return delegate.Write(p)
	}
	return channel
}

// blockingAcceptHandoffTransport is an eligible transport whose listener
// Accept blocks until canceled, keeping the listener untransferred while
// awaiting Commit.
type blockingAcceptHandoffTransport struct{ inner *directHandoffTransport }

func (t blockingAcceptHandoffTransport) Name() string { return t.inner.Name() }

func (t blockingAcceptHandoffTransport) NewSession(ctx context.Context, auth TransportAuth) (Session, error) {
	session, err := t.inner.NewSession(ctx, auth)
	if err != nil {
		return nil, err
	}
	return &scriptedSession{
		delegate: session,
		listen: func(ctx context.Context, conn net.PacketConn, remote net.Addr, material []byte) (TransportListener, error) {
			listener, listenErr := session.Listen(ctx, conn, remote, material)
			if listenErr != nil {
				return nil, listenErr
			}
			return &turnBlockedAcceptListener{inner: listener}, nil
		},
	}, nil
}

func (t blockingAcceptHandoffTransport) WiremuxRelayTransportProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3TransportForTest(t)
}

type turnBlockedAcceptListener struct {
	inner TransportListener
}

func (l *turnBlockedAcceptListener) Accept(ctx context.Context) (io.ReadWriteCloser, error) {
	<-ctx.Done()
	return nil, ctx.Err()
}

func (l *turnBlockedAcceptListener) Close() error { return l.inner.Close() }

func TestTurnRetryMalformedPostSelectionFrameConvergesProtocolMismatch(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	corrupting := newReadyCorruptingControlChannel(listener.negotiate.channel)
	listener.negotiate.channel = corrupting

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, blockingAcceptHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackProtocolMismatch)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), corrupting, UpgradeFallbackProtocolMismatch)

	// The detecting dialer sent retry code 5; the preempted listener echoed
	// it; precedence keeps protocol_mismatch over probe_failed.
	reasons := dialer.relay.turnRetryFallbackReasons()
	if len(reasons) != 1 || reasons[0] != UpgradeFallbackProtocolMismatch {
		t.Fatalf("dialer retry fallback reasons = %v, want exactly [protocol_mismatch]", reasons)
	}
	if dialerComposite.closeCount() == 0 || listenerComposite.closeCount() == 0 {
		t.Fatal("composites not closed after post-selection protocol mismatch")
	}
}

// crossProfileInjectingComposite delivers one fabricated v1 probe datagram as
// the first packet the retry probe reads.
type crossProfileInjectingComposite struct {
	*fakeRelayComposite
	once   sync.Once
	packet []byte
	src    net.Addr
}

func (c *crossProfileInjectingComposite) ReadFrom(p []byte) (int, net.Addr, error) {
	var (
		n        int
		injected bool
	)
	c.once.Do(func() {
		n = copy(p, c.packet)
		injected = true
	})
	if injected {
		return n, c.src, nil
	}
	return c.fakeRelayComposite.ReadFrom(p)
}

func TestTurnRetryCrossProfileProbeConvergesProtocolMismatch(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	inner := newFakeRelayComposite(t)
	v1Packet, err := encodeProbeDatagram(
		bytes.Repeat([]byte{0x07}, probeKeyBytes),
		probeMessageRequest,
		probeDirectionListenerToDialer,
		[probeIDBytes]byte{1, 2, 3, 4, 5, 6, 7, 8},
		Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("192.0.2.1:1000")},
		Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("192.0.2.2:2000")},
	)
	if err != nil {
		t.Fatalf("encode v1 probe: %v", err)
	}
	dialerComposite := &crossProfileInjectingComposite{
		fakeRelayComposite: inner,
		packet:             v1Packet,
		src:                net.UDPAddrFromAddrPort(netip.MustParseAddrPort("127.0.0.1:9")),
	}
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackProtocolMismatch)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackProtocolMismatch)

	reasons := dialer.relay.turnRetryFallbackReasons()
	if len(reasons) != 1 || reasons[0] != UpgradeFallbackProtocolMismatch {
		t.Fatalf("dialer retry fallback reasons = %v, want exactly [protocol_mismatch]", reasons)
	}
}

// requestDroppingComposite drops the first dropFirst outbound retry probe
// requests, simulating packets lost before the peer's permission and
// ChannelBind are ready.
type requestDroppingComposite struct {
	*fakeRelayComposite
	mu        sync.Mutex
	dropFirst int
	dropped   int
}

func (c *requestDroppingComposite) WriteTo(p []byte, addr net.Addr) (int, error) {
	if len(p) == probeDatagramBytes && bytes.Equal(p[:4], turnRetryProbeDatagramMagic[:]) && p[5] == byte(probeMessageRequest) {
		c.mu.Lock()
		if c.dropped < c.dropFirst {
			c.dropped++
			c.mu.Unlock()
			return len(p), nil
		}
		c.mu.Unlock()
	}
	return c.fakeRelayComposite.WriteTo(p, addr)
}

func TestTurnRetryProbeRetransmitsThroughInitialLoss(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := &requestDroppingComposite{
		fakeRelayComposite: newFakeRelayComposite(t),
		dropFirst:          2,
	}
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	if dialerOutcome.err != nil || listenerOutcome.err != nil {
		t.Fatalf("upgrade errors = %v / %v, want nil", dialerOutcome.err, listenerOutcome.err)
	}
	if dialerOutcome.result.Path != UpgradePathDirect || listenerOutcome.result.Path != UpgradePathDirect {
		t.Fatalf("paths = %q/%q, want TURN carrier on both", dialerOutcome.result.Path, listenerOutcome.result.Path)
	}
	dialerComposite.mu.Lock()
	dropped := dialerComposite.dropped
	dialerComposite.mu.Unlock()
	if dropped != 2 {
		t.Fatalf("dropped initial retry probe requests = %d, want 2: success must come from retransmission", dropped)
	}
}

type closeCountingStream struct {
	io.ReadWriteCloser
	mu         sync.Mutex
	closeCalls int
}

func (s *closeCountingStream) Close() error {
	s.mu.Lock()
	s.closeCalls++
	s.mu.Unlock()
	return s.ReadWriteCloser.Close()
}

func (s *closeCountingStream) closeCount() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.closeCalls
}

type turnFailingDialTransport struct {
	inner  *directHandoffTransport
	stream *closeCountingStream
}

func (t turnFailingDialTransport) Name() string { return t.inner.Name() }

func (t turnFailingDialTransport) NewSession(ctx context.Context, auth TransportAuth) (Session, error) {
	session, err := t.inner.NewSession(ctx, auth)
	if err != nil {
		return nil, err
	}
	return &scriptedSession{
		delegate: session,
		dial: func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
			if t.stream != nil {
				return t.stream, errors.New("materialized dial error")
			}
			return nil, errors.New("dial failed after commit")
		},
	}, nil
}

func (t turnFailingDialTransport) WiremuxRelayTransportProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3TransportForTest(t)
}

func TestTurnRetryPostCommitDialFailureFailsClosedWithoutRelayResurrection(t *testing.T) {
	cases := []struct {
		name       string
		withStream bool
	}{
		{name: "commit without stream closes only the composite"},
		{name: "stream with error closes only the stream", withStream: true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dialer, listener := newTurnRetryFailingDirectPeers(t)

			dialerComposite := newFakeRelayComposite(t)
			listenerComposite := newFakeRelayComposite(t)
			dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
			listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

			dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
			var stream *closeCountingStream
			if tc.withStream {
				half, other := net.Pipe()
				t.Cleanup(func() { _ = other.Close() })
				stream = &closeCountingStream{ReadWriteCloser: half}
			}
			dialerDone := runTurnRetryHandoffPeer(t, dialer, turnFailingDialTransport{inner: dialTransport, stream: stream})
			listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

			dialerOutcome := <-dialerDone
			listenerOutcome := <-listenerDone
			if !errors.Is(dialerOutcome.err, ErrUpgradeTransportNotConverged) {
				t.Fatalf("dialer error = %v, want %v", dialerOutcome.err, ErrUpgradeTransportNotConverged)
			}
			if !strings.Contains(dialerOutcome.err.Error(), string(turnRetryStagePostCommit)) {
				t.Fatalf("dialer error = %q, want retry stage %q labeled (issue #1218 diagnostics)",
					dialerOutcome.err.Error(), turnRetryStagePostCommit)
			}
			if dialerOutcome.result.Stream != nil {
				t.Fatal("dialer result resurrected a stream after commit boundary")
			}
			if listenerOutcome.err == nil && listenerOutcome.result.Path == UpgradePathRelay {
				t.Fatal("listener resurrected reliable relay after peer commit failure")
			}

			if tc.withStream {
				if stream.closeCount() == 0 {
					t.Fatal("materialized stream was not closed")
				}
				if dialerComposite.closeCount() != 0 {
					t.Fatalf("composite close calls = %d, want 0: stream-owned failure closes only the stream", dialerComposite.closeCount())
				}
			} else if dialerComposite.closeCount() == 0 {
				t.Fatal("committed raw-owned composite was not closed")
			}
			// The unselected direct socket survives a TURN postcommit failure.
			if err := dialer.conn.SetReadDeadline(time.Time{}); err != nil {
				t.Fatalf("dialer direct socket closed after TURN postcommit failure: %v", err)
			}
		})
	}
}

// TestTurnRetryMalformedConvergenceFrameFailsClosedWithStage pins the
// malformed post-commit convergence family (issue #1270): a corrupted
// Accepted or Converged frame fails the decoding role closed with the public
// sentinel, the internal family cause, and the post-commit stage label.
func TestTurnRetryMalformedConvergenceFrameFailsClosedWithStage(t *testing.T) {
	cases := []struct {
		name         string
		corruptFrame func(payload []byte) bool
		corruptOn    func(dialer, listener *turnRetryTestPeer) *turnRetryTestPeer
		failingRole  func(dialer, listener turnRetryTestOutcome) turnRetryTestOutcome
	}{
		{
			name:         "corrupted Accepted fails the dialer",
			corruptFrame: func(p []byte) bool { _, ok := decodeTurnRetryAccepted(p); return ok },
			corruptOn:    func(_, listener *turnRetryTestPeer) *turnRetryTestPeer { return listener },
			failingRole:  func(dialer, _ turnRetryTestOutcome) turnRetryTestOutcome { return dialer },
		},
		{
			name:         "corrupted Converged fails the listener",
			corruptFrame: func(p []byte) bool { _, ok := decodeTurnRetryConverged(p); return ok },
			corruptOn:    func(dialer, _ *turnRetryTestPeer) *turnRetryTestPeer { return dialer },
			failingRole:  func(_, listener turnRetryTestOutcome) turnRetryTestOutcome { return listener },
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dialer, listener := newTurnRetryFailingDirectPeers(t)

			dialerComposite := newFakeRelayComposite(t)
			listenerComposite := newFakeRelayComposite(t)
			dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
			listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

			sender := tc.corruptOn(dialer, listener)
			sender.negotiate.channel = newFrameCorruptingControlChannel(sender.negotiate.channel, tc.corruptFrame)

			dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
			dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
			listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

			failing := tc.failingRole(<-dialerDone, <-listenerDone)
			if !errors.Is(failing.err, ErrUpgradeTransportNotConverged) {
				t.Fatalf("failing role error = %v (result %+v), want %v", failing.err, failing.result, ErrUpgradeTransportNotConverged)
			}
			if !errors.Is(failing.err, errTurnRetryConvergenceMalformed) {
				t.Fatalf("failing role error = %v, want malformed-convergence family cause", failing.err)
			}
			if !strings.Contains(failing.err.Error(), string(turnRetryStagePostCommit)) {
				t.Fatalf("failing role error = %q, want retry stage %q labeled", failing.err.Error(), turnRetryStagePostCommit)
			}
			if failing.result.Stream != nil || failing.result.Path == UpgradePathRelay {
				t.Fatalf("failing role result = %+v, want fail-closed with no stream or relay resurrection", failing.result)
			}
		})
	}
}

// TestTurnRetryDatagramExposureMismatchFailsClosedWithStage pins Decision 2
// of issue #1270 at a production exit: the listener's Confirmed frame is
// rewritten to claim Datagram exposure the dialer never agreed to, so the
// dialer's mismatch exit must keep the phase-specific sentinel and carry the
// post-commit stage label. The terminal executor's pre-existing join of
// ErrUpgradeTransportNotConverged onto stream-owned fail-closed causes is
// unchanged; the wrapper-level rule that the label itself adds nothing is
// pinned by TestTurnRetryMismatchStageLabelKeepsSentinelWithoutNotConverged.
func TestTurnRetryDatagramExposureMismatchFailsClosedWithStage(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	listener.negotiate.channel = newFrameRewritingControlChannel(listener.negotiate.channel, func(payload []byte) ([]byte, bool) {
		agreed, ok := decodeTurnRetryConfirmed(payload)
		if !ok {
			return nil, false
		}
		flipped, err := encodeTurnRetryConfirmed(!agreed)
		if err != nil {
			panic("connect: test Confirmed frame failed to encode: " + err.Error())
		}
		return flipped, true
	})

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	if !errors.Is(dialerOutcome.err, errDatagramExposureAgreementMismatch) {
		t.Fatalf("dialer error = %v (result %+v), want errors.Is errDatagramExposureAgreementMismatch", dialerOutcome.err, dialerOutcome.result)
	}
	if !strings.Contains(dialerOutcome.err.Error(), string(turnRetryStagePostCommit)) {
		t.Fatalf("dialer error = %q, want retry stage %q labeled", dialerOutcome.err.Error(), turnRetryStagePostCommit)
	}
	if dialerOutcome.result.Stream != nil || dialerOutcome.result.Path == UpgradePathRelay {
		t.Fatalf("dialer result = %+v, want fail-closed with no stream or relay resurrection", dialerOutcome.result)
	}
	if listenerOutcome.result.Path == UpgradePathRelay {
		t.Fatalf("listener result = %+v, want no relay resurrection after peer mismatch", listenerOutcome.result)
	}
}

func TestTurnRetryOuterCancellationReturnsExactContextError(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	blockRelease := make(chan struct{})
	t.Cleanup(func() { close(blockRelease) })
	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	// Preparation blocks until context cancellation so the cancel lands
	// mid-retry with an owned composite and active work.
	blockingPrepare := &prepareBlockingComposite{fakeRelayComposite: dialerComposite, release: blockRelease}
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return blockingPrepare, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	ctx, cancel := context.WithCancel(context.Background())
	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeerContext(t, ctx, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeerContext(t, ctx, listener, eligibleHandoffTransport{inner: listenTransport})

	time.Sleep(400 * time.Millisecond)
	cancel()

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	if !errors.Is(dialerOutcome.err, context.Canceled) {
		t.Fatalf("dialer error = %v, want exact %v", dialerOutcome.err, context.Canceled)
	}
	if dialerOutcome.result.Stream != nil || dialerOutcome.result.Path == UpgradePathRelay {
		t.Fatalf("dialer result = %+v, want no reliable-fallback success on outer cancellation", dialerOutcome.result)
	}
	if listenerOutcome.err == nil && listenerOutcome.result.Path == UpgradePathRelay {
		t.Fatal("listener claimed reliable fallback success after outer cancellation")
	}
	if dialerComposite.closeCount() == 0 {
		t.Fatal("dialer composite not closed on outer cancellation")
	}
}

type prepareBlockingComposite struct {
	*fakeRelayComposite
	release chan struct{}
}

func (c *prepareBlockingComposite) PreparePeer(ctx context.Context, peer netip.AddrPort) error {
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-c.release:
		return c.fakeRelayComposite.PreparePeer(ctx, peer)
	}
}

func TestTurnRetryConcurrentCompositeTerminalRequestsShareOneSeal(t *testing.T) {
	t.Parallel()

	composite := newBlockedIOComposite()
	turn := newOwnedTURNPathClaim(noopReadWriteCloser{}, composite)
	session := &compositeBlockedDialSession{dialReturned: make(chan struct{})}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	turn.registerCommit()
	dialDone := turn.startDial(ctx, session, composite, composite.LocalAddr(), []byte("peer"))
	time.Sleep(20 * time.Millisecond)

	type outcome struct {
		result UpgradeResult
		err    error
	}
	results := make(chan outcome, 2)
	for range 2 {
		go func() {
			result, err := turn.failClosed(errors.New("concurrent terminal"), abortAfterOwnedResources)
			results <- outcome{result: result, err: err}
		}()
	}
	first := <-results
	second := <-results
	if !errors.Is(first.err, ErrUpgradeTransportNotConverged) || !errors.Is(second.err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("concurrent terminal errors = %v / %v, want both %v", first.err, second.err, ErrUpgradeTransportNotConverged)
	}
	<-dialDone
}

// acceptOnCancelHandoffTransport is an eligible listener transport whose
// Accept materializes a countable stream exactly when its context is
// canceled, modeling a stream that transfers ownership during the terminal
// join.
type acceptOnCancelHandoffTransport struct {
	inner  *directHandoffTransport
	stream *closeCountingStream
}

func (t acceptOnCancelHandoffTransport) Name() string { return t.inner.Name() }

func (t acceptOnCancelHandoffTransport) NewSession(ctx context.Context, auth TransportAuth) (Session, error) {
	session, err := t.inner.NewSession(ctx, auth)
	if err != nil {
		return nil, err
	}
	return &scriptedSession{
		delegate: session,
		listen: func(ctx context.Context, conn net.PacketConn, remote net.Addr, material []byte) (TransportListener, error) {
			listener, listenErr := session.Listen(ctx, conn, remote, material)
			if listenErr != nil {
				return nil, listenErr
			}
			return &acceptOnCancelListener{inner: listener, stream: t.stream}, nil
		},
	}, nil
}

func (t acceptOnCancelHandoffTransport) WiremuxRelayTransportProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3TransportForTest(t)
}

type acceptOnCancelListener struct {
	inner  TransportListener
	stream *closeCountingStream
}

func (l *acceptOnCancelListener) Accept(ctx context.Context) (io.ReadWriteCloser, error) {
	<-ctx.Done()
	return l.stream, nil
}

func (l *acceptOnCancelListener) Close() error { return l.inner.Close() }

// TestTurnRetryAcceptMaterializingDuringFrameCleanupFailsClosed is the C-006
// finality regression: a peer Fallback or malformed frame racing an Accept
// that materializes a stream during the terminal join must fail closed with
// exactly one stream close and no relay resurrection.
func TestTurnRetryAcceptMaterializingDuringFrameCleanupFailsClosed(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	// The dialer observes a corrupted Ready and sends retry Fallback 5 while
	// the listener awaits Commit with its Accept still pending; the join then
	// materializes a stream.
	corrupting := newReadyCorruptingControlChannel(listener.negotiate.channel)
	listener.negotiate.channel = corrupting

	half, other := net.Pipe()
	t.Cleanup(func() { _ = other.Close() })
	stream := &closeCountingStream{ReadWriteCloser: half}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, acceptOnCancelHandoffTransport{inner: listenTransport, stream: stream})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone

	if !errors.Is(listenerOutcome.err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("listener error = %v (result %+v), want %v after transfer boundary",
			listenerOutcome.err, listenerOutcome.result, ErrUpgradeTransportNotConverged)
	}
	if !errors.Is(listenerOutcome.err, errTurnRetryTransferredResource) {
		t.Fatalf("listener error = %v, want transferred-resource family cause (issue #1270)", listenerOutcome.err)
	}
	if !strings.Contains(listenerOutcome.err.Error(), string(turnRetryStageReadyCommit)) {
		t.Fatalf("listener error = %q, want retry stage %q labeled (issue #1270)",
			listenerOutcome.err.Error(), turnRetryStageReadyCommit)
	}
	if listenerOutcome.result.Stream != nil || listenerOutcome.result.Path == UpgradePathRelay {
		t.Fatalf("listener result = %+v, want no relay resurrection after materialized Accept", listenerOutcome.result)
	}
	if calls := stream.closeCount(); calls != 1 {
		t.Fatalf("materialized stream close calls = %d, want exactly 1", calls)
	}
	// The detecting dialer still converges its own terminal path.
	if dialerOutcome.err == nil && dialerOutcome.result.Path == UpgradePathDirect {
		t.Fatalf("dialer result = %+v, want terminal fallback or control error", dialerOutcome.result)
	}
}

// slowAcceptHandoffTransport delays the listener's Accept until a timer that
// starts at Listen and expires after the precommit handoff deadline but
// within the fresh postcommit budget.
type slowAcceptHandoffTransport struct {
	inner *directHandoffTransport
	delay time.Duration
}

func (t slowAcceptHandoffTransport) Name() string { return t.inner.Name() }

func (t slowAcceptHandoffTransport) NewSession(ctx context.Context, auth TransportAuth) (Session, error) {
	session, err := t.inner.NewSession(ctx, auth)
	if err != nil {
		return nil, err
	}
	return &scriptedSession{
		delegate: session,
		listen: func(ctx context.Context, conn net.PacketConn, remote net.Addr, material []byte) (TransportListener, error) {
			listener, listenErr := session.Listen(ctx, conn, remote, material)
			if listenErr != nil {
				return nil, listenErr
			}
			return &slowAcceptListener{inner: listener, release: time.After(t.delay)}, nil
		},
	}, nil
}

func (t slowAcceptHandoffTransport) WiremuxRelayTransportProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3TransportForTest(t)
}

type slowAcceptListener struct {
	inner   TransportListener
	release <-chan time.Time
}

func (l *slowAcceptListener) Accept(ctx context.Context) (io.ReadWriteCloser, error) {
	select {
	case <-l.release:
		return l.inner.Accept(ctx)
	case <-ctx.Done():
		return nil, ctx.Err()
	}
}

func (l *slowAcceptListener) Close() error { return l.inner.Close() }

// TestTurnRetryListenerAcceptUsesFreshPostCommitBudget is the C-002
// regression from the replacement review: an Accept that completes after the
// precommit handoff deadline but within the fresh postcommit budget must
// converge; the spent handoff context must not cancel it.
func TestTurnRetryListenerAcceptUsesFreshPostCommitBudget(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	// probeTimeout 500ms bounds both the precommit handoff and the fresh
	// postcommit budget; Commit is delayed 350ms so the 700ms Accept lands
	// after the handoff deadline (Listen+500ms) and inside the postcommit
	// budget (~Listen+850ms).
	dialerDelegate := dialer.negotiate.channel
	delayedCommit := newScriptedControlChannel(nil, false)
	delayedCommit.delegate = dialerDelegate
	delayedCommit.writeScript = func(p []byte) (int, error) {
		if len(p) > 4 && len(p) <= 4+turnRetryMaxPayload && decodeTurnRetryCommit(p[4:]) {
			time.Sleep(350 * time.Millisecond)
		}
		return dialerDelegate.Write(p)
	}
	dialer.negotiate.channel = delayedCommit
	dialer.extraOpts = []UpgradeOption{WithProbeTimeout(500 * time.Millisecond)}
	listener.extraOpts = []UpgradeOption{WithProbeTimeout(500 * time.Millisecond)}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, slowAcceptHandoffTransport{inner: listenTransport, delay: 700 * time.Millisecond})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	if listenerOutcome.err != nil {
		t.Fatalf("listener error = %v (result %+v), want convergence within the fresh postcommit budget",
			listenerOutcome.err, listenerOutcome.result)
	}
	if dialerOutcome.err != nil {
		t.Fatalf("dialer error = %v, want convergence", dialerOutcome.err)
	}
	if listenerOutcome.result.Path != UpgradePathDirect || dialerOutcome.result.Path != UpgradePathDirect {
		t.Fatalf("paths = %q/%q, want TURN carrier on both", dialerOutcome.result.Path, listenerOutcome.result.Path)
	}
	_ = dialerOutcome.result.Stream.Close()
	_ = listenerOutcome.result.Stream.Close()
}
