package connect

import (
	"net/netip"
	"testing"
)

func topologyCandidate(kind CandidateKind, addr string) Candidate {
	return Candidate{Kind: kind, Addr: netip.MustParseAddrPort(addr)}
}

func TestUpgradeResultCarrierTopologyClassifiesCanonicalShapes(t *testing.T) {
	t.Parallel()

	host := topologyCandidate(CandidateKindHost, "192.0.2.10:1000")
	reflexive := topologyCandidate(CandidateKindReflexive, "198.51.100.20:2000")
	relayA := topologyCandidate(CandidateKindRelay, "203.0.113.1:3478")
	relayB := topologyCandidate(CandidateKindRelay, "203.0.113.2:3478")

	valid := []struct {
		name   string
		result UpgradeResult
		want   CarrierTopology
	}{
		{
			name:   "relay fallback with nil pair is relay-assisted",
			result: UpgradeResult{Path: UpgradePathRelay},
			want:   CarrierTopologyRelayAssisted,
		},
		{
			name:   "direct host-to-host",
			result: UpgradeResult{Path: UpgradePathDirect, SelectedPair: &CandidatePair{Local: host, Remote: host}},
			want:   CarrierTopologyDirect,
		},
		{
			name:   "direct host reflexive",
			result: UpgradeResult{Path: UpgradePathDirect, SelectedPair: &CandidatePair{Local: host, Remote: reflexive}},
			want:   CarrierTopologyDirect,
		},
		{
			name:   "direct reflexive host",
			result: UpgradeResult{Path: UpgradePathDirect, SelectedPair: &CandidatePair{Local: reflexive, Remote: host}},
			want:   CarrierTopologyDirect,
		},
		{
			name:   "direct reflexive-to-reflexive",
			result: UpgradeResult{Path: UpgradePathDirect, SelectedPair: &CandidatePair{Local: reflexive, Remote: reflexive}},
			want:   CarrierTopologyDirect,
		},
		{
			name:   "relay-to-relay upgrade is relay-assisted",
			result: UpgradeResult{Path: UpgradePathDirect, SelectedPair: &CandidatePair{Local: relayA, Remote: relayB}},
			want:   CarrierTopologyRelayAssisted,
		},
	}
	for _, tc := range valid {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			got, err := tc.result.CarrierTopology()
			if err != nil {
				t.Fatalf("CarrierTopology error = %v, want nil", err)
			}
			if got != tc.want {
				t.Fatalf("CarrierTopology = %q, want %q", got, tc.want)
			}
		})
	}

	invalid := []struct {
		name   string
		result UpgradeResult
	}{
		{
			name:   "mixed relay local with non-relay remote",
			result: UpgradeResult{Path: UpgradePathDirect, SelectedPair: &CandidatePair{Local: relayA, Remote: host}},
		},
		{
			name:   "mixed non-relay local with relay remote",
			result: UpgradeResult{Path: UpgradePathDirect, SelectedPair: &CandidatePair{Local: reflexive, Remote: relayB}},
		},
		{
			name:   "direct with nil pair",
			result: UpgradeResult{Path: UpgradePathDirect},
		},
		{
			name:   "relay fallback with pair",
			result: UpgradeResult{Path: UpgradePathRelay, SelectedPair: &CandidatePair{Local: host, Remote: host}},
		},
		{
			name:   "unknown candidate kind",
			result: UpgradeResult{Path: UpgradePathDirect, SelectedPair: &CandidatePair{Local: Candidate{Kind: "bogus", Addr: host.Addr}, Remote: host}},
		},
		{
			name:   "unknown path",
			result: UpgradeResult{Path: UpgradePath("bogus")},
		},
	}
	for _, tc := range invalid {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			got, err := tc.result.CarrierTopology()
			if err == nil {
				t.Fatalf("CarrierTopology = %q, want invalid-shape error", got)
			}
			if got != CarrierTopology("") {
				t.Fatalf("CarrierTopology = %q, want invalid zero value", got)
			}
		})
	}
}
