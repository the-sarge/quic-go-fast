package connect

import (
	"crypto/hkdf"
	"crypto/sha256"
	"errors"
	"fmt"
	"strings"
)

// Exporter derivation errors.
var (
	ErrInvalidExporterLabel   = errors.New("connect: exporter label contains NUL")
	ErrNegativeExporterLength = errors.New("connect: exporter length is negative")
	ErrExporterLengthTooLong  = errors.New("connect: exporter length exceeds HKDF-SHA-256 limit")
	ErrEmptyMasterSecret      = errors.New("connect: exporter master secret is empty")
)

// NewHKDFKeyExporter returns a KeyExporter for AuthContext implementations.
//
// masterSecret is the identity layer's session master secret and must be
// non-empty. A non-empty master secret does not by itself prove entropy quality;
// identity layers remain responsible for generating strong session secrets.
// sessionBinding is mixed into the exporter state once, so Derive callers
// provide only protocol-specific labels and context. Both inputs are copied
// before use and are not retained.
//
// Direct diagnostics that invoke fmt.Formatter are redacted. The diagnostic
// contract also covers interface, pointer, and value operands in exported and
// unexported holder fields for %v, %+v, %#v, %s, %q, %p, %w, %d, %x, and %X.
// Direct %p, rejected %w, and reflection fallbacks may include addresses or fmt
// error syntax, but not retained key material.
// This is not a guarantee for arbitrary reflection, unsafe memory access,
// third-party serializers, or custom logging code. The exporter has no reset
// or release operation; revocable auth views enforce their own lifetimes.
func NewHKDFKeyExporter(masterSecret, sessionBinding []byte) KeyExporter {
	if len(masterSecret) == 0 {
		return &hkdfKeyExporter{initErr: ErrEmptyMasterSecret}
	}

	master := append([]byte(nil), masterSecret...)
	binding := append([]byte(nil), sessionBinding...)
	prk, err := hkdf.Extract(sha256.New, master, binding)
	clear(master)
	clear(binding)

	return &hkdfKeyExporter{
		// fmt may bypass Format for hidden fields and rejected verbs. Keep
		// secret bytes in a closure, whose captured state fmt cannot traverse,
		// rather than in a reflected field (even behind a pointer).
		expand: func(info string, length int) ([]byte, error) {
			return hkdf.Expand(sha256.New, prk, info, length)
		},
		initErr: err,
	}
}

type hkdfKeyExporter struct { //nolint:recvcheck // Format uses a value receiver to redact dereferenced values; Derive preserves its pointer receiver.
	expand  func(info string, length int) ([]byte, error)
	initErr error
}

// Format supplies an intentional diagnostic when fmt invokes methods. The
// representation above independently protects reflection-only fallbacks.
func (e hkdfKeyExporter) Format(state fmt.State, verb rune) {
	const redacted = "HKDFKeyExporter{<redacted>}"
	if verb == 'q' {
		_, _ = fmt.Fprintf(state, "%q", redacted)
		return
	}
	_, _ = fmt.Fprint(state, redacted)
}

func (e *hkdfKeyExporter) Derive(label string, context []byte, length int) ([]byte, error) {
	if strings.ContainsRune(label, '\x00') {
		return nil, ErrInvalidExporterLabel
	}
	if length < 0 {
		return nil, ErrNegativeExporterLength
	}
	if length > 255*sha256.Size {
		return nil, ErrExporterLengthTooLong
	}
	if e.initErr != nil {
		return nil, e.initErr
	}

	info := make([]byte, 0, len(label)+1+len(context))
	info = append(info, label...)
	info = append(info, 0x00)
	info = append(info, context...)

	if e.expand == nil {
		// Preserve the private zero value's original nil-PRK behavior.
		return hkdf.Expand(sha256.New, nil, string(info), length)
	}
	return e.expand(string(info), length)
}
