package connect

import (
	"context"
	"errors"
	"go/ast"
	"go/parser"
	"go/token"
	"io"
	"net"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/proberuntime"
)

type attemptResourceSnapshot struct {
	packetConn      net.PacketConn
	session         Session
	listener        TransportListener
	stream          io.ReadWriteCloser
	dial            attemptOperationLifecycle
	listen          attemptOperationLifecycle
	accept          attemptOperationLifecycle
	acceptResult    transportAcceptResult
	acceptResultSet bool
	committed       bool
	transferred     bool
	claim           packetClaimState
}

func (r *attemptResources) snapshot() attemptResourceSnapshot {
	r.mu.Lock()
	defer r.mu.Unlock()
	return attemptResourceSnapshot{
		packetConn:      r.packetConn,
		session:         r.session,
		listener:        r.listener,
		stream:          r.stream,
		dial:            r.dialState,
		listen:          r.listenState,
		accept:          r.acceptState,
		acceptResult:    r.acceptResult,
		acceptResultSet: r.acceptResultSet,
		committed:       r.committed,
		transferred:     r.transfer.Transferred(),
		claim:           r.claim,
	}
}

func newTestDirectUpgradeAttempt(attempt directUpgradeAttempt) directUpgradeAttempt {
	if attempt.owner != nil {
		panic("test directUpgradeAttempt already has an owner")
	}
	attempt.owner = newAttemptResources(attempt.channel, attempt.cfg.packetConn)
	return attempt
}

func registerCompletedTestAcceptOperation(
	owner *attemptResources,
	listener TransportListener,
	acceptDone chan transportAcceptResult,
	result transportAcceptResult,
) {
	ready := make(chan struct{})
	close(ready)
	operation := &ownedAcceptOperation{
		cancel: func() {},
		ready:  ready,
		done:   acceptDone,
	}
	owner.mu.Lock()
	defer owner.mu.Unlock()
	owner.listener = listener
	owner.accept = operation
	owner.acceptState = attemptOperationComplete
	owner.acceptResult = result
	owner.acceptResultSet = true
	if result.stream != nil {
		owner.stream = result.stream
	}
	owner.recordTransportResultLocked(result)
}

func registerCompletedTestAcceptAttempt(
	owner *attemptResources,
	session Session,
	listener TransportListener,
	result transportAcceptResult,
) {
	owner.registerSession(session)
	result.stream = newTestPacketOwningStream(result.stream, owner.packetConn)
	acceptDone := make(chan transportAcceptResult, 1)
	acceptDone <- result
	registerCompletedTestAcceptOperation(owner, listener, acceptDone, result)
}

func TestAttemptResourcesPersistentIdentity(t *testing.T) {
	t.Parallel()

	packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
	attempt := newDirectUpgradeAttempt(
		&Negotiator{channel: noopReadWriteCloser{}},
		upgradeConfig{packetConn: packetConn},
	)
	copied := attempt

	owner := attempt.resources()
	if owner != copied.resources() {
		t.Fatal("copied directUpgradeAttempt did not retain one attemptResources owner")
	}
	if got := owner.snapshot().packetConn; got != packetConn {
		t.Fatalf("owner packet conn = %p, want exact supplied conn %p", got, packetConn)
	}

	dialer := newDialerDirectUpgradeProtocolEngine(attempt, nil, localUpgradeOffer{}, candidatePairProbeResult{})
	listener := newListenerDirectUpgradeProtocolEngine(attempt, nil, localUpgradeOffer{}, candidatePairPlan{}, 0)
	fallback := newTerminalFallbackExchange(attempt)
	for name, got := range map[string]*attemptResources{
		"dialer":   dialer.attempt.resources(),
		"listener": listener.attempt.resources(),
		"fallback": fallback.attempt.resources(),
	} {
		if got != owner {
			t.Fatalf("%s constructor owner = %p, want exact owner %p", name, got, owner)
		}
	}
}

func TestNewTransportSessionLateResultCloseOnce(t *testing.T) {
	session := &terminalTestSession{}
	transport := &lateSessionTransport{
		started: make(chan struct{}),
		release: make(chan struct{}),
		session: session,
	}
	owner := newAttemptResources(&terminalTestChannel{}, &terminalTestPacketConn{})
	attempt := directUpgradeAttempt{
		cfg:   upgradeConfig{transport: transport},
		owner: owner,
	}
	ctx, cancel := context.WithCancel(context.Background())
	outcome := make(chan error, 1)
	go func() {
		_, err := attempt.newTransportSession(ctx)
		outcome <- err
	}()

	<-transport.started
	cancel()
	if err := <-outcome; !errors.Is(err, context.Canceled) {
		t.Fatalf("newTransportSession error = %v, want context.Canceled", err)
	}
	close(transport.release)

	deadline := time.NewTimer(time.Second)
	defer deadline.Stop()
	for owner.snapshot().session != session {
		select {
		case <-deadline.C:
			t.Fatal("late Session was not registered with the terminal owner")
		default:
			runtime.Gosched()
		}
	}

	result, err := owner.settleRelay(UpgradeFallbackTransportFailed)
	if err != nil || result.Path != UpgradePathRelay {
		t.Fatalf("terminal settlement = %+v, %v; want relay result", result, err)
	}

	duplicateWindow := time.NewTimer(10 * time.Millisecond)
	defer duplicateWindow.Stop()
	for {
		if got := session.closeCalls.Load(); got != 1 {
			t.Fatalf("late Session Close calls = %d, want exactly 1", got)
		}
		select {
		case <-duplicateWindow.C:
			return
		default:
			runtime.Gosched()
		}
	}
}

func TestAttemptResourcesRegistersOperationsBeforeStart(t *testing.T) {
	t.Parallel()

	owner := newAttemptResources(noopReadWriteCloser{}, nil)
	session := &scriptedSession{}
	owner.registerSession(session)

	session.dial = func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
		if state := owner.snapshot().dial; state != attemptOperationRunning {
			t.Errorf("Dial started with lifecycle %v, want running", state)
		}
		return noopReadWriteCloser{}, nil
	}
	if result := <-owner.startDial(context.Background(), session, nil, nil, nil); result.err != nil {
		t.Fatalf("Dial result error = %v", result.err)
	}
	if snapshot := owner.snapshot(); snapshot.session != session || snapshot.stream == nil {
		t.Fatalf("Dial graph = session %T, stream %T; want exact Session and materialized stream", snapshot.session, snapshot.stream)
	}

	listener := &registrationObservingListener{}
	session.listen = func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
		if state := owner.snapshot().listen; state != attemptOperationRunning {
			t.Errorf("Listen started with lifecycle %v, want running", state)
		}
		return listener, nil
	}
	if result := <-owner.startListen(context.Background(), session, nil, nil, nil); result.err != nil {
		t.Fatalf("Listen result error = %v", result.err)
	}
	if snapshot := owner.snapshot(); snapshot.listener != listener {
		t.Fatalf("registered listener = %T, want %T", snapshot.listener, listener)
	}

	listener.accept = func() {
		if state := owner.snapshot().accept; state != attemptOperationRunning {
			t.Errorf("Accept started with lifecycle %v, want running", state)
		}
	}
	_, acceptDone := owner.startAccept(context.Background(), listener)
	if result := <-acceptDone; result.err != nil {
		t.Fatalf("Accept result error = %v", result.err)
	}
	if state := owner.snapshot().accept; state != attemptOperationComplete {
		t.Fatalf("Accept lifecycle = %v, want complete", state)
	}
}

type lateSessionTransport struct {
	started chan struct{}
	release chan struct{}
	session Session
}

func (*lateSessionTransport) Name() string {
	return "late-session"
}

func (t *lateSessionTransport) NewSession(context.Context, TransportAuth) (Session, error) {
	close(t.started)
	<-t.release
	return t.session, nil
}

func TestAttemptResourcesJoinsOwnedDial(t *testing.T) {
	t.Parallel()

	dialErr := errors.New("dial failed")
	streamWithError := noopReadWriteCloser{}
	tests := []struct {
		name       string
		stream     io.ReadWriteCloser
		err        error
		wantStream io.ReadWriteCloser
		wantErr    error
	}{
		{
			name:    "failure",
			err:     dialErr,
			wantErr: dialErr,
		},
		{
			name:       "success",
			stream:     noopReadWriteCloser{},
			wantStream: noopReadWriteCloser{},
		},
		{
			name:       "materialized error",
			stream:     streamWithError,
			err:        dialErr,
			wantStream: streamWithError,
			wantErr:    dialErr,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			session := newFinalitySession(test.stream, test.err)
			owner := newAttemptResources(noopReadWriteCloser{}, nil)
			owner.registerSession(session)
			owner.startDial(context.Background(), session, nil, nil, nil)
			session.dialGate.waitStarted(t)

			result := owner.joinDialForTerminal(true)
			if result.stream != test.wantStream {
				t.Fatalf("joined stream = %v, want %v", result.stream, test.wantStream)
			}
			if !errors.Is(result.err, test.wantErr) {
				t.Fatalf("joined error = %v, want %v", result.err, test.wantErr)
			}
			if !session.wasClosed() {
				t.Fatal("Session.Close was not called before joining Dial")
			}
			if state := owner.snapshot().dial; state != attemptOperationJoined {
				t.Fatalf("Dial lifecycle = %v, want joined", state)
			}
		})
	}
}

func TestAttemptResourcesJoinsOwnedListen(t *testing.T) {
	t.Parallel()

	listenErr := errors.New("listen failed")
	listenerWithError := &registrationObservingListener{accept: func() {}}
	tests := []struct {
		name         string
		listener     TransportListener
		err          error
		wantListener TransportListener
		wantErr      error
	}{
		{
			name:    "failure",
			err:     listenErr,
			wantErr: listenErr,
		},
		{
			name:         "materialized error",
			listener:     listenerWithError,
			err:          listenErr,
			wantListener: listenerWithError,
			wantErr:      listenErr,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			session := newFinalityListenSession(test.listener, test.err)
			owner := newAttemptResources(noopReadWriteCloser{}, nil)
			owner.registerSession(session)
			owner.startListen(context.Background(), session, nil, nil, nil)
			session.listenGate.waitStarted(t)

			result := owner.joinListenForTerminal(true)
			if result.listener != test.wantListener {
				t.Fatalf("joined listener = %v, want %v", result.listener, test.wantListener)
			}
			if !errors.Is(result.err, test.wantErr) {
				t.Fatalf("joined error = %v, want %v", result.err, test.wantErr)
			}
			if !session.wasClosed() {
				t.Fatal("Session.Close was not called before joining Listen")
			}
			if state := owner.snapshot().listen; state != attemptOperationJoined {
				t.Fatalf("Listen lifecycle = %v, want joined", state)
			}
		})
	}
}

func TestAttemptResourcesRegistersDefinitiveAcceptResult(t *testing.T) {
	t.Parallel()

	acceptErr := errors.New("accept failed")
	tests := []struct {
		name            string
		stream          io.ReadWriteCloser
		err             error
		wantTransferred bool
	}{
		{
			name: "failure",
			err:  acceptErr,
		},
		{
			name:            "success",
			stream:          &countingReadWriteCloser{},
			wantTransferred: true,
		},
		{
			name:            "materialized error",
			stream:          &countingReadWriteCloser{},
			err:             acceptErr,
			wantTransferred: true,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			owner := newAttemptResources(noopReadWriteCloser{}, nil)
			listener := &scriptedAcceptListener{stream: test.stream, err: test.err}
			_, acceptDone := owner.startAccept(context.Background(), listener)
			result := <-acceptDone
			snapshot := owner.snapshot()

			if !snapshot.acceptResultSet {
				t.Fatal("Accept completion became observable before its result was registered")
			}
			if snapshot.acceptResult.stream != result.stream {
				t.Fatalf("registered stream = %v, want %v", snapshot.acceptResult.stream, result.stream)
			}
			if !errors.Is(snapshot.acceptResult.err, result.err) {
				t.Fatalf("registered error = %v, want %v", snapshot.acceptResult.err, result.err)
			}
			if snapshot.transferred != test.wantTransferred {
				t.Fatalf("transferred = %t, want %t", snapshot.transferred, test.wantTransferred)
			}
		})
	}

	t.Run("canceled operation publishes materialized state for terminal settlement", func(t *testing.T) {
		stream := &countingReadWriteCloser{}
		listener := &gatedOwnerAcceptListener{
			stream:  stream,
			started: make(chan struct{}),
			release: make(chan struct{}),
		}
		owner := newAttemptResources(noopReadWriteCloser{}, nil)
		cancel, acceptDone := owner.startAccept(context.Background(), listener)
		<-listener.started
		cancel()
		close(listener.release)

		observable := <-acceptDone
		if observable.stream != stream || observable.err != nil {
			t.Fatalf("observable Accept result = %T, %v; want exact stream, nil", observable.stream, observable.err)
		}
		snapshot := owner.snapshot()
		if snapshot.acceptResult.stream != stream || snapshot.acceptResult.err != nil || !snapshot.transferred {
			t.Fatalf("definitive Accept state = %T, %v, transferred %t; want exact stream, nil, true", snapshot.acceptResult.stream, snapshot.acceptResult.err, snapshot.transferred)
		}
		if got := stream.closes.Load(); got != 0 {
			t.Fatalf("operation cancellation closed materialized stream %d times before terminal settlement, want 0", got)
		}
		if _, err := owner.failClosed(context.Canceled, abortAfterOwnedResources); !errors.Is(err, context.Canceled) {
			t.Fatalf("terminal settlement error = %v, want %v", err, context.Canceled)
		}
		if got := stream.closes.Load(); got != 1 {
			t.Fatalf("terminal settlement closed materialized stream %d times, want 1", got)
		}
	})
}

func TestAttemptResourcesClaimStateIsMonotonicAndActive(t *testing.T) {
	t.Parallel()

	t.Run("materialized stream resolves the transferred claim without cleanup", func(t *testing.T) {
		packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
		stream := &countingReadWriteCloser{}
		session := newFinalitySession(stream, nil)
		owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
		owner.registerSession(session)

		if snapshot := owner.snapshot(); snapshot.committed || snapshot.transferred || snapshot.claim != packetClaimBorrowed {
			t.Fatalf("initial transfer state = committed %t, transferred %t, claim %v; want borrowed", snapshot.committed, snapshot.transferred, snapshot.claim)
		}
		owner.registerCommit()
		if snapshot := owner.snapshot(); !snapshot.committed || !snapshot.transferred || snapshot.claim != packetClaimRawOwned {
			t.Fatalf("commit transfer state = committed %t, transferred %t, claim %v; want committed transferred raw-owned", snapshot.committed, snapshot.transferred, snapshot.claim)
		}

		owner.startDial(context.Background(), session, packetConn, nil, nil)
		session.dialGate.waitStarted(t)
		result := owner.joinDialForTerminal(true)
		if result.stream != stream {
			t.Fatalf("joined stream = %v, want exact stream %v", result.stream, stream)
		}
		owner.registerCommit()
		if snapshot := owner.snapshot(); !snapshot.transferred || snapshot.claim != packetClaimStreamOwned {
			t.Fatalf("materialized transfer state = (%t, %v), want stream-owned", snapshot.transferred, snapshot.claim)
		}
		if packetConn.closed.Load() {
			t.Fatal("registration closed the packet socket before terminal disposition")
		}
		if got := stream.closes.Load(); got != 0 {
			t.Fatalf("registration closed the stream %d times before terminal disposition", got)
		}
	})

	t.Run("definitive nil stream resolves the committed claim without cleanup", func(t *testing.T) {
		packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
		session := newFinalitySession(nil, errors.New("dial failed"))
		owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
		owner.registerSession(session)
		owner.registerCommit()
		owner.startDial(context.Background(), session, packetConn, nil, nil)
		session.dialGate.waitStarted(t)
		owner.joinDialForTerminal(true)

		if snapshot := owner.snapshot(); !snapshot.transferred || snapshot.claim != packetClaimRawOwned {
			t.Fatalf("nil-stream transfer state = (%t, %v), want raw-owned", snapshot.transferred, snapshot.claim)
		}
		if packetConn.closed.Load() {
			t.Fatal("registration closed the packet socket before terminal disposition")
		}
	})

	t.Run("Accept failure before commit resolves the later claim without cleanup", func(t *testing.T) {
		packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
		owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
		_, acceptDone := owner.startAccept(
			context.Background(),
			&scriptedAcceptListener{err: errors.New("accept failed")},
		)
		<-acceptDone
		owner.registerCommit()

		snapshot := owner.snapshot()
		if !snapshot.committed || !snapshot.transferred || snapshot.claim != packetClaimRawOwned {
			t.Fatalf("Accept failure then commit state = committed %t, transferred %t, claim %v; want committed and transferred with raw-owned claim", snapshot.committed, snapshot.transferred, snapshot.claim)
		}
		if packetConn.closed.Load() {
			t.Fatal("registration closed the packet socket before terminal disposition")
		}
	})
}

func TestNegotiatorUpgradePendingListenTerminalSourceMatrix(t *testing.T) {
	t.Run("definitive result preserves failed and materialized Listen shapes", func(t *testing.T) {
		resultErr := errors.New("Listen failed")
		tests := []struct {
			name     string
			listener TransportListener
			wantRow  directUpgradeListenerRow
		}{
			{name: "failure", wantRow: directUpgradeListenerRowL06F},
			{name: "materialized", listener: &fallbackJoiningListener{}, wantRow: directUpgradeListenerRowL06E},
		}
		for _, test := range tests {
			t.Run(test.name, func(t *testing.T) {
				peerFrame, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
				if err != nil {
					t.Fatalf("encode peer fallback: %v", err)
				}
				channel := newWriteTriggeredControlChannel(peerFrame, 1)
				attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
					channel:       channel,
					controlFrames: newControlFrameSequencer(channel),
					cfg: upgradeConfig{
						controlTimeout: time.Second,
					},
				})
				owner := attempt.resources()
				session := newTerminalSourceListenSession(test.listener, resultErr)
				listenDone := owner.startListen(
					context.Background(),
					session,
					nil,
					nil,
					nil,
				)
				listenResult := <-listenDone
				if listenResult.listener != test.listener || !errors.Is(listenResult.err, resultErr) {
					t.Fatalf("definitive Listen result = listener %T, error %v; want exact listener and %v", listenResult.listener, listenResult.err, resultErr)
				}
				cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerListenPending)
				engine := directUpgradeProtocolEngine{
					role:    upgradeRoleListen,
					attempt: attempt,
					session: session,
					cursor:  &cursor,
				}
				var rows []directUpgradeListenerRow
				engine.testListenerTrace = func(row directUpgradeListenerRow) {
					rows = append(rows, row)
				}
				event := directUpgradeProtocolEventListenerListenFailure
				if listenResult.listener != nil {
					event = directUpgradeProtocolEventListenerListenMaterializedError
				}
				outcome := engine.dispatchListenerEvent(
					context.Background(),
					event,
					directUpgradeProtocolActionInput{listenResult: listenResult, cause: listenResult.err},
					&directUpgradeProtocolRuntime{handoffCtx: context.Background()},
				)
				if outcome.err != nil || outcome.result.Path != UpgradePathRelay || !outcome.terminal {
					t.Fatalf("definitive Listen terminal result = %+v, %v, terminal %t; want terminal relay", outcome.result, outcome.err, outcome.terminal)
				}
				if len(rows) != 1 || rows[0] != test.wantRow {
					t.Fatalf("definitive Listen rows = %v, want [%s]", rows, test.wantRow)
				}
				snapshot := owner.snapshot()
				if snapshot.listen != attemptOperationJoined {
					t.Fatalf("definitive Listen lifecycle = %v, want joined", snapshot.listen)
				}
				if calls := session.closeCallCount(); calls != 1 {
					t.Fatalf("Session.Close calls = %d, want 1", calls)
				}
				if test.listener != nil {
					if calls := test.listener.(*fallbackJoiningListener).closeCalls.Load(); calls != 1 {
						t.Fatalf("materialized listener Close calls = %d, want 1", calls)
					}
				}
			})
		}
	})

	sources := []struct {
		name       string
		failureRow directUpgradeListenerRow
		successRow directUpgradeListenerRow
	}{
		{name: "peer_fallback", failureRow: directUpgradeListenerRowL05F, successRow: directUpgradeListenerRowL05S},
		{name: "control_error", failureRow: directUpgradeListenerRowL05EF, successRow: directUpgradeListenerRowL05ES},
		{name: "caller_cancel", failureRow: directUpgradeListenerRowL05CF, successRow: directUpgradeListenerRowL05CS},
		{name: "handoff_budget", failureRow: directUpgradeListenerRowL05TF, successRow: directUpgradeListenerRowL05TS},
	}
	for _, source := range sources {
		for _, materialized := range []bool{false, true} {
			name := "failure"
			wantRow := source.failureRow
			if materialized {
				name = "materialized"
				wantRow = source.successRow
			}
			t.Run(source.name+"/"+name, func(t *testing.T) {
				peerFrame, err := encodeUpgradeControlFallback(UpgradeFallbackProbeFailed)
				if err != nil {
					t.Fatalf("encode peer fallback: %v", err)
				}
				controlErr := errors.New("selected-frame read failed")
				var channel io.ReadWriteCloser
				var sequencer *controlFrameSequencer
				var settled func() bool
				switch source.name {
				case "peer_fallback":
					scripted := newScriptedControlChannel(peerFrame, false)
					channel = scripted
					sequencer = newControlFrameSequencer(scripted)
					settled = func() bool {
						scripted.mu.Lock()
						defer scripted.mu.Unlock()
						return scripted.writes.Len() > 0
					}
				case "control_error":
					scripted := newScriptedControlChannel(nil, true)
					channel = scripted
					sequencer = newBufferedControlFrameSequencer(controlFrameReadResult{err: controlErr})
					settled = scripted.closed.Load
				case "caller_cancel":
					scripted := newScriptedControlChannel(nil, true)
					channel = scripted
					sequencer = newControlFrameSequencer(scripted)
					settled = scripted.closed.Load
				case "handoff_budget":
					triggered := newWriteTriggeredControlChannel(peerFrame, 1)
					channel = triggered
					sequencer = newControlFrameSequencer(triggered)
					settled = func() bool {
						triggered.mu.Lock()
						defer triggered.mu.Unlock()
						return triggered.writeCount > 0
					}
				default:
					t.Fatalf("unknown source %q", source.name)
				}
				attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
					channel:       channel,
					controlFrames: sequencer,
					cfg: upgradeConfig{
						controlTimeout: time.Second,
					},
				})
				owner := attempt.resources()
				var listener TransportListener
				if materialized {
					listener = &fallbackJoiningListener{}
				}
				session, sessionObservation := newFallbackJoiningListenSession(
					listener,
					settled,
					func() {
						if state := owner.snapshot().listen; state != attemptOperationRunning {
							t.Errorf("Listen started with lifecycle %v, want running", state)
						}
					},
				)
				callerCtx, cancelCaller := context.WithCancel(context.Background())
				defer cancelCaller()
				handoffCtx, cancelHandoff := context.WithCancel(context.Background())
				defer cancelHandoff()
				cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStateListenerListenPending)
				engine := directUpgradeProtocolEngine{
					role:    upgradeRoleListen,
					attempt: attempt,
					session: session,
					cursor:  &cursor,
				}
				var rows []directUpgradeListenerRow
				engine.testListenerTrace = func(row directUpgradeListenerRow) {
					rows = append(rows, row)
				}
				runtime := directUpgradeProtocolRuntime{
					handoffCtx: handoffCtx,
					listenCh:   owner.startListen(handoffCtx, session, nil, nil, nil),
				}
				type engineOutcome struct {
					result UpgradeResult
					err    error
				}
				done := make(chan engineOutcome, 1)
				go func() {
					result, runErr := engine.awaitListenerListen(callerCtx, &runtime)
					done <- engineOutcome{result: result, err: runErr}
				}()
				<-sessionObservation.started
				switch source.name {
				case "caller_cancel":
					cancelCaller()
				case "handoff_budget":
					cancelHandoff()
				}
				outcome := <-done
				switch source.name {
				case "peer_fallback", "handoff_budget":
					if outcome.err != nil || outcome.result.Path != UpgradePathRelay {
						t.Fatalf("terminal result = %+v, %v; want relay", outcome.result, outcome.err)
					}
				case "control_error":
					if outcome.result != (UpgradeResult{}) || !errors.Is(outcome.err, controlErr) {
						t.Fatalf("terminal result = %+v, %v; want zero and %v", outcome.result, outcome.err, controlErr)
					}
				case "caller_cancel":
					if outcome.result != (UpgradeResult{}) || !errors.Is(outcome.err, context.Canceled) {
						t.Fatalf("terminal result = %+v, %v; want zero and %v", outcome.result, outcome.err, context.Canceled)
					}
				}
				if len(rows) != 1 || rows[0] != wantRow {
					t.Fatalf("listener rows = %v, want [%s]", rows, wantRow)
				}
				assertJoinedFallbackListen(t, owner, session, sessionObservation, listener)
				if !sessionObservation.settlementObserved.Load() {
					t.Fatal("Session.Close ran before control settlement")
				}
			})
		}
	}
}

func assertJoinedFallbackListen(
	t *testing.T,
	owner *attemptResources,
	session *scriptedSession,
	observation *fallbackJoiningSessionObservation,
	listener TransportListener,
) {
	t.Helper()
	snapshot := owner.snapshot()
	if snapshot.listen != attemptOperationJoined || snapshot.listener != listener {
		t.Fatalf("joined Listen state = lifecycle %v, listener %T; want joined and exact listener", snapshot.listen, snapshot.listener)
	}
	if calls := observation.listenCalls.Load(); calls != 1 {
		t.Fatalf("Session.Listen calls = %d, want 1", calls)
	}
	if calls := session.closeCallCount(); calls != 1 {
		t.Fatalf("Session.Close calls = %d, want 1", calls)
	}
	if listener != nil {
		if calls := listener.(*fallbackJoiningListener).closeCalls.Load(); calls != 1 {
			t.Fatalf("listener Close calls = %d, want 1", calls)
		}
	}
}

func TestSessionCloseUnblocksAndAttemptOwnerJoinsOperation(t *testing.T) {
	t.Run("blocking-listen", func(t *testing.T) {
		session := newBlockingListenSession()
		owner := newAttemptResources(noopReadWriteCloser{}, nil)
		owner.startListen(context.Background(), session, nil, nil, nil)
		session.listenGate.waitStarted(t)
		requireJoinedListen(t, owner)
		if !session.wasClosed() {
			t.Fatal("blockingListenSession.Close was not called")
		}
	})

	t.Run("controlled-accept", func(t *testing.T) {
		gate := newScriptedOperationGate()
		session := &scriptedSession{
			listenGate: gate,
			listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
				return newControlledAcceptListener(nil, nil, nil), nil
			},
		}
		owner := newAttemptResources(noopReadWriteCloser{}, nil)
		owner.startListen(context.Background(), session, nil, nil, nil)
		gate.waitStarted(t)
		requireJoinedListen(t, owner)
		if !session.wasClosed() {
			t.Fatal("controlledAcceptSession.Close was not called")
		}
	})

	t.Run("delayed-dial", func(t *testing.T) {
		gate := newScriptedOperationGate()
		session := &scriptedSession{
			dialGate: gate,
			dial: func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
				return nil, errors.New("delayed dial released")
			},
		}
		owner := newAttemptResources(noopReadWriteCloser{}, nil)
		owner.startDial(context.Background(), session, nil, nil, nil)
		gate.waitStarted(t)
		requireJoinedDial(t, owner)
		if !session.wasClosed() {
			t.Fatal("delayedDialSession.Close was not called")
		}
	})

	t.Run("blocking-accept", func(t *testing.T) {
		gate := newScriptedOperationGate()
		session := &scriptedSession{
			listenGate: gate,
			listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
				return newBlockingAcceptListener(), nil
			},
		}
		owner := newAttemptResources(noopReadWriteCloser{}, nil)
		owner.startListen(context.Background(), session, nil, nil, nil)
		gate.waitStarted(t)
		requireJoinedListen(t, owner)
		if !session.wasClosed() {
			t.Fatal("blockingAcceptSession.Close was not called")
		}
	})
}

func TestSessionOperationReceiverCensus(t *testing.T) {
	tests := map[string]struct {
		category string
		axis     string
		session  Session
	}{
		"compositeBlockedDialSession": {
			category: "blocking operation conformer",
			axis:     "blocks in actual composite packet I/O so only composite disposal can unblock Dial",
			session:  &compositeBlockedDialSession{},
		},
		"terminalTestSession": {
			category: "blocking operation conformer",
			axis:     "models the coupled terminal resource graph with symmetric Dial/Listen gates and cross-resource disposal ordering",
			session:  &terminalTestSession{},
		},
		"directHandoffSession": {
			category: "synchronous fixture",
			axis:     "owns paired streams, exact packet handoff, selected-remote observation, and optional Datagram capability",
			session:  &directHandoffSession{},
		},
		"scriptedSession": {
			category: "synchronous fixture",
			axis:     "central scripted callback, delegation, operation-gate, and Close-release double",
			session:  &scriptedSession{},
		},
	}

	got := testSessionOperationReceivers(t)
	want := make(map[string]struct{}, len(tests))
	for name := range tests {
		want[name] = struct{}{}
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("test Session receiver census = %v, want categorized registry %v", sortedSessionReceiverNames(got), sortedSessionReceiverNames(want))
	}

	names := sortedSessionReceiverNames(want)
	for _, name := range names {
		test := tests[name]
		t.Run(name, func(t *testing.T) {
			if test.axis == "" {
				t.Fatalf("%s has no distinct Session axis", test.category)
			}
			if test.session == nil {
				t.Fatalf("%s has no Session implementation", test.category)
			}
			receiverType := reflect.TypeOf(test.session)
			if receiverType.Kind() == reflect.Pointer {
				receiverType = receiverType.Elem()
			}
			receiverName := canonicalTestSessionReceiverName(receiverType.Name())
			if receiverName != name {
				t.Fatalf("Session receiver = %q, want registry key %q", receiverType.Name(), name)
			}
			switch test.category {
			case "blocking operation conformer", "synchronous fixture", "no-pending-result cleanup deadline fixture":
			default:
				t.Fatalf("Session receiver category = %q, want a supported census category", test.category)
			}
		})
	}

	retiredSelectors := map[string]string{
		"blockingAcceptSession":        "scripted Listen callback returning a blocking Accept listener",
		"blockingCloseSession":         "scripted Close gate",
		"blockingHandshakeSession":     "scripted handshake gate",
		"blockingListenSession":        "scripted uncancelable Listen gate released by Close",
		"blockingSession":              "scripted Close callback",
		"controlledAcceptSession":      "scripted Listen callback returning a controlled Accept listener",
		"delayedDialSession":           "scripted Dial callback with a release channel",
		"fakeSession":                  "scripted handshake, operation, and Close callbacks",
		"fallbackJoiningListenSession": "scripted Listen and Close callbacks with external observations",
		"finalityListenSession":        "scripted uncancelable Listen gate released by Close",
		"finalitySession":              "scripted uncancelable Dial gate released by Close",
		"listenBudgetRecordingSession": "scripted Listen observation callback",
		"nilListenSuccessSession":      "scripted Listen callback returning an intentional nil success",
		"registrationObservingSession": "scripted Dial and Listen observation callbacks",
		"setupDeadlineCloseSession":    "scripted handshake and Close gates",
		"stageOrderDialSession":        "scripted Dial observation callback",
		"terminalSourceListenSession":  "scripted Listen result callback",
	}
	retiredNames := make([]string, 0, len(retiredSelectors))
	for name := range retiredSelectors {
		retiredNames = append(retiredNames, name)
	}
	sort.Strings(retiredNames)
	for _, name := range retiredNames {
		capability := retiredSelectors[name]
		t.Run(name, func(t *testing.T) {
			if capability == "" {
				t.Fatal("retired Session selector has no scripted replacement capability")
			}
			if _, ok := tests["scriptedSession"]; !ok {
				t.Fatalf("retired Session selector replacement %q is not registered", capability)
			}
		})
	}
}

func TestControlChannelReceiverCensus(t *testing.T) {
	tests := map[string]struct {
		scope    string
		category string
		axis     string
		channel  io.ReadWriteCloser
	}{
		"closeCountingStream": {
			scope:    "shared stream/channel stub",
			category: "stream close counter",
			axis:     "counts transport-stream disposal while delegating stream I/O",
			channel:  &closeCountingStream{},
		},
		"closeTrackingStream": {
			scope:    "shared stream/channel stub",
			category: "stream close tracker",
			axis:     "records transport-stream closure while delegating stream I/O",
			channel:  &closeTrackingStream{},
		},
		"countingReadWriteCloser": {
			scope:    "shared stream/channel stub",
			category: "close counter",
			axis:     "counts terminal resource disposal without imposing control-protocol behavior",
			channel:  &countingReadWriteCloser{},
		},
		"datagramCapableStream": {
			scope:    "shared stream/channel stub",
			category: "Datagram-capable stream",
			axis:     "exposes the optional Datagram carrier capability independently of control framing",
			channel:  datagramCapableStream{},
		},
		"asymmetricDatagramCapableStream": {
			scope:    "shared stream/channel stub",
			category: "asymmetric Datagram stream",
			axis:     "promotes stream I/O while exposing a one-sided optional Datagram carrier",
			channel:  asymmetricDatagramCapableStream{ReadWriteCloser: noopReadWriteCloser{}},
		},
		"frameRecordingChannel": {
			scope:    "dedicated control fake",
			category: "protocol recorder",
			axis:     "records and decodes complete retry frames across arbitrary write fragmentation",
			channel:  &frameRecordingChannel{},
		},
		"noopReadWriteCloser": {
			scope:    "shared stream/channel stub",
			category: "no-op carrier",
			axis:     "provides a zero-state carrier wherever neither stream nor control behavior is under test",
			channel:  noopReadWriteCloser{},
		},
		"malformedDatagramHandoffStream": {
			scope:    "shared stream/channel stub",
			category: "malformed Datagram stream",
			axis:     "promotes stream I/O while returning an invalid optional Datagram capability",
			channel:  malformedDatagramHandoffStream{ReadWriteCloser: noopReadWriteCloser{}},
		},
		"observeCommitChannel": {
			scope:    "dedicated control fake",
			category: "causal protocol conformer",
			axis:     "recognizes a fragmented Commit trigger and orders its publication against the following read",
			channel:  &observeCommitChannel{},
		},
		"strictPeerControl": {
			scope:    "dedicated control fake",
			category: "authenticated peer control replacement",
			axis:     "replaces one complete negotiated frame while delegating carrier lifetime",
			channel:  &strictPeerControl{ReadWriteCloser: noopReadWriteCloser{}},
		},
		"scriptedControlChannel": {
			scope:    "dedicated control fake",
			category: "scripted fixture",
			axis:     "central callback, delegation, operation-gate, observation, and Close-release double",
			channel:  newScriptedControlChannel(nil, false),
		},
		"terminalTestChannel": {
			scope:    "dedicated control fake",
			category: "terminal resource conformer",
			axis:     "models coupled terminal cleanup state and direct-upgrade ownership transfer",
			channel:  &terminalTestChannel{},
		},
		"terminalTestStream": {
			scope:    "shared stream/channel stub",
			category: "terminal stream conformer",
			axis:     "models transport-stream packet ownership and coupled terminal cleanup independently of control framing",
			channel:  &terminalTestStream{},
		},
		"testPacketOwningStream": {
			scope:    "shared stream/channel stub",
			category: "packet-owning stream wrapper",
			axis:     "binds stream disposal to packet-connection ownership for transport handoff assertions",
			channel:  &testPacketOwningStream{},
		},
		"testPacketOwningDatagramStream": {
			scope:    "shared stream/channel stub",
			category: "packet-owning Datagram stream",
			axis:     "promotes packet-owning stream I/O while exposing the optional Datagram carrier",
			channel:  &testPacketOwningDatagramStream{testPacketOwningStream: &testPacketOwningStream{}},
		},
	}

	got := testControlChannelReceivers(t)
	want := make(map[string]struct{}, len(tests))
	for name := range tests {
		want[name] = struct{}{}
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("test control-channel receiver census = %v, want categorized registry %v", sortedSessionReceiverNames(got), sortedSessionReceiverNames(want))
	}

	for _, name := range sortedSessionReceiverNames(want) {
		test := tests[name]
		t.Run(name, func(t *testing.T) {
			if test.axis == "" {
				t.Fatalf("%s has no distinct control-channel axis", test.category)
			}
			switch test.scope {
			case "dedicated control fake", "shared stream/channel stub":
			default:
				t.Fatalf("control-channel receiver scope = %q, want an explicit dedicated or shared classification", test.scope)
			}
			receiverType := reflect.TypeOf(test.channel)
			if receiverType.Kind() == reflect.Pointer {
				receiverType = receiverType.Elem()
			}
			if receiverType.Name() != name {
				t.Fatalf("control-channel receiver = %q, want registry key %q", receiverType.Name(), name)
			}
		})
	}
}

func TestControlChannelReceiverDiscoveryFollowsPromotedMethodSets(t *testing.T) {
	methods := map[string]map[string]struct{}{
		"scriptedFixture":   {"Read": {}, "Write": {}, "Close": {}},
		"concreteDecorator": {"Write": {}},
	}
	embedded := map[string][]string{
		"interfaceOnlyDecorator": {embeddedReadWriteCloserInterface},
		"concreteDecorator":      {"scriptedFixture"},
	}
	want := map[string]struct{}{
		"scriptedFixture":        {},
		"interfaceOnlyDecorator": {},
		"concreteDecorator":      {},
	}
	if got := discoverReadWriteCloserReceivers(methods, embedded); !reflect.DeepEqual(got, want) {
		t.Fatalf("promoted ReadWriteCloser receivers = %v, want %v", sortedSessionReceiverNames(got), sortedSessionReceiverNames(want))
	}
}

func TestProbeRuntimeFixtureCensus(t *testing.T) {
	tests := map[string]struct {
		axis    string
		sharing string
		runtime proberuntime.Runtime
	}{
		"logicalProbeRuntime": {
			axis:    "advances one runtime directly to each receive deadline without scheduling packet events",
			sharing: "has no event scheduler to share",
			runtime: &logicalProbeRuntime{},
		},
		"scriptedProbeRuntime": {
			axis:    "runs one runtime against an ordered queue of deterministic packet and error events",
			sharing: "owns a single-runtime event queue rather than network coordination",
			runtime: newScriptedProbeRuntime(time.Time{}),
		},
		"punchProbeRuntime": {
			axis:    "coordinates multiple runtimes through NAT permissions, packet delivery, and a shared logical clock",
			sharing: "its scheduler is inseparable from the simulated network topology and cooperative parking protocol",
			runtime: &punchProbeRuntime{},
		},
	}

	got := testProbeRuntimeReceivers(t)
	want := make(map[string]struct{}, len(tests))
	for name := range tests {
		want[name] = struct{}{}
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("test probe-runtime receiver census = %v, want categorized registry %v", sortedSessionReceiverNames(got), sortedSessionReceiverNames(want))
	}

	for _, name := range sortedSessionReceiverNames(want) {
		test := tests[name]
		t.Run(name, func(t *testing.T) {
			if test.axis == "" || test.sharing == "" {
				t.Fatal("runtime fixture lacks a distinct axis or scheduler-sharing decision")
			}
			typeName := reflect.TypeOf(test.runtime).Elem().Name()
			if typeName != name {
				t.Fatalf("runtime type = %q, want registry key %q", typeName, name)
			}
		})
	}
}

func testSessionOperationReceivers(t *testing.T) map[string]struct{} {
	t.Helper()
	entries, err := os.ReadDir(".")
	if err != nil {
		t.Fatalf("read connect package: %v", err)
	}

	methodsByReceiver := make(map[string]map[string]struct{})
	files := token.NewFileSet()
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), "_test.go") {
			continue
		}
		parsed, parseErr := parser.ParseFile(files, filepath.Clean(entry.Name()), nil, parser.SkipObjectResolution)
		if parseErr != nil {
			t.Fatalf("parse %s: %v", entry.Name(), parseErr)
		}
		for _, declaration := range parsed.Decls {
			function, ok := declaration.(*ast.FuncDecl)
			if !ok || function.Recv == nil || len(function.Recv.List) != 1 {
				continue
			}
			name, ok := testSessionReceiverName(function.Recv.List[0].Type)
			if !ok {
				t.Fatalf("%s.%s uses unsupported receiver syntax %T", entry.Name(), function.Name.Name, function.Recv.List[0].Type)
			}
			if methodsByReceiver[name] == nil {
				methodsByReceiver[name] = make(map[string]struct{})
			}
			methodsByReceiver[name][function.Name.Name] = struct{}{}
		}
	}

	receivers := make(map[string]struct{})
	for receiver, methods := range methodsByReceiver {
		if hasSessionOperationMethods(methods) {
			receivers[receiver] = struct{}{}
		}
	}
	return receivers
}

func testControlChannelReceivers(t *testing.T) map[string]struct{} {
	t.Helper()
	methodsByReceiver := testReceiverMethods(t)
	embeddedReceivers := testEmbeddedReceiverTypes(t)
	return discoverReadWriteCloserReceivers(methodsByReceiver, embeddedReceivers)
}

const embeddedReadWriteCloserInterface = "io.ReadWriteCloser"

func testEmbeddedReceiverTypes(t *testing.T) map[string][]string {
	t.Helper()
	entries, err := os.ReadDir(".")
	if err != nil {
		t.Fatalf("read connect package: %v", err)
	}

	embeddedByReceiver := make(map[string][]string)
	files := token.NewFileSet()
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), "_test.go") {
			continue
		}
		parsed, parseErr := parser.ParseFile(files, filepath.Clean(entry.Name()), nil, parser.SkipObjectResolution)
		if parseErr != nil {
			t.Fatalf("parse %s: %v", entry.Name(), parseErr)
		}
		for _, declaration := range parsed.Decls {
			generic, ok := declaration.(*ast.GenDecl)
			if !ok || generic.Tok != token.TYPE {
				continue
			}
			for _, specification := range generic.Specs {
				typeSpec, ok := specification.(*ast.TypeSpec)
				if !ok {
					continue
				}
				structure, ok := typeSpec.Type.(*ast.StructType)
				if !ok {
					continue
				}
				for _, field := range structure.Fields.List {
					if len(field.Names) != 0 {
						continue
					}
					if embedded, ok := embeddedReceiverType(field.Type); ok {
						name := canonicalTestSessionReceiverName(typeSpec.Name.Name)
						embeddedByReceiver[name] = append(embeddedByReceiver[name], embedded)
					}
				}
			}
		}
	}
	return embeddedByReceiver
}

func embeddedReceiverType(expression ast.Expr) (string, bool) {
	switch expression := expression.(type) {
	case *ast.SelectorExpr:
		packageName, ok := expression.X.(*ast.Ident)
		if !ok {
			return "", false
		}
		if packageName.Name == "io" && expression.Sel.Name == "ReadWriteCloser" || packageName.Name == "net" && expression.Sel.Name == "Conn" {
			return embeddedReadWriteCloserInterface, true
		}
		return "", false
	case *ast.Ident:
		return canonicalTestSessionReceiverName(expression.Name), true
	case *ast.StarExpr:
		return embeddedReceiverType(expression.X)
	case *ast.IndexExpr:
		return embeddedReceiverType(expression.X)
	case *ast.IndexListExpr:
		return embeddedReceiverType(expression.X)
	default:
		return "", false
	}
}

func discoverReadWriteCloserReceivers(methodsByReceiver map[string]map[string]struct{}, embeddedByReceiver map[string][]string) map[string]struct{} {
	receivers := make(map[string]struct{})
	for receiver, methods := range methodsByReceiver {
		if hasReadWriteCloseMethods(methods) {
			receivers[receiver] = struct{}{}
		}
	}

	changed := true
	for changed {
		changed = false
		for receiver, embeddedTypes := range embeddedByReceiver {
			if _, ok := receivers[receiver]; ok {
				continue
			}
			for _, embedded := range embeddedTypes {
				_, knownReceiver := receivers[embedded]
				if embedded != embeddedReadWriteCloserInterface && !knownReceiver {
					continue
				}
				receivers[receiver] = struct{}{}
				changed = true
				break
			}
		}
	}
	return receivers
}

func testProbeRuntimeReceivers(t *testing.T) map[string]struct{} {
	t.Helper()
	methodsByReceiver := testReceiverMethods(t)
	receivers := make(map[string]struct{})
	for receiver, methods := range methodsByReceiver {
		if hasMethods(methods, "Now", "Send", "Receive", "Release") {
			receivers[receiver] = struct{}{}
		}
	}
	return receivers
}

func testReceiverMethods(t *testing.T) map[string]map[string]struct{} {
	t.Helper()
	entries, err := os.ReadDir(".")
	if err != nil {
		t.Fatalf("read connect package: %v", err)
	}

	methodsByReceiver := make(map[string]map[string]struct{})
	files := token.NewFileSet()
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), "_test.go") {
			continue
		}
		parsed, parseErr := parser.ParseFile(files, filepath.Clean(entry.Name()), nil, parser.SkipObjectResolution)
		if parseErr != nil {
			t.Fatalf("parse %s: %v", entry.Name(), parseErr)
		}
		for _, declaration := range parsed.Decls {
			function, ok := declaration.(*ast.FuncDecl)
			if !ok || function.Recv == nil || len(function.Recv.List) != 1 {
				continue
			}
			name, ok := testSessionReceiverName(function.Recv.List[0].Type)
			if !ok {
				t.Fatalf("%s.%s uses unsupported receiver syntax %T", entry.Name(), function.Name.Name, function.Recv.List[0].Type)
			}
			if methodsByReceiver[name] == nil {
				methodsByReceiver[name] = make(map[string]struct{})
			}
			methodsByReceiver[name][function.Name.Name] = struct{}{}
		}
	}
	return methodsByReceiver
}

func testSessionReceiverName(receiver ast.Expr) (string, bool) {
	switch expression := receiver.(type) {
	case *ast.Ident:
		return canonicalTestSessionReceiverName(expression.Name), true
	case *ast.StarExpr:
		return testSessionReceiverName(expression.X)
	case *ast.IndexExpr:
		return testSessionReceiverName(expression.X)
	case *ast.IndexListExpr:
		return testSessionReceiverName(expression.X)
	default:
		return "", false
	}
}

func canonicalTestSessionReceiverName(name string) string {
	if index := strings.IndexByte(name, '['); index >= 0 {
		return name[:index]
	}
	return name
}

func hasSessionOperationMethods(methods map[string]struct{}) bool {
	return hasMethods(methods, "HandshakeMaterial", "Dial", "Listen", "Close")
}

func hasReadWriteCloseMethods(methods map[string]struct{}) bool {
	return hasMethods(methods, "Read", "Write", "Close")
}

func hasMethods(methods map[string]struct{}, names ...string) bool {
	for _, name := range names {
		if _, ok := methods[name]; !ok {
			return false
		}
	}
	return true
}

func sortedSessionReceiverNames(receivers map[string]struct{}) []string {
	names := make([]string, 0, len(receivers))
	for name := range receivers {
		names = append(names, name)
	}
	sort.Strings(names)
	return names
}

func requireJoinedDial(t *testing.T, owner *attemptResources) transportStreamResult {
	t.Helper()
	joined := make(chan transportStreamResult, 1)
	go func() {
		joined <- owner.joinDialForTerminal(true)
	}()
	select {
	case result := <-joined:
		return result
	case <-time.After(250 * time.Millisecond):
		t.Fatal("attempt owner did not join Dial after cancellation plus Session.Close")
		return transportStreamResult{}
	}
}

func requireJoinedListen(t *testing.T, owner *attemptResources) transportListenResult {
	t.Helper()
	joined := make(chan transportListenResult, 1)
	go func() {
		joined <- owner.joinListenForTerminal(true)
	}()
	select {
	case result := <-joined:
		return result
	case <-time.After(250 * time.Millisecond):
		t.Fatal("attempt owner did not join Listen after cancellation plus Session.Close")
		return transportListenResult{}
	}
}

type registrationObservingListener struct {
	accept func()
}

func (l *registrationObservingListener) Accept(context.Context) (io.ReadWriteCloser, error) {
	l.accept()
	return noopReadWriteCloser{}, nil
}

func (*registrationObservingListener) Close() error {
	return nil
}

type scriptedAcceptListener struct {
	stream io.ReadWriteCloser
	err    error
}

func (l *scriptedAcceptListener) Accept(context.Context) (io.ReadWriteCloser, error) {
	return l.stream, l.err
}

func (*scriptedAcceptListener) Close() error {
	return nil
}

type gatedOwnerAcceptListener struct {
	stream  io.ReadWriteCloser
	started chan struct{}
	release chan struct{}
}

func (l *gatedOwnerAcceptListener) Accept(context.Context) (io.ReadWriteCloser, error) {
	close(l.started)
	<-l.release
	return l.stream, nil
}

func (*gatedOwnerAcceptListener) Close() error {
	return nil
}

func newFinalitySession(stream io.ReadWriteCloser, err error) *scriptedSession {
	gate := newUncancelableScriptedOperationGate()
	return &scriptedSession{
		dialGate:      gate,
		closeReleases: []*scriptedOperationGate{gate},
		dial: func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
			return stream, err
		},
	}
}

func newFinalityListenSession(listener TransportListener, err error) *scriptedSession {
	gate := newUncancelableScriptedOperationGate()
	return &scriptedSession{
		listenGate:    gate,
		closeReleases: []*scriptedOperationGate{gate},
		listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
			return listener, err
		},
	}
}

type fallbackJoiningSessionObservation struct {
	started            chan struct{}
	listenCalls        atomic.Int32
	settlementObserved atomic.Bool
}

func newTerminalSourceListenSession(listener TransportListener, err error) *scriptedSession {
	return &scriptedSession{listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
		return listener, err
	}}
}

func newFallbackJoiningListenSession(
	listener TransportListener,
	observeSettlement func() bool,
	observeStart func(),
) (*scriptedSession, *fallbackJoiningSessionObservation) {
	observation := &fallbackJoiningSessionObservation{started: make(chan struct{})}
	release := make(chan struct{})
	var releaseOnce sync.Once
	session := &scriptedSession{
		listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
			observation.listenCalls.Add(1)
			observeStart()
			close(observation.started)
			<-release
			return listener, nil
		},
		close: func() error {
			observation.settlementObserved.Store(observeSettlement())
			releaseOnce.Do(func() {
				close(release)
			})
			return nil
		},
	}
	return session, observation
}

type fallbackJoiningListener struct {
	closeCalls atomic.Int32
}

func (*fallbackJoiningListener) Accept(context.Context) (io.ReadWriteCloser, error) {
	panic("unexpected Accept")
}

func (l *fallbackJoiningListener) Close() error {
	l.closeCalls.Add(1)
	return nil
}
