//go:build !unix

package connect

import "net"

func ipv6WildcardAllowsIPv4(net.PacketConn) bool {
	// Non-Unix platforms use the conservative IPv6-only assumption until they
	// have a platform-specific dual-stack socket probe.
	return false
}
