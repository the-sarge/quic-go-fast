package connect

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"net/netip"
	"sync"
	"testing"
	"time"
)

const (
	// testCausalObservationTimeout bounds asynchronous test signals without
	// turning shared-runner scheduling into protocol behavior.
	testCausalObservationTimeout = 6 * time.Second
	// testRunnerSafeProbeTimeout gives classification tests setup margin when
	// probe expiry is not the behavior under test.
	testRunnerSafeProbeTimeout = time.Second
)

func TestAuthContextAdmitsIdentityLayerShapes(t *testing.T) {
	auths := []AuthContext{
		pakeAuthContext{testAuthContext()},
		noiseIKAuthContext{testAuthContext()},
		byoAuthContext{testAuthContext()},
	}

	for _, auth := range auths {
		negotiator, err := NewNegotiator(noopReadWriteCloser{}, auth)
		if err != nil {
			t.Fatalf("NewNegotiator(%T): %v", auth, err)
		}
		if negotiator == nil {
			t.Fatalf("NewNegotiator(%T) returned nil negotiator", auth)
		}
	}
}

func TestNewNegotiatorRejectsEqualDirectionalKeys(t *testing.T) {
	auth := testAuthContext()
	auth.receiveKey = append([]byte(nil), auth.sendKey...)

	_, err := NewNegotiator(noopReadWriteCloser{}, auth)
	if !errors.Is(err, ErrEqualDirectionalKeys) {
		t.Fatalf("NewNegotiator error = %v, want %v", err, ErrEqualDirectionalKeys)
	}
}

func TestNewNegotiatorRejectsEmptyDirectionalKeys(t *testing.T) {
	tests := []struct {
		name       string
		sendKey    []byte
		receiveKey []byte
	}{
		{name: "empty send key", sendKey: nil, receiveKey: []byte("receive-key")},
		{name: "empty receive key", sendKey: []byte("send-key"), receiveKey: nil},
		{name: "both empty", sendKey: nil, receiveKey: nil},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			auth := testAuthContext()
			auth.sendKey = tt.sendKey
			auth.receiveKey = tt.receiveKey

			_, err := NewNegotiator(noopReadWriteCloser{}, auth)
			if !errors.Is(err, ErrEmptyDirectionalKey) {
				t.Fatalf("NewNegotiator error = %v, want %v", err, ErrEmptyDirectionalKey)
			}
		})
	}
}

func TestNewNegotiatorRejectsInvalidDirectionalKeySizes(t *testing.T) {
	tests := []struct {
		name       string
		sendKey    []byte
		receiveKey []byte
	}{
		{
			name:       "invalid send key size",
			sendKey:    bytes.Repeat([]byte{0x01}, 20),
			receiveKey: bytes.Repeat([]byte{0x02}, 32),
		},
		{
			name:       "invalid receive key size",
			sendKey:    bytes.Repeat([]byte{0x01}, 32),
			receiveKey: bytes.Repeat([]byte{0x02}, 20),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			auth := testAuthContext()
			auth.sendKey = tt.sendKey
			auth.receiveKey = tt.receiveKey

			_, err := NewNegotiator(noopReadWriteCloser{}, auth)
			if !errors.Is(err, ErrInvalidDirectionalKeySize) {
				t.Fatalf("NewNegotiator error = %v, want %v", err, ErrInvalidDirectionalKeySize)
			}
		})
	}
}

func TestNewNegotiatorRejectsInvalidInputs(t *testing.T) {
	nilExporterAuth := testAuthContext()
	nilExporterAuth.exporter = nil

	tests := []struct {
		name    string
		channel io.ReadWriteCloser
		auth    AuthContext
		wantErr error
	}{
		{
			name:    "nil channel",
			channel: nil,
			auth:    testAuthContext(),
			wantErr: ErrNilChannel,
		},
		{
			name:    "nil auth context",
			channel: noopReadWriteCloser{},
			auth:    nil,
			wantErr: ErrNilAuthContext,
		},
		{
			name:    "nil key exporter",
			channel: noopReadWriteCloser{},
			auth:    nilExporterAuth,
			wantErr: ErrNilKeyExporter,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := NewNegotiator(tt.channel, tt.auth)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("NewNegotiator error = %v, want %v", err, tt.wantErr)
			}
			if got != nil {
				t.Fatalf("NewNegotiator returned negotiator %v, want nil", got)
			}
		})
	}
}

func TestNewNegotiatorWithTransportAuthRejectsNilTransportView(t *testing.T) {
	got, err := NewNegotiatorWithTransportAuth(noopReadWriteCloser{}, testAuthContext(), nil)
	if !errors.Is(err, ErrNilTransportAuth) {
		t.Fatalf("NewNegotiatorWithTransportAuth error = %v, want %v", err, ErrNilTransportAuth)
	}
	if got != nil {
		t.Fatalf("NewNegotiatorWithTransportAuth returned %v, want nil", got)
	}
}

func TestNewNegotiatorStoresConstructionTimeDirectionalOrientation(t *testing.T) {
	auth := testAuthContext()

	negotiator, err := NewNegotiator(noopReadWriteCloser{}, auth)
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	keys, err := NewDirectionalKeys(auth)
	if err != nil {
		t.Fatalf("NewDirectionalKeys: %v", err)
	}
	defer keys.Clear()
	if negotiator.directionalKeyOrientation != keys.Orientation() {
		t.Fatalf("directional key orientation = %v, want %v", negotiator.directionalKeyOrientation, keys.Orientation())
	}
}

func TestNegotiatorUpgradeAssignsDeterministicRoles(t *testing.T) {
	alice, bob, aliceAuth, _ := newNegotiatorPairWithAuth(t, noopReadWriteCloser{}, noopReadWriteCloser{})

	aliceRole := newDirectUpgradeAttempt(alice, upgradeConfig{transport: &fakeTransport{name: "fake-stream"}}).role()
	bobRole := newDirectUpgradeAttempt(bob, upgradeConfig{transport: &fakeTransport{name: "fake-stream"}}).role()
	if aliceRole == bobRole {
		t.Fatalf("peers both assigned role %v, want opposite dial/listen roles", aliceRole)
	}

	aliceKeys, err := NewDirectionalKeys(aliceAuth)
	if err != nil {
		t.Fatalf("NewDirectionalKeys alice: %v", err)
	}
	defer aliceKeys.Clear()
	wantAliceRole := assignUpgradeRole(aliceKeys.Orientation())
	if aliceRole != wantAliceRole {
		t.Fatalf("alice role = %v, want %v", aliceRole, wantAliceRole)
	}
}

func TestAssignUpgradeRolePinsDirectionalOrientation(t *testing.T) {
	tests := []struct {
		name        string
		orientation DirectionalKeyOrientation
		want        upgradeRole
	}{
		{
			name:        "send hash greater dials",
			orientation: DirectionalKeyOrientationSendHashGreater,
			want:        upgradeRoleDial,
		},
		{
			name:        "receive hash greater or equal listens",
			orientation: DirectionalKeyOrientationReceiveHashGreaterOrEqual,
			want:        upgradeRoleListen,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := assignUpgradeRole(tt.orientation); got != tt.want {
				t.Fatalf("assignUpgradeRole() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDirectUpgradeAttemptBuildsLocalOffer(t *testing.T) {
	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	transport := &fakeTransport{name: "fake-stream"}
	handshakeCalled := false
	session := &scriptedSession{handshake: func() []byte {
		handshakeCalled = true
		return []byte("fake-handshake-material")
	}}
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{transport: transport})
	candidates := []Candidate{{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("192.0.2.10:12345")}}
	probeNonce := bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes)
	offer, err := attempt.localOffer(context.Background(), session, candidates, probeNonce)
	if err != nil {
		t.Fatalf("localOffer: %v", err)
	}

	if offer.transportName != "fake-stream" {
		t.Fatalf("offer transport name = %q, want fake-stream", offer.transportName)
	}
	if transport.nameCalls != 1 {
		t.Fatalf("Name calls = %d, want 1", transport.nameCalls)
	}
	if !bytes.Equal(offer.handshakeMaterial, []byte("fake-handshake-material")) {
		t.Fatalf("offer handshake material = %q, want fake-handshake-material", offer.handshakeMaterial)
	}
	if !bytes.Equal(offer.probeNonce, probeNonce) {
		t.Fatalf("offer probe nonce = %x, want %x", offer.probeNonce, probeNonce)
	}
	if !equalCandidates(offer.candidates, candidates) {
		t.Fatalf("offer candidates = %#v, want %#v", offer.candidates, candidates)
	}
	if !handshakeCalled {
		t.Fatal("localOffer did not read session handshake material")
	}
	if offer.role != attempt.role() {
		t.Fatalf("offer role = %v, want %v", offer.role, attempt.role())
	}
}

func TestDirectUpgradeAttemptNilHandshakeMaterialEncodesEmptyBytes(t *testing.T) {
	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	transport := &fakeTransport{name: "fake-stream"}
	session := &scriptedSession{handshake: func() []byte { return nil }}
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{transport: transport})
	candidates := []Candidate{{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("192.0.2.10:12345")}}
	probeNonce := bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes)
	offer, err := attempt.localOffer(context.Background(), session, candidates, probeNonce)
	if err != nil {
		t.Fatalf("localOffer: %v", err)
	}

	frame, err := encodeUpgradeControlOfferForTest(offer)
	if err != nil {
		t.Fatalf("encode offer: %v", err)
	}
	peer, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("read offer: %v", err)
	}
	if !peer.HasOffer {
		t.Fatal("decoded first phase did not contain offer")
	}
	if len(peer.Offer.handshakeMaterial) != 0 {
		t.Fatalf("decoded handshake material = %x, want empty", peer.Offer.handshakeMaterial)
	}
}

func TestSessionListenReceivesSelectedRemoteAddress(t *testing.T) {
	var listenRemote net.Addr
	var listenRemoteMaterial []byte
	session := &scriptedSession{listen: func(_ context.Context, _ net.PacketConn, remote net.Addr, remoteMaterial []byte) (TransportListener, error) {
		listenRemote = remote
		listenRemoteMaterial = append([]byte(nil), remoteMaterial...)
		return nil, errors.New("fake transport listen should not run in contract test")
	}}
	remote := &net.UDPAddr{IP: net.IPv4(203, 0, 113, 7), Port: 4433}
	remoteMaterial := []byte("remote-handshake-material")

	_, _ = session.Listen(context.Background(), nil, remote, remoteMaterial)

	if listenRemote != remote {
		t.Fatalf("Listen remote = %v, want %v", listenRemote, remote)
	}
	if !bytes.Equal(listenRemoteMaterial, remoteMaterial) {
		t.Fatalf("Listen remote material = %q, want %q", listenRemoteMaterial, remoteMaterial)
	}
}

func TestTransportHandoffHelpersRejectNilSuccessResults(t *testing.T) {
	owner := newAttemptResources(nil, nil)
	nilListenSession := &scriptedSession{listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
		//nolint:nilnil // This script returns a nil listener with a nil error on purpose; that is the case under test.
		return nil, nil
	}}
	if result := <-owner.startListen(context.Background(), nilListenSession, nil, nil, nil); !errors.Is(result.err, errNilTransportListener) || result.listener != nil {
		t.Fatalf("Listen result = (%v, %v), want nil listener and %v", result.listener, result.err, errNilTransportListener)
	}

	_, acceptDone := owner.startAccept(context.Background(), nilAcceptSuccessListener{})
	if result := <-acceptDone; !errors.Is(result.err, errNilTransportStream) || result.stream != nil {
		t.Fatalf("Accept result = (%v, %v), want nil stream and %v", result.stream, result.err, errNilTransportStream)
	}
}

func TestNegotiatorUpgradeRejectsInvalidInputs(t *testing.T) {
	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	packetConnWithoutTransport := listenPacket(t, "127.0.0.1:0")
	defer packetConnWithoutTransport.Close()

	tests := []struct {
		name    string
		ctx     context.Context
		opts    []UpgradeOption
		wantErr error
	}{
		{
			name:    "nil context",
			ctx:     nil,
			wantErr: ErrNilContext,
		},
		{
			name:    "nil transport option",
			ctx:     context.Background(),
			opts:    []UpgradeOption{WithTransport(nil)},
			wantErr: ErrNilTransport,
		},
		{
			name:    "nil packet conn option",
			ctx:     context.Background(),
			opts:    []UpgradeOption{WithUpgradePacketConn(nil)},
			wantErr: ErrNilPacketConn,
		},
		{
			name:    "packet conn without transport",
			ctx:     context.Background(),
			opts:    []UpgradeOption{WithUpgradePacketConn(packetConnWithoutTransport)},
			wantErr: ErrUpgradePacketConnWithoutTransport,
		},
		{
			name:    "zero probe timeout",
			ctx:     context.Background(),
			opts:    []UpgradeOption{WithProbeTimeout(0)},
			wantErr: ErrInvalidProbeTimeout,
		},
		{
			name:    "probe concurrency too high",
			ctx:     context.Background(),
			opts:    []UpgradeOption{WithProbeConcurrency(17)},
			wantErr: ErrInvalidProbeConcurrency,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := negotiator.Upgrade(tt.ctx, tt.opts...)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("Upgrade error = %v, want %v", err, tt.wantErr)
			}
			if got != (UpgradeResult{}) {
				t.Fatalf("Upgrade result = %#v, want zero value", got)
			}
		})
	}
}

func TestNegotiatorUpgradeInvalidOptionsDoNotEnterControlMode(t *testing.T) {
	ipv4Conn := listenPacketNetwork(t, "udp4", "127.0.0.1:0")

	tests := []struct {
		name    string
		opts    []UpgradeOption
		wantErr error
	}{
		{
			name:    "zero probe timeout",
			opts:    []UpgradeOption{WithProbeTimeout(0)},
			wantErr: ErrInvalidProbeTimeout,
		},
		{
			name:    "zero control timeout",
			opts:    []UpgradeOption{WithUpgradeControlTimeout(0)},
			wantErr: ErrInvalidControlTimeout,
		},
		{
			name:    "negative control timeout",
			opts:    []UpgradeOption{WithUpgradeControlTimeout(-time.Second)},
			wantErr: ErrInvalidControlTimeout,
		},
		{
			name:    "nil STUN server",
			opts:    []UpgradeOption{WithUpgradeSTUNServer(nil)},
			wantErr: ErrInvalidSTUNServerAddress,
		},
		{
			name: "packet conn without transport takes precedence over local addr",
			opts: []UpgradeOption{WithUpgradePacketConn(localAddrPacketConn{
				PacketConn: ipv4Conn,
				localAddr:  testNetAddr("not-an-addr"),
			})},
			wantErr: ErrUpgradePacketConnWithoutTransport,
		},
		{
			name:    "malformed STUN server",
			opts:    []UpgradeOption{WithUpgradeSTUNServer(testNetAddr("not-an-addr"))},
			wantErr: ErrInvalidSTUNServerAddress,
		},
		{
			name:    "non-UDP STUN server",
			opts:    []UpgradeOption{WithUpgradeSTUNServer(tcpAddr(t, "127.0.0.1:3478"))},
			wantErr: ErrInvalidSTUNServerAddress,
		},
		{
			name:    "zero-port STUN server",
			opts:    []UpgradeOption{WithUpgradeSTUNServer(udpAddr(t, "192.0.2.1:0"))},
			wantErr: ErrInvalidSTUNServerAddress,
		},
		{
			name:    "unspecified STUN server",
			opts:    []UpgradeOption{WithUpgradeSTUNServer(udpAddr(t, "0.0.0.0:3478"))},
			wantErr: ErrInvalidSTUNServerAddress,
		},
		{
			name:    "multicast STUN server",
			opts:    []UpgradeOption{WithUpgradeSTUNServer(udpAddr(t, "224.0.0.1:3478"))},
			wantErr: ErrInvalidSTUNServerAddress,
		},
		{
			name: "packet conn incompatible with STUN server family",
			opts: []UpgradeOption{
				WithTransport(&fakeTransport{name: "fake-stream"}),
				WithUpgradePacketConn(ipv4Conn),
				WithUpgradeSTUNServer(udpAddr(t, "[2001:db8::1]:3478")),
			},
			wantErr: ErrInvalidSTUNServerAddress,
		},
		{
			name: "invalid excluded local prefix",
			opts: []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
				ExcludeLocalPrefixes: []netip.Prefix{{}},
			})},
			wantErr: ErrInvalidCandidatePolicy,
		},
		{
			name: "invalid deprioritized local prefix",
			opts: []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
				DeprioritizeLocalPrefixes: []netip.Prefix{{}},
			})},
			wantErr: ErrInvalidCandidatePolicy,
		},
		{
			name: "invalid excluded remote prefix",
			opts: []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
				ExcludeRemotePrefixes: []netip.Prefix{{}},
			})},
			wantErr: ErrInvalidCandidatePolicy,
		},
		{
			name: "invalid deprioritized remote prefix",
			opts: []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
				DeprioritizeRemotePrefixes: []netip.Prefix{{}},
			})},
			wantErr: ErrInvalidCandidatePolicy,
		},
		{
			name: "empty excluded local interface",
			opts: []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
				ExcludeLocalInterfaces: []string{""},
			})},
			wantErr: ErrInvalidCandidatePolicy,
		},
		{
			name: "whitespace deprioritized local interface",
			opts: []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
				DeprioritizeLocalInterfaces: []string{" \t"},
			})},
			wantErr: ErrInvalidCandidatePolicy,
		},
		{
			name: "invalid excluded kind",
			opts: []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
				ExcludeKinds: []CandidateKind{CandidateKind("bogus")},
			})},
			wantErr: ErrInvalidCandidatePolicy,
		},
		{
			name: "invalid deprioritized kind",
			opts: []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
				DeprioritizeKinds: []CandidateKind{CandidateKind("bogus")},
			})},
			wantErr: ErrInvalidCandidatePolicy,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			relay := newScriptedControlChannel(nil, false)
			negotiator, err := NewNegotiator(relay, testAuthContext())
			if err != nil {
				t.Fatalf("NewNegotiator: %v", err)
			}

			got, err := negotiator.Upgrade(context.Background(), tt.opts...)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("Upgrade error = %v, want %v", err, tt.wantErr)
			}
			if got != (UpgradeResult{}) {
				t.Fatalf("Upgrade result = %#v, want zero value", got)
			}
			if got := relay.writeCallCount(); got != 0 {
				t.Fatalf("relay write calls = %d, want 0", got)
			}
			if got := relay.readCallCount(); got != 0 {
				t.Fatalf("relay read calls = %d, want 0", got)
			}
		})
	}
}

func TestNegotiatorUpgradeRejectsInvalidPacketConnLocalAddrWithoutSTUN(t *testing.T) {
	tests := []struct {
		name      string
		localAddr net.Addr
	}{
		{
			name:      "nil local addr",
			localAddr: nil,
		},
		{
			name:      "unparseable local addr",
			localAddr: testNetAddr("not-an-addr"),
		},
		{
			name:      "zero-port local addr",
			localAddr: udpAddr(t, "192.0.2.10:0"),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			relay := newScriptedControlChannel(nil, false)
			negotiator, err := NewNegotiator(relay, testAuthContext())
			if err != nil {
				t.Fatalf("NewNegotiator: %v", err)
			}

			transport := &fakeTransport{name: "fake-stream"}
			conn := localAddrPacketConn{
				PacketConn: listenPacket(t, "127.0.0.1:0"),
				localAddr:  tt.localAddr,
			}

			got, err := negotiator.Upgrade(context.Background(), WithTransport(transport), WithUpgradePacketConn(conn))
			if !errors.Is(err, ErrInvalidPacketConnLocalAddr) {
				t.Fatalf("Upgrade error = %v, want %v", err, ErrInvalidPacketConnLocalAddr)
			}
			if got != (UpgradeResult{}) {
				t.Fatalf("Upgrade result = %#v, want zero value", got)
			}
			if transport.newSessionCalls != 0 {
				t.Fatalf("NewSession calls = %d, want 0", transport.newSessionCalls)
			}
			if got := relay.writeCallCount(); got != 0 {
				t.Fatalf("relay write calls = %d, want 0", got)
			}
			if got := relay.readCallCount(); got != 0 {
				t.Fatalf("relay read calls = %d, want 0", got)
			}
		})
	}
}

func TestNegotiatorUpgradeNoPacketConnSynchronizesRelayFallback(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background())
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background())
	})

	aliceOutcome := <-aliceDone
	bobOutcome := <-bobDone
	assertRelayFallbackResult(t, "alice", aliceOutcome, aliceRelay, UpgradeFallbackNotRequested)
	assertRelayFallbackResult(t, "bob", bobOutcome, bobRelay, UpgradeFallbackNotRequested)

	appBytes := []byte("application bytes after fallback")
	writeDone := make(chan error, 1)
	go func() {
		_, err := aliceOutcome.result.Stream.Write(appBytes)
		writeDone <- err
	}()

	got := make([]byte, len(appBytes))
	if _, err := io.ReadFull(bobOutcome.result.Stream, got); err != nil {
		t.Fatalf("read application bytes after fallback: %v", err)
	}
	if !bytes.Equal(got, appBytes) {
		t.Fatalf("application bytes after fallback = %q, want %q", got, appBytes)
	}
	if err := <-writeDone; err != nil {
		t.Fatalf("write application bytes after fallback: %v", err)
	}
}

func TestNegotiatorUpgradeFallbackReturnsContextErrorWhenPeerStaysSilent(t *testing.T) {
	aliceRelay, peerRelay := net.Pipe()
	defer peerRelay.Close()

	readObserved := make(chan struct{}, 1)
	writeObserved := make(chan struct{}, 1)
	closeCalled := make(chan struct{}, 1)
	relay := newObservedControlChannel(aliceRelay, readObserved, writeObserved, nil, nil, closeCalled)
	alice, err := NewNegotiator(relay, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 250*time.Millisecond)
	defer cancel()

	done := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(ctx)
	})

	startTimer := time.NewTimer(time.Second)
	defer startTimer.Stop()
	for readStarted, writeStarted := false, false; !readStarted || !writeStarted; {
		select {
		case <-readObserved:
			readStarted = true
		case <-writeObserved:
			writeStarted = true
		case outcome := <-done:
			t.Fatalf("Upgrade returned before fallback relay I/O blocked: result=%#v err=%v", outcome.result, outcome.err)
		case <-startTimer.C:
			t.Fatal("Upgrade did not enter fallback relay I/O")
		}
	}

	select {
	case outcome := <-done:
		if !errors.Is(outcome.err, context.DeadlineExceeded) {
			t.Fatalf("Upgrade error = %v, want %v", outcome.err, context.DeadlineExceeded)
		}
		if outcome.result != (UpgradeResult{}) {
			t.Fatalf("Upgrade result = %#v, want zero value", outcome.result)
		}
		select {
		case <-closeCalled:
		default:
			t.Fatal("Upgrade did not close relay after fallback control exchange timed out")
		}
	case <-time.After(time.Second):
		t.Fatal("Upgrade did not return promptly after context deadline")
	}
}

func TestNegotiatorUpgradeFallbackTimesOutWhenPeerStaysSilent(t *testing.T) {
	aliceRelay, peerRelay := net.Pipe()
	defer peerRelay.Close()

	readObserved := make(chan struct{}, 1)
	writeObserved := make(chan struct{}, 1)
	readReturned := make(chan struct{}, 1)
	writeReturned := make(chan struct{}, 1)
	closeCalled := make(chan struct{}, 1)
	relay := newObservedControlChannel(aliceRelay, readObserved, writeObserved, readReturned, writeReturned, closeCalled)
	alice, err := NewNegotiator(relay, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	done := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background(), WithUpgradeControlTimeout(50*time.Millisecond))
	})

	startTimer := time.NewTimer(time.Second)
	defer startTimer.Stop()
	for readStarted, writeStarted := false, false; !readStarted || !writeStarted; {
		select {
		case <-readObserved:
			readStarted = true
		case <-writeObserved:
			writeStarted = true
		case outcome := <-done:
			t.Fatalf("Upgrade returned before fallback relay I/O blocked: result=%#v err=%v", outcome.result, outcome.err)
		case <-startTimer.C:
			t.Fatal("Upgrade did not enter fallback relay I/O")
		}
	}

	select {
	case outcome := <-done:
		if !errors.Is(outcome.err, ErrUpgradeControlTimeout) {
			t.Fatalf("Upgrade error = %v, want %v", outcome.err, ErrUpgradeControlTimeout)
		}
		if outcome.result != (UpgradeResult{}) {
			t.Fatalf("Upgrade result = %#v, want zero value", outcome.result)
		}
		select {
		case <-closeCalled:
		default:
			t.Fatal("Upgrade did not close relay after fallback control exchange timed out")
		}
	case <-time.After(time.Second):
		t.Fatal("Upgrade did not return promptly after internal fallback timeout")
	}

	for name, returned := range map[string]<-chan struct{}{
		"read":  readReturned,
		"write": writeReturned,
	} {
		select {
		case <-returned:
		case <-time.After(time.Second):
			t.Fatalf("fallback %s goroutine did not return after timeout abort", name)
		}
	}
}

func TestNegotiatorUpgradeFirstPhaseControlTimeoutHandlesPeerSkew(t *testing.T) {
	t.Run("short timeout closes relay before peer arrives", func(t *testing.T) {
		aliceRelay, bobRelay := net.Pipe()
		defer bobRelay.Close()

		closeCalled := make(chan struct{}, 1)
		relay := newObservedControlChannel(aliceRelay, nil, nil, nil, nil, closeCalled)
		alice, err := NewNegotiator(relay, testAuthContext())
		if err != nil {
			t.Fatalf("NewNegotiator alice: %v", err)
		}

		done := runNegotiatorUpgrade(func() (UpgradeResult, error) {
			return alice.Upgrade(context.Background(), WithUpgradeControlTimeout(50*time.Millisecond))
		})

		select {
		case outcome := <-done:
			if !errors.Is(outcome.err, ErrUpgradeControlTimeout) {
				t.Fatalf("Upgrade error = %v, want %v", outcome.err, ErrUpgradeControlTimeout)
			}
			if outcome.result != (UpgradeResult{}) {
				t.Fatalf("Upgrade result = %#v, want zero value", outcome.result)
			}
			select {
			case <-closeCalled:
			default:
				t.Fatal("Upgrade did not close relay after control timeout")
			}
		case <-time.After(testCausalObservationTimeout):
			t.Fatal("Upgrade did not return promptly after control timeout")
		}
	})

	t.Run("long timeout allows delayed peer fallback", func(t *testing.T) {
		aliceRaw, bobRelay := net.Pipe()
		readStarted := make(chan struct{}, 1)
		aliceRelay := newObservedControlChannel(aliceRaw, readStarted, nil, nil, nil, nil)
		t.Cleanup(func() {
			_ = aliceRelay.Close()
			_ = bobRelay.Close()
		})
		alice, bob := newNegotiatorPair(t, aliceRelay, bobRelay)

		aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
			return alice.Upgrade(context.Background(), WithUpgradeControlTimeout(time.Second))
		})
		select {
		case <-readStarted:
		case outcome := <-aliceDone:
			t.Fatalf("alice Upgrade returned before waiting for the delayed peer: error=%v path=%v fallback=%v", outcome.err, outcome.result.Path, outcome.result.FallbackReason)
		case <-time.After(testCausalObservationTimeout):
			t.Fatal("timed out waiting for alice to enter the peer control read")
		}
		bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
			return bob.Upgrade(context.Background(), WithUpgradeControlTimeout(time.Second))
		})

		assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackNotRequested)
		assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackNotRequested)
	})
}

func TestNegotiatorUpgradeFirstPhaseFallbackWriteErrorAbortsRelay(t *testing.T) {
	writeErr := errors.New("relay write failed")
	relay := newWriteFailControlChannel(writeErr)
	negotiator, err := NewNegotiator(relay, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	got, err := negotiator.Upgrade(context.Background())
	if !errors.Is(err, writeErr) {
		t.Fatalf("Upgrade error = %v, want %v", err, writeErr)
	}
	if got != (UpgradeResult{}) {
		t.Fatalf("Upgrade result = %#v, want zero value", got)
	}
	if !relay.wasClosed() {
		t.Fatal("Upgrade did not close relay after fallback write error")
	}
}

func TestNegotiatorUpgradeNoPacketConnAcceptsPeerOfferFallback(t *testing.T) {
	aliceRelay, peerRelay := net.Pipe()
	defer aliceRelay.Close()
	defer peerRelay.Close()

	alice, err := NewNegotiator(aliceRelay, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	offerFrame := mustEncodeUpgradeControlOfferFrame(t)
	peerDone := make(chan error, 1)
	go func() {
		if _, err := readUpgradeControlFrame(peerRelay); err != nil {
			peerDone <- err
			return
		}
		peerDone <- writeFull(peerRelay, offerFrame)
	}()

	result, err := alice.Upgrade(context.Background())
	outcome := upgradeTestOutcome{result: result, err: err}
	assertRelayFallbackResult(t, "alice", outcome, aliceRelay, UpgradeFallbackNotRequested)
	if err := <-peerDone; err != nil {
		t.Fatalf("peer first-phase exchange: %v", err)
	}

	appBytes := []byte("application bytes after peer offer fallback")
	writeDone := make(chan error, 1)
	go func() {
		_, err := peerRelay.Write(appBytes)
		writeDone <- err
	}()

	got := make([]byte, len(appBytes))
	if _, err := io.ReadFull(result.Stream, got); err != nil {
		t.Fatalf("read application bytes after peer offer fallback: %v", err)
	}
	if !bytes.Equal(got, appBytes) {
		t.Fatalf("application bytes after peer offer fallback = %q, want %q", got, appBytes)
	}
	if err := <-writeDone; err != nil {
		t.Fatalf("write application bytes after peer offer fallback: %v", err)
	}
}

func TestNegotiatorUpgradeCompleteInvalidFirstPhaseFrameFallsBackToProtocolMismatch(t *testing.T) {
	aliceRelay, peerRelay := net.Pipe()
	defer aliceRelay.Close()
	defer peerRelay.Close()

	alice, err := NewNegotiator(aliceRelay, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	peerDone := make(chan error, 1)
	go func() {
		if _, err := readUpgradeControlFrame(peerRelay); err != nil {
			peerDone <- err
			return
		}
		var zeroLengthFrame [4]byte
		peerDone <- writeFull(peerRelay, zeroLengthFrame[:])
	}()

	result, err := alice.Upgrade(context.Background())
	outcome := upgradeTestOutcome{result: result, err: err}
	assertRelayFallbackResult(t, "alice", outcome, aliceRelay, UpgradeFallbackProtocolMismatch)
	if err := <-peerDone; err != nil {
		t.Fatalf("peer first-phase exchange: %v", err)
	}

	appBytes := []byte("application bytes after protocol mismatch fallback")
	writeDone := make(chan error, 1)
	go func() {
		_, err := peerRelay.Write(appBytes)
		writeDone <- err
	}()

	got := make([]byte, len(appBytes))
	if _, err := io.ReadFull(result.Stream, got); err != nil {
		t.Fatalf("read application bytes after protocol mismatch fallback: %v", err)
	}
	if !bytes.Equal(got, appBytes) {
		t.Fatalf("application bytes after protocol mismatch fallback = %q, want %q", got, appBytes)
	}
	if err := <-writeDone; err != nil {
		t.Fatalf("write application bytes after protocol mismatch fallback: %v", err)
	}
}

func TestNegotiatorUpgradeFirstPhaseFallbackReasonConvergesAsymmetrically(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()
	bobTransport := &fakeTransport{name: "fake-stream", newSessionErr: errors.New("boom")}

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background())
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background(), WithTransport(bobTransport), WithUpgradePacketConn(bobConn))
	})

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackNotRequested)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackNotRequested)
}

func TestNegotiatorUpgradeTerminalOnlyFirstPhaseReasonsFallbackToProtocolMismatch(t *testing.T) {
	tests := []struct {
		name       string
		wireReason uint64
	}{
		{
			name:       "transport mismatch",
			wireReason: 4,
		},
		{
			name:       "probe failed",
			wireReason: 6,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			aliceRelay, peerRelay := net.Pipe()
			defer aliceRelay.Close()
			defer peerRelay.Close()

			alice, err := NewNegotiator(aliceRelay, testAuthContext())
			if err != nil {
				t.Fatalf("NewNegotiator: %v", err)
			}

			peerDone := make(chan error, 1)
			go func() {
				if _, err := readUpgradeControlFrame(peerRelay); err != nil {
					peerDone <- err
					return
				}
				frame := mustEncodeUpgradeControlFrame(t, map[uint64]uint64{
					upgradeControlKeyType:           upgradeControlMessageFallback,
					upgradeControlKeyVersion:        upgradeControlVersion,
					upgradeControlKeyFallbackReason: tt.wireReason,
				})
				peerDone <- writeFull(peerRelay, frame)
			}()

			result, err := alice.Upgrade(context.Background())
			outcome := upgradeTestOutcome{result: result, err: err}
			assertRelayFallbackResult(t, "alice", outcome, aliceRelay, UpgradeFallbackProtocolMismatch)
			if err := <-peerDone; err != nil {
				t.Fatalf("peer first-phase exchange: %v", err)
			}

			appBytes := []byte("application bytes after terminal-only fallback")
			writeDone := make(chan error, 1)
			go func() {
				_, err := peerRelay.Write(appBytes)
				writeDone <- err
			}()

			got := make([]byte, len(appBytes))
			if _, err := io.ReadFull(result.Stream, got); err != nil {
				t.Fatalf("read application bytes after terminal-only fallback: %v", err)
			}
			if !bytes.Equal(got, appBytes) {
				t.Fatalf("application bytes after terminal-only fallback = %q, want %q", got, appBytes)
			}
			if err := <-writeDone; err != nil {
				t.Fatalf("write application bytes after terminal-only fallback: %v", err)
			}
		})
	}
}

func TestNegotiatorUpgradeDirectOfferRejectsTerminalOnlyFirstPhaseFallback(t *testing.T) {
	aliceRelay, peerRelay := net.Pipe()
	defer aliceRelay.Close()
	defer peerRelay.Close()

	alice, err := NewNegotiator(aliceRelay, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	conn := listenPacket(t, "127.0.0.1:0")
	defer conn.Close()

	peerDone := make(chan error, 1)
	go func() {
		if _, err := readUpgradeControlFrame(peerRelay); err != nil {
			peerDone <- err
			return
		}
		frame := mustEncodeUpgradeControlFrame(t, map[uint64]uint64{
			upgradeControlKeyType:           upgradeControlMessageFallback,
			upgradeControlKeyVersion:        upgradeControlVersion,
			upgradeControlKeyFallbackReason: 6,
		})
		peerDone <- writeFull(peerRelay, frame)
	}()

	result, err := alice.Upgrade(context.Background(), WithTransport(&fakeTransport{name: "fake-stream"}), WithUpgradePacketConn(conn))
	outcome := upgradeTestOutcome{result: result, err: err}
	assertRelayFallbackResult(t, "alice", outcome, aliceRelay, UpgradeFallbackProtocolMismatch)
	if err := <-peerDone; err != nil {
		t.Fatalf("peer first-phase exchange: %v", err)
	}
}

func TestNegotiatorUpgradeAcceptsNonQUICTransport(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceTransport := &fakeTransport{name: "fake-stream"}
	bobTransport := &fakeTransport{name: "fake-stream"}
	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background(), WithTransport(aliceTransport), WithUpgradePacketConn(aliceConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background(), WithTransport(bobTransport), WithUpgradePacketConn(bobConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
	})

	aliceOutcome := <-aliceDone
	bobOutcome := <-bobDone
	assertRelayFallbackResult(t, "alice", aliceOutcome, aliceRelay, UpgradeFallbackTransportFailed)
	assertRelayFallbackResult(t, "bob", bobOutcome, bobRelay, UpgradeFallbackTransportFailed)

	if aliceTransport.newSessionCalls != 1 {
		t.Fatalf("NewSession calls = %d, want 1", aliceTransport.newSessionCalls)
	}
	if aliceTransport.auth == nil {
		t.Fatal("NewSession did not receive auth context")
	}
	transportBinding, err := aliceTransport.auth.SessionBinding()
	if err != nil {
		t.Fatalf("NewSession auth binding: %v", err)
	}
	wantBinding := testAuthContext().SessionBinding()
	if !bytes.Equal(transportBinding, wantBinding) {
		t.Fatalf("NewSession auth binding = %q, want %q", transportBinding, wantBinding)
	}
	if !aliceTransport.handshakeCalled {
		t.Fatal("Upgrade did not read fake transport handshake material")
	}
	if aliceTransport.nameCalls != 1 {
		t.Fatalf("Name calls = %d, want 1", aliceTransport.nameCalls)
	}
	if !aliceTransport.session.wasClosed() {
		t.Fatal("Upgrade did not close temporary fake transport session")
	}
}

func TestNegotiatorUpgradeTransportWithoutPacketConnDoesNotCreateSession(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	transport := &fakeTransport{name: "fake-stream"}
	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background(), WithTransport(transport))
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background())
	})

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackNotRequested)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackNotRequested)
	if transport.newSessionCalls != 0 {
		t.Fatalf("NewSession calls = %d, want 0", transport.newSessionCalls)
	}
	if transport.nameCalls != 0 {
		t.Fatalf("Name calls = %d, want 0", transport.nameCalls)
	}
}

func TestNegotiatorUpgradeRejectsCanceledContext(t *testing.T) {
	relay := noopReadWriteCloser{}
	negotiator, err := NewNegotiator(relay, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	transport := &fakeTransport{name: "fake-stream"}
	got, err := negotiator.Upgrade(canceledContext(), WithTransport(transport))
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("Upgrade canceled context error = %v, want %v", err, context.Canceled)
	}
	if got != (UpgradeResult{}) {
		t.Fatalf("Upgrade result = %#v, want zero value", got)
	}
	if transport.newSessionCalls != 0 {
		t.Fatalf("NewSession calls = %d, want 0", transport.newSessionCalls)
	}
}

func TestNegotiatorUpgradeReturnsContextErrorWhenTransportSeesCanceledParent(t *testing.T) {
	relay := noopReadWriteCloser{}
	negotiator, err := NewNegotiator(relay, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}

	ctx, cancel := context.WithCancel(context.Background())
	transport := &fakeTransport{
		name: "fake-stream",
		newSessionHook: func(context.Context) {
			cancel()
		},
		newSessionErr: errors.New("transport observed canceled parent"),
	}
	conn := listenPacket(t, "127.0.0.1:0")
	defer conn.Close()

	got, err := negotiator.Upgrade(ctx, WithTransport(transport), WithUpgradePacketConn(conn))
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("Upgrade error = %v, want %v", err, context.Canceled)
	}
	if got != (UpgradeResult{}) {
		t.Fatalf("Upgrade result = %#v, want zero value", got)
	}
	if transport.newSessionCalls != 1 {
		t.Fatalf("NewSession calls = %d, want 1", transport.newSessionCalls)
	}
}

func TestNegotiatorUpgradeFallsBackWhenTransportSessionIgnoresSetupTimeout(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	blockingTransport := &blockingTransport{
		name:    "fake-stream",
		started: make(chan struct{}, 1),
		release: make(chan struct{}),
		closed:  make(chan struct{}, 1),
	}
	bobTransport := &fakeTransport{name: "fake-stream", newSessionErr: errors.New("boom")}

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(blockingTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(50*time.Millisecond),
			WithUpgradeControlTimeout(time.Second),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithUpgradeControlTimeout(time.Second),
		)
	})

	select {
	case <-blockingTransport.started:
	case <-time.After(time.Second):
		t.Fatal("blocking transport NewSession did not start")
	}

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackTransportFailed)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackTransportFailed)

	close(blockingTransport.release)
	select {
	case <-blockingTransport.closed:
	case <-time.After(time.Second):
		t.Fatal("late transport session was not closed after setup timeout")
	}
}

func TestNegotiatorUpgradeFallsBackWhenHandshakeMaterialIgnoresSetupTimeout(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	handshakeGate := newScriptedOperationGate()
	closed := make(chan struct{}, 1)
	session := &scriptedSession{
		handshakeGate: handshakeGate,
		handshake:     func() []byte { return []byte("late-handshake-material") },
		close: func() error {
			signal(closed)
			return nil
		},
	}
	aliceTransport := &blockingHandshakeTransport{name: "fake-stream", session: session}
	bobTransport := &fakeTransport{name: "fake-stream", newSessionErr: errors.New("boom")}

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(50*time.Millisecond),
			WithUpgradeControlTimeout(time.Second),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithUpgradeControlTimeout(time.Second),
		)
	})

	handshakeGate.waitStarted(t)

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackTransportFailed)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackTransportFailed)
	select {
	case <-closed:
	case <-time.After(time.Second):
		t.Fatal("session was not closed after handshake material timeout")
	}
	handshakeGate.release()
}

func TestNegotiatorUpgradeSessionCleanupUsesFreshTimeoutAfterSetupDeadline(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	bobConn := listenPacket(t, "127.0.0.1:0")

	handshakeGate := newScriptedOperationGate()
	closeGate := newScriptedOperationGate()
	closed := make(chan struct{}, 1)
	session := &scriptedSession{
		handshakeGate: handshakeGate,
		handshake:     func() []byte { return []byte("late-handshake-material") },
		closeGate:     closeGate,
		close: func() error {
			signal(closed)
			return nil
		},
	}
	t.Cleanup(func() {
		handshakeGate.release()
		closeGate.release()
	})
	aliceTransport := &setupDeadlineCloseTransport{name: "fake-stream", session: session}
	bobTransport := &fakeTransport{name: "fake-stream", newSessionErr: errors.New("boom")}

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(25*time.Millisecond),
			WithUpgradeControlTimeout(time.Second),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithUpgradeControlTimeout(time.Second),
		)
	})

	handshakeGate.waitStarted(t)
	var closeStartedAt time.Time
	closeGate.waitStarted(t)
	closeStartedAt = time.Now()

	aliceOutcome := <-aliceDone
	if elapsed := time.Since(closeStartedAt); elapsed < upgradeTransportSessionCleanupTimeout/2 {
		t.Fatalf("alice Upgrade returned after %s, want cleanup to wait near %s", elapsed, upgradeTransportSessionCleanupTimeout)
	}
	assertRelayFallbackResult(t, "alice", aliceOutcome, aliceRelay, UpgradeFallbackTransportFailed)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackTransportFailed)
	closeGate.release()
	handshakeGate.release()
	select {
	case <-closed:
	case <-time.After(time.Second):
		t.Fatal("session Close did not return after release")
	}
}

func TestTerminalFallbackExchangeCompletesBeforeSessionCleanupStarts(t *testing.T) {
	fallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("encode fallback: %v", err)
	}
	channel := newScriptedControlChannel(fallbackFrame, false)
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			controlTimeout: testCausalObservationTimeout,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	started := make(chan fallbackCleanupEntryObservation, 1)
	release := make(chan struct{})
	closed := make(chan struct{}, 1)
	session := &scriptedSession{
		close: func() error {
			channel.mu.Lock()
			observation := fallbackCleanupEntryObservation{
				writtenFallback:            append([]byte(nil), channel.writes.Bytes()...),
				remainingPeerFallbackBytes: channel.read.Len(),
			}
			channel.mu.Unlock()
			select {
			case started <- observation:
			default:
			}
			<-release
			signal(closed)
			return nil
		},
	}
	var releaseOnce sync.Once
	releaseCleanup := func() {
		releaseOnce.Do(func() {
			close(release)
		})
	}
	t.Cleanup(releaseCleanup)

	done := make(chan upgradeTestOutcome, 1)
	go func() {
		result, err := newTerminalFallbackExchange(attempt).withSessionCleanup(
			context.Background(),
			session,
			UpgradeFallbackTransportFailed,
		)
		done <- upgradeTestOutcome{result: result, err: err}
	}()

	var cleanupEntry fallbackCleanupEntryObservation
	select {
	case cleanupEntry = <-started:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("blocking session Close did not start")
	}
	if !bytes.Equal(cleanupEntry.writtenFallback, fallbackFrame) {
		t.Fatalf("fallback bytes at cleanup entry = %x, want %x", cleanupEntry.writtenFallback, fallbackFrame)
	}
	if cleanupEntry.remainingPeerFallbackBytes != 0 {
		t.Fatalf("peer fallback bytes remaining at cleanup entry = %d, want 0", cleanupEntry.remainingPeerFallbackBytes)
	}

	releaseCleanup()
	select {
	case <-closed:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("blocking session Close did not return after release")
	}
	assertRelayFallbackResult(
		t,
		"terminal fallback exchange",
		receiveUpgradeOutcomeWithin(t, "terminal fallback cleanup", done, testCausalObservationTimeout),
		channel,
		UpgradeFallbackTransportFailed,
	)
}

func TestNegotiatorUpgradeClosesSessionReturnedWithSetupError(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceSession := &scriptedSession{}
	bobSession := &scriptedSession{}
	aliceTransport := &fakeTransport{
		name:          "fake-stream",
		session:       aliceSession,
		newSessionErr: errors.New("alice setup failed"),
	}
	bobTransport := &fakeTransport{
		name:          "fake-stream",
		session:       bobSession,
		newSessionErr: errors.New("bob setup failed"),
	}

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background(), WithTransport(aliceTransport), WithUpgradePacketConn(aliceConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background(), WithTransport(bobTransport), WithUpgradePacketConn(bobConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
	})

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackTransportFailed)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackTransportFailed)
	if !aliceSession.wasClosed() {
		t.Fatal("alice session returned with setup error was not closed")
	}
	if !bobSession.wasClosed() {
		t.Fatal("bob session returned with setup error was not closed")
	}
}

func TestNegotiatorUpgradeFallsBackToRelayOnDirectSetupFailures(t *testing.T) {
	tests := []struct {
		name           string
		ctx            context.Context
		transport      *fakeTransport
		wantNewSession int
		wantReason     UpgradeFallbackReason
	}{
		{
			name:           "transport session error",
			ctx:            context.Background(),
			transport:      &fakeTransport{name: "fake-stream", newSessionErr: errors.New("boom")},
			wantNewSession: 1,
			wantReason:     UpgradeFallbackTransportFailed,
		},
		{
			name:           "transport session deadline with active parent context",
			ctx:            context.Background(),
			transport:      &fakeTransport{name: "fake-stream", newSessionErr: context.DeadlineExceeded},
			wantNewSession: 1,
			wantReason:     UpgradeFallbackTransportFailed,
		},
		{
			name:           "nil transport session",
			ctx:            context.Background(),
			transport:      &fakeTransport{name: "fake-stream", nilSession: true},
			wantNewSession: 1,
			wantReason:     UpgradeFallbackTransportFailed,
		},
		{
			name:           "transport session close error",
			ctx:            context.Background(),
			transport:      &fakeTransport{name: "fake-stream", closeErr: errors.New("boom")},
			wantNewSession: 1,
			wantReason:     UpgradeFallbackTransportFailed,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

			aliceConn := listenPacket(t, "127.0.0.1:0")
			defer aliceConn.Close()
			bobConn := listenPacket(t, "127.0.0.1:0")
			defer bobConn.Close()
			bobTransport := &fakeTransport{name: "fake-stream", newSessionErr: tt.transport.newSessionErr, nilSession: tt.transport.nilSession, closeErr: tt.transport.closeErr}

			aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
				return alice.Upgrade(tt.ctx, WithTransport(tt.transport), WithUpgradePacketConn(aliceConn))
			})
			bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
				return bob.Upgrade(tt.ctx, WithTransport(bobTransport), WithUpgradePacketConn(bobConn))
			})

			assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, tt.wantReason)
			assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, tt.wantReason)
			if tt.transport.newSessionCalls != tt.wantNewSession {
				t.Fatalf("alice NewSession calls = %d, want %d", tt.transport.newSessionCalls, tt.wantNewSession)
			}
			if bobTransport.newSessionCalls != tt.wantNewSession {
				t.Fatalf("bob NewSession calls = %d, want %d", bobTransport.newSessionCalls, tt.wantNewSession)
			}
		})
	}
}

func TestNegotiatorUpgradeListenerEngineHappyPathHandsOffExactPacketConnAndSelectedRemoteAddress(t *testing.T) {
	alice, bob, _, _ := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport, bobTransport := newDirectHandoffTransports("fake-stream")
	// This test exercises successful packet-socket handoff, not probe timeout
	// behavior. Leave enough budget for shared CI runners to schedule both
	// peers without changing the production default.
	const probeTimeout = time.Second

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background(), WithTransport(aliceTransport), WithUpgradePacketConn(aliceConn), WithProbeTimeout(probeTimeout))
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background(), WithTransport(bobTransport), WithUpgradePacketConn(bobConn), WithProbeTimeout(probeTimeout))
	})

	aliceOutcome := <-aliceDone
	bobOutcome := <-bobDone
	assertDirectResult(t, "alice", aliceOutcome)
	assertDirectResult(t, "bob", bobOutcome)

	appBytes := []byte("application bytes after direct handoff")
	writeDone := make(chan error, 1)
	go func() {
		_, err := aliceOutcome.result.Stream.Write(appBytes)
		writeDone <- err
	}()

	got := make([]byte, len(appBytes))
	if _, err := io.ReadFull(bobOutcome.result.Stream, got); err != nil {
		t.Fatalf("read application bytes after direct handoff: %v", err)
	}
	if !bytes.Equal(got, appBytes) {
		t.Fatalf("application bytes after direct handoff = %q, want %q", got, appBytes)
	}
	if err := <-writeDone; err != nil {
		t.Fatalf("write application bytes after direct handoff: %v", err)
	}

	assertDirectHandoff(t, "alice", aliceTransport.session, aliceConn, bobConn.LocalAddr())
	assertDirectHandoff(t, "bob", bobTransport.session, bobConn, aliceConn.LocalAddr())
	assertConvergedCandidatePairs(t, aliceOutcome.result.SelectedPair, bobOutcome.result.SelectedPair)
	if aliceOutcome.result.ProbeRTT <= 0 {
		t.Fatalf("alice probe RTT = %s, want positive", aliceOutcome.result.ProbeRTT)
	}
	if bobOutcome.result.ProbeRTT <= 0 {
		t.Fatalf("bob probe RTT = %s, want positive", bobOutcome.result.ProbeRTT)
	}
	_ = aliceOutcome.result.Stream.Close()
	_ = bobOutcome.result.Stream.Close()
	assertDirectListenerClosed(t, "alice", aliceTransport.session)
	assertDirectListenerClosed(t, "bob", bobTransport.session)
}

func TestNegotiatorUpgradeAsymmetricDatagramAdapterKeepsReliableOnlyResults(t *testing.T) {
	alice, bob, _, _ := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport, bobTransport := newDirectHandoffTransports("fake-stream")
	carrier := &stubDatagramCarrier{maxPayload: 1240, lifetime: openDatagramLifetime(t)}
	aliceTransport.streams.dialStream = asymmetricDatagramCapableStream{
		ReadWriteCloser: aliceTransport.streams.dialStream,
		carrier:         carrier,
	}

	const probeTimeout = time.Second
	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithProbeTimeout(probeTimeout),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(probeTimeout),
		)
	})

	aliceOutcome := <-aliceDone
	bobOutcome := <-bobDone
	assertDirectResult(t, "alice", aliceOutcome)
	assertDirectResult(t, "bob", bobOutcome)
	for peer, result := range map[string]UpgradeResult{
		"alice": aliceOutcome.result,
		"bob":   bobOutcome.result,
	} {
		if result.Datagrams != nil {
			t.Fatalf("%s UpgradeResult.Datagrams = %T, want nil after asymmetric exposure", peer, result.Datagrams)
		}
		if _, ok := result.Stream.(DatagramCapable); ok {
			t.Fatalf("%s UpgradeResult.Stream type %T preserved DatagramCapable", peer, result.Stream)
		}
	}

	for _, transfer := range []struct {
		name           string
		writer, reader io.ReadWriteCloser
		payload        []byte
	}{
		{name: "alice to bob", writer: aliceOutcome.result.Stream, reader: bobOutcome.result.Stream, payload: []byte("alice reliable")},
		{name: "bob to alice", writer: bobOutcome.result.Stream, reader: aliceOutcome.result.Stream, payload: []byte("bob reliable")},
	} {
		writeDone := make(chan error, 1)
		go func() {
			_, writeErr := transfer.writer.Write(transfer.payload)
			writeDone <- writeErr
		}()
		got := make([]byte, len(transfer.payload))
		if _, readErr := io.ReadFull(transfer.reader, got); readErr != nil {
			t.Fatalf("%s reliable read: %v", transfer.name, readErr)
		}
		if !bytes.Equal(got, transfer.payload) {
			t.Fatalf("%s reliable payload = %q, want %q", transfer.name, got, transfer.payload)
		}
		if writeErr := <-writeDone; writeErr != nil {
			t.Fatalf("%s reliable write: %v", transfer.name, writeErr)
		}
	}

	_ = aliceOutcome.result.Stream.Close()
	_ = bobOutcome.result.Stream.Close()
}

func TestNegotiatorUpgradeFallsBackWhenListenerSetupOutlivesReadyBudget(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport := newBlockingListenTransport("fake-stream")
	bobTransport := newBlockingListenTransport("fake-stream")

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(ctx, WithTransport(aliceTransport), WithUpgradePacketConn(aliceConn), WithProbeTimeout(150*time.Millisecond), WithUpgradeControlTimeout(time.Second))
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(ctx, WithTransport(bobTransport), WithUpgradePacketConn(bobConn), WithProbeTimeout(150*time.Millisecond), WithUpgradeControlTimeout(time.Second))
	})

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackTransportFailed)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackTransportFailed)
	if !aliceTransport.session.listenGate.wasStarted() && !bobTransport.session.listenGate.wasStarted() {
		t.Fatal("neither peer entered blocking listener setup")
	}
	if !aliceTransport.session.wasClosed() && !bobTransport.session.wasClosed() {
		t.Fatal("blocking listener setup was not closed during fallback")
	}
}

func TestNegotiatorUpgradeProbeFailureFallsBackToRelay(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{{
		name:  "test0",
		flags: net.FlagUp,
		addrs: []net.Addr{
			testNetAddr("192.0.2.10/24"),
		},
	}})

	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	defer aliceConn.Close()
	bobConn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	defer bobConn.Close()
	aliceProbeConn := &recordingPacketConn{PacketConn: aliceConn}
	bobProbeConn := &recordingPacketConn{PacketConn: bobConn}

	aliceDone := make(chan upgradeTestOutcome, 1)
	bobDone := make(chan upgradeTestOutcome, 1)
	aliceCfg := testUpgradeConfig(t,
		WithTransport(&fakeTransport{name: "fake-stream"}),
		WithUpgradePacketConn(aliceProbeConn),
		WithProbeTimeout(50*time.Millisecond),
		WithUpgradeControlTimeout(time.Second),
	)
	aliceCfg.testGatherer = gatherer
	bobCfg := testUpgradeConfig(t,
		WithTransport(&fakeTransport{name: "fake-stream"}),
		WithUpgradePacketConn(bobProbeConn),
		WithProbeTimeout(50*time.Millisecond),
		WithUpgradeControlTimeout(time.Second),
	)
	bobCfg.testGatherer = gatherer
	go func() {
		result, err := newDirectUpgradeAttempt(alice, aliceCfg).run(context.Background())
		aliceDone <- upgradeTestOutcome{result: result, err: err}
	}()
	go func() {
		result, err := newDirectUpgradeAttempt(bob, bobCfg).run(context.Background())
		bobDone <- upgradeTestOutcome{result: result, err: err}
	}()

	aliceOutcome := <-aliceDone
	bobOutcome := <-bobDone
	assertRelayFallbackResult(t, "alice", aliceOutcome, aliceRelay, UpgradeFallbackProbeFailed)
	assertRelayFallbackResult(t, "bob", bobOutcome, bobRelay, UpgradeFallbackProbeFailed)

	appBytes := []byte("application bytes after probe failure fallback")
	writeDone := make(chan error, 1)
	go func() {
		_, err := aliceOutcome.result.Stream.Write(appBytes)
		writeDone <- err
	}()

	got := make([]byte, len(appBytes))
	if _, err := io.ReadFull(bobOutcome.result.Stream, got); err != nil {
		t.Fatalf("read application bytes after probe failure fallback: %v", err)
	}
	if !bytes.Equal(got, appBytes) {
		t.Fatalf("application bytes after probe failure fallback = %q, want %q", got, appBytes)
	}
	if err := <-writeDone; err != nil {
		t.Fatalf("write application bytes after probe failure fallback: %v", err)
	}
	if aliceProbeConn.writeCalls() == 0 {
		t.Fatal("alice did not write any UDP probe datagrams")
	}
	if bobProbeConn.writeCalls() == 0 {
		t.Fatal("bob did not write any UDP probe datagrams")
	}
	if !aliceProbeConn.readDeadlineCleared() {
		t.Fatal("alice packet conn read deadline was not cleared after probe fallback")
	}
	if !bobProbeConn.readDeadlineCleared() {
		t.Fatal("bob packet conn read deadline was not cleared after probe fallback")
	}
}

func TestNegotiatorUpgradeNilHandshakeMaterialConverges(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport := &fakeTransport{name: "fake-stream", nilHandshakeMaterial: true}
	bobTransport := &fakeTransport{name: "fake-stream", nilHandshakeMaterial: true}

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background(), WithTransport(aliceTransport), WithUpgradePacketConn(aliceConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background(), WithTransport(bobTransport), WithUpgradePacketConn(bobConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
	})

	aliceOutcome := <-aliceDone
	bobOutcome := <-bobDone
	assertRelayFallbackResult(t, "alice", aliceOutcome, aliceRelay, UpgradeFallbackTransportFailed)
	assertRelayFallbackResult(t, "bob", bobOutcome, bobRelay, UpgradeFallbackTransportFailed)

	appBytes := []byte("application bytes after nil handshake fallback")
	writeDone := make(chan error, 1)
	go func() {
		_, err := aliceOutcome.result.Stream.Write(appBytes)
		writeDone <- err
	}()

	got := make([]byte, len(appBytes))
	select {
	case err := <-writeDone:
		if err != nil {
			t.Fatalf("write application bytes after nil handshake fallback: %v", err)
		}
	default:
	}
	if _, err := io.ReadFull(bobOutcome.result.Stream, got); err != nil {
		t.Fatalf("read application bytes after nil handshake fallback: %v", err)
	}
	if !bytes.Equal(got, appBytes) {
		t.Fatalf("application bytes after nil handshake fallback = %q, want %q", got, appBytes)
	}
	select {
	case err := <-writeDone:
		if err != nil {
			t.Fatalf("write application bytes after nil handshake fallback: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("write application bytes after nil handshake fallback did not complete")
	}
}

func TestNegotiatorUpgradeTransportNameMismatchTerminalFallback(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(context.Background(), WithTransport(&fakeTransport{name: "fake-stream"}), WithUpgradePacketConn(aliceConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background(), WithTransport(&fakeTransport{name: "other-stream"}), WithUpgradePacketConn(bobConn))
	})

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackTransportMismatch)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackTransportMismatch)
}

func TestNegotiatorUpgradeLocalCandidateInterfacePolicyAffectsEncodedOffer(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			name:  "vpn0",
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
			},
		},
		{
			name:  "eth0",
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("198.51.100.10/24"),
			},
		},
		{
			name:  "cell0",
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("203.0.113.10/24"),
			},
		},
	})

	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	port := conn.LocalAddr().(*net.UDPAddr).AddrPort().Port()

	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{
		packetConn:   conn,
		testGatherer: gatherer,
		candidatePolicy: CandidatePolicy{
			ExcludeLocalInterfaces:      []string{"cell0"},
			DeprioritizeLocalInterfaces: []string{"vpn0"},
		},
	})
	candidates, fallbackReason, err := attempt.localCandidates(context.Background())
	if err != nil {
		t.Fatalf("localCandidates: %v", err)
	}
	if fallbackReason != UpgradeFallbackNone {
		t.Fatalf("localCandidates fallback = %q, want none", fallbackReason)
	}

	offer := localUpgradeOffer{
		transportName:     "fake-stream",
		handshakeMaterial: []byte("fake-handshake-material"),
		probeNonce:        bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		candidates:        candidates,
	}
	frame, err := encodeUpgradeControlOfferForTest(offer)
	if err != nil {
		t.Fatalf("encode offer: %v", err)
	}
	peer, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("read offer: %v", err)
	}
	want := []Candidate{
		{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("198.51.100.10"), port)},
		{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("192.0.2.10"), port)},
	}
	if !equalCandidates(peer.Offer.candidates, want) {
		t.Fatalf("encoded offer candidates = %#v, want %#v", peer.Offer.candidates, want)
	}
}

func TestNegotiatorUpgradeExplicitBoundCandidateInterfacePolicyExcludes(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			name:  "cell0",
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
			},
		},
	})

	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  udpAddr(t, "192.0.2.10:12345"),
	}
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{
		packetConn:   conn,
		testGatherer: gatherer,
		candidatePolicy: CandidatePolicy{
			ExcludeLocalInterfaces: []string{"cell0"},
		},
	})

	candidates, fallbackReason, err := attempt.localCandidates(context.Background())
	if err != nil {
		t.Fatalf("localCandidates: %v", err)
	}
	if fallbackReason != UpgradeFallbackPolicyExcluded {
		t.Fatalf("localCandidates fallback = %q, want %q", fallbackReason, UpgradeFallbackPolicyExcluded)
	}
	if candidates != nil {
		t.Fatalf("localCandidates = %#v, want nil", candidates)
	}
}

func TestNegotiatorUpgradeScopedIPv6LocalCandidatePolicyExcludesPrefix(t *testing.T) {
	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  udpAddr(t, "[fe80::1%vpn0]:12345"),
	}
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{
		packetConn: conn,
		candidatePolicy: CandidatePolicy{
			ExcludeLocalPrefixes: []netip.Prefix{netip.MustParsePrefix("fe80::/64")},
		},
	})

	candidates, fallbackReason, err := attempt.localCandidates(context.Background())
	if err != nil {
		t.Fatalf("localCandidates: %v", err)
	}
	if fallbackReason != UpgradeFallbackPolicyExcluded {
		t.Fatalf("localCandidates fallback = %q, want %q", fallbackReason, UpgradeFallbackPolicyExcluded)
	}
	if candidates != nil {
		t.Fatalf("localCandidates = %#v, want nil", candidates)
	}
}

func TestNegotiatorUpgradeScopedIPv6LocalCandidatePolicyExcludesInterface(t *testing.T) {
	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  udpAddr(t, "[fe80::1%vpn0]:12345"),
	}
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{
		packetConn: conn,
		candidatePolicy: CandidatePolicy{
			ExcludeLocalInterfaces: []string{"vpn0"},
		},
	})

	candidates, fallbackReason, err := attempt.localCandidates(context.Background())
	if err != nil {
		t.Fatalf("localCandidates: %v", err)
	}
	if fallbackReason != UpgradeFallbackPolicyExcluded {
		t.Fatalf("localCandidates fallback = %q, want %q", fallbackReason, UpgradeFallbackPolicyExcluded)
	}
	if candidates != nil {
		t.Fatalf("localCandidates = %#v, want nil", candidates)
	}
}

func TestNegotiatorUpgradeReflexiveCandidateInterfacePolicyExcludes(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			name:  "vpn0",
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
			},
		},
	})
	gatherer.reflexive = func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return udpAddr(t, "198.51.100.40:54321"), nil
	}

	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  udpAddr(t, "192.0.2.10:12345"),
	}
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{
		packetConn:    conn,
		stunServer:    udpAddr(t, "192.0.2.1:3478"),
		stunServerSet: true,
		testGatherer:  gatherer,
		candidatePolicy: CandidatePolicy{
			ExcludeLocalInterfaces: []string{"vpn0"},
		},
	})

	candidates, fallbackReason, err := attempt.localCandidates(context.Background())
	if err != nil {
		t.Fatalf("localCandidates: %v", err)
	}
	if fallbackReason != UpgradeFallbackPolicyExcluded {
		t.Fatalf("localCandidates fallback = %q, want %q", fallbackReason, UpgradeFallbackPolicyExcluded)
	}
	if candidates != nil {
		t.Fatalf("localCandidates = %#v, want nil", candidates)
	}
}

func TestNegotiatorUpgradeWildcardReflexiveCandidateInterfacePolicyExcludesUnknown(t *testing.T) {
	gatherer := testGathererWithInterfaces(nil)
	gatherer.reflexive = func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return udpAddr(t, "198.51.100.40:54321"), nil
	}

	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{
		packetConn:    conn,
		stunServer:    udpAddr(t, "192.0.2.1:3478"),
		stunServerSet: true,
		testGatherer:  gatherer,
		candidatePolicy: CandidatePolicy{
			ExcludeLocalInterfaces: []string{"vpn0"},
		},
	})

	candidates, fallbackReason, err := attempt.localCandidates(context.Background())
	if err != nil {
		t.Fatalf("localCandidates: %v", err)
	}
	if fallbackReason != UpgradeFallbackPolicyExcluded {
		t.Fatalf("localCandidates fallback = %q, want %q", fallbackReason, UpgradeFallbackPolicyExcluded)
	}
	if candidates != nil {
		t.Fatalf("localCandidates = %#v, want nil", candidates)
	}
}

func TestCandidatePolicyDeprioritizesUnknownInterfaceReflexiveCandidate(t *testing.T) {
	unknownInterfaceReflexive := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.40:54321")}
	knownInterfaceReflexive := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "203.0.113.40:54321")}
	candidates := []gatheredCandidate{
		{candidate: unknownInterfaceReflexive},
		{candidate: knownInterfaceReflexive, localInterface: "eth0"},
	}

	got := applyLocalCandidatePolicy(candidates, CandidatePolicy{
		DeprioritizeLocalInterfaces: []string{"vpn0"},
	})

	want := []Candidate{knownInterfaceReflexive, unknownInterfaceReflexive}
	if !equalCandidates(got, want) {
		t.Fatalf("applyLocalCandidatePolicy = %#v, want %#v", got, want)
	}
}

func TestNegotiatorUpgradeReflexiveCandidateInterfacePolicyDeprioritizes(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			name:  "vpn0",
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
			},
		},
	})
	reflexiveAddr := mustAddrPort(t, "198.51.100.40:54321")
	gatherer.reflexive = func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return udpAddr(t, reflexiveAddr.String()), nil
	}

	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  udpAddr(t, "192.0.2.10:12345"),
	}
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{
		packetConn:    conn,
		stunServer:    udpAddr(t, "192.0.2.1:3478"),
		stunServerSet: true,
		testGatherer:  gatherer,
		candidatePolicy: CandidatePolicy{
			DeprioritizeLocalInterfaces: []string{"vpn0"},
		},
	})

	candidates, fallbackReason, err := attempt.localCandidates(context.Background())
	if err != nil {
		t.Fatalf("localCandidates: %v", err)
	}
	if fallbackReason != UpgradeFallbackNone {
		t.Fatalf("localCandidates fallback = %q, want none", fallbackReason)
	}
	want := []Candidate{
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")},
		{Kind: CandidateKindReflexive, Addr: reflexiveAddr},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("localCandidates = %#v, want %#v", candidates, want)
	}
}

func TestNegotiatorUpgradeExplicitBoundCandidateInterfacePolicyDeprioritizes(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			name:  "vpn0",
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
			},
		},
	})
	reflexiveAddr := udpAddr(t, "198.51.100.40:54321")
	gatherer.reflexive = func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return reflexiveAddr, nil
	}

	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  udpAddr(t, "192.0.2.10:12345"),
	}
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{
		packetConn:    conn,
		stunServer:    udpAddr(t, "192.0.2.1:3478"),
		stunServerSet: true,
		testGatherer:  gatherer,
		candidatePolicy: CandidatePolicy{
			DeprioritizeLocalInterfaces: []string{"vpn0"},
		},
	})

	candidates, fallbackReason, err := attempt.localCandidates(context.Background())
	if err != nil {
		t.Fatalf("localCandidates: %v", err)
	}
	if fallbackReason != UpgradeFallbackNone {
		t.Fatalf("localCandidates fallback = %q, want none", fallbackReason)
	}
	want := []Candidate{
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")},
		{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.40:54321")},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("localCandidates = %#v, want %#v", candidates, want)
	}
}

func TestNegotiatorUpgradeTooManyCandidatesTruncatesAndConverges(t *testing.T) {
	preferred := make([]net.Addr, 0, upgradeControlMaxCandidates)
	for i := 1; i <= upgradeControlMaxCandidates; i++ {
		preferred = append(preferred, testNetAddr(fmt.Sprintf("10.0.1.%d/24", i)))
	}
	deprioritized := make([]net.Addr, 0, 10)
	for i := 1; i <= 10; i++ {
		deprioritized = append(deprioritized, testNetAddr(fmt.Sprintf("10.0.0.%d/24", i)))
	}
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			name:  "vpn0",
			flags: net.FlagUp,
			addrs: deprioritized,
		},
		{
			name:  "eth0",
			flags: net.FlagUp,
			addrs: preferred,
		},
	})

	negotiator, err := NewNegotiator(noopReadWriteCloser{}, testAuthContext())
	if err != nil {
		t.Fatalf("NewNegotiator: %v", err)
	}
	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	attempt := newDirectUpgradeAttempt(negotiator, upgradeConfig{
		packetConn:   conn,
		testGatherer: gatherer,
		candidatePolicy: CandidatePolicy{
			DeprioritizeLocalInterfaces: []string{"vpn0"},
		},
	})
	candidates, fallbackReason, err := attempt.localCandidates(context.Background())
	if err != nil {
		t.Fatalf("localCandidates: %v", err)
	}
	if fallbackReason != UpgradeFallbackNone {
		t.Fatalf("localCandidates fallback = %q, want none", fallbackReason)
	}
	if len(candidates) != upgradeControlMaxCandidates {
		t.Fatalf("localCandidates count = %d, want %d", len(candidates), upgradeControlMaxCandidates)
	}
	for _, candidate := range candidates {
		if netip.MustParsePrefix("10.0.0.0/24").Contains(candidate.Addr.Addr()) {
			t.Fatalf("deprioritized candidate %v survived cap; want only preferred candidates", candidate)
		}
	}

	offer := localUpgradeOffer{
		transportName:     "fake-stream",
		handshakeMaterial: []byte("fake-handshake-material"),
		probeNonce:        bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		candidates:        candidates,
	}
	frame, err := encodeUpgradeControlOfferForTest(offer)
	if err != nil {
		t.Fatalf("encode offer: %v", err)
	}
	peer, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("read offer: %v", err)
	}
	if len(peer.Offer.candidates) != upgradeControlMaxCandidates {
		t.Fatalf("encoded candidate count = %d, want %d", len(peer.Offer.candidates), upgradeControlMaxCandidates)
	}

	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	defer aliceConn.Close()
	bobConn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	defer bobConn.Close()
	aliceDone := make(chan upgradeTestOutcome, 1)
	bobDone := make(chan upgradeTestOutcome, 1)
	aliceCfg := testUpgradeConfig(t,
		WithTransport(&fakeTransport{name: "fake-stream"}),
		WithUpgradePacketConn(aliceConn),
		WithCandidatePolicy(CandidatePolicy{DeprioritizeLocalInterfaces: []string{"vpn0"}}),
		WithProbeTimeout(50*time.Millisecond),
	)
	aliceCfg.testGatherer = gatherer
	bobCfg := testUpgradeConfig(t,
		WithTransport(&fakeTransport{name: "fake-stream"}),
		WithUpgradePacketConn(bobConn),
		WithCandidatePolicy(CandidatePolicy{DeprioritizeLocalInterfaces: []string{"vpn0"}}),
		WithProbeTimeout(50*time.Millisecond),
	)
	bobCfg.testGatherer = gatherer
	go func() {
		result, err := newDirectUpgradeAttempt(alice, aliceCfg).run(context.Background())
		aliceDone <- upgradeTestOutcome{result: result, err: err}
	}()
	go func() {
		result, err := newDirectUpgradeAttempt(bob, bobCfg).run(context.Background())
		bobDone <- upgradeTestOutcome{result: result, err: err}
	}()

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackProbeFailed)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackProbeFailed)
}

func TestNegotiatorUpgradeLocalCandidateGatheringSetupTimeoutFallsBack(t *testing.T) {
	stunConn := listenPacket(t, "127.0.0.1:0")
	defer stunConn.Close()

	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	aliceTransport := &fakeTransport{name: "fake-stream"}
	bobTransport := &fakeTransport{name: "fake-stream"}

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(aliceTransport),
			WithUpgradePacketConn(aliceConn),
			WithUpgradeSTUNServer(stunConn.LocalAddr()),
			WithProbeTimeout(20*time.Millisecond),
			WithUpgradeControlTimeout(time.Second),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(bobTransport),
			WithUpgradePacketConn(bobConn),
			WithUpgradeSTUNServer(stunConn.LocalAddr()),
			WithProbeTimeout(20*time.Millisecond),
			WithUpgradeControlTimeout(time.Second),
		)
	})

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackTransportFailed)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackTransportFailed)
	if !aliceTransport.session.wasClosed() {
		t.Fatal("alice temporary session was not closed after candidate gathering timeout")
	}
	if !bobTransport.session.wasClosed() {
		t.Fatal("bob temporary session was not closed after candidate gathering timeout")
	}
}

func TestNegotiatorUpgradeInvalidLocalOfferFieldsFirstPhaseFallback(t *testing.T) {
	tests := []struct {
		name      string
		transport *fakeTransport
	}{
		{
			name:      "invalid transport name",
			transport: &fakeTransport{name: "fake-stream\x00"},
		},
		{
			name: "oversized handshake material",
			transport: &fakeTransport{
				name:              "fake-stream",
				handshakeMaterial: bytes.Repeat([]byte{0x42}, upgradeControlMaxStringBytes+1),
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

			aliceConn := listenPacket(t, "127.0.0.1:0")
			bobConn := listenPacket(t, "127.0.0.1:0")
			aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
				return alice.Upgrade(context.Background(), WithTransport(tt.transport), WithUpgradePacketConn(aliceConn))
			})
			bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
				return bob.Upgrade(context.Background(), WithTransport(&fakeTransport{name: "fake-stream"}), WithUpgradePacketConn(bobConn))
			})

			assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackTransportFailed)
			assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackTransportFailed)
		})
	}
}

func TestNegotiatorUpgradeUnexpectedGatherErrorFirstPhaseFallback(t *testing.T) {
	gatherErr := errors.New("interface inventory failed")
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			name:     "eth0",
			flags:    net.FlagUp,
			addrsErr: gatherErr,
		},
	})

	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	bobConn := listenPacket(t, "127.0.0.1:0")
	aliceCfg := testUpgradeConfig(t, WithTransport(&fakeTransport{name: "fake-stream"}), WithUpgradePacketConn(aliceConn))
	aliceCfg.testGatherer = gatherer
	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return newDirectUpgradeAttempt(alice, aliceCfg).run(context.Background())
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background(), WithTransport(&fakeTransport{name: "fake-stream"}), WithUpgradePacketConn(bobConn), WithProbeTimeout(testRunnerSafeProbeTimeout))
	})

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackTransportFailed)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackTransportFailed)
}

func testUpgradeConfig(t *testing.T, opts ...UpgradeOption) upgradeConfig {
	t.Helper()

	cfg, err := newUpgradeConfig(opts)
	if err != nil {
		t.Fatalf("newUpgradeConfig: %v", err)
	}
	return cfg
}

func TestNegotiatorUpgradeLocalCandidatePolicyExhaustionFirstPhaseFallback(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	excludeLocalhost := CandidatePolicy{
		ExcludeLocalPrefixes: []netip.Prefix{netip.MustParsePrefix("127.0.0.0/8")},
	}

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(&fakeTransport{name: "fake-stream"}),
			WithUpgradePacketConn(aliceConn),
			WithCandidatePolicy(excludeLocalhost),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(context.Background(), WithTransport(&fakeTransport{name: "fake-stream"}), WithUpgradePacketConn(bobConn))
	})

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackPolicyExcluded)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackPolicyExcluded)
}

func TestNegotiatorUpgradeRemoteCandidatePolicyExhaustionTerminalFallback(t *testing.T) {
	alice, bob, aliceRelay, bobRelay := newPipeNegotiatorPair(t)

	aliceConn := listenPacket(t, "127.0.0.1:0")
	defer aliceConn.Close()
	bobConn := listenPacket(t, "127.0.0.1:0")
	defer bobConn.Close()

	excludeRemoteLoopback := CandidatePolicy{
		ExcludeRemotePrefixes: []netip.Prefix{netip.MustParsePrefix("127.0.0.0/8")},
	}

	aliceDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return alice.Upgrade(
			context.Background(),
			WithTransport(&fakeTransport{name: "fake-stream"}),
			WithUpgradePacketConn(aliceConn),
			WithCandidatePolicy(excludeRemoteLoopback),
			WithProbeTimeout(testRunnerSafeProbeTimeout),
		)
	})
	bobDone := runNegotiatorUpgrade(func() (UpgradeResult, error) {
		return bob.Upgrade(
			context.Background(),
			WithTransport(&fakeTransport{name: "fake-stream"}),
			WithUpgradePacketConn(bobConn),
			WithProbeTimeout(testRunnerSafeProbeTimeout),
		)
	})

	assertRelayFallbackResult(t, "alice", <-aliceDone, aliceRelay, UpgradeFallbackPolicyExcluded)
	assertRelayFallbackResult(t, "bob", <-bobDone, bobRelay, UpgradeFallbackPolicyExcluded)
}

func assertRelayFallbackResult(t *testing.T, peer string, outcome upgradeTestOutcome, wantStream io.ReadWriteCloser, wantReason UpgradeFallbackReason,
) {
	t.Helper()

	if outcome.err != nil {
		t.Fatalf("%s Upgrade error = %v, want nil", peer, outcome.err)
	}
	if outcome.result.Stream != wantStream {
		t.Fatalf("%s stream = %T, want relay stream", peer, outcome.result.Stream)
	}
	if outcome.result.Path != UpgradePathRelay {
		t.Fatalf("%s path = %q, want %q", peer, outcome.result.Path, UpgradePathRelay)
	}
	if outcome.result.FallbackReason != wantReason {
		t.Fatalf("%s fallback reason = %q, want %q", peer, outcome.result.FallbackReason, wantReason)
	}
	if outcome.result.SelectedPair != nil {
		t.Fatalf("%s selected pair = %#v, want nil", peer, outcome.result.SelectedPair)
	}
	if outcome.result.ProbeRTT != 0 {
		t.Fatalf("%s probe RTT = %v, want 0", peer, outcome.result.ProbeRTT)
	}
}

func assertDirectResult(t *testing.T, peer string, outcome upgradeTestOutcome,
) {
	t.Helper()

	if outcome.err != nil {
		t.Fatalf("%s Upgrade error = %v, want nil", peer, outcome.err)
	}
	if outcome.result.Stream == nil {
		t.Fatalf("%s stream = nil, want direct stream", peer)
	}
	if outcome.result.Path != UpgradePathDirect {
		t.Fatalf("%s path = %q, want %q", peer, outcome.result.Path, UpgradePathDirect)
	}
	if outcome.result.FallbackReason != UpgradeFallbackNone {
		t.Fatalf("%s fallback reason = %q, want none", peer, outcome.result.FallbackReason)
	}
	if outcome.result.SelectedPair == nil {
		t.Fatalf("%s selected pair = nil, want selected direct pair", peer)
	}
}

func assertDirectHandoff(t *testing.T, peer string, session *directHandoffSession, wantConn net.PacketConn, wantRemote net.Addr) {
	t.Helper()

	if session == nil {
		t.Fatalf("%s direct session = nil", peer)
	}
	switch {
	case session.dialConn != nil:
		if session.dialConn != wantConn {
			t.Fatalf("%s Dial conn = %p, want exact packet conn %p", peer, session.dialConn, wantConn)
		}
		if session.dialRemote.String() != wantRemote.String() {
			t.Fatalf("%s Dial remote = %v, want %v", peer, session.dialRemote, wantRemote)
		}
	case session.listenConn != nil:
		if session.listenConn != wantConn {
			t.Fatalf("%s Listen conn = %p, want exact packet conn %p", peer, session.listenConn, wantConn)
		}
		if session.listenRemote.String() != wantRemote.String() {
			t.Fatalf("%s Listen remote = %v, want %v", peer, session.listenRemote, wantRemote)
		}
	default:
		t.Fatalf("%s session did not receive Dial or Listen", peer)
	}
}

func assertConvergedCandidatePairs(t *testing.T, alicePair, bobPair *CandidatePair) {
	t.Helper()

	if alicePair == nil || bobPair == nil {
		t.Fatalf("selected pairs = alice %#v bob %#v, want both set", alicePair, bobPair)
	}
	if alicePair.Local != bobPair.Remote || alicePair.Remote != bobPair.Local {
		t.Fatalf("selected pairs did not converge: alice %#v bob %#v", alicePair, bobPair)
	}
}

func assertDirectListenerClosed(t *testing.T, peer string, session *directHandoffSession) {
	t.Helper()

	if session == nil || session.listenConn == nil {
		return
	}
	if session.listener == nil {
		t.Fatalf("%s listener = nil, want recorded listener", peer)
	}
	if !session.listener.closed {
		t.Fatalf("%s listener was not closed when returned direct stream closed", peer)
	}
}

func canceledContext() context.Context {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	return ctx
}

type (
	pakeAuthContext    struct{ authContextFixture }
	noiseIKAuthContext struct{ authContextFixture }
	byoAuthContext     struct{ authContextFixture }
)

type authContextFixture struct {
	sendKey        []byte
	receiveKey     []byte
	sessionBinding []byte
	exporter       KeyExporter
}

func testAuthContext() authContextFixture {
	return authContextFixture{
		sendKey:        bytes.Repeat([]byte{0x01}, 32),
		receiveKey:     bytes.Repeat([]byte{0x02}, 32),
		sessionBinding: []byte("session-binding"),
		exporter:       NewHKDFKeyExporter([]byte("master secret"), []byte("session-binding")),
	}
}

func (a authContextFixture) SendKey() []byte {
	return append([]byte(nil), a.sendKey...)
}

func (a authContextFixture) ReceiveKey() []byte {
	return append([]byte(nil), a.receiveKey...)
}

func (a authContextFixture) SessionBinding() []byte {
	return append([]byte(nil), a.sessionBinding...)
}

func (a authContextFixture) Exporter() KeyExporter {
	return a.exporter
}

type fakeTransport struct {
	name                 string
	auth                 TransportAuth
	nameCalls            int
	newSessionCalls      int
	session              *scriptedSession
	handshakeCalled      bool
	nilSession           bool
	nilHandshakeMaterial bool
	newSessionErr        error
	newSessionHook       func(context.Context)
	handshakeMaterial    []byte
	closeErr             error
}

func (t *fakeTransport) Name() string {
	t.nameCalls++
	return t.name
}

func (t *fakeTransport) NewSession(ctx context.Context, auth TransportAuth) (Session, error) {
	t.auth = auth
	t.newSessionCalls++
	if t.newSessionHook != nil {
		t.newSessionHook(ctx)
	}
	if t.newSessionErr != nil {
		if t.session != nil {
			return t.session, t.newSessionErr
		}
		return nil, t.newSessionErr
	}
	if t.nilSession {
		//nolint:nilnil // nilSession exists to return a nil session with a nil error and exercise the negotiator's nil-session guard.
		return nil, nil
	}
	t.session = &scriptedSession{
		handshake: func() []byte {
			t.handshakeCalled = true
			if t.nilHandshakeMaterial {
				return nil
			}
			if t.handshakeMaterial != nil {
				return append([]byte(nil), t.handshakeMaterial...)
			}
			return []byte("fake-handshake-material")
		},
		dial: func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
			return nil, errors.New("fake transport dial should not run in contract test")
		},
		listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
			return nil, errors.New("fake transport listen should not run in contract test")
		},
		close: func() error { return t.closeErr },
	}
	return t.session, nil
}

func newDirectHandoffTransports(name string) (*directHandoffTransport, *directHandoffTransport) {
	dialStream, listenStream := net.Pipe()
	shared := &directHandoffStreams{
		dialStream:   dialStream,
		listenStream: listenStream,
	}
	return &directHandoffTransport{name: name, streams: shared}, &directHandoffTransport{name: name, streams: shared}
}

type directHandoffStreams struct {
	dialStream   io.ReadWriteCloser
	listenStream io.ReadWriteCloser
}

type asymmetricDatagramCapableStream struct {
	io.ReadWriteCloser
	carrier DatagramCarrier
}

func (s asymmetricDatagramCapableStream) DatagramCarrier() (DatagramCarrier, bool) {
	return s.carrier, true
}

type directHandoffTransport struct {
	name                 string
	auth                 TransportAuth
	newSessionCalls      int
	streams              *directHandoffStreams
	session              *directHandoffSession
	handshakeMaterial    []byte
	dialDeadlineObserved chan time.Time
}

func (t *directHandoffTransport) Name() string {
	return t.name
}

func (t *directHandoffTransport) NewSession(_ context.Context, auth TransportAuth) (Session, error) {
	t.auth = auth
	t.newSessionCalls++
	t.session = &directHandoffSession{
		transport: t,
		streams:   t.streams,
	}
	return t.session, nil
}

type directHandoffSession struct {
	transport *directHandoffTransport
	streams   *directHandoffStreams

	handshakeCalled      bool
	dialConn             net.PacketConn
	dialRemote           net.Addr
	dialRemoteMaterial   []byte
	listenConn           net.PacketConn
	listenRemote         net.Addr
	listenRemoteMaterial []byte
	listener             *directHandoffListener
	closed               bool
}

func (s *directHandoffSession) HandshakeMaterial() []byte {
	s.handshakeCalled = true
	if s.transport.handshakeMaterial != nil {
		return append([]byte(nil), s.transport.handshakeMaterial...)
	}
	return []byte("fake-handshake-material")
}

func (s *directHandoffSession) Dial(ctx context.Context, conn net.PacketConn, remote net.Addr, remoteMaterial []byte) (io.ReadWriteCloser, error) {
	if s.transport.dialDeadlineObserved != nil {
		deadline, _ := ctx.Deadline()
		select {
		case s.transport.dialDeadlineObserved <- deadline:
		default:
		}
	}
	s.dialConn = conn
	s.dialRemote = remote
	s.dialRemoteMaterial = append([]byte(nil), remoteMaterial...)
	return newTestPacketOwningStream(s.streams.dialStream, conn), nil
}

func TestDirectHandoffSessionDialDeadlineObservationDoesNotBlockRepeatedDial(t *testing.T) {
	session := &directHandoffSession{
		transport: &directHandoffTransport{dialDeadlineObserved: make(chan time.Time, 1)},
		streams:   &directHandoffStreams{dialStream: noopReadWriteCloser{}},
	}
	done := make(chan error, 1)
	go func() {
		for range 2 {
			stream, err := session.Dial(context.Background(), discardTestPacketConn{}, nil, nil)
			if err != nil {
				done <- err
				return
			}
			if err := stream.Close(); err != nil {
				done <- err
				return
			}
		}
		done <- nil
	}()

	select {
	case err := <-done:
		if err != nil {
			t.Fatalf("repeated Dial: %v", err)
		}
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("repeated Dial blocked on a full deadline observation channel")
	}
}

func (s *directHandoffSession) Listen(_ context.Context, conn net.PacketConn, remote net.Addr, remoteMaterial []byte) (TransportListener, error) {
	s.listenConn = conn
	s.listenRemote = remote
	s.listenRemoteMaterial = append([]byte(nil), remoteMaterial...)
	s.listener = &directHandoffListener{stream: s.streams.listenStream, packetConn: conn}
	return s.listener, nil
}

func (s *directHandoffSession) Close() error {
	s.closed = true
	return nil
}

type directHandoffListener struct {
	stream     io.ReadWriteCloser
	packetConn net.PacketConn
	closed     bool
}

func (l *directHandoffListener) Accept(context.Context) (io.ReadWriteCloser, error) {
	return newTestPacketOwningStream(l.stream, l.packetConn), nil
}

func (l *directHandoffListener) Close() error {
	l.closed = true
	return nil
}

type testPacketOwningStream struct {
	stream     io.ReadWriteCloser
	packetConn net.PacketConn
	once       sync.Once
	err        error
}

func newTestPacketOwningStream(stream io.ReadWriteCloser, packetConn net.PacketConn) io.ReadWriteCloser {
	if stream == nil {
		return nil
	}
	owner := &testPacketOwningStream{stream: stream, packetConn: packetConn}
	if datagrams, ok := stream.(DatagramCapable); ok {
		return &testPacketOwningDatagramStream{
			testPacketOwningStream: owner,
			datagrams:              datagrams,
		}
	}
	return owner
}

func (s *testPacketOwningStream) Read(p []byte) (int, error) {
	return s.stream.Read(p)
}

func (s *testPacketOwningStream) Write(p []byte) (int, error) {
	return s.stream.Write(p)
}

func (s *testPacketOwningStream) Close() error {
	s.once.Do(func() {
		s.err = s.stream.Close()
		if s.packetConn != nil {
			_ = s.packetConn.Close()
		}
	})
	return s.err
}

type testPacketOwningDatagramStream struct {
	*testPacketOwningStream
	datagrams DatagramCapable
}

func (s *testPacketOwningDatagramStream) DatagramCarrier() (DatagramCarrier, bool) {
	return s.datagrams.DatagramCarrier()
}

type nilAcceptSuccessListener struct{}

func (nilAcceptSuccessListener) Accept(context.Context) (io.ReadWriteCloser, error) {
	//nolint:nilnil // this double returns a nil stream with a nil error on purpose; that is the case under test.
	return nil, nil
}

func (nilAcceptSuccessListener) Close() error {
	return nil
}

func newBlockingListenTransport(name string) *blockingListenTransport {
	return &blockingListenTransport{
		name:    name,
		session: newBlockingListenSession(),
	}
}

type blockingListenTransport struct {
	name    string
	session *scriptedSession
}

func (t *blockingListenTransport) Name() string {
	return t.name
}

func (t *blockingListenTransport) NewSession(context.Context, TransportAuth) (Session, error) {
	return t.session, nil
}

func newBlockingListenSession() *scriptedSession {
	gate := newUncancelableScriptedOperationGate()
	return &scriptedSession{
		listenGate:    gate,
		closeReleases: []*scriptedOperationGate{gate},
		listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
			return nil, errors.New("blocking listener setup released")
		},
	}
}

type blockingTransport struct {
	name    string
	started chan struct{}
	release chan struct{}
	closed  chan struct{}
}

func (t *blockingTransport) Name() string {
	return t.name
}

func (t *blockingTransport) NewSession(context.Context, TransportAuth) (Session, error) {
	select {
	case t.started <- struct{}{}:
	default:
	}
	<-t.release
	return &scriptedSession{
		handshakeMaterial: []byte("late-handshake-material"),
		close: func() error {
			signal(t.closed)
			return nil
		},
	}, nil
}

type blockingHandshakeTransport struct {
	name    string
	session *scriptedSession
}

func (t *blockingHandshakeTransport) Name() string {
	return t.name
}

func (t *blockingHandshakeTransport) NewSession(context.Context, TransportAuth) (Session, error) {
	return t.session, nil
}

type setupDeadlineCloseTransport struct {
	name    string
	session *scriptedSession
}

func (t *setupDeadlineCloseTransport) Name() string {
	return t.name
}

func (t *setupDeadlineCloseTransport) NewSession(context.Context, TransportAuth) (Session, error) {
	return t.session, nil
}

type fallbackCleanupEntryObservation struct {
	writtenFallback            []byte
	remainingPeerFallbackBytes int
}

type recordingPacketConn struct {
	net.PacketConn
	mu                  sync.Mutex
	writes              int
	clearedReadDeadline bool
}

func (c *recordingPacketConn) WriteTo(p []byte, addr net.Addr) (int, error) {
	c.mu.Lock()
	c.writes++
	c.mu.Unlock()
	return c.PacketConn.WriteTo(p, addr)
}

func (c *recordingPacketConn) SetReadDeadline(t time.Time) error {
	c.mu.Lock()
	if t.IsZero() {
		c.clearedReadDeadline = true
	}
	c.mu.Unlock()
	return c.PacketConn.SetReadDeadline(t)
}

func (c *recordingPacketConn) writeCalls() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.writes
}

func (c *recordingPacketConn) readDeadlineCleared() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.clearedReadDeadline
}

func signal(ch chan struct{}) {
	select {
	case ch <- struct{}{}:
	default:
	}
}
