package connect

import (
	"bytes"
	"context"
	"errors"
	"io"
	"sync/atomic"
	"testing"
	"time"
)

func TestControlFrameSequencerKeepsSinglePendingRead(t *testing.T) {
	release := make(chan struct{})
	var calls atomic.Int32
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		calls.Add(1)
		<-release
		return controlFrameReadResult{payload: []byte("frame")}
	})

	first := sequencer.next()
	second := sequencer.next()
	if first != second {
		t.Fatal("next returned a different channel while a read was pending")
	}
	waitForSequencerReadCalls(t, &calls, 1)

	close(release)
	result := awaitSequencerResult(t, first)
	if !bytes.Equal(result.payload, []byte("frame")) {
		t.Fatalf("payload = %q, want frame", result.payload)
	}
	if result.err != nil {
		t.Fatalf("result error = %v, want nil", result.err)
	}
}

func TestControlFrameSequencerUnreadPrecedesNextRead(t *testing.T) {
	reads := []controlFrameReadResult{
		{payload: []byte("first")},
		{payload: []byte("second")},
	}
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		result := reads[0]
		reads = reads[1:]
		return result
	})

	first := awaitSequencerResult(t, sequencer.next())
	sequencer.unread(first)

	replayed := awaitSequencerResult(t, sequencer.next())
	if !bytes.Equal(replayed.payload, []byte("first")) {
		t.Fatalf("replayed payload = %q, want first", replayed.payload)
	}

	second := awaitSequencerResult(t, sequencer.next())
	if !bytes.Equal(second.payload, []byte("second")) {
		t.Fatalf("second payload = %q, want second", second.payload)
	}
}

func TestControlFrameSequencerUnreadStackPrecedesNextRead(t *testing.T) {
	reads := []controlFrameReadResult{
		{payload: []byte("first")},
		{payload: []byte("second")},
		{payload: []byte("third")},
	}
	var calls atomic.Int32
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		calls.Add(1)
		result := reads[0]
		reads = reads[1:]
		return result
	})

	first := awaitSequencerResult(t, sequencer.next())
	second := awaitSequencerResult(t, sequencer.next())
	sequencer.unread(first)
	sequencer.unread(second)

	replayedSecond := awaitSequencerResult(t, sequencer.next())
	if !bytes.Equal(replayedSecond.payload, []byte("second")) {
		t.Fatalf("first replayed payload = %q, want second", replayedSecond.payload)
	}
	replayedFirst := awaitSequencerResult(t, sequencer.next())
	if !bytes.Equal(replayedFirst.payload, []byte("first")) {
		t.Fatalf("second replayed payload = %q, want first", replayedFirst.payload)
	}
	if calls.Load() != 2 {
		t.Fatalf("read calls before pushback drained = %d, want 2", calls.Load())
	}

	third := awaitSequencerResult(t, sequencer.next())
	if !bytes.Equal(third.payload, []byte("third")) {
		t.Fatalf("third payload = %q, want third", third.payload)
	}
	if calls.Load() != 3 {
		t.Fatalf("read calls after pushback drained = %d, want 3", calls.Load())
	}
}

func TestControlFrameSequencerKeepsCompletedResultUntilConsumed(t *testing.T) {
	reads := []controlFrameReadResult{
		{payload: []byte("first")},
		{payload: []byte("second")},
	}
	var calls atomic.Int32
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		calls.Add(1)
		result := reads[0]
		reads = reads[1:]
		return result
	})

	first := sequencer.next()
	waitForSequencerReadCalls(t, &calls, 1)
	waitForSequencerBufferedResult(t, first)

	second := sequencer.next()
	if second != first {
		t.Fatal("next returned a new channel while a completed result was unconsumed")
	}
	result := awaitSequencerResult(t, second)
	if !bytes.Equal(result.payload, []byte("first")) {
		t.Fatalf("payload = %q, want first", result.payload)
	}
	if calls.Load() != 1 {
		t.Fatalf("read calls = %d, want 1 before first result is consumed", calls.Load())
	}

	next := sequencer.next()
	waitForSequencerReadCalls(t, &calls, 2)
	result = awaitSequencerResult(t, next)
	if !bytes.Equal(result.payload, []byte("second")) {
		t.Fatalf("payload = %q, want second", result.payload)
	}
}

func TestControlFrameSequencerRecvReturnsFrameBeforeTimeout(t *testing.T) {
	want := []byte("frame")
	sequencer := newBufferedControlFrameSequencer(controlFrameReadResult{payload: want})

	got, err := sequencer.recv(context.Background(), time.Second)
	if err != nil {
		t.Fatalf("recv error = %v, want nil", err)
	}
	if !bytes.Equal(got.payload, want) {
		t.Fatalf("recv payload = %q, want %q", got.payload, want)
	}
}

func TestControlFrameSequencerRecvTimeoutReturnsUpgradeControlTimeout(t *testing.T) {
	releaseRead := make(chan struct{})
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		<-releaseRead
		return controlFrameReadResult{}
	})
	t.Cleanup(func() {
		close(releaseRead)
		_ = awaitSequencerResult(t, sequencer.next())
		waitForSequencerReadIdle(t, sequencer)
	})

	got, err := sequencer.recv(context.Background(), time.Millisecond)
	if !errors.Is(err, ErrUpgradeControlTimeout) {
		t.Fatalf("recv error = %v, want %v", err, ErrUpgradeControlTimeout)
	}
	if got.payload != nil {
		t.Fatalf("recv payload = %q, want nil", got.payload)
	}
}

func TestControlFrameSequencerRecvDoesNotStartReadAfterContextDone(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	readStarted := make(chan struct{}, 1)
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		readStarted <- struct{}{}
		select {}
	})

	got, err := sequencer.recv(ctx, 0)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("recv error = %v, want context canceled", err)
	}
	if got.payload != nil {
		t.Fatalf("recv payload = %q, want nil", got.payload)
	}
	select {
	case <-readStarted:
		t.Fatal("recv started a control read after context was done")
	case <-time.After(20 * time.Millisecond):
	}
}

func TestControlFrameSequencerRecvPrefersBufferedFrameAfterContextDone(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	want := []byte("confirmed")
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		return controlFrameReadResult{payload: want}
	})
	done := sequencer.next()
	waitForSequencerBufferedResult(t, done)
	cancel()

	got, err := sequencer.recv(ctx, 0)
	if err != nil {
		t.Fatalf("recv error = %v, want buffered frame", err)
	}
	if !bytes.Equal(got.payload, want) {
		t.Fatalf("recv payload = %q, want %q", got.payload, want)
	}
}

func TestControlFrameSequencerRecvPrefersContextOverBufferedReadError(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	readErr := io.ErrUnexpectedEOF
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		return controlFrameReadResult{err: readErr}
	})
	done := sequencer.next()
	waitForSequencerBufferedResult(t, done)
	cancel()

	got, err := sequencer.recv(ctx, 0)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("recv error = %v, want context canceled", err)
	}
	if errors.Is(err, readErr) {
		t.Fatalf("recv error = %v, should prefer context over read error", err)
	}
	if got.payload != nil {
		t.Fatalf("recv payload = %q, want nil", got.payload)
	}
}

func TestControlFrameSequencerRecvReturnsReadErrorWhenContextActive(t *testing.T) {
	readErr := io.ErrUnexpectedEOF
	sequencer := newBufferedControlFrameSequencer(controlFrameReadResult{err: readErr})

	got, err := sequencer.recv(context.Background(), 0)
	if !errors.Is(err, readErr) {
		t.Fatalf("recv error = %v, want %v", err, readErr)
	}
	if got.payload != nil {
		t.Fatalf("recv payload = %q, want nil", got.payload)
	}
}

func TestControlFrameSequencerUnreadPanicsWhileReadPending(t *testing.T) {
	release := make(chan struct{})
	defer close(release)

	var calls atomic.Int32
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		calls.Add(1)
		<-release
		return controlFrameReadResult{payload: []byte("frame")}
	})

	_ = sequencer.next()
	waitForSequencerReadCalls(t, &calls, 1)

	defer func() {
		if recover() == nil {
			t.Fatal("unread did not panic while read was pending")
		}
	}()
	sequencer.unread(controlFrameReadResult{payload: []byte("replayed")})
}

func waitForSequencerReadCalls(t *testing.T, calls *atomic.Int32, want int32) {
	t.Helper()

	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		if got := calls.Load(); got == want {
			return
		}
		time.Sleep(time.Millisecond)
	}
	t.Fatalf("read calls = %d, want %d", calls.Load(), want)
}

func waitForSequencerBufferedResult(t *testing.T, done <-chan controlFrameReadResult) {
	t.Helper()

	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		if len(done) > 0 {
			return
		}
		time.Sleep(time.Millisecond)
	}
	t.Fatal("timed out waiting for sequencer result to become buffered")
}

func waitForSequencerReadIdle(t *testing.T, sequencer *controlFrameSequencer) {
	t.Helper()

	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		sequencer.mu.Lock()
		readInProgress := sequencer.readInProgress
		sequencer.mu.Unlock()
		if !readInProgress {
			return
		}
		time.Sleep(time.Millisecond)
	}
	t.Fatal("timed out waiting for sequencer read to finish")
}

func awaitSequencerResult(t *testing.T, done <-chan controlFrameReadResult) controlFrameReadResult {
	t.Helper()

	select {
	case result := <-done:
		return result
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for sequencer result")
		return controlFrameReadResult{}
	}
}

func newBufferedControlFrameSequencer(results ...controlFrameReadResult) *controlFrameSequencer {
	sequencer := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		select {}
	})
	preloadControlFrameSequencer(sequencer, results...)
	return sequencer
}

func newPrefixedControlFrameSequencer(reader io.Reader, results ...controlFrameReadResult) *controlFrameSequencer {
	sequencer := newControlFrameSequencer(reader)
	preloadControlFrameSequencer(sequencer, results...)
	return sequencer
}

func preloadControlFrameSequencer(sequencer *controlFrameSequencer, results ...controlFrameReadResult) {
	for i := len(results) - 1; i >= 0; i-- {
		sequencer.unread(results[i])
	}
}
