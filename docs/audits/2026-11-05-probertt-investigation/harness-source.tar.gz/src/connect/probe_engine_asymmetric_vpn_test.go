package connect

import (
	"bytes"
	"context"
	"fmt"
	"net"
	"net/netip"
	"testing"
	"time"
)

// These tests retain the deterministic in-repo diagnosis for issue #1006 and
// verify its repeated-complete-pass correction. The field failure reproduced
// without tunnel candidates: one peer selected a viable reflexive×reflexive
// pair while the other reported upgrade fallback reason "probe_failed" after
// its only request burst missed the effective punch window.
//
// The suite isolates the candidate mechanisms one by one:
//
//   - Pair ranking: the viable reflexive×reflexive pair ranks dead last on
//     both peers, behind every host×host pair including unroutable tunnel
//     pairs (TestPlanProbeCandidatePairsRanksViableReflexivePairLastOnBothPeers).
//   - Never-scheduled budget exhaustion: packet-swallowing dead pairs occupy
//     probe slots for one full frozen retry schedule (60-75ms) each, so the
//     serialized cursor starves the last-ranked viable pair only once
//     roughly 160-200 dead pairs precede it at the default 3s probe timeout
//     and concurrency 4 — far beyond field-realistic candidate counts
//     (TestProbeCandidatePairPlanStarvesViablePairOnlyBeyondDeadPairBudget).
//   - Success withholding and deadline discard: a recorded success on the
//     viable pair is withheld until every already-active higher-ranked pair
//     exhausts and is discarded outright when the attempt deadline lands first
//     (TestProbePairsWithholdsViableSuccessUntilHigherRankedDeadPairExhausts,
//     TestProbeCandidatePairPlanDiscardsWithheldViableSuccessAtAttemptDeadline).
//   - Prior-pass success settlement: once authenticated success freezes new
//     admissions, inactive higher-ranked pairs do not delay selection
//     (TestProbeCandidatePairPlanSettlesPriorPassSuccessWithLaterRanksUnscheduled).
//   - Cross-peer schedule desynchronization: the original single-pass engine
//     gave the viable pair one three-request burst 40-50ms wide. The retained
//     scenarios now prove later complete passes recover both a late punch and
//     a 300ms peer-start skew, including when the listener validates first and
//     must remain response-capable for the dialer's next pass
//     (TestProbeCandidatePairPlanRepeatedPassSelectsLatePunchBeforeDeadline,
//     TestTwoPeerProbeStartSkewConvergesOnRepeatedSchedulePass,
//     TestTwoPeerProbeFirstListenerSuccessRemainsResponsiveUntilDialerConverges).
//
// All timing assertions rely only on the frozen retry schedule bounds: each
// probe retry delay is probeRetryInterval plus at most probeRetryJitter, so a
// pair's slot hold is in [3*probeRetryInterval, 3*(probeRetryInterval+
// probeRetryJitter)] = [60ms, 75ms] and its three requests span at most
// 2*(probeRetryInterval+probeRetryJitter) = 50ms. The tests therefore stay
// deterministic under the unseedable crypto/rand jitter.

// asymmetricVPNFixture is the field-shaped topology from issue #1006: the
// dialer (join side, no VPN) has one host candidate plus its reflexive
// candidate; the listener (share side, VPN up) additionally advertises a
// tunnel-interface host candidate in the CGNAT range. Candidate lists are in
// production advertisement order: host candidates sorted by address, then the
// reflexive candidate.
type asymmetricVPNFixture struct {
	dialerHost   Candidate
	dialerRefl   Candidate
	listenerHost Candidate
	listenerTun  Candidate
	listenerRefl Candidate
}

func newAsymmetricVPNFixture(t *testing.T) asymmetricVPNFixture {
	t.Helper()
	return asymmetricVPNFixture{
		dialerHost:   Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.168.1.10:40000")},
		dialerRefl:   Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "203.0.113.10:40000")},
		listenerHost: Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.168.50.20:41000")},
		listenerTun:  Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "100.64.17.5:41000")},
		listenerRefl: Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.20:41000")},
	}
}

func (f asymmetricVPNFixture) dialerLocals() []Candidate {
	return []Candidate{f.dialerHost, f.dialerRefl}
}

func (f asymmetricVPNFixture) listenerLocals() []Candidate {
	return []Candidate{f.listenerTun, f.listenerHost, f.listenerRefl}
}

func (f asymmetricVPNFixture) listenerLocalsWithoutTunnel() []Candidate {
	return []Candidate{f.listenerHost, f.listenerRefl}
}

func dialerProbeNonce() []byte {
	return bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes)
}

func listenerProbeNonce() []byte {
	return bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes)
}

// derivedDialProbeKey mirrors the probe key probeCandidatePairPlan derives for
// the dial role from the shared test auth context and the fixed probe nonces.
func derivedDialProbeKey(t *testing.T) []byte {
	t.Helper()
	key, err := deriveProbeKey(testAuthContext().Exporter(), dialerProbeNonce(), listenerProbeNonce())
	if err != nil {
		t.Fatalf("deriveProbeKey: %v", err)
	}
	return key
}

// viablePairPeerScript records the dialer-side probe requests on the viable
// candidate pair and answers them only once the scripted peer's hole punch is
// open. Every other probe datagram is swallowed silently, matching
// packet-swallowing dead candidates rather than send-erroring ones.
type viablePairPeerScript struct {
	requestTimes []time.Duration
	responses    int
}

func scriptViablePairPeer(
	t *testing.T,
	runtime *scriptedProbeRuntime,
	key []byte,
	viableLocal Candidate,
	viableRemote Candidate,
	punchOpen time.Duration,
) *viablePairPeerScript {
	t.Helper()
	script := &viablePairPeerScript{}
	start := runtime.Now()
	viableToken, err := probeCandidatePairToken(key, probeDirectionDialerToListener, viableLocal, viableRemote)
	if err != nil {
		t.Fatalf("probeCandidatePairToken: %v", err)
	}
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest || !bytes.Equal(decoded.Token[:], viableToken) {
			return nil // dead candidate pair: swallowed without a send error
		}
		elapsed := runtime.now.Sub(start)
		script.requestTimes = append(script.requestTimes, elapsed)
		if elapsed < punchOpen {
			return nil // the peer's punch is not open yet: dropped at the peer's NAT
		}
		script.responses++
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, decoded.ProbeID, viableRemote, viableLocal)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(viableRemote.Addr), nil)
		return nil
	}
	return script
}

func runDialProbeCandidatePairPlan(
	t *testing.T,
	runtime *scriptedProbeRuntime,
	probeTimeout time.Duration,
	pairPlan candidatePairPlan,
	localAddr netip.AddrPort,
) candidatePairProbeResult {
	t.Helper()
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		auth: testAuthContext(),
		cfg: upgradeConfig{
			packetConn:   &runtimeProviderPacketConn{runtime: runtime, local: localAddr},
			probeTimeout: probeTimeout,
		},
	})
	local := localUpgradeOffer{role: upgradeRoleDial, probeNonce: dialerProbeNonce()}
	peer := localUpgradeOffer{probeNonce: listenerProbeNonce()}
	result, err := attempt.probeCandidatePairPlan(context.Background(), local, peer, pairPlan)
	if err != nil {
		t.Fatalf("probeCandidatePairPlan: %v", err)
	}
	return result
}

func assertSelectedViablePair(t *testing.T, result candidatePairProbeResult, local, remote Candidate) {
	t.Helper()
	if !result.succeeded {
		t.Fatalf("probe did not succeed on the viable pair: %#v", result)
	}
	if result.pair.local != local || result.pair.remote != remote {
		t.Fatalf("selected pair = %#v, want local %#v remote %#v", result.pair, local, remote)
	}
}

// TestPlanProbeCandidatePairsRanksViableReflexivePairLastOnBothPeers pins the
// ranking property behind the field failure: pair rank uses the maximum of
// the two candidate kinds, so the only viable pair — reflexive×reflexive —
// sorts behind every host×host pair, including pairs built from unroutable
// tunnel-interface candidates, on both peers.
func TestPlanProbeCandidatePairsRanksViableReflexivePairLastOnBothPeers(t *testing.T) {
	f := newAsymmetricVPNFixture(t)

	dialerPlan := planProbeCandidatePairs(f.dialerLocals(), f.listenerLocals(), CandidatePolicy{}, upgradeRoleDial)
	wantDialer := []probeCandidatePair{
		{local: f.dialerHost, remote: f.listenerTun},
		{local: f.dialerHost, remote: f.listenerHost},
		{local: f.dialerHost, remote: f.listenerRefl},
		{local: f.dialerRefl, remote: f.listenerTun},
		{local: f.dialerRefl, remote: f.listenerHost},
		{local: f.dialerRefl, remote: f.listenerRefl},
	}
	assertProbeCandidatePairs(t, dialerPlan.pairs, wantDialer)

	listenerPlan := planProbeCandidatePairs(f.listenerLocals(), f.dialerLocals(), CandidatePolicy{}, upgradeRoleListen)
	wantListener := []probeCandidatePair{
		{local: f.listenerTun, remote: f.dialerHost},
		{local: f.listenerHost, remote: f.dialerHost},
		{local: f.listenerTun, remote: f.dialerRefl},
		{local: f.listenerHost, remote: f.dialerRefl},
		{local: f.listenerRefl, remote: f.dialerHost},
		{local: f.listenerRefl, remote: f.dialerRefl},
	}
	assertProbeCandidatePairs(t, listenerPlan.pairs, wantListener)
}

// TestProbePairsFieldShapedDeadPairsDelayButDoNotStarveViablePair shows that
// at field-realistic candidate counts the dead tunnel pairs do not exhaust
// the probe budget: they push the viable pair's only probe burst exactly one
// slot hold (60-75ms) later. With the peer answering whenever probed, the
// upgrade still selects the viable pair, so never-scheduled budget exhaustion
// alone cannot explain the field probe_failed at these counts.
func TestProbePairsFieldShapedDeadPairsDelayButDoNotStarveViablePair(t *testing.T) {
	f := newAsymmetricVPNFixture(t)
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")

	tests := []struct {
		name          string
		remotes       []Candidate
		wantFirstSend func(first time.Duration) bool
		firstSendWant string
	}{
		{
			name:    "tunnel candidate present delays the viable burst by one slot hold",
			remotes: f.listenerLocals(),
			wantFirstSend: func(first time.Duration) bool {
				return first >= 3*probeRetryInterval && first <= 3*(probeRetryInterval+probeRetryJitter)
			},
			firstSendWant: "in [60ms, 75ms]",
		},
		{
			name:    "tunnel candidate absent probes the viable pair immediately",
			remotes: f.listenerLocalsWithoutTunnel(),
			wantFirstSend: func(first time.Duration) bool {
				return first == 0
			},
			firstSendWant: "0s",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			pairPlan := planProbeCandidatePairs(f.dialerLocals(), tt.remotes, CandidatePolicy{}, upgradeRoleDial)
			runtime := newScriptedProbeRuntime(time.Unix(1, 0))
			script := scriptViablePairPeer(t, runtime, key, f.dialerRefl, f.listenerRefl, 0)

			result, err := probePairs(
				context.Background(),
				runtime,
				runtime.Now().Add(defaultUpgradeProbeTimeout),
				key,
				upgradeRoleDial,
				pairPlan.pairs,
				defaultUpgradeProbeConcurrency,
			)
			if err != nil {
				t.Fatalf("probePairs: %v", err)
			}
			assertSelectedViablePair(t, result, f.dialerRefl, f.listenerRefl)
			if len(script.requestTimes) == 0 {
				t.Fatal("viable pair was never probed")
			}
			if first := script.requestTimes[0]; !tt.wantFirstSend(first) {
				t.Fatalf("first viable probe request at %s, want %s", first, tt.firstSendWant)
			}
		})
	}
}

// starvationCandidateLists builds a dialer-side candidate plan input whose
// host×host mesh contributes hostCount*tunnelCount packet-swallowing dead
// pairs ranked ahead of the single viable reflexive×reflexive pair.
func starvationCandidateLists(t *testing.T, hostCount, tunnelCount int) (locals, remotes []Candidate, viableLocal, viableRemote Candidate) {
	t.Helper()
	viableLocal = Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "203.0.113.10:40000")}
	viableRemote = Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.20:41000")}
	locals = make([]Candidate, 0, hostCount+1)
	for i := range hostCount {
		locals = append(locals, benchmarkHostCandidate([3]byte{10, 0, 0}, i, 40000))
	}
	locals = append(locals, viableLocal)
	remotes = make([]Candidate, 0, tunnelCount+1)
	for i := range tunnelCount {
		remotes = append(remotes, benchmarkHostCandidate([3]byte{100, 64, 0}, i, 41000))
	}
	remotes = append(remotes, viableRemote)
	return locals, remotes, viableLocal, viableRemote
}

// TestProbeCandidatePairPlanStarvesViablePairOnlyBeyondDeadPairBudget
// establishes the never-scheduled boundary at the default probe timeout (3s)
// and concurrency (4). The cursor admits pairs strictly in rank order and a
// packet-swallowing pair holds its slot for one frozen retry schedule, which
// is bounded in [60ms, 75ms]. The viable pair at rank k is therefore first
// probed after (k-4)/4 slot holds along its admission chain:
//
//   - 272 pairs: 67 holds ≥ 67*60ms = 4020ms > 3000ms, so the viable pair is
//     provably never probed and the attempt reports probe_failed.
//   - 72 pairs: 17 holds ∈ [1020ms, 1275ms] < 3000ms, so the viable pair is
//     probed and selected.
//
// The crossover sits at 160-200 dead pairs (4*3000ms/75ms to 4*3000ms/60ms),
// an adversarial candidate mesh on the order of 13×13 — not the handful of
// interfaces per host reported in the field.
func TestProbeCandidatePairPlanStarvesViablePairOnlyBeyondDeadPairBudget(t *testing.T) {
	tests := []struct {
		name        string
		hostCount   int
		tunnelCount int
		wantPairs   int
		wantProbed  bool
	}{
		{
			name:        "272 pairs starve the viable pair at the default budget",
			hostCount:   16,
			tunnelCount: 15,
			wantPairs:   16*15 + 16 + 15 + 1,
			wantProbed:  false,
		},
		{
			name:        "72 pairs still reach the viable pair within the default budget",
			hostCount:   8,
			tunnelCount: 7,
			wantPairs:   8*7 + 8 + 7 + 1,
			wantProbed:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			locals, remotes, viableLocal, viableRemote := starvationCandidateLists(t, tt.hostCount, tt.tunnelCount)
			pairPlan := planProbeCandidatePairs(locals, remotes, CandidatePolicy{}, upgradeRoleDial)
			if len(pairPlan.pairs) != tt.wantPairs {
				t.Fatalf("pair plan length = %d, want %d", len(pairPlan.pairs), tt.wantPairs)
			}
			viable := probeCandidatePair{local: viableLocal, remote: viableRemote}
			if last := pairPlan.pairs[len(pairPlan.pairs)-1]; last != viable {
				t.Fatalf("last-ranked pair = %#v, want viable pair %#v", last, viable)
			}

			runtime := newScriptedProbeRuntime(time.Unix(1, 0))
			start := runtime.Now()
			script := scriptViablePairPeer(t, runtime, derivedDialProbeKey(t), viableLocal, viableRemote, 0)

			result := runDialProbeCandidatePairPlan(t, runtime, 0, pairPlan, viableLocal.Addr)

			if tt.wantProbed {
				assertSelectedViablePair(t, result, viableLocal, viableRemote)
				if result.fallback != UpgradeFallbackNone {
					t.Fatalf("fallback = %q, want %q", result.fallback, UpgradeFallbackNone)
				}
				first := script.requestTimes[0]
				chainHolds := (tt.wantPairs - 1 - 3) / 4
				minFirst := time.Duration(3*chainHolds) * probeRetryInterval
				maxFirst := time.Duration(3*chainHolds) * (probeRetryInterval + probeRetryJitter)
				if first < minFirst || first > maxFirst {
					t.Fatalf("first viable probe request at %s, want within [%s, %s]", first, minFirst, maxFirst)
				}
				return
			}

			if result.succeeded {
				t.Fatalf("probe unexpectedly succeeded: %#v", result)
			}
			if result.fallback != UpgradeFallbackProbeFailed {
				t.Fatalf("fallback = %q, want %q", result.fallback, UpgradeFallbackProbeFailed)
			}
			if len(script.requestTimes) != 0 {
				t.Fatalf("viable pair was probed at %v despite starvation-scale dead pairs", script.requestTimes)
			}
			if elapsed := runtime.now.Sub(start); elapsed != defaultUpgradeProbeTimeout {
				t.Fatalf("attempt consumed %s, want the full default probe timeout %s", elapsed, defaultUpgradeProbeTimeout)
			}
		})
	}
}

// TestProbePairsWithholdsViableSuccessUntilHigherRankedDeadPairExhausts pins
// head-of-line success withholding: the viable pair's response is recorded
// ~1ms into the attempt, but best-ready selection refuses to report it until
// the higher-ranked packet-swallowing pair exhausts its slot hold, so the
// attempt returns only after 60-75ms. At field-realistic counts this
// mechanism delays selection; it converts to a failure only when the attempt
// deadline lands inside the withholding window.
func TestProbePairsWithholdsViableSuccessUntilHigherRankedDeadPairExhausts(t *testing.T) {
	f := newAsymmetricVPNFixture(t)
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	pairs := []probeCandidatePair{
		{local: f.dialerRefl, remote: f.listenerHost},
		{local: f.dialerRefl, remote: f.listenerRefl},
	}
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	start := runtime.Now()
	script := scriptViablePairPeer(t, runtime, key, f.dialerRefl, f.listenerRefl, 0)
	scriptSend := runtime.onSend
	higherRankedRequests := 0
	runtime.onSend = func(packet []byte, addr net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if ok && decoded.MessageType == probeMessageRequest {
			remote, err := addrPortFromNetAddr(addr)
			if err != nil {
				return err
			}
			if remote == f.listenerHost.Addr {
				higherRankedRequests++
			}
		}
		return scriptSend(packet, addr)
	}

	result, err := probePairs(
		context.Background(),
		runtime,
		start.Add(defaultUpgradeProbeTimeout),
		key,
		upgradeRoleDial,
		pairs,
		defaultUpgradeProbeConcurrency,
	)
	if err != nil {
		t.Fatalf("probePairs: %v", err)
	}
	assertSelectedViablePair(t, result, f.dialerRefl, f.listenerRefl)
	if script.responses != 1 {
		t.Fatalf("viable pair responses = %d, want 1", script.responses)
	}
	if higherRankedRequests != probeRequestAttempts {
		t.Fatalf("higher-ranked requests = %d, want one complete pass of %d before selecting the ready result", higherRankedRequests, probeRequestAttempts)
	}
	elapsed := runtime.now.Sub(start)
	if elapsed < 3*probeRetryInterval || elapsed > 3*(probeRetryInterval+probeRetryJitter) {
		t.Fatalf(
			"success reported after %s, want withheld into the dead pair's exhaustion window [%s, %s]",
			elapsed, 3*probeRetryInterval, 3*(probeRetryInterval+probeRetryJitter),
		)
	}
}

// TestProbeCandidatePairPlanDiscardsWithheldViableSuccessAtAttemptDeadline
// pins the discard half of the withholding mechanism: with a probe timeout
// that expires inside the withholding window, the attempt reports
// probe_failed even though it received and recorded a validating response on
// the viable pair. The 30ms timeout is a parameterization (the production
// WithProbeTimeout knob), not a default. In this one-wave two-pair fixture,
// withholding lasts for the higher-ranked pair's 60-75ms admission span. A
// retained earlier-pass probe ID can instead validate just after rollover,
// while higher-ranked pairs are re-armed, and remain withheld through the
// rest of that complete pass; this test does not impose a universal 60-75ms
// withholding bound.
func TestProbeCandidatePairPlanDiscardsWithheldViableSuccessAtAttemptDeadline(t *testing.T) {
	f := newAsymmetricVPNFixture(t)
	pairs := []probeCandidatePair{
		{local: f.dialerRefl, remote: f.listenerHost},
		{local: f.dialerRefl, remote: f.listenerRefl},
	}

	tests := []struct {
		name         string
		probeTimeout time.Duration
		punchOpen    time.Duration
		wantSuccess  bool
	}{
		{
			name: "deadline inside the withholding window discards the recorded success",
			// Below the minimum slot hold (60ms) of the higher-ranked dead
			// pair, above the ~1ms viable response arrival.
			probeTimeout: 30 * time.Millisecond,
			wantSuccess:  false,
		},
		{
			name: "deadline beyond the withholding window reports the same success",
			// Above the maximum slot hold (75ms) of the higher-ranked dead pair.
			probeTimeout: 200 * time.Millisecond,
			wantSuccess:  true,
		},
		{
			name: "deadline during a repeated pass discards its recorded lower-ranked success",
			// The first pass's final request is sent by 50ms. Opening at 55ms
			// makes the viable pair succeed just after pass two begins at
			// 60-75ms, while the higher-ranked pair cannot finish pass two
			// before the 100ms attempt deadline.
			probeTimeout: 100 * time.Millisecond,
			punchOpen:    55 * time.Millisecond,
			wantSuccess:  false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			runtime := newScriptedProbeRuntime(time.Unix(1, 0))
			script := scriptViablePairPeer(t, runtime, derivedDialProbeKey(t), f.dialerRefl, f.listenerRefl, tt.punchOpen)

			result := runDialProbeCandidatePairPlan(t, runtime, tt.probeTimeout, candidatePairPlan{pairs: pairs}, f.dialerRefl.Addr)

			if script.responses != 1 {
				t.Fatalf("viable pair responses = %d, want 1", script.responses)
			}
			if tt.wantSuccess {
				assertSelectedViablePair(t, result, f.dialerRefl, f.listenerRefl)
				return
			}
			if result.succeeded {
				t.Fatalf("probe unexpectedly reported the withheld success: %#v", result)
			}
			if result.fallback != UpgradeFallbackProbeFailed {
				t.Fatalf("fallback = %q, want %q", result.fallback, UpgradeFallbackProbeFailed)
			}
			if len(runtime.events) != 0 {
				t.Fatalf("validating response was never consumed before the deadline: %d events pending", len(runtime.events))
			}
		})
	}
}

// TestProbeCandidatePairPlanSettlesPriorPassSuccessWithLaterRanksUnscheduled reproduces issue #1134 at the production probe-engine seam. The viable last-ranked pair's first-pass response arrives only after pass two admits ranks 0-3. Recording that success freezes new admissions, so ranks 4-6 must not remain artificial blockers after the already-active higher-ranked work finishes its current burst.
func TestProbeCandidatePairPlanSettlesPriorPassSuccessWithLaterRanksUnscheduled(t *testing.T) {
	local := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "203.0.113.10:40000")}
	pairs := make([]probeCandidatePair, 8)
	if defaultUpgradeProbeConcurrency >= len(pairs)-1 {
		t.Fatalf("fixture requires an inactive higher-ranked pair between the active wave and viable rank: concurrency = %d, pairs = %d", defaultUpgradeProbeConcurrency, len(pairs))
	}
	for i := range pairs {
		pairs[i] = probeCandidatePair{
			local:  local,
			remote: Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, fmt.Sprintf("198.51.100.%d:41000", i+1))},
		}
	}
	viable := pairs[len(pairs)-1]
	key := derivedDialProbeKey(t)
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	requestCounts := make(map[netip.AddrPort]int)
	var viableProbeID [probeIDBytes]byte
	viableProbeIDSet := false
	responseQueued := false
	runtime.onSend = func(packet []byte, addr net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		destination, err := addrPortFromNetAddr(addr)
		if err != nil {
			return err
		}
		requestCounts[destination]++
		if destination == viable.remote.Addr {
			viableProbeID = decoded.ProbeID
			viableProbeIDSet = true
		}
		if destination != pairs[0].remote.Addr || requestCounts[destination] != probeRequestAttempts+1 || !viableProbeIDSet || responseQueued {
			return nil
		}
		responseQueued = true
		response, err := encodeProbeDatagram(key, probeMessageResponse, probeDirectionListenerToDialer, viableProbeID, viable.remote, viable.local)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(viable.remote.Addr), nil)
		return nil
	}

	start := runtime.Now()
	result := runDialProbeCandidatePairPlan(t, runtime, 500*time.Millisecond, candidatePairPlan{pairs: pairs}, local.Addr)

	assertSelectedViablePair(t, result, viable.local, viable.remote)
	if !responseQueued {
		t.Fatal("prior-pass viable response was never queued after pass-two admission")
	}
	for rank := defaultUpgradeProbeConcurrency; rank < len(pairs)-1; rank++ {
		if got := requestCounts[pairs[rank].remote.Addr]; got != probeRequestAttempts {
			t.Fatalf("rank %d requests = %d, want only the first-pass %d requests after success froze admissions", rank, got, probeRequestAttempts)
		}
	}
	if elapsed := runtime.Now().Sub(start); elapsed >= 500*time.Millisecond {
		t.Fatalf("recorded viable success settled at %s, want before the attempt deadline", elapsed)
	}
}

// TestProbeCandidatePairPlanRepeatedPassSelectsLatePunchBeforeDeadline pins
// the local half of the issue-#1006 correction at full defaults. The viable
// pair's first burst is pushed into [60ms, 125ms] by the dead tunnel pairs. A
// peer whose punch opens after that burst must still be reached by a later
// complete schedule pass while the existing attempt budget remains.
func TestProbeCandidatePairPlanRepeatedPassSelectsLatePunchBeforeDeadline(t *testing.T) {
	f := newAsymmetricVPNFixture(t)
	burstEnd := 3*(probeRetryInterval+probeRetryJitter) + 2*(probeRetryInterval+probeRetryJitter)

	tests := []struct {
		name      string
		punchOpen time.Duration
	}{
		{
			name: "peer punch open before the viable burst succeeds",
			// Below the burst's earliest possible start (60ms).
			punchOpen: 40 * time.Millisecond,
		},
		{
			name: "peer punch open after the viable burst succeeds on a later pass",
			// Above the burst's latest possible end (125ms).
			punchOpen: 200 * time.Millisecond,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			pairPlan := planProbeCandidatePairs(f.dialerLocals(), f.listenerLocals(), CandidatePolicy{}, upgradeRoleDial)
			runtime := newScriptedProbeRuntime(time.Unix(1, 0))
			script := scriptViablePairPeer(t, runtime, derivedDialProbeKey(t), f.dialerRefl, f.listenerRefl, tt.punchOpen)

			result := runDialProbeCandidatePairPlan(t, runtime, 0, pairPlan, f.dialerRefl.Addr)

			assertSelectedViablePair(t, result, f.dialerRefl, f.listenerRefl)
			if script.responses == 0 {
				t.Fatal("viable pair was never answered")
			}
			if tt.punchOpen > burstEnd && len(script.requestTimes) <= probeRequestAttempts {
				t.Fatalf("viable probe requests = %d, want a later pass after the first %d-request burst", len(script.requestTimes), probeRequestAttempts)
			}
		})
	}
}

// TestCandidatePolicyTunnelHygieneEvidence pins the candidate-policy facts
// the issue-#1006 fix-direction comparison relies on. It is evidence for the
// comparison, not a recommendation.
func TestCandidatePolicyTunnelHygieneEvidence(t *testing.T) {
	f := newAsymmetricVPNFixture(t)
	cgnat := netip.MustParsePrefix("100.64.0.0/10")

	t.Run("remote CGNAT deprioritization moves the viable pair into the first probe wave", func(t *testing.T) {
		policy := CandidatePolicy{DeprioritizeRemotePrefixes: []netip.Prefix{cgnat}}
		plan := planProbeCandidatePairs(f.dialerLocals(), f.listenerLocals(), policy, upgradeRoleDial)
		// Remote deprioritization outranks kind ordering, so every tunnel pair
		// sorts behind the viable reflexive pair while remaining probeable.
		want := []probeCandidatePair{
			{local: f.dialerHost, remote: f.listenerHost},
			{local: f.dialerHost, remote: f.listenerRefl},
			{local: f.dialerRefl, remote: f.listenerHost},
			{local: f.dialerRefl, remote: f.listenerRefl},
			{local: f.dialerHost, remote: f.listenerTun},
			{local: f.dialerRefl, remote: f.listenerTun},
		}
		assertProbeCandidatePairs(t, plan.pairs, want)
	})

	t.Run("local CGNAT deprioritization cannot lift the reflexive pair past host pairs", func(t *testing.T) {
		policy := CandidatePolicy{DeprioritizeLocalPrefixes: []netip.Prefix{cgnat}}
		gathered := []gatheredCandidate{
			{candidate: f.listenerTun, localInterface: "utun4"},
			{candidate: f.listenerHost, localInterface: "en0"},
			{candidate: f.listenerRefl},
		}
		localPlan := planLocalCandidates(gathered, policy)
		wantLocals := []Candidate{f.listenerHost, f.listenerRefl, f.listenerTun}
		if len(localPlan.candidates) != len(wantLocals) {
			t.Fatalf("local candidates = %#v, want %#v", localPlan.candidates, wantLocals)
		}
		for i := range wantLocals {
			if localPlan.candidates[i] != wantLocals[i] {
				t.Fatalf("local candidates[%d] = %#v, want %#v", i, localPlan.candidates[i], wantLocals[i])
			}
		}
		// Pair ranking has no local-deprioritization key: kind order still
		// places host×host pairs first, so the listener's viable pair stays
		// out of the first probe wave (index 4 with concurrency 4).
		plan := planProbeCandidatePairs(localPlan.candidates, f.dialerLocals(), policy, upgradeRoleListen)
		viable := probeCandidatePair{local: f.listenerRefl, remote: f.dialerRefl}
		if plan.pairs[4] != viable {
			t.Fatalf("pair at index 4 = %#v, want viable pair %#v; all pairs %#v", plan.pairs[4], viable, plan.pairs)
		}
	})

	t.Run("local CGNAT prefix exclusion removes tunnel candidates from the offer", func(t *testing.T) {
		policy := CandidatePolicy{ExcludeLocalPrefixes: []netip.Prefix{cgnat}}
		gathered := []gatheredCandidate{
			{candidate: f.listenerTun, localInterface: "utun4"},
			{candidate: f.listenerHost, localInterface: "en0"},
			{candidate: f.listenerRefl},
		}
		localPlan := planLocalCandidates(gathered, policy)
		want := []Candidate{f.listenerHost, f.listenerRefl}
		if len(localPlan.candidates) != len(want) || localPlan.candidates[0] != want[0] || localPlan.candidates[1] != want[1] {
			t.Fatalf("local candidates = %#v, want %#v", localPlan.candidates, want)
		}
	})

	t.Run("interface-name exclusion on a wildcard-bound socket drops the only viable candidate", func(t *testing.T) {
		// The documented CandidatePolicy footgun: a reflexive candidate
		// gathered from a wildcard-bound socket has no known local interface
		// and conservatively matches any non-empty ExcludeLocalInterfaces
		// rule. In this topology that excludes the only viable candidate, so
		// interface-name hygiene guidance would guarantee relay fallback.
		policy := CandidatePolicy{ExcludeLocalInterfaces: []string{"utun4"}}
		gathered := []gatheredCandidate{
			{candidate: f.listenerTun, localInterface: "utun4"},
			{candidate: f.listenerHost, localInterface: "en0"},
			{candidate: f.listenerRefl},
		}
		localPlan := planLocalCandidates(gathered, policy)
		if len(localPlan.candidates) != 1 || localPlan.candidates[0] != f.listenerHost {
			t.Fatalf("local candidates = %#v, want only the en0 host candidate %#v", localPlan.candidates, f.listenerHost)
		}
	})
}

type punchPeerOutcome struct {
	result      candidatePairProbeResult
	err         error
	completedAt time.Duration
}

// runPunchFabricPeer runs one peer's production candidate-pair probe on the
// punch fabric: it waits for the peer's probe start, plans candidate pairs
// exactly as the direct upgrade does, and probes with production defaults.
func runPunchFabricPeer(
	ctx context.Context,
	runtime *punchProbeRuntime,
	role upgradeRole,
	locals []Candidate,
	remotes []Candidate,
	probeStart time.Time,
	retryDelay time.Duration,
	outcomes chan<- punchPeerOutcome,
) {
	runtime.sleepUntil(probeStart)
	attemptConfig := directUpgradeAttempt{
		auth: testAuthContext(),
		cfg: upgradeConfig{
			packetConn: &runtimeProviderPacketConn{runtime: runtime, local: runtime.addr},
		},
	}
	if retryDelay > 0 {
		attemptConfig.testProbeRetry = func() time.Duration { return retryDelay }
	}
	attempt := newTestDirectUpgradeAttempt(attemptConfig)
	localNonce, peerNonce := dialerProbeNonce(), listenerProbeNonce()
	if role != upgradeRoleDial {
		localNonce, peerNonce = listenerProbeNonce(), dialerProbeNonce()
	}
	local := localUpgradeOffer{role: role, probeNonce: localNonce, candidates: locals}
	peer := localUpgradeOffer{probeNonce: peerNonce, candidates: remotes}
	pairPlan := planProbeCandidatePairs(locals, remotes, CandidatePolicy{}, role)
	result, err := attempt.probeCandidatePairPlan(ctx, local, peer, pairPlan)
	outcomes <- punchPeerOutcome{result: result, err: err, completedAt: runtime.Now().Sub(runtime.fabric.epoch)}
}

// twoPeerPunchOutcomes carries both peers' probe results plus the fabric for
// send-log assertions.
type twoPeerPunchOutcomes struct {
	dialer   punchPeerOutcome
	listener punchPeerOutcome
	fabric   *punchProbeFabric
}

type twoPeerPunchConfig struct {
	dialerLocals                  []Candidate
	listenerLocals                []Candidate
	dialerStart                   time.Time
	listenerStart                 time.Time
	deliveryLatency               time.Duration
	dialerPermitActivationDelay   time.Duration
	listenerPermitActivationDelay time.Duration
	dialerRetryDelay              time.Duration
	listenerRetryDelay            time.Duration
}

// runTwoPeerPunchProbe drives both production probe engines over the punch
// fabric with the field-shaped candidate lists, starting each peer's probe at
// its own logical time.
func runTwoPeerPunchProbe(t *testing.T, f asymmetricVPNFixture, start, dialerStart, listenerStart time.Time) twoPeerPunchOutcomes {
	t.Helper()
	return runTwoPeerPunchProbeWithConfig(t, f, start, twoPeerPunchConfig{
		dialerLocals:   f.dialerLocals(),
		listenerLocals: f.listenerLocals(),
		dialerStart:    dialerStart,
		listenerStart:  listenerStart,
	})
}

func runTwoPeerPunchProbeWithConfig(t *testing.T, f asymmetricVPNFixture, start time.Time, cfg twoPeerPunchConfig) twoPeerPunchOutcomes {
	t.Helper()
	fabric := newPunchProbeFabric(start)
	if cfg.deliveryLatency > 0 {
		fabric.deliveryLatency = cfg.deliveryLatency
	}
	watchdog := time.AfterFunc(30*time.Second, func() { fabric.abort(errPunchFabricWatchdog) })
	t.Cleanup(func() { watchdog.Stop() })

	dialerRuntime := fabric.newRuntime(f.dialerRefl.Addr)
	listenerRuntime := fabric.newRuntime(f.listenerRefl.Addr)
	dialerRuntime.permitActivationDelay = cfg.dialerPermitActivationDelay
	listenerRuntime.permitActivationDelay = cfg.listenerPermitActivationDelay
	dialerOutcome := make(chan punchPeerOutcome, 1)
	listenerOutcome := make(chan punchPeerOutcome, 1)
	go runPunchFabricPeer(context.Background(), dialerRuntime, upgradeRoleDial, cfg.dialerLocals, cfg.listenerLocals, cfg.dialerStart, cfg.dialerRetryDelay, dialerOutcome)
	go runPunchFabricPeer(context.Background(), listenerRuntime, upgradeRoleListen, cfg.listenerLocals, cfg.dialerLocals, cfg.listenerStart, cfg.listenerRetryDelay, listenerOutcome)
	outcomes := twoPeerPunchOutcomes{dialer: <-dialerOutcome, listener: <-listenerOutcome, fabric: fabric}

	if outcomes.dialer.err != nil {
		t.Fatalf("dialer probe: %v", outcomes.dialer.err)
	}
	if outcomes.listener.err != nil {
		t.Fatalf("listener probe: %v", outcomes.listener.err)
	}
	return outcomes
}

// TestTwoPeerProbeDelayedPermissionActivationConvergesWithRepeatedSchedulePasses
// models issue #1006 field RUN=4 without tunnel candidates. Both peers start
// together. Packets take 100ms to cross the modeled network, while the
// listener's inbound permission activates independently at 160ms. The
// dialer's first reflexive-pair burst therefore arrives too early and is
// dropped; the listener's requests cross the dialer's already-open permission,
// and their responses arrive after the listener's permission activates. A
// later complete schedule pass must revisit the viable pair so both peers
// select it before the existing attempt deadline.
func TestTwoPeerProbeDelayedPermissionActivationConvergesWithRepeatedSchedulePasses(t *testing.T) {
	f := newAsymmetricVPNFixture(t)
	start := time.Unix(1, 0)
	const (
		deliveryLatency       = 100 * time.Millisecond
		permitActivationDelay = 160 * time.Millisecond
		firstPassRequestCount = probeRequestAttempts
	)

	outcomes := runTwoPeerPunchProbeWithConfig(t, f, start, twoPeerPunchConfig{
		dialerLocals:                  f.dialerLocals(),
		listenerLocals:                f.listenerLocalsWithoutTunnel(),
		dialerStart:                   start,
		listenerStart:                 start,
		deliveryLatency:               deliveryLatency,
		listenerPermitActivationDelay: permitActivationDelay,
	})

	assertSelectedViablePair(t, outcomes.listener.result, f.listenerRefl, f.dialerRefl)
	assertSelectedViablePair(t, outcomes.dialer.result, f.dialerRefl, f.listenerRefl)

	key := derivedDialProbeKey(t)
	viableToken, err := probeCandidatePairToken(key, probeDirectionDialerToListener, f.dialerRefl, f.listenerRefl)
	if err != nil {
		t.Fatalf("viable pair token: %v", err)
	}
	viableRequests := make([]punchFabricSend, 0, firstPassRequestCount+1)
	for _, send := range outcomes.fabric.sendLog() {
		if send.from != f.dialerRefl.Addr || send.to != f.listenerRefl.Addr {
			continue
		}
		decoded, ok := decodeProbeDatagram(send.payload)
		if ok && decoded.MessageType == probeMessageRequest && bytes.Equal(decoded.Token[:], viableToken) {
			viableRequests = append(viableRequests, send)
		}
	}
	if len(viableRequests) <= firstPassRequestCount {
		t.Fatalf("viable-pair requests = %d, want a complete first pass plus a repeated request", len(viableRequests))
	}
	for i := range firstPassRequestCount {
		arrival := viableRequests[i].at + deliveryLatency
		if arrival >= permitActivationDelay {
			t.Fatalf("first-pass viable request %d arrived at %s, want before permission activation at %s", i+1, arrival, permitActivationDelay)
		}
	}
	repeatedProbeIDs := make(map[[probeIDBytes]byte]struct{})
	for _, send := range viableRequests[firstPassRequestCount:] {
		if send.at+deliveryLatency < permitActivationDelay {
			continue
		}
		decoded, ok := decodeProbeDatagram(send.payload)
		if !ok {
			t.Fatal("punch fabric recorded an undecodable repeated probe request")
		}
		repeatedProbeIDs[decoded.ProbeID] = struct{}{}
	}
	if len(repeatedProbeIDs) == 0 {
		t.Fatal("no repeated-pass viable request arrived after permission activation")
	}
	for _, send := range outcomes.fabric.sendLog() {
		if send.from != f.listenerRefl.Addr || send.to != f.dialerRefl.Addr {
			continue
		}
		decoded, ok := decodeProbeDatagram(send.payload)
		if !ok || decoded.MessageType != probeMessageResponse {
			continue
		}
		if _, ok := repeatedProbeIDs[decoded.ProbeID]; ok {
			return
		}
	}
	t.Fatal("listener never answered a repeated-pass viable request")
}

// TestTwoPeerProbeFirstListenerSuccessRemainsResponsiveUntilDialerConverges
// covers the first-validator release race observed by the patched #1006 field
// gate. The listener begins later and needs 60ms after its first outbound punch
// before admitting the dialer's traffic. It validates first through the reverse
// direction; the dialer's next complete pass then needs the already-successful
// listener to remain receive/respond-capable so both peers converge.
func TestTwoPeerProbeFirstListenerSuccessRemainsResponsiveUntilDialerConverges(t *testing.T) {
	f := newAsymmetricVPNFixture(t)
	start := time.Unix(1, 0)
	const probeStartSkew = 300 * time.Millisecond
	outcomes := runTwoPeerPunchProbeWithConfig(t, f, start, twoPeerPunchConfig{
		dialerLocals:                  f.dialerLocals(),
		listenerLocals:                f.listenerLocalsWithoutTunnel(),
		dialerStart:                   start,
		listenerStart:                 start.Add(probeStartSkew),
		deliveryLatency:               20 * time.Millisecond,
		listenerPermitActivationDelay: 60 * time.Millisecond,
		dialerRetryDelay:              probeRetryInterval + probeRetryJitter,
		listenerRetryDelay:            probeRetryInterval,
	})

	assertSelectedViablePair(t, outcomes.listener.result, f.listenerRefl, f.dialerRefl)
	assertSelectedViablePair(t, outcomes.dialer.result, f.dialerRefl, f.listenerRefl)
	if want := probeStartSkew + defaultUpgradeProbeTimeout; outcomes.listener.completedAt != want {
		t.Fatalf("listener hold completed at %s, want existing attempt deadline %s", outcomes.listener.completedAt, want)
	}
	if outcomes.dialer.completedAt >= outcomes.listener.completedAt {
		t.Fatalf("dialer completed at %s, want before listener hold deadline %s", outcomes.dialer.completedAt, outcomes.listener.completedAt)
	}

	key := derivedDialProbeKey(t)
	listenerToken, err := probeCandidatePairToken(key, probeDirectionListenerToDialer, f.listenerRefl, f.dialerRefl)
	if err != nil {
		t.Fatalf("listener viable token: %v", err)
	}
	dialerToken, err := probeCandidatePairToken(key, probeDirectionDialerToListener, f.dialerRefl, f.listenerRefl)
	if err != nil {
		t.Fatalf("dialer viable token: %v", err)
	}
	sends := outcomes.fabric.sendLog()
	listenerRequestIDs := make(map[[probeIDBytes]byte]struct{})
	var listenerSuccessAt time.Duration
	for _, send := range sends {
		decoded, ok := decodeProbeDatagram(send.payload)
		if !ok {
			continue
		}
		if send.from == f.listenerRefl.Addr && send.to == f.dialerRefl.Addr && decoded.MessageType == probeMessageRequest && bytes.Equal(decoded.Token[:], listenerToken) {
			listenerRequestIDs[decoded.ProbeID] = struct{}{}
		}
		if send.from != f.dialerRefl.Addr || send.to != f.listenerRefl.Addr || decoded.MessageType != probeMessageResponse {
			continue
		}
		if _, ok := listenerRequestIDs[decoded.ProbeID]; !ok {
			continue
		}
		arrival := send.at + 20*time.Millisecond
		if arrival >= probeStartSkew+60*time.Millisecond && (listenerSuccessAt == 0 || arrival < listenerSuccessAt) {
			listenerSuccessAt = arrival
		}
	}
	if listenerSuccessAt == 0 {
		t.Fatal("listener never received its validating viable-pair response")
	}

	postSuccessDialerRequests := make(map[[probeIDBytes]byte]struct{})
	postSuccessListenerResponses := 0
	for _, send := range sends {
		decoded, ok := decodeProbeDatagram(send.payload)
		if !ok {
			continue
		}
		if send.from == f.listenerRefl.Addr && send.to == f.dialerRefl.Addr && decoded.MessageType == probeMessageRequest && send.at >= listenerSuccessAt {
			t.Fatalf("listener sent a new request at %s after its success at %s", send.at, listenerSuccessAt)
		}
		if send.from == f.dialerRefl.Addr && send.to == f.listenerRefl.Addr && decoded.MessageType == probeMessageRequest && bytes.Equal(decoded.Token[:], dialerToken) && send.at+20*time.Millisecond > listenerSuccessAt {
			postSuccessDialerRequests[decoded.ProbeID] = struct{}{}
		}
		if send.from == f.listenerRefl.Addr && send.to == f.dialerRefl.Addr && decoded.MessageType == probeMessageResponse {
			if _, ok := postSuccessDialerRequests[decoded.ProbeID]; ok {
				postSuccessListenerResponses++
			}
		}
	}
	if len(postSuccessDialerRequests) == 0 {
		t.Fatal("dialer sent no viable-pair request after the listener succeeded")
	}
	if postSuccessListenerResponses == 0 {
		t.Fatal("successful listener did not answer the dialer's later viable-pair request")
	}
}

// TestTwoPeerProbeEnginesConvergeOnViablePairWithAlignedProbeStarts is the
// two-engine negative control: with the field-shaped asymmetric candidate
// lists, packet-swallowing dead pairs on both sides, hole-punch filtering on
// both reflexive addresses, and aligned probe starts, both production probe
// engines still select the viable pair. The single shared socket means the
// wave-one host×reflexive pairs already open both punch directions, so at
// field-realistic counts none of the local scheduling mechanisms produces the
// field failure while the peers' schedules stay aligned.
func TestTwoPeerProbeEnginesConvergeOnViablePairWithAlignedProbeStarts(t *testing.T) {
	f := newAsymmetricVPNFixture(t)
	start := time.Unix(1, 0)

	outcomes := runTwoPeerPunchProbe(t, f, start, start, start)

	assertSelectedViablePair(t, outcomes.dialer.result, f.dialerRefl, f.listenerRefl)
	assertSelectedViablePair(t, outcomes.listener.result, f.listenerRefl, f.dialerRefl)
}

// TestTwoPeerProbeStartSkewConvergesOnRepeatedSchedulePass is the deterministic
// two-engine regression for the original issue-#1006 diagnosis. With the same
// field-shaped lists as the aligned-start control, delaying only the listener's
// probe start beyond the dialer's first toward-viable-remote send window
// (which closes by 125ms; the skew is 300ms) still converges:
//
//   - The dialer's entire single burst toward the listener's reflexive
//     candidate lands before the listener has sent anything, is dropped at
//     the listener's NAT, and a later complete schedule pass revisits it.
//   - The listener's later requests pass the dialer's long-open punch, the
//     dialer answers them, and both peers select the viable pair.
func TestTwoPeerProbeStartSkewConvergesOnRepeatedSchedulePass(t *testing.T) {
	f := newAsymmetricVPNFixture(t)
	start := time.Unix(1, 0)
	const probeStartSkew = 300 * time.Millisecond

	outcomes := runTwoPeerPunchProbe(t, f, start, start, start.Add(probeStartSkew))

	assertSelectedViablePair(t, outcomes.dialer.result, f.dialerRefl, f.listenerRefl)
	assertSelectedViablePair(t, outcomes.listener.result, f.listenerRefl, f.dialerRefl)

	key := derivedDialProbeKey(t)
	hostToReflexiveToken, err := probeCandidatePairToken(key, probeDirectionDialerToListener, f.dialerHost, f.listenerRefl)
	if err != nil {
		t.Fatalf("host-to-reflexive pair token: %v", err)
	}
	reflexiveToReflexiveToken, err := probeCandidatePairToken(key, probeDirectionDialerToListener, f.dialerRefl, f.listenerRefl)
	if err != nil {
		t.Fatalf("reflexive-to-reflexive pair token: %v", err)
	}
	relevantTokens := map[string]struct{}{
		string(hostToReflexiveToken):      {},
		string(reflexiveToReflexiveToken): {},
	}
	requestCounts := make(map[string]int, len(relevantTokens))
	var dialerFirstBurstRequests, dialerLaterRequests, dialerPostSkewRequests, dialerLateReplies int
	listenerFirstSend := time.Duration(-1)
	for _, send := range outcomes.fabric.sendLog() {
		if send.from == f.dialerRefl.Addr && send.to == f.listenerRefl.Addr {
			decoded, ok := decodeProbeDatagram(send.payload)
			if !ok {
				t.Fatal("punch fabric recorded an undecodable probe datagram")
			}
			switch decoded.MessageType {
			case probeMessageRequest:
				token := string(decoded.Token[:])
				if _, ok := relevantTokens[token]; !ok {
					t.Fatalf("dialer request toward listener reflexive candidate has unknown pair token %x", decoded.Token)
				}
				requestCounts[token]++
				if requestCounts[token] <= probeRequestAttempts {
					dialerFirstBurstRequests++
					continue
				}
				dialerLaterRequests++
				if send.at >= probeStartSkew {
					dialerPostSkewRequests++
				}
			case probeMessageResponse:
				if send.at < probeStartSkew {
					continue
				}
				dialerLateReplies++
			}
		}
		if send.from == f.listenerRefl.Addr && (listenerFirstSend < 0 || send.at < listenerFirstSend) {
			listenerFirstSend = send.at
		}
	}
	// Two dialer pairs target the listener's reflexive candidate (host×refl
	// and the viable refl×refl), each probing the full frozen three-request
	// schedule before the listener sent anything.
	if want := 2 * probeRequestAttempts; dialerFirstBurstRequests != want {
		t.Fatalf("dialer requests toward the listener before the skew = %d, want %d", dialerFirstBurstRequests, want)
	}
	for token := range relevantTokens {
		if requestCounts[token] < probeRequestAttempts {
			t.Fatalf("dialer first-pass requests for pair token %x = %d, want at least %d", []byte(token), requestCounts[token], probeRequestAttempts)
		}
	}
	if dialerLaterRequests == 0 {
		t.Fatal("dialer never revisited the listener reflexive candidate after the first burst missed")
	}
	if dialerPostSkewRequests == 0 {
		t.Fatal("dialer never revisited the listener reflexive candidate after the listener began probing")
	}
	if dialerLateReplies == 0 {
		t.Fatal("dialer never answered the listener's late punch, so the listener could not have validated the pair")
	}
	if listenerFirstSend != probeStartSkew {
		t.Fatalf("listener's first send at %s, want exactly the probe start skew %s", listenerFirstSend, probeStartSkew)
	}
}
