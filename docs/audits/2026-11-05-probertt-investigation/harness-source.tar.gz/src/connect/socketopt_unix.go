//go:build unix

package connect

import (
	"net"
	"syscall"
)

func ipv6WildcardAllowsIPv4(conn net.PacketConn) bool {
	syscallConn, ok := conn.(syscall.Conn)
	if !ok {
		return false
	}
	rawConn, err := syscallConn.SyscallConn()
	if err != nil {
		return false
	}

	allowsIPv4 := false
	if err := rawConn.Control(func(fd uintptr) {
		v6Only, err := syscall.GetsockoptInt(int(fd), syscall.IPPROTO_IPV6, syscall.IPV6_V6ONLY)
		allowsIPv4 = err == nil && v6Only == 0
	}); err != nil {
		return false
	}
	return allowsIPv4
}
