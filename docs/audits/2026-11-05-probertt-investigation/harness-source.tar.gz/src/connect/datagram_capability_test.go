package connect

import (
	"context"
	"errors"
	"io"
	"net"
	"net/netip"
	"testing"
	"time"
)

func TestDatagramCarrierFromStream(t *testing.T) {
	carrier := &stubDatagramCarrier{maxPayload: 1240, lifetime: openDatagramLifetime(t)}
	var typedNilCarrier *stubDatagramCarrier
	var typedNilLifetime *stubTypedNilContext
	tests := []struct {
		name       string
		stream     io.ReadWriteCloser
		want       DatagramCarrier
		wantErr    bool
		wantAbsent bool
	}{
		{name: "stream only", stream: noopReadWriteCloser{}, wantAbsent: true},
		{name: "explicit absence", stream: datagramCapableStream{}, wantAbsent: true},
		{name: "present", stream: datagramCapableStream{carrier: carrier, present: true}, want: carrier},
		{name: "nil present", stream: datagramCapableStream{present: true}, wantErr: true},
		{name: "typed nil present", stream: datagramCapableStream{carrier: typedNilCarrier, present: true}, wantErr: true},
		{name: "carrier absent", stream: datagramCapableStream{carrier: carrier}, wantErr: true},
		{name: "nil lifetime", stream: datagramCapableStream{carrier: &stubDatagramCarrier{maxPayload: 1240}, present: true}, wantErr: true},
		{name: "typed nil lifetime", stream: datagramCapableStream{carrier: &stubDatagramCarrier{maxPayload: 1240, lifetime: typedNilLifetime}, present: true}, wantErr: true},
		{name: "non-signaling lifetime", stream: datagramCapableStream{carrier: &stubDatagramCarrier{maxPayload: 1240, lifetime: context.Background()}, present: true}, wantErr: true},
		{name: "unusable ceiling", stream: datagramCapableStream{carrier: &stubDatagramCarrier{maxPayload: 1, lifetime: openDatagramLifetime(t)}, present: true}, wantErr: true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := datagramCarrierFromStream(tt.stream)
			if (err != nil) != tt.wantErr {
				t.Fatalf("datagramCarrierFromStream() error = %v, wantErr %v", err, tt.wantErr)
			}
			if tt.wantAbsent && got != nil {
				t.Fatalf("datagramCarrierFromStream() = %T, want nil", got)
			}
			if tt.want != nil && got != tt.want {
				t.Fatalf("datagramCarrierFromStream() = %T, want original carrier", got)
			}
		})
	}
}

func TestDatagramCarrierDiscoveryQueriesReturnPromptly(t *testing.T) {
	carrier := &stubDatagramCarrier{maxPayload: 1240, lifetime: openDatagramLifetime(t)}
	stream := datagramCapableStream{carrier: carrier, present: true}
	done := make(chan error, 1)
	go func() {
		discovered, err := datagramCarrierFromStream(stream)
		if err == nil && discovered != nil {
			_ = discovered.Lifetime()
			_ = discovered.MaxDatagramPayload()
		}
		done <- err
	}()
	select {
	case err := <-done:
		if err != nil {
			t.Fatalf("prompt Datagram discovery: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("Datagram discovery or query blocked")
	}
}

func TestDirectUpgradeResultUsesExclusiveDatagramFieldAndReliableOnlyStream(t *testing.T) {
	carrier := &stubDatagramCarrier{maxPayload: 1240, lifetime: openDatagramLifetime(t)}
	raw := datagramCapableStream{carrier: carrier, present: true}
	for _, stream := range []io.ReadWriteCloser{
		raw,
		newTerminalListenerOwnedStream(raw, func() {}),
	} {
		result := directUpgradeResult(stream, carrier, CandidatePair{}, 0)
		if result.Datagrams != carrier {
			t.Fatalf("UpgradeResult.Datagrams = %T, want original carrier", result.Datagrams)
		}
		if _, ok := result.Stream.(DatagramCapable); ok {
			t.Fatalf("UpgradeResult.Stream type %T preserved optional stream interface", result.Stream)
		}
	}
}

func TestListenerMalformedDatagramCarrierBeforeCommitHardFailsAcceptedTransport(t *testing.T) {
	packetConn := &closeTrackingPacketConn{PacketConn: listenPacket(t, "127.0.0.1:0")}
	t.Cleanup(func() { _ = packetConn.Close() })
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:40000")}
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:40001")}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selectedPair{dialer: dialerCandidate, listener: listenerCandidate})
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}
	controlLocal, controlPeer := net.Pipe()
	t.Cleanup(func() { _ = controlPeer.Close() })
	directLocal, directPeer := net.Pipe()
	t.Cleanup(func() { _ = directPeer.Close() })
	trackedStream := &closeTrackingStream{ReadWriteCloser: directLocal}

	peerDone := make(chan error, 1)
	go func() {
		payload, readErr := readUpgradeControlFrame(controlPeer)
		if readErr != nil {
			peerDone <- readErr
			return
		}
		if ready, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseReady); !ready.Is(upgradeControlPhaseReady) {
			peerDone <- errors.New("peer did not receive ready")
			return
		}
		_, readErr = controlPeer.Read(make([]byte, 1))
		peerDone <- readErr
	}()

	attempt := directUpgradeAttempt{
		channel:       controlLocal,
		controlFrames: newPrefixedControlFrameSequencer(controlLocal, controlFrameReadResult{payload: selectedFrame[4:]}),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			controlTimeout: time.Second,
			probeTimeout:   time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	session := &directHandoffSession{streams: &directHandoffStreams{
		listenStream: malformedDatagramHandoffStream{ReadWriteCloser: trackedStream},
	}}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	result, err := newListenerDirectUpgradeProtocolEngine(
		attempt,
		session,
		localUpgradeOffer{
			handshakeMaterial: []byte("fake-handshake-material"),
			candidates:        []Candidate{dialerCandidate},
		},
		testListenerCandidatePairPlan(listenerCandidate, dialerCandidate),
		0,
	).runListener(ctx, ctx)
	if !errors.Is(err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("listener malformed carrier error = %v, want ErrUpgradeTransportNotConverged", err)
	}
	if !errors.Is(err, errMalformedDatagramCapability) {
		t.Fatalf("listener malformed carrier error = %v, want malformed capability cause", err)
	}
	if result != (UpgradeResult{}) {
		t.Fatalf("listener malformed carrier result = %#v, want zero value", result)
	}
	if !trackedStream.closed.Load() {
		t.Fatal("listener malformed carrier did not close accepted stream")
	}
	if !packetConn.closed.Load() {
		t.Fatal("listener malformed carrier did not close transferred packet conn")
	}
	if !session.closed || session.listener == nil || !session.listener.closed {
		t.Fatal("listener malformed carrier did not close listener session")
	}
	select {
	case peerErr := <-peerDone:
		if peerErr == nil {
			t.Fatal("peer control read succeeded, want relay abort without fallback")
		}
	case <-time.After(time.Second):
		t.Fatal("peer control read did not unblock after malformed carrier")
	}
}

type stubDatagramCarrier struct {
	maxPayload int
	lifetime   context.Context
}

func (c *stubDatagramCarrier) Lifetime() context.Context { return c.lifetime }

func (c *stubDatagramCarrier) MaxDatagramPayload() int { return c.maxPayload }

func (c *stubDatagramCarrier) SendDatagram(context.Context, []byte) error { return nil }

func (c *stubDatagramCarrier) ReceiveDatagram(context.Context) ([]byte, error) {
	return nil, errors.New("not implemented")
}

func openDatagramLifetime(t *testing.T) context.Context {
	t.Helper()
	ctx, cancel := context.WithCancelCause(context.Background())
	t.Cleanup(func() { cancel(errors.New("test complete")) })
	return ctx
}

type datagramCapableStream struct {
	carrier DatagramCarrier
	present bool
}

type malformedDatagramHandoffStream struct{ io.ReadWriteCloser }

func (malformedDatagramHandoffStream) DatagramCarrier() (DatagramCarrier, bool) {
	return nil, true
}

func (datagramCapableStream) Read([]byte) (int, error)    { return 0, io.EOF }
func (datagramCapableStream) Write(p []byte) (int, error) { return len(p), nil }
func (datagramCapableStream) Close() error                { return nil }

func (s datagramCapableStream) DatagramCarrier() (DatagramCarrier, bool) {
	return s.carrier, s.present
}

type stubTypedNilContext struct{}

func (*stubTypedNilContext) Deadline() (time.Time, bool) { panic("typed-nil context method called") }

func (*stubTypedNilContext) Done() <-chan struct{} { panic("typed-nil context method called") }

func (*stubTypedNilContext) Err() error { panic("typed-nil context method called") }

func (*stubTypedNilContext) Value(any) any { panic("typed-nil context method called") }
