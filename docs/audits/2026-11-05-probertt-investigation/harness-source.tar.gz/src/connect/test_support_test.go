package connect

import (
	"context"
	"encoding/hex"
	"errors"
	"io"
	"net"
	"net/netip"
	"slices"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

type upgradeTestOutcome struct {
	result UpgradeResult
	err    error
}

type acceptTestOutcome struct {
	stream io.ReadWriteCloser
	err    error
}

func newPipeNegotiatorPair(t testing.TB) (alice, bob *Negotiator, aliceRelay, bobRelay net.Conn) {
	t.Helper()

	aliceRelay, bobRelay = net.Pipe()
	t.Cleanup(func() {
		_ = aliceRelay.Close()
		_ = bobRelay.Close()
	})
	alice, bob = newNegotiatorPair(t, aliceRelay, bobRelay)
	return alice, bob, aliceRelay, bobRelay
}

func newNegotiatorPair(t testing.TB, aliceRelay, bobRelay io.ReadWriteCloser) (alice, bob *Negotiator) {
	t.Helper()
	alice, bob, _, _ = newNegotiatorPairWithAuth(t, aliceRelay, bobRelay)
	return alice, bob
}

func newNegotiatorPairWithAuth(t testing.TB, aliceRelay, bobRelay io.ReadWriteCloser) (alice, bob *Negotiator, aliceAuth, bobAuth authContextFixture) {
	t.Helper()

	aliceAuth = testAuthContext()
	bobAuth = testAuthContext()
	bobAuth.sendKey = aliceAuth.receiveKey
	bobAuth.receiveKey = aliceAuth.sendKey

	var err error
	alice, err = NewNegotiator(aliceRelay, aliceAuth)
	if err != nil {
		t.Fatalf("NewNegotiator alice: %v", err)
	}
	bob, err = NewNegotiator(bobRelay, bobAuth)
	if err != nil {
		t.Fatalf("NewNegotiator bob: %v", err)
	}
	return alice, bob, aliceAuth, bobAuth
}

func runNegotiatorUpgrade(run func() (UpgradeResult, error)) <-chan upgradeTestOutcome {
	done := make(chan upgradeTestOutcome, 1)
	go func() {
		result, err := run()
		done <- upgradeTestOutcome{result: result, err: err}
	}()
	return done
}

type scriptedSession struct {
	delegate          Session
	handshake         func() []byte
	handshakeMaterial []byte
	handshakeGate     *scriptedOperationGate
	dial              func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error)
	dialGate          *scriptedOperationGate
	listen            func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error)
	listenGate        *scriptedOperationGate
	close             func() error
	closeGate         *scriptedOperationGate
	closeReleases     []*scriptedOperationGate
	closed            atomic.Bool
	closeCalls        atomic.Int32
}

func (s *scriptedSession) HandshakeMaterial() []byte {
	if s.handshakeGate != nil {
		_ = s.handshakeGate.wait(context.Background())
	}
	if s.handshake != nil {
		return s.handshake()
	}
	if s.delegate != nil {
		return s.delegate.HandshakeMaterial()
	}
	if s.handshakeMaterial == nil {
		return []byte("fake-handshake-material")
	}
	return s.handshakeMaterial
}

func (s *scriptedSession) Dial(ctx context.Context, conn net.PacketConn, remote net.Addr, material []byte) (io.ReadWriteCloser, error) {
	if s.dialGate != nil {
		if err := s.dialGate.wait(ctx); err != nil {
			return nil, err
		}
	}
	if s.dial != nil {
		return s.dial(ctx, conn, remote, material)
	}
	if s.delegate != nil {
		return s.delegate.Dial(ctx, conn, remote, material)
	}
	return nil, errors.New("connect: unexpected scripted Session.Dial")
}

func (s *scriptedSession) Listen(ctx context.Context, conn net.PacketConn, remote net.Addr, material []byte) (TransportListener, error) {
	if s.listenGate != nil {
		if err := s.listenGate.wait(ctx); err != nil {
			return nil, err
		}
	}
	if s.listen != nil {
		return s.listen(ctx, conn, remote, material)
	}
	if s.delegate != nil {
		return s.delegate.Listen(ctx, conn, remote, material)
	}
	return nil, errors.New("connect: unexpected scripted Session.Listen")
}

func (s *scriptedSession) Close() error {
	s.closeCalls.Add(1)
	s.closed.Store(true)
	for _, gate := range s.closeReleases {
		gate.release()
	}
	if s.closeGate != nil {
		_ = s.closeGate.wait(context.Background())
	}
	if s.close != nil {
		return s.close()
	}
	if s.delegate != nil {
		return s.delegate.Close()
	}
	return nil
}

func (s *scriptedSession) wasClosed() bool {
	return s.closed.Load()
}

func (s *scriptedSession) closeCallCount() int {
	return int(s.closeCalls.Load())
}

type scriptedOperationGate struct {
	started            chan struct{}
	releaseCh          chan struct{}
	ignoreCancellation bool
	startedOnce        sync.Once
	releaseOnce        sync.Once
}

func newScriptedOperationGate() *scriptedOperationGate {
	return &scriptedOperationGate{
		started:   make(chan struct{}),
		releaseCh: make(chan struct{}),
	}
}

func newUncancelableScriptedOperationGate() *scriptedOperationGate {
	gate := newScriptedOperationGate()
	gate.ignoreCancellation = true
	return gate
}

func (g *scriptedOperationGate) wait(ctx context.Context) error {
	g.startedOnce.Do(func() {
		close(g.started)
	})
	if g.ignoreCancellation {
		<-g.releaseCh
		return nil
	}
	select {
	case <-g.releaseCh:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func (g *scriptedOperationGate) release() {
	g.releaseOnce.Do(func() {
		close(g.releaseCh)
	})
}

func (g *scriptedOperationGate) waitStarted(t testing.TB) {
	t.Helper()
	select {
	case <-g.started:
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("scripted operation did not reach its gate")
	}
}

func (g *scriptedOperationGate) wasStarted() bool {
	select {
	case <-g.started:
		return true
	default:
		return false
	}
}

type noopReadWriteCloser struct{}

func (noopReadWriteCloser) Read([]byte) (int, error) {
	return 0, io.EOF
}

func (noopReadWriteCloser) Write(p []byte) (int, error) {
	return len(p), nil
}

func (noopReadWriteCloser) Close() error {
	return nil
}

func mustHex(t testing.TB, raw string) []byte {
	t.Helper()

	got, err := hex.DecodeString(raw)
	if err != nil {
		t.Fatalf("DecodeString(%q): %v", raw, err)
	}
	return got
}

func boolToInt32(value bool) int32 {
	if value {
		return 1
	}
	return 0
}

func equalCandidates(got, want []Candidate) bool {
	return slices.Equal(got, want)
}

func listenPacket(t testing.TB, addr string) net.PacketConn {
	t.Helper()
	return listenPacketNetwork(t, "udp", addr)
}

func listenPacketNetwork(t testing.TB, network, addr string) net.PacketConn {
	t.Helper()

	conn, err := net.ListenPacket(network, addr)
	if err != nil {
		t.Fatalf("ListenPacket(%q, %q): %v", network, addr, err)
	}
	t.Cleanup(func() {
		_ = conn.Close()
	})
	return conn
}

func listenPacketNetworkOrSkip(t testing.TB, network, addr string) net.PacketConn {
	t.Helper()

	conn, err := net.ListenPacket(network, addr)
	if err != nil {
		t.Skipf("ListenPacket(%q, %q): %v", network, addr, err)
	}
	t.Cleanup(func() {
		_ = conn.Close()
	})
	return conn
}

func udpAddr(t testing.TB, raw string) *net.UDPAddr {
	t.Helper()

	addr, err := net.ResolveUDPAddr("udp", raw)
	if err != nil {
		t.Fatalf("ResolveUDPAddr(%q): %v", raw, err)
	}
	return addr
}

func tcpAddr(t testing.TB, raw string) *net.TCPAddr {
	t.Helper()

	addr, err := net.ResolveTCPAddr("tcp", raw)
	if err != nil {
		t.Fatalf("ResolveTCPAddr(%q): %v", raw, err)
	}
	return addr
}

type localAddrPacketConn struct {
	net.PacketConn
	localAddr net.Addr
}

func (c localAddrPacketConn) LocalAddr() net.Addr {
	return c.localAddr
}

type testNetAddr string

func (a testNetAddr) Network() string { return "ip+net" }

func (a testNetAddr) String() string { return string(a) }

func mustAddrPort(t testing.TB, raw string) netip.AddrPort {
	t.Helper()

	addr, err := netip.ParseAddrPort(raw)
	if err != nil {
		t.Fatalf("ParseAddrPort(%q): %v", raw, err)
	}
	return addr
}
