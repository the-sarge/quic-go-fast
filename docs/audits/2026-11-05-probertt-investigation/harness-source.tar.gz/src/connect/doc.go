// Package connect contains wiremux's candidate exchange, hole-punching,
// transport upgrade negotiation, direct-first TURN retry, and shared auth
// and transport contracts.
//
// With WithTURNAllocator configured on both peers, a failed direct probe
// enters a compatibility-negotiated TURN retry: the dialer sends Retry Start
// after its own probe failure, each role allocates at most one relay-backed
// packet connection, the peers authenticate a relay/relay pair with a
// separate retry probe profile, and the existing transport commits over the
// TURN composite. Ordinary precommit retry failures return the original
// reliable relay fallback; commit and stream boundaries keep their existing
// no-fallback finality. UpgradeResult.CarrierTopology reports the physical
// carrier shape independently of the compatibility-frozen UpgradePath.
package connect
