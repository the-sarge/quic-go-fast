package connect

import (
	"bytes"
	"io"
	"testing"
)

func mustEncodeUpgradeControlFrame(t *testing.T, fields any) []byte {
	t.Helper()

	frame, err := encodeUpgradeControlTestFrame(fields)
	if err != nil {
		t.Fatalf("encode upgrade-control frame %#v: %v", fields, err)
	}
	return frame
}

func mustEncodeUpgradeControlOfferFrame(t *testing.T) []byte {
	t.Helper()

	return mustEncodeUpgradeControlOfferFrameWithTransport(t, "fake-stream")
}

func mustEncodeUpgradeControlOfferFrameWithTransport(t *testing.T, transportName string) []byte {
	t.Helper()

	return mustEncodeUpgradeControlFrame(t, map[uint64]any{
		upgradeControlKeyType:          upgradeControlMessageOffer,
		upgradeControlKeyVersion:       upgradeControlVersion,
		upgradeControlKeyTransportName: transportName,
		upgradeControlKeyHandshake:     []byte("fake-handshake-material"),
		upgradeControlKeyProbeNonce:    bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		upgradeControlKeyCandidates: []any{
			map[uint64]any{
				upgradeControlCandidateKeyKind:     upgradeControlCandidateKindHostCode,
				upgradeControlCandidateKeyAddrPort: []byte{0x04, 192, 0, 2, 10, 0x30, 0x39},
			},
		},
	})
}

func encodeUpgradeControlOfferForTest(offer localUpgradeOffer) ([]byte, error) {
	return encodeUpgradeControlOffer(offer)
}

// These read helpers are test harness conveniences. Production control I/O
// reads framed payloads through readUpgradeControlFrame and decodes values at
// the sequenced call sites.
// These framed helpers preserve their historical framing-only errors; callers
// of typed decoders inspect payload causes separately.
func readUpgradeControlFallback(reader io.Reader) (upgradeControlFallback, error) {
	payload, err := readUpgradeControlPayload(reader)
	if err != nil {
		return upgradeControlFallback{}, classifyUpgradeControlFramingError(err)
	}
	value, _ := decodeUpgradeControlFallbackPayload(payload)
	return value, nil
}

func readUpgradeControlFirstPhase(reader io.Reader) (upgradeControlFirstPhase, error) {
	payload, err := readUpgradeControlPayload(reader)
	if err != nil {
		return upgradeControlFirstPhase{}, classifyUpgradeControlFramingError(err)
	}
	value, _ := decodeUpgradeControlFirstPhasePayload(payload)
	return value, nil
}

func readUpgradeControlSelectedPairPhase(reader io.Reader) (upgradeControlSelectedPairPhase, error) {
	payload, err := readUpgradeControlPayload(reader)
	if err != nil {
		return upgradeControlSelectedPairPhase{}, classifyUpgradeControlFramingError(err)
	}
	value, _ := decodeUpgradeControlSelectedPairPhasePayload(payload)
	return value, nil
}

func readUpgradeControlReadyPhase(reader io.Reader) (upgradeControlPhaseResult, error) {
	payload, err := readUpgradeControlPayload(reader)
	if err != nil {
		return upgradeControlPhaseResult{}, classifyUpgradeControlFramingError(err)
	}
	value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseReady)
	return value, nil
}

func readUpgradeControlCommitPhase(reader io.Reader) (upgradeControlPhaseResult, error) {
	payload, err := readUpgradeControlPayload(reader)
	if err != nil {
		return upgradeControlPhaseResult{}, classifyUpgradeControlFramingError(err)
	}
	value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseCommit)
	return value, nil
}

func readUpgradeControlAcceptedPhase(reader io.Reader) (upgradeControlPhaseResult, error) {
	payload, err := readUpgradeControlPayload(reader)
	if err != nil {
		return upgradeControlPhaseResult{}, classifyUpgradeControlFramingError(err)
	}
	value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseAccepted)
	return value, nil
}

func readUpgradeControlConvergedPhase(reader io.Reader) (upgradeControlPhaseResult, error) {
	payload, err := readUpgradeControlPayload(reader)
	if err != nil {
		return upgradeControlPhaseResult{}, classifyUpgradeControlFramingError(err)
	}
	value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseConverged)
	return value, nil
}

func readUpgradeControlConfirmedPhase(reader io.Reader) (upgradeControlPhaseResult, error) {
	payload, err := readUpgradeControlPayload(reader)
	if err != nil {
		return upgradeControlPhaseResult{}, classifyUpgradeControlFramingError(err)
	}
	value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseConfirmed)
	return value, nil
}

// encodeUpgradeControlTestFrame encodes arbitrary deterministic-CBOR fields into a
// length-prefixed frame for connect integration tests that synthesize malformed or partial
// messages.
func encodeUpgradeControlTestFrame(fields any) ([]byte, error) {
	payload, err := encMode.Marshal(fields)
	if err != nil {
		return nil, err
	}
	if len(payload) == 0 {
		return nil, errUpgradeControlFrameEmpty
	}
	if len(payload) > maxPayload {
		return nil, errUpgradeControlFrameOversize
	}
	frame := make([]byte, 4+len(payload))
	putUint32Length(frame[:4], len(payload))
	copy(frame[4:], payload)
	return frame, nil
}
