package connect

import (
	"context"
	"errors"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/GridSwarm/wiremux/internal/packetownership"
)

func TestSelectedPathClaimClosedStateSet(t *testing.T) {
	t.Parallel()

	want := []packetClaimState{
		packetClaimBorrowed,
		packetClaimRawOwned,
		packetClaimStreamOwned,
		packetClaimSuccessTransferred,
		packetClaimReleasedBorrow,
		packetClaimDisposed,
	}
	seen := map[packetClaimState]string{}
	for _, state := range want {
		name := state.String()
		if name == "" || strings.HasPrefix(name, "packetClaimState(") {
			t.Fatalf("claim state %v has no stable name", state)
		}
		if prev, ok := seen[state]; ok {
			t.Fatalf("duplicate claim state value for %s and %s", prev, name)
		}
		seen[state] = name
	}
	if len(seen) != 6 {
		t.Fatalf("closed claim state set size = %d, want 6", len(seen))
	}
	if got := packetClaimState(6).String(); !strings.HasPrefix(got, "packetClaimState(") {
		t.Fatalf("claim state set widened past six: %s", got)
	}
}

func TestSelectedPathClaimDirectAttemptBeginsBorrowed(t *testing.T) {
	t.Parallel()

	packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
	owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
	snapshot := owner.snapshot()
	if snapshot.claim != packetClaimBorrowed {
		t.Fatalf("initial claim = %v, want borrowed", snapshot.claim)
	}
	if snapshot.transferred || snapshot.committed {
		t.Fatalf("initial transfer facts = transferred %t committed %t, want both false", snapshot.transferred, snapshot.committed)
	}
	if snapshot.packetConn != packetConn {
		t.Fatalf("selected packet conn = %p, want exact borrowed conn %p", snapshot.packetConn, packetConn)
	}
	if packetConn.closed.Load() {
		t.Fatal("constructor closed the borrowed packet socket")
	}
}

func TestSelectedPathClaimPrecommitTerminalReleasesBorrow(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		run  func(*attemptResources) error
	}{
		{
			name: "settleRelay",
			run: func(owner *attemptResources) error {
				_, err := owner.settleRelay(UpgradeFallbackProbeFailed)
				return err
			},
		},
		{
			name: "failClosed",
			run: func(owner *attemptResources) error {
				_, err := owner.failClosed(context.Canceled, retainForOuterSettlement)
				return err
			},
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
			owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
			if err := test.run(owner); err != nil && test.name == "settleRelay" {
				t.Fatalf("%s error = %v, want nil", test.name, err)
			}
			snapshot := owner.snapshot()
			if snapshot.claim != packetClaimReleasedBorrow {
				t.Fatalf("%s claim = %v, want released-borrow", test.name, snapshot.claim)
			}
			if snapshot.transferred {
				t.Fatalf("%s marked root transfer, want no root marker", test.name)
			}
			if packetConn.closed.Load() {
				t.Fatalf("%s closed the borrowed packet socket", test.name)
			}
		})
	}
}

func TestSelectedPathClaimCommitWithoutStreamMovesToRawOwned(t *testing.T) {
	t.Parallel()

	packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
	owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
	owner.registerCommit()
	snapshot := owner.snapshot()
	if !snapshot.committed || !snapshot.transferred || snapshot.claim != packetClaimRawOwned {
		t.Fatalf("commit state = committed %t transferred %t claim %v; want committed, transferred, raw-owned",
			snapshot.committed, snapshot.transferred, snapshot.claim)
	}
	if packetConn.closed.Load() {
		t.Fatal("commit closed the packet socket before terminal disposition")
	}
}

func TestSelectedPathClaimNonNilStreamMovesToStreamOwned(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		err  error
	}{
		{name: "success"},
		{name: "stream-plus-error", err: errors.New("dial failed after stream")},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
			stream := &countingReadWriteCloser{}
			session := newFinalitySession(stream, test.err)
			owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
			owner.registerSession(session)
			owner.startDial(context.Background(), session, packetConn, nil, nil)
			session.dialGate.waitStarted(t)
			owner.joinDialForTerminal(true)

			snapshot := owner.snapshot()
			if !snapshot.transferred || snapshot.claim != packetClaimStreamOwned {
				t.Fatalf("stream claim = transferred %t claim %v; want transferred stream-owned", snapshot.transferred, snapshot.claim)
			}
			if packetConn.closed.Load() {
				t.Fatal("stream registration closed the packet socket before terminal disposition")
			}
			if got := stream.closes.Load(); got != 0 {
				t.Fatalf("stream registration closed the stream %d times before terminal disposition", got)
			}
		})
	}
}

func TestSelectedPathClaimOwnedSuccessTransfers(t *testing.T) {
	t.Parallel()

	packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
	stream := &countingReadWriteCloser{}
	session := newFinalitySession(stream, nil)
	owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
	owner.registerSession(session)
	owner.registerCommit()
	owner.startDial(context.Background(), session, packetConn, nil, nil)
	session.dialGate.waitStarted(t)
	owner.joinDialForTerminal(true)

	pair := CandidatePair{}
	result, err := owner.succeedDirect(pair, 0, nil)
	if err != nil {
		t.Fatalf("succeedDirect error = %v", err)
	}
	if result.Stream == nil {
		t.Fatal("succeedDirect returned nil stream")
	}
	if snapshot := owner.snapshot(); snapshot.claim != packetClaimSuccessTransferred {
		t.Fatalf("success claim = %v, want success-transferred", snapshot.claim)
	}
	if packetConn.closed.Load() {
		t.Fatal("success disposition closed the packet socket")
	}
}

func TestSelectedPathClaimOwnedFailureDisposes(t *testing.T) {
	t.Parallel()

	t.Run("raw-owned closes only packet conn", func(t *testing.T) {
		t.Parallel()

		packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
		session := newFinalitySession(nil, errors.New("dial failed"))
		owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
		owner.registerSession(session)
		owner.registerCommit()
		owner.startDial(context.Background(), session, packetConn, nil, nil)
		session.dialGate.waitStarted(t)
		owner.joinDialForTerminal(true)

		if _, err := owner.failClosed(errors.New("post-commit failure"), abortAfterOwnedResources); !errors.Is(err, ErrUpgradeTransportNotConverged) {
			t.Fatalf("failClosed error = %v, want ErrUpgradeTransportNotConverged", err)
		}
		if snapshot := owner.snapshot(); snapshot.claim != packetClaimDisposed {
			t.Fatalf("raw-owned failure claim = %v, want disposed", snapshot.claim)
		}
		if !packetConn.closed.Load() {
			t.Fatal("raw-owned failure did not close the packet socket")
		}
	})

	t.Run("stream-owned closes only stream", func(t *testing.T) {
		t.Parallel()

		packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
		stream := &countingReadWriteCloser{}
		ownedStream := newTestPacketOwningStream(stream, packetConn)
		session := newFinalitySession(ownedStream, nil)
		owner := newAttemptResources(noopReadWriteCloser{}, packetConn)
		owner.registerSession(session)
		owner.registerCommit()
		owner.startDial(context.Background(), session, packetConn, nil, nil)
		session.dialGate.waitStarted(t)
		owner.joinDialForTerminal(true)

		if _, err := owner.failClosed(errors.New("post-stream failure"), abortAfterOwnedResources); !errors.Is(err, ErrUpgradeTransportNotConverged) {
			t.Fatalf("failClosed error = %v, want ErrUpgradeTransportNotConverged", err)
		}
		if snapshot := owner.snapshot(); snapshot.claim != packetClaimDisposed {
			t.Fatalf("stream-owned failure claim = %v, want disposed", snapshot.claim)
		}
		if got := stream.closes.Load(); got != 1 {
			t.Fatalf("stream closes = %d, want 1", got)
		}
		// Packet conn closes exactly once through the stream owner, not a second raw close.
		if got := packetConn.closes.Load(); got != 1 {
			t.Fatalf("packet conn closes = %d, want 1 via stream Close", got)
		}
	})
}

func TestSelectedPathClaimTURNConstructorStartsRawOwnedWithoutRootMarker(t *testing.T) {
	t.Parallel()

	packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
	marker := packetownership.NewMarker()
	owner := newOwnedTURNPathClaim(noopReadWriteCloser{}, packetConn, marker)
	snapshot := owner.snapshot()
	if snapshot.claim != packetClaimRawOwned {
		t.Fatalf("TURN claim = %v, want raw-owned", snapshot.claim)
	}
	if snapshot.transferred || snapshot.committed {
		t.Fatalf("TURN root facts = transferred %t committed %t, want both false", snapshot.transferred, snapshot.committed)
	}
	if marker.Transferred() {
		t.Fatal("TURN constructor marked the supplied root marker")
	}
	if snapshot.packetConn != packetConn {
		t.Fatalf("TURN selected packet conn = %p, want exact conn %p", snapshot.packetConn, packetConn)
	}
	if packetConn.closed.Load() {
		t.Fatal("TURN constructor closed the packet socket")
	}
}

func TestSelectedPathClaimProductionSocketReferenceCensus(t *testing.T) {
	t.Parallel()

	entries, err := os.ReadDir(".")
	if err != nil {
		t.Fatalf("read connect package: %v", err)
	}
	files := token.NewFileSet()
	cfgPacketConnUses := map[string]int{}
	selectedPacketConnUses := map[string]int{}

	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".go") || strings.HasSuffix(entry.Name(), "_test.go") {
			continue
		}
		parsed, parseErr := parser.ParseFile(files, filepath.Clean(entry.Name()), nil, 0)
		if parseErr != nil {
			t.Fatalf("parse %s: %v", entry.Name(), parseErr)
		}
		for _, declaration := range parsed.Decls {
			function, ok := declaration.(*ast.FuncDecl)
			if !ok || function.Body == nil {
				continue
			}
			owner := terminalCensusFunctionOwner(function)
			ast.Inspect(function.Body, func(node ast.Node) bool {
				switch expression := node.(type) {
				case *ast.SelectorExpr:
					if expression.Sel.Name != "packetConn" {
						return true
					}
					if selected, ok := expression.X.(*ast.SelectorExpr); ok && selected.Sel.Name == "cfg" {
						cfgPacketConnUses[owner]++
					}
				case *ast.CallExpr:
					if terminalCensusCalledName(expression.Fun) == "selectedPacketConn" {
						selectedPacketConnUses[owner]++
					}
				}
				return true
			})
		}
	}

	// Option validation remains config-owned (local cfg.packetConn). Runtime
	// consumers must not read attempt.cfg.packetConn.
	if len(cfgPacketConnUses) != 0 {
		t.Fatalf("production attempt.cfg.packetConn uses = %#v, want none after selected-path migration", cfgPacketConnUses)
	}
	wantSelected := map[string]int{
		"directUpgradeAttempt.run":                              1,
		"directUpgradeAttempt.localCandidates":                  1,
		"directUpgradeAttempt.probeCandidatePairPlan":           1,
		"directUpgradeProtocolEngine.executeDialerTransition":   2,
		"directUpgradeProtocolEngine.executeListenerTransition": 2,
		// runHeldSuccessListener reads the selected socket only for the
		// behaviorally inert heldSuccessListenerEntryObserver assertion; it
		// carries no packet-socket lifecycle authority.
		"directUpgradeProtocolEngine.runHeldSuccessListener": 1,
	}
	for owner, wantCount := range wantSelected {
		if got := selectedPacketConnUses[owner]; got != wantCount {
			t.Fatalf("selectedPacketConn uses in %s = %d, want %d (all uses %#v)", owner, got, wantCount, selectedPacketConnUses)
		}
	}
	if len(selectedPacketConnUses) != len(wantSelected) {
		t.Fatalf("unexpected selectedPacketConn consumers %#v, want exactly %#v", selectedPacketConnUses, wantSelected)
	}

	attempt := newDirectUpgradeAttempt(
		&Negotiator{channel: noopReadWriteCloser{}},
		upgradeConfig{packetConn: &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}},
	)
	if attempt.selectedPacketConn() == nil {
		t.Fatal("selectedPacketConn returned nil for configured direct attempt")
	}
	if attempt.selectedPacketConn() != attempt.resources().packetConn {
		t.Fatal("selectedPacketConn did not return the attempt-owner socket")
	}
	if attempt.selectedPacketConn() != attempt.cfg.packetConn {
		t.Fatal("owner socket diverged from configured option value at construction")
	}
}
