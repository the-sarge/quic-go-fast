package connect

import (
	"errors"
	"fmt"
)

var errUnsupportedUpgradeFallbackReason = errors.New("connect: unsupported upgrade fallback reason")

const (
	fallbackReasonWireNotRequested      = uint64(1)
	fallbackReasonWirePolicyExcluded    = uint64(2)
	fallbackReasonWireNoCandidates      = uint64(3)
	fallbackReasonWireTransportMismatch = uint64(4)
	fallbackReasonWireProtocolMismatch  = uint64(5)
	fallbackReasonWireProbeFailed       = uint64(6)
	fallbackReasonWireTransportFailed   = uint64(7)
)

// fallbackReasonPhase names the control exchange in which a coarse fallback
// reason may lawfully cross the wire: the first-phase offer exchange, the
// direct terminal fallback exchange, or the TURN-retry terminal fallback
// exchange. Phase admissibility is a fact of the one definition table below;
// a reason outside its phase is treated as a protocol mismatch, not widened.
type fallbackReasonPhase uint8

const (
	fallbackReasonPhaseFirst fallbackReasonPhase = 1 << iota
	fallbackReasonPhaseTerminal
	// fallbackReasonPhaseRetryTerminal is the TURN-retry terminal exchange,
	// which admits exactly wire codes 2, 5, and 6 (2026-08-09 TURN retry
	// connectivity plan; docs/COMPATIBILITY.md §Wire and encoding profiles).
	fallbackReasonPhaseRetryTerminal
)

type fallbackReasonDefinition struct {
	value          UpgradeFallbackReason
	wire           uint64
	phase          fallbackReasonPhase
	precedenceRank int
}

var fallbackReasonDefinitions = []fallbackReasonDefinition{
	{
		value:          UpgradeFallbackNotRequested,
		wire:           fallbackReasonWireNotRequested,
		phase:          fallbackReasonPhaseFirst,
		precedenceRank: 1,
	},
	{
		value:          UpgradeFallbackPolicyExcluded,
		wire:           fallbackReasonWirePolicyExcluded,
		phase:          fallbackReasonPhaseFirst | fallbackReasonPhaseTerminal | fallbackReasonPhaseRetryTerminal,
		precedenceRank: 3,
	},
	{
		value:          UpgradeFallbackNoCandidates,
		wire:           fallbackReasonWireNoCandidates,
		phase:          fallbackReasonPhaseFirst,
		precedenceRank: 4,
	},
	{
		value:          UpgradeFallbackTransportMismatch,
		wire:           fallbackReasonWireTransportMismatch,
		phase:          fallbackReasonPhaseTerminal,
		precedenceRank: 2,
	},
	{
		value:          UpgradeFallbackProtocolMismatch,
		wire:           fallbackReasonWireProtocolMismatch,
		phase:          fallbackReasonPhaseFirst | fallbackReasonPhaseTerminal | fallbackReasonPhaseRetryTerminal,
		precedenceRank: 0,
	},
	{
		value:          UpgradeFallbackProbeFailed,
		wire:           fallbackReasonWireProbeFailed,
		phase:          fallbackReasonPhaseTerminal | fallbackReasonPhaseRetryTerminal,
		precedenceRank: 6,
	},
	{
		value:          UpgradeFallbackTransportFailed,
		wire:           fallbackReasonWireTransportFailed,
		phase:          fallbackReasonPhaseFirst | fallbackReasonPhaseTerminal,
		precedenceRank: 5,
	},
}

func lookupFallbackReason(reason UpgradeFallbackReason) (fallbackReasonDefinition, bool) {
	for _, def := range fallbackReasonDefinitions {
		if def.value == reason {
			return def, true
		}
	}
	return fallbackReasonDefinition{}, false
}

func lookupFallbackReasonWire(wire uint64) (fallbackReasonDefinition, bool) {
	for _, def := range fallbackReasonDefinitions {
		if def.wire == wire {
			return def, true
		}
	}
	return fallbackReasonDefinition{}, false
}

func resolveFallbackReason(
	phase fallbackReasonPhase,
	local, peer UpgradeFallbackReason,
) UpgradeFallbackReason {
	localDef, ok := lookupFallbackReason(local)
	if !ok || !localDef.validForPhase(phase) {
		return UpgradeFallbackProtocolMismatch
	}
	peerDef, ok := lookupFallbackReason(peer)
	if !ok || !peerDef.validForPhase(phase) {
		return UpgradeFallbackProtocolMismatch
	}
	if localDef.precedenceRank <= peerDef.precedenceRank {
		return localDef.value
	}
	return peerDef.value
}

func firstPhasePeerFallbackReason(peer UpgradeFallbackReason) UpgradeFallbackReason {
	if !validFirstPhaseFallbackReason(peer) {
		return UpgradeFallbackProtocolMismatch
	}
	return peer
}

func validFirstPhaseFallbackReason(reason UpgradeFallbackReason) bool {
	return validFallbackReasonForPhase(reason, fallbackReasonPhaseFirst)
}

func validTerminalFallbackReason(reason UpgradeFallbackReason) bool {
	return validFallbackReasonForPhase(reason, fallbackReasonPhaseTerminal)
}

func validFallbackReasonForPhase(reason UpgradeFallbackReason, phase fallbackReasonPhase) bool {
	def, ok := lookupFallbackReason(reason)
	return ok && def.validForPhase(phase)
}

func (d fallbackReasonDefinition) validForPhase(phase fallbackReasonPhase) bool {
	return d.phase&phase != 0
}

func fallbackReasonToWire(reason UpgradeFallbackReason) (uint64, error) {
	def, ok := lookupFallbackReason(reason)
	if !ok {
		return 0, fmt.Errorf("%w: %q", errUnsupportedUpgradeFallbackReason, reason)
	}
	return def.wire, nil
}

func fallbackReasonFromWireValue(value uint64) (UpgradeFallbackReason, bool) {
	def, ok := lookupFallbackReasonWire(value)
	if !ok {
		return UpgradeFallbackNone, false
	}
	return def.value, true
}

// fallbackReasonToWireForPhase returns the wire code for reason when the
// registry admits it in phase; a reason outside the phase reports false.
func fallbackReasonToWireForPhase(reason UpgradeFallbackReason, phase fallbackReasonPhase) (uint64, bool) {
	def, ok := lookupFallbackReason(reason)
	if !ok || !def.validForPhase(phase) {
		return 0, false
	}
	return def.wire, true
}

// fallbackReasonFromWireForPhase returns the reason for a wire value when the
// registry admits it in phase; an unregistered or phase-invalid value reports
// false.
func fallbackReasonFromWireForPhase(value uint64, phase fallbackReasonPhase) (UpgradeFallbackReason, bool) {
	def, ok := lookupFallbackReasonWire(value)
	if !ok || !def.validForPhase(phase) {
		return UpgradeFallbackNone, false
	}
	return def.value, true
}
