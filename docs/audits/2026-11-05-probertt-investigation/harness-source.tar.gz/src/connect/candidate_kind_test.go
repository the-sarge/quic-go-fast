package connect

import "testing"

func TestClassifyCandidateKind(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		kind CandidateKind
		want candidateKindSemantics
	}{
		{
			name: "host is recognized direct rank zero",
			kind: CandidateKindHost,
			want: candidateKindSemantics{recognized: true, preferenceRank: 0, direct: true},
		},
		{
			name: "reflexive is recognized direct rank one",
			kind: CandidateKindReflexive,
			want: candidateKindSemantics{recognized: true, preferenceRank: 1, direct: true},
		},
		{
			name: "relay is recognized relay rank two",
			kind: CandidateKindRelay,
			want: candidateKindSemantics{recognized: true, preferenceRank: 2, relay: true},
		},
		{
			name: "unknown is fail closed rank three",
			kind: CandidateKind("unknown"),
			want: candidateKindSemantics{preferenceRank: 3},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := classifyCandidateKind(tt.kind); got != tt.want {
				t.Fatalf("classifyCandidateKind(%q) = %#v, want %#v", tt.kind, got, tt.want)
			}
		})
	}
}
