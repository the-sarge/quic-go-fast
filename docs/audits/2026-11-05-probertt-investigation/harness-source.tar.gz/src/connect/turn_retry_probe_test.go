package connect

import (
	"bytes"
	"errors"
	"net/netip"
	"testing"
)

func authenticateProbeDatagram(
	probeKey []byte,
	messageType probeMessageType,
	direction probeDirection,
	probeID [probeIDBytes]byte,
	source Candidate,
	destination Candidate,
) ([]byte, []byte, error) {
	return v1ProbeWireParams().authenticateDatagram(probeKey, messageType, direction, probeID, source, destination)
}

func TestEncodeTurnRetryProbeDatagramGoldenVectors(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	probeID := [probeIDBytes]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}
	dialer := Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "192.0.2.10:12345")}
	listener := Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "198.51.100.40:54321")}

	tests := []struct {
		name        string
		messageType probeMessageType
		direction   probeDirection
		source      Candidate
		destination Candidate
		want        []byte
	}{
		{
			name:        "request dialer to listener",
			messageType: probeMessageRequest,
			direction:   probeDirectionDialerToListener,
			source:      dialer,
			destination: listener,
			want: mustHex(t,
				"574d54520101010102030405060708"+
					"9a62c110991111391001fe1a74daa716"+
					"026059a779fff2132ed9b4d456677a47560c4f044ece7ea26733445dfbdf02c9",
			),
		},
		{
			name:        "response listener to dialer",
			messageType: probeMessageResponse,
			direction:   probeDirectionListenerToDialer,
			source:      listener,
			destination: dialer,
			want: mustHex(t,
				"574d54520102020102030405060708"+
					"6c913e0be72080b112d3f340860a3ccf"+
					"84d587cc88e7ac05f6903f9b8916416f18d361dd4b77154d0649343980285141",
			),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := encodeTurnRetryProbeDatagram(key, tt.messageType, tt.direction, probeID, tt.source, tt.destination)
			if err != nil {
				t.Fatalf("encodeTurnRetryProbeDatagram: %v", err)
			}
			if len(got) != probeDatagramBytes {
				t.Fatalf("length = %d, want %d", len(got), probeDatagramBytes)
			}
			if !bytes.Equal(got, tt.want) {
				t.Fatalf("datagram = %x, want %x", got, tt.want)
			}
		})
	}
}

func TestDeriveTurnRetryProbeKeyExporterDomain(t *testing.T) {
	dialerNonce := bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes)
	listenerNonce := bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes)
	exporter := &recordingKeyExporter{output: bytes.Repeat([]byte{0xab}, probeKeyBytes)}

	got, err := deriveTurnRetryProbeKey(exporter, dialerNonce, listenerNonce)
	if err != nil {
		t.Fatalf("deriveTurnRetryProbeKey: %v", err)
	}
	if !bytes.Equal(got, exporter.output) {
		t.Fatalf("derived key = %x, want %x", got, exporter.output)
	}
	if exporter.label != turnRetryProbeKeyExporterLabel {
		t.Fatalf("exporter label = %q, want %q", exporter.label, turnRetryProbeKeyExporterLabel)
	}
	if exporter.label != "wiremux turn-retry/1 probe-hmac" {
		t.Fatalf("exporter label literal = %q, want wiremux turn-retry/1 probe-hmac", exporter.label)
	}
	if exporter.label == probeKeyExporterLabel {
		t.Fatalf("retry exporter label unexpectedly equals v1 label %q", probeKeyExporterLabel)
	}
	wantContext := append([]byte{probeContextVersion}, dialerNonce...)
	wantContext = append(wantContext, listenerNonce...)
	if !bytes.Equal(exporter.context, wantContext) {
		t.Fatalf("exporter context = %x, want %x", exporter.context, wantContext)
	}
	if exporter.length != probeKeyBytes {
		t.Fatalf("exporter length = %d, want %d", exporter.length, probeKeyBytes)
	}
}

func TestDeriveTurnRetryProbeKeyRejectsInvalidNonces(t *testing.T) {
	validNonce := bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes)
	shortNonce := validNonce[:upgradeControlProbeNonceBytes-1]

	tests := []struct {
		name          string
		dialerNonce   []byte
		listenerNonce []byte
	}{
		{name: "31-byte dialer nonce", dialerNonce: shortNonce, listenerNonce: validNonce},
		{name: "31-byte listener nonce", dialerNonce: validNonce, listenerNonce: shortNonce},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			exporter := &recordingKeyExporter{output: bytes.Repeat([]byte{0xab}, probeKeyBytes)}
			key, err := deriveTurnRetryProbeKey(exporter, tt.dialerNonce, tt.listenerNonce)
			if !errors.Is(err, errInvalidProbeNonce) {
				t.Fatalf("deriveTurnRetryProbeKey error = %v, want %v", err, errInvalidProbeNonce)
			}
			if key != nil {
				t.Fatalf("derived key = %x, want nil", key)
			}
			if exporter.calls != 0 {
				t.Fatalf("exporter calls = %d, want 0", exporter.calls)
			}
		})
	}
}

func TestAcceptTurnRetryProbeDatagramValidatesAuthenticatedPacket(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	probeID := [probeIDBytes]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}
	source := Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "192.0.2.10:12345")}
	destination := Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "198.51.100.40:54321")}
	good, err := encodeTurnRetryProbeDatagram(key, probeMessageRequest, probeDirectionDialerToListener, probeID, source, destination)
	if err != nil {
		t.Fatalf("encodeTurnRetryProbeDatagram: %v", err)
	}

	v1, err := encodeProbeDatagram(key, probeMessageRequest, probeDirectionDialerToListener, probeID,
		Candidate{Kind: CandidateKindHost, Addr: source.Addr},
		Candidate{Kind: CandidateKindReflexive, Addr: destination.Addr},
	)
	if err != nil {
		t.Fatalf("encodeProbeDatagram: %v", err)
	}

	tests := []struct {
		name           string
		datagram       []byte
		source         Candidate
		destination    Candidate
		observedSource netip.AddrPort
		wantOK         bool
	}{
		{
			name:           "valid",
			datagram:       good,
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
			wantOK:         true,
		},
		{
			name:           "relay-only kind guard rejects host candidate",
			datagram:       good,
			source:         Candidate{Kind: CandidateKindHost, Addr: source.Addr},
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "tampered address",
			datagram:       good,
			source:         Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "192.0.2.11:12345")},
			destination:    destination,
			observedSource: mustAddrPort(t, "192.0.2.11:12345"),
		},
		{
			name:           "wrong direction expectation",
			datagram:       good,
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "observed source mismatch",
			datagram:       good,
			source:         source,
			destination:    destination,
			observedSource: destination.Addr,
		},
		{
			name:           "v1 cross-profile magic",
			datagram:       v1,
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "same-magic v1 authentication domain",
			datagram:       mustSameMagicV1AuthRetryDatagram(t, key, probeID, source, destination),
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "wrong tag",
			datagram:       tamperProbeDatagram(good, len(good)-1, good[len(good)-1]^0xff),
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			wantDirection := probeDirectionDialerToListener
			if tt.name == "wrong direction expectation" {
				wantDirection = probeDirectionListenerToDialer
			}
			_, ok := acceptTurnRetryProbeDatagram(key, tt.datagram, probeMessageRequest, wantDirection, tt.source, tt.destination, tt.observedSource)
			if ok != tt.wantOK {
				t.Fatalf("accept = %v, want %v", ok, tt.wantOK)
			}
		})
	}
}

func TestEncodeTurnRetryProbeRejectsNonRelayCandidates(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	probeID := [probeIDBytes]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}
	_, err := encodeTurnRetryProbeDatagram(
		key,
		probeMessageRequest,
		probeDirectionDialerToListener,
		probeID,
		Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")},
		Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "198.51.100.40:54321")},
	)
	if !errors.Is(err, errUnsupportedProbeCandidateKind) {
		t.Fatalf("error = %v, want %v", err, errUnsupportedProbeCandidateKind)
	}
}

func TestTurnRetryProbeCrossProfileRejectsRetryMagicOnV1Accept(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	probeID := [probeIDBytes]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}
	source := Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "192.0.2.10:12345")}
	destination := Candidate{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "198.51.100.40:54321")}
	retry, err := encodeTurnRetryProbeDatagram(key, probeMessageRequest, probeDirectionDialerToListener, probeID, source, destination)
	if err != nil {
		t.Fatalf("encodeTurnRetryProbeDatagram: %v", err)
	}
	_, ok := acceptProbeDatagram(
		key,
		retry,
		probeMessageRequest,
		probeDirectionDialerToListener,
		Candidate{Kind: CandidateKindHost, Addr: source.Addr},
		Candidate{Kind: CandidateKindReflexive, Addr: destination.Addr},
		source.Addr,
	)
	if ok {
		t.Fatal("v1 acceptProbeDatagram accepted WMTR retry datagram")
	}
}

func mustSameMagicV1AuthRetryDatagram(t *testing.T, key []byte, probeID [probeIDBytes]byte, source, destination Candidate) []byte {
	t.Helper()
	// Build a WMTR-framed packet whose token/tag were computed with the v1
	// host/reflexive transcript domain so acceptance must fail after magic match.
	v1Source := Candidate{Kind: CandidateKindHost, Addr: source.Addr}
	v1Destination := Candidate{Kind: CandidateKindReflexive, Addr: destination.Addr}
	token, tag, err := authenticateProbeDatagram(key, probeMessageRequest, probeDirectionDialerToListener, probeID, v1Source, v1Destination)
	if err != nil {
		t.Fatalf("authenticateProbeDatagram: %v", err)
	}
	datagram := make([]byte, 0, probeDatagramBytes)
	datagram = append(datagram, turnRetryProbeDatagramMagic[:]...)
	datagram = append(datagram, probeDatagramVersion)
	datagram = append(datagram, byte(probeMessageRequest))
	datagram = append(datagram, byte(probeDirectionDialerToListener))
	datagram = append(datagram, probeID[:]...)
	datagram = append(datagram, token...)
	datagram = append(datagram, tag...)
	return datagram
}

func TestProbeWireParamsCrossProfileAsymmetry(t *testing.T) {
	// The goldens are the independent source of truth: the v1 request from
	// TestEncodeProbeDatagramGoldenVectors and the retry request from
	// TestEncodeTurnRetryProbeDatagramGoldenVectors.
	v1Golden := mustHex(t,
		"574d58500101010102030405060708"+
			"f543ac095e6378cb98552a8300d754de"+
			"7360039d44a2c03cd865ac0bbc3b5078552bb4bf1ec59cf6285af4ae149f3101",
	)
	retryGolden := mustHex(t,
		"574d54520101010102030405060708"+
			"9a62c110991111391001fe1a74daa716"+
			"026059a779fff2132ed9b4d456677a47560c4f044ece7ea26733445dfbdf02c9",
	)

	if v1ProbeWireParams().crossProfile != nil {
		t.Fatal("v1ProbeWireParams().crossProfile must be nil so foreign datagrams stay ignored")
	}
	crossProfile := turnRetryProbeWireParams().crossProfile
	if crossProfile == nil {
		t.Fatal("turnRetryProbeWireParams().crossProfile must reject valid v1 datagrams")
	}

	tests := []struct {
		name     string
		datagram []byte
		want     bool
	}{
		{name: "v1 golden request is foreign", datagram: v1Golden, want: true},
		{name: "retry golden request is native", datagram: retryGolden, want: false},
		{name: "truncated v1 golden is not a v1 datagram", datagram: v1Golden[:len(v1Golden)-1], want: false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := crossProfile(tt.datagram); got != tt.want {
				t.Fatalf("crossProfile = %v, want %v", got, tt.want)
			}
		})
	}
}
