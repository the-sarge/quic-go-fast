package connect

type directUpgradeProtocolState uint8

const (
	directUpgradeProtocolStateTerminal directUpgradeProtocolState = iota
	directUpgradeProtocolStateListenerAwaitingAcceptOrCommit
	directUpgradeProtocolStateListenerAcceptFirst
	directUpgradeProtocolStateListenerCommitFirst
	directUpgradeProtocolStateDialerAwaitReady
	directUpgradeProtocolStateDialerCommit
	directUpgradeProtocolStateDialerPostCommit
	directUpgradeProtocolStateDialerPostCommitBeforeConverged
	directUpgradeProtocolStateDialerPostCommitAwaitingFrame
	directUpgradeProtocolStateListenerSelected
	directUpgradeProtocolStateListenerListenPending
	directUpgradeProtocolStateListenerAcceptPending
	directUpgradeProtocolStateListenerMaterialized
	directUpgradeProtocolStateListenerPostCommit
	directUpgradeProtocolStatePostCommitStart
	directUpgradeProtocolStatePostCommitAccepted
	directUpgradeProtocolStatePostCommitConverged
)

type directUpgradeProtocolEvent uint8

const (
	directUpgradeProtocolEventNoEvent directUpgradeProtocolEvent = iota
	directUpgradeProtocolEventPostCommitAdvance
	directUpgradeProtocolEventDialerReadyAccepted
	directUpgradeProtocolEventDialerSelectedEncodeFailed
	directUpgradeProtocolEventDialerSelectedWriteFailed
	directUpgradeProtocolEventDialerReadyTimedOut
	directUpgradeProtocolEventDialerReadyControlFailed
	directUpgradeProtocolEventDialerReadyFallback
	directUpgradeProtocolEventDialerReadyPhaseMismatch
	directUpgradeProtocolEventDialerCommitEncodeFailed
	directUpgradeProtocolEventDialerCommitWriteFailed
	directUpgradeProtocolEventDialerCommitPublished
	directUpgradeProtocolEventDialerDialSucceeded
	directUpgradeProtocolEventDialerDialMaterializedError
	directUpgradeProtocolEventDialerDialDatagramValidationFailed
	directUpgradeProtocolEventDialerDialFailed
	directUpgradeProtocolEventDialerDialNilResult
	directUpgradeProtocolEventDialerCallerCanceledMaterialized
	directUpgradeProtocolEventDialerCallerCanceledPendingFailure
	directUpgradeProtocolEventDialerCallerCanceledPendingSuccess
	directUpgradeProtocolEventDialerCallerCanceledPendingMaterializedError
	directUpgradeProtocolEventDialerBudgetExpiredMaterialized
	directUpgradeProtocolEventDialerBudgetExpiredPendingFailure
	directUpgradeProtocolEventDialerBudgetExpiredPendingSuccess
	directUpgradeProtocolEventDialerBudgetExpiredPendingMaterializedError
	directUpgradeProtocolEventDialerSendFailedMaterialized
	directUpgradeProtocolEventDialerSendFailedPendingFailure
	directUpgradeProtocolEventDialerSendFailedPendingSuccess
	directUpgradeProtocolEventDialerSendFailedPendingMaterializedError
	directUpgradeProtocolEventDialerReadFailedMaterialized
	directUpgradeProtocolEventDialerReadFailedPendingFailure
	directUpgradeProtocolEventDialerReadFailedPendingSuccess
	directUpgradeProtocolEventDialerReadFailedPendingMaterializedError
	directUpgradeProtocolEventDialerWrongPhaseMaterialized
	directUpgradeProtocolEventDialerWrongPhasePendingFailure
	directUpgradeProtocolEventDialerWrongPhasePendingSuccess
	directUpgradeProtocolEventDialerWrongPhasePendingMaterializedError
	directUpgradeProtocolEventDialerAccepted
	directUpgradeProtocolEventDialerConverged
	directUpgradeProtocolEventDialerDatagramMismatch
	directUpgradeProtocolEventDialerConfirmedCompleted
	directUpgradeProtocolEventDialerConfirmed
	directUpgradeProtocolEventDialerUnexpectedPreCommit
	directUpgradeProtocolEventDialerUnexpectedMaterialized
	directUpgradeProtocolEventDialerUnexpectedPendingFailure
	directUpgradeProtocolEventDialerUnexpectedPendingSuccess
	directUpgradeProtocolEventDialerUnexpectedPendingMaterializedError
	directUpgradeProtocolEventListenerSelectedTimedOut
	directUpgradeProtocolEventListenerSelectedControlError
	directUpgradeProtocolEventListenerSelectedPeerFallback
	directUpgradeProtocolEventListenerSelectedInvalid
	directUpgradeProtocolEventListenerSelectedAdmitted
	directUpgradeProtocolEventListenerListenSequencerRelayFailure
	directUpgradeProtocolEventListenerListenSequencerRelayMaterialized
	directUpgradeProtocolEventListenerListenControlFailure
	directUpgradeProtocolEventListenerListenControlMaterialized
	directUpgradeProtocolEventListenerListenCancelFailure
	directUpgradeProtocolEventListenerListenCancelMaterialized
	directUpgradeProtocolEventListenerListenBudgetFailure
	directUpgradeProtocolEventListenerListenBudgetMaterialized
	directUpgradeProtocolEventListenerListenFailure
	directUpgradeProtocolEventListenerListenMaterializedError
	directUpgradeProtocolEventListenerListenSucceeded
	directUpgradeProtocolEventListenerReadyEncodeAcceptFailure
	directUpgradeProtocolEventListenerReadyEncodeAcceptSuccess
	directUpgradeProtocolEventListenerReadyEncodeAcceptMaterializedError
	directUpgradeProtocolEventListenerReadyWriteAcceptFailure
	directUpgradeProtocolEventListenerReadyWriteAcceptSuccess
	directUpgradeProtocolEventListenerReadyWriteAcceptMaterializedError
	directUpgradeProtocolEventListenerPrecommitAcceptFailure
	directUpgradeProtocolEventListenerPrecommitAcceptMaterializedError
	directUpgradeProtocolEventListenerPrecommitAcceptSuccess
	directUpgradeProtocolEventListenerAcceptDatagramValidationFailed
	directUpgradeProtocolEventListenerCommitFirst
	directUpgradeProtocolEventListenerPeerFallbackAcceptFailure
	directUpgradeProtocolEventListenerPeerFallbackAcceptSuccess
	directUpgradeProtocolEventListenerPeerFallbackAcceptMaterializedError
	directUpgradeProtocolEventListenerControlErrorAcceptFailure
	directUpgradeProtocolEventListenerControlErrorAcceptSuccess
	directUpgradeProtocolEventListenerControlErrorAcceptMaterializedError
	directUpgradeProtocolEventListenerTimeoutAcceptFailure
	directUpgradeProtocolEventListenerTimeoutAcceptSuccess
	directUpgradeProtocolEventListenerTimeoutAcceptMaterializedError
	directUpgradeProtocolEventListenerTimeoutCommitAcceptFailure
	directUpgradeProtocolEventListenerTimeoutCommitAcceptSuccess
	directUpgradeProtocolEventListenerTimeoutCommitAcceptMaterializedError
	directUpgradeProtocolEventListenerTimeoutWireFallback
	directUpgradeProtocolEventListenerTimeoutControlError
	directUpgradeProtocolEventListenerCancelAcceptFailure
	directUpgradeProtocolEventListenerCancelAcceptSuccess
	directUpgradeProtocolEventListenerCancelAcceptMaterializedError
	directUpgradeProtocolEventListenerCancelCommitAcceptFailure
	directUpgradeProtocolEventListenerCancelCommitAcceptSuccess
	directUpgradeProtocolEventListenerCancelCommitAcceptMaterializedError
	directUpgradeProtocolEventListenerCancelEmptyAcceptFailure
	directUpgradeProtocolEventListenerCancelEmptyAcceptSuccess
	directUpgradeProtocolEventListenerCancelEmptyAcceptMaterializedError
	directUpgradeProtocolEventListenerAcceptFirstCommit
	directUpgradeProtocolEventListenerAcceptFirstControlError
	directUpgradeProtocolEventListenerAcceptFirstNoncommit
	directUpgradeProtocolEventListenerAcceptFirstBudgetExpired
	directUpgradeProtocolEventListenerAcceptFirstCanceled
	directUpgradeProtocolEventListenerCommitFirstAcceptSuccess
	directUpgradeProtocolEventListenerCommitFirstAcceptFailure
	directUpgradeProtocolEventListenerCommitFirstAcceptMaterializedError
	directUpgradeProtocolEventListenerPeerAbortAcceptFailure
	directUpgradeProtocolEventListenerPeerAbortAcceptSuccess
	directUpgradeProtocolEventListenerPeerAbortAcceptMaterializedError
	directUpgradeProtocolEventListenerAcceptBudgetFailure
	directUpgradeProtocolEventListenerAcceptBudgetSuccess
	directUpgradeProtocolEventListenerAcceptBudgetMaterializedError
	directUpgradeProtocolEventListenerCommitFirstCancelAcceptFailure
	directUpgradeProtocolEventListenerCommitFirstCancelAcceptSuccess
	directUpgradeProtocolEventListenerCommitFirstCancelAcceptMaterializedError
	directUpgradeProtocolEventListenerAcceptedSendFailed
	directUpgradeProtocolEventListenerConvergedReadFailed
	directUpgradeProtocolEventListenerConvergedWrongPhase
	directUpgradeProtocolEventListenerDatagramMismatch
	directUpgradeProtocolEventListenerConfirmedSendFailed
	directUpgradeProtocolEventListenerPostcommitCanceled
	directUpgradeProtocolEventListenerPostcommitBudgetExpired
	directUpgradeProtocolEventListenerConfirmed
	directUpgradeProtocolEventListenerUnexpectedPreAcceptFailure
	directUpgradeProtocolEventListenerUnexpectedPreAcceptSuccess
	directUpgradeProtocolEventListenerUnexpectedPreAcceptMaterializedError
	directUpgradeProtocolEventListenerUnexpectedCommitAcceptFailure
	directUpgradeProtocolEventListenerUnexpectedCommitAcceptSuccess
	directUpgradeProtocolEventListenerUnexpectedCommitAcceptMaterializedError
	directUpgradeProtocolEventListenerUnexpectedMaterialized
)

type directUpgradeProtocolActionKind uint8

const (
	directUpgradeProtocolActionAdvance directUpgradeProtocolActionKind = iota + 1
	directUpgradeProtocolActionCoordinateFallback
	directUpgradeProtocolActionFailClosed
	directUpgradeProtocolActionCommitAndStartDial
	directUpgradeProtocolActionObserveDial
	directUpgradeProtocolActionRecordAccepted
	directUpgradeProtocolActionSendConverged
	directUpgradeProtocolActionSucceedDirect
	directUpgradeProtocolActionStartListenerTransport
	directUpgradeProtocolActionStartListenerAccept
	directUpgradeProtocolActionRecordListenerCommit
	directUpgradeProtocolActionEnterListenerPostCommit
)

type directUpgradeProtocolFallback uint8

const (
	directUpgradeFallbackWithSession directUpgradeProtocolFallback = iota + 1
	directUpgradeFallbackSkippingReady
	directUpgradeFallbackWithPeer
	directUpgradeListenerFallbackWithSessionAndPeer
	directUpgradeListenerFallbackWithAcceptedSessionAndPeer
	directUpgradeListenerFallbackAfterPreCommitAcceptFailure
	directUpgradeListenerFallbackAfterHandoffTimeout
)

type directUpgradeProtocolAction struct {
	kind             directUpgradeProtocolActionKind
	fallback         directUpgradeProtocolFallback
	fallbackReason   UpgradeFallbackReason
	control          failClosedControlDisposition
	commitsTransport bool
}

type directUpgradeDialerRow string

const (
	directUpgradeDialerRowD01  directUpgradeDialerRow = "D01"
	directUpgradeDialerRowD02  directUpgradeDialerRow = "D02"
	directUpgradeDialerRowD03  directUpgradeDialerRow = "D03"
	directUpgradeDialerRowD04  directUpgradeDialerRow = "D04"
	directUpgradeDialerRowD05  directUpgradeDialerRow = "D05"
	directUpgradeDialerRowD06  directUpgradeDialerRow = "D06"
	directUpgradeDialerRowD07  directUpgradeDialerRow = "D07"
	directUpgradeDialerRowD08  directUpgradeDialerRow = "D08"
	directUpgradeDialerRowD09  directUpgradeDialerRow = "D09"
	directUpgradeDialerRowD10  directUpgradeDialerRow = "D10"
	directUpgradeDialerRowD11M directUpgradeDialerRow = "D11-M"
	directUpgradeDialerRowD11V directUpgradeDialerRow = "D11-V"
	directUpgradeDialerRowD11  directUpgradeDialerRow = "D11"
	directUpgradeDialerRowD12  directUpgradeDialerRow = "D12"
	directUpgradeDialerRowD13M directUpgradeDialerRow = "D13-M"
	directUpgradeDialerRowD13F directUpgradeDialerRow = "D13-F"
	directUpgradeDialerRowD13S directUpgradeDialerRow = "D13-S"
	directUpgradeDialerRowD13E directUpgradeDialerRow = "D13-E"
	directUpgradeDialerRowD14M directUpgradeDialerRow = "D14-M"
	directUpgradeDialerRowD14F directUpgradeDialerRow = "D14-F"
	directUpgradeDialerRowD14S directUpgradeDialerRow = "D14-S"
	directUpgradeDialerRowD14E directUpgradeDialerRow = "D14-E"
	directUpgradeDialerRowD15M directUpgradeDialerRow = "D15-M"
	directUpgradeDialerRowD15F directUpgradeDialerRow = "D15-F"
	directUpgradeDialerRowD15S directUpgradeDialerRow = "D15-S"
	directUpgradeDialerRowD15E directUpgradeDialerRow = "D15-E"
	directUpgradeDialerRowD16M directUpgradeDialerRow = "D16-M"
	directUpgradeDialerRowD16F directUpgradeDialerRow = "D16-F"
	directUpgradeDialerRowD16S directUpgradeDialerRow = "D16-S"
	directUpgradeDialerRowD16E directUpgradeDialerRow = "D16-E"
	directUpgradeDialerRowD17M directUpgradeDialerRow = "D17-M"
	directUpgradeDialerRowD17F directUpgradeDialerRow = "D17-F"
	directUpgradeDialerRowD17S directUpgradeDialerRow = "D17-S"
	directUpgradeDialerRowD17E directUpgradeDialerRow = "D17-E"
	directUpgradeDialerRowD18  directUpgradeDialerRow = "D18"
	directUpgradeDialerRowD19  directUpgradeDialerRow = "D19"
	directUpgradeDialerRowD20  directUpgradeDialerRow = "D20"
	directUpgradeDialerRowD21  directUpgradeDialerRow = "D21"
	directUpgradeDialerRowD22  directUpgradeDialerRow = "D22"
	directUpgradeDialerRowD23M directUpgradeDialerRow = "D23-M"
	directUpgradeDialerRowD23F directUpgradeDialerRow = "D23-F"
	directUpgradeDialerRowD23S directUpgradeDialerRow = "D23-S"
	directUpgradeDialerRowD23E directUpgradeDialerRow = "D23-E"
)

type directUpgradeListenerRow string

const (
	directUpgradeListenerRowL01   directUpgradeListenerRow = "L01"
	directUpgradeListenerRowL02   directUpgradeListenerRow = "L02"
	directUpgradeListenerRowL03   directUpgradeListenerRow = "L03"
	directUpgradeListenerRowL04   directUpgradeListenerRow = "L04"
	directUpgradeListenerRowL05P  directUpgradeListenerRow = "L05-P"
	directUpgradeListenerRowL05F  directUpgradeListenerRow = "L05-F"
	directUpgradeListenerRowL05S  directUpgradeListenerRow = "L05-S"
	directUpgradeListenerRowL05EF directUpgradeListenerRow = "L05-EF"
	directUpgradeListenerRowL05ES directUpgradeListenerRow = "L05-ES"
	directUpgradeListenerRowL05CF directUpgradeListenerRow = "L05-CF"
	directUpgradeListenerRowL05CS directUpgradeListenerRow = "L05-CS"
	directUpgradeListenerRowL05TF directUpgradeListenerRow = "L05-TF"
	directUpgradeListenerRowL05TS directUpgradeListenerRow = "L05-TS"
	directUpgradeListenerRowL06F  directUpgradeListenerRow = "L06-F"
	directUpgradeListenerRowL06E  directUpgradeListenerRow = "L06-E"
	directUpgradeListenerRowL07   directUpgradeListenerRow = "L07"
	directUpgradeListenerRowL08F  directUpgradeListenerRow = "L08-F"
	directUpgradeListenerRowL08S  directUpgradeListenerRow = "L08-S"
	directUpgradeListenerRowL08E  directUpgradeListenerRow = "L08-E"
	directUpgradeListenerRowL09F  directUpgradeListenerRow = "L09-F"
	directUpgradeListenerRowL09S  directUpgradeListenerRow = "L09-S"
	directUpgradeListenerRowL09E  directUpgradeListenerRow = "L09-E"
	directUpgradeListenerRowL10F  directUpgradeListenerRow = "L10-F"
	directUpgradeListenerRowL10E  directUpgradeListenerRow = "L10-E"
	directUpgradeListenerRowL11   directUpgradeListenerRow = "L11"
	directUpgradeListenerRowL12   directUpgradeListenerRow = "L12"
	directUpgradeListenerRowL13   directUpgradeListenerRow = "L13"
	directUpgradeListenerRowL14F  directUpgradeListenerRow = "L14-F"
	directUpgradeListenerRowL14S  directUpgradeListenerRow = "L14-S"
	directUpgradeListenerRowL14E  directUpgradeListenerRow = "L14-E"
	directUpgradeListenerRowL15F  directUpgradeListenerRow = "L15-F"
	directUpgradeListenerRowL15S  directUpgradeListenerRow = "L15-S"
	directUpgradeListenerRowL15E  directUpgradeListenerRow = "L15-E"
	directUpgradeListenerRowL16F  directUpgradeListenerRow = "L16-F"
	directUpgradeListenerRowL16S  directUpgradeListenerRow = "L16-S"
	directUpgradeListenerRowL16E  directUpgradeListenerRow = "L16-E"
	directUpgradeListenerRowL17F  directUpgradeListenerRow = "L17-F"
	directUpgradeListenerRowL17S  directUpgradeListenerRow = "L17-S"
	directUpgradeListenerRowL17E  directUpgradeListenerRow = "L17-E"
	directUpgradeListenerRowL18   directUpgradeListenerRow = "L18"
	directUpgradeListenerRowL19   directUpgradeListenerRow = "L19"
	directUpgradeListenerRowL20   directUpgradeListenerRow = "L20"
	directUpgradeListenerRowL21   directUpgradeListenerRow = "L21"
	directUpgradeListenerRowL21E  directUpgradeListenerRow = "L21-E"
	directUpgradeListenerRowL22F  directUpgradeListenerRow = "L22-F"
	directUpgradeListenerRowL22S  directUpgradeListenerRow = "L22-S"
	directUpgradeListenerRowL22E  directUpgradeListenerRow = "L22-E"
	directUpgradeListenerRowL23F  directUpgradeListenerRow = "L23-F"
	directUpgradeListenerRowL23S  directUpgradeListenerRow = "L23-S"
	directUpgradeListenerRowL23E  directUpgradeListenerRow = "L23-E"
	directUpgradeListenerRowL24   directUpgradeListenerRow = "L24"
	directUpgradeListenerRowL25   directUpgradeListenerRow = "L25"
	directUpgradeListenerRowL26   directUpgradeListenerRow = "L26"
	directUpgradeListenerRowL27   directUpgradeListenerRow = "L27"
	directUpgradeListenerRowL28   directUpgradeListenerRow = "L28"
	directUpgradeListenerRowL29   directUpgradeListenerRow = "L29"
	directUpgradeListenerRowL30F  directUpgradeListenerRow = "L30-F"
	directUpgradeListenerRowL30E  directUpgradeListenerRow = "L30-E"
	directUpgradeListenerRowL31F  directUpgradeListenerRow = "L31-F"
	directUpgradeListenerRowL31S  directUpgradeListenerRow = "L31-S"
	directUpgradeListenerRowL31E  directUpgradeListenerRow = "L31-E"
	directUpgradeListenerRowL32F  directUpgradeListenerRow = "L32-F"
	directUpgradeListenerRowL32S  directUpgradeListenerRow = "L32-S"
	directUpgradeListenerRowL32E  directUpgradeListenerRow = "L32-E"
	directUpgradeListenerRowL33F  directUpgradeListenerRow = "L33-F"
	directUpgradeListenerRowL33S  directUpgradeListenerRow = "L33-S"
	directUpgradeListenerRowL33E  directUpgradeListenerRow = "L33-E"
	directUpgradeListenerRowL34   directUpgradeListenerRow = "L34"
	directUpgradeListenerRowL35   directUpgradeListenerRow = "L35"
	directUpgradeListenerRowL36   directUpgradeListenerRow = "L36"
	directUpgradeListenerRowL37   directUpgradeListenerRow = "L37"
	directUpgradeListenerRowL38   directUpgradeListenerRow = "L38"
	directUpgradeListenerRowL39   directUpgradeListenerRow = "L39"
	directUpgradeListenerRowL40   directUpgradeListenerRow = "L40"
	directUpgradeListenerRowL41   directUpgradeListenerRow = "L41"
	directUpgradeListenerRowL42PF directUpgradeListenerRow = "L42-PF"
	directUpgradeListenerRowL42PS directUpgradeListenerRow = "L42-PS"
	directUpgradeListenerRowL42PE directUpgradeListenerRow = "L42-PE"
	directUpgradeListenerRowL42CF directUpgradeListenerRow = "L42-CF"
	directUpgradeListenerRowL42CS directUpgradeListenerRow = "L42-CS"
	directUpgradeListenerRowL42CE directUpgradeListenerRow = "L42-CE"
	directUpgradeListenerRowL42M  directUpgradeListenerRow = "L42-M"
)

type directUpgradeProtocolTransition struct {
	role             upgradeRole
	from             directUpgradeProtocolState
	event            directUpgradeProtocolEvent
	to               directUpgradeProtocolState
	postCommitStep   directUpgradePostCommitStep
	postCommitAction directUpgradePostCommitPhaseAction
	dialerRow        directUpgradeDialerRow
	listenerRow      directUpgradeListenerRow
	action           directUpgradeProtocolAction
}

func newDialerProtocolTransition(
	row directUpgradeDialerRow,
	event directUpgradeProtocolEvent,
	from directUpgradeProtocolState,
	to directUpgradeProtocolState,
	action directUpgradeProtocolAction,
) directUpgradeProtocolTransition {
	return directUpgradeProtocolTransition{
		role:      upgradeRoleDial,
		from:      from,
		event:     event,
		to:        to,
		dialerRow: row,
		action:    action,
	}
}

func newListenerProtocolTransition(
	row directUpgradeListenerRow,
	event directUpgradeProtocolEvent,
	from directUpgradeProtocolState,
	to directUpgradeProtocolState,
	action directUpgradeProtocolAction,
) directUpgradeProtocolTransition {
	return directUpgradeProtocolTransition{
		role:        upgradeRoleListen,
		from:        from,
		event:       event,
		to:          to,
		listenerRow: row,
		action:      action,
	}
}

func listenerFailClosedAction(control failClosedControlDisposition) directUpgradeProtocolAction {
	if control == 0 {
		control = abortAfterOwnedResources
	}
	return directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: control}
}

func listenerCommittedFailClosedAction() directUpgradeProtocolAction {
	return directUpgradeProtocolAction{
		kind:             directUpgradeProtocolActionFailClosed,
		control:          abortAfterOwnedResources,
		commitsTransport: true,
	}
}

func listenerFallbackAction(
	mode directUpgradeProtocolFallback,
	reason UpgradeFallbackReason,
) directUpgradeProtocolAction {
	return directUpgradeProtocolAction{
		kind:           directUpgradeProtocolActionCoordinateFallback,
		fallback:       mode,
		fallbackReason: reason,
	}
}

var directUpgradeProtocolTransitions = [...]directUpgradeProtocolTransition{
	{
		role:      upgradeRoleDial,
		from:      directUpgradeProtocolStateDialerAwaitReady,
		event:     directUpgradeProtocolEventDialerSelectedEncodeFailed,
		to:        directUpgradeProtocolStateTerminal,
		dialerRow: directUpgradeDialerRowD01,
		action: directUpgradeProtocolAction{
			kind:           directUpgradeProtocolActionCoordinateFallback,
			fallback:       directUpgradeFallbackWithSession,
			fallbackReason: UpgradeFallbackTransportFailed,
		},
	},
	{
		role:   upgradeRoleDial,
		from:   directUpgradeProtocolStateDialerAwaitReady,
		event:  directUpgradeProtocolEventDialerUnexpectedPreCommit,
		to:     directUpgradeProtocolStateTerminal,
		action: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortBeforeOwnedResources},
	},
	{
		role:   upgradeRoleDial,
		from:   directUpgradeProtocolStateDialerAwaitReady,
		event:  directUpgradeProtocolEventDialerReadyAccepted,
		to:     directUpgradeProtocolStateDialerCommit,
		action: directUpgradeProtocolAction{kind: directUpgradeProtocolActionAdvance},
	},
	{
		role:      upgradeRoleDial,
		from:      directUpgradeProtocolStateDialerAwaitReady,
		event:     directUpgradeProtocolEventDialerSelectedWriteFailed,
		to:        directUpgradeProtocolStateTerminal,
		dialerRow: directUpgradeDialerRowD02,
		action:    directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortBeforeOwnedResources},
	},
	{
		role:      upgradeRoleDial,
		from:      directUpgradeProtocolStateDialerAwaitReady,
		event:     directUpgradeProtocolEventDialerReadyTimedOut,
		to:        directUpgradeProtocolStateTerminal,
		dialerRow: directUpgradeDialerRowD03,
		action: directUpgradeProtocolAction{
			kind:           directUpgradeProtocolActionCoordinateFallback,
			fallback:       directUpgradeFallbackSkippingReady,
			fallbackReason: UpgradeFallbackTransportFailed,
		},
	},
	{
		role:      upgradeRoleDial,
		from:      directUpgradeProtocolStateDialerAwaitReady,
		event:     directUpgradeProtocolEventDialerReadyControlFailed,
		to:        directUpgradeProtocolStateTerminal,
		dialerRow: directUpgradeDialerRowD04,
		action:    directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortBeforeOwnedResources},
	},
	{
		role:      upgradeRoleDial,
		from:      directUpgradeProtocolStateDialerAwaitReady,
		event:     directUpgradeProtocolEventDialerReadyFallback,
		to:        directUpgradeProtocolStateTerminal,
		dialerRow: directUpgradeDialerRowD05,
		action: directUpgradeProtocolAction{
			kind:     directUpgradeProtocolActionCoordinateFallback,
			fallback: directUpgradeFallbackWithPeer,
		},
	},
	{
		role:      upgradeRoleDial,
		from:      directUpgradeProtocolStateDialerAwaitReady,
		event:     directUpgradeProtocolEventDialerReadyPhaseMismatch,
		to:        directUpgradeProtocolStateTerminal,
		dialerRow: directUpgradeDialerRowD06,
		action: directUpgradeProtocolAction{
			kind:           directUpgradeProtocolActionCoordinateFallback,
			fallback:       directUpgradeFallbackWithSession,
			fallbackReason: UpgradeFallbackProtocolMismatch,
		},
	},
	{
		role:      upgradeRoleDial,
		from:      directUpgradeProtocolStateDialerCommit,
		event:     directUpgradeProtocolEventDialerCommitEncodeFailed,
		to:        directUpgradeProtocolStateTerminal,
		dialerRow: directUpgradeDialerRowD07,
		action:    directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: retainForOuterSettlement},
	},
	{
		role:      upgradeRoleDial,
		from:      directUpgradeProtocolStateDialerCommit,
		event:     directUpgradeProtocolEventDialerCommitWriteFailed,
		to:        directUpgradeProtocolStateTerminal,
		dialerRow: directUpgradeDialerRowD08,
		action:    directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortBeforeOwnedResources},
	},
	{
		role:      upgradeRoleDial,
		from:      directUpgradeProtocolStateDialerCommit,
		event:     directUpgradeProtocolEventDialerCommitPublished,
		to:        directUpgradeProtocolStatePostCommitStart,
		dialerRow: directUpgradeDialerRowD09,
		action:    directUpgradeProtocolAction{kind: directUpgradeProtocolActionCommitAndStartDial},
	},
	{
		role:   upgradeRoleDial,
		from:   directUpgradeProtocolStateDialerCommit,
		event:  directUpgradeProtocolEventDialerUnexpectedPreCommit,
		to:     directUpgradeProtocolStateTerminal,
		action: directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortBeforeOwnedResources},
	},
	newDialerProtocolTransition(directUpgradeDialerRowD10, directUpgradeProtocolEventDialerDialSucceeded, directUpgradeProtocolStateDialerPostCommitBeforeConverged, directUpgradeProtocolStateDialerPostCommitBeforeConverged, directUpgradeProtocolAction{kind: directUpgradeProtocolActionObserveDial}),
	newDialerProtocolTransition(directUpgradeDialerRowD11M, directUpgradeProtocolEventDialerDialMaterializedError, directUpgradeProtocolStateDialerPostCommitBeforeConverged, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD11V, directUpgradeProtocolEventDialerDialDatagramValidationFailed, directUpgradeProtocolStateDialerPostCommitBeforeConverged, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD11, directUpgradeProtocolEventDialerDialFailed, directUpgradeProtocolStateDialerPostCommitBeforeConverged, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD12, directUpgradeProtocolEventDialerDialNilResult, directUpgradeProtocolStateDialerPostCommitBeforeConverged, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD13M, directUpgradeProtocolEventDialerCallerCanceledMaterialized, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD13F, directUpgradeProtocolEventDialerCallerCanceledPendingFailure, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD13S, directUpgradeProtocolEventDialerCallerCanceledPendingSuccess, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD13E, directUpgradeProtocolEventDialerCallerCanceledPendingMaterializedError, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD14M, directUpgradeProtocolEventDialerBudgetExpiredMaterialized, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD14F, directUpgradeProtocolEventDialerBudgetExpiredPendingFailure, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD14S, directUpgradeProtocolEventDialerBudgetExpiredPendingSuccess, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD14E, directUpgradeProtocolEventDialerBudgetExpiredPendingMaterializedError, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD15M, directUpgradeProtocolEventDialerSendFailedMaterialized, directUpgradeProtocolStatePostCommitAccepted, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD15F, directUpgradeProtocolEventDialerSendFailedPendingFailure, directUpgradeProtocolStatePostCommitAccepted, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD15S, directUpgradeProtocolEventDialerSendFailedPendingSuccess, directUpgradeProtocolStatePostCommitAccepted, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD15E, directUpgradeProtocolEventDialerSendFailedPendingMaterializedError, directUpgradeProtocolStatePostCommitAccepted, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD16M, directUpgradeProtocolEventDialerReadFailedMaterialized, directUpgradeProtocolStateDialerPostCommitAwaitingFrame, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD16F, directUpgradeProtocolEventDialerReadFailedPendingFailure, directUpgradeProtocolStateDialerPostCommitAwaitingFrame, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD16S, directUpgradeProtocolEventDialerReadFailedPendingSuccess, directUpgradeProtocolStateDialerPostCommitAwaitingFrame, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD16E, directUpgradeProtocolEventDialerReadFailedPendingMaterializedError, directUpgradeProtocolStateDialerPostCommitAwaitingFrame, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD17M, directUpgradeProtocolEventDialerWrongPhaseMaterialized, directUpgradeProtocolStateDialerPostCommitAwaitingFrame, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD17F, directUpgradeProtocolEventDialerWrongPhasePendingFailure, directUpgradeProtocolStateDialerPostCommitAwaitingFrame, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD17S, directUpgradeProtocolEventDialerWrongPhasePendingSuccess, directUpgradeProtocolStateDialerPostCommitAwaitingFrame, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD17E, directUpgradeProtocolEventDialerWrongPhasePendingMaterializedError, directUpgradeProtocolStateDialerPostCommitAwaitingFrame, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	{
		role:             upgradeRoleDial,
		from:             directUpgradeProtocolStatePostCommitStart,
		event:            directUpgradeProtocolEventDialerAccepted,
		to:               directUpgradeProtocolStatePostCommitAccepted,
		postCommitStep:   directUpgradePostCommitStepAccepted,
		postCommitAction: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitAwait, phase: upgradeControlPhaseAccepted},
		dialerRow:        directUpgradeDialerRowD18,
		action:           directUpgradeProtocolAction{kind: directUpgradeProtocolActionRecordAccepted},
	},
	{
		role:             upgradeRoleDial,
		from:             directUpgradeProtocolStatePostCommitAccepted,
		event:            directUpgradeProtocolEventDialerConverged,
		to:               directUpgradeProtocolStatePostCommitConverged,
		postCommitStep:   directUpgradePostCommitStepConverged,
		postCommitAction: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitSend, phase: upgradeControlPhaseConverged},
		dialerRow:        directUpgradeDialerRowD19,
		action:           directUpgradeProtocolAction{kind: directUpgradeProtocolActionSendConverged},
	},
	newDialerProtocolTransition(directUpgradeDialerRowD20, directUpgradeProtocolEventDialerDatagramMismatch, directUpgradeProtocolStatePostCommitConverged, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD21, directUpgradeProtocolEventDialerConfirmedCompleted, directUpgradeProtocolStatePostCommitConverged, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionSucceedDirect}),
	{
		role:             upgradeRoleDial,
		from:             directUpgradeProtocolStatePostCommitConverged,
		event:            directUpgradeProtocolEventDialerConfirmed,
		to:               directUpgradeProtocolStateTerminal,
		postCommitStep:   directUpgradePostCommitStepConfirmed,
		postCommitAction: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitAwait, phase: upgradeControlPhaseConfirmed},
		dialerRow:        directUpgradeDialerRowD22,
		action:           directUpgradeProtocolAction{kind: directUpgradeProtocolActionSucceedDirect},
	},
	newDialerProtocolTransition(directUpgradeDialerRowD23M, directUpgradeProtocolEventDialerUnexpectedMaterialized, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD23F, directUpgradeProtocolEventDialerUnexpectedPendingFailure, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD23S, directUpgradeProtocolEventDialerUnexpectedPendingSuccess, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newDialerProtocolTransition(directUpgradeDialerRowD23E, directUpgradeProtocolEventDialerUnexpectedPendingMaterializedError, directUpgradeProtocolStateDialerPostCommit, directUpgradeProtocolStateTerminal, directUpgradeProtocolAction{kind: directUpgradeProtocolActionFailClosed, control: abortAfterOwnedResources}),
	newListenerProtocolTransition(directUpgradeListenerRowL01, directUpgradeProtocolEventListenerSelectedTimedOut, directUpgradeProtocolStateListenerSelected, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeFallbackWithSession, UpgradeFallbackTransportFailed)),
	newListenerProtocolTransition(directUpgradeListenerRowL02, directUpgradeProtocolEventListenerSelectedControlError, directUpgradeProtocolStateListenerSelected, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortBeforeOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL03, directUpgradeProtocolEventListenerSelectedPeerFallback, directUpgradeProtocolStateListenerSelected, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeListenerFallbackWithSessionAndPeer, UpgradeFallbackNone)),
	newListenerProtocolTransition(directUpgradeListenerRowL04, directUpgradeProtocolEventListenerSelectedInvalid, directUpgradeProtocolStateListenerSelected, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeFallbackWithSession, UpgradeFallbackProtocolMismatch)),
	newListenerProtocolTransition(directUpgradeListenerRowL05P, directUpgradeProtocolEventListenerSelectedAdmitted, directUpgradeProtocolStateListenerSelected, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolAction{kind: directUpgradeProtocolActionStartListenerTransport}),
	newListenerProtocolTransition(directUpgradeListenerRowL05F, directUpgradeProtocolEventListenerListenSequencerRelayFailure, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeListenerFallbackWithSessionAndPeer, UpgradeFallbackNone)),
	newListenerProtocolTransition(directUpgradeListenerRowL05S, directUpgradeProtocolEventListenerListenSequencerRelayMaterialized, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeListenerFallbackWithSessionAndPeer, UpgradeFallbackNone)),
	newListenerProtocolTransition(directUpgradeListenerRowL05EF, directUpgradeProtocolEventListenerListenControlFailure, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortBeforeOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL05ES, directUpgradeProtocolEventListenerListenControlMaterialized, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortBeforeOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL05CF, directUpgradeProtocolEventListenerListenCancelFailure, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortBeforeOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL05CS, directUpgradeProtocolEventListenerListenCancelMaterialized, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortBeforeOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL05TF, directUpgradeProtocolEventListenerListenBudgetFailure, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeFallbackWithSession, UpgradeFallbackTransportFailed)),
	newListenerProtocolTransition(directUpgradeListenerRowL05TS, directUpgradeProtocolEventListenerListenBudgetMaterialized, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeFallbackWithSession, UpgradeFallbackTransportFailed)),
	newListenerProtocolTransition(directUpgradeListenerRowL06F, directUpgradeProtocolEventListenerListenFailure, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeFallbackWithSession, UpgradeFallbackTransportFailed)),
	newListenerProtocolTransition(directUpgradeListenerRowL06E, directUpgradeProtocolEventListenerListenMaterializedError, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeFallbackWithSession, UpgradeFallbackTransportFailed)),
	newListenerProtocolTransition(directUpgradeListenerRowL07, directUpgradeProtocolEventListenerListenSucceeded, directUpgradeProtocolStateListenerListenPending, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolAction{kind: directUpgradeProtocolActionStartListenerAccept}),
	newListenerProtocolTransition(directUpgradeListenerRowL08F, directUpgradeProtocolEventListenerReadyEncodeAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(retainForOuterSettlement)),
	newListenerProtocolTransition(directUpgradeListenerRowL08S, directUpgradeProtocolEventListenerReadyEncodeAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(retainForOuterSettlement)),
	newListenerProtocolTransition(directUpgradeListenerRowL08E, directUpgradeProtocolEventListenerReadyEncodeAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(retainForOuterSettlement)),
	newListenerProtocolTransition(directUpgradeListenerRowL09F, directUpgradeProtocolEventListenerReadyWriteAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL09S, directUpgradeProtocolEventListenerReadyWriteAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL09E, directUpgradeProtocolEventListenerReadyWriteAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL10F, directUpgradeProtocolEventListenerPrecommitAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeListenerFallbackAfterPreCommitAcceptFailure, UpgradeFallbackTransportFailed)),
	newListenerProtocolTransition(directUpgradeListenerRowL10E, directUpgradeProtocolEventListenerPrecommitAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL11, directUpgradeProtocolEventListenerPrecommitAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateListenerAcceptFirst, directUpgradeProtocolAction{kind: directUpgradeProtocolActionAdvance}),
	newListenerProtocolTransition(directUpgradeListenerRowL12, directUpgradeProtocolEventListenerAcceptDatagramValidationFailed, directUpgradeProtocolStateListenerAcceptPending, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL13, directUpgradeProtocolEventListenerCommitFirst, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolAction{kind: directUpgradeProtocolActionRecordListenerCommit}),
	newListenerProtocolTransition(directUpgradeListenerRowL14F, directUpgradeProtocolEventListenerPeerFallbackAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeListenerFallbackWithAcceptedSessionAndPeer, UpgradeFallbackNone)),
	newListenerProtocolTransition(directUpgradeListenerRowL14S, directUpgradeProtocolEventListenerPeerFallbackAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL14E, directUpgradeProtocolEventListenerPeerFallbackAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL15F, directUpgradeProtocolEventListenerControlErrorAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL15S, directUpgradeProtocolEventListenerControlErrorAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL15E, directUpgradeProtocolEventListenerControlErrorAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL16F, directUpgradeProtocolEventListenerTimeoutAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeListenerFallbackAfterHandoffTimeout, UpgradeFallbackTransportFailed)),
	newListenerProtocolTransition(directUpgradeListenerRowL16S, directUpgradeProtocolEventListenerTimeoutAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL16E, directUpgradeProtocolEventListenerTimeoutAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL17F, directUpgradeProtocolEventListenerTimeoutCommitAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerCommittedFailClosedAction()),
	newListenerProtocolTransition(directUpgradeListenerRowL17S, directUpgradeProtocolEventListenerTimeoutCommitAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerCommittedFailClosedAction()),
	newListenerProtocolTransition(directUpgradeListenerRowL17E, directUpgradeProtocolEventListenerTimeoutCommitAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerCommittedFailClosedAction()),
	newListenerProtocolTransition(directUpgradeListenerRowL18, directUpgradeProtocolEventListenerTimeoutWireFallback, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFallbackAction(directUpgradeListenerFallbackWithAcceptedSessionAndPeer, UpgradeFallbackNone)),
	newListenerProtocolTransition(directUpgradeListenerRowL19, directUpgradeProtocolEventListenerTimeoutControlError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL20, directUpgradeProtocolEventListenerCancelAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL21, directUpgradeProtocolEventListenerCancelAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL21E, directUpgradeProtocolEventListenerCancelAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL22F, directUpgradeProtocolEventListenerCancelCommitAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerCommittedFailClosedAction()),
	newListenerProtocolTransition(directUpgradeListenerRowL22S, directUpgradeProtocolEventListenerCancelCommitAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerCommittedFailClosedAction()),
	newListenerProtocolTransition(directUpgradeListenerRowL22E, directUpgradeProtocolEventListenerCancelCommitAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerCommittedFailClosedAction()),
	newListenerProtocolTransition(directUpgradeListenerRowL23F, directUpgradeProtocolEventListenerCancelEmptyAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL23S, directUpgradeProtocolEventListenerCancelEmptyAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL23E, directUpgradeProtocolEventListenerCancelEmptyAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL24, directUpgradeProtocolEventListenerAcceptFirstCommit, directUpgradeProtocolStateListenerAcceptFirst, directUpgradeProtocolStatePostCommitStart, directUpgradeProtocolAction{kind: directUpgradeProtocolActionEnterListenerPostCommit}),
	newListenerProtocolTransition(directUpgradeListenerRowL25, directUpgradeProtocolEventListenerAcceptFirstControlError, directUpgradeProtocolStateListenerAcceptFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL26, directUpgradeProtocolEventListenerAcceptFirstNoncommit, directUpgradeProtocolStateListenerAcceptFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL27, directUpgradeProtocolEventListenerAcceptFirstBudgetExpired, directUpgradeProtocolStateListenerAcceptFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL28, directUpgradeProtocolEventListenerAcceptFirstCanceled, directUpgradeProtocolStateListenerAcceptFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL29, directUpgradeProtocolEventListenerCommitFirstAcceptSuccess, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStatePostCommitStart, directUpgradeProtocolAction{kind: directUpgradeProtocolActionEnterListenerPostCommit}),
	newListenerProtocolTransition(directUpgradeListenerRowL30F, directUpgradeProtocolEventListenerCommitFirstAcceptFailure, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL30E, directUpgradeProtocolEventListenerCommitFirstAcceptMaterializedError, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL31F, directUpgradeProtocolEventListenerPeerAbortAcceptFailure, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL31S, directUpgradeProtocolEventListenerPeerAbortAcceptSuccess, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL31E, directUpgradeProtocolEventListenerPeerAbortAcceptMaterializedError, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL32F, directUpgradeProtocolEventListenerAcceptBudgetFailure, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL32S, directUpgradeProtocolEventListenerAcceptBudgetSuccess, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL32E, directUpgradeProtocolEventListenerAcceptBudgetMaterializedError, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL33F, directUpgradeProtocolEventListenerCommitFirstCancelAcceptFailure, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL33S, directUpgradeProtocolEventListenerCommitFirstCancelAcceptSuccess, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL33E, directUpgradeProtocolEventListenerCommitFirstCancelAcceptMaterializedError, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL34, directUpgradeProtocolEventListenerAcceptedSendFailed, directUpgradeProtocolStatePostCommitStart, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL35, directUpgradeProtocolEventListenerConvergedReadFailed, directUpgradeProtocolStatePostCommitAccepted, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL36, directUpgradeProtocolEventListenerConvergedWrongPhase, directUpgradeProtocolStatePostCommitAccepted, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL37, directUpgradeProtocolEventListenerDatagramMismatch, directUpgradeProtocolStatePostCommitAccepted, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL38, directUpgradeProtocolEventListenerConfirmedSendFailed, directUpgradeProtocolStatePostCommitConverged, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL39, directUpgradeProtocolEventListenerPostcommitCanceled, directUpgradeProtocolStateListenerPostCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL40, directUpgradeProtocolEventListenerPostcommitBudgetExpired, directUpgradeProtocolStateListenerPostCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL42PF, directUpgradeProtocolEventListenerUnexpectedPreAcceptFailure, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL42PS, directUpgradeProtocolEventListenerUnexpectedPreAcceptSuccess, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL42PE, directUpgradeProtocolEventListenerUnexpectedPreAcceptMaterializedError, directUpgradeProtocolStateListenerAwaitingAcceptOrCommit, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL42CF, directUpgradeProtocolEventListenerUnexpectedCommitAcceptFailure, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL42CS, directUpgradeProtocolEventListenerUnexpectedCommitAcceptSuccess, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL42CE, directUpgradeProtocolEventListenerUnexpectedCommitAcceptMaterializedError, directUpgradeProtocolStateListenerCommitFirst, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	newListenerProtocolTransition(directUpgradeListenerRowL42M, directUpgradeProtocolEventListenerUnexpectedMaterialized, directUpgradeProtocolStateListenerMaterialized, directUpgradeProtocolStateTerminal, listenerFailClosedAction(abortAfterOwnedResources)),
	// Post-commit convergence sequence from PRD-0001: listener accepted,
	// dialer converged, listener confirmed. Transport ownership and frame I/O
	// remain in the shared protocol engine and persistent attempt owner.
	{
		role:             upgradeRoleListen,
		from:             directUpgradeProtocolStatePostCommitStart,
		event:            directUpgradeProtocolEventPostCommitAdvance,
		to:               directUpgradeProtocolStatePostCommitAccepted,
		postCommitStep:   directUpgradePostCommitStepAccepted,
		postCommitAction: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitSend, phase: upgradeControlPhaseAccepted},
		action:           directUpgradeProtocolAction{kind: directUpgradeProtocolActionAdvance},
	},
	{
		role:             upgradeRoleListen,
		from:             directUpgradeProtocolStatePostCommitAccepted,
		event:            directUpgradeProtocolEventPostCommitAdvance,
		to:               directUpgradeProtocolStatePostCommitConverged,
		postCommitStep:   directUpgradePostCommitStepConverged,
		postCommitAction: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitAwait, phase: upgradeControlPhaseConverged},
		action:           directUpgradeProtocolAction{kind: directUpgradeProtocolActionAdvance},
	},
	{
		role:             upgradeRoleListen,
		from:             directUpgradeProtocolStatePostCommitConverged,
		event:            directUpgradeProtocolEventListenerConfirmed,
		to:               directUpgradeProtocolStateTerminal,
		postCommitStep:   directUpgradePostCommitStepConfirmed,
		postCommitAction: directUpgradePostCommitPhaseAction{local: directUpgradePostCommitSend, phase: upgradeControlPhaseConfirmed},
		listenerRow:      directUpgradeListenerRowL41,
		action:           directUpgradeProtocolAction{kind: directUpgradeProtocolActionSucceedDirect},
	},
}

type directUpgradeProtocolCursor struct {
	role  upgradeRole
	state directUpgradeProtocolState
}

func newDirectUpgradeProtocolCursor(role upgradeRole, state directUpgradeProtocolState) directUpgradeProtocolCursor {
	return directUpgradeProtocolCursor{role: role, state: state}
}

func (cursor *directUpgradeProtocolCursor) next(event directUpgradeProtocolEvent) (directUpgradeProtocolTransition, bool) {
	transition, ok := cursor.resolve(event)
	if !ok {
		return directUpgradeProtocolTransition{}, false
	}
	cursor.apply(transition)
	return transition, true
}

func (cursor *directUpgradeProtocolCursor) resolve(event directUpgradeProtocolEvent) (directUpgradeProtocolTransition, bool) {
	if cursor.state == directUpgradeProtocolStateTerminal {
		return directUpgradeProtocolTransition{}, false
	}
	transition, ok := nextDirectUpgradeProtocolTransition(cursor.role, cursor.state, event)
	if !ok {
		return directUpgradeProtocolTransition{}, false
	}
	return transition, true
}

func (cursor *directUpgradeProtocolCursor) apply(transition directUpgradeProtocolTransition) {
	if cursor.role == upgradeRoleDial &&
		directUpgradeProtocolDialerPatternState(transition.from) &&
		directUpgradeProtocolDialerPatternState(transition.to) {
		return
	}
	cursor.state = transition.to
}

func nextDirectUpgradeProtocolTransition(
	role upgradeRole,
	state directUpgradeProtocolState,
	event directUpgradeProtocolEvent,
) (directUpgradeProtocolTransition, bool) {
	for _, transition := range directUpgradeProtocolTransitions {
		if transition.role == role && transition.event == event &&
			directUpgradeProtocolStateMatches(transition, state) {
			return transition, true
		}
	}
	return directUpgradeProtocolTransition{}, false
}

func directUpgradeProtocolStateMatches(transition directUpgradeProtocolTransition, state directUpgradeProtocolState) bool {
	if transition.role == upgradeRoleListen {
		switch transition.from {
		case directUpgradeProtocolStateListenerAcceptPending:
			return state == directUpgradeProtocolStateListenerAwaitingAcceptOrCommit ||
				state == directUpgradeProtocolStateListenerCommitFirst
		case directUpgradeProtocolStateListenerMaterialized:
			return state == directUpgradeProtocolStateListenerAcceptFirst ||
				directUpgradeProtocolListenerPostCommitState(state)
		case directUpgradeProtocolStateListenerPostCommit:
			return directUpgradeProtocolListenerPostCommitState(state)
		default:
			return transition.from == state
		}
	}
	switch transition.from {
	case directUpgradeProtocolStateDialerPostCommit:
		return directUpgradeProtocolDialerPostCommitState(state)
	case directUpgradeProtocolStateDialerPostCommitBeforeConverged:
		return state == directUpgradeProtocolStatePostCommitStart || state == directUpgradeProtocolStatePostCommitAccepted
	case directUpgradeProtocolStateDialerPostCommitAwaitingFrame:
		return state == directUpgradeProtocolStatePostCommitStart || state == directUpgradeProtocolStatePostCommitConverged
	default:
		return transition.from == state
	}
}

func directUpgradeProtocolListenerPostCommitState(state directUpgradeProtocolState) bool {
	switch state {
	case directUpgradeProtocolStatePostCommitStart,
		directUpgradeProtocolStatePostCommitAccepted,
		directUpgradeProtocolStatePostCommitConverged:
		return true
	default:
		return false
	}
}

func directUpgradeProtocolDialerPatternState(state directUpgradeProtocolState) bool {
	switch state {
	case directUpgradeProtocolStateDialerPostCommit,
		directUpgradeProtocolStateDialerPostCommitBeforeConverged,
		directUpgradeProtocolStateDialerPostCommitAwaitingFrame:
		return true
	default:
		return false
	}
}

func directUpgradeProtocolDialerPostCommitState(state directUpgradeProtocolState) bool {
	switch state {
	case directUpgradeProtocolStatePostCommitStart,
		directUpgradeProtocolStatePostCommitAccepted,
		directUpgradeProtocolStatePostCommitConverged:
		return true
	default:
		return false
	}
}

// The post-commit helpers stay beside directUpgradeProtocolTransitions because
// they derive their order from the authoritative transition table.
func directUpgradePostCommitPhaseOrder(role upgradeRole) (directUpgradePostCommitPhaseOrderTable, bool) {
	cursor := newDirectUpgradeProtocolCursor(role, directUpgradeProtocolStatePostCommitStart)
	var order directUpgradePostCommitPhaseOrderTable
	for step := range order {
		transition, ok := cursor.next(directUpgradePostCommitEvent(role, directUpgradePostCommitStep(step)))
		if !ok || transition.postCommitStep != directUpgradePostCommitStep(step) || transition.postCommitAction.local == 0 {
			return directUpgradePostCommitPhaseOrderTable{}, false
		}
		order[step] = transition.postCommitAction
	}
	if cursor.state != directUpgradeProtocolStateTerminal {
		return directUpgradePostCommitPhaseOrderTable{}, false
	}
	return order, true
}

func directUpgradePostCommitEvent(role upgradeRole, step directUpgradePostCommitStep) directUpgradeProtocolEvent {
	if role == upgradeRoleListen {
		if step == directUpgradePostCommitStepConfirmed {
			return directUpgradeProtocolEventListenerConfirmed
		}
		return directUpgradeProtocolEventPostCommitAdvance
	}
	switch step {
	case directUpgradePostCommitStepAccepted:
		return directUpgradeProtocolEventDialerAccepted
	case directUpgradePostCommitStepConverged:
		return directUpgradeProtocolEventDialerConverged
	case directUpgradePostCommitStepConfirmed:
		return directUpgradeProtocolEventDialerConfirmed
	default:
		return directUpgradeProtocolEventNoEvent
	}
}
