package connect

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"time"

	"github.com/GridSwarm/wiremux/internal/proberuntime"
	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// errTurnRetryCrossProfileProbe reports a valid v1 probe datagram observed on
// the turn-retry probe path; cross-profile probe traffic maps to
// protocol_mismatch rather than being silently ignored.
var errTurnRetryCrossProfileProbe = errors.New("connect: cross-profile probe datagram on turn-retry path")

// turnRetryEngine drives one role's TURN retry sequence after retry-dialect
// selection. The upgrade dispatcher retains dialect authority; this engine
// owns the role's allocation validation, policy, preparation, authenticated
// retry probe, materialization, and convergence phases, and routes every
// terminal disposition through the selected-path claims and the terminal
// executor.
type turnRetryEngine struct {
	attempt directUpgradeAttempt
	session Session
	local   localUpgradeOffer
	peer    localUpgradeOffer

	retryCtx    context.Context
	cancelRetry context.CancelFunc

	// stage names the retry step in flight for failure labeling. The single
	// goroutine driving this role's retry sequence writes and reads it at
	// phase boundaries; failure paths attach it through stageError so a
	// budget expiry or peer abort names the stalled step (issue #1218).
	stage turnRetryStage

	turn           *attemptResources
	composite      RelayPacketConn
	localRelayAddr netip.AddrPort
	peerRelayAddr  netip.AddrPort
	localNonce     []byte
	peerNonce      []byte
}

func (e *turnRetryEngine) localRelayCandidate() Candidate {
	return Candidate{Kind: CandidateKindRelay, Addr: e.localRelayAddr}
}

func (e *turnRetryEngine) peerRelayCandidate() Candidate {
	return Candidate{Kind: CandidateKindRelay, Addr: e.peerRelayAddr}
}

func (e *turnRetryEngine) policy() CandidatePolicy {
	return e.attempt.cfg.candidatePolicy
}

// stageError labels err with the retry stage currently in flight.
func (e *turnRetryEngine) stageError(err error) error {
	return turnRetryStageError(e.stage, err)
}

// malformedConvergenceFrame names the post-commit convergence frame that
// failed to decode beneath the stable malformed-convergence family cause.
func (e *turnRetryEngine) malformedConvergenceFrame(frame string) error {
	return fmt.Errorf("connect: %s frame: %w", frame, errTurnRetryConvergenceMalformed)
}

// stageErrorGuarded labels err with the retry stage currently in flight
// unless the outer context has ended, in which case the bare context error is
// returned: caller-driven termination is not a retry-path failure and stays
// unlabeled.
func (e *turnRetryEngine) stageErrorGuarded(ctx context.Context, err error) error {
	if ctxErr := ctx.Err(); ctxErr != nil {
		return ctxErr
	}
	return e.stageError(err)
}

// adoptAllocation validates the single Allocate outcome: only an official
// marked result with a canonical relayed address continues. The composite
// becomes a fresh raw-owned TURN claim without any root marker, and its
// immutable canonical relayed address is consumed exactly once here; policy
// and the emitted Retry Offer read only this canonicalized value.
func (e *turnRetryEngine) adoptAllocation(outcome turnRetryAllocationOutcome, allocation *turnRetryAllocation) bool {
	if outcome.err != nil || outcome.conn == nil || !relayprofile.IsTURNQUIC3(outcome.conn) {
		allocation.dispose()
		return false
	}
	addr, err := addrPortFromNetAddr(outcome.conn.LocalAddr())
	if err != nil || !addr.IsValid() || addr.Port() == 0 {
		allocation.dispose()
		return false
	}
	e.composite = outcome.conn
	e.localRelayAddr = addr
	e.turn = newOwnedTURNPathClaim(e.attempt.channel, outcome.conn)
	return true
}

// disposeComposite disposes the owned composite through the terminal
// executor's disposal-before-join path when a claim exists. It returns any
// stream that materialized during the join so callers can route a transferred
// result to fail-closed instead of reliable fallback.
func (e *turnRetryEngine) disposeComposite() transportStreamResult {
	if e.turn == nil {
		return transportStreamResult{}
	}
	return e.turn.disposeOwnedCompositeBeforeJoin()
}

type turnRetryRaceEventKind uint8

const (
	turnRetryRaceFrame turnRetryRaceEventKind = iota + 1
	turnRetryRaceWorkDone
	turnRetryRaceRetryExpired
	turnRetryRaceContextDone
)

type turnRetryRaceEvent struct {
	kind  turnRetryRaceEventKind
	frame controlFrameReadResult
}

// raceWorkAgainstControl races one unit of retry work against the next
// authenticated control frame and this role's retry deadline. It is a
// sanctioned controlFrameSequencer.next race site: a losing frame stays
// buffered for the next consumer, and the caller must handle a received
// frame.
func (e *turnRetryEngine) raceWorkAgainstControl(ctx context.Context, workDone <-chan struct{}) turnRetryRaceEvent {
	select {
	case frame := <-e.attempt.controlFrames.next():
		return turnRetryRaceEvent{kind: turnRetryRaceFrame, frame: frame}
	case <-workDone:
		return turnRetryRaceEvent{kind: turnRetryRaceWorkDone}
	case <-e.retryCtx.Done():
		if ctx.Err() != nil {
			return turnRetryRaceEvent{kind: turnRetryRaceContextDone}
		}
		return turnRetryRaceEvent{kind: turnRetryRaceRetryExpired}
	}
}

// raceHandoffWorkAgainstControl is the materialization-phase variant: the
// role's retry budget has ended, so only the handoff budget and the outer
// context bound the race.
func (e *turnRetryEngine) raceHandoffWorkAgainstControl(ctx, handoffCtx context.Context, workDone <-chan struct{}) turnRetryRaceEvent {
	select {
	case frame := <-e.attempt.controlFrames.next():
		return turnRetryRaceEvent{kind: turnRetryRaceFrame, frame: frame}
	case <-workDone:
		return turnRetryRaceEvent{kind: turnRetryRaceWorkDone}
	case <-handoffCtx.Done():
		if ctx.Err() != nil {
			return turnRetryRaceEvent{kind: turnRetryRaceContextDone}
		}
		return turnRetryRaceEvent{kind: turnRetryRaceRetryExpired}
	}
}

// isStaleTurnRetryFrame reports whether payload is a valid non-Fallback retry
// frame that crossed a local Fallback decision in flight; the terminal
// exchange skips such frames while awaiting the peer's Fallback.
func isStaleTurnRetryFrame(payload []byte) bool {
	if _, ok := decodeTurnRetryOffer(payload); ok {
		return true
	}
	if _, ok := decodeTurnRetrySelected(payload); ok {
		return true
	}
	if decodeTurnRetryStart(payload) || decodeTurnRetryReady(payload) || decodeTurnRetryCommit(payload) {
		return true
	}
	if _, ok := decodeTurnRetryAccepted(payload); ok {
		return true
	}
	if _, ok := decodeTurnRetryConverged(payload); ok {
		return true
	}
	if _, ok := decodeTurnRetryConfirmed(payload); ok {
		return true
	}
	return false
}

// handlePostSelectionFrame classifies a frame that arrived while retry work
// was active. disposeAndJoin must cancel local retry work, invoke composite
// disposal before awaiting the joins, and report any independently completed
// local failure disposition (or UpgradeFallbackNone when work was merely
// preempted). A materialized transferred stream inside disposeAndJoin must be
// handled by the caller before calling this.
func (e *turnRetryEngine) handlePostSelectionFrame(
	ctx context.Context,
	frame controlFrameReadResult,
	disposeAndJoin func() UpgradeFallbackReason,
) (UpgradeResult, error) {
	a := e.attempt
	if frame.err != nil {
		disposeAndJoin()
		if ctxErr := ctx.Err(); ctxErr != nil {
			return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
		}
		return a.resources().failClosed(e.stageError(frame.err), abortBeforeOwnedResources)
	}
	if fallback, ok := decodeTurnRetryFallback(frame.payload); ok {
		local := disposeAndJoin()
		return a.turnRetrySettlePreempted(ctx, e.stage, local, fallback.Reason)
	}
	// Malformed post-selection frame: send retry code 5 under precedence,
	// cancel local retry operations, invoke each local composite's Close
	// before awaiting the joins, and return synchronized reliable fallback.
	disposeAndJoin()
	return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProtocolMismatch, UpgradeFallbackProtocolMismatch, func() {})
}

// writeOfferUnderRetryBudget publishes a Retry Offer bounded by both the
// role-local retry budget and the existing control timeout. A write still in
// flight at retry expiry is joined under the control timeout before any later
// frame so abandoned bytes cannot interleave; expiry with a completed write
// reports expired=true so the caller resolves synchronized retry code 6
// instead of continuing the sequence.
func (e *turnRetryEngine) writeOfferUnderRetryBudget(ctx context.Context, frame []byte) (expired bool, err error) {
	a := e.attempt
	writeErr := make(chan error, 1)
	go func() { writeErr <- writeFull(a.channel, frame) }()

	timer := time.NewTimer(a.cfg.controlTimeout)
	defer timer.Stop()
	retryDone := e.retryCtx.Done()
	for {
		select {
		case err := <-writeErr:
			if err != nil {
				if ctxErr := ctx.Err(); ctxErr != nil {
					return expired, ctxErr
				}
				return expired, err
			}
			// The budget state is authoritative even when the write-completion
			// arm wins a select where the deadline is simultaneously ready.
			if !expired && ctx.Err() == nil && errors.Is(e.retryCtx.Err(), context.DeadlineExceeded) {
				expired = true
			}
			return expired, nil
		case <-retryDone:
			if ctxErr := ctx.Err(); ctxErr != nil {
				return expired, ctxErr
			}
			// Record the budget expiry and keep joining the in-flight write
			// under the independent control timeout.
			expired = true
			retryDone = nil
		case <-ctx.Done():
			return expired, ctx.Err()
		case <-timer.C:
			if ctxErr := ctx.Err(); ctxErr != nil {
				return expired, ctxErr
			}
			return expired, ErrUpgradeControlTimeout
		}
	}
}

// preparePeer runs PreparePeer under the retry budget, racing authenticated
// control receipt and cancellation. The bool reports a terminal outcome.
func (e *turnRetryEngine) preparePeer(ctx context.Context) (UpgradeResult, error, bool) {
	a := e.attempt
	e.stage = turnRetryStagePeerPreparation
	prepErr := make(chan error, 1)
	prepDone := make(chan struct{})
	go func() {
		err := e.composite.PreparePeer(e.retryCtx, e.peerRelayAddr)
		prepErr <- err
		close(prepDone)
	}()
	disposeAndJoin := func() UpgradeFallbackReason {
		e.cancelRetry()
		e.disposeComposite()
		<-prepDone
		err := <-prepErr
		prepErr <- err
		if err != nil && !errors.Is(err, context.Canceled) && !errors.Is(err, net.ErrClosed) {
			return UpgradeFallbackProbeFailed
		}
		return UpgradeFallbackNone
	}

	ev := e.raceWorkAgainstControl(ctx, prepDone)
	switch ev.kind {
	case turnRetryRaceWorkDone:
		err := <-prepErr
		prepErr <- err
		if err == nil {
			return UpgradeResult{}, nil, false
		}
		if ctxErr := ctx.Err(); ctxErr != nil {
			e.cancelRetry()
			e.disposeComposite()
			result, rerr := a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
			return result, rerr, true
		}
		// Role-specific preparation failure synchronizes retry Fallback 6 and
		// publicly preserves the original direct probe_failed.
		e.cancelRetry()
		result, rerr := a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() { e.disposeComposite() })
		return result, rerr, true
	case turnRetryRaceFrame:
		result, rerr := e.handlePostSelectionFrame(ctx, ev.frame, disposeAndJoin)
		return result, rerr, true
	case turnRetryRaceRetryExpired:
		e.cancelRetry()
		result, rerr := a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {
			e.disposeComposite()
			<-prepDone
		})
		return result, rerr, true
	default:
		e.cancelRetry()
		e.disposeComposite()
		<-prepDone
		result, rerr := a.resources().failClosed(ctx.Err(), abortBeforeOwnedResources)
		return result, rerr, true
	}
}

type turnRetryProbeState struct {
	outcome  *probeCandidatePairsOutcome
	cancel   context.CancelFunc
	done     chan struct{}
	outcomes chan probeCandidatePairsOutcome
}

// turnRetryProbeRunner is the test seam (upgradeConfig.testTurnRetryProbeRunner)
// that replaces the probe execution inside startRetryProbe's goroutine. It
// changes only what runs there, never how the probe is started, canceled,
// joined, or released, so tests can pin a joined outcome that scheduler
// timing cannot otherwise force (issue #1272).
type turnRetryProbeRunner func(ctx context.Context, role upgradeRole) (candidatePairProbeResult, error)

// startRetryProbe launches the authenticated retry probe through the existing
// bounded scheduler: repeated requests reuse its retry interval/jitter and
// attempt-pass behavior until the shared retry deadline, so packets lost
// before the peer's permission/ChannelBind readiness are tolerated within
// that budget.
func (e *turnRetryEngine) startRetryProbe(role upgradeRole) (*turnRetryProbeState, error) {
	dialerNonce, listenerNonce := orderedProbeNonces(role, e.localNonce, e.peerNonce)
	probeKey, err := turnRetryProbeWireParams().deriveKey(e.attempt.auth.Exporter(), dialerNonce, listenerNonce)
	if err != nil {
		return nil, err
	}
	probeCtx, cancelProbe := context.WithCancel(e.retryCtx)
	runtime, err := proberuntime.New(probeCtx, e.composite)
	if err != nil {
		cancelProbe()
		return nil, err
	}
	deadline, ok := e.retryCtx.Deadline()
	if !ok {
		deadline = runtime.Now().Add(defaultTURNRetryTimeout)
	}
	retryDelay := e.attempt.testProbeRetry
	if retryDelay == nil {
		retryDelay = probeRetryDelay
	}
	pairs := []probeCandidatePair{{local: e.localRelayCandidate(), remote: e.peerRelayCandidate()}}
	state := &turnRetryProbeState{
		cancel:   cancelProbe,
		done:     make(chan struct{}),
		outcomes: make(chan probeCandidatePairsOutcome, 1),
	}
	go func() {
		var (
			result candidatePairProbeResult
			err    error
		)
		if runner := e.attempt.cfg.testTurnRetryProbeRunner; runner != nil {
			result, err = runner(probeCtx, role)
		} else {
			result, err = probePairsWithRetryDelay(
				probeCtx, runtime, deadline, probeKey, role, pairs, 1, retryDelay,
				turnRetryProbeWireParams(), role == upgradeRoleListen,
			)
		}
		runtime.Release()
		state.outcomes <- probeCandidatePairsOutcome{result: result, err: err}
		close(state.done)
	}()
	return state, nil
}

// join cancels the probe and returns its outcome exactly once, caching it for
// repeated calls.
func (p *turnRetryProbeState) join() probeCandidatePairsOutcome {
	if p.outcome != nil {
		return *p.outcome
	}
	p.cancel()
	<-p.done
	outcome := <-p.outcomes
	p.outcome = &outcome
	return outcome
}

// localProbeDisposition maps a joined probe outcome to an independently
// completed local disposition; cancellation artifacts never replace a peer
// reason.
func localProbeDisposition(outcome probeCandidatePairsOutcome) UpgradeFallbackReason {
	if outcome.err != nil {
		if errors.Is(outcome.err, errTurnRetryCrossProfileProbe) {
			return UpgradeFallbackProtocolMismatch
		}
		if errors.Is(outcome.err, context.Canceled) {
			return UpgradeFallbackNone
		}
		return UpgradeFallbackProbeFailed
	}
	if outcome.result.succeeded {
		return UpgradeFallbackNone
	}
	return UpgradeFallbackProbeFailed
}

// sendTurnRetryPostCommitFrame writes an already-encoded retry frame under
// the post-commit budget with the same publication-grace semantics as the v1
// post-commit sender.
func (e *turnRetryEngine) sendTurnRetryPostCommitFrame(postCommitCtx context.Context, frame []byte) error {
	writeErr := make(chan error, 1)
	go func() { writeErr <- writeFull(e.attempt.channel, frame) }()
	return awaitPostCommitWrite(postCommitCtx, writeErr)
}

// stagePostCommitCause selects the outer-context, budget, or observed cause
// for a post-commit fail-closed disposition. Outer-context termination stays
// unlabeled; post-commit budget expiry and observed internal failures carry
// the in-flight retry stage label (issue #1218 diagnostics).
func (e *turnRetryEngine) stagePostCommitCause(ctx, postCommitCtx context.Context, observed error) error {
	if ctxErr := ctx.Err(); ctxErr != nil {
		return ctxErr
	}
	if ctxErr := postCommitCtx.Err(); ctxErr != nil {
		return e.stageError(ctxErr)
	}
	return e.stageError(observed)
}

// runListener drives the listener retry sequence from authenticated Retry
// Start receipt: start the role-local retry budget, evaluate relay-kind
// exclusion before allocation, allocate exactly once, exchange offers,
// prepare the canonical peer, answer and run the authenticated retry probe,
// cancel-and-join it at the dialer's authenticated Selected — a held success
// or the Selected frame's bilateral evidence proceeds while a real probe
// failure fails closed (#1218) — materialize over the composite, and drive
// commit and convergence.
func (a directUpgradeAttempt) runTurnRetryListener(
	ctx context.Context,
	session Session,
	local localUpgradeOffer,
	peer localUpgradeOffer,
) (UpgradeResult, error) {
	retryCtx, cancelRetry := context.WithTimeout(ctx, a.cfg.turnRetryTimeout)
	defer cancelRetry()
	e := &turnRetryEngine{
		attempt:     a,
		session:     session,
		local:       local,
		peer:        peer,
		retryCtx:    retryCtx,
		cancelRetry: cancelRetry,
		stage:       turnRetryStageAllocation,
	}

	// Listener relay-kind exclusion is evaluated after Start and before its
	// local allocation; the listener's retry Fallback selects the retry
	// dialect with zero allocator calls.
	if turnRetryRelayKindExcluded(e.policy()) {
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackPolicyExcluded, UpgradeFallbackPolicyExcluded, func() {})
	}

	allocation := startTurnRetryAllocation(retryCtx, a.cfg.turnAllocator)
	outcome := allocation.join()
	if ctxErr := ctx.Err(); ctxErr != nil {
		allocation.dispose()
		return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
	}
	if errors.Is(retryCtx.Err(), context.DeadlineExceeded) {
		allocation.dispose()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {})
	}
	if !e.adoptAllocation(outcome, allocation) {
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {})
	}
	if candidateAddrMatchesPrefix(e.localRelayCandidate(), e.policy().ExcludeLocalPrefixes) {
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackPolicyExcluded, UpgradeFallbackPolicyExcluded, func() { e.disposeComposite() })
	}

	e.stage = turnRetryStageOfferExchange
	nonce, err := newProbeNonce()
	if err != nil {
		e.disposeComposite()
		return a.resources().failClosed(err, retainForOuterSettlement)
	}
	e.localNonce = nonce
	offerFrame, err := encodeTurnRetryOffer(turnRetryOffer{
		candidate:     e.localRelayCandidate(),
		packetProfile: turnRetryPacketProfileQUIC3,
		probeNonce:    nonce,
	})
	if err != nil {
		e.disposeComposite()
		return a.resources().failClosed(err, retainForOuterSettlement)
	}
	offerExpired, err := e.writeOfferUnderRetryBudget(ctx, offerFrame)
	if err != nil {
		e.disposeComposite()
		return a.resources().failClosed(e.stageErrorGuarded(ctx, err), abortBeforeOwnedResources)
	}
	if offerExpired {
		// The role-local retry budget covers both offers: expiry during
		// publication resolves synchronized retry Fallback 6.
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() { e.disposeComposite() })
	}

	// Await the dialer's retry Offer under the shared retry budget.
	ev := e.raceWorkAgainstControl(ctx, nil)
	switch ev.kind {
	case turnRetryRaceFrame:
	case turnRetryRaceRetryExpired:
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() { e.disposeComposite() })
	default:
		e.cancelRetry()
		e.disposeComposite()
		return a.resources().failClosed(ctx.Err(), abortBeforeOwnedResources)
	}
	frame := ev.frame
	if frame.err != nil {
		e.disposeComposite()
		if ctxErr := ctx.Err(); ctxErr != nil {
			return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
		}
		return a.resources().failClosed(e.stageError(frame.err), abortBeforeOwnedResources)
	}
	dialerOffer, ok := decodeTurnRetryOffer(frame.payload)
	if !ok {
		return e.handlePostSelectionFrame(ctx, frame, func() UpgradeFallbackReason {
			e.cancelRetry()
			e.disposeComposite()
			return UpgradeFallbackNone
		})
	}
	if candidateAddrMatchesPrefix(dialerOffer.candidate, e.policy().ExcludeRemotePrefixes) {
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackPolicyExcluded, UpgradeFallbackPolicyExcluded, func() { e.disposeComposite() })
	}
	e.peerRelayAddr = dialerOffer.candidate.Addr
	e.peerNonce = append([]byte(nil), dialerOffer.probeNonce...)

	if result, rerr, terminal := e.preparePeer(ctx); terminal {
		return result, rerr
	}

	e.stage = turnRetryStageProbe
	probe, err := e.startRetryProbe(upgradeRoleListen)
	if err != nil {
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() { e.disposeComposite() })
	}
	var (
		selected      turnRetrySelected
		selectedValid bool
	)
	probePending := probe.done
	for !selectedValid {
		ev := e.raceWorkAgainstControl(ctx, probePending)
		switch ev.kind {
		case turnRetryRaceWorkDone:
			// The probe completed before Selected; hold its outcome and keep
			// waiting for the dialer's frame under the retry budget.
			probePending = nil
			outcome := probe.join()
			if disposition := localProbeDisposition(outcome); disposition != UpgradeFallbackNone {
				e.cancelRetry()
				return a.turnRetryTerminalFallbackExchange(ctx, e.stage, disposition, disposition, func() { e.disposeComposite() })
			}
		case turnRetryRaceFrame:
			frame := ev.frame
			if frame.err != nil {
				e.cancelRetry()
				e.disposeComposite()
				probe.join()
				if ctxErr := ctx.Err(); ctxErr != nil {
					return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
				}
				return a.resources().failClosed(e.stageError(frame.err), abortBeforeOwnedResources)
			}
			if sel, ok := decodeTurnRetrySelected(frame.payload); ok {
				if sel.dialer != e.peerRelayCandidate() || sel.listener != e.localRelayCandidate() {
					// Impossible selected state: not the exact
					// authenticated relay/relay pair. Invoke composite
					// disposal before awaiting the probe join — probe work
					// blocked in composite I/O wakes only through Close.
					e.cancelRetry()
					return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProtocolMismatch, UpgradeFallbackProtocolMismatch, func() {
						e.disposeComposite()
						probe.join()
					})
				}
				probeOutcome := probe.join()
				if !probeOutcome.result.succeeded {
					if probeOutcome.err != nil && !errors.Is(probeOutcome.err, context.Canceled) {
						// Only a real local probe failure fails closed
						// here. Without one, the authenticated Selected
						// frame is itself bilateral pair evidence: it can
						// exist only because this listener's HMAC-signed
						// probe response traversed the exact relayed pair
						// both ways (#1218).
						disposition := localProbeDisposition(probeOutcome)
						e.cancelRetry()
						return a.turnRetryTerminalFallbackExchange(ctx, e.stage, disposition, disposition, func() { e.disposeComposite() })
					}
				}
				selected = sel
				if selected.rtt <= 0 {
					selected.rtt = probeOutcome.result.rtt
				}
				selectedValid = true
				continue
			}
			return e.handlePostSelectionFrame(ctx, frame, func() UpgradeFallbackReason {
				e.cancelRetry()
				e.disposeComposite()
				return localProbeDisposition(probe.join())
			})
		case turnRetryRaceRetryExpired:
			e.cancelRetry()
			return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {
				e.disposeComposite()
				probe.join()
			})
		default:
			e.cancelRetry()
			e.disposeComposite()
			probe.join()
			return a.resources().failClosed(ctx.Err(), abortBeforeOwnedResources)
		}
	}

	return e.runListenerMaterialization(ctx, selected)
}

// runListenerMaterialization mirrors the existing ready/commit
// materialization boundaries over the TURN composite: Listen at Selected
// validation, Ready after Listen succeeds and Accept starts, Commit awaited
// concurrently with Accept, then Accepted/Converged/Confirmed convergence.
func (e *turnRetryEngine) runListenerMaterialization(ctx context.Context, selected turnRetrySelected) (UpgradeResult, error) {
	a := e.attempt
	e.stage = turnRetryStageReadyCommit
	handoffCtx, cancelHandoff := context.WithTimeout(ctx, a.cfg.probeTimeout)
	defer cancelHandoff()

	listenCh := e.turn.startListen(handoffCtx, e.session, e.composite, netUDPAddr(e.peerRelayAddr), e.peer.handshakeMaterial)
	listenSig := make(chan struct{})
	var listenResult transportListenResult
	go func() {
		listenResult = <-listenCh
		close(listenSig)
	}()
	for {
		ev := e.raceHandoffWorkAgainstControl(ctx, handoffCtx, listenSig)
		if ev.kind == turnRetryRaceWorkDone {
			break
		}
		switch ev.kind {
		case turnRetryRaceFrame:
			return e.handlePostSelectionFrame(ctx, ev.frame, func() UpgradeFallbackReason {
				cancelHandoff()
				e.disposeComposite()
				<-listenSig
				return UpgradeFallbackNone
			})
		case turnRetryRaceRetryExpired:
			// Handoff budget expiry is a listener precommit readiness failure.
			cancelHandoff()
			return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {
				e.disposeComposite()
				<-listenSig
			})
		default:
			cancelHandoff()
			e.disposeComposite()
			<-listenSig
			result, err := a.resources().failClosed(ctx.Err(), abortBeforeOwnedResources)
			return result, err
		}
	}
	if listenResult.err != nil || listenResult.listener == nil {
		e.disposeComposite()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {})
	}

	// Accept spans the commit boundary: like the v1 listener, it runs under
	// the outer context so the spent precommit handoff budget cannot cancel
	// an Accept that the fresh postcommit budget is still waiting for.
	_, acceptCh := e.turn.startAccept(ctx, listenResult.listener)
	acceptSig := make(chan struct{})
	var acceptResult transportAcceptResult
	go func() {
		acceptResult = <-acceptCh
		close(acceptSig)
	}()
	// disposeAndClassify routes the disposal-before-join result: a
	// materialized stream crossed the transfer boundary and forbids reliable
	// fallback.
	disposeAndClassify := func() *transportStreamResult {
		result := e.disposeComposite()
		<-acceptSig
		if result.stream != nil {
			return &result
		}
		return nil
	}

	readyFrame, err := encodeTurnRetryReady()
	if err != nil {
		if transferred := disposeAndClassify(); transferred != nil {
			return e.turn.failClosed(e.stageError(err), abortAfterOwnedResources)
		}
		return a.resources().failClosed(err, retainForOuterSettlement)
	}
	if err := a.writeUpgradeControlFrame(ctx, readyFrame); err != nil {
		if transferred := disposeAndClassify(); transferred != nil {
			return e.turn.failClosed(e.stageErrorGuarded(ctx, err), abortAfterOwnedResources)
		}
		if ctxErr := ctx.Err(); ctxErr != nil {
			return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
		}
		return a.resources().failClosed(e.stageError(err), abortBeforeOwnedResources)
	}

	acceptDone := false
	commitObserved := false
	acceptPending := acceptSig
	for !commitObserved {
		ev := e.raceHandoffWorkAgainstControl(ctx, handoffCtx, acceptPending)
		switch ev.kind {
		case turnRetryRaceWorkDone:
			acceptPending = nil
			acceptDone = true
			switch classifyTransportStreamResult(acceptResult) {
			case transportStreamResultSuccess:
				// Hold the accepted stream and keep awaiting Commit.
			case transportStreamResultMaterializedError:
				// A non-nil stream transferred ownership even with an error;
				// reliable fallback is no longer available.
				return e.turn.failClosed(e.stageErrorGuarded(ctx, acceptResult.err), abortAfterOwnedResources)
			default:
				// Listener precommit readiness failure without transfer.
				e.disposeComposite()
				return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {})
			}
		case turnRetryRaceFrame:
			frame := ev.frame
			if frame.err == nil && decodeTurnRetryCommit(frame.payload) {
				commitObserved = true
				continue
			}
			// A well-formed frame (peer Fallback or malformed payload) carries
			// no error of its own; the transferred-resource family names the
			// disposition so the exit still carries its stage.
			transferredCause := frame.err
			if transferredCause == nil {
				transferredCause = errTurnRetryTransferredResource
			}
			if acceptDone && acceptResult.stream != nil {
				// Transfer boundary crossed: any precommit failure now fails
				// closed on the stream owner.
				return e.turn.failClosed(e.stageErrorGuarded(ctx, transferredCause), abortAfterOwnedResources)
			}
			// Dispose before awaiting the Accept join, then classify: a stream
			// that materializes during the join crossed the transfer boundary
			// and forbids reliable fallback.
			cancelHandoff()
			transferred := disposeAndClassify()
			if transferred != nil {
				return e.turn.failClosed(e.stageErrorGuarded(ctx, transferredCause), abortAfterOwnedResources)
			}
			if frame.err != nil {
				if ctxErr := ctx.Err(); ctxErr != nil {
					return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
				}
				return a.resources().failClosed(e.stageError(frame.err), abortBeforeOwnedResources)
			}
			if fallback, ok := decodeTurnRetryFallback(frame.payload); ok {
				return a.turnRetrySettlePreempted(ctx, e.stage, UpgradeFallbackNone, fallback.Reason)
			}
			return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProtocolMismatch, UpgradeFallbackProtocolMismatch, func() {})
		case turnRetryRaceRetryExpired:
			cancelHandoff()
			if acceptDone && acceptResult.stream != nil {
				return e.turn.failClosed(e.stageError(errTurnRetryTransferredResource), abortAfterOwnedResources)
			}
			if transferred := disposeAndClassify(); transferred != nil {
				return e.turn.failClosed(e.stageError(errTurnRetryTransferredResource), abortAfterOwnedResources)
			}
			return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {})
		default:
			cancelHandoff()
			if acceptDone && acceptResult.stream != nil {
				return e.turn.failClosed(ctx.Err(), abortAfterOwnedResources)
			}
			if transferred := disposeAndClassify(); transferred != nil {
				return e.turn.failClosed(ctx.Err(), abortAfterOwnedResources)
			}
			return a.resources().failClosed(ctx.Err(), abortBeforeOwnedResources)
		}
	}

	// Commit observed: finality on the TURN claim; the direct claim's
	// borrowed conn is released untouched at the TURN switch.
	e.turn.registerCommit()
	a.resources().markTerminalClaimReleasedBorrow()
	e.stage = turnRetryStagePostCommit

	postCommitCtx, cancelPostCommit := a.newOwnedTransportBudgetContext(ctx)
	defer cancelPostCommit()
	if !acceptDone {
		select {
		case <-acceptSig:
		case <-postCommitCtx.Done():
			return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, nil), abortAfterOwnedResources)
		}
	}
	if classifyTransportStreamResult(acceptResult) != transportStreamResultSuccess {
		cause := acceptResult.err
		if acceptResult.stream == nil && cause == nil {
			cause = errNilTransportStream
		}
		return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, cause), abortAfterOwnedResources)
	}

	acceptedFrame, err := encodeTurnRetryAccepted(acceptResult.datagrams != nil)
	if err != nil {
		return e.turn.failClosed(e.stageError(err), abortAfterOwnedResources)
	}
	if err := e.sendTurnRetryPostCommitFrame(postCommitCtx, acceptedFrame); err != nil {
		return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, err), abortAfterOwnedResources)
	}

	convergedFrame, err := a.controlFrames.recv(postCommitCtx, 0)
	if err != nil {
		return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, err), abortAfterOwnedResources)
	}
	convergedDatagrams, ok := decodeTurnRetryConverged(convergedFrame.payload)
	if !ok {
		return e.turn.failClosed(e.stageError(e.malformedConvergenceFrame("Converged")), abortAfterOwnedResources)
	}
	if convergedDatagrams && acceptResult.datagrams == nil {
		return e.turn.failClosed(e.stageError(errDatagramExposureAgreementMismatch), abortAfterOwnedResources)
	}
	datagramsAgreed := convergedDatagrams

	confirmedFrame, err := encodeTurnRetryConfirmed(datagramsAgreed)
	if err != nil {
		return e.turn.failClosed(e.stageError(err), abortAfterOwnedResources)
	}
	if err := e.sendTurnRetryPostCommitFrame(postCommitCtx, confirmedFrame); err != nil {
		return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, err), abortAfterOwnedResources)
	}

	datagrams := acceptResult.datagrams
	if !datagramsAgreed {
		datagrams = nil
	}
	return e.turn.succeedDirect(
		CandidatePair{Local: e.localRelayCandidate(), Remote: e.peerRelayCandidate()},
		selected.rtt,
		datagrams,
	)
}

// runDialer continues the dialer after the listener's retry Offer selected
// the retry dialect: complete the single allocation, apply policy, send the
// dialer Offer, prepare the canonical peer, run the authenticated retry
// probe, select the exact pair, and drive commit and convergence over the
// TURN composite.
func (e *turnRetryEngine) runDialer(ctx context.Context, allocation *turnRetryAllocation, peerOffer turnRetryOffer) (UpgradeResult, error) {
	a := e.attempt

	// ExcludeRemotePrefixes applies to the authenticated peer relay address
	// when its Offer is received.
	if candidateAddrMatchesPrefix(peerOffer.candidate, e.policy().ExcludeRemotePrefixes) {
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackPolicyExcluded, UpgradeFallbackPolicyExcluded, allocation.dispose)
	}
	e.peerRelayAddr = peerOffer.candidate.Addr
	e.peerNonce = append([]byte(nil), peerOffer.probeNonce...)

	// Complete the allocation, racing authenticated control receipt: the
	// listener may preempt with a retry Fallback while Allocate is in flight.
	allocDone := make(chan struct{})
	go func() {
		allocation.join()
		close(allocDone)
	}()
	for {
		ev := e.raceWorkAgainstControl(ctx, allocDone)
		if ev.kind == turnRetryRaceWorkDone {
			break
		}
		switch ev.kind {
		case turnRetryRaceFrame:
			return e.handlePostSelectionFrame(ctx, ev.frame, func() UpgradeFallbackReason {
				e.cancelRetry()
				outcome := allocation.join()
				local := turnRetryEntryLocalDisposition(e.retryCtx, outcome)
				allocation.dispose()
				return local
			})
		case turnRetryRaceRetryExpired:
			e.cancelRetry()
			return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, allocation.dispose)
		default:
			e.cancelRetry()
			allocation.dispose()
			return a.resources().failClosed(ctx.Err(), abortBeforeOwnedResources)
		}
	}
	if !e.adoptAllocation(allocation.join(), allocation) {
		// Nil result, non-nil-plus-error, unmarked, or non-canonical address:
		// close every non-nil result, then synchronize retry Fallback 6 while
		// publicly preserving the original direct probe_failed.
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {})
	}

	// ExcludeLocalPrefixes applies to this role's allocated relay address
	// after Allocate and before Offer.
	if candidateAddrMatchesPrefix(e.localRelayCandidate(), e.policy().ExcludeLocalPrefixes) {
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackPolicyExcluded, UpgradeFallbackPolicyExcluded, func() { e.disposeComposite() })
	}

	e.stage = turnRetryStageOfferExchange
	nonce, err := newProbeNonce()
	if err != nil {
		e.disposeComposite()
		return a.resources().failClosed(err, retainForOuterSettlement)
	}
	e.localNonce = nonce
	offerFrame, err := encodeTurnRetryOffer(turnRetryOffer{
		candidate:     e.localRelayCandidate(),
		packetProfile: turnRetryPacketProfileQUIC3,
		probeNonce:    nonce,
	})
	if err != nil {
		e.disposeComposite()
		return a.resources().failClosed(err, retainForOuterSettlement)
	}
	offerExpired, err := e.writeOfferUnderRetryBudget(ctx, offerFrame)
	if err != nil {
		e.disposeComposite()
		return a.resources().failClosed(e.stageErrorGuarded(ctx, err), abortBeforeOwnedResources)
	}
	if offerExpired {
		// The role-local retry budget covers both offers: expiry during
		// publication resolves synchronized retry Fallback 6.
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() { e.disposeComposite() })
	}

	if result, rerr, terminal := e.preparePeer(ctx); terminal {
		return result, rerr
	}

	e.stage = turnRetryStageProbe
	probe, err := e.startRetryProbe(upgradeRoleDial)
	if err != nil {
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() { e.disposeComposite() })
	}
	var probeOutcome probeCandidatePairsOutcome
	for {
		ev := e.raceWorkAgainstControl(ctx, probe.done)
		if ev.kind == turnRetryRaceWorkDone {
			probeOutcome = probe.join()
			break
		}
		switch ev.kind {
		case turnRetryRaceFrame:
			return e.handlePostSelectionFrame(ctx, ev.frame, func() UpgradeFallbackReason {
				e.cancelRetry()
				e.disposeComposite()
				return localProbeDisposition(probe.join())
			})
		case turnRetryRaceRetryExpired:
			e.cancelRetry()
			return a.turnRetryTerminalFallbackExchange(ctx, e.stage, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, func() {
				e.disposeComposite()
				probe.join()
			})
		default:
			e.cancelRetry()
			e.disposeComposite()
			probe.join()
			return a.resources().failClosed(ctx.Err(), abortBeforeOwnedResources)
		}
	}
	if disposition := localProbeDisposition(probeOutcome); disposition != UpgradeFallbackNone || !probeOutcome.result.succeeded {
		if disposition == UpgradeFallbackNone {
			disposition = UpgradeFallbackProbeFailed
		}
		e.cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, e.stage, disposition, disposition, func() { e.disposeComposite() })
	}

	e.stage = turnRetryStageReadyCommit
	selectedFrame, err := encodeTurnRetrySelected(turnRetrySelected{
		dialer:   e.localRelayCandidate(),
		listener: e.peerRelayCandidate(),
		rtt:      probeOutcome.result.rtt,
	})
	if err != nil {
		e.disposeComposite()
		return a.resources().failClosed(err, retainForOuterSettlement)
	}
	if err := a.writeUpgradeControlFrame(ctx, selectedFrame); err != nil {
		e.disposeComposite()
		if ctxErr := ctx.Err(); ctxErr != nil {
			return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
		}
		return a.resources().failClosed(e.stageError(err), abortBeforeOwnedResources)
	}

	readyFrame, err := a.controlFrames.recv(ctx, a.cfg.controlTimeout)
	if err != nil {
		e.disposeComposite()
		if ctxErr := ctx.Err(); ctxErr != nil {
			return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
		}
		return a.resources().failClosed(e.stageError(err), abortBeforeOwnedResources)
	}
	if !decodeTurnRetryReady(readyFrame.payload) {
		return e.handlePostSelectionFrame(ctx, readyFrame, func() UpgradeFallbackReason {
			e.disposeComposite()
			return UpgradeFallbackNone
		})
	}

	commitFrame, err := encodeTurnRetryCommit()
	if err != nil {
		e.disposeComposite()
		return a.resources().failClosed(err, retainForOuterSettlement)
	}
	if err := a.writeUpgradeControlFrame(ctx, commitFrame); err != nil {
		e.disposeComposite()
		if ctxErr := ctx.Err(); ctxErr != nil {
			return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
		}
		return a.resources().failClosed(e.stageError(err), abortBeforeOwnedResources)
	}

	// Commit establishes finality on the TURN claim; the direct claim's
	// borrowed conn is released untouched at the TURN switch.
	e.turn.registerCommit()
	a.resources().markTerminalClaimReleasedBorrow()
	e.stage = turnRetryStagePostCommit

	postCommitCtx, cancelPostCommit := a.newOwnedTransportBudgetContext(ctx)
	defer cancelPostCommit()
	drainPacketConn(postCommitCtx, e.composite)
	dialCh := e.turn.startDial(postCommitCtx, e.session, e.composite, netUDPAddr(e.peerRelayAddr), e.peer.handshakeMaterial)

	acceptedFrame, err := a.controlFrames.recv(postCommitCtx, 0)
	if err != nil {
		return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, err), abortAfterOwnedResources)
	}
	peerDatagrams, ok := decodeTurnRetryAccepted(acceptedFrame.payload)
	if !ok {
		return e.turn.failClosed(e.stageError(e.malformedConvergenceFrame("Accepted")), abortAfterOwnedResources)
	}

	var dialResult transportStreamResult
	select {
	case dialResult = <-dialCh:
	case <-postCommitCtx.Done():
		return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, nil), abortAfterOwnedResources)
	}
	if classifyTransportStreamResult(dialResult) != transportStreamResultSuccess {
		cause := dialResult.err
		if dialResult.stream == nil && cause == nil {
			cause = errNilTransportStream
		}
		return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, cause), abortAfterOwnedResources)
	}

	datagramsAgreed := peerDatagrams && dialResult.datagrams != nil
	convergedFrame, err := encodeTurnRetryConverged(datagramsAgreed)
	if err != nil {
		return e.turn.failClosed(e.stageError(err), abortAfterOwnedResources)
	}
	if err := e.sendTurnRetryPostCommitFrame(postCommitCtx, convergedFrame); err != nil {
		return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, err), abortAfterOwnedResources)
	}

	confirmedFrame, err := a.controlFrames.recv(postCommitCtx, 0)
	if err != nil {
		return e.turn.failClosed(e.stagePostCommitCause(ctx, postCommitCtx, err), abortAfterOwnedResources)
	}
	confirmedDatagrams, ok := decodeTurnRetryConfirmed(confirmedFrame.payload)
	if !ok {
		return e.turn.failClosed(e.stageError(e.malformedConvergenceFrame("Confirmed")), abortAfterOwnedResources)
	}
	if confirmedDatagrams != datagramsAgreed {
		return e.turn.failClosed(e.stageError(errDatagramExposureAgreementMismatch), abortAfterOwnedResources)
	}

	datagrams := dialResult.datagrams
	if !datagramsAgreed {
		datagrams = nil
	}
	return e.turn.succeedDirect(
		CandidatePair{Local: e.localRelayCandidate(), Remote: e.peerRelayCandidate()},
		probeOutcome.result.rtt,
		datagrams,
	)
}
