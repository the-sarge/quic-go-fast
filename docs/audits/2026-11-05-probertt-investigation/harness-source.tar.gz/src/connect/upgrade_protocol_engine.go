package connect

import (
	"context"
	"errors"
	"time"
)

var errDatagramExposureAgreementMismatch = errors.New("connect: contradictory Datagram exposure agreement")

const postCommitWritePublicationGrace = 10 * time.Millisecond

type postCommitTransportResult = transportStreamResult

// postCommitIOOverride is the engine's one test seam over post-commit control
// I/O. Each operation is consulted only when non-nil.
type postCommitIOOverride struct {
	send  func(context.Context, upgradeControlPhase, bool) error
	await func(context.Context, upgradeControlPhase) (controlFrameReadResult, error)
}

type directUpgradeProtocolEngine struct {
	role upgradeRole

	attempt           directUpgradeAttempt
	session           Session
	peer              localUpgradeOffer
	pairPlan          candidatePairPlan
	localProbeRTT     time.Duration
	selected          selectedPair
	cursor            *directUpgradeProtocolCursor
	testDialerTrace   func(directUpgradeDialerRow)
	testListenerTrace func(directUpgradeListenerRow)
	runtime           *directUpgradeProtocolRuntime

	// testPostCommitIO, when set by a test, replaces the engine's post-commit
	// control operations for both managed roles. Production never sets it.
	testPostCommitIO postCommitIOOverride

	// turnRetryStart, when set on a bilateral listener, routes an exact Retry
	// Start received while holding local direct success into the TURN retry
	// listener: held success is discarded and the direct pair becomes
	// ineligible.
	turnRetryStart func(context.Context) (UpgradeResult, error)
}

type directUpgradeProtocolRuntime struct {
	handoffCtx       context.Context
	selected         selectedPair
	listenCh         <-chan transportListenResult
	listener         TransportListener
	acceptCancel     context.CancelFunc
	acceptCh         <-chan transportAcceptResult
	acceptResult     transportAcceptResult
	commitBudgetCtx  context.Context
	commitCancel     context.CancelFunc
	commitCh         <-chan commitAwaitResult
	postCommitCtx    context.Context
	postCommitCancel context.CancelFunc
	transportCh      <-chan postCommitTransportResult
	transport        postCommitTransportResult
	transportReady   bool
	peerDatagrams    bool
	datagramsAgreed  bool
}

type directUpgradeProtocolActionInput struct {
	cause          error
	fallbackReason UpgradeFallbackReason
	peerFallback   *terminalFallbackReadResult
	selected       selectedPair
	listenResult   transportListenResult
	acceptResult   transportAcceptResult
	commitResult   commitAwaitResult
	transport      postCommitTransportResult
	peerDatagrams  bool
}

type directUpgradeProtocolDispatchResult struct {
	result   UpgradeResult
	err      error
	terminal bool
}

func newDialerDirectUpgradeProtocolEngine(
	attempt directUpgradeAttempt,
	session Session,
	peer localUpgradeOffer,
	probeResult candidatePairProbeResult,
) directUpgradeProtocolEngine {
	_ = attempt.resources()
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, directUpgradeProtocolStateDialerAwaitReady)
	return directUpgradeProtocolEngine{
		role:          upgradeRoleDial,
		attempt:       attempt,
		session:       session,
		peer:          peer,
		localProbeRTT: probeResult.rtt,
		selected:      selectedPairFromProbeResult(probeResult),
		cursor:        &cursor,
	}
}

func (d directUpgradeProtocolEngine) runDialer(ctx, handoffCtx context.Context) (UpgradeResult, error) {
	a := d.attempt
	runtime := directUpgradeProtocolRuntime{}
	frame, err := encodeUpgradeControlSelectedPair(d.selected)
	if err != nil {
		return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerSelectedEncodeFailed, directUpgradeProtocolActionInput{cause: err}, &runtime)
	}
	if err := a.writeUpgradeControlFrame(ctx, frame); err != nil {
		return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerSelectedWriteFailed, directUpgradeProtocolActionInput{cause: err}, &runtime)
	}

	readyFrame, err := a.controlFrames.recv(handoffCtx, a.cfg.controlTimeout)
	if err != nil {
		if isPreCommitControlTimeout(err) {
			return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerReadyTimedOut, directUpgradeProtocolActionInput{cause: err}, &runtime)
		}
		return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerReadyControlFailed, directUpgradeProtocolActionInput{cause: err}, &runtime)
	}
	ready, payloadCause := decodeUpgradeControlPhasePayload(readyFrame.payload, upgradeControlPhaseReady)
	if a.cfg.strict && payloadCause != nil {
		return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerReadyControlFailed, directUpgradeProtocolActionInput{cause: payloadCause}, &runtime)
	}
	if ready.HasFallback {
		var peerFallback *terminalFallbackReadResult
		if ready.WireFallback {
			peerFallback = &terminalFallbackReadResult{peer: upgradeControlFallback{Reason: ready.FallbackReason}}
		}
		return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerReadyFallback, directUpgradeProtocolActionInput{fallbackReason: ready.FallbackReason, peerFallback: peerFallback}, &runtime)
	}
	if !ready.Is(upgradeControlPhaseReady) {
		return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerReadyPhaseMismatch, directUpgradeProtocolActionInput{}, &runtime)
	}
	if outcome := d.dispatchDialerEvent(ctx, directUpgradeProtocolEventDialerReadyAccepted, directUpgradeProtocolActionInput{}, &runtime); outcome.err != nil || outcome.terminal {
		return outcome.result, outcome.err
	}

	commitFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseCommit)
	if err != nil {
		return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerCommitEncodeFailed, directUpgradeProtocolActionInput{cause: err}, &runtime)
	}
	commitTransition, ok := d.cursor.resolve(directUpgradeProtocolEventDialerCommitPublished)
	if !ok || commitTransition.action.kind != directUpgradeProtocolActionCommitAndStartDial {
		return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerUnexpectedPreCommit, directUpgradeProtocolActionInput{cause: errUnexpectedPostCommitPhaseOrder}, &runtime)
	}
	if err := a.writeUpgradeControlFrame(ctx, commitFrame); err != nil {
		return d.terminalDialerEvent(ctx, directUpgradeProtocolEventDialerCommitWriteFailed, directUpgradeProtocolActionInput{cause: err}, &runtime)
	}
	if outcome := d.executeDialerTransition(ctx, commitTransition, directUpgradeProtocolActionInput{}, &runtime); outcome.err != nil || outcome.terminal {
		return outcome.result, outcome.err
	}
	defer runtime.postCommitCancel()
	d.runtime = &runtime
	return d.run(runtime.postCommitCtx, ctx)
}

func (d directUpgradeProtocolEngine) terminalDialerEvent(
	ctx context.Context,
	event directUpgradeProtocolEvent,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) (UpgradeResult, error) {
	outcome := d.dispatchDialerEvent(ctx, event, input, runtime)
	if !outcome.terminal && outcome.err == nil {
		return UpgradeResult{}, errUnexpectedPostCommitPhaseOrder
	}
	return outcome.result, outcome.err
}

func (d directUpgradeProtocolEngine) dispatchDialerEvent(
	ctx context.Context,
	event directUpgradeProtocolEvent,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolDispatchResult {
	transition, ok := d.cursor.resolve(event)
	if !ok {
		return d.dispatchUnexpectedDialerEvent(ctx, input, runtime)
	}
	return d.executeDialerTransition(ctx, transition, input, runtime)
}

func (d directUpgradeProtocolEngine) executeDialerTransition(
	ctx context.Context,
	transition directUpgradeProtocolTransition,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolDispatchResult {
	if d.testDialerTrace != nil && transition.dialerRow != "" {
		d.testDialerTrace(transition.dialerRow)
	}
	action := transition.action
	resources := d.attempt.resources()
	switch action.kind {
	case directUpgradeProtocolActionAdvance:
		d.cursor.apply(transition)
		return directUpgradeProtocolDispatchResult{}
	case directUpgradeProtocolActionCoordinateFallback:
		reason := action.fallbackReason
		if reason == UpgradeFallbackNone {
			reason = input.fallbackReason
		}
		fallback := newTerminalFallbackExchange(d.attempt)
		d.cursor.apply(transition)
		var result UpgradeResult
		var err error
		switch action.fallback {
		case directUpgradeFallbackWithSession:
			result, err = fallback.withSessionCleanup(ctx, d.session, reason)
		case directUpgradeFallbackSkippingReady:
			result, err = fallback.withSessionCleanupSkippingReady(ctx, d.session, reason)
		case directUpgradeFallbackWithPeer:
			result, err = fallback.withSessionCleanupUsingPeerFallback(ctx, d.session, reason, input.peerFallback)
		default:
			panic("connect: dialer fallback action has no execution plan")
		}
		return directUpgradeProtocolDispatchResult{result: result, err: err, terminal: true}
	case directUpgradeProtocolActionFailClosed:
		d.cursor.apply(transition)
		result, err := resources.failClosed(input.cause, action.control)
		return directUpgradeProtocolDispatchResult{result: result, err: err, terminal: true}
	case directUpgradeProtocolActionCommitAndStartDial:
		resources.registerCommit()
		runtime.postCommitCtx, runtime.postCommitCancel = d.attempt.newOwnedTransportBudgetContext(ctx)
		drainPacketConn(runtime.postCommitCtx, d.attempt.selectedPacketConn())
		runtime.transportCh = resources.startDial(
			runtime.postCommitCtx,
			d.session,
			d.attempt.selectedPacketConn(),
			netUDPAddr(d.selected.remote(upgradeRoleDial).Addr),
			d.peer.handshakeMaterial,
		)
		d.cursor.apply(transition)
		return directUpgradeProtocolDispatchResult{}
	case directUpgradeProtocolActionObserveDial:
		runtime.transport = input.transport
		runtime.transportReady = true
		runtime.transportCh = nil
		d.cursor.apply(transition)
		return directUpgradeProtocolDispatchResult{}
	case directUpgradeProtocolActionRecordAccepted:
		runtime.peerDatagrams = input.peerDatagrams
		d.cursor.apply(transition)
		return directUpgradeProtocolDispatchResult{}
	case directUpgradeProtocolActionSendConverged:
		if !runtime.transportReady {
			return directUpgradeProtocolDispatchResult{err: errUnexpectedPostCommitPhaseOrder}
		}
		runtime.datagramsAgreed = runtime.peerDatagrams && runtime.transport.datagrams != nil
		if err := d.sendPostCommit(runtime.postCommitCtx, transition.postCommitAction.phase, runtime.datagramsAgreed); err != nil {
			return directUpgradeProtocolDispatchResult{err: err}
		}
		d.cursor.apply(transition)
		return directUpgradeProtocolDispatchResult{}
	case directUpgradeProtocolActionSucceedDirect:
		transport := runtime.transport
		if !runtime.datagramsAgreed {
			transport.datagrams = nil
		}
		d.cursor.apply(transition)
		result, err := resources.succeedDirect(
			d.selected.candidatePair(upgradeRoleDial),
			selectedProbeRTT(d.selected, d.localProbeRTT),
			transport.datagrams,
		)
		return directUpgradeProtocolDispatchResult{result: result, err: err, terminal: true}
	default:
		return d.dispatchUnexpectedDialerEvent(ctx, directUpgradeProtocolActionInput{cause: errUnexpectedPostCommitPhaseOrder}, runtime)
	}
}

func (d directUpgradeProtocolEngine) dispatchUnexpectedDialerEvent(
	ctx context.Context,
	input directUpgradeProtocolActionInput,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolDispatchResult {
	if input.cause == nil {
		input.cause = errUnexpectedPostCommitPhaseOrder
	}
	event := directUpgradeProtocolEventDialerUnexpectedPreCommit
	if directUpgradeProtocolDialerPostCommitState(d.cursor.state) {
		event = d.dialerFailureEvent(
			runtime,
			directUpgradeProtocolEventDialerUnexpectedMaterialized,
			directUpgradeProtocolEventDialerUnexpectedPendingFailure,
			directUpgradeProtocolEventDialerUnexpectedPendingSuccess,
			directUpgradeProtocolEventDialerUnexpectedPendingMaterializedError,
		)
	}
	transition, ok := d.cursor.resolve(event)
	if !ok {
		panic("connect: dialer transition table lacks its internal-error row")
	}
	return d.executeDialerTransition(ctx, transition, input, runtime)
}

func (d directUpgradeProtocolEngine) run(
	postCommitCtx context.Context,
	callerCtx context.Context,
) (UpgradeResult, error) {
	managedRole := d.role == upgradeRoleDial || d.role == upgradeRoleListen
	if !managedRole || d.cursor == nil || d.runtime == nil {
		if managedRole && d.attempt.owner != nil {
			return d.attempt.owner.failClosed(errUnexpectedPostCommitPhaseOrder, abortAfterOwnedResources)
		}
		return UpgradeResult{}, errUnexpectedPostCommitPhaseOrder
	}
	if callerCtx == nil {
		callerCtx = postCommitCtx
	}
	managedDialer := d.dialerEngine()
	runtime := d.runtime
	cursor := d.cursor

	for {
		if outcome, terminal := d.pollEngineTransport(callerCtx, runtime); terminal {
			return d.finishEngineOutcome(outcome)
		}
		if cause := d.contextCause(callerCtx, runtime.postCommitCtx); cause != nil {
			return d.finishEngineOutcome(d.contextEngineOutcome(callerCtx, runtime, cause))
		}

		transition, ok := nextDirectUpgradePhaseTransition(cursor)
		if !ok {
			return d.finishEngineOutcome(d.unexpectedEngineOutcome(callerCtx, runtime))
		}
		if transition.postCommitStep == directUpgradePostCommitStepConverged && !runtime.transportReady {
			if outcome, terminal := d.awaitEngineTransport(callerCtx, runtime); terminal {
				return d.finishEngineOutcome(outcome)
			}
		}

		switch transition.postCommitAction.local {
		case directUpgradePostCommitSend:
			var outcome directUpgradeProtocolDispatchResult
			if managedDialer {
				outcome = d.executeDialerTransition(callerCtx, transition, directUpgradeProtocolActionInput{}, runtime)
			} else {
				advertise := directUpgradePhaseAdvertisement(transition.postCommitAction.phase, runtime)
				if err := d.sendPostCommit(runtime.postCommitCtx, transition.postCommitAction.phase, advertise); err != nil {
					event := directUpgradeProtocolEventListenerAcceptedSendFailed
					if transition.postCommitAction.phase == upgradeControlPhaseConfirmed {
						event = directUpgradeProtocolEventListenerConfirmedSendFailed
					}
					cause := err
					if contextCause := d.contextCause(callerCtx, runtime.postCommitCtx); contextCause != nil {
						cause = contextCause
						event = d.listenerContextEvent(callerCtx, runtime.postCommitCtx)
					}
					outcome = d.dispatchListenerEvent(callerCtx, event, directUpgradeProtocolActionInput{cause: cause, transport: runtime.transport}, runtime)
				} else {
					outcome = d.executeListenerTransition(callerCtx, transition, directUpgradeProtocolActionInput{}, runtime)
				}
			}
			if managedDialer && outcome.err != nil && !outcome.terminal {
				contextCause := d.contextCause(callerCtx, runtime.postCommitCtx)
				cause := outcome.err
				var event directUpgradeProtocolEvent
				if contextCause != nil {
					cause = contextCause
					event = d.dialerContextEvent(callerCtx, runtime.postCommitCtx, runtime)
				} else {
					event = d.dialerFailureEvent(
						runtime,
						directUpgradeProtocolEventDialerSendFailedMaterialized,
						directUpgradeProtocolEventDialerSendFailedPendingFailure,
						directUpgradeProtocolEventDialerSendFailedPendingSuccess,
						directUpgradeProtocolEventDialerSendFailedPendingMaterializedError,
					)
				}
				outcome = d.dispatchDialerEvent(callerCtx, event, directUpgradeProtocolActionInput{cause: cause, transport: runtime.transport}, runtime)
			}
			if outcome.terminal || outcome.err != nil {
				return d.finishEngineOutcome(outcome)
			}

		case directUpgradePostCommitAwait:
			frame, completedAtCancellation, outcome, terminal := d.awaitEnginePhase(
				callerCtx,
				runtime,
				transition.postCommitAction.phase,
			)
			if terminal {
				return d.finishEngineOutcome(outcome)
			}
			if frame.err != nil {
				if managedDialer {
					contextCause := d.contextCause(callerCtx, runtime.postCommitCtx)
					cause := frame.err
					var event directUpgradeProtocolEvent
					if contextCause != nil {
						cause = contextCause
						event = d.dialerContextEvent(callerCtx, runtime.postCommitCtx, runtime)
					} else {
						event = d.dialerFailureEvent(
							runtime,
							directUpgradeProtocolEventDialerReadFailedMaterialized,
							directUpgradeProtocolEventDialerReadFailedPendingFailure,
							directUpgradeProtocolEventDialerReadFailedPendingSuccess,
							directUpgradeProtocolEventDialerReadFailedPendingMaterializedError,
						)
					}
					outcome = d.dispatchDialerEvent(callerCtx, event, directUpgradeProtocolActionInput{cause: cause, transport: runtime.transport}, runtime)
				} else {
					cause := frame.err
					event := directUpgradeProtocolEventListenerConvergedReadFailed
					if contextCause := d.contextCause(callerCtx, runtime.postCommitCtx); contextCause != nil {
						cause = contextCause
						event = d.listenerContextEvent(callerCtx, runtime.postCommitCtx)
					}
					outcome = d.dispatchListenerEvent(callerCtx, event, directUpgradeProtocolActionInput{cause: cause, transport: runtime.transport}, runtime)
				}
				return d.finishEngineOutcome(outcome)
			}
			phase, payloadCause := decodeUpgradeControlPhasePayload(frame.payload, transition.postCommitAction.phase)
			if phase.HasFallback || !phase.Is(transition.postCommitAction.phase) {
				if managedDialer {
					event := d.dialerFailureEvent(
						runtime,
						directUpgradeProtocolEventDialerWrongPhaseMaterialized,
						directUpgradeProtocolEventDialerWrongPhasePendingFailure,
						directUpgradeProtocolEventDialerWrongPhasePendingSuccess,
						directUpgradeProtocolEventDialerWrongPhasePendingMaterializedError,
					)
					outcome = d.dispatchDialerEvent(callerCtx, event, directUpgradeProtocolActionInput{cause: d.attempt.terminalControlCause(payloadCause, nil), transport: runtime.transport}, runtime)
				} else {
					outcome = d.dispatchListenerEvent(callerCtx, directUpgradeProtocolEventListenerConvergedWrongPhase, directUpgradeProtocolActionInput{cause: d.attempt.terminalControlCause(payloadCause, ErrUpgradeTransportNotConverged), transport: runtime.transport}, runtime)
				}
				return d.finishEngineOutcome(outcome)
			}

			if managedDialer {
				switch transition.action.kind {
				case directUpgradeProtocolActionRecordAccepted:
					outcome = d.executeDialerTransition(
						callerCtx,
						transition,
						directUpgradeProtocolActionInput{peerDatagrams: phase.Datagrams},
						runtime,
					)
				case directUpgradeProtocolActionSucceedDirect:
					switch {
					case phase.Datagrams != runtime.datagramsAgreed:
						outcome = d.dispatchDialerEvent(
							callerCtx,
							directUpgradeProtocolEventDialerDatagramMismatch,
							directUpgradeProtocolActionInput{cause: errDatagramExposureAgreementMismatch, transport: runtime.transport},
							runtime,
						)
					case completedAtCancellation:
						outcome = d.dispatchDialerEvent(
							callerCtx,
							directUpgradeProtocolEventDialerConfirmedCompleted,
							directUpgradeProtocolActionInput{transport: runtime.transport},
							runtime,
						)
					default:
						outcome = d.executeDialerTransition(
							callerCtx,
							transition,
							directUpgradeProtocolActionInput{transport: runtime.transport},
							runtime,
						)
					}
				default:
					outcome = d.unexpectedEngineOutcome(callerCtx, runtime)
				}
			} else {
				switch {
				case transition.postCommitAction.phase != upgradeControlPhaseConverged:
					outcome = d.unexpectedEngineOutcome(callerCtx, runtime)
				case phase.Datagrams && runtime.transport.datagrams == nil:
					outcome = d.dispatchListenerEvent(
						callerCtx,
						directUpgradeProtocolEventListenerDatagramMismatch,
						directUpgradeProtocolActionInput{cause: errDatagramExposureAgreementMismatch, transport: runtime.transport},
						runtime,
					)
				default:
					runtime.datagramsAgreed = phase.Datagrams
					outcome = d.executeListenerTransition(callerCtx, transition, directUpgradeProtocolActionInput{}, runtime)
				}
			}
			if outcome.terminal || outcome.err != nil {
				return d.finishEngineOutcome(outcome)
			}

		default:
			return d.finishEngineOutcome(d.unexpectedEngineOutcome(callerCtx, runtime))
		}

		if cursor.state == directUpgradeProtocolStateTerminal {
			return d.finishEngineOutcome(d.unexpectedEngineOutcome(callerCtx, runtime))
		}
	}
}

func (d directUpgradeProtocolEngine) dialerEngine() bool {
	return d.role == upgradeRoleDial
}

func (d directUpgradeProtocolEngine) listenerEngine() bool {
	return d.role == upgradeRoleListen
}

func (d directUpgradeProtocolEngine) finishEngineOutcome(
	outcome directUpgradeProtocolDispatchResult,
) (UpgradeResult, error) {
	if !outcome.terminal {
		if outcome.err != nil {
			return UpgradeResult{}, outcome.err
		}
		return UpgradeResult{}, errUnexpectedPostCommitPhaseOrder
	}
	return outcome.result, outcome.err
}

func nextDirectUpgradePhaseTransition(
	cursor *directUpgradeProtocolCursor,
) (directUpgradeProtocolTransition, bool) {
	var found directUpgradeProtocolTransition
	count := 0
	for _, transition := range directUpgradeProtocolTransitions {
		if transition.role != cursor.role ||
			transition.postCommitAction.local == 0 ||
			!directUpgradeProtocolStateMatches(transition, cursor.state) {
			continue
		}
		found = transition
		count++
	}
	return found, count == 1
}

func directUpgradePhaseAdvertisement(
	phase upgradeControlPhase,
	runtime *directUpgradeProtocolRuntime,
) bool {
	switch phase {
	case upgradeControlPhaseAccepted:
		return runtime.transportReady && runtime.transport.datagrams != nil
	case upgradeControlPhaseConfirmed:
		return runtime.datagramsAgreed
	default:
		return false
	}
}

func (d directUpgradeProtocolEngine) pollEngineTransport(
	callerCtx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (directUpgradeProtocolDispatchResult, bool) {
	if runtime.transportReady || runtime.transportCh == nil {
		return directUpgradeProtocolDispatchResult{}, false
	}
	select {
	case result := <-runtime.transportCh:
		outcome := d.observeEngineTransport(callerCtx, runtime, result)
		return outcome, outcome.terminal || outcome.err != nil
	default:
		return directUpgradeProtocolDispatchResult{}, false
	}
}

func (d directUpgradeProtocolEngine) awaitEngineTransport(
	callerCtx context.Context,
	runtime *directUpgradeProtocolRuntime,
) (directUpgradeProtocolDispatchResult, bool) {
	if runtime.transportReady {
		return directUpgradeProtocolDispatchResult{}, false
	}
	if runtime.transportCh == nil {
		outcome := d.unexpectedEngineOutcome(callerCtx, runtime)
		return outcome, true
	}
	for {
		select {
		case result := <-runtime.transportCh:
			outcome := d.observeEngineTransport(callerCtx, runtime, result)
			return outcome, outcome.terminal || outcome.err != nil
		case <-callerCtx.Done():
			if d.dialerEngine() {
				if outcome, terminal := d.pollEngineTransport(callerCtx, runtime); terminal {
					return outcome, true
				}
			}
			return d.contextEngineOutcome(callerCtx, runtime, d.contextErr(callerCtx, runtime.postCommitCtx)), true
		case <-runtime.postCommitCtx.Done():
			if d.dialerEngine() {
				if outcome, terminal := d.pollEngineTransport(callerCtx, runtime); terminal {
					return outcome, true
				}
			}
			return d.contextEngineOutcome(callerCtx, runtime, d.contextErr(callerCtx, runtime.postCommitCtx)), true
		}
	}
}

func (d directUpgradeProtocolEngine) awaitEnginePhase(
	callerCtx context.Context,
	runtime *directUpgradeProtocolRuntime,
	expected upgradeControlPhase,
) (
	controlFrameReadResult,
	bool,
	directUpgradeProtocolDispatchResult,
	bool,
) {
	done := make(chan controlFrameReadResult, 1)
	go func() {
		frame, err := d.awaitPostCommit(runtime.postCommitCtx, expected)
		done <- controlFrameReadResult{payload: frame.payload, err: err}
	}()
	return d.awaitEnginePhaseFromDone(callerCtx, runtime, done)
}

func (d directUpgradeProtocolEngine) awaitEnginePhaseFromDone(
	callerCtx context.Context,
	runtime *directUpgradeProtocolRuntime,
	done <-chan controlFrameReadResult,
) (
	controlFrameReadResult,
	bool,
	directUpgradeProtocolDispatchResult,
	bool,
) {
	pollDone := func() (controlFrameReadResult, bool) {
		select {
		case frame := <-done:
			return frame, true
		default:
			return controlFrameReadResult{}, false
		}
	}
	if frame, ok := pollDone(); ok {
		return frame, d.contextCause(callerCtx, runtime.postCommitCtx) != nil, directUpgradeProtocolDispatchResult{}, false
	}
	for {
		select {
		case result := <-runtime.transportCh:
			outcome := d.observeEngineTransport(callerCtx, runtime, result)
			if outcome.terminal || outcome.err != nil {
				return controlFrameReadResult{}, false, outcome, true
			}
		case frame := <-done:
			return frame, false, directUpgradeProtocolDispatchResult{}, false
		case <-callerCtx.Done():
			if frame, ok := pollDone(); ok {
				return frame, true, directUpgradeProtocolDispatchResult{}, false
			}
			if d.dialerEngine() {
				if outcome, terminal := d.pollEngineTransport(callerCtx, runtime); terminal {
					return controlFrameReadResult{}, false, outcome, true
				}
			}
			outcome := d.contextEngineOutcome(callerCtx, runtime, d.contextErr(callerCtx, runtime.postCommitCtx))
			return controlFrameReadResult{}, false, outcome, true
		case <-runtime.postCommitCtx.Done():
			if frame, ok := pollDone(); ok {
				return frame, true, directUpgradeProtocolDispatchResult{}, false
			}
			if d.dialerEngine() {
				if outcome, terminal := d.pollEngineTransport(callerCtx, runtime); terminal {
					return controlFrameReadResult{}, false, outcome, true
				}
			}
			outcome := d.contextEngineOutcome(callerCtx, runtime, d.contextErr(callerCtx, runtime.postCommitCtx))
			return controlFrameReadResult{}, false, outcome, true
		}
	}
}

func (d directUpgradeProtocolEngine) observeEngineTransport(
	callerCtx context.Context,
	runtime *directUpgradeProtocolRuntime,
	result postCommitTransportResult,
) directUpgradeProtocolDispatchResult {
	if d.dialerEngine() {
		return d.observeDialerTransport(callerCtx, runtime, result)
	}
	runtime.transport = result
	runtime.transportReady = true
	runtime.transportCh = nil
	if cause := d.transportFailureCause(callerCtx, runtime.postCommitCtx, result); cause != nil {
		event := d.listenerContextEvent(callerCtx, runtime.postCommitCtx)
		return d.dispatchListenerEvent(
			callerCtx,
			event,
			directUpgradeProtocolActionInput{cause: cause, transport: result},
			runtime,
		)
	}
	return directUpgradeProtocolDispatchResult{}
}

func (d directUpgradeProtocolEngine) observeDialerTransport(
	callerCtx context.Context,
	runtime *directUpgradeProtocolRuntime,
	result postCommitTransportResult,
) directUpgradeProtocolDispatchResult {
	event := directUpgradeProtocolEventDialerDialSucceeded
	cause := result.err
	switch {
	case result.stream != nil && result.datagramCarrierValidationErr:
		event = directUpgradeProtocolEventDialerDialDatagramValidationFailed
	case result.stream != nil && result.err != nil:
		event = directUpgradeProtocolEventDialerDialMaterializedError
	case result.stream == nil && result.err != nil:
		event = directUpgradeProtocolEventDialerDialFailed
	case result.stream == nil:
		event = directUpgradeProtocolEventDialerDialNilResult
		cause = errNilTransportStream
	}
	return d.dispatchDialerEvent(
		callerCtx,
		event,
		directUpgradeProtocolActionInput{cause: cause, transport: result},
		runtime,
	)
}

func (d directUpgradeProtocolEngine) contextEngineOutcome(
	callerCtx context.Context,
	runtime *directUpgradeProtocolRuntime,
	cause error,
) directUpgradeProtocolDispatchResult {
	if d.listenerEngine() {
		event := d.listenerContextEvent(callerCtx, runtime.postCommitCtx)
		return d.dispatchListenerEvent(
			callerCtx,
			event,
			directUpgradeProtocolActionInput{cause: cause, transport: runtime.transport},
			runtime,
		)
	}
	event := d.dialerContextEvent(callerCtx, runtime.postCommitCtx, runtime)
	return d.dispatchDialerEvent(
		callerCtx,
		event,
		directUpgradeProtocolActionInput{cause: cause, transport: runtime.transport},
		runtime,
	)
}

func (d directUpgradeProtocolEngine) unexpectedEngineOutcome(
	callerCtx context.Context,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolDispatchResult {
	if d.listenerEngine() {
		return d.dispatchListenerEvent(
			callerCtx,
			directUpgradeProtocolEventListenerUnexpectedMaterialized,
			directUpgradeProtocolActionInput{cause: errUnexpectedPostCommitPhaseOrder, transport: runtime.transport},
			runtime,
		)
	}
	return d.dispatchUnexpectedDialerEvent(
		callerCtx,
		directUpgradeProtocolActionInput{cause: errUnexpectedPostCommitPhaseOrder, transport: runtime.transport},
		runtime,
	)
}

func (d directUpgradeProtocolEngine) listenerContextEvent(
	callerCtx context.Context,
	postCommitCtx context.Context,
) directUpgradeProtocolEvent {
	if callerCtx != nil && callerCtx.Err() != nil {
		return directUpgradeProtocolEventListenerPostcommitCanceled
	}
	if postCommitCtx != nil && postCommitCtx.Err() != nil {
		return directUpgradeProtocolEventListenerPostcommitBudgetExpired
	}
	return directUpgradeProtocolEventListenerUnexpectedMaterialized
}

func (d directUpgradeProtocolEngine) dialerContextEvent(
	callerCtx context.Context,
	postCommitCtx context.Context,
	runtime *directUpgradeProtocolRuntime,
) directUpgradeProtocolEvent {
	if callerCtx != nil && callerCtx.Err() != nil {
		return d.dialerFailureEvent(
			runtime,
			directUpgradeProtocolEventDialerCallerCanceledMaterialized,
			directUpgradeProtocolEventDialerCallerCanceledPendingFailure,
			directUpgradeProtocolEventDialerCallerCanceledPendingSuccess,
			directUpgradeProtocolEventDialerCallerCanceledPendingMaterializedError,
		)
	}
	if postCommitCtx != nil && postCommitCtx.Err() != nil {
		return d.dialerFailureEvent(
			runtime,
			directUpgradeProtocolEventDialerBudgetExpiredMaterialized,
			directUpgradeProtocolEventDialerBudgetExpiredPendingFailure,
			directUpgradeProtocolEventDialerBudgetExpiredPendingSuccess,
			directUpgradeProtocolEventDialerBudgetExpiredPendingMaterializedError,
		)
	}
	return d.dialerFailureEvent(
		runtime,
		directUpgradeProtocolEventDialerUnexpectedMaterialized,
		directUpgradeProtocolEventDialerUnexpectedPendingFailure,
		directUpgradeProtocolEventDialerUnexpectedPendingSuccess,
		directUpgradeProtocolEventDialerUnexpectedPendingMaterializedError,
	)
}

func (d directUpgradeProtocolEngine) dialerFailureEvent(
	runtime *directUpgradeProtocolRuntime,
	materialized directUpgradeProtocolEvent,
	pendingFailure directUpgradeProtocolEvent,
	pendingSuccess directUpgradeProtocolEvent,
	pendingMaterializedError directUpgradeProtocolEvent,
) directUpgradeProtocolEvent {
	if runtime.transportReady && runtime.transport.stream != nil {
		return materialized
	}
	result := d.attempt.resources().joinPendingDialForClassification()
	runtime.transport = result
	runtime.transportReady = true
	runtime.transportCh = nil
	switch classifyTransportStreamResult(result) {
	case transportStreamResultNoMaterialization:
		return pendingFailure
	case transportStreamResultSuccess:
		return pendingSuccess
	case transportStreamResultMaterializedError:
		return pendingMaterializedError
	default:
		panic("connect: pending Dial result has no classification")
	}
}

// sendPostCommit is the post-commit control sender for both managed roles.
// Its write arbitration at cancellation is owned by awaitPostCommitWrite:
// a completed write counts as sent (ADR-0006 D3), matching the TURN engine's
// sendTurnRetryPostCommitFrame.
func (d directUpgradeProtocolEngine) sendPostCommit(
	ctx context.Context,
	phase upgradeControlPhase,
	datagrams bool,
) error {
	if d.testPostCommitIO.send != nil {
		return d.testPostCommitIO.send(ctx, phase, datagrams)
	}
	frame, err := encodeUpgradeControlPostCommitPhase(phase, datagrams)
	if err != nil {
		return err
	}
	writeErr := make(chan error, 1)
	go func() { writeErr <- writeFull(d.attempt.channel, frame) }()
	return awaitPostCommitWrite(ctx, writeErr)
}

func awaitPostCommitWrite(ctx context.Context, writeErr <-chan error) error {
	select {
	case err := <-writeErr:
		if err != nil {
			if ctxErr := ctx.Err(); ctxErr != nil {
				return ctxErr
			}
		}
		return err
	case <-ctx.Done():
		select {
		case err := <-writeErr:
			if err == nil {
				return nil
			}
			return ctx.Err()
		default:
		}
		// A successful write that is already completing at cancellation owns the
		// D19 boundary. Wait only long enough for that completion to be published;
		// a blocked control write must not hold teardown indefinitely.
		timer := time.NewTimer(postCommitWritePublicationGrace)
		defer timer.Stop()
		select {
		case err := <-writeErr:
			if err == nil {
				return nil
			}
			return ctx.Err()
		case <-timer.C:
			return ctx.Err()
		}
	}
}

// awaitPostCommit is the post-commit control awaiter for both managed roles.
func (d directUpgradeProtocolEngine) awaitPostCommit(
	ctx context.Context,
	phase upgradeControlPhase,
) (controlFrameReadResult, error) {
	if d.testPostCommitIO.await != nil {
		return d.testPostCommitIO.await(ctx, phase)
	}
	return d.attempt.controlFrames.recv(ctx, 0)
}

func (d directUpgradeProtocolEngine) transportFailureCause(
	callerCtx context.Context,
	postCommitCtx context.Context,
	result postCommitTransportResult,
) error {
	if ctxErr := d.contextCause(callerCtx, postCommitCtx); ctxErr != nil {
		return ctxErr
	}
	if result.err != nil {
		return result.err
	}
	if result.stream == nil {
		return errNilTransportStream
	}
	return nil
}

func (d directUpgradeProtocolEngine) contextErr(
	callerCtx context.Context,
	postCommitCtx context.Context,
) error {
	if ctxErr := d.contextCause(callerCtx, postCommitCtx); ctxErr != nil {
		return ctxErr
	}
	return errUnexpectedPostCommitPhaseOrder
}

func (d directUpgradeProtocolEngine) contextCause(
	callerCtx context.Context,
	postCommitCtx context.Context,
) error {
	if ctxErr := callerCtx.Err(); ctxErr != nil {
		return ctxErr
	}
	if ctxErr := postCommitCtx.Err(); ctxErr != nil {
		return d.attempt.phaseTimeoutCause(ctxErr)
	}
	return nil
}
