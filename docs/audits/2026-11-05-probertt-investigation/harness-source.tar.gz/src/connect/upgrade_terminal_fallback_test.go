package connect

import (
	"bytes"
	"context"
	"errors"
	"net"
	"sync"
	"testing"
	"time"
)

func TestTerminalFallbackExchangeHandlesPeerControlEvent(t *testing.T) {
	controlErr := errors.New("control read failed")
	tests := []struct {
		name         string
		event        directUpgradeControlEvent
		cancel       bool
		committed    bool
		wantHandled  bool
		wantReason   UpgradeFallbackReason
		wantErr      error
		wantTerminal bool
	}{
		{name: "relay fallback", event: directUpgradeControlEvent{kind: directUpgradeControlEventRelayFallback, fallbackReason: UpgradeFallbackProbeFailed}, wantHandled: true, wantReason: UpgradeFallbackProbeFailed},
		{name: "ignore and keep waiting", event: directUpgradeControlEvent{kind: directUpgradeControlEventIgnoreAndKeepWaiting}},
		{name: "fail closed committed", event: directUpgradeControlEvent{kind: directUpgradeControlEventFailClosedCommitted}, committed: true, wantHandled: true, wantErr: ErrUpgradeTransportNotConverged, wantTerminal: true},
		{name: "control error", event: directUpgradeControlEvent{kind: directUpgradeControlEventControlError, cause: controlErr}, wantHandled: true, wantErr: controlErr, wantTerminal: true},
		{name: "commit observed", event: directUpgradeControlEvent{kind: directUpgradeControlEventCommitObserved}, wantHandled: true, wantErr: errUnexpectedDirectUpgradeControlState, wantTerminal: true},
		{name: "transport failure", event: directUpgradeControlEvent{kind: directUpgradeControlEventTransportFailure, cause: controlErr}, wantHandled: true, wantErr: errUnexpectedDirectUpgradeControlState, wantTerminal: true},
		{name: "zero", event: directUpgradeControlEvent{}, wantHandled: true, wantErr: errUnexpectedDirectUpgradeControlState, wantTerminal: true},
		{name: "unknown", event: directUpgradeControlEvent{kind: directUpgradeControlEventKind(99)}, wantHandled: true, wantErr: errUnexpectedDirectUpgradeControlState, wantTerminal: true},
		{name: "context error precedes unsupported event", event: directUpgradeControlEvent{kind: directUpgradeControlEventKind(99)}, cancel: true, wantHandled: true, wantErr: context.Canceled, wantTerminal: true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			channel := newScriptedControlChannel(nil, true)
			packetConn := &terminalTestPacketConn{}
			attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{channel: channel, cfg: upgradeConfig{packetConn: packetConn}})
			controlDisposition := abortBeforeOwnedResources
			if tt.committed {
				registerCompletedTestAcceptAttempt(
					attempt.resources(),
					&directHandoffSession{},
					&directHandoffListener{},
					transportAcceptResult{err: errors.New("pre-commit Accept failure")},
				)
				controlDisposition = abortAfterOwnedResources
			}
			exchange := newTerminalFallbackExchange(attempt)
			ctx, cancel := context.WithCancel(context.Background())
			if tt.cancel {
				cancel()
			} else {
				defer cancel()
			}

			handled, reason, result, err, terminal := exchange.handlePeerControlEvent(ctx, tt.event, terminalFallbackExchangeRequest{reason: UpgradeFallbackTransportFailed, controlDisposition: controlDisposition})
			if handled != tt.wantHandled || reason != tt.wantReason || terminal != tt.wantTerminal {
				t.Fatalf("outcome = (handled %v, reason %q, terminal %v), want (%v, %q, %v)", handled, reason, terminal, tt.wantHandled, tt.wantReason, tt.wantTerminal)
			}
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("error = %v, want %v", err, tt.wantErr)
			}
			if tt.wantTerminal && result.Stream != nil {
				t.Fatalf("terminal result stream = %T, want nil", result.Stream)
			}
		})
	}
}

func TestTerminalFallbackExchangeUsesPreSettledPeerFallback(t *testing.T) {
	channel := newScriptedControlChannel(nil, true)
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(),
		cfg: upgradeConfig{
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)

	result, err := newTerminalFallbackExchange(attempt).withPeerFallback(
		context.Background(),
		UpgradeFallbackTransportFailed,
		&terminalFallbackReadResult{peer: upgradeControlFallback{Reason: UpgradeFallbackProbeFailed}},
	)
	if err != nil {
		t.Fatalf("withPeerFallback error = %v, want nil", err)
	}
	if result.Stream != channel {
		t.Fatalf("fallback stream = %T, want relay channel", result.Stream)
	}
	if result.Path != UpgradePathRelay {
		t.Fatalf("fallback path = %q, want relay", result.Path)
	}
	if result.FallbackReason != UpgradeFallbackTransportFailed {
		t.Fatalf("fallback reason = %q, want transport_failed", result.FallbackReason)
	}
}

func TestTerminalFallbackExchangePreSettledPeerFallbackDoesNotStartControlRead(t *testing.T) {
	readStarted := make(chan struct{}, 1)
	channel := newDelayedWriteControlChannel(nil, true, 20*time.Millisecond)
	attempt := directUpgradeAttempt{
		channel: channel,
		controlFrames: newControlFrameSequencerWithRead(func() controlFrameReadResult {
			readStarted <- struct{}{}
			select {}
		}),
		cfg: upgradeConfig{
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)

	result, err := newTerminalFallbackExchange(attempt).withPeerFallback(
		context.Background(),
		UpgradeFallbackTransportFailed,
		&terminalFallbackReadResult{peer: upgradeControlFallback{Reason: UpgradeFallbackProbeFailed}},
	)
	if err != nil {
		t.Fatalf("withPeerFallback error = %v, want nil", err)
	}
	if result.Stream != channel {
		t.Fatalf("fallback stream = %T, want relay channel", result.Stream)
	}
	select {
	case <-readStarted:
		t.Fatal("pre-settled peer fallback started a control read")
	default:
	}
}

func TestTerminalFallbackExchangePeerFallbackErrorReturnsBeforeWrite(t *testing.T) {
	peerErr := errors.New("peer fallback read failed")
	channel := newScriptedControlChannel(nil, true)
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(),
		cfg: upgradeConfig{
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)

	result, err := newTerminalFallbackExchange(attempt).withPeerFallback(
		context.Background(),
		UpgradeFallbackTransportFailed,
		&terminalFallbackReadResult{err: peerErr},
	)
	if !errors.Is(err, peerErr) {
		t.Fatalf("withPeerFallback error = %v, want peer read error", err)
	}
	if result.Stream != nil {
		t.Fatal("peer read error returned stream")
	}
	if !channel.closed.Load() {
		t.Fatal("relay channel was not aborted")
	}
	channel.mu.Lock()
	writes := channel.writes.Len()
	channel.mu.Unlock()
	if writes != 0 {
		t.Fatalf("fallback write bytes = %d, want 0", writes)
	}
}

func TestTerminalFallbackExchangeFailureSourcesDisposeOwnedResources(t *testing.T) {
	t.Run("definitive materialized Accept peer control error", func(t *testing.T) {
		peerErr := errors.New("peer control failed")
		packetConn := &terminalTestPacketConn{}
		stream := &terminalTestStream{}
		listener := &directHandoffListener{}
		session := &directHandoffSession{}
		channel := newScriptedControlChannel(nil, true)
		attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
			channel:       channel,
			controlFrames: newBufferedControlFrameSequencer(),
			cfg: upgradeConfig{
				packetConn:     packetConn,
				controlTimeout: time.Second,
			},
		})
		registerCompletedTestAcceptAttempt(
			attempt.resources(),
			session,
			listener,
			transportAcceptResult{stream: stream, err: errors.New("Accept materialized with error")},
		)

		result, err := newTerminalFallbackExchange(attempt).withAcceptedSessionCleanupUsingPeerFallback(
			context.Background(),
			session,
			UpgradeFallbackTransportFailed,
			&terminalFallbackReadResult{err: peerErr},
		)

		assertTerminalFallbackAcceptFailure(t, attempt.resources(), result, err, peerErr, stream, packetConn, session, listener)
	})

	t.Run("definitive materialized Accept write failure", func(t *testing.T) {
		writeErr := errors.New("fallback write failed")
		packetConn := &terminalTestPacketConn{}
		stream := &terminalTestStream{}
		listener := &directHandoffListener{}
		session := &directHandoffSession{}
		channel := newWriteFailControlChannel(writeErr)
		attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
			channel:       channel,
			controlFrames: newBufferedControlFrameSequencer(),
			cfg: upgradeConfig{
				packetConn:     packetConn,
				controlTimeout: time.Second,
			},
		})
		registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, transportAcceptResult{stream: stream})

		result, err := newTerminalFallbackExchange(attempt).withAcceptedSessionCleanupUsingPeerFallback(
			context.Background(),
			session,
			UpgradeFallbackTransportFailed,
			&terminalFallbackReadResult{peer: upgradeControlFallback{Reason: UpgradeFallbackProbeFailed}},
		)

		assertTerminalFallbackAcceptFailure(t, attempt.resources(), result, err, writeErr, stream, packetConn, session, listener)
	})

	for _, test := range []struct {
		name       string
		newContext func() (context.Context, context.CancelFunc)
		wantErr    error
	}{
		{
			name: "pending Accept cancellation",
			newContext: func() (context.Context, context.CancelFunc) {
				ctx, cancel := context.WithCancel(context.Background())
				cancel()
				return ctx, func() {}
			},
			wantErr: context.Canceled,
		},
		{
			name: "pending Accept timeout",
			newContext: func() (context.Context, context.CancelFunc) {
				return context.Background(), func() {}
			},
			wantErr: ErrUpgradeControlTimeout,
		},
	} {
		t.Run(test.name, func(t *testing.T) {
			packetConn := &terminalTestPacketConn{}
			stream := &terminalTestStream{}
			ownedStream := newTestPacketOwningStream(stream, packetConn)
			listener := newTerminalTestAcceptListener(nil, ownedStream, nil)
			session := &terminalTestSession{}
			channel := newScriptedControlChannel(nil, true)
			attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
				channel:       channel,
				controlFrames: newControlFrameSequencer(channel),
				cfg: upgradeConfig{
					packetConn:     packetConn,
					controlTimeout: 5 * time.Millisecond,
				},
			})
			attempt.resources().registerSession(session)
			_, _ = attempt.resources().startAccept(context.Background(), listener)
			<-listener.acceptStarted
			ctx, cancel := test.newContext()
			defer cancel()

			result, err := newTerminalFallbackExchange(attempt).withAcceptedSessionCleanupUsingPeerFallback(
				ctx,
				session,
				UpgradeFallbackTransportFailed,
				nil,
			)

			if result != (UpgradeResult{}) || !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, test.wantErr) || errors.Is(err, errInvalidAttemptTerminalDisposition) {
				t.Fatalf("pending Accept terminal result = %+v, %v; want zero, transport-not-converged, and %v", result, err, test.wantErr)
			}
			if stream.closeCalls.Load() != 1 || packetConn.closeCalls.Load() != 1 || listener.closeCalls.Load() != 1 || session.closeCalls.Load() != 1 || !channel.closed.Load() {
				t.Fatalf("pending Accept cleanup = stream %d, packet %d, listener %d, session %d, control closed %t; want exactly once and closed", stream.closeCalls.Load(), packetConn.closeCalls.Load(), listener.closeCalls.Load(), session.closeCalls.Load(), channel.closed.Load())
			}
			assertTerminalFallbackSealed(t, attempt.resources())
		})
	}

	t.Run("definitive Listen peer control error", func(t *testing.T) {
		peerErr := errors.New("peer control failed")
		listener := &fallbackJoiningListener{}
		session := newTerminalSourceListenSession(listener, nil)
		channel := newScriptedControlChannel(nil, true)
		attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
			channel:       channel,
			controlFrames: newBufferedControlFrameSequencer(),
			cfg: upgradeConfig{
				controlTimeout: time.Second,
			},
		})
		listenDone := attempt.resources().startListen(context.Background(), session, nil, nil, nil)
		if got := <-listenDone; got.listener != listener || got.err != nil {
			t.Fatalf("Listen result = %T, %v; want exact listener, nil", got.listener, got.err)
		}

		result, err := newTerminalFallbackExchange(attempt).withSessionCleanupUsingPeerFallback(
			context.Background(),
			session,
			UpgradeFallbackTransportFailed,
			&terminalFallbackReadResult{err: peerErr},
		)

		if result != (UpgradeResult{}) || !errors.Is(err, peerErr) || errors.Is(err, errInvalidAttemptTerminalDisposition) {
			t.Fatalf("definitive Listen terminal result = %+v, %v; want zero and %v", result, err, peerErr)
		}
		if listener.closeCalls.Load() != 1 || session.closeCallCount() != 1 || !channel.closed.Load() {
			t.Fatalf("definitive Listen cleanup = listener %d, session %d, control closed %t; want exactly once and closed", listener.closeCalls.Load(), session.closeCallCount(), channel.closed.Load())
		}
		assertTerminalFallbackSealed(t, attempt.resources())
	})
}

func assertTerminalFallbackAcceptFailure(
	t *testing.T,
	owner *attemptResources,
	result UpgradeResult,
	err error,
	wantErr error,
	stream *terminalTestStream,
	packetConn *terminalTestPacketConn,
	session *directHandoffSession,
	listener *directHandoffListener,
) {
	t.Helper()
	if result != (UpgradeResult{}) || !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, wantErr) || errors.Is(err, errInvalidAttemptTerminalDisposition) {
		t.Fatalf("materialized Accept terminal result = %+v, %v; want zero, transport-not-converged, and %v", result, err, wantErr)
	}
	if stream.closeCalls.Load() != 1 || packetConn.closeCalls.Load() != 1 || !listener.closed || !session.closed {
		t.Fatalf("materialized Accept cleanup = stream %d, packet %d, listener closed %t, session closed %t; want exactly once and closed", stream.closeCalls.Load(), packetConn.closeCalls.Load(), listener.closed, session.closed)
	}
	assertTerminalFallbackSealed(t, owner)
}

func assertTerminalFallbackSealed(t *testing.T, owner *attemptResources) {
	t.Helper()
	owner.mu.Lock()
	sealed := owner.terminalSealed
	owner.mu.Unlock()
	if !sealed {
		t.Fatal("fallback failure did not seal terminal disposition")
	}
}

func TestTerminalFallbackExchangePreCommitCommitObservedFailsClosed(t *testing.T) {
	packetConn := &closeTrackingPacketConn{PacketConn: listenPacket(t, "127.0.0.1:0")}
	defer packetConn.Close()

	commitFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseCommit)
	if err != nil {
		t.Fatalf("encode commit: %v", err)
	}
	commitDone := make(chan commitAwaitResult, 1)
	commitDone <- commitAwaitResult{frame: controlFrameReadResult{payload: commitFrame[4:]}}
	channel := newScriptedControlChannel(nil, true)
	session := &directHandoffSession{}
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	registerCompletedTestAcceptAttempt(
		attempt.resources(),
		session,
		&directHandoffListener{},
		transportAcceptResult{err: errors.New("pre-commit Accept failure")},
	)

	result, err := newTerminalFallbackExchange(attempt).afterPreCommitAcceptFailure(context.Background(), session, commitDone)
	if !errors.Is(err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("afterPreCommitAcceptFailure error = %v, want transport-not-converged", err)
	}
	if result.Stream != nil {
		t.Fatal("commit-observed fallback returned stream")
	}
	if !session.closed {
		t.Fatal("session was not closed")
	}
	if !packetConn.closed.Load() {
		t.Fatal("packet conn was not closed")
	}
	if !channel.closed.Load() {
		t.Fatal("relay channel was not aborted")
	}
}

func TestTerminalFallbackExchangePreCommitTimeoutDoesNotSettleRelay(t *testing.T) {
	commitDone := make(chan commitAwaitResult, 1)
	commitDone <- commitAwaitResult{err: ErrUpgradeControlTimeout}
	channel := newScriptedControlChannel(nil, true)
	session := &directHandoffSession{}
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(),
		cfg: upgradeConfig{
			controlTimeout: 10 * time.Millisecond,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	registerCompletedTestAcceptAttempt(
		attempt.resources(),
		session,
		&directHandoffListener{},
		transportAcceptResult{err: errors.New("pre-commit Accept failure")},
	)

	result, err := newTerminalFallbackExchange(attempt).afterPreCommitAcceptFailure(context.Background(), session, commitDone)
	if !errors.Is(err, ErrUpgradeControlTimeout) {
		t.Fatalf("afterPreCommitAcceptFailure error = %v, want control timeout", err)
	}
	if result.Stream != nil {
		t.Fatal("pre-commit timeout returned relay stream")
	}
	if !session.closed {
		t.Fatal("session was not closed")
	}
	if !channel.closed.Load() {
		t.Fatal("relay channel was not aborted")
	}
}

func TestTerminalFallbackExchangePreCommitTimeoutWaitsForCallerDeadline(t *testing.T) {
	commitDone := make(chan commitAwaitResult, 1)
	commitDone <- commitAwaitResult{err: ErrUpgradeControlTimeout}
	channel := newScriptedControlChannel(nil, true)
	session := &directHandoffSession{}
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(),
		cfg: upgradeConfig{
			controlTimeout: time.Hour,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	registerCompletedTestAcceptAttempt(
		attempt.resources(),
		session,
		&directHandoffListener{},
		transportAcceptResult{err: errors.New("pre-commit Accept failure")},
	)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Millisecond)
	defer cancel()

	start := time.Now()
	result, err := newTerminalFallbackExchange(attempt).afterPreCommitAcceptFailure(ctx, session, commitDone)
	elapsed := time.Since(start)

	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("afterPreCommitAcceptFailure error = %v, want caller deadline", err)
	}
	if elapsed > 500*time.Millisecond {
		t.Fatalf("afterPreCommitAcceptFailure elapsed = %s, want caller deadline before control timeout", elapsed)
	}
	if result.Stream != nil {
		t.Fatal("pre-commit timeout returned relay stream")
	}
	if !session.closed {
		t.Fatal("session was not closed")
	}
	if !channel.closed.Load() {
		t.Fatal("relay channel was not aborted")
	}
}

func TestTerminalFallbackExchangeCommitSourceOwnsInFlightRead(t *testing.T) {
	staleFallback, err := encodeUpgradeControlFallback(UpgradeFallbackProtocolMismatch)
	if err != nil {
		t.Fatalf("encode stale fallback: %v", err)
	}
	commitFallback, err := encodeUpgradeControlFallback(UpgradeFallbackProbeFailed)
	if err != nil {
		t.Fatalf("encode commit fallback: %v", err)
	}
	commitDone := make(chan commitAwaitResult, 1)
	go func() {
		time.Sleep(20 * time.Millisecond)
		commitDone <- commitAwaitResult{frame: controlFrameReadResult{payload: commitFallback[4:]}}
	}()
	channel := newScriptedControlChannel(nil, true)
	session := &directHandoffSession{}
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(controlFrameReadResult{payload: staleFallback[4:]}),
		cfg: upgradeConfig{
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)

	result, err := newTerminalFallbackExchange(attempt).afterPreCommitAcceptFailure(context.Background(), session, commitDone)
	if err != nil {
		t.Fatalf("afterPreCommitAcceptFailure error = %v, want nil", err)
	}
	if result.Stream != channel {
		t.Fatalf("fallback stream = %T, want relay channel", result.Stream)
	}
	if result.FallbackReason != UpgradeFallbackTransportFailed {
		t.Fatalf("fallback reason = %q, want transport_failed from commit source", result.FallbackReason)
	}
	if !session.closed {
		t.Fatal("session was not closed")
	}
}

func TestTerminalFallbackExchangeListenerHandoffTimeoutDisablesCommitSource(t *testing.T) {
	peerFallback, err := encodeUpgradeControlFallback(UpgradeFallbackProtocolMismatch)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	commitDone := make(chan commitAwaitResult, 1)
	commitDone <- commitAwaitResult{err: ErrUpgradeControlTimeout}
	channel := newScriptedControlChannel(nil, true)
	session := &directHandoffSession{}
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(controlFrameReadResult{payload: peerFallback[4:]}),
		cfg: upgradeConfig{
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)

	result, err := newTerminalFallbackExchange(attempt).afterListenerHandoffTimeout(
		context.Background(),
		session,
		commitDone,
	)
	if err != nil {
		t.Fatalf("afterListenerHandoffTimeout error = %v, want nil", err)
	}
	if result.Stream != channel {
		t.Fatalf("fallback stream = %T, want relay channel", result.Stream)
	}
	if result.Path != UpgradePathRelay {
		t.Fatalf("fallback path = %q, want relay", result.Path)
	}
	if result.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("fallback reason = %q, want protocol_mismatch", result.FallbackReason)
	}
	if !session.closed {
		t.Fatal("session was not closed")
	}
}

func TestTerminalFallbackExchangeUsesSequencerUnreadReplay(t *testing.T) {
	peerFallback, err := encodeUpgradeControlFallback(UpgradeFallbackProtocolMismatch)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	channel := newScriptedControlChannel(peerFallback, false)
	attempt := directUpgradeAttempt{
		channel:       channel,
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			controlTimeout: time.Second,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	peerFrame := awaitSequencerResult(t, attempt.controlFrames.next())
	attempt.controlFrames.unread(peerFrame)

	result, err := newTerminalFallbackExchange(attempt).withPeerFallback(
		context.Background(),
		UpgradeFallbackTransportFailed,
		nil,
	)
	if err != nil {
		t.Fatalf("withPeerFallback error = %v, want nil", err)
	}
	if result.Stream != channel {
		t.Fatalf("fallback stream = %T, want relay channel", result.Stream)
	}
	if result.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("fallback reason = %q, want protocol_mismatch", result.FallbackReason)
	}
}

func TestProbeCandidatePairsWithTerminalFallbackReplaysSelectedPairThroughSequencer(t *testing.T) {
	packetConn := listenPacket(t, "127.0.0.1:0")
	defer packetConn.Close()
	listenerAddr, err := addrPortFromNetAddr(packetConn.LocalAddr())
	if err != nil {
		t.Fatalf("packet conn local addr: %v", err)
	}
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: listenerAddr}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:9")}
	selected := selectedPair{
		dialer:   dialerCandidate,
		listener: listenerCandidate,
		rtt:      7 * time.Millisecond,
	}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selected)
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}
	channel := newScriptedControlChannel(selectedFrame, false)
	attempt := directUpgradeAttempt{
		channel:       channel,
		auth:          testAuthContext(),
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			packetConn:       packetConn,
			probeTimeout:     time.Second,
			probeConcurrency: 1,
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	offer := localUpgradeOffer{
		role:       upgradeRoleListen,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
	}
	peer := localUpgradeOffer{
		probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes),
	}
	pairPlan := testListenerCandidatePairPlan(listenerCandidate, dialerCandidate)
	probeCtx, cancelProbe := context.WithTimeout(context.Background(), time.Second)
	defer cancelProbe()

	race, err := attempt.probeCandidatePairsWithTerminalFallback(
		probeCtx,
		cancelProbe,
		offer,
		peer,
		pairPlan,
	)
	if err != nil {
		t.Fatalf("probeCandidatePairsWithTerminalFallback error = %v", err)
	}
	if race.peer != nil {
		t.Fatalf("peer fallback = %#v, want nil", race.peer)
	}
	if race.kind != probeControlRaceSelectedPair {
		t.Fatalf("race kind = %v, want selected-pair observation", race.kind)
	}
	if race.probe.succeeded {
		t.Fatal("selected-pair frame fabricated probe success")
	}
	if race.probe != (candidatePairProbeResult{}) {
		t.Fatalf("selected-pair observation leaked probe result = %#v, want zero", race.probe)
	}
	if race.selected != selected {
		t.Fatalf("selected pair = %#v, want %#v", race.selected, selected)
	}

	replayed := awaitSequencerResult(t, attempt.controlFrames.next())
	decoded, _ := decodeUpgradeControlSelectedPairPhasePayload(replayed.payload)
	if !decoded.HasSelectedPair {
		t.Fatal("replayed control frame did not contain selected pair")
	}
	if decoded.SelectedPair != selected {
		t.Fatalf("replayed selected pair = %#v, want %#v", decoded.SelectedPair, selected)
	}
}

func TestProbeCandidatePairsWithTerminalFallbackSelectedPairOmitsRTT(t *testing.T) {
	packetConn := listenPacket(t, "127.0.0.1:0")
	defer packetConn.Close()
	listenerAddr, err := addrPortFromNetAddr(packetConn.LocalAddr())
	if err != nil {
		t.Fatalf("packet conn local addr: %v", err)
	}
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: listenerAddr}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:9")}
	selected := selectedPair{
		dialer:   dialerCandidate,
		listener: listenerCandidate,
	}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selected)
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}
	channel := newScriptedControlChannel(selectedFrame, false)
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		auth:          testAuthContext(),
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			packetConn:       packetConn,
			probeTimeout:     time.Second,
			probeConcurrency: 1,
		},
	})
	offer := localUpgradeOffer{
		role:       upgradeRoleListen,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
	}
	peer := localUpgradeOffer{
		probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes),
	}
	pairPlan := testListenerCandidatePairPlan(listenerCandidate, dialerCandidate)
	probeCtx, cancelProbe := context.WithTimeout(context.Background(), time.Second)
	defer cancelProbe()

	race, err := attempt.probeCandidatePairsWithTerminalFallback(
		probeCtx,
		cancelProbe,
		offer,
		peer,
		pairPlan,
	)
	if err != nil {
		t.Fatalf("probeCandidatePairsWithTerminalFallback error = %v", err)
	}
	if race.kind != probeControlRaceSelectedPair {
		t.Fatalf("race kind = %v, want selected-pair observation", race.kind)
	}
	if race.selected.rtt != 0 {
		t.Fatalf("omitted-frame selected rtt = %s, want 0", race.selected.rtt)
	}
	if race.probe != (candidatePairProbeResult{}) {
		t.Fatalf("omitted-frame observation leaked probe result = %#v, want zero", race.probe)
	}
	if got := selectedProbeRTT(race.selected, race.probe.rtt); got != 0 {
		t.Fatalf("selectedProbeRTT = %s, want 0 with no local probe fallback", got)
	}
}

func TestProbeCandidatePairsWithTerminalFallbackProbeDoneReportsSuccessfulProbe(t *testing.T) {
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	channel := newScriptedControlChannel(nil, true)
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	packetConn := &runtimeProviderPacketConn{runtime: runtime, local: listenerCandidate.Addr}
	offer := localUpgradeOffer{
		role:       upgradeRoleListen,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
	}
	peer := localUpgradeOffer{
		probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes),
	}
	probeKey, err := deriveProbeKey(testAuthContext().Exporter(), peer.probeNonce, offer.probeNonce)
	if err != nil {
		t.Fatalf("derive probe key: %v", err)
	}
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		response, err := encodeProbeDatagram(probeKey, probeMessageResponse, probeDirectionDialerToListener, decoded.ProbeID, dialerCandidate, listenerCandidate)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(dialerCandidate.Addr), nil)
		return nil
	}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:        channel,
		auth:           testAuthContext(),
		controlFrames:  newControlFrameSequencer(channel),
		testProbeRetry: func() time.Duration { return probeRetryInterval },
		cfg: upgradeConfig{
			packetConn:       packetConn,
			probeTimeout:     time.Second,
			probeConcurrency: 1,
		},
	})
	pairPlan := testListenerCandidatePairPlan(listenerCandidate, dialerCandidate)
	probeCtx, cancelProbe := context.WithTimeout(context.Background(), testCausalObservationTimeout)
	defer cancelProbe()

	race, err := attempt.probeCandidatePairsWithTerminalFallback(
		probeCtx,
		cancelProbe,
		offer,
		peer,
		pairPlan,
	)
	if err != nil {
		t.Fatalf("probeCandidatePairsWithTerminalFallback error = %v", err)
	}
	if race.kind != probeControlRaceProbeDone {
		t.Fatalf("race kind = %v, want probe-done", race.kind)
	}
	if !race.probe.succeeded {
		t.Fatalf("probe result = %#v, want successful local probe", race.probe)
	}
	if race.probe.pair != (probeCandidatePair{local: listenerCandidate, remote: dialerCandidate}) {
		t.Fatalf("probe pair = %#v, want listener-local pair", race.probe.pair)
	}
	if race.probe.rtt <= 0 {
		t.Fatalf("probe rtt = %s, want measured local probe timing", race.probe.rtt)
	}
	if race.peer != nil {
		t.Fatalf("peer fallback = %#v, want nil", race.peer)
	}
}

func TestProbeCandidatePairsWithTerminalFallbackSelectedPairReleasesHeldListener(t *testing.T) {
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	selected := selectedPair{
		dialer:   dialerCandidate,
		listener: listenerCandidate,
		rtt:      7 * time.Millisecond,
	}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selected)
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}
	releaseSelected := make(chan struct{})
	channel := newReleasedReadControlChannel(selectedFrame, releaseSelected)
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	runtime.blockWhenEmpty = true
	packetConn := &runtimeProviderPacketConn{runtime: runtime, local: listenerCandidate.Addr}
	offer := localUpgradeOffer{
		role:       upgradeRoleListen,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
	}
	peer := localUpgradeOffer{
		probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes),
	}
	probeKey, err := deriveProbeKey(testAuthContext().Exporter(), peer.probeNonce, offer.probeNonce)
	if err != nil {
		t.Fatalf("derive probe key: %v", err)
	}
	requestSends := 0
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		requestSends++
		response, err := encodeProbeDatagram(probeKey, probeMessageResponse, probeDirectionDialerToListener, decoded.ProbeID, dialerCandidate, listenerCandidate)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(dialerCandidate.Addr), nil)
		return nil
	}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:        channel,
		auth:           testAuthContext(),
		controlFrames:  newControlFrameSequencer(channel),
		testProbeRetry: func() time.Duration { return probeRetryInterval },
		cfg: upgradeConfig{
			packetConn:       packetConn,
			probeTimeout:     time.Second,
			probeConcurrency: 1,
		},
	})
	pairPlan := testListenerCandidatePairPlan(listenerCandidate, dialerCandidate)
	probeCtx, cancelProbe := context.WithTimeout(context.Background(), testCausalObservationTimeout)
	defer cancelProbe()

	done := make(chan probeMonitorOutcome, 1)
	go func() {
		race, err := attempt.probeCandidatePairsWithTerminalFallback(
			probeCtx,
			cancelProbe,
			offer,
			peer,
			pairPlan,
		)
		done <- probeMonitorOutcome{race: race, err: err}
	}()

	select {
	case <-runtime.receiveStarted:
		// The scripted response was consumed and the successful listener is
		// now parked in its receive/respond hold.
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("timed out waiting for successful listener hold")
	}
	if requestSends != 1 {
		t.Fatalf("listener request sends before hold = %d, want 1", requestSends)
	}
	if runtime.isReleased() {
		t.Fatal("successful listener released its runtime before peer control convergence")
	}
	select {
	case outcome := <-done:
		t.Fatalf("listener hold returned before selected-pair control: %#v", outcome)
	default:
	}

	close(releaseSelected)
	outcome := receiveProbeMonitorOutcome(t, done)
	if outcome.err != nil {
		t.Fatalf("probeCandidatePairsWithTerminalFallback error = %v, want nil", outcome.err)
	}
	if outcome.race.peer != nil {
		t.Fatalf("peer fallback = %#v, want nil", outcome.race.peer)
	}
	if outcome.race.kind != probeControlRaceSelectedPair {
		t.Fatalf("race kind = %v, want selected-pair observation", outcome.race.kind)
	}
	if outcome.race.probe.succeeded {
		t.Fatal("selected-pair frame fabricated probe success after local probe finished")
	}
	if outcome.race.probe != (candidatePairProbeResult{}) {
		t.Fatalf("selected-pair observation leaked probe result = %#v, want zero", outcome.race.probe)
	}
	if outcome.race.selected != selected {
		t.Fatalf("selected pair = %#v, want %#v", outcome.race.selected, selected)
	}
	if !runtime.isReleased() {
		t.Fatal("selected-pair control did not join and release the held listener runtime")
	}
	if calls := packetConn.rawDeadlineCalls.Load(); calls != 0 {
		t.Fatalf("raw packet deadline calls = %d, want 0", calls)
	}
}

func TestProbeCandidatePairsWithTerminalFallbackPeerFallbackReleasesHeldListener(t *testing.T) {
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	fallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackProbeFailed)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	releaseFallback := make(chan struct{})
	channel := newReleasedReadControlChannel(fallbackFrame, releaseFallback)
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	runtime.blockWhenEmpty = true
	packetConn := &runtimeProviderPacketConn{runtime: runtime, local: listenerCandidate.Addr}
	offer := localUpgradeOffer{
		role:       upgradeRoleListen,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
	}
	peer := localUpgradeOffer{
		probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes),
	}
	probeKey, err := deriveProbeKey(testAuthContext().Exporter(), peer.probeNonce, offer.probeNonce)
	if err != nil {
		t.Fatalf("derive probe key: %v", err)
	}
	requestSends := 0
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		requestSends++
		response, err := encodeProbeDatagram(probeKey, probeMessageResponse, probeDirectionDialerToListener, decoded.ProbeID, dialerCandidate, listenerCandidate)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(dialerCandidate.Addr), nil)
		return nil
	}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:        channel,
		auth:           testAuthContext(),
		controlFrames:  newControlFrameSequencer(channel),
		testProbeRetry: func() time.Duration { return probeRetryInterval },
		cfg: upgradeConfig{
			packetConn:       packetConn,
			probeTimeout:     time.Second,
			probeConcurrency: 1,
		},
	})
	pairPlan := testListenerCandidatePairPlan(listenerCandidate, dialerCandidate)
	probeCtx, cancelProbe := context.WithCancel(context.Background())
	defer cancelProbe()

	done := make(chan probeMonitorOutcome, 1)
	go func() {
		race, err := attempt.probeCandidatePairsWithTerminalFallback(
			probeCtx,
			cancelProbe,
			offer,
			peer,
			pairPlan,
		)
		done <- probeMonitorOutcome{race: race, err: err}
	}()

	select {
	case <-runtime.receiveStarted:
		// The scripted response was consumed and the successful listener is
		// now parked in its receive/respond hold.
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("timed out waiting for successful listener hold")
	}
	if requestSends != 1 {
		t.Fatalf("listener request sends before hold = %d, want 1", requestSends)
	}
	if runtime.isReleased() {
		t.Fatal("successful listener released its runtime before peer fallback")
	}
	close(releaseFallback)

	outcome := receiveProbeMonitorOutcome(t, done)
	if outcome.err != nil {
		t.Fatalf("probeCandidatePairsWithTerminalFallback error = %v, want nil", outcome.err)
	}
	if outcome.race.kind != probeControlRacePeerFallback {
		t.Fatalf("race kind = %v, want peer fallback", outcome.race.kind)
	}
	if outcome.race.peer == nil {
		t.Fatal("peer fallback = nil, want terminal fallback")
	}
	if outcome.race.peer.peer.Reason != UpgradeFallbackProbeFailed {
		t.Fatalf("peer fallback reason = %q, want %q", outcome.race.peer.peer.Reason, UpgradeFallbackProbeFailed)
	}
	if outcome.race.probe.fallback != UpgradeFallbackProbeFailed {
		t.Fatalf("local fallback reason = %q, want %q", outcome.race.probe.fallback, UpgradeFallbackProbeFailed)
	}
	if !runtime.isReleased() {
		t.Fatal("peer terminal fallback did not join and release the held listener runtime")
	}
	if calls := packetConn.rawDeadlineCalls.Load(); calls != 0 {
		t.Fatalf("raw packet deadline calls = %d, want 0", calls)
	}
}

func TestProbeCandidatePairsWithTerminalFallbackCallerCancellationReleasesHeldListener(t *testing.T) {
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")}
	channel := newScriptedControlChannel(nil, true)
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	runtime.blockWhenEmpty = true
	packetConn := &runtimeProviderPacketConn{runtime: runtime, local: listenerCandidate.Addr}
	offer := localUpgradeOffer{
		role:       upgradeRoleListen,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
	}
	peer := localUpgradeOffer{
		probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes),
	}
	probeKey, err := deriveProbeKey(testAuthContext().Exporter(), peer.probeNonce, offer.probeNonce)
	if err != nil {
		t.Fatalf("derive probe key: %v", err)
	}
	requestSends := 0
	runtime.onSend = func(packet []byte, _ net.Addr) error {
		decoded, ok := decodeProbeDatagram(packet)
		if !ok || decoded.MessageType != probeMessageRequest {
			return nil
		}
		requestSends++
		response, err := encodeProbeDatagram(probeKey, probeMessageResponse, probeDirectionDialerToListener, decoded.ProbeID, dialerCandidate, listenerCandidate)
		if err != nil {
			return err
		}
		runtime.enqueueAfter(time.Millisecond, response, net.UDPAddrFromAddrPort(dialerCandidate.Addr), nil)
		return nil
	}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:        channel,
		auth:           testAuthContext(),
		controlFrames:  newControlFrameSequencer(channel),
		testProbeRetry: func() time.Duration { return probeRetryInterval },
		cfg: upgradeConfig{
			packetConn:       packetConn,
			probeTimeout:     time.Second,
			probeConcurrency: 1,
		},
	})
	pairPlan := testListenerCandidatePairPlan(listenerCandidate, dialerCandidate)
	probeCtx, cancelProbe := context.WithCancel(context.Background())
	defer cancelProbe()

	done := make(chan probeMonitorOutcome, 1)
	go func() {
		race, err := attempt.probeCandidatePairsWithTerminalFallback(
			probeCtx,
			cancelProbe,
			offer,
			peer,
			pairPlan,
		)
		done <- probeMonitorOutcome{race: race, err: err}
	}()

	select {
	case <-runtime.receiveStarted:
		// The scripted response was consumed and the successful listener is
		// now parked in its receive/respond hold.
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("timed out waiting for successful listener hold")
	}
	if requestSends != 1 {
		t.Fatalf("listener request sends before hold = %d, want 1", requestSends)
	}
	if runtime.isReleased() {
		t.Fatal("successful listener released its runtime before caller cancellation")
	}
	cancelProbe()

	outcome := receiveProbeMonitorOutcome(t, done)
	if !errors.Is(outcome.err, context.Canceled) {
		t.Fatalf("probeCandidatePairsWithTerminalFallback error = %v, want context.Canceled", outcome.err)
	}
	if outcome.race.kind != probeControlRaceFailed {
		t.Fatalf("race kind = %v, want failed", outcome.race.kind)
	}
	if outcome.race.peer != nil {
		t.Fatalf("peer fallback = %#v, want nil", outcome.race.peer)
	}
	if !runtime.isReleased() {
		t.Fatal("caller cancellation did not join and release the held listener runtime")
	}
	if calls := packetConn.rawDeadlineCalls.Load(); calls != 0 {
		t.Fatalf("raw packet deadline calls = %d, want 0", calls)
	}
}

func TestProbeCandidatePairsWithTerminalFallbackHeldFailureObservesCallerCancellation(t *testing.T) {
	// A bilateral listener whose local probe fails suppresses its v1 Fallback
	// and holds for the dialer's Selected/Start/Fallback under the control
	// timeout. Outer cancellation must end that hold promptly with the exact
	// context error instead of waiting for a peer frame or the control
	// timeout; the hour-long control timeout here makes a missing arm fail
	// the bounded outcome wait rather than pass late.
	channel := newScriptedControlChannel(nil, true)
	t.Cleanup(func() { _ = channel.Close() })
	packetConn := listenPacket(t, "127.0.0.1:0")
	listenerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[::1]:10002")}
	offer := localUpgradeOffer{
		role:       upgradeRoleListen,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
		turnRetry:  true,
	}
	peer := localUpgradeOffer{
		role:       upgradeRoleDial,
		probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes),
		turnRetry:  true,
	}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		auth:          testAuthContext(),
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			packetConn:     packetConn,
			probeTimeout:   time.Second,
			controlTimeout: time.Hour,
		},
	})
	// Address-family-incompatible candidates plan zero pairs and an immediate
	// local probe_failed, which is exactly the held-failure entry.
	pairPlan := testListenerCandidatePairPlan(listenerCandidate, dialerCandidate)
	if len(pairPlan.pairs) != 0 || pairPlan.fallback != UpgradeFallbackProbeFailed {
		t.Fatalf("pair plan = %#v, want zero pairs with probe_failed", pairPlan)
	}
	probeCtx, cancelProbe := context.WithCancel(context.Background())
	defer cancelProbe()

	done := make(chan probeMonitorOutcome, 1)
	go func() {
		race, err := attempt.probeCandidatePairsWithTerminalFallback(
			probeCtx,
			cancelProbe,
			offer,
			peer,
			pairPlan,
		)
		done <- probeMonitorOutcome{race: race, err: err}
	}()

	select {
	case outcome := <-done:
		t.Fatalf("hold ended before cancellation: race=%#v err=%v", outcome.race, outcome.err)
	case <-time.After(50 * time.Millisecond):
		// The held-failure hold is in progress with no peer frame pending.
	}
	canceledAt := time.Now()
	cancelProbe()

	outcome := receiveProbeMonitorOutcome(t, done)
	if !errors.Is(outcome.err, context.Canceled) {
		t.Fatalf("probeCandidatePairsWithTerminalFallback error = %v, want context.Canceled", outcome.err)
	}
	if outcome.race.kind != probeControlRaceFailed {
		t.Fatalf("race kind = %v, want failed", outcome.race.kind)
	}
	if outcome.race.probe.fallback != UpgradeFallbackProbeFailed {
		t.Fatalf("race probe fallback = %v, want the held probe_failed", outcome.race.probe.fallback)
	}
	if outcome.race.peer != nil {
		t.Fatalf("peer fallback = %#v, want nil", outcome.race.peer)
	}
	if elapsed := time.Since(canceledAt); elapsed >= time.Second {
		t.Fatalf("hold released %s after cancellation, want well inside the control timeout", elapsed)
	}
}

func TestProbeCandidatePairsWithTerminalFallbackAdvancesSequencerAfterSelectedPairProbeError(t *testing.T) {
	selected := selectedPair{
		dialer:   Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10001")},
		listener: Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "127.0.0.1:10002")},
		rtt:      7 * time.Millisecond,
	}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selected)
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}
	peerFallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackProbeFailed)
	if err != nil {
		t.Fatalf("encode peer fallback: %v", err)
	}
	releaseRead := make(chan struct{})
	channel := newReleasedReadControlChannel(append(selectedFrame, peerFallbackFrame...), releaseRead)
	exporterErr := errors.New("probe key failed")
	exporter := &blockingErrorExporter{
		started: make(chan struct{}),
		release: make(chan struct{}),
		err:     exporterErr,
	}
	auth := testAuthContext()
	auth.exporter = exporter
	runtime := newScriptedProbeRuntime(time.Unix(1, 0))
	attempt := directUpgradeAttempt{
		channel:       channel,
		auth:          auth,
		controlFrames: newControlFrameSequencer(channel),
		cfg: upgradeConfig{
			packetConn: &runtimeProviderPacketConn{runtime: runtime, local: selected.listener.Addr},
		},
	}
	attempt = newTestDirectUpgradeAttempt(attempt)
	offer := localUpgradeOffer{
		role:       upgradeRoleListen,
		probeNonce: bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes),
	}
	peer := localUpgradeOffer{
		probeNonce: bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes),
	}
	pairPlan := candidatePairPlan{
		role: upgradeRoleListen,
		pairs: []probeCandidatePair{
			{local: selected.listener, remote: selected.dialer},
		},
	}
	probeCtx, cancelProbe := context.WithTimeout(context.Background(), time.Second)
	defer cancelProbe()

	done := make(chan probeMonitorOutcome, 1)
	go func() {
		race, err := attempt.probeCandidatePairsWithTerminalFallback(
			probeCtx,
			cancelProbe,
			offer,
			peer,
			pairPlan,
		)
		done <- probeMonitorOutcome{race: race, err: err}
	}()

	awaitBlockingExporterStarted(t, exporter)
	close(releaseRead)
	waitForReleasedControlChannelRemaining(t, channel, len(peerFallbackFrame))
	close(exporter.release)

	outcome := receiveProbeMonitorOutcome(t, done)
	if !errors.Is(outcome.err, exporterErr) {
		t.Fatalf("probeCandidatePairsWithTerminalFallback error = %v, want %v", outcome.err, exporterErr)
	}
	if outcome.race.kind != probeControlRaceFailed {
		t.Fatalf("race kind = %v, want failed", outcome.race.kind)
	}
	if outcome.race.peer != nil {
		t.Fatalf("peer fallback = %#v, want nil", outcome.race.peer)
	}
	if outcome.race.probe.fallback != UpgradeFallbackTransportFailed {
		t.Fatalf("probe fallback = %q, want %q", outcome.race.probe.fallback, UpgradeFallbackTransportFailed)
	}
	if !runtime.isReleased() {
		t.Fatal("probe runtime was not released after exporter failure")
	}

	next := awaitSequencerResult(t, attempt.controlFrames.next())
	decoded := terminalFallbackFromControlFrame(next)
	if decoded.err != nil {
		t.Fatalf("decode next terminal fallback: %v", decoded.err)
	}
	if decoded.peer.Reason != UpgradeFallbackProbeFailed {
		t.Fatalf("next fallback reason = %q, want %q", decoded.peer.Reason, UpgradeFallbackProbeFailed)
	}
}

type blockingErrorExporter struct {
	started chan struct{}
	release chan struct{}
	err     error
	once    sync.Once
}

func (e *blockingErrorExporter) Derive(string, []byte, int) ([]byte, error) {
	e.once.Do(func() {
		close(e.started)
	})
	<-e.release
	return nil, e.err
}

type probeMonitorOutcome struct {
	race probeControlRaceOutcome
	err  error
}

func awaitBlockingExporterStarted(t *testing.T, exporter *blockingErrorExporter) {
	t.Helper()

	select {
	case <-exporter.started:
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for probe key derivation to start")
	}
}

func waitForReleasedControlChannelRemaining(t *testing.T, channel *scriptedControlChannel, want int) {
	t.Helper()
	if err := validateReleasedControlChannelInspectionFixture(channel); err != nil {
		t.Fatal(err)
	}

	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		channel.mu.Lock()
		got := channel.read.Len()
		channel.mu.Unlock()
		if got == want {
			return
		}
		time.Sleep(time.Millisecond)
	}
	channel.mu.Lock()
	got := channel.read.Len()
	channel.mu.Unlock()
	t.Fatalf("control channel unread bytes = %d, want %d", got, want)
}

func validateReleasedControlChannelInspectionFixture(channel *scriptedControlChannel) error {
	if channel == nil || !channel.inspectRead || channel.read == nil || channel.delegate != nil {
		return errors.New("released-control inspection requires a scripted channel backed by its internal reader")
	}
	return nil
}

func receiveProbeMonitorOutcome(t *testing.T, done <-chan probeMonitorOutcome) probeMonitorOutcome {
	t.Helper()

	select {
	case outcome := <-done:
		return outcome
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for probe monitor outcome")
		return probeMonitorOutcome{}
	}
}
