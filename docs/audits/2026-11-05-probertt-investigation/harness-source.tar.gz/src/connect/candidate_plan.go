package connect

import (
	"net/netip"
	"slices"
	"sort"
)

type localCandidatePlan struct {
	candidates []Candidate
	fallback   UpgradeFallbackReason
}

func planLocalCandidates(candidates []gatheredCandidate, policy CandidatePolicy) localCandidatePlan {
	if len(candidates) == 0 {
		return localCandidatePlan{fallback: UpgradeFallbackNoCandidates}
	}

	filtered := applyLocalCandidatePolicy(candidates, policy)
	if len(filtered) == 0 {
		return localCandidatePlan{fallback: UpgradeFallbackPolicyExcluded}
	}
	if len(filtered) > upgradeControlMaxCandidates {
		filtered = filtered[:upgradeControlMaxCandidates]
	}
	return localCandidatePlan{candidates: filtered}
}

func applyLocalCandidatePolicy(candidates []gatheredCandidate, policy CandidatePolicy) []Candidate {
	filtered := make([]gatheredCandidate, 0, len(candidates))
	for _, candidate := range candidates {
		if candidatePolicyMatchesCandidate(candidate, policy.ExcludeLocalInterfaces, policy.ExcludeLocalPrefixes, policy.ExcludeKinds) {
			continue
		}
		filtered = append(filtered, candidate)
	}

	sort.SliceStable(filtered, func(i, j int) bool {
		iDeprioritized := candidatePolicyMatchesCandidate(filtered[i], policy.DeprioritizeLocalInterfaces, policy.DeprioritizeLocalPrefixes, policy.DeprioritizeKinds)
		jDeprioritized := candidatePolicyMatchesCandidate(filtered[j], policy.DeprioritizeLocalInterfaces, policy.DeprioritizeLocalPrefixes, policy.DeprioritizeKinds)
		if iDeprioritized != jDeprioritized {
			return !iDeprioritized
		}
		return candidateLess(filtered[i].candidate, filtered[j].candidate)
	})
	return candidatesFromGathered(filtered)
}

func candidatePolicyMatchesCandidate(candidate gatheredCandidate, interfaces []string, prefixes []netip.Prefix, kinds []CandidateKind) bool {
	if len(interfaces) > 0 {
		if candidate.localInterface == "" && candidate.candidate.Kind == CandidateKindReflexive {
			return true
		}
		for _, name := range interfaces {
			if candidate.localInterface != "" && candidate.localInterface == name {
				return true
			}
		}
	}
	if candidateKindMatches(candidate.candidate.Kind, kinds) {
		return true
	}
	return candidateAddrMatchesPrefix(candidate.candidate, prefixes)
}

func candidateLess(a, b Candidate) bool {
	if a.Kind != b.Kind {
		return candidateKindOrder(a.Kind) < candidateKindOrder(b.Kind)
	}
	if cmp := a.Addr.Addr().Compare(b.Addr.Addr()); cmp != 0 {
		return cmp < 0
	}
	return a.Addr.Port() < b.Addr.Port()
}

type candidatePairPlan struct {
	role     upgradeRole
	pairs    []probeCandidatePair
	fallback UpgradeFallbackReason
}

func planProbeCandidatePairs(local, remote []Candidate, policy CandidatePolicy, role upgradeRole) candidatePairPlan {
	pairs := candidatePairs(local, remote, policy)
	if len(pairs) > 0 {
		return candidatePairPlan{role: role, pairs: pairs}
	}
	if hasPolicyAgnosticCompatiblePair(local, remote) {
		return candidatePairPlan{role: role, fallback: UpgradeFallbackPolicyExcluded}
	}
	return candidatePairPlan{role: role, fallback: UpgradeFallbackProbeFailed}
}

func (p candidatePairPlan) allowsSelectedPair(selected selectedPair) bool {
	switch p.role {
	case upgradeRoleDial, upgradeRoleListen:
	default:
		return false
	}
	want := probeCandidatePair{
		local:  selected.local(p.role),
		remote: selected.remote(p.role),
	}
	return slices.Contains(p.pairs, want)
}

func candidatePairs(local, remote []Candidate, policy CandidatePolicy) []probeCandidatePair {
	filteredLocal := make([]Candidate, 0, len(local))
	for _, candidate := range local {
		if !directProbeCandidateSupported(candidate) {
			continue
		}
		filteredLocal = append(filteredLocal, candidate)
	}

	filteredRemote := make([]rankedProbeCandidate, 0, len(remote))
	for _, candidate := range remote {
		if !directProbeCandidateSupported(candidate) || remoteCandidateExcluded(candidate, policy) {
			continue
		}
		filteredRemote = append(filteredRemote, rankedProbeCandidate{
			candidate:     candidate,
			deprioritized: remoteCandidateDeprioritized(candidate, policy),
		})
	}

	sort.SliceStable(filteredRemote, func(i, j int) bool {
		if filteredRemote[i].deprioritized != filteredRemote[j].deprioritized {
			return !filteredRemote[i].deprioritized
		}
		return candidateLess(filteredRemote[i].candidate, filteredRemote[j].candidate)
	})

	rankedPairs := make([]rankedProbeCandidatePair, 0, len(filteredLocal)*len(filteredRemote))
	for localRank, localCandidate := range filteredLocal {
		for remoteRank, remoteCandidate := range filteredRemote {
			pair := probeCandidatePair{
				local:  localCandidate,
				remote: remoteCandidate.candidate,
			}
			if !probeCandidatePairAddressFamilyCompatible(pair) {
				continue
			}
			rankedPairs = append(rankedPairs, rankedProbeCandidatePair{
				pair:                pair,
				localRank:           localRank,
				remoteRank:          remoteRank,
				remoteDeprioritized: remoteCandidate.deprioritized,
				kindOrder:           probeCandidatePairKindOrder(pair),
				sharesLocalSubnet:   sameLocalSubnet(pair),
			})
		}
	}

	sort.SliceStable(rankedPairs, func(i, j int) bool {
		return rankedProbeCandidatePairLess(rankedPairs[i], rankedPairs[j])
	})
	pairs := make([]probeCandidatePair, 0, len(rankedPairs))
	for _, pair := range rankedPairs {
		pairs = append(pairs, pair.pair)
	}
	return pairs
}

func probeCandidatePairAddressFamilyCompatible(pair probeCandidatePair) bool {
	local := pair.local.Addr.Addr().Unmap()
	remote := pair.remote.Addr.Addr().Unmap()
	return local.Is4() && remote.Is4() || local.Is6() && remote.Is6()
}

func directProbeCandidateSupported(candidate Candidate) bool {
	return classifyCandidateKind(candidate.Kind).direct && probeCandidateSupported(candidate)
}

// hasPolicyAgnosticCompatiblePair is called only after policy-filtered pairing
// produced no pairs. A true result means caller policy, not built-in validity or
// address-family filtering, removed every otherwise compatible candidate pair.
func hasPolicyAgnosticCompatiblePair(local, remote []Candidate) bool {
	for _, localCandidate := range local {
		if !directProbeCandidateSupported(localCandidate) {
			continue
		}
		for _, remoteCandidate := range remote {
			if !directProbeCandidateSupported(remoteCandidate) {
				continue
			}
			if probeCandidatePairAddressFamilyCompatible(probeCandidatePair{
				local:  localCandidate,
				remote: remoteCandidate,
			}) {
				return true
			}
		}
	}
	return false
}

func remoteCandidateExcluded(candidate Candidate, policy CandidatePolicy) bool {
	return candidateKindMatches(candidate.Kind, policy.ExcludeKinds) ||
		candidateAddrMatchesPrefix(candidate, policy.ExcludeRemotePrefixes)
}

func remoteCandidateDeprioritized(candidate Candidate, policy CandidatePolicy) bool {
	return candidateKindMatches(candidate.Kind, policy.DeprioritizeKinds) ||
		candidateAddrMatchesPrefix(candidate, policy.DeprioritizeRemotePrefixes)
}

func candidateKindMatches(kind CandidateKind, kinds []CandidateKind) bool {
	return slices.Contains(kinds, kind)
}

func candidateAddrMatchesPrefix(candidate Candidate, prefixes []netip.Prefix) bool {
	addr := unscopedAddr(candidate.Addr.Addr())
	for _, prefix := range prefixes {
		if prefix.Contains(addr) {
			return true
		}
	}
	return false
}

func rankedProbeCandidatePairLess(a, b rankedProbeCandidatePair) bool {
	if a.remoteDeprioritized != b.remoteDeprioritized {
		return !a.remoteDeprioritized
	}
	if a.kindOrder != b.kindOrder {
		return a.kindOrder < b.kindOrder
	}
	if a.sharesLocalSubnet != b.sharesLocalSubnet {
		return a.sharesLocalSubnet
	}
	if a.localRank != b.localRank {
		return a.localRank < b.localRank
	}
	if a.remoteRank != b.remoteRank {
		return a.remoteRank < b.remoteRank
	}
	return false
}
