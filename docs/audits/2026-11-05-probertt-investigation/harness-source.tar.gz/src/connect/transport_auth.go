package connect

type legacyTransportAuth struct {
	auth AuthContext
}

func (a legacyTransportAuth) SessionBinding() ([]byte, error) {
	return a.auth.SessionBinding(), nil
}

func (a legacyTransportAuth) Exporter() KeyExporter {
	exporter := a.auth.Exporter()
	if exporter == nil {
		return transportAuthErrorExporter{err: ErrNilKeyExporter}
	}
	return exporter
}

func transportAuthFor(auth AuthContext) TransportAuth {
	return legacyTransportAuth{auth: auth}
}

type transportAuthErrorExporter struct {
	err error
}

func (e transportAuthErrorExporter) Derive(string, []byte, int) ([]byte, error) {
	return nil, e.err
}
