package connect

import (
	"context"
	"errors"
	"net"
	"net/netip"
	"sync/atomic"
	"time"

	"github.com/GridSwarm/wiremux/internal/proberuntime"
)

// discardTestPacketConn is the inert packet-connection substrate used by
// protocol and ownership tests that never exercise probe scheduling.
type discardTestPacketConn struct {
	local netip.AddrPort
}

func (discardTestPacketConn) ReadFrom([]byte) (int, net.Addr, error) {
	return 0, nil, testPacketTimeoutError{}
}

func (discardTestPacketConn) WriteTo(packet []byte, _ net.Addr) (int, error) {
	return len(packet), nil
}

func (discardTestPacketConn) Close() error { return nil }

func (c discardTestPacketConn) LocalAddr() net.Addr {
	return net.UDPAddrFromAddrPort(c.local)
}

func (discardTestPacketConn) SetDeadline(time.Time) error      { return nil }
func (discardTestPacketConn) SetReadDeadline(time.Time) error  { return nil }
func (discardTestPacketConn) SetWriteDeadline(time.Time) error { return nil }

type testPacketTimeoutError struct{}

func (testPacketTimeoutError) Error() string { return "test packet read timeout" }
func (testPacketTimeoutError) Timeout() bool { return true }

type runtimeProviderPacketConn struct {
	runtime                proberuntime.Runtime
	onNewProbeRuntime      func(context.Context)
	local                  netip.AddrPort
	onRawAccess            func()
	rawDeadlineCalls       atomic.Int32
	rawReadCalls           atomic.Int32
	drainComplete          atomic.Bool
	rawAccessBeforeRelease atomic.Bool
}

func (c *runtimeProviderPacketConn) NewProbeRuntime(ctx context.Context) (proberuntime.Runtime, error) {
	if c.onNewProbeRuntime != nil {
		c.onNewProbeRuntime(ctx)
	}
	return c.runtime, nil
}

func (c *runtimeProviderPacketConn) ReadFrom([]byte) (int, net.Addr, error) {
	if c.onRawAccess != nil {
		c.onRawAccess()
	}
	c.rawReadCalls.Add(1)
	return 0, nil, testPacketTimeoutError{}
}

func (*runtimeProviderPacketConn) WriteTo([]byte, net.Addr) (int, error) {
	return 0, errors.New("unexpected raw packet write")
}

func (*runtimeProviderPacketConn) Close() error { return nil }

func (c *runtimeProviderPacketConn) LocalAddr() net.Addr {
	return net.UDPAddrFromAddrPort(c.local)
}

func (c *runtimeProviderPacketConn) SetDeadline(time.Time) error {
	c.rawDeadlineCalls.Add(1)
	return nil
}

func (c *runtimeProviderPacketConn) SetReadDeadline(deadline time.Time) error {
	if c.onRawAccess != nil {
		c.onRawAccess()
	}
	c.rawDeadlineCalls.Add(1)
	if deadline.IsZero() && c.rawReadCalls.Load() != 0 {
		c.drainComplete.Store(true)
	}
	return nil
}

func (*runtimeProviderPacketConn) SetWriteDeadline(time.Time) error { return nil }
