package connect

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net"
	"net/netip"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// fakeRelayComposite is a conforming official-marked relay composite over a
// real loopback UDP socket: retry probes and transport bytes flow for real
// between two fakes. LocalAddr returns a fresh *net.UDPAddr per call exactly
// like the official composite, and Close is idempotent, joins nothing beyond
// the socket, and returns promptly.
type fakeRelayComposite struct {
	conn net.PacketConn

	// failPrepare, when non-nil, makes every PreparePeer call fail with it.
	failPrepare error

	mu             sync.Mutex
	prepared       netip.AddrPort
	preparedSet    bool
	prepareCalls   int
	closeCalls     int
	localAddrCalls int
	closeOnce      sync.Once
	closeErr       error
}

func newFakeRelayComposite(t *testing.T) *fakeRelayComposite {
	t.Helper()
	conn := listenPacketNetwork(t, "udp4", "127.0.0.1:0")
	return &fakeRelayComposite{conn: conn}
}

func (c *fakeRelayComposite) WiremuxRelayProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3()
}

func (c *fakeRelayComposite) relayedAddr() netip.AddrPort {
	addr, err := addrPortFromNetAddr(c.conn.LocalAddr())
	if err != nil {
		panic(err)
	}
	return addr
}

func (c *fakeRelayComposite) LocalAddr() net.Addr {
	c.mu.Lock()
	c.localAddrCalls++
	c.mu.Unlock()
	return net.UDPAddrFromAddrPort(c.relayedAddr())
}

func (c *fakeRelayComposite) PreparePeer(_ context.Context, peer netip.AddrPort) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.prepareCalls++
	if c.failPrepare != nil {
		return c.failPrepare
	}
	if c.preparedSet && c.prepared != peer {
		return errors.New("fake composite: different peer already prepared")
	}
	c.prepared = peer
	c.preparedSet = true
	return nil
}

func (c *fakeRelayComposite) ReadFrom(p []byte) (int, net.Addr, error) { return c.conn.ReadFrom(p) }

func (c *fakeRelayComposite) WriteTo(p []byte, a net.Addr) (int, error) { return c.conn.WriteTo(p, a) }

func (c *fakeRelayComposite) SetDeadline(t time.Time) error { return c.conn.SetDeadline(t) }

func (c *fakeRelayComposite) SetReadDeadline(t time.Time) error {
	return c.conn.SetReadDeadline(t)
}

func (c *fakeRelayComposite) SetWriteDeadline(t time.Time) error {
	return c.conn.SetWriteDeadline(t)
}

func (c *fakeRelayComposite) Close() error {
	c.mu.Lock()
	c.closeCalls++
	c.mu.Unlock()
	c.closeOnce.Do(func() { c.closeErr = c.conn.Close() })
	return c.closeErr
}

func (c *fakeRelayComposite) closeCount() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.closeCalls
}

func (c *fakeRelayComposite) preparedPeer() (netip.AddrPort, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.prepared, c.preparedSet
}

// runTurnRetryHandoffPeer runs one peer configured for TURN retry with a
// working stream-handoff transport wrapped in the eligible shape.
func runTurnRetryHandoffPeer(
	t *testing.T,
	peer *turnRetryTestPeer,
	transport Transport,
) <-chan turnRetryTestOutcome {
	t.Helper()
	return runTurnRetryHandoffPeerContext(t, context.Background(), peer, transport)
}

func runTurnRetryHandoffPeerContext(
	t *testing.T,
	ctx context.Context,
	peer *turnRetryTestPeer,
	transport Transport,
) <-chan turnRetryTestOutcome {
	t.Helper()

	gatherer := testGathererWithInterfaces([]gatherInterface{{
		name:  "test0",
		flags: net.FlagUp,
		addrs: []net.Addr{testNetAddr("192.0.2.10/24")},
	}})

	opts := []UpgradeOption{
		WithTransport(transport),
		WithUpgradePacketConn(peer.conn),
		WithProbeTimeout(150 * time.Millisecond),
		WithUpgradeControlTimeout(2 * time.Second),
		WithTURNAllocator(peer.allocator),
		WithTURNRetryTimeout(2 * time.Second),
	}
	opts = append(opts, peer.extraOpts...)
	cfg := testUpgradeConfig(t, opts...)
	cfg.testGatherer = gatherer
	cfg.testTurnRetryProbeRunner = peer.probeRunner

	done := make(chan turnRetryTestOutcome, 1)
	go func() {
		result, err := newDirectUpgradeAttempt(peer.negotiate, cfg).run(ctx)
		done <- turnRetryTestOutcome{result: result, err: err}
	}()
	return done
}

// eligibleHandoffTransport wraps directHandoffTransport in the TURN-eligible
// shape by delegation (never embedding).
type eligibleHandoffTransport struct{ inner *directHandoffTransport }

func (t eligibleHandoffTransport) Name() string { return t.inner.Name() }

func (t eligibleHandoffTransport) NewSession(ctx context.Context, auth TransportAuth) (Session, error) {
	return t.inner.NewSession(ctx, auth)
}

func (t eligibleHandoffTransport) WiremuxRelayTransportProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3TransportForTest(t)
}

func TestTurnRetryBilateralDirectFailureUpgradesOverComposites(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
		return dialerComposite, nil
	}
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
		return listenerComposite, nil
	}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")

	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone

	for _, peer := range []struct {
		name    string
		outcome turnRetryTestOutcome
		local   *fakeRelayComposite
		remote  *fakeRelayComposite
	}{
		{name: "dialer", outcome: dialerOutcome, local: dialerComposite, remote: listenerComposite},
		{name: "listener", outcome: listenerOutcome, local: listenerComposite, remote: dialerComposite},
	} {
		if peer.outcome.err != nil {
			t.Fatalf("%s Upgrade error = %v, want nil", peer.name, peer.outcome.err)
		}
		result := peer.outcome.result
		if result.Path != UpgradePathDirect {
			t.Fatalf("%s path = %q, want %q", peer.name, result.Path, UpgradePathDirect)
		}
		if result.Stream == nil {
			t.Fatalf("%s stream = nil, want TURN carrier stream", peer.name)
		}
		if result.SelectedPair == nil {
			t.Fatalf("%s selected pair = nil, want relay/relay pair", peer.name)
		}
		if result.SelectedPair.Local.Kind != CandidateKindRelay || result.SelectedPair.Remote.Kind != CandidateKindRelay {
			t.Fatalf("%s selected pair kinds = %s/%s, want relay/relay",
				peer.name, result.SelectedPair.Local.Kind, result.SelectedPair.Remote.Kind)
		}
		if result.SelectedPair.Local.Addr != peer.local.relayedAddr() {
			t.Fatalf("%s local relay candidate = %v, want %v", peer.name, result.SelectedPair.Local.Addr, peer.local.relayedAddr())
		}
		if result.SelectedPair.Remote.Addr != peer.remote.relayedAddr() {
			t.Fatalf("%s remote relay candidate = %v, want %v", peer.name, result.SelectedPair.Remote.Addr, peer.remote.relayedAddr())
		}
		if result.ProbeRTT <= 0 {
			t.Fatalf("%s probe RTT = %v, want positive retry-probe RTT", peer.name, result.ProbeRTT)
		}
		if result.FallbackReason != UpgradeFallbackNone {
			t.Fatalf("%s fallback reason = %q, want none", peer.name, result.FallbackReason)
		}
		prepared, ok := peer.local.preparedPeer()
		if !ok || prepared != peer.remote.relayedAddr() {
			t.Fatalf("%s prepared peer = %v (%v), want %v", peer.name, prepared, ok, peer.remote.relayedAddr())
		}
		if calls := peer.name; calls == "" {
			t.Fatal("unreachable")
		}
	}
	if calls := dialer.allocator.callCount(); calls != 1 {
		t.Fatalf("dialer allocator calls = %d, want exactly 1", calls)
	}
	if calls := listener.allocator.callCount(); calls != 1 {
		t.Fatalf("listener allocator calls = %d, want exactly 1", calls)
	}
	if count := dialer.relay.turnRetryStartCount(); count != 1 {
		t.Fatalf("retry Start frames = %d, want exactly one retry entry", count)
	}
	// The immutable canonical relayed address is consumed exactly once per
	// composite; policy and the Retry Offer never re-read the mutable value.
	for _, composite := range []*fakeRelayComposite{dialerComposite, listenerComposite} {
		composite.mu.Lock()
		calls := composite.localAddrCalls
		composite.mu.Unlock()
		if calls != 1 {
			t.Fatalf("composite LocalAddr calls = %d, want exactly 1", calls)
		}
	}

	// The unselected direct sockets stay caller-owned and open.
	for _, peer := range []*turnRetryTestPeer{dialer, listener} {
		if err := peer.conn.SetReadDeadline(time.Time{}); err != nil {
			t.Fatalf("%s direct socket closed after TURN success: %v", peer.name, err)
		}
	}

	// The upgraded stream carries application bytes end to end.
	appBytes := []byte("bytes over the TURN carrier")
	writeDone := make(chan error, 1)
	go func() {
		_, err := dialerOutcome.result.Stream.Write(appBytes)
		writeDone <- err
	}()
	got := make([]byte, len(appBytes))
	if _, err := io.ReadFull(listenerOutcome.result.Stream, got); err != nil {
		t.Fatalf("read TURN carrier bytes: %v", err)
	}
	if !bytes.Equal(got, appBytes) {
		t.Fatalf("TURN carrier bytes = %q, want %q", got, appBytes)
	}
	if err := <-writeDone; err != nil {
		t.Fatalf("write TURN carrier bytes: %v", err)
	}

	// Closing the returned streams disposes the composites through the
	// transport's exact-packet ownership; no second close authority appears.
	_ = dialerOutcome.result.Stream.Close()
	_ = listenerOutcome.result.Stream.Close()
	if dialerComposite.closeCount() == 0 {
		t.Fatal("dialer composite never closed after stream Close")
	}
	if listenerComposite.closeCount() == 0 {
		t.Fatal("listener composite never closed after stream Close")
	}
}

// unmarkedRelayConn is a non-nil allocator result that does not bear the
// official relay-profile marker.
type unmarkedRelayConn struct {
	net.PacketConn
	mu         sync.Mutex
	closeCalls int
}

func (c *unmarkedRelayConn) PreparePeer(context.Context, netip.AddrPort) error { return nil }

func (c *unmarkedRelayConn) Close() error {
	c.mu.Lock()
	c.closeCalls++
	c.mu.Unlock()
	return c.PacketConn.Close()
}

func (c *unmarkedRelayConn) closeCount() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.closeCalls
}

func TestTurnRetryAllocationFailureSynchronizesOriginalProbeFailed(t *testing.T) {
	cases := []struct {
		name        string
		failingRole string
	}{
		{name: "dialer allocation error", failingRole: "dialer"},
		{name: "listener allocation error", failingRole: "listener"},
		{name: "dialer nil result without error", failingRole: "dialer-nil"},
		{name: "dialer non-nil result with error", failingRole: "dialer-conn-err"},
		{name: "listener unmarked result", failingRole: "listener-unmarked"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dialer, listener := newTurnRetryFailingDirectPeers(t)

			healthyComposite := newFakeRelayComposite(t)
			var failedConn interface{ closeCount() int }
			configure := func(peer *turnRetryTestPeer, healthy bool) {
				if healthy {
					peer.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
						return healthyComposite, nil
					}
					return
				}
				switch tc.failingRole {
				case "dialer", "listener":
					peer.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
						return nil, errors.New("allocation refused")
					}
				case "dialer-nil":
					peer.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
						//nolint:nilnil // the dialer-nil row exists to return a nil RelayPacketConn with a nil error.
						return nil, nil
					}
				case "dialer-conn-err":
					partial := newFakeRelayComposite(t)
					failedConn = partial
					peer.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
						return partial, errors.New("allocation partially failed")
					}
				case "listener-unmarked":
					unmarked := &unmarkedRelayConn{PacketConn: listenPacketNetwork(t, "udp4", "127.0.0.1:0")}
					failedConn = unmarked
					peer.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
						return unmarked, nil
					}
				}
			}
			dialerFails := tc.failingRole == "dialer" || tc.failingRole == "dialer-nil" || tc.failingRole == "dialer-conn-err"
			configure(dialer, !dialerFails)
			configure(listener, dialerFails)

			dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
			dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
			listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

			dialerOutcome := <-dialerDone
			listenerOutcome := <-listenerDone
			assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackProbeFailed)
			assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackProbeFailed)

			if calls := dialer.allocator.callCount(); calls != 1 {
				t.Fatalf("dialer allocator calls = %d, want 1", calls)
			}
			if calls := listener.allocator.callCount(); calls != 1 {
				t.Fatalf("listener allocator calls = %d, want 1", calls)
			}
			if healthyComposite.closeCount() == 0 {
				t.Fatal("healthy role's composite was not closed on synchronized fallback")
			}
			if failedConn != nil && failedConn.closeCount() != 1 {
				t.Fatalf("failing role's non-nil result close calls = %d, want exactly 1", failedConn.closeCount())
			}
		})
	}
}

func TestTurnRetryPrefixExclusionSynchronizesPolicyExcluded(t *testing.T) {
	loopback := netip.MustParsePrefix("127.0.0.0/8")
	cases := []struct {
		name         string
		dialerPolicy CandidatePolicy
		listenPolicy CandidatePolicy
		// echoRole names the peer expected to be solely preempted and echo
		// policy_excluded (retry wire code 2) rather than reach it locally.
		echoRole string
	}{
		{
			name:         "dialer local prefix exclusion after allocate",
			dialerPolicy: CandidatePolicy{ExcludeLocalPrefixes: []netip.Prefix{loopback}},
			echoRole:     "listener",
		},
		{
			name:         "listener local prefix exclusion after allocate",
			listenPolicy: CandidatePolicy{ExcludeLocalPrefixes: []netip.Prefix{loopback}},
			echoRole:     "dialer",
		},
		{
			name:         "listener remote prefix exclusion at dialer offer",
			listenPolicy: CandidatePolicy{ExcludeRemotePrefixes: []netip.Prefix{loopback}},
			echoRole:     "dialer",
		},
		{
			name:         "dialer remote prefix exclusion at listener offer",
			dialerPolicy: CandidatePolicy{ExcludeRemotePrefixes: []netip.Prefix{loopback}},
			echoRole:     "listener",
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dialer, listener := newTurnRetryFailingDirectPeers(t)
			dialerComposite := newFakeRelayComposite(t)
			listenerComposite := newFakeRelayComposite(t)
			dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
			listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }
			if len(tc.dialerPolicy.ExcludeLocalPrefixes)+len(tc.dialerPolicy.ExcludeRemotePrefixes) > 0 {
				dialer.extraOpts = []UpgradeOption{WithCandidatePolicy(tc.dialerPolicy)}
			}
			if len(tc.listenPolicy.ExcludeLocalPrefixes)+len(tc.listenPolicy.ExcludeRemotePrefixes) > 0 {
				listener.extraOpts = []UpgradeOption{WithCandidatePolicy(tc.listenPolicy)}
			}

			dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
			dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
			listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

			dialerOutcome := <-dialerDone
			listenerOutcome := <-listenerDone
			assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackPolicyExcluded)
			assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackPolicyExcluded)

			echo := dialer
			if tc.echoRole == "listener" {
				echo = listener
			}
			reasons := echo.relay.turnRetryFallbackReasons()
			if len(reasons) != 1 || reasons[0] != UpgradeFallbackPolicyExcluded {
				t.Fatalf("%s echoed retry fallback reasons = %v, want exactly [policy_excluded]", tc.echoRole, reasons)
			}
		})
	}
}

// mutableAddrRelayComposite returns the same *net.UDPAddr from every
// LocalAddr call and mutates it as soon as PreparePeer runs, proving that
// policy and the emitted Retry Offer consumed the original immutable
// canonical value.
type mutableAddrRelayComposite struct {
	*fakeRelayComposite
	sharedAddr *net.UDPAddr
}

func (c *mutableAddrRelayComposite) LocalAddr() net.Addr {
	c.mu.Lock()
	c.localAddrCalls++
	c.mu.Unlock()
	return c.sharedAddr
}

func (c *mutableAddrRelayComposite) PreparePeer(ctx context.Context, peer netip.AddrPort) error {
	c.sharedAddr.IP = net.IPv4(203, 0, 113, 99)
	c.sharedAddr.Port = 9
	return c.fakeRelayComposite.PreparePeer(ctx, peer)
}

func TestTurnRetryLocalAddrMutationCannotChangePolicyOrOffer(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerInner := newFakeRelayComposite(t)
	original := dialerInner.relayedAddr()
	dialerComposite := &mutableAddrRelayComposite{
		fakeRelayComposite: dialerInner,
		sharedAddr:         net.UDPAddrFromAddrPort(original),
	}
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }
	// The mutated value would be policy-excluded; the original is not. If the
	// dialer consumed the mutated address, policy would reject it.
	dialer.extraOpts = []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
		ExcludeLocalPrefixes: []netip.Prefix{netip.MustParsePrefix("203.0.113.0/24")},
	})}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	if dialerOutcome.err != nil || listenerOutcome.err != nil {
		t.Fatalf("upgrade errors = %v / %v, want nil", dialerOutcome.err, listenerOutcome.err)
	}
	if dialerOutcome.result.Path != UpgradePathDirect {
		t.Fatalf("dialer path = %q, want direct TURN carrier", dialerOutcome.result.Path)
	}
	// The listener observed the dialer's Retry Offer; its remote candidate
	// must be the original canonical relayed address, not the mutated value.
	if got := listenerOutcome.result.SelectedPair.Remote.Addr; got != original {
		t.Fatalf("listener-observed dialer relay candidate = %v, want original %v", got, original)
	}
	if got := dialerOutcome.result.SelectedPair.Local.Addr; got != original {
		t.Fatalf("dialer local relay candidate = %v, want original %v", got, original)
	}
}

// listenerProbeRequestDroppingComposite drops every outbound
// listener-originated retry-probe request while the listener's responses and
// all other traffic flow, reproducing the #1218 contention signature: the
// listener keeps answering the dialer but its own probe round trip never
// completes, so it holds no success when Selected arrives.
type listenerProbeRequestDroppingComposite struct {
	*fakeRelayComposite
	droppedRequests atomic.Int32
}

func (c *listenerProbeRequestDroppingComposite) WriteTo(p []byte, a net.Addr) (int, error) {
	if decoded, ok := decodeTurnRetryProbeDatagram(p); ok &&
		decoded.MessageType == probeMessageRequest &&
		decoded.Direction == probeDirectionListenerToDialer {
		c.droppedRequests.Add(1)
		return len(p), nil
	}
	return c.fakeRelayComposite.WriteTo(p, a)
}

// TestTurnRetryListenerWithoutOwnProbeSuccessUpgradesOnSelected is the #1218
// regression: a listener whose own probe requests are all lost must adopt the
// dialer's authenticated Selected frame as bilateral pair evidence and
// upgrade, instead of probing until the full retry budget while the dialer's
// Ready wait expires. The 5s retry budget exceeds the fixture's 2s control
// timeout, so a regression strands the listener past the dialer's exit and
// both sides fail out of the direct path.
func TestTurnRetryListenerWithoutOwnProbeSuccessUpgradesOnSelected(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := &listenerProbeRequestDroppingComposite{fakeRelayComposite: newFakeRelayComposite(t)}
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
		return dialerComposite, nil
	}
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
		return listenerComposite, nil
	}
	dialer.extraOpts = []UpgradeOption{WithTURNRetryTimeout(5 * time.Second)}
	listener.extraOpts = []UpgradeOption{WithTURNRetryTimeout(5 * time.Second)}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone

	if n := listenerComposite.droppedRequests.Load(); n == 0 {
		t.Fatal("fixture dropped no listener probe requests; the lost-request condition was never exercised")
	}
	for _, peer := range []struct {
		name    string
		outcome turnRetryTestOutcome
		local   interface{ relayedAddr() netip.AddrPort }
		remote  interface{ relayedAddr() netip.AddrPort }
	}{
		{name: "dialer", outcome: dialerOutcome, local: dialerComposite, remote: listenerComposite},
		{name: "listener", outcome: listenerOutcome, local: listenerComposite, remote: dialerComposite},
	} {
		if peer.outcome.err != nil {
			t.Fatalf("%s Upgrade error = %v, want nil", peer.name, peer.outcome.err)
		}
		result := peer.outcome.result
		if result.Path != UpgradePathDirect {
			t.Fatalf("%s path = %q, want %q", peer.name, result.Path, UpgradePathDirect)
		}
		if result.FallbackReason != UpgradeFallbackNone {
			t.Fatalf("%s fallback reason = %q, want none", peer.name, result.FallbackReason)
		}
		if result.SelectedPair == nil {
			t.Fatalf("%s selected pair = nil, want relay/relay", peer.name)
		}
		if result.SelectedPair.Local.Addr != peer.local.relayedAddr() || result.SelectedPair.Remote.Addr != peer.remote.relayedAddr() {
			t.Fatalf("%s selected pair = %v -> %v, want %v -> %v", peer.name,
				result.SelectedPair.Local.Addr, result.SelectedPair.Remote.Addr,
				peer.local.relayedAddr(), peer.remote.relayedAddr())
		}
		if result.ProbeRTT <= 0 {
			t.Fatalf("%s probe RTT = %v, want positive RTT adopted from the Selected frame", peer.name, result.ProbeRTT)
		}
	}

	_ = dialerOutcome.result.Stream.Close()
	_ = listenerOutcome.result.Stream.Close()
}
