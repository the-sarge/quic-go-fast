package connect

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// optionStubRelayAllocator is a non-nil RelayPacketAllocator for option
// validation; allocation must never run during config validation.
type optionStubRelayAllocator struct{}

func (optionStubRelayAllocator) Allocate(context.Context) (RelayPacketConn, error) {
	return nil, errors.New("connect test: allocator must not run during option validation")
}

// turnEligibleTransport mirrors the built-in QUIC transport's eligibility
// shape: value-receiver methods and a value-receiver profile method sealing
// its exact non-pointer concrete type through the relayprofile test seam (the
// production mint seals only the built-in transport's identity).
type turnEligibleTransport struct{}

func (turnEligibleTransport) Name() string { return "turn-eligible" }

func (turnEligibleTransport) NewSession(context.Context, TransportAuth) (Session, error) {
	return nil, errors.New("connect test: session must not start during option validation")
}

func (t turnEligibleTransport) WiremuxRelayTransportProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3TransportForTest(t)
}

// turnEmbeddingWrapperTransport reaches the profile method only by promotion
// and must reject before that method is invoked.
type turnEmbeddingWrapperTransport struct {
	turnEligibleTransport
}

// turnForeignTokenTransport declares its own profile method but returns a
// token sealed (through the test seam) to a different concrete type, so its
// dynamic type never matches the sealed transport type.
type turnForeignTokenTransport struct{}

func (turnForeignTokenTransport) Name() string { return "turn-foreign-token" }

func (turnForeignTokenTransport) NewSession(context.Context, TransportAuth) (Session, error) {
	return nil, errors.New("connect test: session must not start during option validation")
}

func (turnForeignTokenTransport) WiremuxRelayTransportProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3TransportForTest(turnEligibleTransport{})
}

func TestValidateUpgradeOptionsTURNTransportEligibility(t *testing.T) {
	t.Parallel()

	allocator := optionStubRelayAllocator{}

	cases := []struct {
		name string
		opts []UpgradeOption
		want error
	}{
		{
			name: "nil allocator rejects",
			opts: []UpgradeOption{WithTURNAllocator(nil)},
			want: ErrNilTURNAllocator,
		},
		{
			name: "allocator without transport rejects before any I/O",
			opts: []UpgradeOption{WithTURNAllocator(allocator)},
			want: ErrTURNTransportUnsupported,
		},
		{
			name: "allocator with custom transport rejects",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTransport(&fakeTransport{name: "custom"}),
			},
			want: ErrTURNTransportUnsupported,
		},
		{
			name: "allocator with exact eligible value transport validates",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTransport(turnEligibleTransport{}),
			},
			want: nil,
		},
		{
			name: "allocator with exact eligible pointer transport validates",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTransport(&turnEligibleTransport{}),
			},
			want: nil,
		},
		{
			name: "allocator with typed-nil eligible pointer rejects",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTransport((*turnEligibleTransport)(nil)),
			},
			want: ErrTURNTransportUnsupported,
		},
		{
			name: "allocator with embedding wrapper transport rejects",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTransport(turnEmbeddingWrapperTransport{}),
			},
			want: ErrTURNTransportUnsupported,
		},
		{
			name: "allocator with foreign sealed-token transport rejects",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTransport(turnForeignTokenTransport{}),
			},
			want: ErrTURNTransportUnsupported,
		},
		{
			name: "repeated allocator options use the final option",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTURNAllocator(nil),
				WithTransport(turnEligibleTransport{}),
			},
			want: ErrNilTURNAllocator,
		},
		{
			name: "zero retry timeout rejects",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTransport(turnEligibleTransport{}),
				WithTURNRetryTimeout(0),
			},
			want: ErrInvalidTURNRetryTimeout,
		},
		{
			name: "negative retry timeout rejects",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTransport(turnEligibleTransport{}),
				WithTURNRetryTimeout(-time.Second),
			},
			want: ErrInvalidTURNRetryTimeout,
		},
		{
			name: "positive retry timeout validates",
			opts: []UpgradeOption{
				WithTURNAllocator(allocator),
				WithTransport(turnEligibleTransport{}),
				WithTURNRetryTimeout(250 * time.Millisecond),
			},
			want: nil,
		},
		{
			name: "retry timeout without allocator validates",
			opts: []UpgradeOption{WithTURNRetryTimeout(time.Second)},
			want: nil,
		},
		{
			name: "eligible transport without allocator validates",
			opts: []UpgradeOption{WithTransport(turnEligibleTransport{})},
			want: nil,
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			err := ValidateUpgradeOptions(tc.opts...)
			if tc.want == nil {
				if err != nil {
					t.Fatalf("ValidateUpgradeOptions error = %v, want nil", err)
				}
				return
			}
			if !errors.Is(err, tc.want) {
				t.Fatalf("ValidateUpgradeOptions error = %v, want %v", err, tc.want)
			}
		})
	}
}

func TestNewUpgradeConfigTURNRetryTimeoutDefault(t *testing.T) {
	t.Parallel()

	cfg, err := newUpgradeConfig([]UpgradeOption{
		WithTURNAllocator(optionStubRelayAllocator{}),
		WithTransport(turnEligibleTransport{}),
	})
	if err != nil {
		t.Fatalf("newUpgradeConfig error = %v, want nil", err)
	}
	if cfg.turnRetryTimeout != defaultTURNRetryTimeout {
		t.Fatalf("turnRetryTimeout = %v, want default %v", cfg.turnRetryTimeout, defaultTURNRetryTimeout)
	}
	if defaultTURNRetryTimeout != 5*time.Second {
		t.Fatalf("defaultTURNRetryTimeout = %v, want 5s", defaultTURNRetryTimeout)
	}

	cfg, err = newUpgradeConfig([]UpgradeOption{
		WithTURNAllocator(optionStubRelayAllocator{}),
		WithTransport(turnEligibleTransport{}),
		WithTURNRetryTimeout(750 * time.Millisecond),
	})
	if err != nil {
		t.Fatalf("newUpgradeConfig error = %v, want nil", err)
	}
	if cfg.turnRetryTimeout != 750*time.Millisecond {
		t.Fatalf("turnRetryTimeout = %v, want configured 750ms", cfg.turnRetryTimeout)
	}
}
