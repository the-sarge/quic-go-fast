package connect

import (
	"context"
	"errors"
	"io"
	"sync"
	"time"
)

// controlFrameSequencer serializes upgrade-control-frame reads from the
// relay channel. Exactly three usage patterns are sanctioned in production:
//
//  1. Direct sequential recv.
//  2. Goroutine-wrapped recv, where the owning exchange loop retains the
//     result through a buffered handoff channel and drains or handles it
//     before returning: the duplex exchange loops
//     (exchangeFirstPhaseControlFrame, upgrade.go; exchangeWithClassifier,
//     upgrade_terminal_fallback.go) and the commit-await goroutines
//     (upgrade_protocol_engine_listener.go).
//  3. next, only for the three documented frame-vs-work races (see next's
//     doc comment).
type controlFrameSequencer struct {
	strictToken *strictAttemptToken
	read        func() controlFrameReadResult

	mu  sync.Mutex
	out chan controlFrameReadResult
	// pushback is a LIFO stack; callers preserving wire order must unread in
	// reverse order.
	pushback       []controlFrameReadResult
	readInProgress bool
}

func newControlFrameSequencer(channel io.Reader, strict ...*strictAttemptToken) *controlFrameSequencer {
	s := newControlFrameSequencerWithRead(func() controlFrameReadResult {
		payload, err := readUpgradeControlFrame(channel)
		if len(strict) != 0 && strict[0] != nil && errors.Is(err, ErrUpgradeControlFramingFailed) {
			err = &strictAttemptError{strict[0], UpgradeErrorProtocol, err}
		}
		return controlFrameReadResult{payload: payload, err: err}
	})
	if len(strict) != 0 {
		s.strictToken = strict[0]
	}
	return s
}

func newControlFrameSequencerWithRead(read func() controlFrameReadResult) *controlFrameSequencer {
	return &controlFrameSequencer{
		read: read,
		out:  make(chan controlFrameReadResult, 1),
	}
}

// next is the frame-vs-work race primitive: it arms a read (idempotent while
// one is in flight) and returns the result channel. A frame is consumed only
// when the caller receives from the channel, so a select arm that loses its
// race leaves the frame buffered for the next consumer. Sanctioned production
// callers are exactly the five frame-vs-work races —
// probeCandidatePairsWithTerminalFallback (the probe race, upgrade.go),
// directUpgradeProtocolEngine.awaitListenerListen,
// directUpgradeProtocolEngine.awaitListenerCommitFirst, and the TURN retry
// helpers turnRetryEngine.raceWorkAgainstControl and
// turnRetryEngine.raceHandoffWorkAgainstControl — plus recv's internal await,
// which is a sequential consume, not a race site. Sequential awaits must use
// recv; adding a next caller requires amending the acceptance criteria in
// docs/adr/2026-07-05-control-frame-recv-plan.md. Callers that receive must
// handle the frame — or, in the probe race only, unread it — and callers
// that lose the race must not receive at all; never receive-and-drop. At
// most one goroutine may select on next at a time (upgrade phases are
// sequential, which guarantees this today).
func (s *controlFrameSequencer) next() <-chan controlFrameReadResult {
	s.mu.Lock()
	if len(s.out) > 0 || s.readInProgress {
		out := s.out
		s.mu.Unlock()
		return out
	}
	if len(s.pushback) > 0 {
		last := len(s.pushback) - 1
		s.out <- s.pushback[last]
		s.pushback = s.pushback[:last]
		out := s.out
		s.mu.Unlock()
		return out
	}
	s.readInProgress = true
	out := s.out
	s.mu.Unlock()

	go s.readNext()
	return out
}

// recv is the sequential-await primitive: it blocks until a frame arrives,
// the timeout expires (ErrUpgradeControlTimeout), or ctx is done, draining an
// already-arrived frame before yielding to cancellation. recv always
// consumes, so a goroutine wrapping it must retain ownership of any frame it
// receives (pattern 2 in the type's doc comment). What is
// forbidden is racing recv against independent non-frame work and abandoning
// the consumed frame when the other arm wins; those frame-vs-work races must
// select on next instead (see next's doc comment for the sanctioned sites).
func (s *controlFrameSequencer) recv(ctx context.Context, timeout time.Duration) (controlFrameReadResult, error) {
	select {
	case <-ctx.Done():
		return s.pendingAfterContextDone(ctx)
	default:
	}

	done := s.next()
	var timeoutC <-chan time.Time
	var timer *time.Timer
	if timeout > 0 {
		timer = time.NewTimer(timeout)
		timeoutC = timer.C
		defer timer.Stop()
	}

	select {
	case result := <-done:
		return controlFrameReadResultForContext(ctx, result)
	case <-ctx.Done():
		return s.pendingAfterContextDone(ctx)
	case <-timeoutC:
		if ctxErr := ctx.Err(); ctxErr != nil {
			return controlFrameReadResult{}, ctxErr
		}
		if s.strictToken != nil {
			return controlFrameReadResult{}, &strictAttemptError{s.strictToken, UpgradeErrorTransientTransport, ErrUpgradeControlTimeout}
		}
		return controlFrameReadResult{}, ErrUpgradeControlTimeout
	}
}

func (s *controlFrameSequencer) pendingAfterContextDone(ctx context.Context) (controlFrameReadResult, error) {
	done := s.pendingResult()
	if done == nil {
		return controlFrameReadResult{}, ctx.Err()
	}
	select {
	case result := <-done:
		return controlFrameReadResultForContext(ctx, result)
	default:
		return controlFrameReadResult{}, ctx.Err()
	}
}

func (s *controlFrameSequencer) pendingResult() <-chan controlFrameReadResult {
	s.mu.Lock()
	defer s.mu.Unlock()

	if len(s.out) > 0 || s.readInProgress {
		return s.out
	}
	if len(s.pushback) > 0 {
		last := len(s.pushback) - 1
		s.out <- s.pushback[last]
		s.pushback = s.pushback[:last]
		return s.out
	}
	return nil
}

func controlFrameReadResultForContext(ctx context.Context, result controlFrameReadResult) (controlFrameReadResult, error) {
	if result.err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return controlFrameReadResult{}, ctxErr
		}
		return controlFrameReadResult{}, result.err
	}
	return result, nil
}

// unread pushes a received frame back for the next consumer. Its only
// sanctioned production caller is the probe race, which can consume a frame
// that belongs to a later sequencer consumer. It panics while a read is in
// flight, so it must never run concurrently with an armed next.
func (s *controlFrameSequencer) unread(result controlFrameReadResult) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.readInProgress || len(s.out) > 0 {
		panic("connect: unread control frame while sequencer has pending result")
	}
	s.pushback = append(s.pushback, result)
}

func (s *controlFrameSequencer) readNext() {
	result := s.read()
	s.mu.Lock()
	s.out <- result
	s.readInProgress = false
	s.mu.Unlock()
}
