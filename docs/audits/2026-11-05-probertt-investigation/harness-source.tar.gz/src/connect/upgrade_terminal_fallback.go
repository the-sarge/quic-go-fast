package connect

import (
	"context"
	"time"
)

// terminalFallbackExchange owns the terminal fallback control exchange shared
// by the dialer and listener handoff owners.
type terminalFallbackExchange struct {
	attempt directUpgradeAttempt
}

type terminalFallbackExchangeRequest struct {
	reason                                UpgradeFallbackReason
	peerFallback                          *terminalFallbackReadResult
	classifyState                         directUpgradeControlClassifyState
	commitDone                            <-chan commitAwaitResult
	disableCommitSourceOnPreCommitTimeout bool
	controlDisposition                    failClosedControlDisposition
	// ignoreTurnRetryStart keeps a bilateral listener that has already sent
	// its v1 terminal Fallback exclusively in the v1 exchange: a crossed exact
	// Retry Start is a no-op and the read re-arms.
	ignoreTurnRetryStart bool
}

func newTerminalFallbackExchange(attempt directUpgradeAttempt) terminalFallbackExchange {
	_ = attempt.resources()
	return terminalFallbackExchange{attempt: attempt}
}

func (x terminalFallbackExchange) exchange(ctx context.Context, reason UpgradeFallbackReason) (UpgradeResult, error) {
	return x.exchangeWithClassifier(ctx, terminalFallbackExchangeRequest{
		reason:        reason,
		classifyState: directUpgradeControlClassifyTerminalFallbackOnly,
	})
}

func (x terminalFallbackExchange) withSessionCleanup(ctx context.Context, session Session, reason UpgradeFallbackReason) (UpgradeResult, error) {
	x.attempt.resources().registerSession(session)
	return x.exchange(ctx, reason)
}

// withSessionCleanupIgnoringTurnRetryStart is the bilateral listener's
// probe-failed v1 exchange: it behaves exactly like withSessionCleanup except
// that a crossed exact Retry Start frame is treated as a no-op.
func (x terminalFallbackExchange) withSessionCleanupIgnoringTurnRetryStart(
	ctx context.Context,
	session Session,
	reason UpgradeFallbackReason,
) (UpgradeResult, error) {
	x.attempt.resources().registerSession(session)
	return x.exchangeWithClassifier(ctx, terminalFallbackExchangeRequest{
		reason:               reason,
		classifyState:        directUpgradeControlClassifyTerminalFallbackOnly,
		ignoreTurnRetryStart: true,
	})
}

func (x terminalFallbackExchange) withPeerFallback(
	ctx context.Context,
	reason UpgradeFallbackReason,
	peerFallback *terminalFallbackReadResult,
) (UpgradeResult, error) {
	return x.exchangeWithClassifier(ctx, terminalFallbackExchangeRequest{
		reason:        reason,
		peerFallback:  peerFallback,
		classifyState: directUpgradeControlClassifyTerminalFallbackOnly,
	})
}

func (x terminalFallbackExchange) withSessionCleanupUsingPeerFallback(
	ctx context.Context,
	session Session,
	reason UpgradeFallbackReason,
	peerFallback *terminalFallbackReadResult,
) (UpgradeResult, error) {
	x.attempt.resources().registerSession(session)
	return x.withPeerFallback(ctx, reason, peerFallback)
}

func (x terminalFallbackExchange) withAcceptedSessionCleanupUsingPeerFallback(
	ctx context.Context,
	session Session,
	reason UpgradeFallbackReason,
	peerFallback *terminalFallbackReadResult,
) (UpgradeResult, error) {
	x.attempt.resources().registerSession(session)
	return x.exchangeWithClassifier(ctx, terminalFallbackExchangeRequest{
		reason:             reason,
		peerFallback:       peerFallback,
		classifyState:      directUpgradeControlClassifyTerminalFallbackOnly,
		controlDisposition: abortAfterOwnedResources,
	})
}

func (x terminalFallbackExchange) withSessionCleanupSkippingReady(
	ctx context.Context,
	session Session,
	reason UpgradeFallbackReason,
) (UpgradeResult, error) {
	x.attempt.resources().registerSession(session)
	return x.exchangeWithClassifier(ctx, terminalFallbackExchangeRequest{
		reason:        reason,
		classifyState: directUpgradeControlClassifyTerminalFallbackSkipReady,
	})
}

func (x terminalFallbackExchange) afterPreCommitAcceptFailure(
	ctx context.Context,
	session Session,
	commitDone <-chan commitAwaitResult,
) (UpgradeResult, error) {
	x.attempt.resources().registerSession(session)
	return x.exchangeWithClassifier(ctx, terminalFallbackExchangeRequest{
		reason:                                UpgradeFallbackTransportFailed,
		commitDone:                            commitDone,
		disableCommitSourceOnPreCommitTimeout: true,
		classifyState:                         directUpgradeControlClassifyTerminalFallbackListenerCommit,
		controlDisposition:                    abortAfterOwnedResources,
	})
}

func (x terminalFallbackExchange) afterListenerHandoffTimeout(
	ctx context.Context,
	session Session,
	commitDone <-chan commitAwaitResult,
) (UpgradeResult, error) {
	x.attempt.resources().registerSession(session)
	return x.exchangeWithClassifier(ctx, terminalFallbackExchangeRequest{
		reason:                                UpgradeFallbackTransportFailed,
		commitDone:                            commitDone,
		disableCommitSourceOnPreCommitTimeout: true,
		classifyState:                         directUpgradeControlClassifyTerminalFallbackListenerHandoffCommit,
		controlDisposition:                    abortAfterOwnedResources,
	})
}

func (x terminalFallbackExchange) exchangeWithClassifier(ctx context.Context, req terminalFallbackExchangeRequest) (UpgradeResult, error) {
	a := x.attempt
	resources := a.resources()
	if req.controlDisposition == 0 {
		req.controlDisposition = abortBeforeOwnedResources
	}
	var (
		peer     upgradeControlFallback
		sent     bool
		done     bool
		readDone chan controlFrameReadResult
	)
	if req.peerFallback != nil {
		if req.peerFallback.err != nil {
			if ctxErr := ctx.Err(); ctxErr != nil {
				return resources.failClosed(ctxErr, req.controlDisposition)
			}
			return resources.failClosed(req.peerFallback.err, req.controlDisposition)
		}
		peer = req.peerFallback.peer
		done = true
	}

	frame, err := encodeUpgradeControlFallback(req.reason)
	if err != nil {
		return resources.failClosed(err, retainForOuterSettlement)
	}

	writeErr := make(chan error, 1)
	go func() {
		writeErr <- writeFull(a.channel, frame)
	}()

	timeout := time.NewTimer(a.cfg.controlTimeout)
	defer timeout.Stop()
	startRead := func() {
		if readDone != nil {
			return
		}
		readDone = make(chan controlFrameReadResult, 1)
		go func(done chan<- controlFrameReadResult) {
			frame, err := a.controlFrames.recv(ctx, 0)
			done <- controlFrameReadResult{payload: frame.payload, err: err}
		}(readDone)
	}

	for !sent || !done {
		if err := ctx.Err(); err != nil {
			return resources.failClosed(err, req.controlDisposition)
		}
		var frameDone <-chan controlFrameReadResult
		if !done && req.commitDone == nil {
			startRead()
			frameDone = readDone
		}
		select {
		case err := <-writeErr:
			sent = true
			if err != nil {
				if ctxErr := ctx.Err(); ctxErr != nil {
					return resources.failClosed(ctxErr, req.controlDisposition)
				}
				return resources.failClosed(err, req.controlDisposition)
			}
		case frame := <-frameDone:
			readDone = nil
			if req.ignoreTurnRetryStart && frame.err == nil && decodeTurnRetryStart(frame.payload) {
				continue
			}
			event := classifyDirectUpgradeControlEvent(req.classifyState, frame, false, a.cfg.strict)
			handled, reason, result, err, terminal := x.handlePeerControlEvent(ctx, event, req)
			if terminal {
				return result, err
			}
			if !handled {
				continue
			}
			done = true
			peer = upgradeControlFallback{Reason: reason}
		case commitResult := <-req.commitDone:
			if commitResult.err != nil && req.disableCommitSourceOnPreCommitTimeout && isPreCommitControlTimeout(commitResult.err) {
				req.commitDone = nil
				continue
			}
			event := classifyDirectUpgradeControlEvent(
				req.classifyState,
				controlFrameReadResult{payload: commitResult.frame.payload, err: commitResult.err},
				false,
				a.cfg.strict,
			)
			handled, reason, result, err, terminal := x.handlePeerControlEvent(ctx, event, req)
			if terminal {
				return result, err
			}
			if !handled {
				req.commitDone = nil
				continue
			}
			done = true
			peer = upgradeControlFallback{Reason: reason}
		case <-ctx.Done():
			return resources.failClosed(ctx.Err(), req.controlDisposition)
		case <-timeout.C:
			if ctxErr := ctx.Err(); ctxErr != nil {
				return resources.failClosed(ctxErr, req.controlDisposition)
			}
			return resources.failClosed(a.phaseTimeoutCause(ErrUpgradeControlTimeout), req.controlDisposition)
		}
	}

	return resources.settleRelay(
		resolveFallbackReason(fallbackReasonPhaseTerminal, req.reason, peer.Reason),
	)
}

func (x terminalFallbackExchange) handlePeerControlEvent(
	ctx context.Context,
	event directUpgradeControlEvent,
	req terminalFallbackExchangeRequest,
) (
	handled bool,
	reason UpgradeFallbackReason,
	result UpgradeResult,
	err error,
	terminal bool,
) {
	resources := x.attempt.resources()
	switch event.kind {
	case directUpgradeControlEventRelayFallback:
		return true, event.fallbackReason, UpgradeResult{}, nil, false
	case directUpgradeControlEventIgnoreAndKeepWaiting:
		return false, UpgradeFallbackNone, UpgradeResult{}, nil, false
	case directUpgradeControlEventFailClosedCommitted:
		resources.registerCommit()
		result, err := resources.settleRelay(req.reason)
		return true, UpgradeFallbackNone, result, err, true
	case directUpgradeControlEventControlError:
		if ctxErr := ctx.Err(); ctxErr != nil {
			result, err := resources.failClosed(ctxErr, req.controlDisposition)
			return true, UpgradeFallbackNone, result, err, true
		}
		result, err := resources.failClosed(event.cause, req.controlDisposition)
		return true, UpgradeFallbackNone, result, err, true
	default:
		cause := errUnexpectedDirectUpgradeControlState
		if ctxErr := ctx.Err(); ctxErr != nil {
			cause = ctxErr
		}
		result, err := resources.failClosed(cause, req.controlDisposition)
		return true, UpgradeFallbackNone, result, err, true
	}
}
