// This file is the package's canonical-CBOR scanner, shared by the
// upgrade-control and turn-retry codecs. readCBORHead accepts only
// minimal-length (canonical) heads for every major type, so every integer,
// string length, and container count that reaches a codec through these
// helpers is already in its unique canonical encoding; this file is the
// package's single canonical-uint enforcement owner. Codec-specific limits
// arrive through cborScanOptions; the option constructors live with their
// codecs.

package connect

import (
	"bytes"
	"encoding/binary"
	"errors"
)

var errCBORMalformed = errors.New("connect: malformed control CBOR")

type mapEntry struct {
	key      uint64
	keyRaw   []byte
	valueRaw []byte
}

type cborScanOptions struct {
	maxArrayElements int
	maxMapPairs      int
	maxStringBytes   int
	maxNest          int
}

func scanCBORMapEntries(data []byte, offset int, opts cborScanOptions, nest int) ([]mapEntry, int, error) {
	rawEntries, pos, err := scanCBORRawMapEntries(data, offset, opts, nest)
	if err != nil {
		return nil, 0, err
	}
	entries := make([]mapEntry, 0, len(rawEntries))
	for _, entry := range rawEntries {
		key, ok := decodeUint(entry.keyRaw)
		if !ok {
			return nil, 0, errCBORMalformed
		}
		entry.key = key
		entries = append(entries, entry)
	}
	return entries, pos, nil
}

func scanCBORRawMapEntries(data []byte, offset int, opts cborScanOptions, nest int) ([]mapEntry, int, error) {
	major, pairCount, pos, err := readCBORHead(data, offset)
	if err != nil {
		return nil, 0, err
	}
	if major != 5 {
		return nil, 0, errCBORMalformed
	}
	if exceedsIntLimit(pairCount, opts.maxMapPairs) {
		return nil, 0, errCBORMalformed
	}
	childNest := nest + 1
	if childNest > opts.maxNest {
		return nil, 0, errCBORMalformed
	}

	var previousKey []byte
	entries := make([]mapEntry, 0, pairCount)
	for range pairCount {
		keyStart := pos
		keyEnd, err := scanCBORItem(data, keyStart, opts, childNest)
		if err != nil {
			return nil, 0, err
		}
		keyRaw := data[keyStart:keyEnd]
		if previousKey != nil && bytes.Compare(previousKey, keyRaw) >= 0 {
			return nil, 0, errCBORMalformed
		}

		valueStart := keyEnd
		valueEnd, err := scanCBORItem(data, valueStart, opts, childNest)
		if err != nil {
			return nil, 0, err
		}
		entries = append(entries, mapEntry{
			keyRaw:   keyRaw,
			valueRaw: data[valueStart:valueEnd],
		})
		previousKey = keyRaw
		pos = valueEnd
	}

	return entries, pos, nil
}

func scanCBORArrayItems(data []byte, offset int, opts cborScanOptions, nest int) ([][]byte, int, error) {
	major, elementCount, pos, err := readCBORHead(data, offset)
	if err != nil {
		return nil, 0, err
	}
	if major != 4 {
		return nil, 0, errCBORMalformed
	}
	if exceedsIntLimit(elementCount, opts.maxArrayElements) {
		return nil, 0, errCBORMalformed
	}
	childNest := nest + 1
	if childNest > opts.maxNest {
		return nil, 0, errCBORMalformed
	}

	items := make([][]byte, 0, elementCount)
	for range elementCount {
		itemStart := pos
		itemEnd, err := scanCBORItem(data, itemStart, opts, childNest)
		if err != nil {
			return nil, 0, err
		}
		items = append(items, data[itemStart:itemEnd])
		pos = itemEnd
	}
	return items, pos, nil
}

func scanCBORItem(data []byte, offset int, opts cborScanOptions, nest int) (int, error) {
	major, value, pos, err := readCBORHead(data, offset)
	if err != nil {
		return 0, err
	}
	switch major {
	case 0, 1:
		return pos, nil
	case 2, 3:
		end, ok := boundedCBORDataEnd(pos, value, opts.maxStringBytes, len(data))
		if !ok {
			return 0, errCBORMalformed
		}
		return end, nil
	case 4:
		if exceedsIntLimit(value, opts.maxArrayElements) {
			return 0, errCBORMalformed
		}
		childNest := nest + 1
		if childNest > opts.maxNest {
			return 0, errCBORMalformed
		}
		for range value {
			pos, err = scanCBORItem(data, pos, opts, childNest)
			if err != nil {
				return 0, err
			}
		}
		return pos, nil
	case 5:
		if exceedsIntLimit(value, opts.maxMapPairs) {
			return 0, errCBORMalformed
		}
		childNest := nest + 1
		if childNest > opts.maxNest {
			return 0, errCBORMalformed
		}
		var previousKey []byte
		for range value {
			keyStart := pos
			keyEnd, err := scanCBORItem(data, keyStart, opts, childNest)
			if err != nil {
				return 0, err
			}
			keyRaw := data[keyStart:keyEnd]
			if previousKey != nil && bytes.Compare(previousKey, keyRaw) >= 0 {
				return 0, errCBORMalformed
			}
			pos, err = scanCBORItem(data, keyEnd, opts, childNest)
			if err != nil {
				return 0, err
			}
			previousKey = keyRaw
		}
		return pos, nil
	case 6:
		return 0, errCBORMalformed
	case 7:
		switch value {
		case 20, 21, 22:
			return pos, nil
		default:
			return 0, errCBORMalformed
		}
	default:
		return 0, errCBORMalformed
	}
}

// readCBORHead rejects every non-minimal head encoding: each additional-info
// branch requires the value to exceed the range of the shorter form, so a
// given value has exactly one accepted head. This is what makes the scanned
// subset canonical without any per-field re-checking in the codecs.
func readCBORHead(data []byte, offset int) (major byte, value uint64, end int, err error) {
	if offset >= len(data) {
		return 0, 0, 0, errCBORMalformed
	}
	first := data[offset]
	major = first >> 5
	additional := first & 0x1f
	switch {
	case additional < 24:
		return major, uint64(additional), offset + 1, nil
	case additional == 24:
		if offset+2 > len(data) {
			return 0, 0, 0, errCBORMalformed
		}
		value = uint64(data[offset+1])
		if major == 7 {
			if value < 32 {
				return 0, 0, 0, errCBORMalformed
			}
		} else if value < 24 {
			return 0, 0, 0, errCBORMalformed
		}
		return major, value, offset + 2, nil
	case additional == 25:
		if offset+3 > len(data) {
			return 0, 0, 0, errCBORMalformed
		}
		if major == 7 {
			return 0, 0, 0, errCBORMalformed
		}
		value = uint64(binary.BigEndian.Uint16(data[offset+1:]))
		if value <= 0xff {
			return 0, 0, 0, errCBORMalformed
		}
		return major, value, offset + 3, nil
	case additional == 26:
		if offset+5 > len(data) {
			return 0, 0, 0, errCBORMalformed
		}
		if major == 7 {
			return 0, 0, 0, errCBORMalformed
		}
		value = uint64(binary.BigEndian.Uint32(data[offset+1:]))
		if value <= 0xffff {
			return 0, 0, 0, errCBORMalformed
		}
		return major, value, offset + 5, nil
	case additional == 27:
		if offset+9 > len(data) {
			return 0, 0, 0, errCBORMalformed
		}
		if major == 7 {
			return 0, 0, 0, errCBORMalformed
		}
		value = binary.BigEndian.Uint64(data[offset+1:])
		if value <= 0xffffffff {
			return 0, 0, 0, errCBORMalformed
		}
		return major, value, offset + 9, nil
	default:
		return 0, 0, 0, errCBORMalformed
	}
}

func decodeUint(payload []byte) (uint64, bool) {
	if len(payload) == 0 {
		return 0, false
	}
	major, value, end, err := readCBORHead(payload, 0)
	if err != nil || end != len(payload) || major != 0 {
		return 0, false
	}
	return value, true
}

func decodeBytes(payload []byte, maxLen int) ([]byte, bool) {
	if len(payload) == 0 {
		return nil, false
	}
	major, value, end, err := readCBORHead(payload, 0)
	if err != nil || major != 2 {
		return nil, false
	}
	dataEnd, ok := boundedCBORDataEnd(end, value, maxLen, len(payload))
	if !ok || dataEnd != len(payload) {
		return nil, false
	}
	return payload[end:dataEnd], true
}

func decodeText(payload []byte, maxLen int) (string, bool) {
	if len(payload) == 0 {
		return "", false
	}
	major, value, end, err := readCBORHead(payload, 0)
	if err != nil || major != 3 || value == 0 {
		return "", false
	}
	dataEnd, ok := boundedCBORDataEnd(end, value, maxLen, len(payload))
	if !ok || dataEnd != len(payload) {
		return "", false
	}
	for _, b := range payload[end:dataEnd] {
		if b < 0x20 || b > 0x7e {
			return "", false
		}
	}
	return string(payload[end:dataEnd]), true
}

func boundedCBORDataEnd(start int, size uint64, maxSize int, dataLen int) (int, bool) {
	if start < 0 || start > dataLen || exceedsIntLimit(size, maxSize) || exceedsIntLimit(size, dataLen-start) {
		return 0, false
	}
	return start + int(size), true // #nosec G115 -- size is bounded by the remaining data length before conversion.
}

func exceedsIntLimit(value uint64, limit int) bool {
	if limit < 0 {
		return true
	}
	return value > uint64(limit)
}
