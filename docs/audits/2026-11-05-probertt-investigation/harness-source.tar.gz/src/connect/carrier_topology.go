package connect

import "errors"

// CarrierTopology classifies the physical shape of the active carrier,
// independently of the compatibility-frozen UpgradePath outcome: a direct
// upgrade over TURN relays is UpgradePathDirect but relay-assisted topology.
type CarrierTopology string

const (
	// CarrierTopologyDirect is a peer-to-peer carrier on a selected pair
	// whose two candidate kinds independently belong to {host, reflexive} in
	// any order or combination.
	CarrierTopologyDirect CarrierTopology = "direct"
	// CarrierTopologyRelayAssisted is a relay-carried path: the retained
	// reliable relay fallback or an upgraded relay/relay TURN carrier.
	CarrierTopologyRelayAssisted CarrierTopology = "relay_assisted"
)

// errInvalidCarrierTopologyShape reports a result shape outside the canonical
// classification: a mixed pair with exactly one relay candidate, a direct
// path without a selected pair, a relay fallback carrying a pair, or an
// unknown path or candidate kind.
var errInvalidCarrierTopologyShape = errors.New("connect: upgrade result has no canonical carrier topology")

// CarrierTopology centrally derives and validates the canonical carrier
// topology from the produced path and selected pair. Mixed, nil-upgraded, or
// fallback-with-pair shapes return the invalid zero value and a non-nil
// error; an arbitrary externally constructed result is not authoritative.
func (r UpgradeResult) CarrierTopology() (CarrierTopology, error) {
	switch r.Path {
	case UpgradePathRelay:
		if r.SelectedPair != nil {
			return "", errInvalidCarrierTopologyShape
		}
		return CarrierTopologyRelayAssisted, nil
	case UpgradePathDirect:
		if r.SelectedPair == nil {
			return "", errInvalidCarrierTopologyShape
		}
		local := classifyCandidateKind(r.SelectedPair.Local.Kind)
		remote := classifyCandidateKind(r.SelectedPair.Remote.Kind)
		if local.direct && remote.direct {
			return CarrierTopologyDirect, nil
		}
		if local.relay && remote.relay {
			return CarrierTopologyRelayAssisted, nil
		}
		return "", errInvalidCarrierTopologyShape
	default:
		return "", errInvalidCarrierTopologyShape
	}
}
