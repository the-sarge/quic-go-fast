package connect

import (
	"context"
	"errors"
	"io"
	"net"
	"net/netip"
	"reflect"
	"runtime"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func (r *attemptResources) packetOwnershipTransferred() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.transfer.Transferred()
}

func TestAttemptResourcesTerminalSequenceR1NSettleRelayPreOperation(t *testing.T) {
	t.Parallel()

	channel := &terminalTestChannel{}
	packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
	session := &terminalTestSession{}
	owner := newAttemptResources(channel, packetConn)
	owner.registerSession(session)

	result, err := owner.settleRelay(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("settleRelay error = %v, want nil", err)
	}
	if result.Stream != channel || result.Path != UpgradePathRelay || result.FallbackReason != UpgradeFallbackTransportFailed {
		t.Fatalf("settleRelay result = %+v, want exact relay channel and transport_failed reason", result)
	}
	if got := session.closeCalls.Load(); got != 1 {
		t.Fatalf("Session.Close calls = %d, want 1", got)
	}
	if got := channel.closeCalls.Load(); got != 0 {
		t.Fatalf("control Close calls = %d, want 0", got)
	}
	if packetConn.closed.Load() {
		t.Fatal("pre-operation relay settlement closed the exact packet socket")
	}
}

func TestAttemptResourcesTerminalDispositionPreOperationFailClosed(t *testing.T) {
	t.Parallel()

	cause := errors.New("control failed")
	tests := []struct {
		name        string
		disposition failClosedControlDisposition
		wantOrder   []string
	}{
		{
			name:        "R2-NB abort before session",
			disposition: abortBeforeOwnedResources,
			wantOrder:   []string{"control", "session"},
		},
		{
			name:        "R2-NK retain control",
			disposition: retainForOuterSettlement,
			wantOrder:   []string{"session"},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			order := &terminalSequenceRecorder{}
			channel := &terminalTestChannel{order: order}
			packetConn := &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}}
			session := &terminalTestSession{order: order}
			owner := newAttemptResources(channel, packetConn)
			owner.registerSession(session)

			result, err := owner.failClosed(cause, test.disposition)
			if result != (UpgradeResult{}) {
				t.Fatalf("failClosed result = %+v, want zero", result)
			}
			if !errors.Is(err, cause) || errors.Is(err, ErrUpgradeTransportNotConverged) {
				t.Fatalf("failClosed error = %v, want bare preserved cause %v", err, cause)
			}
			if got := order.snapshot(); !reflect.DeepEqual(got, test.wantOrder) {
				t.Fatalf("terminal order = %v, want %v", got, test.wantOrder)
			}
			if packetConn.closed.Load() {
				t.Fatal("pre-operation fail-closed settlement closed the exact packet socket")
			}
		})
	}
}

func TestAttemptResourcesTerminalDispositionIsFirstWins(t *testing.T) {
	t.Parallel()

	channel := &terminalTestChannel{}
	session := &terminalTestSession{}
	owner := newAttemptResources(channel, &closeTrackingPacketConn{PacketConn: discardTestPacketConn{}})
	owner.registerSession(session)

	first, firstErr := owner.settleRelay(UpgradeFallbackProbeFailed)
	second, secondErr := owner.failClosed(errors.New("too late"), abortBeforeOwnedResources)
	if firstErr != nil || secondErr != nil {
		t.Fatalf("terminal errors = %v, %v; want nil first-wins relay result", firstErr, secondErr)
	}
	if first.Stream != channel || first.Path != UpgradePathRelay || first.FallbackReason != UpgradeFallbackProbeFailed {
		t.Fatalf("first result = %+v, want probe-failed relay", first)
	}
	if second != first {
		t.Fatalf("second result = %+v, want first result %+v", second, first)
	}
	if got := session.closeCalls.Load(); got != 1 {
		t.Fatalf("Session.Close calls = %d, want first-wins 1", got)
	}
	if got := channel.closeCalls.Load(); got != 0 {
		t.Fatalf("control Close calls = %d, want 0", got)
	}
	owner.mu.Lock()
	disposition := owner.terminalDisposition
	control := owner.terminalControl
	cause := owner.terminalCause
	owner.mu.Unlock()
	if disposition != attemptTerminalSettleRelay || control != 0 || cause != nil {
		t.Fatalf("winning terminal request = disposition %v, control %v, cause %v; want settleRelay, zero, nil", disposition, control, cause)
	}
}

func TestAttemptResourcesTerminalDispositionConcurrentFirstWins(t *testing.T) {
	t.Parallel()

	packetConn := &terminalTestPacketConn{}
	stream := &terminalTestStream{packetConn: packetConn}
	channel := &terminalTestChannel{}
	session := &terminalTestSession{dialStream: stream}
	owner := newAttemptResources(channel, packetConn)
	owner.registerSession(session)
	<-owner.startDial(context.Background(), session, packetConn, nil, nil)

	const callers = 32
	errs := make(chan error, callers)
	var callersReady sync.WaitGroup
	callersReady.Add(callers)
	start := make(chan struct{})
	for range callers {
		go func() {
			callersReady.Done()
			<-start
			_, err := owner.failClosed(errors.New("terminal"), abortAfterOwnedResources)
			errs <- err
		}()
	}
	callersReady.Wait()
	close(start)
	for range callers {
		err := <-errs
		if !errors.Is(err, ErrUpgradeTransportNotConverged) {
			t.Fatalf("concurrent terminal error = %v, want transport-not-converged", err)
		}
	}
	if stream.closeCalls.Load() != 1 || packetConn.closeCalls.Load() != 1 || session.closeCalls.Load() != 1 || channel.closeCalls.Load() != 1 {
		t.Fatalf("concurrent terminal calls = stream %d, packet %d, session %d, control %d; want all 1", stream.closeCalls.Load(), packetConn.closeCalls.Load(), session.closeCalls.Load(), channel.closeCalls.Load())
	}
}

func TestAttemptResourcesTerminalSequenceMaterializedDialFailure(t *testing.T) {
	t.Parallel()

	order := &terminalSequenceRecorder{}
	packetConn := &terminalTestPacketConn{order: order}
	stream := &terminalTestStream{order: order, packetConn: packetConn}
	channel := &terminalTestChannel{order: order}
	session := &terminalTestSession{order: order, dialStream: stream}
	owner := newAttemptResources(channel, packetConn)
	owner.registerSession(session)
	if result := <-owner.startDial(context.Background(), session, packetConn, nil, nil); result.stream != stream || result.err != nil {
		t.Fatalf("Dial result = %T, %v; want exact stream, nil", result.stream, result.err)
	}

	cause := errors.New("Datagram agreement failed")
	result, err := owner.failClosed(cause, abortAfterOwnedResources)
	if result != (UpgradeResult{}) {
		t.Fatalf("failClosed result = %+v, want zero", result)
	}
	if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, cause) {
		t.Fatalf("failClosed error = %v, want transport-not-converged preserving %v", err, cause)
	}
	wantOrder := []string{"stream", "packet", "session", "control"}
	if got := order.snapshot(); !reflect.DeepEqual(got, wantOrder) {
		t.Fatalf("terminal order = %v, want %v", got, wantOrder)
	}
	if got := stream.closeCalls.Load(); got != 1 {
		t.Fatalf("stream Close calls = %d, want 1", got)
	}
	if got := packetConn.closeCalls.Load(); got != 1 {
		t.Fatalf("exact packet Close calls = %d, want 1", got)
	}
}

func TestAttemptResourcesTerminalSequencePendingDialResultMatrix(t *testing.T) {
	t.Parallel()

	terminalCause := errors.New("terminal request")
	operationErr := errors.New("Dial failed")
	tests := []struct {
		name       string
		withStream bool
		dialErr    error
		wantOrder  []string
		wantStream int32
		wantPacket int32
	}{
		{
			name:       "R9 and R14-F failure",
			dialErr:    operationErr,
			wantOrder:  []string{"session", "packet", "control"},
			wantPacket: 1,
		},
		{
			name:       "R10 and R14-S success",
			withStream: true,
			wantOrder:  []string{"session", "stream", "packet", "control"},
			wantStream: 1,
			wantPacket: 1,
		},
		{
			name:       "R10-E and R14-M stream error",
			withStream: true,
			dialErr:    operationErr,
			wantOrder:  []string{"session", "stream", "packet", "control"},
			wantStream: 1,
			wantPacket: 1,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			order := &terminalSequenceRecorder{}
			packetConn := &terminalTestPacketConn{order: order}
			var stream *terminalTestStream
			var dialStream io.ReadWriteCloser
			if test.withStream {
				stream = &terminalTestStream{order: order, packetConn: packetConn}
				dialStream = stream
			}
			session := &terminalTestSession{
				order:       order,
				dialStream:  dialStream,
				dialErr:     test.dialErr,
				dialStarted: make(chan struct{}),
				dialRelease: make(chan struct{}),
			}
			owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
			owner.registerSession(session)
			owner.registerCommit()
			owner.startDial(context.Background(), session, packetConn, nil, nil)
			<-session.dialStarted

			result, err := owner.failClosed(terminalCause, abortAfterOwnedResources)
			if result != (UpgradeResult{}) {
				t.Fatalf("failClosed result = %+v, want zero", result)
			}
			if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, terminalCause) || errors.Is(err, operationErr) {
				t.Fatalf("failClosed error = %v, want terminal sentinel/cause without operation error", err)
			}
			if got := order.snapshot(); !reflect.DeepEqual(got, test.wantOrder) {
				t.Fatalf("terminal order = %v, want %v", got, test.wantOrder)
			}
			if stream != nil {
				if got := stream.closeCalls.Load(); got != test.wantStream {
					t.Fatalf("stream Close calls = %d, want %d", got, test.wantStream)
				}
			}
			if got := packetConn.closeCalls.Load(); got != test.wantPacket {
				t.Fatalf("exact packet Close calls = %d, want %d", got, test.wantPacket)
			}
			snapshot := owner.snapshot()
			if snapshot.dial != attemptOperationJoined || snapshot.claim != packetClaimDisposed {
				t.Fatalf("terminal Dial state = lifecycle %v, claim %v; want joined and disposed", snapshot.dial, snapshot.claim)
			}
			owner.mu.Lock()
			terminalState := owner.terminalState
			owner.mu.Unlock()
			if terminalState != attemptTerminalStateDialPending {
				t.Fatalf("elected terminal state = %v, want pending Dial", terminalState)
			}
		})
	}
}

func TestAttemptResourcesTerminalSequenceDefinitiveDialResultMatrix(t *testing.T) {
	t.Parallel()

	terminalCause := errors.New("terminal request")
	operationErr := errors.New("Dial failed")
	tests := []struct {
		name       string
		withStream bool
		dialErr    error
		wantOrder  []string
	}{
		{
			name:      "R9-D failure",
			dialErr:   operationErr,
			wantOrder: []string{"session", "packet", "control"},
		},
		{
			name:       "R8 materialized success result",
			withStream: true,
			wantOrder:  []string{"stream", "packet", "session", "control"},
		},
		{
			name:       "R13 materialized stream error",
			withStream: true,
			dialErr:    operationErr,
			wantOrder:  []string{"stream", "packet", "session", "control"},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			order := &terminalSequenceRecorder{}
			packetConn := &terminalTestPacketConn{order: order}
			var stream *terminalTestStream
			var dialStream io.ReadWriteCloser
			if test.withStream {
				stream = &terminalTestStream{order: order, packetConn: packetConn}
				dialStream = stream
			}
			session := &terminalTestSession{order: order, dialStream: dialStream, dialErr: test.dialErr}
			owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
			owner.registerSession(session)
			owner.registerCommit()
			if result := <-owner.startDial(context.Background(), session, packetConn, nil, nil); result.stream != dialStream || !errors.Is(result.err, test.dialErr) {
				t.Fatalf("Dial result = %T, %v; want %T, %v", result.stream, result.err, dialStream, test.dialErr)
			}

			result, err := owner.failClosed(terminalCause, abortAfterOwnedResources)
			if result != (UpgradeResult{}) || !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, terminalCause) || errors.Is(err, operationErr) {
				t.Fatalf("terminal result = %+v, %v; want zero and terminal sentinel/cause only", result, err)
			}
			if got := order.snapshot(); !reflect.DeepEqual(got, test.wantOrder) {
				t.Fatalf("terminal order = %v, want %v", got, test.wantOrder)
			}
			if got := packetConn.closeCalls.Load(); got != 1 {
				t.Fatalf("exact packet Close calls = %d, want 1", got)
			}
			snapshot := owner.snapshot()
			if snapshot.dial != attemptOperationJoined || snapshot.claim != packetClaimDisposed {
				t.Fatalf("terminal Dial state = lifecycle %v, claim %v; want joined and disposed", snapshot.dial, snapshot.claim)
			}
		})
	}
}

func TestAttemptResourcesTerminalSequencePendingAcceptResultMatrix(t *testing.T) {
	t.Parallel()

	terminalCause := errors.New("terminal request")
	operationErr := errors.New("Accept failed")
	tests := []struct {
		name        string
		committed   bool
		withStream  bool
		acceptErr   error
		settleRelay bool
		disposition failClosedControlDisposition
		wantOrder   []string
		wantRelay   bool
		wantWrapped bool
	}{
		{
			name:        "R1-A relay after failed Accept",
			acceptErr:   operationErr,
			settleRelay: true,
			wantOrder:   []string{"listener", "session"},
			wantRelay:   true,
		},
		{
			name:        "R2-AA abort after failed Accept",
			acceptErr:   operationErr,
			disposition: abortAfterOwnedResources,
			wantOrder:   []string{"listener", "session", "control"},
		},
		{
			name:        "R2-AK retain after failed Accept",
			acceptErr:   operationErr,
			disposition: retainForOuterSettlement,
			wantOrder:   []string{"listener", "session"},
		},
		{
			name:        "R5-A relay request promoted by materialized Accept",
			withStream:  true,
			settleRelay: true,
			wantOrder:   []string{"listener", "session", "stream", "packet", "control"},
			wantWrapped: true,
		},
		{
			name:        "R5-A fail closed after materialized Accept",
			withStream:  true,
			disposition: abortAfterOwnedResources,
			wantOrder:   []string{"listener", "session", "stream", "packet", "control"},
			wantWrapped: true,
		},
		{
			name:        "R5-KM retain after materialized Accept error",
			withStream:  true,
			acceptErr:   operationErr,
			disposition: retainForOuterSettlement,
			wantOrder:   []string{"listener", "session", "stream", "packet"},
			wantWrapped: true,
		},
		{
			name:        "R6 committed failed Accept",
			committed:   true,
			acceptErr:   operationErr,
			disposition: abortAfterOwnedResources,
			wantOrder:   []string{"listener", "session", "packet", "control"},
			wantWrapped: true,
		},
		{
			name:        "R7-E committed materialized Accept error",
			committed:   true,
			withStream:  true,
			acceptErr:   operationErr,
			disposition: abortAfterOwnedResources,
			wantOrder:   []string{"listener", "session", "stream", "packet", "control"},
			wantWrapped: true,
		},
		{
			name:        "R5-K retain after materialized Accept",
			withStream:  true,
			disposition: retainForOuterSettlement,
			wantOrder:   []string{"listener", "session", "stream", "packet"},
			wantWrapped: true,
		},
		{
			name:        "R5-AM abort after materialized Accept error",
			withStream:  true,
			acceptErr:   operationErr,
			disposition: abortAfterOwnedResources,
			wantOrder:   []string{"listener", "session", "stream", "packet", "control"},
			wantWrapped: true,
		},
		{
			name:        "R7 committed materialized Accept",
			committed:   true,
			withStream:  true,
			disposition: abortAfterOwnedResources,
			wantOrder:   []string{"listener", "session", "stream", "packet", "control"},
			wantWrapped: true,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			order := &terminalSequenceRecorder{}
			packetConn := &terminalTestPacketConn{order: order}
			var stream *terminalTestStream
			var acceptStream io.ReadWriteCloser
			if test.withStream {
				stream = &terminalTestStream{order: order, packetConn: packetConn}
				acceptStream = stream
			}
			listener := newTerminalTestAcceptListener(order, acceptStream, test.acceptErr)
			channel := &terminalTestChannel{order: order}
			session := &terminalTestSession{order: order}
			owner := newAttemptResources(channel, packetConn)
			owner.registerSession(session)
			if test.committed {
				owner.registerCommit()
			}
			_, acceptDone := owner.startAccept(context.Background(), listener)
			<-listener.acceptStarted

			var (
				result UpgradeResult
				err    error
			)
			if test.settleRelay {
				result, err = owner.settleRelay(UpgradeFallbackTransportFailed)
			} else {
				result, err = owner.failClosed(terminalCause, test.disposition)
			}
			if test.wantRelay {
				if err != nil || result.Stream != channel || result.Path != UpgradePathRelay || result.FallbackReason != UpgradeFallbackTransportFailed {
					t.Fatalf("terminal result = %+v, %v; want transport-failed relay", result, err)
				}
			} else {
				if result != (UpgradeResult{}) {
					t.Fatalf("terminal result = %+v, want zero", result)
				}
				if test.wantWrapped {
					if !errors.Is(err, ErrUpgradeTransportNotConverged) {
						t.Fatalf("terminal error = %v, want transport-not-converged", err)
					}
					if !test.settleRelay && !errors.Is(err, terminalCause) {
						t.Fatalf("terminal error = %v, want preserved cause %v", err, terminalCause)
					}
				} else if !errors.Is(err, terminalCause) || errors.Is(err, ErrUpgradeTransportNotConverged) {
					t.Fatalf("terminal error = %v, want bare cause %v", err, terminalCause)
				}
			}
			if errors.Is(err, operationErr) {
				t.Fatalf("terminal error = %v, must retain operation error as evidence only", err)
			}
			if got := order.snapshot(); !reflect.DeepEqual(got, test.wantOrder) {
				t.Fatalf("terminal order = %v, want %v", got, test.wantOrder)
			}
			if stream != nil {
				if got := stream.closeCalls.Load(); got != 1 {
					t.Fatalf("stream Close calls = %d, want 1", got)
				}
			}
			if got := packetConn.closeCalls.Load(); got != boolToInt32(test.committed || test.withStream) {
				t.Fatalf("exact packet Close calls = %d, want %d", got, boolToInt32(test.committed || test.withStream))
			}
			if state := owner.snapshot().accept; state != attemptOperationJoined {
				t.Fatalf("Accept lifecycle = %v, want joined", state)
			}
			owner.mu.Lock()
			terminalState := owner.terminalState
			owner.mu.Unlock()
			wantTerminalState := attemptTerminalStateAcceptPendingUntransferred
			if test.committed {
				wantTerminalState = attemptTerminalStateAcceptPendingTransferred
			}
			if terminalState != wantTerminalState {
				t.Fatalf("elected terminal state = %v, want %v", terminalState, wantTerminalState)
			}
			select {
			case <-acceptDone:
			default:
				t.Fatal("joined Accept result was not published to its registered result channel")
			}
		})
	}
}

func TestAttemptResourcesSettleRelayPendingAcceptStreamErrorUsesOperationCause(t *testing.T) {
	t.Parallel()

	order := &terminalSequenceRecorder{}
	packetConn := &terminalTestPacketConn{order: order}
	stream := &terminalTestStream{order: order, packetConn: packetConn}
	operationErr := errors.New("Accept materialized with error")
	listener := newTerminalTestAcceptListener(order, stream, operationErr)
	owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
	owner.registerSession(&terminalTestSession{order: order})
	_, acceptDone := owner.startAccept(context.Background(), listener)
	<-listener.acceptStarted

	result, err := owner.settleRelay(UpgradeFallbackTransportFailed)
	if result != (UpgradeResult{}) {
		t.Fatalf("settleRelay result = %+v, want zero", result)
	}
	if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, operationErr) {
		t.Fatalf("settleRelay error = %v, want transport-not-converged preserving operation cause %v", err, operationErr)
	}
	if got := order.snapshot(); !reflect.DeepEqual(got, []string{"listener", "session", "stream", "packet", "control"}) {
		t.Fatalf("terminal order = %v, want [listener session stream packet control]", got)
	}
	if got := stream.closeCalls.Load(); got != 1 {
		t.Fatalf("stream Close calls = %d, want 1", got)
	}
	if got := packetConn.closeCalls.Load(); got != 1 {
		t.Fatalf("exact packet Close calls = %d, want 1", got)
	}
	select {
	case <-acceptDone:
	default:
		t.Fatal("joined Accept result was not published to its registered result channel")
	}
}

func TestAttemptResourcesSettleRelayDefinitivePreCommitAcceptStreamErrorUsesOperationCause(t *testing.T) {
	t.Parallel()

	order := &terminalSequenceRecorder{}
	packetConn := &terminalTestPacketConn{order: order}
	stream := &terminalTestStream{order: order, packetConn: packetConn}
	operationErr := errors.New("Accept materialized with error")
	listener := &terminalTestDefinitiveAcceptListener{order: order}
	acceptDone := make(chan transportAcceptResult, 1)
	owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
	owner.registerSession(&terminalTestSession{order: order})
	registerCompletedTestAcceptOperation(
		owner,
		listener,
		acceptDone,
		transportAcceptResult{stream: stream, err: operationErr},
	)

	result, err := owner.settleRelay(UpgradeFallbackTransportFailed)
	if result != (UpgradeResult{}) {
		t.Fatalf("settleRelay result = %+v, want zero", result)
	}
	if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, operationErr) {
		t.Fatalf("settleRelay error = %v, want transport-not-converged preserving operation cause %v", err, operationErr)
	}
	if got := order.snapshot(); !reflect.DeepEqual(got, []string{"listener", "session", "stream", "packet", "control"}) {
		t.Fatalf("terminal order = %v, want [listener session stream packet control]", got)
	}
	if got := stream.closeCalls.Load(); got != 1 {
		t.Fatalf("stream Close calls = %d, want 1", got)
	}
	if got := packetConn.closeCalls.Load(); got != 1 {
		t.Fatalf("exact packet Close calls = %d, want 1", got)
	}
}

func TestAttemptResourcesFailClosedPendingAcceptStreamErrorPreservesRequestCause(t *testing.T) {
	t.Parallel()

	order := &terminalSequenceRecorder{}
	packetConn := &terminalTestPacketConn{order: order}
	stream := &terminalTestStream{order: order, packetConn: packetConn}
	operationErr := errors.New("Accept materialized with error")
	requestCause := errors.New("terminal request")
	listener := newTerminalTestAcceptListener(order, stream, operationErr)
	owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
	owner.registerSession(&terminalTestSession{order: order})
	_, acceptDone := owner.startAccept(context.Background(), listener)
	<-listener.acceptStarted

	result, err := owner.failClosed(requestCause, abortAfterOwnedResources)
	if result != (UpgradeResult{}) {
		t.Fatalf("failClosed result = %+v, want zero", result)
	}
	if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, requestCause) || errors.Is(err, operationErr) {
		t.Fatalf("failClosed error = %v, want transport-not-converged preserving request cause %v only", err, requestCause)
	}
	if got := order.snapshot(); !reflect.DeepEqual(got, []string{"listener", "session", "stream", "packet", "control"}) {
		t.Fatalf("terminal order = %v, want [listener session stream packet control]", got)
	}
	if got := stream.closeCalls.Load(); got != 1 {
		t.Fatalf("stream Close calls = %d, want 1", got)
	}
	if got := packetConn.closeCalls.Load(); got != 1 {
		t.Fatalf("exact packet Close calls = %d, want 1", got)
	}
	select {
	case <-acceptDone:
	default:
		t.Fatal("joined Accept result was not published to its registered result channel")
	}
}

func TestAttemptResourcesTerminalSequenceDefinitiveAcceptResultMatrix(t *testing.T) {
	t.Parallel()

	terminalCause := errors.New("terminal request")
	operationErr := errors.New("Accept failed")
	tests := []struct {
		name       string
		committed  bool
		withStream bool
		acceptErr  error
		cause      error
		wantOrder  []string
	}{
		{
			name:      "R6 committed failure",
			committed: true,
			acceptErr: operationErr,
			wantOrder: []string{"listener", "session", "packet", "control"},
		},
		{
			name:       "R3 materialized cancellation",
			withStream: true,
			cause:      context.Canceled,
			wantOrder:  []string{"stream", "packet", "listener", "session", "control"},
		},
		{
			name:       "R4 materialized control error",
			withStream: true,
			cause:      errors.New("commit read failed"),
			wantOrder:  []string{"stream", "packet", "listener", "session", "control"},
		},
		{
			name:       "R12 materialized Datagram failure",
			withStream: true,
			cause:      errors.New("Datagram agreement failed"),
			wantOrder:  []string{"stream", "packet", "listener", "session", "control"},
		},
		{
			name:       "R12 materialized transport failure",
			withStream: true,
			cause:      errors.New("transport failed"),
			wantOrder:  []string{"stream", "packet", "listener", "session", "control"},
		},
		{
			name:       "R12 materialized convergence failure",
			withStream: true,
			cause:      errors.New("convergence failed"),
			wantOrder:  []string{"stream", "packet", "listener", "session", "control"},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			order := &terminalSequenceRecorder{}
			packetConn := &terminalTestPacketConn{order: order}
			var stream *terminalTestStream
			var acceptStream io.ReadWriteCloser
			if test.withStream {
				stream = &terminalTestStream{order: order, packetConn: packetConn}
				acceptStream = stream
			}
			listener := &terminalTestDefinitiveAcceptListener{
				order:  order,
				stream: acceptStream,
				err:    test.acceptErr,
			}
			session := &terminalTestSession{order: order}
			owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
			owner.registerSession(session)
			if test.committed {
				owner.registerCommit()
			}
			_, acceptDone := owner.startAccept(context.Background(), listener)
			<-acceptDone

			cause := test.cause
			if cause == nil {
				cause = terminalCause
			}
			result, err := owner.failClosed(cause, abortAfterOwnedResources)
			if result != (UpgradeResult{}) || !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, cause) || errors.Is(err, operationErr) {
				t.Fatalf("terminal result = %+v, %v; want zero and terminal sentinel/cause only", result, err)
			}
			if got := order.snapshot(); !reflect.DeepEqual(got, test.wantOrder) {
				t.Fatalf("terminal order = %v, want %v", got, test.wantOrder)
			}
			if got := packetConn.closeCalls.Load(); got != 1 {
				t.Fatalf("exact packet Close calls = %d, want 1", got)
			}
			snapshot := owner.snapshot()
			if snapshot.accept != attemptOperationJoined || snapshot.claim != packetClaimDisposed {
				t.Fatalf("terminal Accept state = lifecycle %v, claim %v; want joined and disposed", snapshot.accept, snapshot.claim)
			}
		})
	}
}

func TestAttemptResourcesTerminalSequenceDefinitivePreCommitAcceptFailureSettlesRelay(t *testing.T) {
	t.Parallel()

	order := &terminalSequenceRecorder{}
	packetConn := &terminalTestPacketConn{order: order}
	listener := &terminalTestDefinitiveAcceptListener{
		order: order,
		err:   errors.New("Accept failed"),
	}
	session := &terminalTestSession{order: order}
	channel := &terminalTestChannel{order: order}
	owner := newAttemptResources(channel, packetConn)
	owner.registerSession(session)
	_, acceptDone := owner.startAccept(context.Background(), listener)
	<-acceptDone

	result, err := owner.settleRelay(UpgradeFallbackTransportFailed)
	if err != nil || result.Stream != channel || result.Path != UpgradePathRelay || result.FallbackReason != UpgradeFallbackTransportFailed {
		t.Fatalf("terminal result = %+v, %v; want definitive pre-commit relay", result, err)
	}
	if got := order.snapshot(); !reflect.DeepEqual(got, []string{"listener", "session"}) {
		t.Fatalf("terminal order = %v, want [listener session]", got)
	}
	if packetConn.closeCalls.Load() != 0 {
		t.Fatal("definitive pre-commit Accept failure closed the exact packet")
	}
}

func TestAttemptResourcesTerminalDispositionAcceptedPublicationRaceFailsClosed(t *testing.T) {
	t.Parallel()

	operationErr := errors.New("Accept materialized with error")
	tests := []struct {
		name  string
		cause error
	}{
		{name: "R3 cancellation", cause: context.Canceled},
		{name: "R4 control read failure", cause: errors.New("commit read failed")},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			order := &terminalSequenceRecorder{}
			packetConn := &terminalTestPacketConn{order: order}
			stream := &terminalTestStream{order: order, packetConn: packetConn}
			listener := &terminalTestDefinitiveAcceptListener{order: order}
			session := &terminalTestSession{order: order}
			owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
			owner.registerSession(session)
			operation := &ownedAcceptOperation{
				cancel: func() {},
				ready:  make(chan struct{}),
				done:   make(chan transportAcceptResult, 1),
			}
			owner.mu.Lock()
			owner.listener = listener
			owner.stream = stream
			owner.accept = operation
			owner.acceptResult = transportAcceptResult{stream: stream, err: operationErr}
			owner.acceptResultSet = true
			owner.acceptState = attemptOperationComplete
			owner.transfer.MarkTransferred()
			owner.claim = packetClaimStreamOwned
			owner.mu.Unlock()

			type terminalOutcome struct {
				result UpgradeResult
				err    error
			}
			outcome := make(chan terminalOutcome, 1)
			go func() {
				result, err := owner.failClosed(test.cause, abortAfterOwnedResources)
				outcome <- terminalOutcome{result: result, err: err}
			}()
			waitForTerminalSeal(t, owner)

			owner.mu.Lock()
			if owner.terminalState != attemptTerminalStateAcceptStreamOwned {
				t.Fatalf("elected state = %v, want accepted stream", owner.terminalState)
			}
			owner.mu.Unlock()
			select {
			case <-outcome:
				t.Fatal("terminal disposition returned before complete Accept publication")
			default:
			}
			close(operation.ready)

			got := <-outcome
			if got.result != (UpgradeResult{}) || !errors.Is(got.err, ErrUpgradeTransportNotConverged) || !errors.Is(got.err, test.cause) || errors.Is(got.err, operationErr) {
				t.Fatalf("terminal result = %+v, %v; want sentinel and preserved request cause only", got.result, got.err)
			}
			if gotOrder := order.snapshot(); !reflect.DeepEqual(gotOrder, []string{"stream", "packet", "listener", "session", "control"}) {
				t.Fatalf("terminal order = %v, want Q2", gotOrder)
			}
			if stream.closeCalls.Load() != 1 || packetConn.closeCalls.Load() != 1 {
				t.Fatalf("disposal calls = stream %d, packet %d; want 1, 1", stream.closeCalls.Load(), packetConn.closeCalls.Load())
			}
		})
	}
}

func TestAttemptResourcesTerminalDispositionDirectSuccessWaitsForAcceptPublication(t *testing.T) {
	t.Parallel()

	order := &terminalSequenceRecorder{}
	packetConn := &terminalTestPacketConn{order: order}
	stream := &terminalTestStream{order: order, packetConn: packetConn}
	listener := &terminalTestDefinitiveAcceptListener{order: order}
	session := &terminalTestSession{order: order}
	owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
	owner.registerSession(session)
	operation := &ownedAcceptOperation{
		cancel: func() {},
		ready:  make(chan struct{}),
		done:   make(chan transportAcceptResult, 1),
	}
	owner.mu.Lock()
	owner.listener = listener
	owner.stream = stream
	owner.accept = operation
	owner.acceptResult = transportAcceptResult{stream: stream}
	owner.acceptResultSet = true
	owner.acceptState = attemptOperationComplete
	owner.transfer.MarkTransferred()
	owner.claim = packetClaimStreamOwned
	owner.mu.Unlock()

	type terminalOutcome struct {
		result UpgradeResult
		err    error
	}
	outcome := make(chan terminalOutcome, 1)
	go func() {
		result, err := owner.succeedDirect(CandidatePair{}, time.Millisecond, nil)
		outcome <- terminalOutcome{result: result, err: err}
	}()
	waitForTerminalSeal(t, owner)
	select {
	case <-outcome:
		t.Fatal("direct success returned before complete Accept publication")
	default:
	}
	close(operation.ready)

	got := <-outcome
	if got.err != nil || got.result.Stream == nil {
		t.Fatalf("direct success = %+v, %v; want live stream", got.result, got.err)
	}
	if stream.closeCalls.Load() != 0 || packetConn.closeCalls.Load() != 0 || listener.closeCalls.Load() != 0 {
		t.Fatal("direct-success election disposed the accepted path before transfer")
	}
	if err := got.result.Stream.Close(); err != nil {
		t.Fatalf("transferred stream Close = %v", err)
	}
	if stream.closeCalls.Load() != 1 || packetConn.closeCalls.Load() != 1 || listener.closeCalls.Load() != 1 {
		t.Fatalf("transferred disposal calls = stream %d, packet %d, listener %d; want all 1", stream.closeCalls.Load(), packetConn.closeCalls.Load(), listener.closeCalls.Load())
	}
}

func TestAttemptResourcesTerminalDispositionFreezesPendingDialPlan(t *testing.T) {
	t.Parallel()

	order := &terminalSequenceRecorder{}
	packetConn := &terminalTestPacketConn{order: order}
	stream := &terminalTestStream{order: order, packetConn: packetConn}
	session := &terminalTestSession{order: order}
	owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
	owner.registerSession(session)
	operation := &ownedDialOperation{
		cancel: func() {},
		ready:  make(chan struct{}),
		done:   make(chan transportStreamResult, 1),
	}
	owner.mu.Lock()
	owner.committed = true
	owner.transfer.MarkTransferred()
	owner.claim = packetClaimRawOwned
	owner.dial = operation
	owner.dialState = attemptOperationRunning
	owner.mu.Unlock()

	cause := errors.New("terminal request")
	outcome := make(chan error, 1)
	go func() {
		_, err := owner.failClosed(cause, abortAfterOwnedResources)
		outcome <- err
	}()
	waitForTerminalSeal(t, owner)

	owner.mu.Lock()
	operation.result = transportStreamResult{stream: stream}
	owner.stream = stream
	owner.recordTransportResultLocked(operation.result)
	owner.dialState = attemptOperationComplete
	elected := owner.terminalState
	owner.mu.Unlock()
	if elected != attemptTerminalStateDialPending {
		t.Fatalf("elected state = %v, want pending Dial", elected)
	}
	close(operation.ready)

	err := <-outcome
	if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, cause) {
		t.Fatalf("terminal error = %v, want sentinel and preserved cause", err)
	}
	if got := order.snapshot(); !reflect.DeepEqual(got, []string{"session", "stream", "packet", "control"}) {
		t.Fatalf("terminal order = %v, want frozen pending-Dial Q8", got)
	}
}

func TestAttemptResourcesTerminalSequenceListenResultMatrix(t *testing.T) {
	t.Parallel()

	terminalCause := errors.New("terminal request")
	operationErr := errors.New("Listen failed")
	tests := []struct {
		name         string
		definitive   bool
		withListener bool
		listenErr    error
		failClosed   bool
		cause        error
		wantOrder    []string
	}{
		{
			name:      "R1-LF pending failure settles relay",
			listenErr: operationErr,
			wantOrder: []string{"session"},
		},
		{
			name:         "R1-LS pending materialized settles relay",
			withListener: true,
			listenErr:    operationErr,
			wantOrder:    []string{"session", "listener"},
		},
		{
			name:         "R1-LS pending materialized nil error settles relay",
			withListener: true,
			wantOrder:    []string{"session", "listener"},
		},
		{
			name:       "R2-LF-B pending failure control error",
			listenErr:  operationErr,
			failClosed: true,
			wantOrder:  []string{"control", "session"},
		},
		{
			name:         "R2-LS-B pending materialized control error",
			withListener: true,
			listenErr:    operationErr,
			failClosed:   true,
			wantOrder:    []string{"control", "session", "listener"},
		},
		{
			name:         "R2-LS-B pending materialized nil error control error",
			withListener: true,
			failClosed:   true,
			wantOrder:    []string{"control", "session", "listener"},
		},
		{
			name:       "R2-LF-B pending failure caller cancel",
			listenErr:  operationErr,
			failClosed: true,
			cause:      context.Canceled,
			wantOrder:  []string{"control", "session"},
		},
		{
			name:         "R2-LS-B pending materialized caller cancel",
			withListener: true,
			listenErr:    operationErr,
			failClosed:   true,
			cause:        context.Canceled,
			wantOrder:    []string{"control", "session", "listener"},
		},
		{
			name:         "R1-LD definitive materialized settles relay",
			definitive:   true,
			withListener: true,
			listenErr:    operationErr,
			wantOrder:    []string{"session", "listener"},
		},
		{
			name:         "R1-LD definitive materialized nil error settles relay",
			definitive:   true,
			withListener: true,
			wantOrder:    []string{"session", "listener"},
		},
		{
			name:      "nil listener nil error normalizes to failure",
			listenErr: nil,
			wantOrder: []string{"session"},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			order := &terminalSequenceRecorder{}
			packetConn := &terminalTestPacketConn{order: order}
			var listener *terminalTestReturnedListener
			var listenResult TransportListener
			if test.withListener {
				listener = &terminalTestReturnedListener{order: order}
				listenResult = listener
			}
			session := &terminalTestSession{
				order:          order,
				listenListener: listenResult,
				listenErr:      test.listenErr,
				listenStarted:  make(chan struct{}),
				listenRelease:  make(chan struct{}),
			}
			owner := newAttemptResources(&terminalTestChannel{order: order}, packetConn)
			owner.registerSession(session)
			listenDone := owner.startListen(context.Background(), session, packetConn, nil, nil)
			<-session.listenStarted
			if test.definitive {
				session.listenClose.Do(func() {
					close(session.listenRelease)
				})
				<-listenDone
			}

			var (
				result UpgradeResult
				err    error
			)
			if test.failClosed {
				cause := test.cause
				if cause == nil {
					cause = terminalCause
				}
				result, err = owner.failClosed(cause, abortBeforeOwnedResources)
				if result != (UpgradeResult{}) || !errors.Is(err, cause) || errors.Is(err, operationErr) {
					t.Fatalf("terminal result = %+v, %v; want zero and bare terminal cause", result, err)
				}
			} else {
				result, err = owner.settleRelay(UpgradeFallbackTransportFailed)
				if err != nil || result.Path != UpgradePathRelay || result.FallbackReason != UpgradeFallbackTransportFailed {
					t.Fatalf("terminal result = %+v, %v; want transport-failed relay", result, err)
				}
			}
			if got := order.snapshot(); !reflect.DeepEqual(got, test.wantOrder) {
				t.Fatalf("terminal order = %v, want %v", got, test.wantOrder)
			}
			if got := packetConn.closeCalls.Load(); got != 0 {
				t.Fatalf("exact packet Close calls = %d, want 0", got)
			}
			if state := owner.snapshot().listen; state != attemptOperationJoined {
				t.Fatalf("Listen lifecycle = %v, want joined", state)
			}
			if listener != nil {
				if got := listener.closeCalls.Load(); got != 1 {
					t.Fatalf("returned listener Close calls = %d, want 1", got)
				}
			}
		})
	}
}

func TestAttemptResourcesTerminalResultSucceedDirect(t *testing.T) {
	t.Parallel()

	pair := CandidatePair{
		Local:  Candidate{Addr: netip.MustParseAddrPort("192.0.2.1:1000")},
		Remote: Candidate{Addr: netip.MustParseAddrPort("192.0.2.2:2000")},
	}
	tests := []struct {
		name     string
		listener bool
	}{
		{name: "R15 dialer"},
		{name: "R16 listener", listener: true},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			order := &terminalSequenceRecorder{}
			packetConn := &terminalTestPacketConn{order: order}
			stream := &terminalTestStream{order: order, packetConn: packetConn}
			var wantCloseErr error
			channel := &terminalTestChannel{order: order}
			session := &terminalTestSession{order: order, dialStream: stream}
			owner := newAttemptResources(channel, packetConn)
			owner.registerSession(session)
			owner.registerCommit()

			var listener *terminalTestDefinitiveAcceptListener
			if test.listener {
				wantCloseErr = errors.New("stream close failed")
				stream.closeErr = wantCloseErr
				stream.readPayload = []byte("listener read")
				listener = &terminalTestDefinitiveAcceptListener{
					order:    order,
					stream:   stream,
					closeErr: errors.New("listener close failed"),
				}
				_, acceptDone := owner.startAccept(context.Background(), listener)
				<-acceptDone
			} else {
				<-owner.startDial(context.Background(), session, packetConn, nil, nil)
			}

			result, err := owner.succeedDirect(pair, 25*time.Millisecond, nil)
			if err != nil {
				t.Fatalf("succeedDirect error = %v, want nil", err)
			}
			if result.Stream == nil || result.Path != UpgradePathDirect || result.SelectedPair == nil || *result.SelectedPair != pair || result.ProbeRTT != 25*time.Millisecond {
				t.Fatalf("succeedDirect result = %+v, want direct result for exact pair and RTT", result)
			}
			if got := order.snapshot(); !reflect.DeepEqual(got, []string{"session", "relay-success"}) {
				t.Fatalf("terminal order before Wire close = %v, want [session relay-success]", got)
			}
			if got := packetConn.closeCalls.Load(); got != 0 {
				t.Fatalf("exact packet Close calls before Wire close = %d, want 0", got)
			}
			if listener != nil && listener.closeCalls.Load() != 0 {
				t.Fatal("listener closed before returned stream")
			}
			if snapshot := owner.snapshot(); snapshot.claim != packetClaimSuccessTransferred {
				t.Fatalf("terminal claim = %v, want success-transferred", snapshot.claim)
			}
			if test.listener {
				writePayload := []byte("listener write")
				if n, writeErr := result.Stream.Write(writePayload); writeErr != nil || n != len(writePayload) {
					t.Fatalf("returned stream Write = %d, %v; want %d, nil", n, writeErr, len(writePayload))
				}
				if got := stream.writtenSnapshot(); !reflect.DeepEqual(got, writePayload) {
					t.Fatalf("accepted stream write payload = %q, want %q", got, writePayload)
				}
				readBuffer := make([]byte, len(stream.readPayload))
				if n, readErr := result.Stream.Read(readBuffer); readErr != nil || n != len(stream.readPayload) {
					t.Fatalf("returned stream Read = %d, %v; want %d, nil", n, readErr, len(stream.readPayload))
				}
				if got := readBuffer; !reflect.DeepEqual(got, stream.readPayload) {
					t.Fatalf("accepted stream read payload = %q, want %q", got, stream.readPayload)
				}
			}

			if err := result.Stream.Close(); !errors.Is(err, wantCloseErr) {
				t.Fatalf("returned stream Close error = %v, want stream result %v", err, wantCloseErr)
			}
			wantOrder := []string{"session", "relay-success", "stream", "packet"}
			if test.listener {
				wantOrder = append(wantOrder, "listener")
			}
			if got := order.snapshot(); !reflect.DeepEqual(got, wantOrder) {
				t.Fatalf("terminal order after Wire close = %v, want %v", got, wantOrder)
			}
			if got := packetConn.closeCalls.Load(); got != 1 {
				t.Fatalf("exact packet Close calls after Wire close = %d, want 1", got)
			}
		})
	}
}

func TestAttemptResourcesTerminalResultSettleRelayPromotionMatrix(t *testing.T) {
	t.Parallel()

	operationErr := errors.New("operation failed")
	tests := []struct {
		name       string
		listener   bool
		definitive bool
		withStream bool
		resultErr  error
		wantOrder  []string
	}{
		{name: "R11-DF", resultErr: operationErr, wantOrder: []string{"session", "packet", "control"}},
		{name: "R11-DS", withStream: true, wantOrder: []string{"session", "stream", "packet", "control"}},
		{name: "R11-DM", withStream: true, resultErr: operationErr, wantOrder: []string{"session", "stream", "packet", "control"}},
		{name: "R11-DF definitive", definitive: true, resultErr: operationErr, wantOrder: []string{"session", "packet", "control"}},
		{name: "R11-DS definitive", definitive: true, withStream: true, wantOrder: []string{"stream", "packet", "session", "control"}},
		{name: "R11-DM definitive", definitive: true, withStream: true, resultErr: operationErr, wantOrder: []string{"stream", "packet", "session", "control"}},
		{name: "R11-LF", listener: true, resultErr: operationErr, wantOrder: []string{"listener", "session", "packet", "control"}},
		{name: "R11-LS", listener: true, withStream: true, wantOrder: []string{"listener", "session", "stream", "packet", "control"}},
		{name: "R11-LM", listener: true, definitive: true, withStream: true, resultErr: operationErr, wantOrder: []string{"listener", "session", "stream", "packet", "control"}},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			order := &terminalSequenceRecorder{}
			packetConn := &terminalTestPacketConn{order: order}
			var stream *terminalTestStream
			var resultStream io.ReadWriteCloser
			if test.withStream {
				stream = &terminalTestStream{order: order, packetConn: packetConn}
				resultStream = stream
			}
			channel := &terminalTestChannel{order: order}
			session := &terminalTestSession{order: order}
			owner := newAttemptResources(channel, packetConn)
			owner.registerSession(session)
			owner.registerCommit()
			if test.listener {
				listener := newTerminalTestAcceptListener(order, resultStream, test.resultErr)
				_, acceptDone := owner.startAccept(context.Background(), listener)
				<-listener.acceptStarted
				if test.definitive {
					listener.releaseOnce.Do(func() {
						close(listener.releaseAccept)
					})
					<-acceptDone
				}
			} else {
				session.dialStream = resultStream
				session.dialErr = test.resultErr
				session.dialStarted = make(chan struct{})
				session.dialRelease = make(chan struct{})
				dialDone := owner.startDial(context.Background(), session, packetConn, nil, nil)
				<-session.dialStarted
				if test.definitive {
					session.dialClose.Do(func() {
						close(session.dialRelease)
					})
					<-dialDone
				}
			}

			result, err := owner.settleRelay(UpgradeFallbackTransportFailed)
			if result != (UpgradeResult{}) || !errors.Is(err, ErrUpgradeTransportNotConverged) || errors.Is(err, operationErr) {
				t.Fatalf("promoted relay result = %+v, %v; want zero and transport-not-converged only", result, err)
			}
			if got := order.snapshot(); !reflect.DeepEqual(got, test.wantOrder) {
				t.Fatalf("terminal order = %v, want %v", got, test.wantOrder)
			}
			if got := packetConn.closeCalls.Load(); got != 1 {
				t.Fatalf("exact packet Close calls = %d, want 1", got)
			}
		})
	}
}

func TestAttemptResourcesTerminalResultR17TransferredFact(t *testing.T) {
	t.Parallel()

	relayOwner := newAttemptResources(&terminalTestChannel{}, &terminalTestPacketConn{})
	relayOwner.registerSession(&terminalTestSession{})
	if _, err := relayOwner.settleRelay(UpgradeFallbackTransportFailed); err != nil {
		t.Fatalf("relay settlement error = %v", err)
	}
	if relayOwner.packetOwnershipTransferred() {
		t.Fatal("relay settlement reported transferred packet ownership")
	}

	packetConn := &terminalTestPacketConn{}
	stream := &terminalTestStream{packetConn: packetConn}
	session := &terminalTestSession{dialStream: stream}
	transferredOwner := newAttemptResources(&terminalTestChannel{}, packetConn)
	transferredOwner.registerSession(session)
	<-transferredOwner.startDial(context.Background(), session, packetConn, nil, nil)
	if _, err := transferredOwner.failClosed(errors.New("terminal"), abortAfterOwnedResources); !errors.Is(err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("transferred settlement error = %v, want transport-not-converged", err)
	}
	if !transferredOwner.packetOwnershipTransferred() {
		t.Fatal("materialized fail-closed settlement did not report transferred packet ownership")
	}
}

func TestAttemptResourcesTerminalDispositionRejectsAbsentLegalityPairs(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name   string
		setup  func(*attemptResources)
		invoke func(*attemptResources) (UpgradeResult, error)
	}{
		{
			name: "pre-operation abort-after",
			invoke: func(owner *attemptResources) (UpgradeResult, error) {
				return owner.failClosed(errors.New("invalid"), abortAfterOwnedResources)
			},
		},
		{
			name: "missing relay reason",
			invoke: func(owner *attemptResources) (UpgradeResult, error) {
				return owner.settleRelay(UpgradeFallbackNone)
			},
		},
		{
			name: "Listen retain",
			setup: func(owner *attemptResources) {
				owner.listenState = attemptOperationRunning
			},
			invoke: func(owner *attemptResources) (UpgradeResult, error) {
				return owner.failClosed(errors.New("invalid"), retainForOuterSettlement)
			},
		},
		{
			name: "Accept abort-before",
			setup: func(owner *attemptResources) {
				owner.acceptState = attemptOperationRunning
			},
			invoke: func(owner *attemptResources) (UpgradeResult, error) {
				return owner.failClosed(errors.New("invalid"), abortBeforeOwnedResources)
			},
		},
		{
			name: "Dial retain",
			setup: func(owner *attemptResources) {
				owner.transfer.MarkTransferred()
				owner.claim = packetClaimRawOwned
				owner.dialState = attemptOperationRunning
			},
			invoke: func(owner *attemptResources) (UpgradeResult, error) {
				return owner.failClosed(errors.New("invalid"), retainForOuterSettlement)
			},
		},
		{
			name: "raw-owned success",
			setup: func(owner *attemptResources) {
				owner.transfer.MarkTransferred()
				owner.claim = packetClaimRawOwned
				owner.dialState = attemptOperationComplete
				owner.dial = &ownedDialOperation{}
			},
			invoke: func(owner *attemptResources) (UpgradeResult, error) {
				return owner.succeedDirect(CandidatePair{}, 0, nil)
			},
		},
		{
			name: "transferred without operation",
			setup: func(owner *attemptResources) {
				owner.committed = true
				owner.transfer.MarkTransferred()
				owner.claim = packetClaimRawOwned
			},
			invoke: func(owner *attemptResources) (UpgradeResult, error) {
				return owner.failClosed(errors.New("invalid"), abortAfterOwnedResources)
			},
		},
		{
			name: "stream-error success",
			setup: func(owner *attemptResources) {
				stream := &terminalTestStream{}
				owner.transfer.MarkTransferred()
				owner.claim = packetClaimStreamOwned
				owner.stream = stream
				owner.dialState = attemptOperationComplete
				owner.dial = &ownedDialOperation{
					result: transportStreamResult{
						stream: stream,
						err:    errors.New("Dial materialized with error"),
					},
				}
			},
			invoke: func(owner *attemptResources) (UpgradeResult, error) {
				return owner.succeedDirect(CandidatePair{}, 0, nil)
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			channel := &terminalTestChannel{}
			packetConn := &terminalTestPacketConn{}
			session := &terminalTestSession{}
			owner := newAttemptResources(channel, packetConn)
			owner.registerSession(session)
			if test.setup != nil {
				owner.mu.Lock()
				test.setup(owner)
				owner.mu.Unlock()
			}

			result, err := test.invoke(owner)
			if result != (UpgradeResult{}) || !errors.Is(err, errInvalidAttemptTerminalDisposition) {
				t.Fatalf("absent legality pair result = %+v, %v; want zero and invalid-disposition error", result, err)
			}
			if session.closeCalls.Load() != 0 || channel.closeCalls.Load() != 0 || packetConn.closeCalls.Load() != 0 {
				t.Fatal("absent legality pair performed cleanup")
			}
			owner.mu.Lock()
			sealed := owner.terminalSealed
			owner.mu.Unlock()
			if sealed {
				t.Fatal("absent legality pair consumed the first-wins terminal seal")
			}
		})
	}
}

func TestAttemptResourcesFailClosedNormalizesMissingCause(t *testing.T) {
	t.Parallel()

	channel := &terminalTestChannel{}
	session := &terminalTestSession{}
	owner := newAttemptResources(channel, &terminalTestPacketConn{})
	owner.registerSession(session)

	result, err := owner.failClosed(nil, abortBeforeOwnedResources)
	if result != (UpgradeResult{}) || !errors.Is(err, ErrUpgradeTransportNotConverged) {
		t.Fatalf("missing-cause fail-closed result = %+v, %v; want zero and transport-not-converged", result, err)
	}
	if channel.closeCalls.Load() != 1 || session.closeCalls.Load() != 1 {
		t.Fatal("missing-cause fail-closed did not execute the pre-operation terminal recipe")
	}
}

func TestAttemptResourcesTerminalDispositionSealsPublication(t *testing.T) {
	t.Parallel()

	session := &terminalTestSession{}
	owner := newAttemptResources(&terminalTestChannel{}, &terminalTestPacketConn{})
	owner.registerSession(session)
	first, err := owner.settleRelay(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("settleRelay error = %v", err)
	}

	owner.registerCommit()
	lateSession := &terminalTestSession{}
	owner.registerSession(lateSession)
	second, secondErr := owner.failClosed(errors.New("late"), abortAfterOwnedResources)
	if secondErr != nil || second != first {
		t.Fatalf("post-seal result = %+v, %v; want first relay result %+v", second, secondErr, first)
	}
	snapshot := owner.snapshot()
	if snapshot.transferred || snapshot.committed {
		t.Fatalf("post-seal ownership = transferred %t, committed %t; want both false", snapshot.transferred, snapshot.committed)
	}
	if session.closeCalls.Load() != 1 || lateSession.closeCalls.Load() != 0 {
		t.Fatalf("Session.Close calls = first %d, late %d; want 1, 0", session.closeCalls.Load(), lateSession.closeCalls.Load())
	}
}

func waitForTerminalSeal(t *testing.T, owner *attemptResources) {
	t.Helper()
	deadline := time.NewTimer(time.Second)
	defer deadline.Stop()
	for {
		owner.mu.Lock()
		sealed := owner.terminalSealed
		owner.mu.Unlock()
		if sealed {
			return
		}
		select {
		case <-deadline.C:
			t.Fatal("terminal disposition did not seal")
		default:
			runtime.Gosched()
		}
	}
}

type terminalSequenceRecorder struct {
	mu     sync.Mutex
	events []string
}

func (r *terminalSequenceRecorder) add(event string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.events = append(r.events, event)
}

func (r *terminalSequenceRecorder) snapshot() []string {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]string(nil), r.events...)
}

type terminalTestChannel struct {
	closeCalls   atomic.Int32
	successCalls atomic.Int32
	order        *terminalSequenceRecorder
}

func (*terminalTestChannel) Read([]byte) (int, error) {
	return 0, io.EOF
}

func (*terminalTestChannel) Write(p []byte) (int, error) {
	return len(p), nil
}

func (c *terminalTestChannel) Close() error {
	c.closeCalls.Add(1)
	if c.order != nil {
		c.order.add("control")
	}
	return nil
}

func (c *terminalTestChannel) CloseAfterDirectUpgradeSuccess() error {
	c.successCalls.Add(1)
	if c.order != nil {
		c.order.add("relay-success")
	}
	return nil
}

type terminalTestSession struct {
	closeCalls  atomic.Int32
	order       *terminalSequenceRecorder
	dialStream  io.ReadWriteCloser
	dialErr     error
	dialStarted chan struct{}
	dialRelease chan struct{}
	dialClose   sync.Once

	listenListener TransportListener
	listenErr      error
	listenStarted  chan struct{}
	listenRelease  chan struct{}
	listenClose    sync.Once
}

func (*terminalTestSession) HandshakeMaterial() []byte {
	return nil
}

func (s *terminalTestSession) Dial(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
	if s.dialStarted != nil {
		close(s.dialStarted)
		<-s.dialRelease
	}
	return s.dialStream, s.dialErr
}

func (s *terminalTestSession) Listen(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
	if s.listenStarted != nil {
		close(s.listenStarted)
		<-s.listenRelease
	}
	return s.listenListener, s.listenErr
}

func (s *terminalTestSession) Close() error {
	s.closeCalls.Add(1)
	if s.order != nil {
		s.order.add("session")
	}
	if s.dialRelease != nil {
		s.dialClose.Do(func() {
			close(s.dialRelease)
		})
	}
	if s.listenRelease != nil {
		s.listenClose.Do(func() {
			close(s.listenRelease)
		})
	}
	return nil
}

type terminalTestPacketConn struct {
	discardTestPacketConn
	closeCalls atomic.Int32
	order      *terminalSequenceRecorder
}

func (c *terminalTestPacketConn) Close() error {
	c.closeCalls.Add(1)
	if c.order != nil {
		c.order.add("packet")
	}
	return nil
}

type terminalTestStream struct {
	closeCalls  atomic.Int32
	order       *terminalSequenceRecorder
	packetConn  net.PacketConn
	closeErr    error
	readPayload []byte
	writeMu     sync.Mutex
	written     []byte
}

func (s *terminalTestStream) Read(p []byte) (int, error) {
	if len(s.readPayload) == 0 {
		return 0, io.EOF
	}
	return copy(p, s.readPayload), nil
}

func (s *terminalTestStream) Write(p []byte) (int, error) {
	s.writeMu.Lock()
	s.written = append(s.written, p...)
	s.writeMu.Unlock()
	return len(p), nil
}

func (s *terminalTestStream) writtenSnapshot() []byte {
	s.writeMu.Lock()
	defer s.writeMu.Unlock()
	return append([]byte(nil), s.written...)
}

func (s *terminalTestStream) Close() error {
	s.closeCalls.Add(1)
	if s.order != nil {
		s.order.add("stream")
	}
	if s.packetConn != nil {
		_ = s.packetConn.Close()
	}
	return s.closeErr
}

type terminalTestAcceptListener struct {
	order         *terminalSequenceRecorder
	stream        io.ReadWriteCloser
	err           error
	acceptStarted chan struct{}
	releaseAccept chan struct{}
	acceptReturn  chan struct{}
	releaseOnce   sync.Once
	closeCalls    atomic.Int32
}

func newTerminalTestAcceptListener(
	order *terminalSequenceRecorder,
	stream io.ReadWriteCloser,
	err error,
) *terminalTestAcceptListener {
	return &terminalTestAcceptListener{
		order:         order,
		stream:        stream,
		err:           err,
		acceptStarted: make(chan struct{}),
		releaseAccept: make(chan struct{}),
		acceptReturn:  make(chan struct{}),
	}
}

func (l *terminalTestAcceptListener) Accept(context.Context) (io.ReadWriteCloser, error) {
	close(l.acceptStarted)
	<-l.releaseAccept
	close(l.acceptReturn)
	return l.stream, l.err
}

func (l *terminalTestAcceptListener) Close() error {
	l.closeCalls.Add(1)
	if l.order != nil {
		l.order.add("listener")
	}
	l.releaseOnce.Do(func() {
		close(l.releaseAccept)
	})
	<-l.acceptReturn
	return nil
}

type terminalTestReturnedListener struct {
	order      *terminalSequenceRecorder
	closeCalls atomic.Int32
}

func (*terminalTestReturnedListener) Accept(context.Context) (io.ReadWriteCloser, error) {
	panic("unexpected Accept")
}

func (l *terminalTestReturnedListener) Close() error {
	l.closeCalls.Add(1)
	if l.order != nil {
		l.order.add("listener")
	}
	return nil
}

type terminalTestDefinitiveAcceptListener struct {
	order      *terminalSequenceRecorder
	stream     io.ReadWriteCloser
	err        error
	closeErr   error
	closeCalls atomic.Int32
}

func (l *terminalTestDefinitiveAcceptListener) Accept(context.Context) (io.ReadWriteCloser, error) {
	return l.stream, l.err
}

func (l *terminalTestDefinitiveAcceptListener) Close() error {
	l.closeCalls.Add(1)
	if l.order != nil {
		l.order.add("listener")
	}
	return l.closeErr
}
