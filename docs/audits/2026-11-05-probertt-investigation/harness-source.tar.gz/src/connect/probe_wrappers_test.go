package connect

import "net/netip"

// The free-function wrappers below are a test-only convenience over the two
// Probe dialect descriptors. Production code consumes probeWireParams
// directly; the wrappers exist so the existing test corpus keeps its call
// form.

func deriveProbeKey(exporter KeyExporter, dialerNonce, listenerNonce []byte) ([]byte, error) {
	return v1ProbeWireParams().deriveKey(exporter, dialerNonce, listenerNonce)
}

func encodeProbeDatagram(
	probeKey []byte,
	messageType probeMessageType,
	direction probeDirection,
	probeID [probeIDBytes]byte,
	source Candidate,
	destination Candidate,
) ([]byte, error) {
	return v1ProbeWireParams().encodeDatagram(probeKey, messageType, direction, probeID, source, destination)
}

func acceptProbeDatagram(
	probeKey []byte,
	datagram []byte,
	wantMessageType probeMessageType,
	wantDirection probeDirection,
	source Candidate,
	destination Candidate,
	observedSource netip.AddrPort,
) (probeDatagram, bool) {
	return v1ProbeWireParams().acceptDatagram(probeKey, datagram, wantMessageType, wantDirection, source, destination, observedSource)
}

func decodeProbeDatagram(datagram []byte) (probeDatagram, bool) {
	return v1ProbeWireParams().decodeDatagram(datagram)
}

func probeCandidatePairToken(probeKey []byte, direction probeDirection, source, destination Candidate) ([]byte, error) {
	return v1ProbeWireParams().candidatePairToken(probeKey, direction, source, destination)
}

func encodeProbeCandidate(candidate Candidate) ([]byte, error) {
	return v1ProbeWireParams().encodeCandidate(candidate)
}

func deriveTurnRetryProbeKey(exporter KeyExporter, dialerNonce, listenerNonce []byte) ([]byte, error) {
	return turnRetryProbeWireParams().deriveKey(exporter, dialerNonce, listenerNonce)
}

func encodeTurnRetryProbeDatagram(
	probeKey []byte,
	messageType probeMessageType,
	direction probeDirection,
	probeID [probeIDBytes]byte,
	source Candidate,
	destination Candidate,
) ([]byte, error) {
	return turnRetryProbeWireParams().encodeDatagram(probeKey, messageType, direction, probeID, source, destination)
}

func acceptTurnRetryProbeDatagram(
	probeKey []byte,
	datagram []byte,
	wantMessageType probeMessageType,
	wantDirection probeDirection,
	source Candidate,
	destination Candidate,
	observedSource netip.AddrPort,
) (probeDatagram, bool) {
	return turnRetryProbeWireParams().acceptDatagram(probeKey, datagram, wantMessageType, wantDirection, source, destination, observedSource)
}

func decodeTurnRetryProbeDatagram(datagram []byte) (probeDatagram, bool) {
	return turnRetryProbeWireParams().decodeDatagram(datagram)
}
