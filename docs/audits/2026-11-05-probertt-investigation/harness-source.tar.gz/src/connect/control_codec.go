package connect

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"net/netip"
	"time"

	"github.com/fxamacker/cbor/v2"
)

var errUnsupportedCandidateKind = errors.New("connect: unsupported upgrade candidate kind")

const (
	upgradeControlPhaseReady     upgradeControlPhase = upgradeControlPhase(upgradeControlMessageReady)
	upgradeControlPhaseCommit    upgradeControlPhase = upgradeControlPhase(upgradeControlMessageCommit)
	upgradeControlPhaseAccepted  upgradeControlPhase = upgradeControlPhase(upgradeControlMessageAccepted)
	upgradeControlPhaseConverged upgradeControlPhase = upgradeControlPhase(upgradeControlMessageConverged)
	upgradeControlPhaseConfirmed upgradeControlPhase = upgradeControlPhase(upgradeControlMessageConfirmed)
)

type upgradeControlPhase uint64

type upgradeControlFallback struct {
	Reason UpgradeFallbackReason
}

type upgradeControlFirstPhase struct {
	FallbackReason UpgradeFallbackReason
	HasFallback    bool
	Offer          localUpgradeOffer
	HasOffer       bool
}

type upgradeControlSelectedPairPhase struct {
	FallbackReason  UpgradeFallbackReason
	HasFallback     bool
	WireFallback    bool
	SelectedPair    selectedPair
	HasSelectedPair bool
}

type upgradeControlPhaseResult struct {
	Phase          upgradeControlPhase
	FallbackReason UpgradeFallbackReason
	HasFallback    bool
	WireFallback   bool
	Datagrams      bool
}

func (m upgradeControlPhaseResult) Is(phase upgradeControlPhase) bool {
	return m.Phase == phase
}

func encodeUpgradeControlPhase(phase upgradeControlPhase) ([]byte, error) {
	switch phase {
	case upgradeControlPhaseReady:
		return encodeUpgradeControlReadyFrame()
	case upgradeControlPhaseCommit:
		return encodeUpgradeControlCommitFrame()
	case upgradeControlPhaseAccepted:
		return encodeUpgradeControlAcceptedFrame()
	case upgradeControlPhaseConverged:
		return encodeUpgradeControlConvergedFrame()
	case upgradeControlPhaseConfirmed:
		return encodeUpgradeControlConfirmedFrame()
	default:
		return nil, fmt.Errorf("connect: unsupported direct-upgrade control phase %d", phase)
	}
}

func encodeUpgradeControlPostCommitPhase(phase upgradeControlPhase, datagrams bool) ([]byte, error) {
	switch phase {
	case upgradeControlPhaseAccepted, upgradeControlPhaseConverged, upgradeControlPhaseConfirmed:
		return encodeUpgradeControlPostCommitMessage(phase, datagrams)
	default:
		return nil, fmt.Errorf("%w: %d", errUnexpectedPostCommitPhaseOrder, phase)
	}
}

const (
	upgradeControlVersion = uint64(1)

	upgradeControlMessageOffer        = uint64(1)
	upgradeControlMessageFallback     = uint64(2)
	upgradeControlMessageSelectedPair = uint64(3)
	upgradeControlMessageReady        = uint64(4)
	upgradeControlMessageCommit       = uint64(5)
	upgradeControlMessageAccepted     = uint64(6)
	upgradeControlMessageConverged    = uint64(7)
	upgradeControlMessageConfirmed    = uint64(8)

	upgradeControlKeyType              = uint64(0)
	upgradeControlKeyVersion           = uint64(1)
	upgradeControlKeyExtensions        = uint64(2)
	upgradeControlKeyTransportName     = uint64(10)
	upgradeControlKeyHandshake         = uint64(11)
	upgradeControlKeyProbeNonce        = uint64(12)
	upgradeControlKeyCandidates        = uint64(13)
	upgradeControlKeyFallbackReason    = uint64(20)
	upgradeControlKeyDialerCandidate   = uint64(30)
	upgradeControlKeyListenerCandidate = uint64(31)
	upgradeControlKeyProbeRTTNanos     = uint64(32)

	upgradeControlCandidateKeyKind     = uint64(0)
	upgradeControlCandidateKeyAddrPort = uint64(1)

	upgradeControlCandidateKindHostCode      = uint64(1)
	upgradeControlCandidateKindReflexiveCode = uint64(2)

	candidateAddrFamilyIPv4    = byte(0x04)
	candidateAddrFamilyIPv6    = byte(0x06)
	candidateAddrPortIPv4Bytes = 1 + net.IPv4len + 2
	candidateAddrPortIPv6Bytes = 1 + net.IPv6len + 2

	maxPayload                          = 64 * 1024
	maxMapPairs                         = 16
	maxArrayElements                    = 64
	upgradeControlMaxStringBytes        = 4 * 1024
	maxExtensionMapBytes                = 4 * 1024
	maxExtensionValueNest               = 8
	maxPayloadNest                      = 10
	upgradeControlMaxTransportNameBytes = 64
	upgradeControlProbeNonceBytes       = 32
	upgradeControlMaxCandidates         = 64
	upgradeControlMaxProbeRTTNanos      = uint64(9223372036854775807)
)

const upgradeControlDatagramExtension = "wiremux.datagram/1"

// upgradeControlTURNRetryExtension is registered with canonical boolean value
// true only in the upgrade-control v1 Offer extension map. Its presence in any
// other v1 message is protocol_mismatch.
const upgradeControlTURNRetryExtension = "wiremux.turn-retry/1"

var (
	errUpgradeControlFrameEmpty     = errors.New("connect: upgrade-control frame is empty")
	errUpgradeControlFrameOversize  = errors.New("connect: upgrade-control frame is too large")
	errUpgradeControlFrameTruncated = errors.New("connect: upgrade-control frame is truncated")

	encMode = mustEncMode()
	decMode = mustDecMode()
)

func mustEncMode() cbor.EncMode {
	mode, err := cbor.CoreDetEncOptions().EncMode()
	if err != nil {
		panic("connect: invalid upgrade-control CBOR encode options: " + err.Error())
	}
	return mode
}

func mustDecMode() cbor.DecMode {
	mode, err := cbor.DecOptions{
		DupMapKey:        cbor.DupMapKeyEnforcedAPF,
		IndefLength:      cbor.IndefLengthForbidden,
		TagsMd:           cbor.TagsForbidden,
		IntDec:           cbor.IntDecConvertNone,
		MaxNestedLevels:  maxPayloadNest,
		MaxMapPairs:      maxMapPairs,
		MaxArrayElements: maxArrayElements,
	}.DecMode()
	if err != nil {
		panic("connect: invalid upgrade-control CBOR decode options: " + err.Error())
	}
	return mode
}

func encodeUpgradeControlFallback(reason UpgradeFallbackReason) ([]byte, error) {
	wire, err := fallbackReasonToWire(reason)
	if err != nil {
		return nil, err
	}

	payload, err := encMode.Marshal(map[uint64]uint64{
		upgradeControlKeyType:           upgradeControlMessageFallback,
		upgradeControlKeyVersion:        upgradeControlVersion,
		upgradeControlKeyFallbackReason: wire,
	})
	if err != nil {
		return nil, err
	}
	return encodeFramePayload(payload)
}

func encodeUpgradeControlOffer(offer localUpgradeOffer) ([]byte, error) {
	if err := validateUpgradeControlOffer(offer); err != nil {
		return nil, err
	}
	candidates, err := encodeCandidates(offer.candidates)
	if err != nil {
		return nil, err
	}
	handshakeMaterial := append([]byte{}, offer.handshakeMaterial...)
	message := map[uint64]any{
		upgradeControlKeyType:          upgradeControlMessageOffer,
		upgradeControlKeyVersion:       upgradeControlVersion,
		upgradeControlKeyTransportName: offer.transportName,
		upgradeControlKeyHandshake:     handshakeMaterial,
		upgradeControlKeyProbeNonce:    offer.probeNonce,
		upgradeControlKeyCandidates:    candidates,
	}
	if offer.turnRetry {
		message[upgradeControlKeyExtensions] = map[string]bool{
			upgradeControlTURNRetryExtension: true,
		}
	}
	payload, err := encMode.Marshal(message)
	if err != nil {
		return nil, err
	}
	return encodeFramePayload(payload)
}

func encodeFramePayload(payload []byte) ([]byte, error) {
	if len(payload) == 0 {
		return nil, errUpgradeControlFrameEmpty
	}
	if len(payload) > maxPayload {
		return nil, errUpgradeControlFrameOversize
	}
	frame := make([]byte, 4+len(payload))
	putUint32Length(frame[:4], len(payload))
	copy(frame[4:], payload)
	return frame, nil
}

func encodeUpgradeControlSelectedPair(selected selectedPair) ([]byte, error) {
	if err := validateUpgradeControlSelectedPair(selected); err != nil {
		return nil, err
	}
	dialerCandidate, err := encodeCandidate(selected.dialer)
	if err != nil {
		return nil, err
	}
	listenerCandidate, err := encodeCandidate(selected.listener)
	if err != nil {
		return nil, err
	}
	fields := map[uint64]any{
		upgradeControlKeyType:              upgradeControlMessageSelectedPair,
		upgradeControlKeyVersion:           upgradeControlVersion,
		upgradeControlKeyDialerCandidate:   dialerCandidate,
		upgradeControlKeyListenerCandidate: listenerCandidate,
	}
	if selected.rtt > 0 {
		fields[upgradeControlKeyProbeRTTNanos] = positiveDurationNanos(selected.rtt)
	}
	payload, err := encMode.Marshal(fields)
	if err != nil {
		return nil, err
	}
	return encodeFramePayload(payload)
}

func validateUpgradeControlSelectedPair(selected selectedPair) error {
	if _, ok := kindToWire(selected.dialer.Kind); !ok {
		return fmt.Errorf("connect: unsupported dialer candidate kind: %w: %q", errUnsupportedCandidateKind, selected.dialer.Kind)
	}
	if _, ok := encodeCandidateAddrPort(selected.dialer.Addr); !ok {
		return fmt.Errorf("connect: invalid dialer candidate address %s", selected.dialer.Addr)
	}
	if _, ok := kindToWire(selected.listener.Kind); !ok {
		return fmt.Errorf("connect: unsupported listener candidate kind: %w: %q", errUnsupportedCandidateKind, selected.listener.Kind)
	}
	if _, ok := encodeCandidateAddrPort(selected.listener.Addr); !ok {
		return fmt.Errorf("connect: invalid listener candidate address %s", selected.listener.Addr)
	}
	if selected.rtt < 0 {
		return fmt.Errorf("connect: selected pair probe RTT must not be negative")
	}
	if selected.rtt > 0 && positiveDurationNanos(selected.rtt) > upgradeControlMaxProbeRTTNanos {
		return fmt.Errorf("connect: selected pair probe RTT is out of range")
	}
	return nil
}

func positiveDurationNanos(duration time.Duration) uint64 {
	return uint64(duration.Nanoseconds()) // #nosec G115 -- callers reject negative durations before conversion.
}

func encodeUpgradeControlReadyFrame() ([]byte, error) {
	return encodeEmptyControlMessage(upgradeControlMessageReady)
}

func encodeUpgradeControlCommitFrame() ([]byte, error) {
	return encodeEmptyControlMessage(upgradeControlMessageCommit)
}

func encodeUpgradeControlAcceptedFrame() ([]byte, error) {
	return encodeEmptyControlMessage(upgradeControlMessageAccepted)
}

func encodeUpgradeControlConvergedFrame() ([]byte, error) {
	return encodeEmptyControlMessage(upgradeControlMessageConverged)
}

func encodeUpgradeControlConfirmedFrame() ([]byte, error) {
	return encodeEmptyControlMessage(upgradeControlMessageConfirmed)
}

func encodeUpgradeControlPostCommitMessage(phase upgradeControlPhase, datagrams bool) ([]byte, error) {
	message := map[uint64]any{
		upgradeControlKeyType:    uint64(phase),
		upgradeControlKeyVersion: upgradeControlVersion,
	}
	if datagrams {
		message[upgradeControlKeyExtensions] = map[string]bool{upgradeControlDatagramExtension: true}
	}
	payload, err := encMode.Marshal(message)
	if err != nil {
		return nil, err
	}
	return encodeFramePayload(payload)
}

func encodeEmptyControlMessage(messageType uint64) ([]byte, error) {
	payload, err := encMode.Marshal(map[uint64]uint64{
		upgradeControlKeyType:    messageType,
		upgradeControlKeyVersion: upgradeControlVersion,
	})
	if err != nil {
		return nil, err
	}
	return encodeFramePayload(payload)
}

func validateUpgradeControlOffer(offer localUpgradeOffer) error {
	if !validTransportName(offer.transportName) {
		return fmt.Errorf("connect: invalid upgrade transport name")
	}
	if len(offer.handshakeMaterial) > upgradeControlMaxStringBytes {
		return fmt.Errorf("connect: upgrade handshake material exceeds %d bytes", upgradeControlMaxStringBytes)
	}
	if len(offer.probeNonce) != upgradeControlProbeNonceBytes {
		return fmt.Errorf("connect: upgrade probe nonce must be %d bytes", upgradeControlProbeNonceBytes)
	}
	if len(offer.candidates) == 0 || len(offer.candidates) > upgradeControlMaxCandidates {
		return fmt.Errorf("connect: offer must contain 1 to %d candidates", upgradeControlMaxCandidates)
	}
	for _, candidate := range offer.candidates {
		if _, ok := kindToWire(candidate.Kind); !ok {
			return fmt.Errorf("connect: unsupported upgrade candidate kind: %w: %q", errUnsupportedCandidateKind, candidate.Kind)
		}
		if _, ok := encodeCandidateAddrPort(candidate.Addr); !ok {
			return fmt.Errorf("connect: invalid upgrade candidate address %s", candidate.Addr)
		}
	}
	return nil
}

func validTransportName(name string) bool {
	if len(name) == 0 || len(name) > upgradeControlMaxTransportNameBytes {
		return false
	}
	for i := range len(name) {
		if name[i] < 0x20 || name[i] > 0x7e {
			return false
		}
	}
	return true
}

func encodeCandidates(candidates []Candidate) ([]map[uint64]any, error) {
	if len(candidates) == 0 || len(candidates) > upgradeControlMaxCandidates {
		return nil, fmt.Errorf("connect: offer must contain 1 to %d candidates", upgradeControlMaxCandidates)
	}

	encoded := make([]map[uint64]any, 0, len(candidates))
	for _, candidate := range candidates {
		encodedCandidate, err := encodeCandidate(candidate)
		if err != nil {
			return nil, err
		}
		encoded = append(encoded, encodedCandidate)
	}
	return encoded, nil
}

func encodeCandidate(candidate Candidate) (map[uint64]any, error) {
	kind, ok := kindToWire(candidate.Kind)
	if !ok {
		return nil, fmt.Errorf("connect: unsupported upgrade candidate kind: %w: %q", errUnsupportedCandidateKind, candidate.Kind)
	}
	addrPort, ok := encodeCandidateAddrPort(candidate.Addr)
	if !ok {
		return nil, fmt.Errorf("connect: invalid upgrade candidate address %s", candidate.Addr)
	}
	return map[uint64]any{
		upgradeControlCandidateKeyKind:     kind,
		upgradeControlCandidateKeyAddrPort: addrPort,
	}, nil
}

func kindToWire(kind CandidateKind) (uint64, bool) {
	switch kind {
	case CandidateKindHost:
		return upgradeControlCandidateKindHostCode, true
	case CandidateKindReflexive:
		return upgradeControlCandidateKindReflexiveCode, true
	default:
		return 0, false
	}
}

func encodeCandidateAddrPort(addrPort netip.AddrPort) ([]byte, bool) {
	if !addrPort.IsValid() || addrPort.Port() == 0 {
		return nil, false
	}

	addr := addrPort.Addr().Unmap()
	if !addr.IsValid() || addr.IsUnspecified() || addr.IsMulticast() {
		return nil, false
	}
	port := addrPort.Port()
	if addr.Is4() {
		raw := addr.As4()
		encoded := make([]byte, candidateAddrPortIPv4Bytes)
		encoded[0] = candidateAddrFamilyIPv4
		copy(encoded[1:5], raw[:])
		binary.BigEndian.PutUint16(encoded[5:candidateAddrPortIPv4Bytes], port)
		return encoded, true
	}
	if addr.Is6() {
		raw := addr.As16()
		encoded := make([]byte, candidateAddrPortIPv6Bytes)
		encoded[0] = candidateAddrFamilyIPv6
		copy(encoded[1:17], raw[:])
		binary.BigEndian.PutUint16(encoded[17:candidateAddrPortIPv6Bytes], port)
		return encoded, true
	}
	return nil, false
}

func readUpgradeControlFrame(reader io.Reader) ([]byte, error) {
	frame, err := readUpgradeControlPayload(reader)
	if err != nil {
		return nil, classifyUpgradeControlFramingError(err)
	}
	return frame, nil
}

func classifyUpgradeControlFramingError(err error) error {
	if errors.Is(err, errUpgradeControlFrameOversize) || errors.Is(err, errUpgradeControlFrameTruncated) {
		return fmt.Errorf("%w: %w", ErrUpgradeControlFramingFailed, err)
	}
	return err
}

// decodeUpgradeControlFirstPhasePayload retains the legacy domain result and
// separately reports payload validity. Framing failures belong to read helpers.
func decodeUpgradeControlFirstPhasePayload(payload []byte) (upgradeControlFirstPhase, error) {
	offer, ok := decodeOffer(payload)
	if ok {
		return upgradeControlFirstPhase{
			Offer:    offer,
			HasOffer: true,
		}, nil
	}
	fallback, cause := decodeFallbackForPhase(payload, fallbackReasonPhaseFirst)
	return upgradeControlFirstPhase{
		FallbackReason: fallback.Reason,
		HasFallback:    true,
	}, cause
}

// decodeUpgradeControlSelectedPairPhasePayload retains the legacy domain result
// and separately reports payload validity. Framing failures belong to read helpers.
func decodeUpgradeControlSelectedPairPhasePayload(payload []byte) (upgradeControlSelectedPairPhase, error) {
	selected, ok := decodeSelectedPair(payload)
	if ok {
		return upgradeControlSelectedPairPhase{
			SelectedPair:    selected,
			HasSelectedPair: true,
		}, nil
	}
	fallback, cause := decodeFallbackForPhase(payload, fallbackReasonPhaseTerminal)
	return upgradeControlSelectedPairPhase{
		FallbackReason: fallback.Reason,
		HasFallback:    true,
		WireFallback:   payloadHasMessageType(payload, upgradeControlMessageFallback),
	}, cause
}

func decodeUpgradeControlPhasePayload(payload []byte, phase upgradeControlPhase) (upgradeControlPhaseResult, error) {
	allowDatagramExtension := phase == upgradeControlPhaseAccepted ||
		phase == upgradeControlPhaseConverged ||
		phase == upgradeControlPhaseConfirmed
	if datagrams, ok := decodeControlPhase(payload, uint64(phase), allowDatagramExtension); ok {
		return upgradeControlPhaseResult{Phase: phase, Datagrams: datagrams}, nil
	}
	fallback, cause := decodeFallbackForPhase(payload, fallbackReasonPhaseTerminal)
	return upgradeControlPhaseResult{
		FallbackReason: fallback.Reason,
		HasFallback:    true,
		WireFallback:   payloadHasMessageType(payload, upgradeControlMessageFallback),
	}, cause
}

func decodeControlPhase(payload []byte, wantMessageType uint64, allowDatagramExtension bool) (bool, bool) {
	if len(payload) == 0 {
		return false, false
	}
	fields, ok := decodeTopLevelMap(payload)
	if !ok {
		return false, false
	}
	fieldValues, messageType, ok := decodeCommonFields(fields)
	if !ok || messageType != wantMessageType {
		return false, false
	}
	if !keysAreAllowed(fieldValues, map[uint64]struct{}{
		upgradeControlKeyType:       {},
		upgradeControlKeyVersion:    {},
		upgradeControlKeyExtensions: {},
	}) {
		return false, false
	}
	extensions, present := fieldValues[upgradeControlKeyExtensions]
	if !present {
		return false, true
	}
	entries, end, err := scanCBORRawMapEntries(extensions, 0, cborScanOptionsDefault(), 0)
	if err != nil || end != len(extensions) {
		return false, false
	}
	// The registered turn-retry capability is valid only in the v1 Offer
	// extension map; any occurrence in another v1 message rejects. This scan
	// runs before the datagram scan so datagram acceptance cannot mask an
	// invalid turn-retry placement later in the same map.
	for _, entry := range entries {
		key, ok := decodeText(entry.keyRaw, maxExtensionMapBytes)
		if ok && key == upgradeControlTURNRetryExtension {
			return false, false
		}
	}
	for _, entry := range entries {
		key, ok := decodeText(entry.keyRaw, maxExtensionMapBytes)
		if !ok || key != upgradeControlDatagramExtension {
			continue
		}
		if !allowDatagramExtension {
			return false, false
		}
		if !bytes.Equal(entry.valueRaw, []byte{0xf5}) {
			return false, false
		}
		return true, true
	}
	return false, true
}

func decodeUpgradeControlFallbackPayload(payload []byte) (upgradeControlFallback, error) {
	return decodeFallbackForPhase(payload, fallbackReasonPhaseTerminal)
}

// decodeFallbackForPhase retains the legacy reason even when strict phase
// validation rejects it. Payload validity does not decide negotiation policy.
func decodeFallbackForPhase(payload []byte, phase fallbackReasonPhase) (upgradeControlFallback, error) {
	fallback, cause := decodeFallbackCause(payload)
	if cause != nil || !validFallbackReasonForPhase(fallback.Reason, phase) {
		return fallback, errMalformedUpgradeControl
	}
	return fallback, nil
}

func decodeFallbackCause(payload []byte) (upgradeControlFallback, error) {
	if len(payload) == 0 {
		return upgradeControlFallback{Reason: UpgradeFallbackProtocolMismatch}, errMalformedUpgradeControl
	}

	fields, ok := decodeTopLevelMap(payload)
	if !ok {
		return upgradeControlFallback{Reason: UpgradeFallbackProtocolMismatch}, errMalformedUpgradeControl
	}

	fieldValues, messageType, ok := decodeCommonFields(fields)
	if !ok || messageType != upgradeControlMessageFallback {
		return upgradeControlFallback{Reason: UpgradeFallbackProtocolMismatch}, errMalformedUpgradeControl
	}
	if !keysAreAllowed(fieldValues, map[uint64]struct{}{
		upgradeControlKeyType:           {},
		upgradeControlKeyVersion:        {},
		upgradeControlKeyExtensions:     {},
		upgradeControlKeyFallbackReason: {},
	}) {
		return upgradeControlFallback{Reason: UpgradeFallbackProtocolMismatch}, errMalformedUpgradeControl
	}
	if hasRegisteredDatagramExtension(fieldValues) {
		return upgradeControlFallback{Reason: UpgradeFallbackProtocolMismatch}, errMalformedUpgradeControl
	}
	if hasRegisteredTURNRetryExtension(fieldValues) {
		return upgradeControlFallback{Reason: UpgradeFallbackProtocolMismatch}, errMalformedUpgradeControl
	}

	reasonValue, ok := decodeUint(fieldValues[upgradeControlKeyFallbackReason])
	if !ok {
		return upgradeControlFallback{Reason: UpgradeFallbackProtocolMismatch}, errMalformedUpgradeControl
	}

	reason, ok := fallbackReasonFromWireValue(reasonValue)
	if !ok {
		return upgradeControlFallback{Reason: UpgradeFallbackProtocolMismatch}, errMalformedUpgradeControl
	}
	return upgradeControlFallback{Reason: reason}, nil
}

func decodeOffer(payload []byte) (localUpgradeOffer, bool) {
	if len(payload) == 0 {
		return localUpgradeOffer{}, false
	}

	fields, ok := decodeTopLevelMap(payload)
	if !ok {
		return localUpgradeOffer{}, false
	}

	fieldValues, messageType, ok := decodeCommonFields(fields)
	if !ok || messageType != upgradeControlMessageOffer {
		return localUpgradeOffer{}, false
	}
	if !keysAreAllowed(fieldValues, map[uint64]struct{}{
		upgradeControlKeyType:          {},
		upgradeControlKeyVersion:       {},
		upgradeControlKeyExtensions:    {},
		upgradeControlKeyTransportName: {},
		upgradeControlKeyHandshake:     {},
		upgradeControlKeyProbeNonce:    {},
		upgradeControlKeyCandidates:    {},
	}) {
		return localUpgradeOffer{}, false
	}
	if hasRegisteredDatagramExtension(fieldValues) {
		return localUpgradeOffer{}, false
	}
	turnRetry, turnRetryMalformed := registeredTURNRetryExtensionState(fieldValues)
	if turnRetryMalformed {
		return localUpgradeOffer{}, false
	}

	transportName, ok := decodeText(fieldValues[upgradeControlKeyTransportName], upgradeControlMaxTransportNameBytes)
	if !ok {
		return localUpgradeOffer{}, false
	}
	handshakeMaterial, ok := decodeBytes(fieldValues[upgradeControlKeyHandshake], upgradeControlMaxStringBytes)
	if !ok {
		return localUpgradeOffer{}, false
	}
	probeNonce, ok := decodeBytes(fieldValues[upgradeControlKeyProbeNonce], upgradeControlProbeNonceBytes)
	if !ok || len(probeNonce) != upgradeControlProbeNonceBytes {
		return localUpgradeOffer{}, false
	}
	candidates, ok := decodeCandidates(fieldValues[upgradeControlKeyCandidates])
	if !ok {
		return localUpgradeOffer{}, false
	}
	return localUpgradeOffer{
		transportName:     transportName,
		handshakeMaterial: append([]byte(nil), handshakeMaterial...),
		probeNonce:        append([]byte(nil), probeNonce...),
		candidates:        candidates,
		turnRetry:         turnRetry,
	}, true
}

func decodeSelectedPair(payload []byte) (selectedPair, bool) {
	if len(payload) == 0 {
		return selectedPair{}, false
	}

	fields, ok := decodeTopLevelMap(payload)
	if !ok {
		return selectedPair{}, false
	}

	fieldValues, messageType, ok := decodeCommonFields(fields)
	if !ok || messageType != upgradeControlMessageSelectedPair {
		return selectedPair{}, false
	}
	if !keysAreAllowed(fieldValues, map[uint64]struct{}{
		upgradeControlKeyType:              {},
		upgradeControlKeyVersion:           {},
		upgradeControlKeyExtensions:        {},
		upgradeControlKeyDialerCandidate:   {},
		upgradeControlKeyListenerCandidate: {},
		upgradeControlKeyProbeRTTNanos:     {},
	}) {
		return selectedPair{}, false
	}
	if hasRegisteredDatagramExtension(fieldValues) {
		return selectedPair{}, false
	}
	if hasRegisteredTURNRetryExtension(fieldValues) {
		return selectedPair{}, false
	}

	dialerCandidate, ok := decodeCandidate(fieldValues[upgradeControlKeyDialerCandidate])
	if !ok {
		return selectedPair{}, false
	}
	listenerCandidate, ok := decodeCandidate(fieldValues[upgradeControlKeyListenerCandidate])
	if !ok {
		return selectedPair{}, false
	}

	selected := selectedPair{
		dialer:   dialerCandidate,
		listener: listenerCandidate,
	}
	if probeRTTPayload, ok := fieldValues[upgradeControlKeyProbeRTTNanos]; ok {
		rtt, ok := decodeUint(probeRTTPayload)
		if !ok || rtt == 0 || rtt > upgradeControlMaxProbeRTTNanos {
			return selectedPair{}, false
		}
		selected.rtt = time.Duration(rtt)
	}
	return selected, true
}

func decodeCommonFields(fields []mapEntry) (map[uint64][]byte, uint64, bool) {
	fieldValues := make(map[uint64][]byte, len(fields))
	for _, field := range fields {
		if field.key == upgradeControlKeyExtensions && !extensionsAreValid(field.valueRaw) {
			return nil, 0, false
		}
		fieldValues[field.key] = field.valueRaw
	}

	messageType, ok := decodeUint(fieldValues[upgradeControlKeyType])
	if !ok {
		return nil, 0, false
	}
	version, ok := decodeUint(fieldValues[upgradeControlKeyVersion])
	if !ok || version != upgradeControlVersion {
		return nil, 0, false
	}
	return fieldValues, messageType, true
}

func hasRegisteredDatagramExtension(fieldValues map[uint64][]byte) bool {
	return hasRegisteredExtension(fieldValues, upgradeControlDatagramExtension)
}

func hasRegisteredTURNRetryExtension(fieldValues map[uint64][]byte) bool {
	return hasRegisteredExtension(fieldValues, upgradeControlTURNRetryExtension)
}

func hasRegisteredExtension(fieldValues map[uint64][]byte, name string) bool {
	extensions, present := fieldValues[upgradeControlKeyExtensions]
	if !present {
		return false
	}
	entries, end, err := scanCBORRawMapEntries(extensions, 0, cborScanOptionsDefault(), 0)
	if err != nil || end != len(extensions) {
		return false
	}
	for _, entry := range entries {
		key, ok := decodeText(entry.keyRaw, maxExtensionMapBytes)
		if ok && key == name {
			return true
		}
	}
	return false
}

// registeredTURNRetryExtensionState classifies the registered turn-retry
// capability inside a decoded v1 Offer extension map: absent, present with
// exactly one canonical true entry, or malformed (false, non-boolean,
// non-canonical, or duplicate registered rows). Unknown extension keys remain
// ignored by the v1 Offer contract.
func registeredTURNRetryExtensionState(fieldValues map[uint64][]byte) (present bool, malformed bool) {
	extensions, exists := fieldValues[upgradeControlKeyExtensions]
	if !exists {
		return false, false
	}
	entries, end, err := scanCBORRawMapEntries(extensions, 0, cborScanOptionsDefault(), 0)
	if err != nil || end != len(extensions) {
		return false, true
	}
	registered := 0
	for _, entry := range entries {
		key, ok := decodeText(entry.keyRaw, maxExtensionMapBytes)
		if !ok || key != upgradeControlTURNRetryExtension {
			continue
		}
		registered++
		if registered > 1 {
			return false, true
		}
		if !bytes.Equal(entry.valueRaw, []byte{0xf5}) {
			return false, true
		}
	}
	return registered == 1, false
}

func payloadHasMessageType(payload []byte, wantMessageType uint64) bool {
	fields, ok := decodeTopLevelMap(payload)
	if !ok {
		return false
	}
	_, messageType, ok := decodeCommonFields(fields)
	return ok && messageType == wantMessageType
}

func keysAreAllowed(fieldValues map[uint64][]byte, allowed map[uint64]struct{}) bool {
	for key := range fieldValues {
		if _, ok := allowed[key]; !ok {
			return false
		}
	}
	return true
}

func decodeTopLevelMap(payload []byte) ([]mapEntry, bool) {
	if err := decMode.Wellformed(payload); err != nil {
		return nil, false
	}
	entries, end, err := scanCBORMapEntries(payload, 0, cborScanOptionsDefault(), 0)
	if err != nil || end != len(payload) {
		return nil, false
	}
	return entries, true
}

func extensionsAreValid(payload []byte) bool {
	if len(payload) == 0 || len(payload) > maxExtensionMapBytes {
		return false
	}
	entries, end, err := scanCBORRawMapEntries(payload, 0, cborScanOptionsDefault(), 0)
	if err != nil || end != len(payload) || len(entries) > maxMapPairs {
		return false
	}
	for _, entry := range entries {
		if end, err := scanCBORItem(entry.keyRaw, 0, cborScanOptionsDefault(), 0); err != nil || end != len(entry.keyRaw) {
			return false
		}
		if end, err := scanCBORItem(entry.valueRaw, 0, extensionValueScanOptions(), 0); err != nil || end != len(entry.valueRaw) {
			return false
		}
	}
	return true
}

func decodeCandidates(payload []byte) ([]Candidate, bool) {
	items, end, err := scanCBORArrayItems(payload, 0, cborScanOptionsDefault(), 0)
	if err != nil || end != len(payload) || len(items) == 0 || len(items) > upgradeControlMaxCandidates {
		return nil, false
	}
	candidates := make([]Candidate, 0, len(items))
	for _, item := range items {
		candidate, ok := decodeCandidate(item)
		if !ok {
			return nil, false
		}
		candidates = append(candidates, candidate)
	}
	return candidates, true
}

func decodeCandidate(payload []byte) (Candidate, bool) {
	entries, end, err := scanCBORMapEntries(payload, 0, cborScanOptions{
		maxArrayElements: 0,
		maxMapPairs:      2,
		maxStringBytes:   upgradeControlMaxStringBytes,
		maxNest:          maxPayloadNest,
	}, 0)
	if err != nil || end != len(payload) {
		return Candidate{}, false
	}
	fieldValues := make(map[uint64][]byte, len(entries))
	for _, entry := range entries {
		fieldValues[entry.key] = entry.valueRaw
	}
	if len(fieldValues) != 2 {
		return Candidate{}, false
	}
	kindValue, ok := decodeUint(fieldValues[upgradeControlCandidateKeyKind])
	if !ok {
		return Candidate{}, false
	}
	kind, ok := kindFromWire(kindValue)
	if !ok {
		return Candidate{}, false
	}
	addrPort, ok := decodeBytes(fieldValues[upgradeControlCandidateKeyAddrPort], candidateAddrPortIPv6Bytes)
	if !ok {
		return Candidate{}, false
	}
	addr, ok := decodeCandidateAddrPort(addrPort)
	if !ok {
		return Candidate{}, false
	}
	return Candidate{Kind: kind, Addr: addr}, true
}

func kindFromWire(kind uint64) (CandidateKind, bool) {
	switch kind {
	case upgradeControlCandidateKindHostCode:
		return CandidateKindHost, true
	case upgradeControlCandidateKindReflexiveCode:
		return CandidateKindReflexive, true
	default:
		return CandidateKind(""), false
	}
}

func decodeCandidateAddrPort(data []byte) (netip.AddrPort, bool) {
	if len(data) != candidateAddrPortIPv4Bytes && len(data) != candidateAddrPortIPv6Bytes {
		return netip.AddrPort{}, false
	}

	var (
		addr netip.Addr
		port uint16
	)
	switch data[0] {
	case candidateAddrFamilyIPv4:
		if len(data) != candidateAddrPortIPv4Bytes {
			return netip.AddrPort{}, false
		}
		var raw [4]byte
		copy(raw[:], data[1:5])
		addr = netip.AddrFrom4(raw)
		port = binary.BigEndian.Uint16(data[5:candidateAddrPortIPv4Bytes])
	case candidateAddrFamilyIPv6:
		if len(data) != candidateAddrPortIPv6Bytes {
			return netip.AddrPort{}, false
		}
		var raw [16]byte
		copy(raw[:], data[1:17])
		addr = netip.AddrFrom16(raw)
		if addr.Unmap().Is4() {
			return netip.AddrPort{}, false
		}
		port = binary.BigEndian.Uint16(data[17:candidateAddrPortIPv6Bytes])
	default:
		return netip.AddrPort{}, false
	}

	addr = addr.Unmap()
	if !addr.IsValid() ||
		port == 0 ||
		addr.IsUnspecified() ||
		addr.IsMulticast() {
		return netip.AddrPort{}, false
	}
	return netip.AddrPortFrom(addr, port), true
}

func cborScanOptionsDefault() cborScanOptions {
	return cborScanOptions{
		maxArrayElements: maxArrayElements,
		maxMapPairs:      maxMapPairs,
		maxStringBytes:   upgradeControlMaxStringBytes,
		maxNest:          maxPayloadNest,
	}
}

func extensionValueScanOptions() cborScanOptions {
	return cborScanOptions{
		maxArrayElements: maxArrayElements,
		maxMapPairs:      maxMapPairs,
		maxStringBytes:   upgradeControlMaxStringBytes,
		maxNest:          maxExtensionValueNest,
	}
}

func readUpgradeControlPayload(reader io.Reader) ([]byte, error) {
	var prefix [4]byte
	if _, err := io.ReadFull(reader, prefix[:]); err != nil {
		return nil, normalizeReadError(err)
	}
	payloadLen := binary.BigEndian.Uint32(prefix[:])
	if payloadLen > maxPayload {
		return nil, errUpgradeControlFrameOversize
	}
	if payloadLen == 0 {
		return nil, nil
	}

	payload := make([]byte, payloadLen)
	if _, err := io.ReadFull(reader, payload); err != nil {
		return nil, normalizeReadError(err)
	}
	return payload, nil
}

func normalizeReadError(err error) error {
	if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
		return errUpgradeControlFrameTruncated
	}
	return err
}

func putUint32Length(dst []byte, n int) {
	binary.BigEndian.PutUint32(dst, uint32(n)) // #nosec G115 -- callers bound n to maxPayload before encoding the uint32 wire length.
}
