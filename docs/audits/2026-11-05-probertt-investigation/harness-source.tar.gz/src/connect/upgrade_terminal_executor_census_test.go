package connect

import (
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

var terminalCensusTargets = map[string]struct{}{
	"newAttemptResources":   {},
	"newOwnedTURNPathClaim": {},
	"registerSession":       {},
	"registerCommit":        {},
	"startDial":             {},
	"startListen":           {},
	"startAccept":           {},
	"settleRelay":           {},
	"failClosed":            {},
	"succeedDirect":         {},
}

func TestAttemptResourcesTerminalConsumerCensus(t *testing.T) {
	t.Parallel()

	entries, err := os.ReadDir(".")
	if err != nil {
		t.Fatalf("read connect package: %v", err)
	}
	files := token.NewFileSet()
	got := make(map[string]map[string]int, len(terminalCensusTargets))
	for target := range terminalCensusTargets {
		got[target] = map[string]int{}
	}
	var indirectReferences []string

	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".go") || strings.HasSuffix(entry.Name(), "_test.go") {
			continue
		}
		parsed, parseErr := parser.ParseFile(files, filepath.Clean(entry.Name()), nil, 0)
		if parseErr != nil {
			t.Fatalf("parse %s: %v", entry.Name(), parseErr)
		}
		for _, reference := range terminalCensusIndirectReferences(parsed) {
			indirectReferences = append(indirectReferences, entry.Name()+":"+reference)
		}
		for _, declaration := range parsed.Decls {
			function, ok := declaration.(*ast.FuncDecl)
			if !ok || function.Body == nil {
				continue
			}
			owner := terminalCensusFunctionOwner(function)
			ast.Inspect(function.Body, func(node ast.Node) bool {
				call, ok := node.(*ast.CallExpr)
				if !ok {
					return true
				}
				name := terminalCensusCalledName(call.Fun)
				if _, tracked := terminalCensusTargets[name]; tracked {
					got[name][owner]++
				}
				return true
			})
		}
	}
	if len(indirectReferences) != 0 {
		t.Fatalf("indirect attempt-owner production references = %v, want none", indirectReferences)
	}

	want := map[string]map[string]int{
		"newAttemptResources":   {"newDirectUpgradeAttempt": 1},
		"newOwnedTURNPathClaim": {"turnRetryEngine.adoptAllocation": 1},
		"registerSession": {
			"directUpgradeAttempt.newTransportSession":                             1,
			"terminalFallbackExchange.afterListenerHandoffTimeout":                 1,
			"terminalFallbackExchange.afterPreCommitAcceptFailure":                 1,
			"terminalFallbackExchange.withAcceptedSessionCleanupUsingPeerFallback": 1,
			"terminalFallbackExchange.withSessionCleanup":                          1,
			"terminalFallbackExchange.withSessionCleanupIgnoringTurnRetryStart":    1,
			"terminalFallbackExchange.withSessionCleanupSkippingReady":             1,
			"terminalFallbackExchange.withSessionCleanupUsingPeerFallback":         1,
		},
		"registerCommit": {
			"directUpgradeProtocolEngine.executeDialerTransition":   1,
			"directUpgradeProtocolEngine.executeListenerTransition": 1,
			"terminalFallbackExchange.handlePeerControlEvent":       1,
			"turnRetryEngine.runDialer":                             1,
			"turnRetryEngine.runListenerMaterialization":            1,
		},
		"startDial": {
			"directUpgradeProtocolEngine.executeDialerTransition": 1,
			"turnRetryEngine.runDialer":                           1,
		},
		"startListen": {
			"directUpgradeProtocolEngine.executeListenerTransition": 1,
			"turnRetryEngine.runListenerMaterialization":            1,
		},
		"startAccept": {
			"directUpgradeProtocolEngine.executeListenerTransition": 1,
			"turnRetryEngine.runListenerMaterialization":            1,
		},
		"settleRelay": {
			"directUpgradeAttempt.firstPhaseFallback":                1,
			"directUpgradeAttempt.run":                               1,
			"directUpgradeAttempt.turnRetrySettlePreempted":          1,
			"directUpgradeAttempt.turnRetryTerminalFallbackExchange": 1,
			"terminalFallbackExchange.exchangeWithClassifier":        1,
			"terminalFallbackExchange.handlePeerControlEvent":        1,
		},
		"failClosed": {
			"directUpgradeProtocolEngine.executeDialerTransition":       1,
			"directUpgradeProtocolEngine.executeListenerTerminalAction": 2,
			"directUpgradeProtocolEngine.run":                           1,
			"directUpgradeAttempt.firstPhaseFallback":                   2,
			"directUpgradeAttempt.run":                                  13,
			"directUpgradeAttempt.failTurnRetryEntry":                   2,
			"directUpgradeAttempt.runTurnRetryDialerEntry":              3,
			"directUpgradeAttempt.runTurnRetryListener":                 10,
			"directUpgradeAttempt.turnRetrySettlePreempted":             3,
			"directUpgradeAttempt.turnRetryTerminalFallbackExchange":    10,
			"terminalFallbackExchange.exchangeWithClassifier":           9,
			"terminalFallbackExchange.handlePeerControlEvent":           3,
			"turnRetryEngine.handlePostSelectionFrame":                  2,
			"turnRetryEngine.preparePeer":                               2,
			"turnRetryEngine.runDialer":                                 22,
			"turnRetryEngine.runListenerMaterialization":                25,
		},
		"succeedDirect": {
			"directUpgradeProtocolEngine.executeDialerTransition":   1,
			"directUpgradeProtocolEngine.executeListenerTransition": 1,
			"turnRetryEngine.runDialer":                             1,
			"turnRetryEngine.runListenerMaterialization":            1,
		},
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("attempt owner production census = %#v, want %#v", got, want)
	}
}

func TestDirectUpgradeProtocolEngineProductionConstructorCensus(t *testing.T) {
	t.Parallel()

	entries, err := os.ReadDir(".")
	if err != nil {
		t.Fatalf("read connect package: %v", err)
	}
	files := token.NewFileSet()
	got := make(map[string]string)
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".go") || strings.HasSuffix(entry.Name(), "_test.go") {
			continue
		}
		parsed, parseErr := parser.ParseFile(files, filepath.Clean(entry.Name()), nil, 0)
		if parseErr != nil {
			t.Fatalf("parse %s: %v", entry.Name(), parseErr)
		}
		for _, declaration := range parsed.Decls {
			function, ok := declaration.(*ast.FuncDecl)
			if !ok || function.Body == nil {
				continue
			}
			owner := terminalCensusFunctionOwner(function)
			hasOwnerAssertion := false
			ast.Inspect(function.Body, func(node ast.Node) bool {
				call, ok := node.(*ast.CallExpr)
				if ok && terminalCensusCalledName(call.Fun) == "resources" {
					hasOwnerAssertion = true
				}
				return true
			})
			ast.Inspect(function.Body, func(node ast.Node) bool {
				literal, ok := node.(*ast.CompositeLit)
				if !ok {
					return true
				}
				typeName, ok := literal.Type.(*ast.Ident)
				if !ok || typeName.Name != "directUpgradeProtocolEngine" {
					return true
				}
				role := ""
				fields := make(map[string]bool)
				for _, element := range literal.Elts {
					field, keyed := element.(*ast.KeyValueExpr)
					if !keyed {
						t.Fatalf("%s uses an unkeyed directUpgradeProtocolEngine literal", owner)
					}
					key, named := field.Key.(*ast.Ident)
					if !named {
						continue
					}
					fields[key.Name] = true
					if key.Name == "role" {
						value, namedRole := field.Value.(*ast.Ident)
						if namedRole {
							role = value.Name
						}
					}
				}
				if _, duplicate := got[owner]; duplicate {
					t.Fatalf("%s constructs directUpgradeProtocolEngine more than once", owner)
				}
				got[owner] = role
				if (role == "upgradeRoleDial" || role == "upgradeRoleListen") &&
					(!fields["attempt"] || !fields["cursor"] || !hasOwnerAssertion) {
					t.Fatalf("%s protocol constructor lacks attempt, cursor, or owner assertion", owner)
				}
				return true
			})
		}
	}

	want := map[string]string{
		"newDialerDirectUpgradeProtocolEngine":   "upgradeRoleDial",
		"newListenerDirectUpgradeProtocolEngine": "upgradeRoleListen",
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("direct-upgrade engine production constructors = %#v, want %#v", got, want)
	}
}

func TestTerminalCensusFindsIndirectReference(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name   string
		source string
		want   string
	}{
		{name: "terminal method", source: "func retainReference(owner *attemptResources) { _ = owner.failClosed }", want: "failClosed"},
		{name: "commit method", source: "func retainReference(owner *attemptResources) { _ = owner.registerCommit }", want: "registerCommit"},
		{name: "Dial method", source: "func retainReference(owner *attemptResources) { _ = owner.startDial }", want: "startDial"},
		{name: "constructor function", source: "func retainReference() { _ = newAttemptResources }", want: "newAttemptResources"},
		{name: "global constructor function", source: "var retainedConstructor = newAttemptResources", want: "newAttemptResources"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			file, err := parser.ParseFile(token.NewFileSet(), "fixture.go", `package connect
`+test.source, 0)
			if err != nil {
				t.Fatalf("parse fixture: %v", err)
			}
			if got, want := terminalCensusIndirectReferences(file), []string{test.want}; !reflect.DeepEqual(got, want) {
				t.Fatalf("indirect census = %v, want %v", got, want)
			}
		})
	}
}

func terminalCensusIndirectReferences(file *ast.File) []string {
	directCalls := make(map[ast.Expr]struct{})
	declarationNames := map[*ast.Ident]struct{}{file.Name: {}}
	ast.Inspect(file, func(node ast.Node) bool {
		switch declaration := node.(type) {
		case *ast.FuncDecl:
			declarationNames[declaration.Name] = struct{}{}
		case *ast.Field:
			for _, name := range declaration.Names {
				declarationNames[name] = struct{}{}
			}
		case *ast.ImportSpec:
			if declaration.Name != nil {
				declarationNames[declaration.Name] = struct{}{}
			}
		case *ast.TypeSpec:
			declarationNames[declaration.Name] = struct{}{}
		case *ast.ValueSpec:
			for _, name := range declaration.Names {
				declarationNames[name] = struct{}{}
			}
		case *ast.CallExpr:
			if _, tracked := terminalCensusTargets[terminalCensusCalledName(declaration.Fun)]; tracked {
				directCalls[declaration.Fun] = struct{}{}
			}
		}
		return true
	})

	var references []string
	ast.Inspect(file, func(node ast.Node) bool {
		switch expression := node.(type) {
		case *ast.SelectorExpr:
			if _, tracked := terminalCensusTargets[expression.Sel.Name]; tracked {
				if _, direct := directCalls[expression]; !direct {
					references = append(references, expression.Sel.Name)
				}
				return false
			}
		case *ast.Ident:
			if _, tracked := terminalCensusTargets[expression.Name]; tracked {
				_, direct := directCalls[expression]
				_, declaration := declarationNames[expression]
				if !direct && !declaration {
					references = append(references, expression.Name)
				}
			}
		}
		return true
	})
	return references
}

func terminalCensusFunctionOwner(function *ast.FuncDecl) string {
	if function.Recv == nil || len(function.Recv.List) != 1 {
		return function.Name.Name
	}
	receiver := function.Recv.List[0].Type
	if pointer, ok := receiver.(*ast.StarExpr); ok {
		receiver = pointer.X
	}
	name, ok := receiver.(*ast.Ident)
	if !ok {
		return function.Name.Name
	}
	return name.Name + "." + function.Name.Name
}

func terminalCensusCalledName(expression ast.Expr) string {
	switch function := expression.(type) {
	case *ast.Ident:
		return function.Name
	case *ast.SelectorExpr:
		return function.Sel.Name
	default:
		return ""
	}
}
