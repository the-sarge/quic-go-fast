package connect

import (
	"context"
	"crypto/rand"
	"errors"
	"net"
	"net/netip"
	"syscall"
	"time"

	"github.com/GridSwarm/wiremux/internal/proberuntime"
)

const (
	probeReadInterval    = 20 * time.Millisecond
	probeReadBufferBytes = 2048
	probeRetryInterval   = 20 * time.Millisecond
	probeRetryJitter     = 5 * time.Millisecond
	probeRequestAttempts = 3
)

type candidatePairProbeResult struct {
	succeeded bool
	fallback  UpgradeFallbackReason
	pair      probeCandidatePair
	rtt       time.Duration
}

type probeCandidatePair struct {
	local  Candidate
	remote Candidate
}

type rankedProbeCandidate struct {
	candidate     Candidate
	deprioritized bool
}

type rankedProbeCandidatePair struct {
	pair                probeCandidatePair
	localRank           int
	remoteRank          int
	remoteDeprioritized bool
	kindOrder           int
	sharesLocalSubnet   bool
}

type probePairAttempt struct {
	pair            probeCandidatePair
	peerToken       [probeCandidatePairTokenSize]byte
	peerTokenSet    bool
	inFlight        bool
	passExhausted   bool
	outboundRetired bool
	succeeded       bool
	passAttempts    int
	nextSend        time.Time
	probeIDs        map[[probeIDBytes]byte]time.Time
	rtt             time.Duration
}

func (a directUpgradeAttempt) probeCandidatePairPlan(
	ctx context.Context,
	local localUpgradeOffer,
	peer localUpgradeOffer,
	pairPlan candidatePairPlan,
) (candidatePairProbeResult, error) {
	dialerNonce, listenerNonce := orderedProbeNonces(local.role, local.probeNonce, peer.probeNonce)
	if len(pairPlan.pairs) == 0 {
		if _, err := v1ProbeWireParams().deriveKey(a.auth.Exporter(), dialerNonce, listenerNonce); err != nil {
			return candidatePairProbeResult{fallback: UpgradeFallbackTransportFailed}, a.resources().strictCause(UpgradeErrorLocal, err)
		}
		return candidatePairProbeResult{fallback: pairPlan.fallback}, nil
	}

	runtime, err := proberuntime.New(ctx, a.selectedPacketConn())
	if err != nil {
		if a.cfg.strict {
			err = a.resources().strictProbeCause(ctx, err, false)
		}
		return candidatePairProbeResult{fallback: UpgradeFallbackTransportFailed}, err
	}
	if a.cfg.strict {
		runtime = strictProbeRuntime{Runtime: runtime, owner: a.resources()}
	}
	defer runtime.Release()
	probeTimeout := a.cfg.probeTimeout
	if probeTimeout <= 0 {
		probeTimeout = defaultUpgradeProbeTimeout
	}
	attemptDeadline := runtime.Now().Add(probeTimeout)
	probeKey, err := v1ProbeWireParams().deriveKey(a.auth.Exporter(), dialerNonce, listenerNonce)
	if err != nil {
		return candidatePairProbeResult{fallback: UpgradeFallbackTransportFailed}, a.resources().strictCause(UpgradeErrorLocal, err)
	}
	retryDelay := a.testProbeRetry
	if retryDelay == nil {
		retryDelay = probeRetryDelay
	}
	result, err := probePairsWithRetryDelay(ctx, runtime, attemptDeadline, probeKey, local.role, pairPlan.pairs, a.cfg.probeConcurrency, retryDelay, v1ProbeWireParams(), false)
	if err != nil {
		return candidatePairProbeResult{fallback: UpgradeFallbackTransportFailed}, a.resources().strictProbeCause(ctx, err, true)
	}
	if !result.succeeded {
		return candidatePairProbeResult{fallback: UpgradeFallbackProbeFailed}, nil
	}
	result.fallback = UpgradeFallbackNone
	return result, nil
}

func orderedProbeNonces(role upgradeRole, localNonce, peerNonce []byte) ([]byte, []byte) {
	if role == upgradeRoleDial {
		return localNonce, peerNonce
	}
	return peerNonce, localNonce
}

func probeCandidateSupported(candidate Candidate) bool {
	_, err := v1ProbeWireParams().encodeCandidate(candidate)
	return err == nil
}

func probeCandidatePairKindOrder(pair probeCandidatePair) int {
	localOrder := candidateKindOrder(pair.local.Kind)
	remoteOrder := candidateKindOrder(pair.remote.Kind)
	if localOrder > remoteOrder {
		return localOrder
	}
	return remoteOrder
}

func sameLocalSubnet(pair probeCandidatePair) bool {
	local := pair.local.Addr.Addr().Unmap()
	remote := pair.remote.Addr.Addr().Unmap()
	if local.Is4() && remote.Is4() {
		prefix := netip.PrefixFrom(local, 24)
		return prefix.Contains(remote)
	}
	if local.Is6() && remote.Is6() {
		prefix := netip.PrefixFrom(local, 64)
		return prefix.Contains(remote)
	}
	return false
}

// probePairsWithRetryDelay runs the bounded probe scheduler with the given
// Probe dialect. heldOnCancel makes context cancellation return an
// already-held listener success instead of the cancellation error at every
// exit that can observe it: the loop's context check, the receive, and the
// response send inside handleProbePacket (#1283). The TURN retry listener
// joins through cancellation at Selected receipt and must not lose a held
// success (#1218), while v1 callers preserve their existing cancellation
// shape.
func probePairsWithRetryDelay(ctx context.Context, runtime proberuntime.Runtime, attemptDeadline time.Time, probeKey []byte, role upgradeRole, pairs []probeCandidatePair, concurrency int, retryDelay func() time.Duration, dialect probeWireParams, heldOnCancel bool) (candidatePairProbeResult, error) {
	if concurrency <= 0 {
		concurrency = defaultUpgradeProbeConcurrency
	}
	localDirection := localProbeDirection(role)
	peerDirection := peerProbeDirection(role)
	attempts := newProbePairAttempts(pairs)
	var heldListenerResult candidatePairProbeResult

	nextPair := 0

	buf := make([]byte, probeReadBufferBytes)
	for {
		if err := ctx.Err(); err != nil {
			return heldOnCancelExit(heldOnCancel, heldListenerResult, err)
		}
		if !runtime.Now().Before(attemptDeadline) {
			if heldListenerResult.succeeded {
				return heldListenerResult, nil
			}
			return candidatePairProbeResult{}, nil
		}

		now := runtime.Now()
		nextWake := attemptDeadline
		if !heldListenerResult.succeeded {
			expireProbeAttempts(attempts, now)
			if result := bestReadyProbeResult(attempts); result.succeeded {
				if role == upgradeRoleDial {
					return result, nil
				}
				// The dialer is the selected-pair authority. A listener that
				// validates first stops originating requests but keeps this
				// attempt runtime available to answer the dialer's later pass.
				// Selected-pair or fallback control cancels ctx and joins this
				// receive loop before the packet socket changes owners.
				heldListenerResult = result
			}
		}
		if !heldListenerResult.succeeded {
			var deadlineReached, passComplete bool
			var err error
			nextWake, deadlineReached, passComplete, err = advanceProbeSchedule(ctx, runtime, attemptDeadline, probeKey, localDirection, attempts, concurrency, &nextPair, now, retryDelay, dialect)
			if err != nil {
				return candidatePairProbeResult{}, err
			}
			if deadlineReached {
				return candidatePairProbeResult{}, nil
			}
			if !heldListenerResult.succeeded && passComplete && beginNextProbePass(attempts, &nextPair) {
				continue
			}
		}

		n, addr, timeout, err := runtime.Receive(ctx, buf, nextProbeReadDeadline(now, nextWake, attemptDeadline))
		if err != nil {
			return heldOnCancelExit(heldOnCancel, heldListenerResult, err)
		}
		if timeout {
			continue
		}

		observed, err := addrPortFromNetAddrWithSentinel(addr, errInvalidProbeCandidateAddress)
		if err != nil {
			continue
		}
		result, err := handleProbePacket(ctx, runtime, probeKey, localDirection, peerDirection, attempts, buf[:n], observed, addr, dialect)
		if err != nil {
			return heldOnCancelExit(heldOnCancel, heldListenerResult, err)
		}
		if result.succeeded {
			if role == upgradeRoleDial {
				return result, nil
			}
			heldListenerResult = result
		}
	}
}

// heldOnCancelExit is the single owner of the heldOnCancel rule: when the
// rule is enabled, a success is already held, and err is context
// cancellation, the held success is returned instead of the error. Every
// other error passes through unchanged.
func heldOnCancelExit(heldOnCancel bool, held candidatePairProbeResult, err error) (candidatePairProbeResult, error) {
	if heldOnCancel && held.succeeded && errors.Is(err, context.Canceled) {
		return held, nil
	}
	return candidatePairProbeResult{}, err
}

func newProbePairAttempts(pairs []probeCandidatePair) []probePairAttempt {
	attempts := make([]probePairAttempt, len(pairs))
	for i := range pairs {
		attempts[i].pair = pairs[i]
	}
	return attempts
}

func advanceProbeSchedule(
	ctx context.Context,
	runtime proberuntime.Runtime,
	attemptDeadline time.Time,
	probeKey []byte,
	direction probeDirection,
	attempts []probePairAttempt,
	concurrency int,
	nextPair *int,
	now time.Time,
	retryDelay func() time.Duration,
	dialect probeWireParams,
) (nextWake time.Time, deadlineReached, passComplete bool, err error) {
	active := activeProbePairs(attempts)
	for active < concurrency && *nextPair < len(attempts) && !hasProbeSuccess(attempts) {
		attempt := &attempts[*nextPair]
		sendAt, deadlineReached, err := probeScheduleSendTime(ctx, runtime, attemptDeadline)
		if err != nil {
			return time.Time{}, false, false, err
		}
		if deadlineReached {
			return time.Time{}, true, false, nil
		}
		*nextPair++
		if attempt.succeeded || attempt.outboundRetired {
			continue
		}
		attempt.inFlight = true
		if err := sendProbeRequest(ctx, runtime, probeKey, direction, attempt, sendAt, retryDelay, dialect); err != nil {
			if isRecoverableProbeWriteError(err) {
				markProbePairRetired(attempt)
				continue
			}
			return time.Time{}, false, false, err
		}
		active++
	}

	for i := range attempts {
		attempt := &attempts[i]
		if !attempt.inFlight || attempt.passExhausted || attempt.passAttempts >= probeRequestAttempts || attempt.nextSend.After(now) {
			continue
		}
		sendAt, deadlineReached, err := probeScheduleSendTime(ctx, runtime, attemptDeadline)
		if err != nil {
			return time.Time{}, false, false, err
		}
		if deadlineReached {
			return time.Time{}, true, false, nil
		}
		if err := sendProbeRequest(ctx, runtime, probeKey, direction, attempt, sendAt, retryDelay, dialect); err != nil {
			if isRecoverableProbeWriteError(err) {
				markProbePairRetired(attempt)
				continue
			}
			return time.Time{}, false, false, err
		}
	}

	active = activeProbePairs(attempts)
	if *nextPair >= len(attempts) && active == 0 {
		return now.Add(probeReadInterval), false, true, nil
	}

	nextWake = now.Add(probeReadInterval)
	for i := range attempts {
		attempt := &attempts[i]
		if !attempt.inFlight || attempt.passExhausted {
			continue
		}
		if attempt.nextSend.Before(nextWake) {
			nextWake = attempt.nextSend
		}
	}
	return nextWake, false, false, nil
}

func expireProbeAttempts(attempts []probePairAttempt, now time.Time) {
	for i := range attempts {
		attempt := &attempts[i]
		if !attempt.inFlight || attempt.passExhausted {
			continue
		}
		if attempt.passAttempts >= probeRequestAttempts && !attempt.nextSend.After(now) {
			attempt.inFlight = false
			attempt.passExhausted = true
		}
	}
}

func probeScheduleSendTime(ctx context.Context, runtime proberuntime.Runtime, attemptDeadline time.Time) (time.Time, bool, error) {
	if err := ctx.Err(); err != nil {
		return time.Time{}, false, err
	}
	now := runtime.Now()
	if !now.Before(attemptDeadline) {
		return now, true, nil
	}
	return now, false, nil
}

func markProbePairExhausted(attempt *probePairAttempt) {
	attempt.inFlight = false
	attempt.passExhausted = true
}

func markProbePairRetired(attempt *probePairAttempt) {
	markProbePairExhausted(attempt)
	attempt.outboundRetired = true
}

func markProbePairSucceeded(attempt *probePairAttempt, rtt time.Duration) {
	if attempt.succeeded {
		return
	}
	attempt.inFlight = false
	attempt.passExhausted = true
	attempt.succeeded = true
	attempt.rtt = rtt
}

func activeProbePairs(attempts []probePairAttempt) int {
	active := 0
	for i := range attempts {
		if attempts[i].inFlight && !attempts[i].passExhausted {
			active++
		}
	}
	return active
}

func hasProbeSuccess(attempts []probePairAttempt) bool {
	for i := range attempts {
		if attempts[i].succeeded {
			return true
		}
	}
	return false
}

func beginNextProbePass(attempts []probePairAttempt, nextPair *int) bool {
	eligible := false
	for i := range attempts {
		attempt := &attempts[i]
		if attempt.succeeded || attempt.outboundRetired {
			continue
		}
		attempt.inFlight = false
		attempt.passExhausted = false
		attempt.passAttempts = 0
		eligible = true
	}
	if eligible {
		*nextPair = 0
	}
	return eligible
}

func sendProbeRequest(
	ctx context.Context,
	runtime proberuntime.Runtime,
	probeKey []byte,
	direction probeDirection,
	attempt *probePairAttempt,
	now time.Time,
	retryDelay func() time.Duration,
	dialect probeWireParams,
) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if attempt.passAttempts >= probeRequestAttempts {
		return nil
	}

	var probeID [probeIDBytes]byte
	if _, err := rand.Read(probeID[:]); err != nil {
		return err
	}
	datagram, err := dialect.encodeDatagram(probeKey, probeMessageRequest, direction, probeID, attempt.pair.local, attempt.pair.remote)
	if err != nil {
		return err
	}
	if err := runtime.Send(ctx, datagram, net.UDPAddrFromAddrPort(attempt.pair.remote.Addr)); err != nil {
		return err
	}
	if attempt.probeIDs == nil {
		attempt.probeIDs = make(map[[probeIDBytes]byte]time.Time, probeRequestAttempts)
	}
	attempt.probeIDs[probeID] = now
	attempt.passAttempts++
	attempt.nextSend = now.Add(retryDelay())
	return nil
}

func handleProbePacket(
	ctx context.Context,
	runtime proberuntime.Runtime,
	probeKey []byte,
	localDirection probeDirection,
	peerDirection probeDirection,
	attempts []probePairAttempt,
	packet []byte,
	observed netip.AddrPort,
	observedAddr net.Addr,
	dialect probeWireParams,
) (candidatePairProbeResult, error) {
	decoded, ok := dialect.decodeDatagram(packet)
	if !ok {
		if dialect.crossProfile != nil && dialect.crossProfile(packet) {
			return candidatePairProbeResult{}, errTurnRetryCrossProfileProbe
		}
		return candidatePairProbeResult{}, nil
	}
	if decoded.Direction != peerDirection {
		return candidatePairProbeResult{}, nil
	}

	for i := range attempts {
		attempt := &attempts[i]
		if !probeObservedSourceMatches(attempt.pair.remote, observed) {
			continue
		}
		if err := ensureProbeAttemptPeerToken(probeKey, peerDirection, attempt, dialect); err != nil {
			return candidatePairProbeResult{}, err
		}
		if decoded.Token != attempt.peerToken {
			continue
		}
		request, ok := dialect.acceptDatagram(probeKey, packet, probeMessageRequest, peerDirection, attempt.pair.remote, attempt.pair.local, observed)
		if ok {
			response, err := dialect.encodeDatagram(probeKey, probeMessageResponse, localDirection, request.ProbeID, attempt.pair.local, attempt.pair.remote)
			if err == nil && ctx.Err() == nil {
				err := runtime.Send(ctx, response, observedAddr)
				if err != nil {
					if isRecoverableProbeWriteError(err) {
						markProbePairRetired(attempt)
						return candidatePairProbeResult{}, nil
					}
					return candidatePairProbeResult{}, err
				}
			}
			return candidatePairProbeResult{}, nil
		}
		response, ok := dialect.acceptDatagram(probeKey, packet, probeMessageResponse, peerDirection, attempt.pair.remote, attempt.pair.local, observed)
		if ok {
			sentAt, ok := probeIDSentAt(attempt, response.ProbeID)
			if ok {
				rtt := runtime.Now().Sub(sentAt)
				if rtt <= 0 {
					rtt = time.Nanosecond
				}
				markProbePairSucceeded(attempt, rtt)
				return bestReadyProbeResult(attempts), nil
			}
		}
	}
	return candidatePairProbeResult{}, nil
}

func ensureProbeAttemptPeerToken(probeKey []byte, direction probeDirection, attempt *probePairAttempt, dialect probeWireParams) error {
	if attempt.peerTokenSet {
		return nil
	}
	peerToken, err := dialect.candidatePairToken(probeKey, direction, attempt.pair.remote, attempt.pair.local)
	if err != nil {
		return err
	}
	copy(attempt.peerToken[:], peerToken)
	attempt.peerTokenSet = true
	return nil
}

func bestReadyProbeResult(attempts []probePairAttempt) candidatePairProbeResult {
	for i := range attempts {
		if attempts[i].succeeded {
			return candidatePairProbeResult{
				succeeded: true,
				pair:      attempts[i].pair,
				rtt:       attempts[i].rtt,
			}
		}
		if attempts[i].inFlight && !attempts[i].passExhausted {
			return candidatePairProbeResult{}
		}
	}
	return candidatePairProbeResult{}
}

func isRecoverableProbeWriteError(err error) bool {
	return errors.Is(err, syscall.EADDRNOTAVAIL) ||
		errors.Is(err, syscall.EHOSTUNREACH) ||
		errors.Is(err, syscall.ENETUNREACH) ||
		errors.Is(err, syscall.ENOBUFS)
}

func localProbeDirection(role upgradeRole) probeDirection {
	if role == upgradeRoleDial {
		return probeDirectionDialerToListener
	}
	return probeDirectionListenerToDialer
}

func peerProbeDirection(role upgradeRole) probeDirection {
	if role == upgradeRoleDial {
		return probeDirectionListenerToDialer
	}
	return probeDirectionDialerToListener
}

func probeIDSentAt(attempt *probePairAttempt, probeID [probeIDBytes]byte) (time.Time, bool) {
	sentAt, ok := attempt.probeIDs[probeID]
	return sentAt, ok
}

func probeRetryDelay() time.Duration {
	var raw [1]byte
	if _, err := rand.Read(raw[:]); err != nil {
		return probeRetryInterval
	}
	jitter := time.Duration(raw[0]) * probeRetryJitter / 255
	return probeRetryInterval + jitter
}

func nextProbeReadDeadline(now, nextWake, attemptDeadline time.Time) time.Time {
	deadline := nextWake
	if readPoll := now.Add(probeReadInterval); deadline.IsZero() || readPoll.Before(deadline) {
		deadline = readPoll
	}
	if attemptDeadline.Before(deadline) {
		return attemptDeadline
	}
	return deadline
}
