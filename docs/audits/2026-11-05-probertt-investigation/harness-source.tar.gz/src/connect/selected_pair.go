package connect

import "time"

type selectedPair struct {
	// dialer and listener store the selected candidate pair in role-absolute
	// form. Use local, remote, or candidatePair when code needs a role-relative
	// view.
	dialer   Candidate
	listener Candidate
	// rtt is the measured probe round trip when known. A zero value means the
	// selected pair arrived without RTT material and callers should preserve
	// their local probe timing instead.
	rtt time.Duration
}

func (p selectedPair) local(role upgradeRole) Candidate {
	switch role {
	case upgradeRoleDial:
		return p.dialer
	case upgradeRoleListen:
		return p.listener
	default:
		return Candidate{}
	}
}

func (p selectedPair) remote(role upgradeRole) Candidate {
	switch role {
	case upgradeRoleDial:
		return p.listener
	case upgradeRoleListen:
		return p.dialer
	default:
		return Candidate{}
	}
}

func (p selectedPair) candidatePair(role upgradeRole) CandidatePair {
	return CandidatePair{
		Local:  p.local(role),
		Remote: p.remote(role),
	}
}

// selectedPairFromProbeResult records the dialer-origin probe pair in absolute
// role form. Callers must only pass a successful probe result from the dialer
// perspective.
func selectedPairFromProbeResult(result candidatePairProbeResult) selectedPair {
	return selectedPair{
		dialer:   result.pair.local,
		listener: result.pair.remote,
		rtt:      result.rtt,
	}
}

func selectedProbeRTT(selected selectedPair, fallback time.Duration) time.Duration {
	if selected.rtt > 0 {
		return selected.rtt
	}
	return fallback
}
