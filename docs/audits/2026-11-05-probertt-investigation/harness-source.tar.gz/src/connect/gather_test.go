package connect

import (
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"strings"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/stun"
)

func TestGatherReturnsHostCandidateForExplicitBinding(t *testing.T) {
	conn := listenPacket(t, "127.0.0.1:0")

	candidates, err := Gather(context.Background(), WithPacketConn(conn))
	if err != nil {
		t.Fatalf("Gather: %v", err)
	}

	wantAddr := conn.LocalAddr().(*net.UDPAddr).AddrPort()
	want := []Candidate{
		{Kind: CandidateKindHost, Addr: wantAddr},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}

	probeConn := listenPacket(t, "127.0.0.1:0")
	if _, err := conn.WriteTo([]byte("still-open"), probeConn.LocalAddr()); err != nil {
		t.Fatalf("packet conn after Gather WriteTo: %v", err)
	}
}

func TestGatherExplicitBindingResolvesLocalInterfaceOnce(t *testing.T) {
	interfaces := []gatherInterface{
		{
			name:  "eth0",
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
			},
		},
	}
	calls := 0
	gatherer := defaultCandidateGatherer()
	gatherer.interfaces = func() ([]gatherInterface, error) {
		calls++
		return interfaces, nil
	}

	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  udpAddr(t, "192.0.2.10:12345"),
	}
	if _, err := gatherer.gather(context.Background(), WithPacketConn(conn)); err != nil {
		t.Fatalf("Gather without STUN: %v", err)
	}
	if calls != 1 {
		t.Fatalf("gatherInterfaces calls without STUN = %d, want 1", calls)
	}

	calls = 0
	gatherer.reflexive = func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return udpAddr(t, "198.51.100.40:54321"), nil
	}
	if _, err := gatherer.gather(context.Background(), WithPacketConn(conn), WithSTUNServer(udpAddr(t, "192.0.2.1:3478"))); err != nil {
		t.Fatalf("Gather with STUN: %v", err)
	}
	if calls != 1 {
		t.Fatalf("gatherInterfaces calls with STUN = %d, want 1", calls)
	}
}

func TestGatherRejectsInvalidInputs(t *testing.T) {
	conn := listenPacket(t, "127.0.0.1:0")
	canceled, cancel := context.WithCancel(context.Background())
	cancel()

	tests := []struct {
		name    string
		ctx     context.Context
		opts    []GatherOption
		wantErr error
	}{
		{
			name:    "nil context",
			ctx:     nil,
			opts:    []GatherOption{WithPacketConn(conn)},
			wantErr: ErrNilContext,
		},
		{
			name:    "missing packet conn",
			ctx:     context.Background(),
			opts:    nil,
			wantErr: ErrNilPacketConn,
		},
		{
			name:    "canceled context",
			ctx:     canceled,
			opts:    []GatherOption{WithPacketConn(conn)},
			wantErr: context.Canceled,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := Gather(tt.ctx, tt.opts...)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("Gather error = %v, want %v", err, tt.wantErr)
			}
			if got != nil {
				t.Fatalf("Gather = %#v, want nil", got)
			}
		})
	}
}

func TestGatherRejectsPacketConnLocalPortZero(t *testing.T) {
	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  udpAddr(t, "192.0.2.10:0"),
	}

	candidates, err := Gather(context.Background(), WithPacketConn(conn))
	if !errors.Is(err, ErrInvalidPacketConnLocalAddr) {
		t.Fatalf("Gather error = %v, want %v", err, ErrInvalidPacketConnLocalAddr)
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

func TestGatherReturnsReflexiveCandidateFromSTUN(t *testing.T) {
	serverConn := listenPacket(t, "127.0.0.1:0")
	mapped := netip.MustParseAddrPort("203.0.113.10:54321")
	serveMappedAddressOnce(t, serverConn, mapped)

	realConn := listenPacket(t, "127.0.0.1:0")
	conn := localAddrPacketConn{
		PacketConn: realConn,
		localAddr:  udpAddr(t, "192.0.2.10:12345"),
	}

	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := Gather(ctx, WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
	if err != nil {
		t.Fatalf("Gather: %v", err)
	}

	want := []Candidate{
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")},
		{Kind: CandidateKindReflexive, Addr: mapped},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}

	assertPacketConnStillUsable(t, realConn)
}

func TestGatherReturnsHostCandidateWithBackgroundContextWhenSTUNConfigured(t *testing.T) {
	serverConn := listenPacket(t, "127.0.0.1:0")
	go func() {
		_ = stun.NewServer().Serve(serverConn)
	}()

	conn := listenPacket(t, "127.0.0.1:0")

	candidates, err := Gather(context.Background(), WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
	if err != nil {
		t.Fatalf("Gather: %v", err)
	}

	want := []Candidate{
		{Kind: CandidateKindHost, Addr: conn.LocalAddr().(*net.UDPAddr).AddrPort()},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherRejectsInvalidSTUNServerOptions(t *testing.T) {
	conn := listenPacket(t, "127.0.0.1:0")

	tests := []struct {
		name   string
		server net.Addr
	}{
		{
			name:   "nil",
			server: nil,
		},
		{
			name:   "malformed",
			server: testNetAddr("not-an-addr"),
		},
		{
			name:   "non-udp",
			server: tcpAddr(t, "127.0.0.1:3478"),
		},
		{
			name:   "incompatible address family",
			server: udpAddr(t, "[2001:db8::1]:3478"),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			candidates, err := Gather(context.Background(), WithPacketConn(conn), WithSTUNServer(tt.server))
			if !errors.Is(err, ErrInvalidSTUNServerAddress) {
				t.Fatalf("Gather error = %v, want %v", err, ErrInvalidSTUNServerAddress)
			}
			if candidates != nil {
				t.Fatalf("Gather = %#v, want nil", candidates)
			}
		})
	}
}

func TestGatherReturnsReflexiveCandidateWhenHostGatheringFindsNoCandidates(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{flags: net.FlagUp, addrs: []net.Addr{testNetAddr("127.0.0.1/8")}},
	})

	serverConn := listenPacket(t, "127.0.0.1:0")
	mapped := netip.MustParseAddrPort("203.0.113.10:54321")
	serveMappedAddressOnce(t, serverConn, mapped)

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
	if err != nil {
		t.Fatalf("Gather: %v", err)
	}

	want := []Candidate{
		{Kind: CandidateKindReflexive, Addr: mapped},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherReturnsReflexiveCandidateWhenWildcardInterfaceAddressesFail(t *testing.T) {
	addrsErr := errors.New("interface addresses failed")
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags:    net.FlagUp,
			addrsErr: addrsErr,
		},
	})

	serverConn := listenPacket(t, "127.0.0.1:0")
	mapped := netip.MustParseAddrPort("203.0.113.10:54321")
	serveMappedAddressOnce(t, serverConn, mapped)

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
	if err != nil {
		t.Fatalf("Gather: %v", err)
	}

	want := []Candidate{
		{Kind: CandidateKindReflexive, Addr: mapped},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherDropsUnusableReflexiveCandidates(t *testing.T) {
	tests := []struct {
		name   string
		mapped netip.AddrPort
	}{
		{
			name:   "unspecified",
			mapped: netip.MustParseAddrPort("0.0.0.0:12345"),
		},
		{
			name:   "loopback",
			mapped: netip.MustParseAddrPort("127.0.0.1:12345"),
		},
		{
			name:   "link local",
			mapped: netip.MustParseAddrPort("169.254.10.20:12345"),
		},
		{
			name:   "multicast",
			mapped: netip.MustParseAddrPort("224.0.0.1:12345"),
		},
		{
			name:   "zero port",
			mapped: netip.MustParseAddrPort("203.0.113.10:0"),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			serverConn := listenPacket(t, "127.0.0.1:0")
			serveMappedAddressOnce(t, serverConn, tt.mapped)

			realConn := listenPacket(t, "127.0.0.1:0")
			conn := localAddrPacketConn{
				PacketConn: realConn,
				localAddr:  udpAddr(t, "192.0.2.10:12345"),
			}

			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()

			candidates, err := Gather(ctx, WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
			if err != nil {
				t.Fatalf("Gather: %v", err)
			}

			want := []Candidate{
				{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")},
			}
			if !equalCandidates(candidates, want) {
				t.Fatalf("Gather = %#v, want %#v", candidates, want)
			}
		})
	}
}

func TestGatherDeduplicatesHostAndReflexiveAddress(t *testing.T) {
	serverConn := listenPacket(t, "127.0.0.1:0")
	mapped := netip.MustParseAddrPort("198.51.100.10:12345")
	serveMappedAddressOnce(t, serverConn, mapped)

	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  net.UDPAddrFromAddrPort(mapped),
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := Gather(ctx, WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
	if err != nil {
		t.Fatalf("Gather: %v", err)
	}

	want := []Candidate{
		{Kind: CandidateKindHost, Addr: mapped},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherReturnsHostCandidatesWhenValidSTUNDiscoveryFailsWithActiveContext(t *testing.T) {
	conn := failingWritePacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		err:        errors.New("stun send failed"),
	}
	ctx := t.Context()

	candidates, err := Gather(ctx, WithPacketConn(conn), WithSTUNServer(udpAddr(t, "192.0.2.1:3478")))
	if err != nil {
		t.Fatalf("Gather: %v", err)
	}

	want := []Candidate{
		{Kind: CandidateKindHost, Addr: conn.LocalAddr().(*net.UDPAddr).AddrPort()},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherReturnsHostCandidatesWhenReflexiveAddressCannotBeParsed(t *testing.T) {
	gatherer := testGathererWithReflexive(func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return testNetAddr("not-an-addr"), nil
	})

	conn := localAddrPacketConn{
		PacketConn: listenPacket(t, "127.0.0.1:0"),
		localAddr:  udpAddr(t, "192.0.2.10:12345"),
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(udpAddr(t, "192.0.2.1:3478")))
	if err != nil {
		t.Fatalf("Gather: %v", err)
	}

	want := []Candidate{
		{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherPreservesInterfaceAddressErrorWhenReflexiveAddressCannotBeParsed(t *testing.T) {
	addrsErr := errors.New("interface addresses failed")
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags:    net.FlagUp,
			addrsErr: addrsErr,
		},
	})
	gatherer.reflexive = func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return testNetAddr("not-an-addr"), nil
	}

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(udpAddr(t, "192.0.2.1:3478")))
	if !errors.Is(err, addrsErr) {
		t.Fatalf("Gather error = %v, want %v", err, addrsErr)
	}
	if !errors.Is(err, errInvalidReflexiveCandidateAddress) {
		t.Fatalf("Gather error = %v, want %v", err, errInvalidReflexiveCandidateAddress)
	}
	if errors.Is(err, ErrInvalidPacketConnLocalAddr) {
		t.Fatalf("Gather error = %v, want interface address error without %v", err, ErrInvalidPacketConnLocalAddr)
	}
	if strings.Contains(err.Error(), ErrInvalidPacketConnLocalAddr.Error()) {
		t.Fatalf("Gather error = %q, want no %q text", err.Error(), ErrInvalidPacketConnLocalAddr.Error())
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

func TestGatherPreservesNoCandidatesWhenReflexiveAddressCannotBeParsed(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("127.0.0.1/8"),
			},
		},
	})
	gatherer.reflexive = func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return testNetAddr("not-an-addr"), nil
	}

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(udpAddr(t, "192.0.2.1:3478")))
	if !errors.Is(err, ErrNoCandidates) {
		t.Fatalf("Gather error = %v, want %v", err, ErrNoCandidates)
	}
	if !errors.Is(err, errInvalidReflexiveCandidateAddress) {
		t.Fatalf("Gather error = %v, want %v", err, errInvalidReflexiveCandidateAddress)
	}
	if errors.Is(err, ErrInvalidPacketConnLocalAddr) {
		t.Fatalf("Gather error = %v, want no %v", err, ErrInvalidPacketConnLocalAddr)
	}
	if strings.Contains(err.Error(), ErrInvalidPacketConnLocalAddr.Error()) {
		t.Fatalf("Gather error = %q, want no %q text", err.Error(), ErrInvalidPacketConnLocalAddr.Error())
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

func TestGatherPreservesSTUNDiscoveryErrorWhenNoCandidates(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("127.0.0.1/8"),
			},
		},
	})
	gatherer.reflexive = func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return nil, stun.ErrBindingError
	}

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(udpAddr(t, "192.0.2.1:3478")))
	if !errors.Is(err, ErrNoCandidates) {
		t.Fatalf("Gather error = %v, want %v", err, ErrNoCandidates)
	}
	if !errors.Is(err, errSTUNDiscoveryFailed) {
		t.Fatalf("Gather error = %v, want %v", err, errSTUNDiscoveryFailed)
	}
	if !errors.Is(err, stun.ErrBindingError) {
		t.Fatalf("Gather error = %v, want %v", err, stun.ErrBindingError)
	}
	if errors.Is(err, ErrInvalidPacketConnLocalAddr) {
		t.Fatalf("Gather error = %v, want no %v", err, ErrInvalidPacketConnLocalAddr)
	}
	if strings.Contains(err.Error(), ErrInvalidPacketConnLocalAddr.Error()) {
		t.Fatalf("Gather error = %q, want no %q text", err.Error(), ErrInvalidPacketConnLocalAddr.Error())
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

func TestGatherReturnsHostCandidatesWhenSTUNDiscoveryFailsWithActiveContext(t *testing.T) {
	if !hasUsableInterfaceAddress(t) {
		t.Skip("no usable non-loopback interface address on this host")
	}

	gatherer := testGathererWithReflexive(func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return nil, stun.ErrBindingError
	})

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(udpAddr(t, "192.0.2.1:3478")))
	if err != nil {
		t.Fatalf("Gather: %v", err)
	}
	if len(candidates) == 0 {
		t.Fatal("Gather returned no candidates")
	}
	for _, candidate := range candidates {
		if candidate.Kind != CandidateKindHost {
			t.Fatalf("candidate = %#v, want host candidate only", candidate)
		}
	}
}

func TestGatherReturnsCallerContextErrorWhenSTUNDiscoveryCanceled(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("127.0.0.1/8"),
			},
		},
	})
	gatherer.reflexive = func(ctx context.Context, conn net.PacketConn, server net.Addr) (net.Addr, error) {
		<-ctx.Done()
		return nil, ctx.Err()
	}

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(udpAddr(t, "192.0.2.1:3478")))
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("Gather error = %v, want %v", err, context.Canceled)
	}
	if errors.Is(err, ErrNoCandidates) {
		t.Fatalf("Gather error = %v, want no %v", err, ErrNoCandidates)
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

func TestGatherReturnsNoCandidatesWithoutSTUNDiagnosticOnInternalTimeout(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("127.0.0.1/8"),
			},
		},
	})

	serverConn := listenPacket(t, "127.0.0.1:0")
	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
	if !errors.Is(err, ErrNoCandidates) {
		t.Fatalf("Gather error = %v, want %v", err, ErrNoCandidates)
	}
	if errors.Is(err, errSTUNDiscoveryFailed) {
		t.Fatalf("Gather error = %v, want no %v", err, errSTUNDiscoveryFailed)
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

func TestGatherJoinsInterfaceAddressErrorWithSTUNDiscoveryError(t *testing.T) {
	addrsErr := errors.New("interface addresses failed")
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags:    net.FlagUp,
			addrsErr: addrsErr,
		},
	})
	gatherer.reflexive = func(context.Context, net.PacketConn, net.Addr) (net.Addr, error) {
		return nil, stun.ErrBindingError
	}

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	candidates, err := gatherer.gather(ctx, WithPacketConn(conn), WithSTUNServer(udpAddr(t, "192.0.2.1:3478")))
	if !errors.Is(err, addrsErr) {
		t.Fatalf("Gather error = %v, want %v", err, addrsErr)
	}
	if !errors.Is(err, errSTUNDiscoveryFailed) {
		t.Fatalf("Gather error = %v, want %v", err, errSTUNDiscoveryFailed)
	}
	if !errors.Is(err, stun.ErrBindingError) {
		t.Fatalf("Gather error = %v, want %v", err, stun.ErrBindingError)
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

func TestGatherReturnsHostCandidatesWhenSTUNServerIsSilentWithoutCallerDeadline(t *testing.T) {
	serverConn := listenPacket(t, "127.0.0.1:0")
	conn := listenPacket(t, "127.0.0.1:0")
	ctx := t.Context()

	type result struct {
		candidates []Candidate
		err        error
	}
	done := make(chan result, 1)
	go func() {
		candidates, err := Gather(ctx, WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
		done <- result{candidates: candidates, err: err}
	}()

	select {
	case got := <-done:
		if got.err != nil {
			t.Fatalf("Gather: %v", got.err)
		}
		want := []Candidate{
			{Kind: CandidateKindHost, Addr: conn.LocalAddr().(*net.UDPAddr).AddrPort()},
		}
		if !equalCandidates(got.candidates, want) {
			t.Fatalf("Gather = %#v, want %#v", got.candidates, want)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("Gather did not return after silent STUN discovery")
	}
}

func TestGatherReturnsCallerContextErrorWhenSTUNOutlivesDeadline(t *testing.T) {
	serverConn := listenPacket(t, "127.0.0.1:0")
	conn := listenPacket(t, "127.0.0.1:0")
	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancel()

	candidates, err := Gather(ctx, WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("Gather error = %v, want %v", err, context.DeadlineExceeded)
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

func TestGatherEnumeratesUsableHostCandidatesForWildcardBinding(t *testing.T) {
	if !hasUsableInterfaceAddress(t) {
		t.Skip("no usable non-loopback interface address")
	}

	conn := listenPacket(t, "0.0.0.0:0")
	candidates, err := Gather(context.Background(), WithPacketConn(conn))
	if err != nil {
		t.Fatalf("Gather wildcard: %v", err)
	}
	if len(candidates) == 0 {
		t.Fatal("Gather wildcard returned no candidates")
	}

	port := conn.LocalAddr().(*net.UDPAddr).AddrPort().Port()
	for _, candidate := range candidates {
		if candidate.Kind != CandidateKindHost {
			t.Fatalf("candidate kind = %v, want host", candidate.Kind)
		}
		if candidate.Addr.Port() != port {
			t.Fatalf("candidate port = %d, want %d", candidate.Addr.Port(), port)
		}
		if !usableHostAddress(candidate.Addr.Addr()) {
			t.Fatalf("candidate address = %v, want usable non-loopback address", candidate.Addr.Addr())
		}
	}
}

func TestGatherFiltersWildcardCandidatesByIPv4SocketFamily(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
				testNetAddr("2001:db8::10/64"),
			},
		},
	})

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	candidates, err := gatherer.gather(context.Background(), WithPacketConn(conn))
	if err != nil {
		t.Fatalf("Gather wildcard udp4: %v", err)
	}

	port := conn.LocalAddr().(*net.UDPAddr).AddrPort().Port()
	want := []Candidate{
		{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("192.0.2.10"), port)},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherFiltersWildcardCandidatesByIPv6OnlySocketFamily(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
				testNetAddr("2001:db8::10/64"),
			},
		},
	})

	conn := listenPacketNetworkOrSkip(t, "udp6", "[::]:0")
	candidates, err := gatherer.gather(context.Background(), WithPacketConn(conn))
	if err != nil {
		t.Fatalf("Gather wildcard udp6: %v", err)
	}

	port := conn.LocalAddr().(*net.UDPAddr).AddrPort().Port()
	want := []Candidate{
		{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("2001:db8::10"), port)},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherFiltersWildcardCandidatesByDualStackSocketFamily(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
				testNetAddr("2001:db8::10/64"),
			},
		},
	})

	conn := listenPacketNetworkOrSkip(t, "udp", "[::]:0")
	localAddr := conn.LocalAddr().(*net.UDPAddr).AddrPort()
	if !localAddr.Addr().Is6() || !localAddr.Addr().IsUnspecified() {
		t.Skipf("ListenPacket returned non-IPv6-wildcard address %v", localAddr)
	}
	if !ipv6WildcardAllowsIPv4(conn) {
		t.Skip("IPv6 wildcard socket is IPv6-only")
	}

	candidates, err := gatherer.gather(context.Background(), WithPacketConn(conn))
	if err != nil {
		t.Fatalf("Gather wildcard dual-stack: %v", err)
	}

	port := localAddr.Port()
	want := []Candidate{
		{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("192.0.2.10"), port)},
		{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("2001:db8::10"), port)},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherSkipsDownInterfacesForWildcardBinding(t *testing.T) {
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags: 0,
			addrs: []net.Addr{
				testNetAddr("192.0.2.10/24"),
			},
		},
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("198.51.100.10/24"),
			},
		},
	})

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	candidates, err := gatherer.gather(context.Background(), WithPacketConn(conn))
	if err != nil {
		t.Fatalf("Gather wildcard: %v", err)
	}

	port := conn.LocalAddr().(*net.UDPAddr).AddrPort().Port()
	want := []Candidate{
		{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("198.51.100.10"), port)},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherContinuesPastInterfaceAddressErrorsForWildcardBinding(t *testing.T) {
	addrsErr := errors.New("interface addresses failed")
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags:    net.FlagUp,
			addrsErr: addrsErr,
		},
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("198.51.100.10/24"),
			},
		},
	})

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	candidates, err := gatherer.gather(context.Background(), WithPacketConn(conn))
	if err != nil {
		t.Fatalf("Gather wildcard: %v", err)
	}

	port := conn.LocalAddr().(*net.UDPAddr).AddrPort().Port()
	want := []Candidate{
		{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("198.51.100.10"), port)},
	}
	if !equalCandidates(candidates, want) {
		t.Fatalf("Gather = %#v, want %#v", candidates, want)
	}
}

func TestGatherReturnsInterfaceAddressErrorWhenNoWildcardInterfacesAreReadable(t *testing.T) {
	addrsErr := errors.New("interface addresses failed")
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags:    net.FlagUp,
			addrsErr: addrsErr,
		},
	})

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	candidates, err := gatherer.gather(context.Background(), WithPacketConn(conn))
	if !errors.Is(err, addrsErr) {
		t.Fatalf("Gather error = %v, want %v", err, addrsErr)
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

func TestGatherReturnsInterfaceAddressErrorWhenReadableWildcardInterfacesAreUnusable(t *testing.T) {
	addrsErr := errors.New("interface addresses failed")
	gatherer := testGathererWithInterfaces([]gatherInterface{
		{
			flags: net.FlagUp,
			addrs: []net.Addr{
				testNetAddr("127.0.0.1/8"),
			},
		},
		{
			flags:    net.FlagUp,
			addrsErr: addrsErr,
		},
	})

	serverConn := listenPacket(t, "127.0.0.1:0")
	go func() {
		_ = stun.NewServer().Serve(serverConn)
	}()

	conn := listenPacketNetwork(t, "udp4", "0.0.0.0:0")
	candidates, err := gatherer.gather(context.Background(), WithPacketConn(conn), WithSTUNServer(serverConn.LocalAddr()))
	if !errors.Is(err, addrsErr) {
		t.Fatalf("Gather error = %v, want %v", err, addrsErr)
	}
	if errors.Is(err, ErrNoCandidates) {
		t.Fatalf("Gather error = %v, want interface address error without %v", err, ErrNoCandidates)
	}
	if candidates != nil {
		t.Fatalf("Gather = %#v, want nil", candidates)
	}
}

type failingWritePacketConn struct {
	net.PacketConn
	err error
}

func (c failingWritePacketConn) WriteTo([]byte, net.Addr) (int, error) {
	return 0, c.err
}

func assertPacketConnStillUsable(t *testing.T, conn net.PacketConn) {
	t.Helper()

	probeConn := listenPacket(t, "127.0.0.1:0")
	if _, err := conn.WriteTo([]byte("still-open"), probeConn.LocalAddr()); err != nil {
		t.Fatalf("packet conn after STUN Gather WriteTo: %v", err)
	}

	payload := []byte("readable")
	if err := conn.SetReadDeadline(time.Now().Add(time.Second)); err != nil {
		t.Fatalf("packet conn after STUN Gather SetReadDeadline: %v", err)
	}
	t.Cleanup(func() {
		_ = conn.SetReadDeadline(time.Time{})
	})
	if _, err := probeConn.WriteTo(payload, conn.LocalAddr()); err != nil {
		t.Fatalf("probe packet conn WriteTo: %v", err)
	}

	buf := make([]byte, 64)
	n, _, err := conn.ReadFrom(buf)
	if err != nil {
		t.Fatalf("packet conn after STUN Gather ReadFrom: %v", err)
	}
	if got := string(buf[:n]); got != string(payload) {
		t.Fatalf("packet conn after STUN Gather ReadFrom = %q, want %q", got, payload)
	}
}

func serveMappedAddressOnce(t *testing.T, conn net.PacketConn, mapped netip.AddrPort) {
	t.Helper()

	errs := make(chan error, 1)
	go func() {
		buf := make([]byte, 1500)
		n, addr, err := conn.ReadFrom(buf)
		if err != nil {
			errs <- err
			return
		}
		if n < 20 {
			errs <- errors.New("short STUN request")
			return
		}
		response := buildTestBindingSuccess(buf[8:20], mapped)
		_, err = conn.WriteTo(response, addr)
		errs <- err
	}()

	t.Cleanup(func() {
		select {
		case err := <-errs:
			if err != nil && !errors.Is(err, net.ErrClosed) {
				t.Errorf("test STUN server: %v", err)
			}
		default:
		}
	})
}

func buildTestBindingSuccess(transactionID []byte, mapped netip.AddrPort) []byte {
	const (
		testSTUNMagicCookie    = 0x2112a442
		testBindingSuccessType = 0x0101
		testXORMappedAddress   = 0x0020
		testIPv4Family         = 0x01
		testIPv6Family         = 0x02
	)

	ip := mapped.Addr().Unmap()
	var attr []byte
	switch {
	case ip.Is4():
		attr = make([]byte, 12)
		binary.BigEndian.PutUint16(attr[2:4], 8)
		attr[5] = testIPv4Family
		binary.BigEndian.PutUint16(attr[6:8], mapped.Port()^uint16(testSTUNMagicCookie>>16))

		cookie := make([]byte, 4)
		binary.BigEndian.PutUint32(cookie, testSTUNMagicCookie)
		bytes := ip.As4()
		for i := range bytes {
			attr[8+i] = bytes[i] ^ cookie[i]
		}
	case ip.Is6():
		attr = make([]byte, 24)
		binary.BigEndian.PutUint16(attr[2:4], 20)
		attr[5] = testIPv6Family
		binary.BigEndian.PutUint16(attr[6:8], mapped.Port()^uint16(testSTUNMagicCookie>>16))

		var mask [16]byte
		binary.BigEndian.PutUint32(mask[0:4], testSTUNMagicCookie)
		copy(mask[4:], transactionID)
		bytes := ip.As16()
		for i := range bytes {
			attr[8+i] = bytes[i] ^ mask[i]
		}
	default:
		panic("unsupported test mapped address family")
	}
	binary.BigEndian.PutUint16(attr[0:2], testXORMappedAddress)

	msg := make([]byte, 20+len(attr))
	binary.BigEndian.PutUint16(msg[0:2], testBindingSuccessType)
	putTestUint16Length(msg[2:4], len(attr))
	binary.BigEndian.PutUint32(msg[4:8], testSTUNMagicCookie)
	copy(msg[8:20], transactionID)
	copy(msg[20:], attr)
	return msg
}

func testGathererWithInterfaces(interfaces []gatherInterface) candidateGatherer {
	gatherer := defaultCandidateGatherer()
	gatherer.interfaces = func() ([]gatherInterface, error) {
		return interfaces, nil
	}
	return gatherer
}

func testGathererWithReflexive(reflexive func(context.Context, net.PacketConn, net.Addr) (net.Addr, error)) candidateGatherer {
	gatherer := defaultCandidateGatherer()
	gatherer.reflexive = reflexive
	return gatherer
}

func hasUsableInterfaceAddress(t *testing.T) bool {
	t.Helper()

	interfaces, err := net.Interfaces()
	if err != nil {
		t.Fatalf("Interfaces: %v", err)
	}
	for _, iface := range interfaces {
		if iface.Flags&net.FlagUp == 0 {
			continue
		}
		addrs, err := iface.Addrs()
		if err != nil {
			t.Fatalf("Interface %q Addrs: %v", iface.Name, err)
		}
		for _, addr := range addrs {
			prefix, err := netip.ParsePrefix(addr.String())
			if err == nil && usableHostAddress(prefix.Addr()) {
				return true
			}
		}
	}
	return false
}

func putTestUint16Length(dst []byte, n int) {
	if n < 0 || n > 1<<16-1 {
		panic(fmt.Sprintf("test uint16 length %d out of range", n))
	}
	binary.BigEndian.PutUint16(dst, uint16(n)) // #nosec G115 -- test helper bounds n before encoding.
}
