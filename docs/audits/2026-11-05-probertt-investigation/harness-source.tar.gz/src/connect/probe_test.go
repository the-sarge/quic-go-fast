package connect

import (
	"bytes"
	"errors"
	"net/netip"
	"testing"
)

func TestEncodeProbeCandidateIPv4(t *testing.T) {
	tests := []struct {
		name      string
		candidate Candidate
		want      []byte
	}{
		{
			name: "host",
			candidate: Candidate{
				Kind: CandidateKindHost,
				Addr: mustAddrPort(t, "192.0.2.10:12345"),
			},
			want: []byte{0x01, 0x04, 192, 0, 2, 10, 0x30, 0x39},
		},
		{
			name: "reflexive",
			candidate: Candidate{
				Kind: CandidateKindReflexive,
				Addr: mustAddrPort(t, "198.51.100.40:54321"),
			},
			want: []byte{0x02, 0x04, 198, 51, 100, 40, 0xd4, 0x31},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := encodeProbeCandidate(tt.candidate)
			if err != nil {
				t.Fatalf("encodeProbeCandidate: %v", err)
			}
			if !bytes.Equal(got, tt.want) {
				t.Fatalf("encoded candidate = %x, want %x", got, tt.want)
			}
		})
	}
}

func TestEncodeProbeCandidateIPv6AndMappedAddresses(t *testing.T) {
	tests := []struct {
		name      string
		candidate Candidate
		want      []byte
	}{
		{
			name: "native IPv6",
			candidate: Candidate{
				Kind: CandidateKindHost,
				Addr: mustAddrPort(t, "[2001:db8::10]:12345"),
			},
			want: []byte{
				0x01, 0x06,
				0x20, 0x01, 0x0d, 0xb8,
				0x00, 0x00, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00,
				0x00, 0x00,
				0x00, 0x10,
				0x30, 0x39,
			},
		},
		{
			name: "IPv4 mapped",
			candidate: Candidate{
				Kind: CandidateKindReflexive,
				Addr: mustAddrPort(t, "[::ffff:198.51.100.40]:54321"),
			},
			want: []byte{0x02, 0x04, 198, 51, 100, 40, 0xd4, 0x31},
		},
		{
			name: "link local zone omitted",
			candidate: Candidate{
				Kind: CandidateKindHost,
				Addr: mustAddrPort(t, "[fe80::1%en0]:10000"),
			},
			want: []byte{
				0x01, 0x06,
				0xfe, 0x80, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00,
				0x00, 0x00,
				0x00, 0x01,
				0x27, 0x10,
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := encodeProbeCandidate(tt.candidate)
			if err != nil {
				t.Fatalf("encodeProbeCandidate: %v", err)
			}
			if !bytes.Equal(got, tt.want) {
				t.Fatalf("encoded candidate = %x, want %x", got, tt.want)
			}
		})
	}
}

func TestEncodeProbeCandidateRejectsInvalidProbeInputs(t *testing.T) {
	tests := []struct {
		name      string
		candidate Candidate
		wantErr   error
	}{
		{
			name: "relay candidate",
			candidate: Candidate{
				Kind: CandidateKindRelay,
				Addr: mustAddrPort(t, "192.0.2.10:12345"),
			},
			wantErr: errUnsupportedProbeCandidateKind,
		},
		{
			name: "zero port",
			candidate: Candidate{
				Kind: CandidateKindHost,
				Addr: mustAddrPort(t, "192.0.2.10:0"),
			},
			wantErr: errInvalidProbeCandidateAddress,
		},
		{
			name: "unspecified address",
			candidate: Candidate{
				Kind: CandidateKindHost,
				Addr: mustAddrPort(t, "0.0.0.0:12345"),
			},
			wantErr: errInvalidProbeCandidateAddress,
		},
		{
			name: "multicast address",
			candidate: Candidate{
				Kind: CandidateKindReflexive,
				Addr: mustAddrPort(t, "224.0.0.1:12345"),
			},
			wantErr: errInvalidProbeCandidateAddress,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := encodeProbeCandidate(tt.candidate)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("encodeProbeCandidate error = %v, want %v", err, tt.wantErr)
			}
		})
	}
}

func TestDeriveProbeKeyUsesDocumentedExporterContext(t *testing.T) {
	dialerNonce := bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes)
	listenerNonce := bytes.Repeat([]byte{0x22}, upgradeControlProbeNonceBytes)
	exporter := &recordingKeyExporter{
		output: bytes.Repeat([]byte{0xab}, probeKeyBytes),
	}

	got, err := deriveProbeKey(exporter, dialerNonce, listenerNonce)
	if err != nil {
		t.Fatalf("deriveProbeKey: %v", err)
	}
	if !bytes.Equal(got, exporter.output) {
		t.Fatalf("probe key = %x, want %x", got, exporter.output)
	}

	wantContext := append([]byte{0x01}, dialerNonce...)
	wantContext = append(wantContext, listenerNonce...)
	if exporter.label != "wiremux v1 probe-hmac" {
		t.Fatalf("exporter label = %q, want %q", exporter.label, "wiremux v1 probe-hmac")
	}
	if !bytes.Equal(exporter.context, wantContext) {
		t.Fatalf("exporter context = %x, want %x", exporter.context, wantContext)
	}
	if exporter.length != probeKeyBytes {
		t.Fatalf("exporter length = %d, want %d", exporter.length, probeKeyBytes)
	}
}

func TestDeriveProbeKeyRejectsInvalidInputs(t *testing.T) {
	validNonce := bytes.Repeat([]byte{0x11}, upgradeControlProbeNonceBytes)
	exporterErr := errors.New("exporter failed")

	tests := []struct {
		name          string
		exporter      KeyExporter
		dialerNonce   []byte
		listenerNonce []byte
		wantErr       error
	}{
		{
			name:          "short dialer nonce",
			exporter:      &recordingKeyExporter{output: bytes.Repeat([]byte{0xab}, probeKeyBytes)},
			dialerNonce:   validNonce[:len(validNonce)-1],
			listenerNonce: validNonce,
			wantErr:       errInvalidProbeNonce,
		},
		{
			name:          "short listener nonce",
			exporter:      &recordingKeyExporter{output: bytes.Repeat([]byte{0xab}, probeKeyBytes)},
			dialerNonce:   validNonce,
			listenerNonce: validNonce[:len(validNonce)-1],
			wantErr:       errInvalidProbeNonce,
		},
		{
			name:          "exporter failure",
			exporter:      &recordingKeyExporter{err: exporterErr},
			dialerNonce:   validNonce,
			listenerNonce: validNonce,
			wantErr:       exporterErr,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := deriveProbeKey(tt.exporter, tt.dialerNonce, tt.listenerNonce)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("deriveProbeKey error = %v, want %v", err, tt.wantErr)
			}
		})
	}
}

func TestProbeCandidatePairTokenGoldenVector(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	source := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")}
	destination := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.40:54321")}

	got, err := probeCandidatePairToken(key, probeDirectionDialerToListener, source, destination)
	if err != nil {
		t.Fatalf("probeCandidatePairToken: %v", err)
	}
	want := mustHex(t, "f543ac095e6378cb98552a8300d754de")
	if !bytes.Equal(got, want) {
		t.Fatalf("candidate-pair token = %x, want %x", got, want)
	}
}

func TestProbeCandidatePairTokenRejectsInvalidInputs(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	source := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")}
	destination := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.40:54321")}

	tests := []struct {
		name        string
		key         []byte
		direction   probeDirection
		source      Candidate
		destination Candidate
		wantErr     error
	}{
		{
			name:        "invalid key",
			key:         key[:len(key)-1],
			direction:   probeDirectionDialerToListener,
			source:      source,
			destination: destination,
			wantErr:     errInvalidProbeKey,
		},
		{
			name:        "invalid direction",
			key:         key,
			direction:   probeDirection(0xff),
			source:      source,
			destination: destination,
			wantErr:     errInvalidProbeDirection,
		},
		{
			name:        "invalid source",
			key:         key,
			direction:   probeDirectionDialerToListener,
			source:      Candidate{Kind: CandidateKindRelay, Addr: source.Addr},
			destination: destination,
			wantErr:     errUnsupportedProbeCandidateKind,
		},
		{
			name:        "invalid destination",
			key:         key,
			direction:   probeDirectionDialerToListener,
			source:      source,
			destination: Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "0.0.0.0:12345")},
			wantErr:     errInvalidProbeCandidateAddress,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := probeCandidatePairToken(tt.key, tt.direction, tt.source, tt.destination)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("probeCandidatePairToken error = %v, want %v", err, tt.wantErr)
			}
		})
	}
}

func TestEncodeProbeDatagramGoldenVectors(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	probeID := [probeIDBytes]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}
	dialerCandidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")}
	listenerCandidate := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.40:54321")}

	tests := []struct {
		name        string
		messageType probeMessageType
		direction   probeDirection
		source      Candidate
		destination Candidate
		want        []byte
	}{
		{
			name:        "request dialer to listener",
			messageType: probeMessageRequest,
			direction:   probeDirectionDialerToListener,
			source:      dialerCandidate,
			destination: listenerCandidate,
			want: mustHex(t,
				"574d58500101010102030405060708"+
					"f543ac095e6378cb98552a8300d754de"+
					"7360039d44a2c03cd865ac0bbc3b5078552bb4bf1ec59cf6285af4ae149f3101",
			),
		},
		{
			name:        "response listener to dialer",
			messageType: probeMessageResponse,
			direction:   probeDirectionListenerToDialer,
			source:      listenerCandidate,
			destination: dialerCandidate,
			want: mustHex(t,
				"574d58500102020102030405060708"+
					"4b8d795d18c854014f5c3f094f9d10bf"+
					"aacac47b978dd2f99e0f2dc0540ff5aacae3e761376fc2b823253544ec55fc53",
			),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := encodeProbeDatagram(key, tt.messageType, tt.direction, probeID, tt.source, tt.destination)
			if err != nil {
				t.Fatalf("encodeProbeDatagram: %v", err)
			}
			if len(got) != probeDatagramBytes {
				t.Fatalf("probe datagram length = %d, want %d", len(got), probeDatagramBytes)
			}
			if !bytes.Equal(got, tt.want) {
				t.Fatalf("probe datagram = %x, want %x", got, tt.want)
			}
		})
	}
}

func TestEncodeProbeDatagramRejectsInvalidInputs(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	probeID := [probeIDBytes]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}
	source := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")}
	destination := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.40:54321")}

	tests := []struct {
		name        string
		key         []byte
		messageType probeMessageType
		direction   probeDirection
		source      Candidate
		destination Candidate
		wantErr     error
	}{
		{
			name:        "invalid key",
			key:         key[:len(key)-1],
			messageType: probeMessageRequest,
			direction:   probeDirectionDialerToListener,
			source:      source,
			destination: destination,
			wantErr:     errInvalidProbeKey,
		},
		{
			name:        "invalid message type",
			key:         key,
			messageType: probeMessageType(0xff),
			direction:   probeDirectionDialerToListener,
			source:      source,
			destination: destination,
			wantErr:     errInvalidProbeMessageType,
		},
		{
			name:        "invalid direction",
			key:         key,
			messageType: probeMessageRequest,
			direction:   probeDirection(0xff),
			source:      source,
			destination: destination,
			wantErr:     errInvalidProbeDirection,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := encodeProbeDatagram(tt.key, tt.messageType, tt.direction, probeID, tt.source, tt.destination)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("encodeProbeDatagram error = %v, want %v", err, tt.wantErr)
			}
		})
	}
}

func TestAcceptProbeDatagramValidatesAuthenticatedPacket(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	probeID := [probeIDBytes]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}
	source := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")}
	destination := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.40:54321")}
	good, err := encodeProbeDatagram(key, probeMessageRequest, probeDirectionDialerToListener, probeID, source, destination)
	if err != nil {
		t.Fatalf("encodeProbeDatagram: %v", err)
	}

	tests := []struct {
		name           string
		datagram       []byte
		source         Candidate
		destination    Candidate
		observedSource netip.AddrPort
		wantOK         bool
	}{
		{
			name:           "valid",
			datagram:       good,
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
			wantOK:         true,
		},
		{
			name:           "truncated",
			datagram:       good[:len(good)-1],
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "trailing byte",
			datagram:       append(append([]byte(nil), good...), 0x00),
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "wrong magic",
			datagram:       tamperProbeDatagram(good, 0, 0x00),
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "wrong version",
			datagram:       tamperProbeDatagram(good, 4, 0x02),
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "wrong message type",
			datagram:       tamperProbeDatagram(good, 5, byte(probeMessageResponse)),
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "wrong direction",
			datagram:       tamperProbeDatagram(good, 6, byte(probeDirectionListenerToDialer)),
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "wrong token",
			datagram:       tamperProbeDatagram(good, 15, good[15]^0xff),
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "wrong tag",
			datagram:       tamperProbeDatagram(good, len(good)-1, good[len(good)-1]^0xff),
			source:         source,
			destination:    destination,
			observedSource: source.Addr,
		},
		{
			name:           "wrong observed source",
			datagram:       good,
			source:         source,
			destination:    destination,
			observedSource: mustAddrPort(t, "192.0.2.11:12345"),
		},
		{
			name:           "wrong candidate pair",
			datagram:       good,
			source:         Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.11:12345")},
			destination:    destination,
			observedSource: source.Addr,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, ok := acceptProbeDatagram(
				key,
				tt.datagram,
				probeMessageRequest,
				probeDirectionDialerToListener,
				tt.source,
				tt.destination,
				tt.observedSource,
			)
			if ok != tt.wantOK {
				t.Fatalf("acceptProbeDatagram ok = %v, want %v", ok, tt.wantOK)
			}
		})
	}
}

func TestAcceptProbeDatagramNormalizesObservedSource(t *testing.T) {
	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	probeID := [probeIDBytes]byte{0x09, 0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02}
	source := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[fe80::1]:12345")}
	destination := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[2001:db8::10]:54321")}
	datagram, err := encodeProbeDatagram(key, probeMessageRequest, probeDirectionDialerToListener, probeID, source, destination)
	if err != nil {
		t.Fatalf("encodeProbeDatagram: %v", err)
	}

	got, ok := acceptProbeDatagram(
		key,
		datagram,
		probeMessageRequest,
		probeDirectionDialerToListener,
		source,
		destination,
		mustAddrPort(t, "[fe80::1%en0]:12345"),
	)
	if !ok {
		t.Fatal("acceptProbeDatagram rejected observed source with local IPv6 zone")
	}
	if got.ProbeID != probeID {
		t.Fatalf("probe id = %x, want %x", got.ProbeID, probeID)
	}
}

type recordingKeyExporter struct {
	label   string
	context []byte
	length  int
	output  []byte
	err     error
	calls   int
}

func (e *recordingKeyExporter) Derive(label string, context []byte, length int) ([]byte, error) {
	e.calls++
	e.label = label
	e.context = append([]byte(nil), context...)
	e.length = length
	if e.err != nil {
		return nil, e.err
	}
	return append([]byte(nil), e.output...), nil
}

func tamperProbeDatagram(datagram []byte, offset int, value byte) []byte {
	tampered := append([]byte(nil), datagram...)
	tampered[offset] = value
	return tampered
}

// TestProbeEncodeCandidateRejectsZonedUnspecified pins the zone-stripping
// boundary at probeWireParams.encodeCandidate: the wire encoding is zone-less,
// and IsUnspecified compares with the zone included, so a zoned unspecified
// address must reject in both dialects rather than encode as all-zero bytes.
func TestProbeEncodeCandidateRejectsZonedUnspecified(t *testing.T) {
	zonedUnspecified := netip.AddrPortFrom(netip.MustParseAddr("::%eth0"), 9000)

	if _, err := v1ProbeWireParams().encodeCandidate(Candidate{Kind: CandidateKindHost, Addr: zonedUnspecified}); !errors.Is(err, errInvalidProbeCandidateAddress) {
		t.Fatalf("v1 host candidate: got %v, want errInvalidProbeCandidateAddress", err)
	}
	if _, err := turnRetryProbeWireParams().encodeCandidate(Candidate{Kind: CandidateKindRelay, Addr: zonedUnspecified}); !errors.Is(err, errInvalidProbeCandidateAddress) {
		t.Fatalf("turn-retry relay candidate: got %v, want errInvalidProbeCandidateAddress", err)
	}

	// A zoned non-unspecified address stays accepted and encodes the same
	// bytes as its zone-stripped form.
	zoned := Candidate{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("fe80::1%eth0"), 9000)}
	unzoned := Candidate{Kind: CandidateKindHost, Addr: netip.AddrPortFrom(netip.MustParseAddr("fe80::1"), 9000)}
	zonedEncoded, err := v1ProbeWireParams().encodeCandidate(zoned)
	if err != nil {
		t.Fatalf("zoned link-local candidate: %v", err)
	}
	unzonedEncoded, err := v1ProbeWireParams().encodeCandidate(unzoned)
	if err != nil {
		t.Fatalf("unzoned link-local candidate: %v", err)
	}
	if !bytes.Equal(zonedEncoded, unzonedEncoded) {
		t.Fatalf("zoned encoding = %x, want %x", zonedEncoded, unzonedEncoded)
	}
}
