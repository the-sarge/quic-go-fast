package connect

import (
	"context"
	"io"
	"net"
	"strconv"
	"sync"
	"time"

	"github.com/GridSwarm/wiremux/internal/packetownership"
)

type attemptOperationLifecycle uint8

const (
	attemptOperationUnregistered attemptOperationLifecycle = iota
	attemptOperationRunning
	attemptOperationComplete
	attemptOperationJoined
)

// packetClaimState is the selected packet-path disposition record for one
// upgrade attempt. The underlying borrowed direct conn remains caller/root
// owned until the root marker transfers; this claim owns only the disposition
// transitions, not the socket itself while borrowed.
type packetClaimState uint8

const (
	packetClaimBorrowed packetClaimState = iota
	packetClaimRawOwned
	packetClaimStreamOwned
	packetClaimSuccessTransferred
	packetClaimReleasedBorrow
	packetClaimDisposed
)

func (s packetClaimState) String() string {
	switch s {
	case packetClaimBorrowed:
		return "borrowed"
	case packetClaimRawOwned:
		return "raw-owned"
	case packetClaimStreamOwned:
		return "stream-owned"
	case packetClaimSuccessTransferred:
		return "success-transferred"
	case packetClaimReleasedBorrow:
		return "released-borrow"
	case packetClaimDisposed:
		return "disposed"
	default:
		return "packetClaimState(" + strconv.FormatUint(uint64(s), 10) + ")"
	}
}

type ownedDialOperation struct {
	cancel context.CancelFunc
	ready  chan struct{}
	done   chan transportStreamResult
	result transportStreamResult
}

type ownedListenOperation struct {
	cancel context.CancelFunc
	ready  chan struct{}
	done   chan transportListenResult
	result transportListenResult
}

type ownedAcceptOperation struct {
	cancel context.CancelFunc
	ready  chan struct{}
	done   chan transportAcceptResult
}

type attemptResources struct {
	strict          bool
	strictToken     *strictAttemptToken
	strictCallerCtx context.Context
	channel         io.ReadWriteCloser
	packetConn      net.PacketConn

	mu       sync.Mutex
	session  Session
	listener TransportListener
	stream   io.ReadWriteCloser
	dial     *ownedDialOperation
	listen   *ownedListenOperation
	accept   *ownedAcceptOperation

	dialState   attemptOperationLifecycle
	listenState attemptOperationLifecycle
	acceptState attemptOperationLifecycle

	acceptResult      transportAcceptResult
	acceptResultSet   bool
	committed         bool
	transfer          packetownership.Marker
	claim             packetClaimState
	dialSessionClosed bool
	listenerClosed    bool

	// ownedComposite marks a claim whose packetConn is an owned relay
	// composite. Terminal paths for such claims invoke the composite's Close
	// before awaiting any operation join that can depend on the composite's
	// socket (rebaseline #1066): logical deadlines and context cancellation
	// cannot wake work blocked in composite I/O.
	ownedComposite bool

	// compositeDisposed guards the single engine-driven precommit disposal of
	// an owned composite.
	compositeDisposed bool

	terminalSealed      bool
	terminalDone        chan struct{}
	terminalDisposition attemptTerminalDispositionKind
	terminalState       attemptTerminalStateClass
	terminalControl     failClosedControlDisposition
	terminalCause       error
	terminalResult      UpgradeResult
	terminalErr         error
}

func newAttemptResources(
	channel io.ReadWriteCloser,
	packetConn net.PacketConn,
	markers ...packetownership.Marker,
) *attemptResources {
	marker := packetownership.NewMarker()
	if len(markers) != 0 {
		marker = markers[0]
	}
	return &attemptResources{
		channel:      channel,
		packetConn:   packetConn,
		transfer:     marker,
		claim:        packetClaimBorrowed,
		terminalDone: make(chan struct{}),
	}
}

// newOwnedTURNPathClaim constructs a selected-path claim that starts raw-owned
// without marking any root direct-transfer marker. Slice 2.1 keeps this
// constructor unreachable from production upgrade dispatch; Slice 2.3 is the
// first production consumer.
func newOwnedTURNPathClaim(
	channel io.ReadWriteCloser,
	packetConn net.PacketConn,
	markers ...packetownership.Marker,
) *attemptResources {
	marker := packetownership.NewMarker()
	if len(markers) != 0 {
		marker = markers[0]
	}
	return &attemptResources{
		channel:        channel,
		packetConn:     packetConn,
		transfer:       marker,
		claim:          packetClaimRawOwned,
		ownedComposite: true,
		terminalDone:   make(chan struct{}),
	}
}

func (a directUpgradeAttempt) resources() *attemptResources {
	if a.owner == nil {
		panic("connect: directUpgradeAttempt owner is not initialized")
	}
	return a.owner
}

// selectedPacketConn returns the attempt's selected packet socket. Configured
// option storage remains on upgradeConfig for validation; lifecycle authority
// is the selected-path claim, not that raw config field.
func (a directUpgradeAttempt) selectedPacketConn() net.PacketConn {
	return a.resources().packetConn
}

func (r *attemptResources) registerSession(session Session) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.terminalSealed {
		return false
	}
	if session != nil {
		r.session = session
	}
	return session != nil
}

func (r *attemptResources) registerCommit() {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.terminalSealed {
		return
	}
	r.committed = true
	if r.transfer.Transferred() {
		return
	}
	r.transfer.MarkTransferred()
	if r.claim == packetClaimStreamOwned {
		return
	}
	r.claim = packetClaimRawOwned
}

func (r *attemptResources) startDial(
	ctx context.Context,
	session Session,
	conn net.PacketConn,
	remote net.Addr,
	remoteMaterial []byte,
) <-chan transportStreamResult {
	operationCtx, cancel := context.WithCancel(ctx)
	operation := &ownedDialOperation{
		cancel: cancel,
		ready:  make(chan struct{}),
		done:   make(chan transportStreamResult, 1),
	}
	r.mu.Lock()
	r.requirePublicationOpenLocked()
	r.session = session
	r.dial = operation
	r.dialState = attemptOperationRunning
	r.mu.Unlock()

	go func() {
		defer cancel()
		stream, err := session.Dial(operationCtx, conn, remote, remoteMaterial)
		if r.strict {
			err = r.strictOwnedOperationCause(operationCtx, err)
		}
		result := newTransportStreamResult(stream, err)
		r.mu.Lock()
		operation.result = result
		if result.stream != nil {
			r.stream = result.stream
		}
		r.recordTransportResultLocked(result)
		r.dialState = attemptOperationComplete
		r.mu.Unlock()
		operation.done <- result
		close(operation.ready)
	}()
	return operation.done
}

func (r *attemptResources) startListen(
	ctx context.Context,
	session Session,
	conn net.PacketConn,
	remote net.Addr,
	remoteMaterial []byte,
) <-chan transportListenResult {
	operationCtx, cancel := context.WithCancel(ctx)
	operation := &ownedListenOperation{
		cancel: cancel,
		ready:  make(chan struct{}),
		done:   make(chan transportListenResult, 1),
	}
	r.mu.Lock()
	r.requirePublicationOpenLocked()
	r.session = session
	r.listen = operation
	r.listenState = attemptOperationRunning
	r.mu.Unlock()

	go func() {
		defer cancel()
		listener, err := session.Listen(operationCtx, conn, remote, remoteMaterial)
		if r.strict {
			err = r.strictOwnedOperationCause(operationCtx, err)
		}
		result := transportListenResult{listener: listener, err: err}
		if result.err == nil && result.listener == nil {
			result.err = errNilTransportListener
			if r.strict {
				result.err = r.strictCause(UpgradeErrorLocal, result.err)
			}
		}
		r.mu.Lock()
		operation.result = result
		if result.listener != nil {
			r.listener = result.listener
		}
		r.listenState = attemptOperationComplete
		r.mu.Unlock()
		operation.done <- result
		close(operation.ready)
	}()
	return operation.done
}

func (r *attemptResources) startAccept(
	ctx context.Context,
	listener TransportListener,
) (context.CancelFunc, <-chan transportAcceptResult) {
	operationCtx, cancel := context.WithCancel(ctx)
	operation := &ownedAcceptOperation{
		cancel: cancel,
		ready:  make(chan struct{}),
		done:   make(chan transportAcceptResult, 1),
	}
	r.mu.Lock()
	r.requirePublicationOpenLocked()
	r.listener = listener
	r.accept = operation
	r.acceptState = attemptOperationRunning
	r.mu.Unlock()

	go func() {
		stream, err := listener.Accept(operationCtx)
		if r.strict {
			err = r.strictOwnedOperationCause(operationCtx, err)
		}
		result := newTransportStreamResult(stream, err)
		if classifyTransportStreamResult(result) == transportStreamResultNoMaterialization && result.err == nil {
			result.err = errNilTransportStream
			if r.strict {
				result.err = r.strictCause(UpgradeErrorLocal, result.err)
			}
		}
		r.mu.Lock()
		r.acceptResult = result
		r.acceptResultSet = true
		if result.stream != nil {
			r.stream = result.stream
		}
		r.recordTransportResultLocked(result)
		r.acceptState = attemptOperationComplete
		r.mu.Unlock()
		operation.done <- result
		close(operation.ready)
	}()
	return cancel, operation.done
}

func (r *attemptResources) requirePublicationOpenLocked() {
	if r.terminalSealed {
		panic("connect: attempt resource publication is sealed")
	}
}

func (r *attemptResources) recordTransportResultLocked(result transportStreamResult) {
	if classifyTransportStreamResult(result) != transportStreamResultNoMaterialization {
		if !r.transfer.Transferred() {
			r.transfer.MarkTransferred()
		}
		r.claim = packetClaimStreamOwned
		return
	}
	if r.transfer.Transferred() && r.claim == packetClaimBorrowed {
		r.claim = packetClaimRawOwned
	}
}

func (r *attemptResources) closeCommittedPacketConn() {
	if r.packetConn != nil {
		_ = r.packetConn.Close()
	}
}

func (r *attemptResources) abortControlExchange() {
	now := time.Now()
	if deadliner, ok := r.channel.(interface{ SetDeadline(time.Time) error }); ok {
		_ = deadliner.SetDeadline(now)
	}
	if readDeadliner, ok := r.channel.(interface{ SetReadDeadline(time.Time) error }); ok {
		_ = readDeadliner.SetReadDeadline(now)
	}
	if writeDeadliner, ok := r.channel.(interface{ SetWriteDeadline(time.Time) error }); ok {
		_ = writeDeadliner.SetWriteDeadline(now)
	}
	_ = r.channel.Close()
}

func (r *attemptResources) closeDirectUpgradeRelay() {
	if closer, ok := r.channel.(directUpgradeSuccessCloser); ok {
		_ = closer.CloseAfterDirectUpgradeSuccess()
		return
	}
	_ = r.channel.Close()
}

type directUpgradeSuccessCloser interface {
	// CloseAfterDirectUpgradeSuccess is an optional relay-channel hook. When a
	// direct upgrade succeeds, Upgrade calls this instead of Close so wrappers
	// can perform post-success work that still needs the obsolete relay path.
	CloseAfterDirectUpgradeSuccess() error
}
