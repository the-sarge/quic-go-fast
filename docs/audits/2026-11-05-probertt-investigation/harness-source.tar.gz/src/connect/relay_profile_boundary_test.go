package connect

import (
	"context"
	"errors"
	"net"
	"net/netip"
	"testing"

	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// relayMarkedPacketConn is an in-module fake bearing the official relay
// packet marker, with write/close observers proving zero output and
// preserved caller ownership at rejecting boundaries.
type relayMarkedPacketConn struct {
	discardTestPacketConn
	closeCalls int
	writeCalls int
}

func (c *relayMarkedPacketConn) WiremuxRelayProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3()
}

func (c *relayMarkedPacketConn) Close() error {
	c.closeCalls++
	return nil
}

func (c *relayMarkedPacketConn) WriteTo(packet []byte, _ net.Addr) (int, error) {
	c.writeCalls++
	return len(packet), nil
}

func newRelayMarkedPacketConn() *relayMarkedPacketConn {
	return &relayMarkedPacketConn{
		discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:40000")},
	}
}

func TestGatherRejectsRelayProfileComposite(t *testing.T) {
	conn := newRelayMarkedPacketConn()

	candidates, err := Gather(context.Background(), WithPacketConn(conn))
	if !errors.Is(err, ErrRelayProfileDirectPath) {
		t.Fatalf("Gather error = %v, want %v", err, ErrRelayProfileDirectPath)
	}
	if len(candidates) != 0 {
		t.Fatalf("Gather candidates = %d, want 0", len(candidates))
	}
	if conn.writeCalls != 0 {
		t.Fatalf("Gather wrote %d packets through a rejected composite, want 0", conn.writeCalls)
	}
	if conn.closeCalls != 0 {
		t.Fatalf("Gather closed the caller-owned composite %d times, want 0", conn.closeCalls)
	}
}

func TestUpgradeOptionsRejectRelayProfileComposite(t *testing.T) {
	conn := newRelayMarkedPacketConn()

	err := ValidateUpgradeOptions(WithTransport(&fakeTransport{}), WithUpgradePacketConn(conn))
	if !errors.Is(err, ErrRelayProfileDirectPath) {
		t.Fatalf("ValidateUpgradeOptions error = %v, want %v", err, ErrRelayProfileDirectPath)
	}
	if conn.writeCalls != 0 || conn.closeCalls != 0 {
		t.Fatalf("rejected composite observed writes=%d closes=%d, want 0/0", conn.writeCalls, conn.closeCalls)
	}
}

func TestUpgradeOptionsRejectRelayProfileCompositeWithoutTransport(t *testing.T) {
	conn := newRelayMarkedPacketConn()

	err := ValidateUpgradeOptions(WithUpgradePacketConn(conn))
	if !errors.Is(err, ErrRelayProfileDirectPath) {
		t.Fatalf("ValidateUpgradeOptions error = %v, want %v", err, ErrRelayProfileDirectPath)
	}
}
