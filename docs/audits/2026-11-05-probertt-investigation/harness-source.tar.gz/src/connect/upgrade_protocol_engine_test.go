package connect

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net/netip"
	"reflect"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

type managedListenerPostCommitFixture struct {
	engine  directUpgradeProtocolEngine
	runtime *directUpgradeProtocolRuntime
	channel *scriptedControlChannel
	stream  *terminalTestStream
	rows    *[]directUpgradeListenerRow
}

func newManagedListenerPostCommitFixture(
	t *testing.T,
	frames []controlFrameReadResult,
	datagrams DatagramCarrier,
) managedListenerPostCommitFixture {
	t.Helper()
	channel := newScriptedControlChannel(nil, false)
	packetConn := &terminalTestPacketConn{}
	attempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       channel,
		controlFrames: newBufferedControlFrameSequencer(frames...),
		cfg:           upgradeConfig{packetConn: packetConn, probeTimeout: time.Second},
	})
	session := &terminalTestSession{}
	listener := &terminalTestDefinitiveAcceptListener{}
	stream := &terminalTestStream{}
	registerCompletedTestAcceptAttempt(attempt.resources(), session, listener, transportAcceptResult{stream: stream, datagrams: datagrams})
	attempt.resources().registerCommit()
	acceptResult := attempt.resources().snapshot().acceptResult
	cursor := newDirectUpgradeProtocolCursor(upgradeRoleListen, directUpgradeProtocolStatePostCommitStart)
	rows := make([]directUpgradeListenerRow, 0, 1)
	engine := directUpgradeProtocolEngine{
		role:              upgradeRoleListen,
		attempt:           attempt,
		cursor:            &cursor,
		testListenerTrace: func(row directUpgradeListenerRow) { rows = append(rows, row) },
	}
	runtime := &directUpgradeProtocolRuntime{
		selected: selectedPair{
			dialer:   Candidate{Kind: CandidateKindHost},
			listener: Candidate{Kind: CandidateKindHost},
		},
		acceptResult:   acceptResult,
		transport:      acceptResult,
		transportReady: true,
	}
	return managedListenerPostCommitFixture{
		engine:  engine,
		runtime: runtime,
		channel: channel,
		stream:  stream,
		rows:    &rows,
	}
}

func TestListenerEnginePostCommitHappyPathUsesManagedOwner(t *testing.T) {
	convergedFrame, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseConverged, false)
	if err != nil {
		t.Fatalf("encode converged frame: %v", err)
	}
	fixture := newManagedListenerPostCommitFixture(t, []controlFrameReadResult{{payload: convergedFrame[4:]}}, nil)

	result, err := fixture.engine.runListenerPostCommit(context.Background(), fixture.runtime)
	if err != nil || result.Path != UpgradePathDirect || result.Stream == nil {
		t.Fatalf("managed listener result = %#v, %v; want direct stream", result, err)
	}
	if !reflect.DeepEqual(*fixture.rows, []directUpgradeListenerRow{directUpgradeListenerRowL41}) {
		t.Fatalf("managed listener rows = %v, want [%s]", *fixture.rows, directUpgradeListenerRowL41)
	}
	acceptedFrame, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseAccepted, false)
	if err != nil {
		t.Fatalf("encode accepted frame: %v", err)
	}
	confirmedFrame, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseConfirmed, false)
	if err != nil {
		t.Fatalf("encode confirmed frame: %v", err)
	}
	fixture.channel.mu.Lock()
	written := append([]byte(nil), fixture.channel.writes.Bytes()...)
	fixture.channel.mu.Unlock()
	wantWritten := append(append([]byte(nil), acceptedFrame...), confirmedFrame...)
	if !reflect.DeepEqual(written, wantWritten) {
		t.Fatalf("managed listener writes = %x, want %x", written, wantWritten)
	}
	if err := result.Stream.Close(); err != nil {
		t.Fatalf("close direct stream: %v", err)
	}
}

func TestListenerEnginePostCommitDatagramAgreementUsesManagedOwner(t *testing.T) {
	tests := []struct {
		name          string
		local         DatagramCarrier
		peer          bool
		wantDatagrams bool
		wantRow       directUpgradeListenerRow
		wantErr       error
	}{
		{
			name:          "agrees present",
			local:         &stubDatagramCarrier{maxPayload: 1240, lifetime: openDatagramLifetime(t)},
			peer:          true,
			wantDatagrams: true,
			wantRow:       directUpgradeListenerRowL41,
		},
		{
			name:    "rejects peer presence after local absence",
			peer:    true,
			wantRow: directUpgradeListenerRowL37,
			wantErr: errDatagramExposureAgreementMismatch,
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			convergedFrame, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseConverged, test.peer)
			if err != nil {
				t.Fatalf("encode converged frame: %v", err)
			}
			fixture := newManagedListenerPostCommitFixture(t, []controlFrameReadResult{{payload: convergedFrame[4:]}}, test.local)

			result, err := fixture.engine.runListenerPostCommit(context.Background(), fixture.runtime)
			if test.wantErr != nil {
				if result != (UpgradeResult{}) || !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, test.wantErr) {
					t.Fatalf("managed listener result = %#v, %v; want zero with transport-not-converged and %v", result, err, test.wantErr)
				}
			} else {
				if err != nil || result.Path != UpgradePathDirect || result.Stream == nil {
					t.Fatalf("managed listener result = %#v, %v; want direct stream", result, err)
				}
				if got := result.Datagrams != nil; got != test.wantDatagrams {
					t.Fatalf("managed listener Datagrams present = %t, want %t", got, test.wantDatagrams)
				}
				if err := result.Stream.Close(); err != nil {
					t.Fatalf("close direct stream: %v", err)
				}
			}
			if !reflect.DeepEqual(*fixture.rows, []directUpgradeListenerRow{test.wantRow}) {
				t.Fatalf("managed listener rows = %v, want [%s]", *fixture.rows, test.wantRow)
			}
			acceptedFrame, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseAccepted, test.local != nil)
			if err != nil {
				t.Fatalf("encode accepted frame: %v", err)
			}
			fixture.channel.mu.Lock()
			written := append([]byte(nil), fixture.channel.writes.Bytes()...)
			fixture.channel.mu.Unlock()
			wantWritten := acceptedFrame
			if test.wantErr == nil {
				confirmedFrame, encodeErr := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseConfirmed, test.wantDatagrams)
				if encodeErr != nil {
					t.Fatalf("encode confirmed frame: %v", encodeErr)
				}
				wantWritten = append(append([]byte(nil), acceptedFrame...), confirmedFrame...)
			}
			if !reflect.DeepEqual(written, wantWritten) {
				t.Fatalf("managed listener writes = %x, want %x", written, wantWritten)
			}
		})
	}
}

func TestDirectUpgradeProtocolEngineRunRejectsIncompleteManagedState(t *testing.T) {
	newCursor := func(role upgradeRole) *directUpgradeProtocolCursor {
		cursor := newDirectUpgradeProtocolCursor(role, directUpgradeProtocolStatePostCommitStart)
		return &cursor
	}
	newRuntime := func() *directUpgradeProtocolRuntime {
		return &directUpgradeProtocolRuntime{postCommitCtx: context.Background()}
	}
	tests := []struct {
		name   string
		engine directUpgradeProtocolEngine
	}{
		{name: "unknown role", engine: directUpgradeProtocolEngine{role: upgradeRole(99), cursor: newCursor(upgradeRole(99)), runtime: newRuntime()}},
		{name: "dialer missing cursor", engine: directUpgradeProtocolEngine{role: upgradeRoleDial, runtime: newRuntime()}},
		{name: "dialer missing runtime", engine: directUpgradeProtocolEngine{role: upgradeRoleDial, cursor: newCursor(upgradeRoleDial)}},
		{name: "listener missing cursor", engine: directUpgradeProtocolEngine{role: upgradeRoleListen, runtime: newRuntime()}},
		{name: "listener missing runtime", engine: directUpgradeProtocolEngine{role: upgradeRoleListen, cursor: newCursor(upgradeRoleListen)}},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			engine := test.engine
			engine.testPostCommitIO.send = func(context.Context, upgradeControlPhase, bool) error {
				t.Fatal("incomplete engine reached post-commit send")
				return nil
			}
			engine.testPostCommitIO.await = func(context.Context, upgradeControlPhase) (controlFrameReadResult, error) {
				t.Fatal("incomplete engine reached post-commit await")
				return controlFrameReadResult{}, nil
			}

			result, err := engine.run(context.Background(), context.Background())
			if !errors.Is(err, errUnexpectedPostCommitPhaseOrder) {
				t.Fatalf("run error = %v, want unexpected phase order", err)
			}
			if result != (UpgradeResult{}) {
				t.Fatalf("run result = %#v, want zero result", result)
			}
		})
	}

	for _, missing := range []string{"cursor", "runtime"} {
		t.Run("managed listener missing "+missing+" settles owner", func(t *testing.T) {
			fixture := newManagedListenerPostCommitFixture(t, nil, nil)
			fixture.engine.runtime = fixture.runtime
			switch missing {
			case "cursor":
				fixture.engine.cursor = nil
			case "runtime":
				fixture.engine.runtime = nil
			default:
				t.Fatalf("unknown missing state %q", missing)
			}
			fixture.engine.testPostCommitIO.send = func(context.Context, upgradeControlPhase, bool) error {
				t.Fatal("incomplete managed engine reached post-commit send")
				return nil
			}
			fixture.engine.testPostCommitIO.await = func(context.Context, upgradeControlPhase) (controlFrameReadResult, error) {
				t.Fatal("incomplete managed engine reached post-commit await")
				return controlFrameReadResult{}, nil
			}

			result, err := fixture.engine.run(context.Background(), context.Background())
			if !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, errUnexpectedPostCommitPhaseOrder) {
				t.Fatalf("run error = %v, want transport-not-converged with unexpected phase order", err)
			}
			if result != (UpgradeResult{}) {
				t.Fatalf("run result = %#v, want zero result", result)
			}
			if got := fixture.stream.closeCalls.Load(); got != 1 {
				t.Fatalf("accepted stream close count = %d, want 1", got)
			}
			owner := fixture.engine.attempt.resources()
			owner.mu.Lock()
			sealed := owner.terminalSealed
			disposition := owner.terminalDisposition
			control := owner.terminalControl
			terminalResult := owner.terminalResult
			terminalErr := owner.terminalErr
			owner.mu.Unlock()
			if !sealed || disposition != attemptTerminalFailClosed || control != abortAfterOwnedResources {
				t.Fatalf("terminal owner = (sealed %t, disposition %v, control %v), want sealed fail-closed/abort-after", sealed, disposition, control)
			}
			if terminalResult != (UpgradeResult{}) {
				t.Fatalf("terminal result = %#v, want zero result", terminalResult)
			}
			if !errors.Is(terminalErr, ErrUpgradeTransportNotConverged) || !errors.Is(terminalErr, errUnexpectedPostCommitPhaseOrder) {
				t.Fatalf("terminal error = %v, want transport-not-converged with unexpected phase order", terminalErr)
			}
		})
	}
}

func TestListenerEnginePostCommitRejectsInvalidPeerInputWithManagedOwner(t *testing.T) {
	frameErr := errors.New("frame read failed")
	fallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("encode fallback: %v", err)
	}
	wrongPhaseFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseAccepted)
	if err != nil {
		t.Fatalf("encode wrong phase: %v", err)
	}
	tests := []struct {
		name      string
		frame     controlFrameReadResult
		wantRow   directUpgradeListenerRow
		wantCause error
	}{
		{name: "peer fallback", frame: controlFrameReadResult{payload: fallbackFrame[4:]}, wantRow: directUpgradeListenerRowL36, wantCause: ErrUpgradeTransportNotConverged},
		{name: "wrong phase", frame: controlFrameReadResult{payload: wrongPhaseFrame[4:]}, wantRow: directUpgradeListenerRowL36, wantCause: ErrUpgradeTransportNotConverged},
		{name: "frame error", frame: controlFrameReadResult{err: frameErr}, wantRow: directUpgradeListenerRowL35, wantCause: frameErr},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			fixture := newManagedListenerPostCommitFixture(t, []controlFrameReadResult{test.frame}, nil)

			result, err := fixture.engine.runListenerPostCommit(context.Background(), fixture.runtime)
			if result != (UpgradeResult{}) || !errors.Is(err, ErrUpgradeTransportNotConverged) || !errors.Is(err, test.wantCause) {
				t.Fatalf("managed listener result = %#v, %v; want zero with transport-not-converged and %v", result, err, test.wantCause)
			}
			if !reflect.DeepEqual(*fixture.rows, []directUpgradeListenerRow{test.wantRow}) {
				t.Fatalf("managed listener rows = %v, want [%s]", *fixture.rows, test.wantRow)
			}
			if got := fixture.stream.closeCalls.Load(); got != 1 {
				t.Fatalf("managed listener Stream.Close calls = %d, want 1", got)
			}
		})
	}
}

func TestListenerEnginePostCommitPrefersCallerContextWithManagedOwner(t *testing.T) {
	callerCtx, cancelCaller := context.WithCancel(context.Background())
	cancelCaller()
	postCommitCtx, cancelPostCommit := context.WithTimeout(context.Background(), time.Nanosecond)
	defer cancelPostCommit()
	time.Sleep(time.Millisecond)
	fixture := newManagedListenerPostCommitFixture(t, nil, nil)
	fixture.runtime.postCommitCtx = postCommitCtx
	fixture.engine.runtime = fixture.runtime

	result, err := fixture.engine.run(postCommitCtx, callerCtx)
	if result != (UpgradeResult{}) || !errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("managed listener result = %#v, %v; want caller cancellation only", result, err)
	}
	if !reflect.DeepEqual(*fixture.rows, []directUpgradeListenerRow{directUpgradeListenerRowL39}) {
		t.Fatalf("managed listener rows = %v, want [%s]", *fixture.rows, directUpgradeListenerRowL39)
	}
}

func TestListenerEnginePostCommitAwaitPhasePrefersCallerContextWithManagedOwner(t *testing.T) {
	callerCtx := newManualTestContext()
	postCommitCtx := newManualTestContext()
	fixture := newManagedListenerPostCommitFixture(t, nil, nil)
	fixture.runtime.postCommitCtx = postCommitCtx
	fixture.engine.runtime = fixture.runtime
	fixture.engine.testPostCommitIO.send = func(context.Context, upgradeControlPhase, bool) error { return nil }
	awaitStarted := make(chan struct{})
	fixture.engine.testPostCommitIO.await = func(ctx context.Context, phase upgradeControlPhase) (controlFrameReadResult, error) {
		if phase != upgradeControlPhaseConverged {
			t.Fatalf("await phase = %v, want converged", phase)
		}
		close(awaitStarted)
		<-ctx.Done()
		return controlFrameReadResult{}, ctx.Err()
	}
	type engineOutcome struct {
		result UpgradeResult
		err    error
	}
	done := make(chan engineOutcome, 1)
	go func() {
		result, err := fixture.engine.run(postCommitCtx, callerCtx)
		done <- engineOutcome{result: result, err: err}
	}()
	<-awaitStarted
	callerCtx.cancel(context.Canceled)
	postCommitCtx.cancel(context.DeadlineExceeded)
	outcome := <-done
	if outcome.result != (UpgradeResult{}) || !errors.Is(outcome.err, context.Canceled) || errors.Is(outcome.err, context.DeadlineExceeded) {
		t.Fatalf("managed listener result = %#v, %v; want caller cancellation only", outcome.result, outcome.err)
	}
	if !reflect.DeepEqual(*fixture.rows, []directUpgradeListenerRow{directUpgradeListenerRowL39}) {
		t.Fatalf("managed listener rows = %v, want [%s]", *fixture.rows, directUpgradeListenerRowL39)
	}
}

func TestListenerEnginePostCommitConfirmedCompletionWinsContextWithManagedOwner(t *testing.T) {
	callerCtx := newManualTestContext()
	postCommitCtx := newManualTestContext()
	fixture := newManagedListenerPostCommitFixture(t, nil, nil)
	fixture.runtime.postCommitCtx = postCommitCtx
	fixture.engine.runtime = fixture.runtime
	fixture.engine.testPostCommitIO.send = func(_ context.Context, phase upgradeControlPhase, _ bool) error {
		if phase == upgradeControlPhaseConfirmed {
			callerCtx.cancel(context.Canceled)
			postCommitCtx.cancel(context.DeadlineExceeded)
		}
		return nil
	}
	fixture.engine.testPostCommitIO.await = func(_ context.Context, phase upgradeControlPhase) (controlFrameReadResult, error) {
		if phase != upgradeControlPhaseConverged {
			t.Fatalf("await phase = %v, want converged", phase)
		}
		return controlFrameReadResult{payload: postCommitPhasePayload(t, upgradeControlPhaseConverged)}, nil
	}

	result, err := fixture.engine.run(postCommitCtx, callerCtx)
	if err != nil || result.Path != UpgradePathDirect || result.Stream == nil {
		t.Fatalf("managed listener result = %#v, %v; want direct stream", result, err)
	}
	if !reflect.DeepEqual(*fixture.rows, []directUpgradeListenerRow{directUpgradeListenerRowL41}) {
		t.Fatalf("managed listener rows = %v, want [%s]", *fixture.rows, directUpgradeListenerRowL41)
	}
	if err := result.Stream.Close(); err != nil {
		t.Fatalf("close direct stream: %v", err)
	}
}

func TestListenerPostCommitCompletedWriteWinsCancellation(t *testing.T) {
	callerCtx, cancelCaller := context.WithCancel(context.Background())
	defer cancelCaller()
	convergedFrame, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseConverged, false)
	if err != nil {
		t.Fatalf("encode converged frame: %v", err)
	}
	acceptedFrame, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseAccepted, false)
	if err != nil {
		t.Fatalf("encode accepted frame: %v", err)
	}
	confirmedFrame, err := encodeUpgradeControlPostCommitPhase(upgradeControlPhaseConfirmed, false)
	if err != nil {
		t.Fatalf("encode confirmed frame: %v", err)
	}
	fixture := newManagedListenerPostCommitFixture(t, []controlFrameReadResult{{payload: convergedFrame[4:]}}, nil)
	// The production writer completes the Confirmed frame on the control
	// channel as the caller context, and with it the owned post-commit
	// budget context, become done. The completed write counts as sent (D1),
	// so the listener ends direct beside the dialer that received Confirmed
	// instead of failing closed alone.
	fixture.channel.writeScript = func(p []byte) (int, error) {
		n, writeErr := fixture.channel.writeBuffered(p)
		if bytes.Equal(p, confirmedFrame) {
			cancelCaller()
		}
		return n, writeErr
	}

	result, err := fixture.engine.runListenerPostCommit(callerCtx, fixture.runtime)
	if err != nil || result.Path != UpgradePathDirect || result.Stream == nil {
		t.Fatalf("managed listener result = %#v, %v; want direct stream", result, err)
	}
	if !reflect.DeepEqual(*fixture.rows, []directUpgradeListenerRow{directUpgradeListenerRowL41}) {
		t.Fatalf("managed listener rows = %v, want [%s]", *fixture.rows, directUpgradeListenerRowL41)
	}
	fixture.channel.mu.Lock()
	written := append([]byte(nil), fixture.channel.writes.Bytes()...)
	fixture.channel.mu.Unlock()
	wantWritten := append(append([]byte(nil), acceptedFrame...), confirmedFrame...)
	if !bytes.Equal(written, wantWritten) {
		t.Fatalf("managed listener writes = %x, want %x", written, wantWritten)
	}
	if err := result.Stream.Close(); err != nil {
		t.Fatalf("close direct stream: %v", err)
	}

	// The peer dialer that receives exactly the bytes the listener published
	// at cancellation ends direct too through its ordinary Confirmed path
	// (D22), so the pair converges instead of splitting at the final
	// Confirmed write.
	dialerChannel := newScriptedControlChannel(written[len(acceptedFrame):], false)
	dialerPacketConn := &terminalTestPacketConn{discardTestPacketConn: discardTestPacketConn{local: netip.MustParseAddrPort("127.0.0.1:44101")}}
	dialerAttempt := newTestDirectUpgradeAttempt(directUpgradeAttempt{
		channel:       dialerChannel,
		controlFrames: newControlFrameSequencer(dialerChannel),
		cfg:           upgradeConfig{packetConn: dialerPacketConn, controlTimeout: time.Second},
	})
	dialerCursor := newDirectUpgradeProtocolCursor(upgradeRoleDial, directUpgradeProtocolStatePostCommitConverged)
	dialerRows := make([]directUpgradeDialerRow, 0, 1)
	dialer := directUpgradeProtocolEngine{
		role:    upgradeRoleDial,
		attempt: dialerAttempt,
		session: &terminalTestSession{},
		selected: selectedPair{
			dialer:   Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:44101")},
			listener: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("127.0.0.1:44102")},
		},
		cursor:          &dialerCursor,
		testDialerTrace: func(row directUpgradeDialerRow) { dialerRows = append(dialerRows, row) },
	}
	dialerTransport := postCommitTransportResult{stream: &terminalTestStream{packetConn: dialerPacketConn}}
	seedCompletedDialerOwnerForTest(dialerAttempt.resources(), dialer.session, dialerTransport)
	dialerRuntime := directUpgradeProtocolRuntime{
		postCommitCtx:  context.Background(),
		transport:      dialerTransport,
		transportReady: true,
	}
	dialer.runtime = &dialerRuntime

	dialerResult, err := dialer.run(dialerRuntime.postCommitCtx, context.Background())
	if err != nil || dialerResult.Path != UpgradePathDirect || dialerResult.Stream == nil {
		t.Fatalf("peer dialer result = %#v, %v; want direct stream", dialerResult, err)
	}
	if !reflect.DeepEqual(dialerRows, []directUpgradeDialerRow{directUpgradeDialerRowD22}) {
		t.Fatalf("peer dialer rows = %v, want [%s]", dialerRows, directUpgradeDialerRowD22)
	}
	if err := dialerResult.Stream.Close(); err != nil {
		t.Fatalf("close peer dialer direct stream: %v", err)
	}
}

func TestDirectUpgradeProtocolEngineAwaitPhasePrefersBufferedConfirmedFrameOverDoneContexts(t *testing.T) {
	for i := range 100 {
		callerCtx, cancelCaller := context.WithCancel(context.Background())
		cancelCaller()
		postCommitCtx, cancelPostCommit := context.WithCancel(context.Background())
		cancelPostCommit()
		done := make(chan controlFrameReadResult, 1)
		done <- controlFrameReadResult{payload: postCommitPhasePayload(t, upgradeControlPhaseConfirmed)}
		fixture := newManagedListenerPostCommitFixture(t, nil, nil)
		//nolint:fatcontext // each iteration builds and cancels independent contexts from Background; nothing accumulates across the loop.
		fixture.runtime.postCommitCtx = postCommitCtx

		frame, completedAtCancellation, outcome, terminal := fixture.engine.awaitEnginePhaseFromDone(
			callerCtx,
			fixture.runtime,
			done,
		)
		if terminal || outcome.err != nil {
			t.Fatalf("iteration %d: awaitEnginePhaseFromDone outcome = %+v, terminal = %v", i, outcome, terminal)
		}
		if !completedAtCancellation {
			t.Fatalf("iteration %d: completedAtCancellation = false, want true", i)
		}
		if confirmed, _ := decodeUpgradeControlPhasePayload(frame.payload, upgradeControlPhaseConfirmed); !confirmed.Is(upgradeControlPhaseConfirmed) {
			t.Fatalf("iteration %d: buffered frame was not confirmed", i)
		}
		if !fixture.runtime.transportReady {
			t.Fatalf("iteration %d: transportReady was cleared", i)
		}
		if fixture.runtime.transport.stream == nil {
			t.Fatalf("iteration %d: transport stream was cleared", i)
		}
		result, err := fixture.engine.attempt.resources().failClosed(context.Canceled, abortAfterOwnedResources)
		if result != (UpgradeResult{}) || !errors.Is(err, context.Canceled) {
			t.Fatalf("iteration %d: managed owner cleanup = %#v, %v; want zero with cancellation", i, result, err)
		}
	}
}

func postCommitPhasePayload(t *testing.T, phase upgradeControlPhase) []byte {
	t.Helper()

	frame, err := encodeUpgradeControlPostCommitPhase(phase, false)
	if err != nil {
		t.Fatalf("encode post-commit phase %v: %v", phase, err)
	}
	return frame[4:]
}

type countingReadWriteCloser struct {
	closes atomic.Int32
}

func (s *countingReadWriteCloser) Read([]byte) (int, error) {
	return 0, io.EOF
}

func (s *countingReadWriteCloser) Write(p []byte) (int, error) {
	return len(p), nil
}

func (s *countingReadWriteCloser) Close() error {
	s.closes.Add(1)
	return nil
}

type manualTestContext struct {
	done chan struct{}
	once sync.Once
	mu   sync.Mutex
	err  error
}

func newManualTestContext() *manualTestContext {
	return &manualTestContext{done: make(chan struct{})}
}

func (c *manualTestContext) Deadline() (time.Time, bool) {
	return time.Time{}, false
}

func (c *manualTestContext) Done() <-chan struct{} {
	return c.done
}

func (c *manualTestContext) Err() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.err
}

func (c *manualTestContext) Value(any) any {
	return nil
}

func (c *manualTestContext) cancel(err error) {
	c.once.Do(func() {
		c.mu.Lock()
		c.err = err
		c.mu.Unlock()
		close(c.done)
	})
}

type observableDoneTestContext struct {
	*manualTestContext
	doneObserved chan struct{}
	observeOnce  sync.Once
}

func newObservableDoneTestContext() *observableDoneTestContext {
	return &observableDoneTestContext{
		manualTestContext: newManualTestContext(),
		doneObserved:      make(chan struct{}),
	}
}

func (c *observableDoneTestContext) Done() <-chan struct{} {
	c.observeOnce.Do(func() {
		close(c.doneObserved)
	})
	return c.manualTestContext.Done()
}

type errAfterCallsTestContext struct {
	context.Context
	remainingNil atomic.Int32
	err          error
}

func newErrAfterCallsTestContext(nilCalls int32, err error) *errAfterCallsTestContext {
	ctx := &errAfterCallsTestContext{
		Context: context.Background(),
		err:     err,
	}
	ctx.remainingNil.Store(nilCalls)
	return ctx
}

func (c *errAfterCallsTestContext) Err() error {
	if c.remainingNil.Add(-1) >= 0 {
		return nil
	}
	return c.err
}
