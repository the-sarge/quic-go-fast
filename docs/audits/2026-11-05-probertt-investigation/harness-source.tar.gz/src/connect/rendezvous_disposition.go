package connect

import (
	"fmt"
	"reflect"
)

const (
	maxRendezvousDispositionTreeDepth = 8192
	maxRendezvousDispositionTreeSteps = 1 << 20
	maxRendezvousDispositionQueue     = 8192
	maxRendezvousDispositionChildren  = 256
)

// Disposition describes whether a failed wire-establishment outcome spent an
// ephemeral rendezvous identifier.
type Disposition uint8

const (
	// DispositionUnknown means the error does not declare whether the rendezvous
	// identifier was spent.
	DispositionUnknown Disposition = iota

	// DispositionSpent means the failure spent the rendezvous identifier. An
	// identity layer may declare this verdict, and root wiremux.Dial may
	// synthesize it after a successful one-shot identity handshake when a later
	// establishment stage fails.
	DispositionSpent

	// DispositionRetryable means the identity layer declared that the failure
	// did not spend the rendezvous identifier.
	DispositionRetryable
)

// String returns a stable diagnostic spelling for disposition values.
func (d Disposition) String() string {
	switch d {
	case DispositionUnknown:
		return "unknown"
	case DispositionSpent:
		return "spent"
	case DispositionRetryable:
		return "retryable"
	default:
		return fmt.Sprintf("unknown(%d)", d)
	}
}

// OneShotRendezvous is an optional capability for authenticators whose
// successful identity handshake spends the ephemeral rendezvous identifier.
//
// Authenticator implementations may satisfy this interface without changing
// wiremux's Authenticator interface. The root wiremux.Dial consume policy
// consults it for ephemeral SessionID rendezvous after identity succeeds:
// post-success auth-context validation, channel setup, upgrade, or nil-stream
// failures attempt bounded best-effort consumption when this capability returns
// true. Implementations that do not check it keep their existing behavior, and
// callers should treat false as equivalent to not implementing the interface.
// Returning a nil auth context with a nil error violates the Authenticator
// result contract; wiremux.Dial treats that result from a one-shot authenticator
// as a post-success failure, marks it spent, and attempts consumption.
// Authenticator decorators and adapters that wrap a one-shot scheme should
// forward this capability by delegating SuccessSpendsRendezvous to the wrapped
// authenticator.
type OneShotRendezvous interface {
	SuccessSpendsRendezvous() bool
}

// MarkRendezvousSpent marks err as a failure that spent the ephemeral
// rendezvous identifier.
//
// For a cause that is neither nil nor typed-nil, the returned error is
// message-transparent and unwraps to err, so errors.Is and errors.As keep
// seeing the original cause. Passing nil returns nil. Passing a typed-nil cause
// such as (*net.OpError)(nil) returns a non-nil marker with an empty message;
// the marker does not unwrap to the typed-nil cause, so errors.Is and errors.As
// do not traverse or bind it. RendezvousDisposition still reports the declared
// disposition.
//
// The marker is declarative: callers and consume-policy implementations must
// inspect it with RendezvousDisposition before changing behavior. Use
// RendezvousDisposition for tree aggregation; errors.As probing for a
// RendezvousDisposition method is not the public contract and can observe
// only node-local marker state (RendezvousDisposition documents the worked
// anti-example). The root wiremux.Dial consume policy consumes ephemeral
// SessionIDs for identity failures that aggregate to DispositionSpent and uses
// the same marker to report one-shot post-success failures as spent.
func MarkRendezvousSpent(err error) error {
	return markRendezvousDisposition(err, DispositionSpent)
}

// MarkRendezvousRetryable marks err as an identity failure that left the
// ephemeral rendezvous identifier retryable.
//
// For a cause that is neither nil nor typed-nil, the returned error is
// message-transparent and unwraps to err, so errors.Is and errors.As keep
// seeing the original cause. Passing nil returns nil. Passing a typed-nil cause
// such as (*net.OpError)(nil) returns a non-nil marker with an empty message;
// the marker does not unwrap to the typed-nil cause, so errors.Is and errors.As
// do not traverse or bind it. RendezvousDisposition still reports the declared
// disposition.
//
// The marker is declarative: callers and consume-policy implementations must
// inspect it with RendezvousDisposition before changing behavior. Use
// RendezvousDisposition for tree aggregation; errors.As probing for a
// RendezvousDisposition method is not the public contract and can observe
// only node-local marker state (RendezvousDisposition documents the worked
// anti-example). The root wiremux.Dial consume policy leaves ephemeral
// SessionIDs reusable for identity failures that aggregate to
// DispositionRetryable.
func MarkRendezvousRetryable(err error) error {
	return markRendezvousDisposition(err, DispositionRetryable)
}

// RendezvousDisposition reports the disposition declared in err's unwrap tree.
//
// DispositionSpent wins when a malformed or contradictory error tree exposes
// both spent and retryable markers. Producers should not combine conflicting
// disposition markers. Traversal is bounded and malformed or adversarial error
// trees can prevent the predicate from reaching every marker. The walk has
// depth, step, queue, and per-node child caps. DispositionSpent still wins when
// it is reached, but DispositionRetryable is returned only when the walk
// completes without truncation. Hitting the queue cap stops later child
// expansion for the remainder of the walk, so hidden markers may degrade to
// DispositionUnknown. This function is the public tree-aggregation API; callers
// should not replace it with errors.As probing for a RendezvousDisposition
// method, because wrappers may expose only node-local disposition state: when
// a retryable marker wraps a deeper spent marker, errors.As observes the outer
// retryable carrier while this function aggregates to DispositionSpent. Direct
// errors.As probing can panic while traversing arbitrary typed-nil branches
// this function skips or panicking Unwrap methods this function recovers from.
// errors.As itself never calls RendezvousDisposition; if a caller invokes that
// method on a bound carrier and it panics, that call is outside this function.
// During its own traversal, this function recovers from a panicking carrier
// method. errors.As can also report a retryable carrier where the fail-closed
// truncation rule makes this function return DispositionUnknown.
//
// Disposition reports rendezvous reuse semantics, not the stage that failed.
// Callers inspecting an error from wiremux.Dial should combine this result with
// errors.Is checks for wiremux.ErrIdentity, wiremux.ErrChannel, and
// wiremux.ErrUpgrade.
func RendezvousDisposition(err error) (disposition Disposition) {
	if isNilConnectError(err) {
		return DispositionUnknown
	}
	seen := make(map[error]struct{})
	queue := []rendezvousDispositionNode{{err: err}}
	retryable := false
	enqueueClosed := false
	truncated := false
	steps, next := 0, 0
	for ; next < len(queue) && steps < maxRendezvousDispositionTreeSteps; steps++ {
		node := queue[next]
		next++
		if isNilConnectError(node.err) || rendezvousDispositionSeen(node.err, seen) {
			continue
		}
		nodeTruncated, malformed := rendezvousDispositionTraversalTruncatedAtNode(node.err)
		if nodeTruncated || malformed {
			truncated = true
		}
		nodeDisposition, malformed := rendezvousDispositionAtNode(node.err)
		if malformed {
			truncated = true
		}
		switch nodeDisposition {
		case DispositionSpent:
			return DispositionSpent
		case DispositionRetryable:
			retryable = true
		case DispositionUnknown:
			// This node carries no marker; keep walking the tree.
		}
		if enqueueClosed || node.depth >= maxRendezvousDispositionTreeDepth {
			if node.depth >= maxRendezvousDispositionTreeDepth {
				truncated = true
			}
			continue
		}
		children, malformed := rendezvousDispositionChildren(node.err)
		if malformed {
			truncated = true
		}
		if len(children) > maxRendezvousDispositionChildren {
			children = children[:maxRendezvousDispositionChildren]
			truncated = true
		}
		pending := len(queue) - next
		for _, child := range children {
			if isNilConnectError(child) {
				continue
			}
			if pending >= maxRendezvousDispositionQueue {
				enqueueClosed = true
				truncated = true
				break
			}
			queue = append(queue, rendezvousDispositionNode{
				err:   child,
				depth: node.depth + 1,
			})
			pending++
		}
		if next > 1024 && next*2 > len(queue) {
			queue = append(queue[:0], queue[next:]...)
			next = 0
		}
	}
	if next < len(queue) && steps >= maxRendezvousDispositionTreeSteps {
		truncated = true
	}
	if retryable && !truncated {
		return DispositionRetryable
	}
	return DispositionUnknown
}

type rendezvousDispositionNode struct {
	err   error
	depth int
}

func rendezvousDispositionAtNode(err error) (disposition Disposition, malformed bool) {
	defer func() {
		if recover() != nil {
			disposition = DispositionUnknown
			malformed = true
		}
	}()
	carrier, ok := err.(rendezvousDispositionCarrier)
	if ok {
		declared := carrier.RendezvousDisposition()
		switch declared {
		case DispositionSpent, DispositionRetryable:
			return declared, false
		default:
			return DispositionUnknown, false
		}
	}
	return DispositionUnknown, false
}

type rendezvousDispositionCarrier interface {
	RendezvousDisposition() Disposition
}

type rendezvousDispositionTraversalTruncater interface {
	RendezvousDispositionTraversalTruncated() bool
}

func rendezvousDispositionTraversalTruncatedAtNode(err error) (truncated bool, malformed bool) {
	defer func() {
		if recover() != nil {
			truncated = true
			malformed = true
		}
	}()
	truncater, ok := err.(rendezvousDispositionTraversalTruncater)
	return ok && truncater.RendezvousDispositionTraversalTruncated(), false
}

func rendezvousDispositionChildren(err error) (children []error, malformed bool) {
	defer func() {
		if recover() != nil {
			children = nil
			malformed = true
		}
	}()
	// Current-node unwrap discovery keeps traversal bounded and typed-nil-safe.
	//nolint:errorlint // single-node primitive of a bounded traversal; errors.As would walk the whole chain and reintroduce the unbounded recursion this guards against.
	switch typed := err.(type) {
	case interface{ Unwrap() []error }:
		return typed.Unwrap(), false
	case interface{ Unwrap() error }:
		return []error{typed.Unwrap()}, false
	default:
		return nil, false
	}
}

func rendezvousDispositionSeen(err error, seen map[error]struct{}) (seenBefore bool) {
	defer func() {
		if recover() != nil {
			seenBefore = false
		}
	}()
	// Root error_tree.go keeps a richer seen set. This public helper only
	// dedupes stable identity-shaped errors, then relies on fail-closed
	// truncation for value-shaped cycles, avoiding deep structural hashing for
	// comparable value wrappers.
	reflected := reflect.ValueOf(err)
	switch reflected.Kind() {
	case reflect.Pointer, reflect.Chan:
	default:
		return false
	}
	if !reflected.Comparable() {
		return false
	}
	if _, ok := seen[err]; ok {
		return true
	}
	seen[err] = struct{}{}
	return false
}

func markRendezvousDisposition(err error, disposition Disposition) error {
	if err == nil {
		return nil
	}
	return &rendezvousDispositionError{
		err:         err,
		disposition: disposition,
	}
}

type rendezvousDispositionError struct {
	err         error
	disposition Disposition
}

func (e *rendezvousDispositionError) Error() string {
	if e == nil || isNilConnectError(e.err) {
		return ""
	}
	return e.err.Error()
}

func (e *rendezvousDispositionError) Unwrap() error {
	if e == nil || isNilConnectError(e.err) {
		return nil
	}
	return e.err
}

func (e *rendezvousDispositionError) RendezvousDisposition() Disposition {
	if e == nil {
		return DispositionUnknown
	}
	switch e.disposition {
	case DispositionSpent, DispositionRetryable:
		return e.disposition
	default:
		return DispositionUnknown
	}
}

func isNilConnectError(err error) bool {
	if err == nil {
		return true
	}
	reflected := reflect.ValueOf(err)
	switch reflected.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
		return reflected.IsNil()
	default:
		return false
	}
}
