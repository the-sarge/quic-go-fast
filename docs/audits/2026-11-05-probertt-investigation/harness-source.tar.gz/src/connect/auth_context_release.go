package connect

import "sync"

// NewReleasingAuthContext explicitly attaches release semantics to auth.
// Callers can use this adapter for a legacy context whose intentional cleanup
// operation has another shape, including func() error(closer.Close). A plain
// io.Closer is never discovered or invoked automatically.
//
// The returned AuthContext implements AuthContextReleaser. It also preserves
// ChannelUseClaimer when the source implements that optional capability.
func NewReleasingAuthContext(auth AuthContext, release func() error) (AuthContext, error) {
	if auth == nil {
		return nil, ErrNilAuthContext
	}
	if release == nil {
		return nil, ErrNilAuthContextRelease
	}
	base := &releasingAuthContext{AuthContext: auth, release: release}
	if claimer, ok := auth.(ChannelUseClaimer); ok {
		return &claimableReleasingAuthContext{
			releasingAuthContext: base,
			claimer:              claimer,
		}, nil
	}
	return base, nil
}

type releasingAuthContext struct {
	AuthContext

	mu          sync.RWMutex
	revoked     bool
	claimed     bool
	release     func() error
	releaseOnce sync.Once
	releaseErr  error
}

func (a *releasingAuthContext) SendKey() []byte {
	a.mu.RLock()
	defer a.mu.RUnlock()
	if a.revoked {
		return nil
	}
	return a.AuthContext.SendKey()
}

func (a *releasingAuthContext) ReceiveKey() []byte {
	a.mu.RLock()
	defer a.mu.RUnlock()
	if a.revoked {
		return nil
	}
	return a.AuthContext.ReceiveKey()
}

func (a *releasingAuthContext) SessionBinding() []byte {
	a.mu.RLock()
	defer a.mu.RUnlock()
	if a.revoked {
		return nil
	}
	return a.AuthContext.SessionBinding()
}

func (a *releasingAuthContext) Exporter() KeyExporter {
	a.mu.RLock()
	defer a.mu.RUnlock()
	if a.revoked {
		return releasedReleaseAdapterExporter{}
	}
	exporter := a.AuthContext.Exporter()
	if exporter == nil {
		return nil
	}
	return &releaseAdapterExporter{auth: a, exporter: exporter}
}

func (a *releasingAuthContext) ReleaseAuthContext() error {
	a.releaseOnce.Do(func() {
		a.mu.Lock()
		a.revoked = true
		a.mu.Unlock()
		a.releaseErr = a.release()
	})
	return a.releaseErr
}

type claimableReleasingAuthContext struct {
	*releasingAuthContext
	claimer ChannelUseClaimer
}

func (a *claimableReleasingAuthContext) ClaimChannelUse() error {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.revoked {
		return ErrAuthContextReleased
	}
	if a.claimed {
		return ErrChannelUseClaimed
	}
	if err := a.claimer.ClaimChannelUse(); err != nil {
		return err
	}
	a.claimed = true
	return nil
}

type releaseAdapterExporter struct {
	auth     *releasingAuthContext
	exporter KeyExporter
}

func (e *releaseAdapterExporter) Derive(label string, context []byte, length int) ([]byte, error) {
	e.auth.mu.RLock()
	defer e.auth.mu.RUnlock()
	if e.auth.revoked {
		return nil, ErrAuthContextReleased
	}
	return e.exporter.Derive(label, context, length)
}

type releasedReleaseAdapterExporter struct{}

func (releasedReleaseAdapterExporter) Derive(string, []byte, int) ([]byte, error) {
	return nil, ErrAuthContextReleased
}
