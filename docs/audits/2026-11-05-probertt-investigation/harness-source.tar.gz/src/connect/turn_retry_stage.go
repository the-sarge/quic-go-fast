package connect

import "fmt"

// turnRetryStage names the TURN retry step in flight when a failure
// surfaces. The retry budget is one shared context over the whole sequence,
// so without a stage label a budget expiry or peer abort reports only its
// generic control error and a stall is indistinguishable from any other
// failure (issue #1218). Stages are coarse phase names, not per-frame states:
// each maps to one await/work loop whose duration is worth attributing.
type turnRetryStage string

const (
	// turnRetryStageDialectEntry covers the dialer's post-Start wait for the
	// listener's dialect-selecting frame.
	turnRetryStageDialectEntry turnRetryStage = "retry dialect entry"
	// turnRetryStageAllocation covers this role's TURN allocation, including
	// adoption validation and allocation-phase policy checks.
	turnRetryStageAllocation turnRetryStage = "relay allocation"
	// turnRetryStageOfferExchange covers publishing the local Retry Offer and
	// awaiting the peer's.
	turnRetryStageOfferExchange turnRetryStage = "retry offer exchange"
	// turnRetryStagePeerPreparation covers PreparePeer: the TURN permission
	// and channel binding for the authenticated peer relay address.
	turnRetryStagePeerPreparation turnRetryStage = "relay peer preparation"
	// turnRetryStageProbe covers the authenticated retry probe, including the
	// listener's concurrent Selected await.
	turnRetryStageProbe turnRetryStage = "authenticated retry probe"
	// turnRetryStageReadyCommit covers the Selected/Ready/Commit exchange and
	// the listener's precommit materialization.
	turnRetryStageReadyCommit turnRetryStage = "retry ready/commit exchange"
	// turnRetryStagePostCommit covers the post-commit transport handshake and
	// Accepted/Converged/Confirmed convergence.
	turnRetryStagePostCommit turnRetryStage = "post-commit transport convergence"
)

// Internal family causes for fail-closed exits that previously passed a nil
// cause to failClosed and therefore could not carry a stage label (issue
// #1270). Each wraps the public sentinel so existing
// ErrUpgradeTransportNotConverged matches keep holding; the family sentinel
// itself is stable and errors.Is-matchable beneath any per-site detail.
var (
	// errTurnRetryConvergenceMalformed reports a malformed or oversized
	// post-commit convergence frame (Accepted, Converged, or Confirmed).
	errTurnRetryConvergenceMalformed = fmt.Errorf("connect: malformed turn retry convergence frame: %w", ErrUpgradeTransportNotConverged)
	// errTurnRetryTransferredResource reports a stream that crossed the
	// ownership-transfer boundary while the retry race was being abandoned,
	// so reliable fallback is no longer available.
	errTurnRetryTransferredResource = fmt.Errorf("connect: turn retry transport transferred before convergence: %w", ErrUpgradeTransportNotConverged)
)

// turnRetryStageError labels err with the retry stage in flight when it
// surfaced, preserving the wrapped chain for sentinel and context matching.
// A nil err stays nil so callers can wrap unconditionally.
func turnRetryStageError(stage turnRetryStage, err error) error {
	if err == nil {
		return nil
	}
	return fmt.Errorf("connect: turn retry failed during %s: %w", stage, err)
}
