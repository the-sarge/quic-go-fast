package connect

import (
	"errors"
	"testing"
)

func TestNewReleasingAuthContextPreservesOptionalClaim(t *testing.T) {
	source := &releaseAdapterAuthContext{authContextFixture: testAuthContext()}
	releaseErr := errors.New("release sentinel")
	releases := 0
	adapted, err := NewReleasingAuthContext(source, func() error {
		releases++
		return releaseErr
	})
	if err != nil {
		t.Fatalf("NewReleasingAuthContext error = %v", err)
	}
	claimer, ok := adapted.(ChannelUseClaimer)
	if !ok {
		t.Fatal("adapter dropped ChannelUseClaimer")
	}
	if err := claimer.ClaimChannelUse(); err != nil {
		t.Fatalf("ClaimChannelUse error = %v", err)
	}
	if err := claimer.ClaimChannelUse(); !errors.Is(err, ErrChannelUseClaimed) {
		t.Fatalf("second ClaimChannelUse error = %v, want %v", err, ErrChannelUseClaimed)
	}
	if source.claims != 1 {
		t.Fatalf("source claim count = %d, want 1", source.claims)
	}
	exporter := adapted.Exporter()
	releaser, ok := adapted.(AuthContextReleaser)
	if !ok {
		t.Fatal("adapter does not implement AuthContextReleaser")
	}
	if err := releaser.ReleaseAuthContext(); !errors.Is(err, releaseErr) {
		t.Fatalf("ReleaseAuthContext error = %v, want %v", err, releaseErr)
	}
	if err := releaser.ReleaseAuthContext(); !errors.Is(err, releaseErr) {
		t.Fatalf("second ReleaseAuthContext error = %v, want retained %v", err, releaseErr)
	}
	if releases != 1 {
		t.Fatalf("release callback count = %d, want 1", releases)
	}
	if got := adapted.SendKey(); got != nil {
		t.Fatalf("released SendKey = %x, want nil", got)
	}
	if got := adapted.ReceiveKey(); got != nil {
		t.Fatalf("released ReceiveKey = %x, want nil", got)
	}
	if got := adapted.SessionBinding(); got != nil {
		t.Fatalf("released SessionBinding = %x, want nil", got)
	}
	if _, err := exporter.Derive("released", nil, 16); !errors.Is(err, ErrAuthContextReleased) {
		t.Fatalf("retained exporter error = %v, want %v", err, ErrAuthContextReleased)
	}
	if _, err := adapted.Exporter().Derive("released", nil, 16); !errors.Is(err, ErrAuthContextReleased) {
		t.Fatalf("new exporter error = %v, want %v", err, ErrAuthContextReleased)
	}
	if err := claimer.ClaimChannelUse(); !errors.Is(err, ErrAuthContextReleased) {
		t.Fatalf("released ClaimChannelUse error = %v, want %v", err, ErrAuthContextReleased)
	}
}

func TestNewReleasingAuthContextRejectsNilInputs(t *testing.T) {
	if _, err := NewReleasingAuthContext(nil, func() error { return nil }); !errors.Is(err, ErrNilAuthContext) {
		t.Fatalf("nil auth error = %v, want %v", err, ErrNilAuthContext)
	}
	if _, err := NewReleasingAuthContext(testAuthContext(), nil); !errors.Is(err, ErrNilAuthContextRelease) {
		t.Fatalf("nil release error = %v, want %v", err, ErrNilAuthContextRelease)
	}
}

type releaseAdapterAuthContext struct {
	authContextFixture
	claims int
}

func (a *releaseAdapterAuthContext) ClaimChannelUse() error {
	a.claims++
	return nil
}
