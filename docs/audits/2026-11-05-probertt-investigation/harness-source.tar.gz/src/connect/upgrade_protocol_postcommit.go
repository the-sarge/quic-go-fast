package connect

type directUpgradePostCommitStep uint8

const (
	directUpgradePostCommitStepAccepted directUpgradePostCommitStep = iota
	directUpgradePostCommitStepConverged
	directUpgradePostCommitStepConfirmed
)

type directUpgradePostCommitLocalAction uint8

const (
	directUpgradePostCommitAwait directUpgradePostCommitLocalAction = iota + 1
	directUpgradePostCommitSend
)

type directUpgradePostCommitPhaseAction struct {
	local directUpgradePostCommitLocalAction
	phase upgradeControlPhase
}

type directUpgradePostCommitPhaseOrderTable [3]directUpgradePostCommitPhaseAction
