package connect

import (
	"errors"
	"testing"
)

func TestListenerCommitControlEventGuard(t *testing.T) {
	controlErr := errors.New("control read failed")
	tests := []struct {
		name         string
		event        directUpgradeControlEvent
		wantKind     directUpgradeControlEventKind
		wantReason   UpgradeFallbackReason
		wantFallback bool
		wantCause    error
	}{
		{name: "commit observed", event: directUpgradeControlEvent{kind: directUpgradeControlEventCommitObserved}, wantKind: directUpgradeControlEventCommitObserved},
		{name: "relay fallback", event: directUpgradeControlEvent{kind: directUpgradeControlEventRelayFallback, fallbackReason: UpgradeFallbackProbeFailed, wireFallback: true}, wantKind: directUpgradeControlEventRelayFallback, wantReason: UpgradeFallbackProbeFailed, wantFallback: true},
		{name: "control error", event: directUpgradeControlEvent{kind: directUpgradeControlEventControlError, cause: controlErr}, wantKind: directUpgradeControlEventControlError, wantCause: controlErr},
		{name: "transport failure", event: directUpgradeControlEvent{kind: directUpgradeControlEventTransportFailure, cause: controlErr}, wantKind: directUpgradeControlEventTransportFailure, wantCause: controlErr},
		{name: "ignore and keep waiting", event: directUpgradeControlEvent{kind: directUpgradeControlEventIgnoreAndKeepWaiting}, wantKind: directUpgradeControlEventControlError, wantCause: errUnexpectedDirectUpgradeControlState},
		{name: "fail closed committed", event: directUpgradeControlEvent{kind: directUpgradeControlEventFailClosedCommitted}, wantKind: directUpgradeControlEventControlError, wantCause: errUnexpectedDirectUpgradeControlState},
		{name: "zero", event: directUpgradeControlEvent{}, wantKind: directUpgradeControlEventControlError, wantCause: errUnexpectedDirectUpgradeControlState},
		{name: "unknown", event: directUpgradeControlEvent{kind: directUpgradeControlEventKind(99)}, wantKind: directUpgradeControlEventControlError, wantCause: errUnexpectedDirectUpgradeControlState},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := guardListenerCommitControlEvent(tt.event)
			if got.kind != tt.wantKind {
				t.Fatalf("kind = %v, want %v", got.kind, tt.wantKind)
			}
			if got.fallbackReason != tt.wantReason || got.wireFallback != tt.wantFallback {
				t.Fatalf("fallback = (%q, %v), want (%q, %v)", got.fallbackReason, got.wireFallback, tt.wantReason, tt.wantFallback)
			}
			if !errors.Is(got.cause, tt.wantCause) {
				t.Fatalf("cause = %v, want %v", got.cause, tt.wantCause)
			}
		})
	}
}

func TestTransportStreamResultClass(t *testing.T) {
	stream := newScriptedControlChannel(nil, false)
	resultErr := errors.New("transport operation failed")
	tests := []struct {
		name string
		in   transportStreamResult
		want transportStreamResultClass
	}{
		{name: "nil_stream", in: transportStreamResult{}, want: transportStreamResultNoMaterialization},
		{name: "nil_stream_with_error", in: transportStreamResult{err: resultErr}, want: transportStreamResultNoMaterialization},
		{name: "stream_success", in: transportStreamResult{stream: stream}, want: transportStreamResultSuccess},
		{name: "stream_error", in: transportStreamResult{stream: stream, err: resultErr}, want: transportStreamResultMaterializedError},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if got := classifyTransportStreamResult(test.in); got != test.want {
				t.Fatalf("class = %v, want %v", got, test.want)
			}
		})
	}
}

func TestClassifyDirectUpgradeControlEvent(t *testing.T) {
	controlErr := errors.New("control read failed")
	tests := []struct {
		name               string
		state              directUpgradeControlClassifyState
		frame              controlFrameReadResult
		transportCommitted bool
		wantKind           directUpgradeControlEventKind
		wantReason         UpgradeFallbackReason
		wantWireFallback   bool
		wantCause          error
	}{
		{
			name:     "listener commit observes commit",
			state:    directUpgradeControlClassifyListenerCommit,
			frame:    controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseCommit) }),
			wantKind: directUpgradeControlEventCommitObserved,
		},
		{
			name:               "listener commit observes commit after transport committed",
			state:              directUpgradeControlClassifyListenerCommit,
			frame:              controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseCommit) }),
			transportCommitted: true,
			wantKind:           directUpgradeControlEventCommitObserved,
		},
		{
			name:             "listener commit sees wire fallback before commit",
			state:            directUpgradeControlClassifyListenerCommit,
			frame:            controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlFallback(UpgradeFallbackTransportFailed) }),
			wantKind:         directUpgradeControlEventRelayFallback,
			wantReason:       UpgradeFallbackTransportFailed,
			wantWireFallback: true,
		},
		{
			name:       "listener commit maps wrong phase before commit to protocol mismatch fallback",
			state:      directUpgradeControlClassifyListenerCommit,
			frame:      controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseReady) }),
			wantKind:   directUpgradeControlEventRelayFallback,
			wantReason: UpgradeFallbackProtocolMismatch,
		},
		{
			name:               "listener commit maps wrong phase after commit to transport failure",
			state:              directUpgradeControlClassifyListenerCommit,
			frame:              controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseReady) }),
			transportCommitted: true,
			wantKind:           directUpgradeControlEventTransportFailure,
		},
		{
			name:               "listener commit preserves control error after commit",
			state:              directUpgradeControlClassifyListenerCommit,
			frame:              controlFrameReadResult{err: controlErr},
			transportCommitted: true,
			wantKind:           directUpgradeControlEventControlError,
			wantCause:          controlErr,
		},
		{
			name:       "listener commit maps pre commit timeout to relay fallback",
			state:      directUpgradeControlClassifyListenerCommit,
			frame:      controlFrameReadResult{err: ErrUpgradeControlTimeout},
			wantKind:   directUpgradeControlEventRelayFallback,
			wantReason: UpgradeFallbackTransportFailed,
		},
		{
			name:      "listener commit maps pre commit control error to control error",
			state:     directUpgradeControlClassifyListenerCommit,
			frame:     controlFrameReadResult{err: controlErr},
			wantKind:  directUpgradeControlEventControlError,
			wantCause: controlErr,
		},
		{
			name:             "terminal fallback only settles fallback frame",
			state:            directUpgradeControlClassifyTerminalFallbackOnly,
			frame:            controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlFallback(UpgradeFallbackProbeFailed) }),
			wantKind:         directUpgradeControlEventRelayFallback,
			wantReason:       UpgradeFallbackProbeFailed,
			wantWireFallback: true,
		},
		{
			name:       "terminal fallback only maps non fallback frame to protocol mismatch fallback",
			state:      directUpgradeControlClassifyTerminalFallbackOnly,
			frame:      controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseReady) }),
			wantKind:   directUpgradeControlEventRelayFallback,
			wantReason: UpgradeFallbackProtocolMismatch,
		},
		{
			name:      "terminal fallback only preserves control error",
			state:     directUpgradeControlClassifyTerminalFallbackOnly,
			frame:     controlFrameReadResult{err: controlErr},
			wantKind:  directUpgradeControlEventControlError,
			wantCause: controlErr,
		},
		{
			name:     "terminal fallback skip ready ignores ready frame",
			state:    directUpgradeControlClassifyTerminalFallbackSkipReady,
			frame:    controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseReady) }),
			wantKind: directUpgradeControlEventIgnoreAndKeepWaiting,
		},
		{
			name:             "terminal fallback skip ready settles fallback frame",
			state:            directUpgradeControlClassifyTerminalFallbackSkipReady,
			frame:            controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlFallback(UpgradeFallbackProtocolMismatch) }),
			wantKind:         directUpgradeControlEventRelayFallback,
			wantReason:       UpgradeFallbackProtocolMismatch,
			wantWireFallback: true,
		},
		{
			name:      "terminal fallback skip ready preserves control error",
			state:     directUpgradeControlClassifyTerminalFallbackSkipReady,
			frame:     controlFrameReadResult{err: controlErr},
			wantKind:  directUpgradeControlEventControlError,
			wantCause: controlErr,
		},
		{
			name:     "terminal fallback listener commit fails closed on commit",
			state:    directUpgradeControlClassifyTerminalFallbackListenerCommit,
			frame:    controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseCommit) }),
			wantKind: directUpgradeControlEventFailClosedCommitted,
		},
		{
			name:             "terminal fallback listener commit settles fallback",
			state:            directUpgradeControlClassifyTerminalFallbackListenerCommit,
			frame:            controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlFallback(UpgradeFallbackTransportFailed) }),
			wantKind:         directUpgradeControlEventRelayFallback,
			wantReason:       UpgradeFallbackTransportFailed,
			wantWireFallback: true,
		},
		{
			name:      "terminal fallback listener commit preserves control error",
			state:     directUpgradeControlClassifyTerminalFallbackListenerCommit,
			frame:     controlFrameReadResult{err: controlErr},
			wantKind:  directUpgradeControlEventControlError,
			wantCause: controlErr,
		},
		{
			name:       "terminal fallback listener commit maps timeout to relay fallback",
			state:      directUpgradeControlClassifyTerminalFallbackListenerCommit,
			frame:      controlFrameReadResult{err: ErrUpgradeControlTimeout},
			wantKind:   directUpgradeControlEventRelayFallback,
			wantReason: UpgradeFallbackTransportFailed,
		},
		{
			name:       "terminal fallback listener commit maps wrong phase to protocol mismatch fallback",
			state:      directUpgradeControlClassifyTerminalFallbackListenerCommit,
			frame:      controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseReady) }),
			wantKind:   directUpgradeControlEventRelayFallback,
			wantReason: UpgradeFallbackProtocolMismatch,
		},
		{
			name:     "terminal fallback listener handoff commit fails closed on commit",
			state:    directUpgradeControlClassifyTerminalFallbackListenerHandoffCommit,
			frame:    controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseCommit) }),
			wantKind: directUpgradeControlEventFailClosedCommitted,
		},
		{
			name:             "terminal fallback listener handoff commit settles fallback",
			state:            directUpgradeControlClassifyTerminalFallbackListenerHandoffCommit,
			frame:            controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlFallback(UpgradeFallbackProbeFailed) }),
			wantKind:         directUpgradeControlEventRelayFallback,
			wantReason:       UpgradeFallbackProbeFailed,
			wantWireFallback: true,
		},
		{
			name:      "terminal fallback listener handoff commit preserves control error",
			state:     directUpgradeControlClassifyTerminalFallbackListenerHandoffCommit,
			frame:     controlFrameReadResult{err: controlErr},
			wantKind:  directUpgradeControlEventControlError,
			wantCause: controlErr,
		},
		{
			name:      "terminal fallback listener handoff commit preserves timeout as control error",
			state:     directUpgradeControlClassifyTerminalFallbackListenerHandoffCommit,
			frame:     controlFrameReadResult{err: ErrUpgradeControlTimeout},
			wantKind:  directUpgradeControlEventControlError,
			wantCause: ErrUpgradeControlTimeout,
		},
		{
			name:       "terminal fallback listener handoff commit maps wrong phase to protocol mismatch fallback",
			state:      directUpgradeControlClassifyTerminalFallbackListenerHandoffCommit,
			frame:      controlFrameResultWithPayload(t, func() ([]byte, error) { return encodeUpgradeControlPhase(upgradeControlPhaseReady) }),
			wantKind:   directUpgradeControlEventRelayFallback,
			wantReason: UpgradeFallbackProtocolMismatch,
		},
		{
			name:      "unknown state returns control error",
			state:     directUpgradeControlClassifyState(99),
			frame:     controlFrameReadResult{},
			wantKind:  directUpgradeControlEventControlError,
			wantCause: errUnexpectedDirectUpgradeControlState,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := classifyDirectUpgradeControlEvent(tt.state, tt.frame, tt.transportCommitted)
			if got.kind != tt.wantKind {
				t.Fatalf("kind = %v, want %v", got.kind, tt.wantKind)
			}
			if got.fallbackReason != tt.wantReason {
				t.Fatalf("fallback reason = %q, want %q", got.fallbackReason, tt.wantReason)
			}
			if got.wireFallback != tt.wantWireFallback {
				t.Fatalf("wire fallback = %v, want %v", got.wireFallback, tt.wantWireFallback)
			}
			if !errors.Is(got.cause, tt.wantCause) {
				t.Fatalf("cause = %v, want %v", got.cause, tt.wantCause)
			}
		})
	}
}

func commitResultWithPayload(t *testing.T, encode func() ([]byte, error)) commitAwaitResult {
	t.Helper()
	return commitAwaitResult{frame: controlFrameResultWithPayload(t, encode)}
}

func controlFrameResultWithPayload(t *testing.T, encode func() ([]byte, error)) controlFrameReadResult {
	t.Helper()
	frame, err := encode()
	if err != nil {
		t.Fatalf("encode frame: %v", err)
	}
	return controlFrameReadResult{payload: frame[4:]}
}
