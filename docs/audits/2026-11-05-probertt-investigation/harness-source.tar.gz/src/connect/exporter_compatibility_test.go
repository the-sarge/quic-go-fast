package connect

import (
	"bytes"
	"encoding/hex"
	"errors"
	"testing"
)

func exporterKnownAnswerForTest(t *testing.T) []byte {
	t.Helper()
	// Independently calculated with Python hmac.digest / SHA-256 using RFC
	// 5869 Extract and two Expand blocks. IKM = "diagnostic synthetic master",
	// salt = "diagnostic synthetic binding", info = "wiremux v1 test\x00\x00\xff\x01".
	answer, err := hex.DecodeString("06a8b1d2ffa0b067e7be7b7f4a9056aa076f447296cd93ff19f8100ba485ea68572ff334dab1266174df78a0eced97be906a9a1ab45d669cb01169832a66b266")
	if err != nil {
		t.Fatal("known-answer fixture: got invalid hex, want valid hex")
	}
	return answer
}

func TestHKDFKeyExporterKnownAnswer(t *testing.T) {
	e := NewHKDFKeyExporter([]byte("diagnostic synthetic master"), []byte("diagnostic synthetic binding"))
	want := exporterKnownAnswerForTest(t)
	for _, length := range []int{0, 1, 16, 32, 64} {
		got, err := e.Derive("wiremux v1 test", []byte{0, 255, 1}, length)
		if err != nil || !bytes.Equal(got, want[:length]) {
			t.Errorf("known-answer derivation (%d bytes): got mismatch, want match", length)
		}
	}
}

func TestHKDFKeyExporterZeroValueDerivation(t *testing.T) {
	// The previous zero value expanded a nil PRK. Independently calculated
	// HMAC-SHA-256(key="", message="zero-value\x00\x01") preserves that behavior.
	want, err := hex.DecodeString("481e01f95c98d22cbb22a6c09b297856651371201798991463bb3cad31133998")
	if err != nil {
		t.Fatal("zero-value fixture: got invalid hex, want valid hex")
	}
	var e hkdfKeyExporter
	got, err := e.Derive("zero-value", nil, 32)
	if err != nil || !bytes.Equal(got, want) {
		t.Fatal("zero-value derivation: got mismatch, want original nil-PRK output")
	}
}

func TestHKDFKeyExporterOwnsInputsAndRetainedHandle(t *testing.T) {
	master := []byte("diagnostic synthetic master")
	binding := []byte("diagnostic synthetic binding")
	holder := struct{ Exporter KeyExporter }{NewHKDFKeyExporter(master, binding)}
	retained := holder.Exporter
	// Model an ordinary identity holder discarding its exporter and clearing
	// constructor inputs. A raw issued handle has no revocation relationship.
	holder.Exporter = nil
	clear(master)
	clear(binding)
	want := exporterKnownAnswerForTest(t)
	context := []byte{0, 255, 1}
	first, err := retained.Derive("wiremux v1 test", context, len(want))
	if err != nil || !bytes.Equal(first, want) {
		t.Fatal("retained handle after holder reset: got mismatch, want match")
	}
	if !bytes.Equal(context, []byte{0, 255, 1}) {
		t.Fatal("caller context after derivation: got mutation, want unchanged")
	}
	clear(first)
	clear(context)
	again, err := retained.Derive("wiremux v1 test", []byte{0, 255, 1}, len(want))
	if err != nil || !bytes.Equal(again, want) {
		t.Fatal("derivation after caller output/context mutation: got mismatch, want match")
	}
}

func TestHKDFKeyExporterValidationPrecedence(t *testing.T) {
	for name, e := range map[string]KeyExporter{
		"valid":   NewHKDFKeyExporter([]byte("synthetic master"), nil),
		"invalid": NewHKDFKeyExporter(nil, nil),
		"zero":    &hkdfKeyExporter{},
	} {
		for _, tc := range []struct {
			name    string
			label   string
			length  int
			want    error
			message string
		}{
			{"labelBeforeNegative", "bad\x00label", -1, ErrInvalidExporterLabel, "connect: exporter label contains NUL"},
			{"labelBeforeTooLong", "bad\x00label", 8161, ErrInvalidExporterLabel, "connect: exporter label contains NUL"},
			{"negativeBeforeInit", "valid", -1, ErrNegativeExporterLength, "connect: exporter length is negative"},
			{"tooLongBeforeInit", "valid", 8161, ErrExporterLengthTooLong, "connect: exporter length exceeds HKDF-SHA-256 limit"},
		} {
			t.Run(name+"/"+tc.name, func(t *testing.T) {
				got, err := e.Derive(tc.label, nil, tc.length)
				if got != nil || !errors.Is(err, tc.want) || err != tc.want || err.Error() != tc.message { //nolint:errorlint // Exact exported sentinel identity is a compatibility requirement.
					t.Error("validation result: got mismatch, want original sentinel, message, and nil output")
				}
			})
		}
	}
	for _, length := range []int{0, 32} {
		got, err := NewHKDFKeyExporter(nil, nil).Derive("valid", nil, length)
		if got != nil || err != ErrEmptyMasterSecret || err.Error() != "connect: exporter master secret is empty" { //nolint:errorlint // Preserve the exact constructor-failure sentinel.
			t.Error("empty-master result: got mismatch, want original sentinel, message, and nil output")
		}
	}
}
