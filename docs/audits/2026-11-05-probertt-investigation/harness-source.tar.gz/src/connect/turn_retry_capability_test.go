package connect

import (
	"bytes"
	"net/netip"
	"testing"

	"github.com/fxamacker/cbor/v2"
)

func turnRetryCapabilityTestOffer(turnRetry bool) localUpgradeOffer {
	return localUpgradeOffer{
		transportName:     "quic",
		handshakeMaterial: []byte{0x01, 0x02},
		probeNonce:        bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		candidates: []Candidate{{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
		}},
		turnRetry: turnRetry,
	}
}

func TestEncodeUpgradeControlOfferTURNRetryCapabilityGolden(t *testing.T) {
	t.Parallel()

	unconfigured, err := encodeUpgradeControlOffer(turnRetryCapabilityTestOffer(false))
	if err != nil {
		t.Fatalf("encode unconfigured offer: %v", err)
	}
	wantUnconfigured := mustHex(t, "00000040a6000101010a64717569630b4201020c582042424242424242424242424242424242424242424242424242424242424242420d81a20001014704c000020a3039")
	if !bytes.Equal(unconfigured, wantUnconfigured) {
		t.Fatalf("unconfigured offer drifted: got %x want %x", unconfigured, wantUnconfigured)
	}

	configured, err := encodeUpgradeControlOffer(turnRetryCapabilityTestOffer(true))
	if err != nil {
		t.Fatalf("encode configured offer: %v", err)
	}
	wantConfigured := mustHex(t, "00000058a70001010102a174776972656d75782e7475726e2d72657472792f31f50a64717569630b4201020c582042424242424242424242424242424242424242424242424242424242424242420d81a20001014704c000020a3039")
	if !bytes.Equal(configured, wantConfigured) {
		t.Fatalf("configured offer = %x, want %x", configured, wantConfigured)
	}

	decoded, ok := decodeOffer(configured[4:])
	if !ok {
		t.Fatal("configured offer did not decode")
	}
	if !decoded.turnRetry {
		t.Fatal("configured offer decoded without turn-retry capability")
	}
	decodedUnconfigured, ok := decodeOffer(unconfigured[4:])
	if !ok {
		t.Fatal("unconfigured offer did not decode")
	}
	if decodedUnconfigured.turnRetry {
		t.Fatal("unconfigured offer decoded with turn-retry capability")
	}
}

func TestDecodeOfferTURNRetryExtensionSemantics(t *testing.T) {
	t.Parallel()

	duplicateKey := append([]byte{0x74}, []byte(upgradeControlTURNRetryExtension)...)
	duplicateExtensions := append([]byte{0xa2}, duplicateKey...)
	duplicateExtensions = append(duplicateExtensions, 0xf5)
	duplicateExtensions = append(duplicateExtensions, duplicateKey...)
	duplicateExtensions = append(duplicateExtensions, 0xf5)

	tests := []struct {
		name          string
		extensions    any
		wantTurnRetry bool
		wantReject    bool
	}{
		{name: "missing means absent"},
		{name: "unknown ignored", extensions: map[string]any{"future": true}},
		{name: "canonical true means present", extensions: map[string]any{upgradeControlTURNRetryExtension: true}, wantTurnRetry: true},
		{name: "false is malformed", extensions: map[string]any{upgradeControlTURNRetryExtension: false}, wantReject: true},
		{name: "non boolean is malformed", extensions: map[string]any{upgradeControlTURNRetryExtension: uint64(1)}, wantReject: true},
		{name: "text true is malformed", extensions: map[string]any{upgradeControlTURNRetryExtension: "true"}, wantReject: true},
		{name: "duplicate registered key is malformed", extensions: cbor.RawMessage(duplicateExtensions), wantReject: true},
	}

	base, err := encodeUpgradeControlOffer(turnRetryCapabilityTestOffer(false))
	if err != nil {
		t.Fatalf("encode base offer: %v", err)
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()
			frame := base
			if test.extensions != nil {
				frame = setUpgradeControlTestExtensions(t, base, test.extensions)
			}
			offer, ok := decodeOffer(frame[4:])
			if test.wantReject {
				if ok {
					t.Fatalf("malformed turn-retry extension decoded: %#v", offer)
				}
				phase, _ := decodeUpgradeControlFirstPhasePayload(frame[4:])
				if !phase.HasFallback || phase.FallbackReason != UpgradeFallbackProtocolMismatch {
					t.Fatalf("first phase = %#v, want protocol_mismatch fallback", phase)
				}
				return
			}
			if !ok {
				t.Fatal("valid offer rejected")
			}
			if offer.turnRetry != test.wantTurnRetry {
				t.Fatalf("turnRetry = %v, want %v", offer.turnRetry, test.wantTurnRetry)
			}
		})
	}
}

func setUpgradeControlTestExtensions(t *testing.T, frame []byte, extensions any) []byte {
	t.Helper()
	var message map[uint64]cbor.RawMessage
	if err := decMode.Unmarshal(frame[4:], &message); err != nil {
		t.Fatalf("decode test frame: %v", err)
	}
	raw, ok := extensions.(cbor.RawMessage)
	if !ok {
		encoded, err := encMode.Marshal(extensions)
		if err != nil {
			t.Fatalf("encode test extensions: %v", err)
		}
		raw = encoded
	}
	message[upgradeControlKeyExtensions] = raw
	return mustEncodeTestFrame(t, message)
}

func TestDecodeRegisteredTURNRetryExtensionRejectsOutsideOffer(t *testing.T) {
	t.Parallel()

	fallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackNotRequested)
	if err != nil {
		t.Fatalf("encode fallback: %v", err)
	}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selectedPair{
		dialer:   Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("192.0.2.10:12345")},
		listener: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("198.51.100.20:23456")},
	})
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}

	phaseFrame := func(phase upgradeControlPhase) []byte {
		frame, err := encodeUpgradeControlPhase(phase)
		if err != nil {
			t.Fatalf("encode phase %v: %v", phase, err)
		}
		return frame
	}

	tests := []struct {
		name  string
		frame []byte
		valid func([]byte) bool
	}{
		{name: "fallback", frame: fallbackFrame, valid: func(payload []byte) bool {
			value, _ := decodeUpgradeControlFallbackPayload(payload)
			return value.Reason == UpgradeFallbackNotRequested
		}},
		{name: "selected pair", frame: selectedFrame, valid: func(payload []byte) bool {
			_, ok := decodeSelectedPair(payload)
			return ok
		}},
		{name: "ready", frame: phaseFrame(upgradeControlPhaseReady), valid: func(payload []byte) bool {
			value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseReady)
			return value.Is(upgradeControlPhaseReady)
		}},
		{name: "commit", frame: phaseFrame(upgradeControlPhaseCommit), valid: func(payload []byte) bool {
			value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseCommit)
			return value.Is(upgradeControlPhaseCommit)
		}},
		{name: "accepted", frame: phaseFrame(upgradeControlPhaseAccepted), valid: func(payload []byte) bool {
			value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseAccepted)
			return value.Is(upgradeControlPhaseAccepted)
		}},
		{name: "converged", frame: phaseFrame(upgradeControlPhaseConverged), valid: func(payload []byte) bool {
			value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseConverged)
			return value.Is(upgradeControlPhaseConverged)
		}},
		{name: "confirmed", frame: phaseFrame(upgradeControlPhaseConfirmed), valid: func(payload []byte) bool {
			value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseConfirmed)
			return value.Is(upgradeControlPhaseConfirmed)
		}},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()
			registered := addUpgradeControlTestExtension(t, test.frame, upgradeControlTURNRetryExtension, true)
			if test.valid(registered[4:]) {
				t.Fatal("registered turn-retry extension was accepted outside the v1 Offer")
			}
			unknown := addUpgradeControlTestExtension(t, test.frame, "future", true)
			if !test.valid(unknown[4:]) {
				t.Fatal("unknown bounded extension was rejected")
			}
		})
	}
}
