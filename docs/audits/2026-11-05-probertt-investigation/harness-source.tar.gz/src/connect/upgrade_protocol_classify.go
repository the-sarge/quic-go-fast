package connect

// directUpgradeControlClassifyState names the protocol point where a control
// frame or read error was observed. Relay fallback events set wireFallback only
// when the frame was an actual fallback message; protocol-mismatch fallbacks
// synthesized from a wrong phase leave it false. Listener-commit terminal
// fallback is still pre-commit and may map timeout to relay fallback, while
// listener-handoff terminal fallback preserves read errors before commit classification.
type directUpgradeControlClassifyState uint8

const (
	directUpgradeControlClassifyListenerCommit directUpgradeControlClassifyState = iota + 1
	directUpgradeControlClassifyTerminalFallbackOnly
	directUpgradeControlClassifyTerminalFallbackSkipReady
	// The terminal fallback commit states are named by call-site policy.
	// Listener handoff preserves the old error-first timeout behavior, while the
	// listener pre-commit state may still map pre-commit timeout to relay fallback.
	directUpgradeControlClassifyTerminalFallbackListenerCommit
	directUpgradeControlClassifyTerminalFallbackListenerHandoffCommit
)

type directUpgradeControlEventKind uint8

const (
	directUpgradeControlEventCommitObserved directUpgradeControlEventKind = iota + 1
	directUpgradeControlEventRelayFallback
	directUpgradeControlEventControlError
	directUpgradeControlEventTransportFailure
	directUpgradeControlEventIgnoreAndKeepWaiting
	directUpgradeControlEventFailClosedCommitted
)

type directUpgradeControlEvent struct {
	kind           directUpgradeControlEventKind
	fallbackReason UpgradeFallbackReason
	wireFallback   bool
	cause          error
}

func guardListenerCommitControlEvent(event directUpgradeControlEvent) directUpgradeControlEvent {
	switch event.kind {
	case directUpgradeControlEventCommitObserved,
		directUpgradeControlEventRelayFallback,
		directUpgradeControlEventControlError,
		directUpgradeControlEventTransportFailure:
		return event
	default:
		return directUpgradeControlEvent{
			kind:  directUpgradeControlEventControlError,
			cause: errUnexpectedDirectUpgradeControlState,
		}
	}
}

func listenerCommitControlEvent(result commitAwaitResult, transportCommitted bool, strict ...bool) directUpgradeControlEvent {
	return classifyDirectUpgradeControlEvent(
		directUpgradeControlClassifyListenerCommit,
		controlFrameReadResult{payload: result.frame.payload, err: result.err},
		transportCommitted,
		strict...,
	)
}

func classifyDirectUpgradeControlEvent(
	state directUpgradeControlClassifyState,
	frame controlFrameReadResult,
	transportCommitted bool,
	strict ...bool,
) directUpgradeControlEvent {
	strictMode := len(strict) != 0 && strict[0]
	switch state {
	case directUpgradeControlClassifyListenerCommit:
		return classifyListenerCommitControlEvent(frame, transportCommitted, strictMode)
	case directUpgradeControlClassifyTerminalFallbackOnly:
		return classifyTerminalFallbackOnlyControlEvent(frame, strictMode)
	case directUpgradeControlClassifyTerminalFallbackSkipReady:
		return classifyTerminalFallbackSkipReadyControlEvent(frame, strictMode)
	case directUpgradeControlClassifyTerminalFallbackListenerCommit:
		return classifyTerminalFallbackCommitControlEvent(frame, strictMode)
	case directUpgradeControlClassifyTerminalFallbackListenerHandoffCommit:
		return classifyTerminalFallbackListenerHandoffCommitControlEvent(frame, strictMode)
	default:
		return directUpgradeControlEvent{
			kind:  directUpgradeControlEventControlError,
			cause: errUnexpectedDirectUpgradeControlState,
		}
	}
}

func classifyListenerCommitControlEvent(frame controlFrameReadResult, transportCommitted, strictMode bool) directUpgradeControlEvent {
	if frame.err != nil {
		if isPreCommitControlTimeout(frame.err) {
			if transportCommitted {
				return directUpgradeControlEvent{
					kind:  directUpgradeControlEventTransportFailure,
					cause: frame.err,
				}
			}
			return directUpgradeControlEvent{
				kind:           directUpgradeControlEventRelayFallback,
				fallbackReason: UpgradeFallbackTransportFailed,
			}
		}
		return directUpgradeControlEvent{
			kind:  directUpgradeControlEventControlError,
			cause: frame.err,
		}
	}

	commit, payloadCause := decodeUpgradeControlPhasePayload(frame.payload, upgradeControlPhaseCommit)
	if strictMode && payloadCause != nil {
		return directUpgradeControlEvent{kind: directUpgradeControlEventControlError, cause: payloadCause}
	}
	if commit.Is(upgradeControlPhaseCommit) {
		return directUpgradeControlEvent{
			kind: directUpgradeControlEventCommitObserved,
		}
	}
	if transportCommitted {
		return directUpgradeControlEvent{
			kind: directUpgradeControlEventTransportFailure,
		}
	}
	return directUpgradeControlEvent{
		kind:           directUpgradeControlEventRelayFallback,
		fallbackReason: commit.FallbackReason,
		wireFallback:   commit.WireFallback,
	}
}

func classifyTerminalFallbackOnlyControlEvent(frame controlFrameReadResult, strictMode bool) directUpgradeControlEvent {
	result := terminalFallbackFromControlFrame(frame, strictMode)
	if result.err != nil {
		return directUpgradeControlEvent{
			kind:  directUpgradeControlEventControlError,
			cause: result.err,
		}
	}
	return directUpgradeControlEvent{
		kind:           directUpgradeControlEventRelayFallback,
		fallbackReason: result.peer.Reason,
		wireFallback:   payloadHasMessageType(frame.payload, upgradeControlMessageFallback),
	}
}

func classifyTerminalFallbackSkipReadyControlEvent(frame controlFrameReadResult, strictMode bool) directUpgradeControlEvent {
	if frame.err != nil {
		return directUpgradeControlEvent{
			kind:  directUpgradeControlEventControlError,
			cause: frame.err,
		}
	}
	ready, payloadCause := decodeUpgradeControlPhasePayload(frame.payload, upgradeControlPhaseReady)
	if strictMode && payloadCause != nil {
		return directUpgradeControlEvent{kind: directUpgradeControlEventControlError, cause: payloadCause}
	}
	if ready.Is(upgradeControlPhaseReady) {
		return directUpgradeControlEvent{
			kind: directUpgradeControlEventIgnoreAndKeepWaiting,
		}
	}
	return directUpgradeControlEvent{
		kind:           directUpgradeControlEventRelayFallback,
		fallbackReason: ready.FallbackReason,
		wireFallback:   ready.WireFallback,
	}
}

func classifyTerminalFallbackCommitControlEvent(frame controlFrameReadResult, strictMode bool) directUpgradeControlEvent {
	event := classifyListenerCommitControlEvent(frame, false, strictMode)
	switch event.kind {
	case directUpgradeControlEventCommitObserved:
		return directUpgradeControlEvent{
			kind: directUpgradeControlEventFailClosedCommitted,
		}
	case directUpgradeControlEventRelayFallback,
		directUpgradeControlEventControlError:
		return event
	default:
		// Terminal fallback commit classification should only emit commit,
		// fallback, or control-error events; preserve an explicit failure if
		// future classifier changes violate that invariant.
		return directUpgradeControlEvent{
			kind:  directUpgradeControlEventControlError,
			cause: errUnexpectedDirectUpgradeControlState,
		}
	}
}

func classifyTerminalFallbackListenerHandoffCommitControlEvent(frame controlFrameReadResult, strictMode bool) directUpgradeControlEvent {
	if frame.err != nil {
		return directUpgradeControlEvent{
			kind:  directUpgradeControlEventControlError,
			cause: frame.err,
		}
	}
	return classifyTerminalFallbackCommitControlEvent(frame, strictMode)
}
