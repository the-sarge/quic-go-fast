package connect

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net"
	"testing"
	"time"
)

func TestScriptedControlChannelDelegatesAndOverridesOperations(t *testing.T) {
	delegate := newScriptedControlChannel([]byte("delegate read"), false)
	channel := newScriptedControlChannel(nil, false)
	channel.delegate = delegate
	channel.readScript = func(p []byte) (int, error) {
		return copy(p, "override read"), nil
	}

	buffer := make([]byte, len("override read"))
	n, err := channel.Read(buffer)
	if err != nil {
		t.Fatalf("Read: %v", err)
	}
	if got := string(buffer[:n]); got != "override read" {
		t.Fatalf("Read = %q, want override read", got)
	}
	if _, err := channel.Write([]byte("delegated write")); err != nil {
		t.Fatalf("Write: %v", err)
	}
	if got := delegate.written(); !bytes.Equal(got, []byte("delegated write")) {
		t.Fatalf("delegate writes = %q, want delegated write", got)
	}
	if err := channel.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	if !delegate.wasClosed() || delegate.closeCallCount() != 1 {
		t.Fatalf("delegate Close state = closed %t, calls %d; want closed with 1 call", delegate.wasClosed(), delegate.closeCallCount())
	}
}

func TestScriptedControlChannelOperationGateAndObservation(t *testing.T) {
	gate := newScriptedOperationGate()
	observed := make(chan controlWriteObservation, 1)
	channel := newScriptedControlChannel(nil, false)
	channel.writeGate = gate
	channel.observeWrite = func(p []byte, n int, err error) {
		if err != nil {
			t.Errorf("observed Write error = %v", err)
		}
		observed <- controlWriteObservation{count: n, payload: append([]byte(nil), p...)}
	}
	done := make(chan error, 1)
	go func() {
		_, err := channel.Write([]byte("gated write"))
		done <- err
	}()
	gate.waitStarted(t)
	select {
	case <-observed:
		t.Fatal("Write observation ran before gate release")
	default:
	}
	gate.release()
	if err := <-done; err != nil {
		t.Fatalf("Write: %v", err)
	}
	observation := <-observed
	if observation.count != len("gated write") || !bytes.Equal(observation.payload, []byte("gated write")) {
		t.Fatalf("Write observation = %+v, want full gated write", observation)
	}
}

func TestScriptedControlChannelCloseReleasesBlockedRead(t *testing.T) {
	gate := newUncancelableScriptedOperationGate()
	channel := newScriptedControlChannel([]byte("late read"), false)
	channel.readGate = gate
	channel.closeReleases = []*scriptedOperationGate{gate}
	done := make(chan error, 1)
	go func() {
		_, err := channel.Read(make([]byte, len("late read")))
		done <- err
	}()
	gate.waitStarted(t)
	if err := channel.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	select {
	case err := <-done:
		if !errors.Is(err, io.ErrClosedPipe) {
			t.Fatalf("Read error = %v, want %v", err, io.ErrClosedPipe)
		}
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("Close did not release the blocked Read")
	}
}

func TestScriptedControlChannelClosedWriteIsObserved(t *testing.T) {
	builtIn := make(chan controlWriteObservation, 1)
	callback := make(chan error, 1)
	channel := newScriptedControlChannel(nil, false)
	channel.writeObserved = builtIn
	channel.observeWrite = func(_ []byte, _ int, err error) { callback <- err }
	if err := channel.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	payload := []byte("write after close")
	if _, err := channel.Write(payload); !errors.Is(err, io.ErrClosedPipe) {
		t.Fatalf("Write error = %v, want %v", err, io.ErrClosedPipe)
	}
	if got := channel.writeCallCount(); got != 1 {
		t.Fatalf("Write calls = %d, want 1", got)
	}
	observation := <-builtIn
	if observation.count != 1 || !bytes.Equal(observation.payload, payload) {
		t.Fatalf("Write observation = %+v, want count 1 and payload %q", observation, payload)
	}
	if err := <-callback; !errors.Is(err, io.ErrClosedPipe) {
		t.Fatalf("observed Write error = %v, want %v", err, io.ErrClosedPipe)
	}
}

func TestControlChannelHelperPreconditions(t *testing.T) {
	t.Run("ready write observation", func(t *testing.T) {
		err := validateReadyWriteObservationFixture(newScriptedControlChannel(nil, false))
		if err == nil || err.Error() != "ready-write helper requires a scripted control write-observation channel" {
			t.Fatalf("fixture validation error = %v, want ready-write observation diagnostic", err)
		}
	})

	t.Run("released reader inspection", func(t *testing.T) {
		channel := newScriptedControlChannel(nil, false)
		channel.readScript = func([]byte) (int, error) { return 0, io.EOF }
		err := validateReleasedControlChannelInspectionFixture(channel)
		if err == nil || err.Error() != "released-control inspection requires a scripted channel backed by its internal reader" {
			t.Fatalf("fixture validation error = %v, want internal-reader diagnostic", err)
		}
	})

	t.Run("released reader constructor", func(t *testing.T) {
		release := make(chan struct{})
		close(release)
		if err := validateReleasedControlChannelInspectionFixture(newReleasedReadControlChannel(nil, release)); err != nil {
			t.Fatalf("released-control fixture validation: %v", err)
		}
	})
}

func TestScriptedSessionDelegatesAndOverridesOperations(t *testing.T) {
	delegateDialStream := noopReadWriteCloser{}
	delegateListener := &scriptedAcceptListener{stream: noopReadWriteCloser{}}
	delegate := &scriptedSession{
		handshake: func() []byte { return []byte("delegate material") },
		dial: func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
			return delegateDialStream, nil
		},
		listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
			return delegateListener, nil
		},
	}
	session := &scriptedSession{
		delegate:  delegate,
		handshake: func() []byte { return nil },
	}

	if material := session.HandshakeMaterial(); material != nil {
		t.Fatalf("HandshakeMaterial = %x, want nil", material)
	}
	stream, err := session.Dial(context.Background(), nil, nil, nil)
	if err != nil {
		t.Fatalf("Dial: %v", err)
	}
	if stream != delegateDialStream {
		t.Fatalf("Dial stream = %T, want delegated %T", stream, delegateDialStream)
	}
	listener, err := session.Listen(context.Background(), nil, nil, nil)
	if err != nil {
		t.Fatalf("Listen: %v", err)
	}
	if listener != delegateListener {
		t.Fatalf("Listen listener = %T, want delegated %T", listener, delegateListener)
	}
	if err := session.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	if !session.wasClosed() || session.closeCallCount() != 1 {
		t.Fatalf("Close state = closed %t, calls %d; want closed with 1 call", session.wasClosed(), session.closeCallCount())
	}
	if !delegate.wasClosed() || delegate.closeCallCount() != 1 {
		t.Fatalf("delegate Close state = closed %t, calls %d; want closed with 1 call", delegate.wasClosed(), delegate.closeCallCount())
	}
}

func TestScriptedSessionGateHonorsCancellation(t *testing.T) {
	gate := newScriptedOperationGate()
	called := false
	session := &scriptedSession{
		dialGate: gate,
		dial: func(context.Context, net.PacketConn, net.Addr, []byte) (io.ReadWriteCloser, error) {
			called = true
			return noopReadWriteCloser{}, nil
		},
	}
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() {
		_, err := session.Dial(ctx, nil, nil, nil)
		done <- err
	}()
	gate.waitStarted(t)
	cancel()

	if err := <-done; !errors.Is(err, context.Canceled) {
		t.Fatalf("Dial error = %v, want %v", err, context.Canceled)
	}
	if called {
		t.Fatal("Dial script ran after gate cancellation")
	}
}

func TestScriptedSessionCloseReleasesBlockedOperation(t *testing.T) {
	gate := newScriptedOperationGate()
	wantListener := &scriptedAcceptListener{stream: noopReadWriteCloser{}}
	session := &scriptedSession{
		listenGate:    gate,
		closeReleases: []*scriptedOperationGate{gate},
		listen: func(context.Context, net.PacketConn, net.Addr, []byte) (TransportListener, error) {
			return wantListener, nil
		},
	}
	done := make(chan TransportListener, 1)
	go func() {
		listener, _ := session.Listen(context.Background(), nil, nil, nil)
		done <- listener
	}()
	gate.waitStarted(t)

	if err := session.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	select {
	case listener := <-done:
		if listener != wantListener {
			t.Fatalf("Listen listener = %T, want %T", listener, wantListener)
		}
	case <-time.After(testCausalObservationTimeout):
		t.Fatal("Close did not release the blocked Listen")
	}
}
