package connect

import (
	"context"
	"errors"
	"net"
	"os"
	"syscall"
	"time"

	"github.com/GridSwarm/wiremux/internal/packetownership"
	"github.com/GridSwarm/wiremux/internal/proberuntime"
)

// UpgradeErrorKind describes why a strict upgrade failed. Only
// UpgradeErrorTransientTransport authorizes considering a transport retry.
type UpgradeErrorKind string

const (
	UpgradeErrorProtocol           UpgradeErrorKind = "protocol"
	UpgradeErrorLocal              UpgradeErrorKind = "local"
	UpgradeErrorTransport          UpgradeErrorKind = "transport"
	UpgradeErrorTransientTransport UpgradeErrorKind = "transient_transport"
	UpgradeErrorCanceled           UpgradeErrorKind = "canceled"
	UpgradeErrorDeadline           UpgradeErrorKind = "deadline"
)

// UpgradeError is a strict negotiation failure with no usable result.
// Unwrap preserves the underlying error identities, including the legacy
// ownership-boundary sentinel. That sentinel alone is not retry authority.
type UpgradeError struct {
	kind  UpgradeErrorKind
	cause error
}

func (e *UpgradeError) Error() string {
	if e.cause == nil {
		return "connect: strict upgrade failure"
	}
	return "connect: strict upgrade " + string(e.kind) + ": " + e.cause.Error()
}
func (e *UpgradeError) Unwrap() error { return e.cause }

// Kind returns the semantic failure category.
func (e *UpgradeError) Kind() UpgradeErrorKind { return e.kind }

var errNilTransportSession = errors.New("connect: transport returned nil session")

var errMalformedUpgradeControl = errors.New("connect: malformed authenticated upgrade control")

// ErrStrictUpgradeTURNUnsupported reports TURN options supplied to UpgradeStrict.
var ErrStrictUpgradeTURNUnsupported = errors.New("connect: strict upgrade does not support TURN options")

// UpgradeStrict attempts an upgrade with semantic terminal failures. It accepts
// Upgrade options except WithTURNAllocator and WithTURNRetryTimeout, which fail
// preflight. Safe negotiated fallback returns the same usable relay result as
// Upgrade; malformed authenticated control returns an UpgradeError and no stream.
// Unknown operation errors are terminal, even if they implement net.Error.
// Caller cancellation and deadline remain distinct from internal phase expiry.
//
// Channel, auth, packet-socket ownership and successful stream lifetime follow
// Upgrade. Preflight leaves inputs untouched; after control begins terminal
// failure aborts the carrier and settles resources through the existing owner.
func (n *Negotiator) UpgradeStrict(ctx context.Context, opts ...UpgradeOption) (UpgradeResult, error) {
	if ctx == nil {
		return UpgradeResult{}, &UpgradeError{UpgradeErrorLocal, ErrNilContext}
	}
	cfg, err := newUpgradeConfig(opts)
	if err != nil {
		return UpgradeResult{}, &UpgradeError{UpgradeErrorLocal, err}
	}
	if cfg.turnAllocatorSet || cfg.turnRetryTimeoutSet {
		return UpgradeResult{}, &UpgradeError{UpgradeErrorLocal, ErrStrictUpgradeTURNUnsupported}
	}
	cfg.strict = true
	attempt := newDirectUpgradeAttempt(n, cfg, packetownership.MarkerFromContext(ctx))
	return attempt.run(ctx)
}

// The token proves provenance without retaining the resource owner in returned
// errors. It has nonzero size so distinct attempts always have distinct tokens.
type (
	strictAttemptToken byte
	strictAttemptError struct {
		token *strictAttemptToken
		kind  UpgradeErrorKind
		cause error
	}
)

func (e *strictAttemptError) Error() string { return e.cause.Error() }
func (e *strictAttemptError) Unwrap() error { return e.cause }

func (r *attemptResources) strictCause(kind UpgradeErrorKind, err error) error {
	if !r.strict || err == nil {
		return err
	}
	return &strictAttemptError{r.strictToken, kind, err}
}

func (r *attemptResources) strictSemanticKind(err error) (UpgradeErrorKind, bool) {
	semantic, ok := err.(*strictAttemptError) //nolint:errorlint // Only the current owner's exact private marker grants authority; never invoke custom As.
	if ok && semantic.token == r.strictToken {
		return semantic.kind, true
	}
	return "", false
}

// Called under the existing terminal seal, before cleanup can cancel the caller.
// Inspect only owner markers and exact local sentinels; external error trees are
// preserved for the caller but never traversed under the resource lock.
func (r *attemptResources) strictFailureKind(err error) UpgradeErrorKind {
	if kind, ok := r.strictSemanticKind(err); ok {
		return kind
	}
	//nolint:errorlint // Exact owner-produced sentinels, not identities in an external error tree.
	switch err {
	case errMalformedUpgradeControl, ErrUpgradeControlFramingFailed, errDatagramExposureAgreementMismatch:
		return UpgradeErrorProtocol
	case errNilTransportStream, errNilTransportListener, errNilTransportSession, errUnexpectedDirectUpgradeControlState, errUnexpectedPostCommitPhaseOrder, errUnexpectedListenerHandoffState, errInvalidAttemptTerminalDisposition:
		return UpgradeErrorLocal
	}
	if r.strictCallerCtx != nil && r.strictCallerCtx.Err() != nil && err == r.strictCallerCtx.Err() { //nolint:errorlint // Caller termination must be the actual settlement cause.
		if r.strictCallerCtx.Err() == context.Canceled {
			return UpgradeErrorCanceled
		}
		return UpgradeErrorDeadline
	}
	return UpgradeErrorTransport
}

// Transport classification is performed only at the owned operation boundary.
// Unwrap only concrete standard-library network wrappers; a custom error or
// joined integrity failure cannot acquire retry authority through net.Error.
func (r *attemptResources) strictTransportCause(err error) error {
	if err == nil {
		return nil
	}
	cause := err
	if op, ok := cause.(*net.OpError); ok && op != nil { //nolint:errorlint // Only concrete standard wrappers may grant retry authority.
		cause = op.Err
	}
	if call, ok := cause.(*os.SyscallError); ok && call != nil { //nolint:errorlint // A custom or joined wrapper must remain terminal.
		cause = call.Err
	}
	errno, ok := cause.(syscall.Errno) //nolint:errorlint // Admit only the exact standard-library leaf, not a matching leaf in an unknown error tree.
	if !ok {
		return r.strictCause(UpgradeErrorTransport, err)
	}
	switch errno {
	case syscall.ENETUNREACH, syscall.EHOSTUNREACH, syscall.ECONNREFUSED, syscall.ECONNRESET, syscall.ETIMEDOUT, syscall.ENETDOWN:
		return r.strictCause(UpgradeErrorTransientTransport, err)
	default:
		return r.strictCause(UpgradeErrorTransport, err)
	}
}

func (a directUpgradeAttempt) terminalControlCause(payloadCause, legacy error) error {
	if !a.cfg.strict {
		return legacy
	}
	if payloadCause != nil {
		return payloadCause
	}
	return ErrUpgradeTransportNotConverged
}

// Unknown transport and invalid local failures cannot be silently converted to
// safe fallback. Known outages and owner-observed internal expiry can.
func (r *attemptResources) strictTerminalCause(err error) bool {
	kind, ok := r.strictSemanticKind(err)
	return ok && kind != UpgradeErrorTransientTransport
}

func (a directUpgradeAttempt) phaseTimeoutCause(err error) error {
	return a.resources().strictCause(UpgradeErrorTransientTransport, err)
}

func (r *attemptResources) strictOwnedOperationCause(ctx context.Context, err error) error {
	if err == nil {
		return nil
	}
	if (err == context.Canceled && ctx.Err() == context.Canceled) || (err == context.DeadlineExceeded && ctx.Err() == context.DeadlineExceeded) { //nolint:errorlint // Exact owner context errors qualify; joined or custom errors do not.
		if r.strictCallerCtx != nil && r.strictCallerCtx.Err() != nil {
			return r.strictCallerCtx.Err()
		}
		return r.strictCause(UpgradeErrorTransientTransport, err)
	}
	return r.strictTransportCause(err)
}

// Probe cancellation is authoritative only at the operation that observes its
// own context. Independent local errors are tagged before joining the probe.
func (r *attemptResources) strictProbeCause(ctx context.Context, err error, local bool) error {
	if !r.strict || err == nil {
		return err
	}
	if _, tagged := r.strictSemanticKind(err); tagged {
		return err
	}
	if ctx.Err() != nil && err == ctx.Err() { //nolint:errorlint // Only the owned operation's exact context error authorizes join suppression.
		kind := UpgradeErrorCanceled
		if ctx.Err() == context.DeadlineExceeded {
			kind = UpgradeErrorDeadline
		}
		return r.strictCause(kind, err)
	}
	if local {
		return r.strictCause(UpgradeErrorLocal, err)
	}
	return r.strictTransportCause(err)
}

// Suppress the join's cancellation only after consumers have retained the
// completed result, including the evidence used to preserve a peer's reason.
func (r *attemptResources) strictJoinedProbeCause(err error) error {
	if kind, tagged := r.strictSemanticKind(err); r.strict && tagged && kind == UpgradeErrorCanceled {
		return nil
	}
	return err
}

// This adapter classifies propagated socket operations at their source.
type strictProbeRuntime struct {
	proberuntime.Runtime
	owner *attemptResources
}

func (s strictProbeRuntime) Send(ctx context.Context, packet []byte, addr net.Addr) error {
	return s.owner.strictProbeCause(ctx, s.Runtime.Send(ctx, packet, addr), false)
}

func (s strictProbeRuntime) Receive(ctx context.Context, packet []byte, deadline time.Time) (int, net.Addr, bool, error) {
	n, addr, received, err := s.Runtime.Receive(ctx, packet, deadline)
	return n, addr, received, s.owner.strictProbeCause(ctx, err, false)
}

// Normalize commit errors while the listener still owns both phase contexts.
// Event reduction and competing receive paths must retain this authority.
func (d directUpgradeProtocolEngine) listenerCommitCause(ctx context.Context, runtime *directUpgradeProtocolRuntime, err error) error {
	r := d.attempt.resources()
	if !d.attempt.cfg.strict || err == nil {
		return err
	}
	if _, tagged := r.strictSemanticKind(err); tagged {
		return err
	}
	if ctx.Err() != nil && err == ctx.Err() { //nolint:errorlint // Exact caller termination is not an internal timeout.
		return r.strictCause(r.strictFailureKind(err), err)
	}
	for _, phase := range []context.Context{runtime.commitBudgetCtx, runtime.handoffCtx} {
		if phase != nil && phase.Err() != nil && err == phase.Err() { //nolint:errorlint // Only this phase owner's exact error grants authority.
			kind := UpgradeErrorTransientTransport
			if phase.Err() == context.Canceled {
				kind = UpgradeErrorCanceled
			}
			return r.strictCause(kind, err)
		}
	}
	return r.strictCause(r.strictFailureKind(err), err)
}

func (d directUpgradeProtocolEngine) listenerCommitTimedOut(ctx context.Context, runtime *directUpgradeProtocolRuntime, err error) bool {
	if !d.attempt.cfg.strict {
		return isPreCommitControlTimeout(err)
	}
	cause := d.listenerCommitCause(ctx, runtime, err)
	kind, tagged := d.attempt.resources().strictSemanticKind(cause)
	return tagged && kind == UpgradeErrorTransientTransport && isPreCommitControlTimeout(cause)
}

func (d directUpgradeProtocolEngine) listenerCommitStopped(ctx context.Context, runtime *directUpgradeProtocolRuntime, err error) bool {
	if !d.attempt.cfg.strict {
		return isStoppedCommitAwait(err)
	}
	cause := d.listenerCommitCause(ctx, runtime, err)
	kind, tagged := d.attempt.resources().strictSemanticKind(cause)
	return tagged && ((kind == UpgradeErrorCanceled && ctx.Err() == nil) || d.listenerCommitTimedOut(ctx, runtime, cause))
}

func (d directUpgradeProtocolEngine) listenerCommitEvent(ctx context.Context, runtime *directUpgradeProtocolRuntime, result commitAwaitResult, committed bool) directUpgradeControlEvent {
	result.err = d.listenerCommitCause(ctx, runtime, result.err)
	event := guardListenerCommitControlEvent(listenerCommitControlEvent(result, committed, d.attempt.cfg.strict))
	if d.attempt.cfg.strict && result.err != nil {
		if !d.listenerCommitTimedOut(ctx, runtime, result.err) {
			return directUpgradeControlEvent{kind: directUpgradeControlEventControlError, cause: result.err}
		}
		event.cause = result.err
	}
	return event
}
