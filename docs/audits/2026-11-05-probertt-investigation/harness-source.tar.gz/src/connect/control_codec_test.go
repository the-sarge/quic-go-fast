package connect

import (
	"bytes"
	"errors"
	"net/netip"
	"testing"
	"time"
)

func TestEncodeUpgradeControlFallbackGolden(t *testing.T) {
	got, err := encodeUpgradeControlFallback(UpgradeFallbackNotRequested)
	if err != nil {
		t.Fatalf("encode fallback: %v", err)
	}

	want := mustHex(t, "00000007a3000201011401")
	if !bytes.Equal(got, want) {
		t.Fatalf("fallback frame = %x, want %x", got, want)
	}
}

func TestReadUpgradeControlFallbackAcceptsExtensionMapGolden(t *testing.T) {
	// u32be(9) || {0: 2, 1: 1, 2: {}, 20: 1}
	frame := mustHex(t, "00000009a40002010102a01401")

	got, err := readUpgradeControlFallback(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("read fallback: %v", err)
	}
	if got.Reason != UpgradeFallbackNotRequested {
		t.Fatalf("fallback reason = %q, want %q", got.Reason, UpgradeFallbackNotRequested)
	}
}

func TestReadUpgradeControlFallbackIgnoresBoundedExtensionEntries(t *testing.T) {
	frame := mustEncodeTestFrame(t, map[uint64]any{
		upgradeControlKeyType:           upgradeControlMessageFallback,
		upgradeControlKeyVersion:        upgradeControlVersion,
		upgradeControlKeyExtensions:     map[any]any{"future": []any{uint64(1), true, nil}},
		upgradeControlKeyFallbackReason: uint64(1),
	})

	got, err := readUpgradeControlFallback(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("read fallback: %v", err)
	}
	if got.Reason != UpgradeFallbackNotRequested {
		t.Fatalf("fallback reason = %q, want %q", got.Reason, UpgradeFallbackNotRequested)
	}
}

func TestEncodeUpgradeControlOfferGolden(t *testing.T) {
	offer := localUpgradeOffer{
		transportName:     "quic",
		handshakeMaterial: []byte{0x01, 0x02},
		probeNonce:        bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		candidates: []Candidate{
			{
				Kind: CandidateKindHost,
				Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
			},
		},
	}

	got, err := encodeUpgradeControlOffer(offer)
	if err != nil {
		t.Fatalf("encode offer: %v", err)
	}

	want := mustHex(t, "00000040a6000101010a64717569630b4201020c582042424242424242424242424242424242424242424242424242424242424242420d81a20001014704c000020a3039")
	if !bytes.Equal(got, want) {
		t.Fatalf("offer frame = %x, want %x", got, want)
	}
}

func TestEncodeUpgradeControlSelectedPairGolden(t *testing.T) {
	selected := selectedPair{
		dialer: Candidate{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
		},
		listener: Candidate{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("198.51.100.20:23456"),
		},
		rtt: 123456789 * time.Nanosecond,
	}

	got, err := encodeUpgradeControlSelectedPair(selected)
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}

	want := mustHex(t, "00000028a500030101181ea20001014704c000020a3039181fa20001014704c63364145ba018201a075bcd15")
	if !bytes.Equal(got, want) {
		t.Fatalf("selected pair frame = %x, want %x", got, want)
	}
}

func TestEncodeUpgradeControlReadyCommitAcceptedConvergedAndConfirmedGolden(t *testing.T) {
	tests := []struct {
		name  string
		phase upgradeControlPhase
		want  string
	}{
		{name: "ready", phase: upgradeControlPhaseReady, want: "00000005a200040101"},
		{name: "commit", phase: upgradeControlPhaseCommit, want: "00000005a200050101"},
		{name: "accepted", phase: upgradeControlPhaseAccepted, want: "00000005a200060101"},
		{name: "converged", phase: upgradeControlPhaseConverged, want: "00000005a200070101"},
		{name: "confirmed", phase: upgradeControlPhaseConfirmed, want: "00000005a200080101"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := encodeUpgradeControlPhase(tt.phase)
			if err != nil {
				t.Fatalf("encode phase: %v", err)
			}
			want := mustHex(t, tt.want)
			if !bytes.Equal(got, want) {
				t.Fatalf("%s frame = %x, want %x", tt.name, got, want)
			}
		})
	}
}

func TestEncodeUpgradeControlDatagramPostCommitGolden(t *testing.T) {
	tests := []struct {
		name  string
		phase upgradeControlPhase
		want  string
	}{
		{name: "accepted", phase: upgradeControlPhaseAccepted, want: "0000001ba30006010102a172776972656d75782e646174616772616d2f31f5"},
		{name: "converged", phase: upgradeControlPhaseConverged, want: "0000001ba30007010102a172776972656d75782e646174616772616d2f31f5"},
		{name: "confirmed", phase: upgradeControlPhaseConfirmed, want: "0000001ba30008010102a172776972656d75782e646174616772616d2f31f5"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			got, err := encodeUpgradeControlPostCommitPhase(test.phase, true)
			if err != nil {
				t.Fatalf("encode Datagram phase: %v", err)
			}
			want := mustHex(t, test.want)
			if !bytes.Equal(got, want) {
				t.Fatalf("Datagram %s frame = %x, want %x", test.name, got, want)
			}
			decoded, _ := decodeUpgradeControlPhasePayload(got[4:], test.phase)
			if !decoded.Is(test.phase) || !decoded.Datagrams || decoded.HasFallback {
				t.Fatalf("decoded Datagram %s = %#v", test.name, decoded)
			}
		})
	}
}

func TestDecodeUpgradeControlDatagramExtensionSemantics(t *testing.T) {
	tests := []struct {
		name          string
		extensions    map[string]any
		wantDatagrams bool
		wantFallback  bool
	}{
		{name: "missing means false", extensions: nil},
		{name: "unknown ignored", extensions: map[string]any{"future": true}},
		{name: "true means present", extensions: map[string]any{upgradeControlDatagramExtension: true}, wantDatagrams: true},
		{name: "false is malformed", extensions: map[string]any{upgradeControlDatagramExtension: false}, wantFallback: true},
		{name: "non boolean is malformed", extensions: map[string]any{upgradeControlDatagramExtension: uint64(1)}, wantFallback: true},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			message := map[uint64]any{
				upgradeControlKeyType:    upgradeControlMessageAccepted,
				upgradeControlKeyVersion: upgradeControlVersion,
			}
			if test.extensions != nil {
				message[upgradeControlKeyExtensions] = test.extensions
			}
			frame := mustEncodeTestFrame(t, message)
			got, _ := decodeUpgradeControlPhasePayload(frame[4:], upgradeControlPhaseAccepted)
			if got.Datagrams != test.wantDatagrams || got.HasFallback != test.wantFallback {
				t.Fatalf("decoded phase = %#v, want Datagrams=%v fallback=%v", got, test.wantDatagrams, test.wantFallback)
			}
		})
	}
}

func TestDecodeRegisteredDatagramExtensionRejectsForbiddenPhases(t *testing.T) {
	offerFrame, err := encodeUpgradeControlOffer(localUpgradeOffer{
		transportName:     "quic",
		handshakeMaterial: []byte{0x01},
		probeNonce:        bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		candidates: []Candidate{{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
		}},
	})
	if err != nil {
		t.Fatalf("encode offer: %v", err)
	}
	fallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackNotRequested)
	if err != nil {
		t.Fatalf("encode fallback: %v", err)
	}
	selectedFrame, err := encodeUpgradeControlSelectedPair(selectedPair{
		dialer:   Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("192.0.2.10:12345")},
		listener: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("198.51.100.20:23456")},
	})
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}
	readyFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseReady)
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	commitFrame, err := encodeUpgradeControlPhase(upgradeControlPhaseCommit)
	if err != nil {
		t.Fatalf("encode commit: %v", err)
	}

	tests := []struct {
		name  string
		frame []byte
		valid func([]byte) bool
	}{
		{name: "offer", frame: offerFrame, valid: func(payload []byte) bool { _, ok := decodeOffer(payload); return ok }},
		{name: "fallback", frame: fallbackFrame, valid: func(payload []byte) bool {
			value, _ := decodeUpgradeControlFallbackPayload(payload)
			return value.Reason == UpgradeFallbackNotRequested
		}},
		{name: "selected pair", frame: selectedFrame, valid: func(payload []byte) bool { _, ok := decodeSelectedPair(payload); return ok }},
		{name: "ready", frame: readyFrame, valid: func(payload []byte) bool {
			value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseReady)
			return value.Is(upgradeControlPhaseReady)
		}},
		{name: "commit", frame: commitFrame, valid: func(payload []byte) bool {
			value, _ := decodeUpgradeControlPhasePayload(payload, upgradeControlPhaseCommit)
			return value.Is(upgradeControlPhaseCommit)
		}},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			registered := addUpgradeControlTestExtension(t, test.frame, upgradeControlDatagramExtension, true)
			if test.valid(registered[4:]) {
				t.Fatal("registered Datagram extension was accepted in a forbidden phase")
			}
			unknown := addUpgradeControlTestExtension(t, test.frame, "future", true)
			if !test.valid(unknown[4:]) {
				t.Fatal("unknown bounded extension was rejected")
			}
		})
	}
}

func addUpgradeControlTestExtension(t *testing.T, frame []byte, key string, value any) []byte {
	t.Helper()
	var message map[uint64]any
	if err := decMode.Unmarshal(frame[4:], &message); err != nil {
		t.Fatalf("decode test frame: %v", err)
	}
	message[upgradeControlKeyExtensions] = map[string]any{key: value}
	return mustEncodeTestFrame(t, message)
}

func TestReadUpgradeControlSelectedPairPhaseAcceptsSelectedPairAndFallback(t *testing.T) {
	selected := selectedPair{
		dialer: Candidate{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
		},
		listener: Candidate{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("198.51.100.20:23456"),
		},
		rtt: 123 * time.Nanosecond,
	}
	frame, err := encodeUpgradeControlSelectedPair(selected)
	if err != nil {
		t.Fatalf("encode selected pair: %v", err)
	}

	got, err := readUpgradeControlSelectedPairPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("read selected-pair phase: %v", err)
	}
	if got.HasFallback {
		t.Fatalf("selected-pair phase fallback = %#v, want selected pair", got)
	}
	if !got.HasSelectedPair {
		t.Fatal("selected-pair phase did not report selected pair")
	}
	if got.SelectedPair != selected {
		t.Fatalf("selected pair = %#v, want %#v", got.SelectedPair, selected)
	}

	fallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackTransportFailed)
	if err != nil {
		t.Fatalf("encode fallback: %v", err)
	}
	fallback, err := readUpgradeControlSelectedPairPhase(bytes.NewReader(fallbackFrame))
	if err != nil {
		t.Fatalf("read fallback selected-pair phase: %v", err)
	}
	if !fallback.HasFallback || fallback.FallbackReason != UpgradeFallbackTransportFailed {
		t.Fatalf("selected-pair phase fallback = %#v, want transport_failed", fallback)
	}
	if !fallback.WireFallback {
		t.Fatalf("selected-pair phase wire fallback = false, want true")
	}
}

func TestReadUpgradeControlReadyAndCommitPhases(t *testing.T) {
	readyFrame, err := encodeUpgradeControlReadyFrame()
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	ready, err := readUpgradeControlReadyPhase(bytes.NewReader(readyFrame))
	if err != nil {
		t.Fatalf("read ready phase: %v", err)
	}
	if !ready.Is(upgradeControlPhaseReady) || ready.HasFallback {
		t.Fatalf("ready phase = %#v, want ready without fallback", ready)
	}

	commitFrame, err := encodeUpgradeControlCommitFrame()
	if err != nil {
		t.Fatalf("encode commit: %v", err)
	}
	commit, err := readUpgradeControlCommitPhase(bytes.NewReader(commitFrame))
	if err != nil {
		t.Fatalf("read commit phase: %v", err)
	}
	if !commit.Is(upgradeControlPhaseCommit) || commit.HasFallback {
		t.Fatalf("commit phase = %#v, want commit without fallback", commit)
	}

	acceptedFrame, err := encodeUpgradeControlAcceptedFrame()
	if err != nil {
		t.Fatalf("encode accepted: %v", err)
	}
	accepted, err := readUpgradeControlAcceptedPhase(bytes.NewReader(acceptedFrame))
	if err != nil {
		t.Fatalf("read accepted phase: %v", err)
	}
	if !accepted.Is(upgradeControlPhaseAccepted) || accepted.HasFallback {
		t.Fatalf("accepted phase = %#v, want accepted without fallback", accepted)
	}

	convergedFrame, err := encodeUpgradeControlConvergedFrame()
	if err != nil {
		t.Fatalf("encode converged: %v", err)
	}
	converged, err := readUpgradeControlConvergedPhase(bytes.NewReader(convergedFrame))
	if err != nil {
		t.Fatalf("read converged phase: %v", err)
	}
	if !converged.Is(upgradeControlPhaseConverged) || converged.HasFallback {
		t.Fatalf("converged phase = %#v, want converged without fallback", converged)
	}

	confirmedFrame, err := encodeUpgradeControlConfirmedFrame()
	if err != nil {
		t.Fatalf("encode confirmed: %v", err)
	}
	confirmed, err := readUpgradeControlConfirmedPhase(bytes.NewReader(confirmedFrame))
	if err != nil {
		t.Fatalf("read confirmed phase: %v", err)
	}
	if !confirmed.Is(upgradeControlPhaseConfirmed) || confirmed.HasFallback {
		t.Fatalf("confirmed phase = %#v, want confirmed without fallback", confirmed)
	}

	fallbackFrame, err := encodeUpgradeControlFallback(UpgradeFallbackProbeFailed)
	if err != nil {
		t.Fatalf("encode fallback: %v", err)
	}
	readyFallback, err := readUpgradeControlReadyPhase(bytes.NewReader(fallbackFrame))
	if err != nil {
		t.Fatalf("read ready fallback: %v", err)
	}
	if !readyFallback.HasFallback || readyFallback.FallbackReason != UpgradeFallbackProbeFailed {
		t.Fatalf("ready fallback = %#v, want probe_failed", readyFallback)
	}
	if !readyFallback.WireFallback {
		t.Fatalf("ready wire fallback = false, want true")
	}
	commitFallback, err := readUpgradeControlCommitPhase(bytes.NewReader(fallbackFrame))
	if err != nil {
		t.Fatalf("read commit fallback: %v", err)
	}
	if !commitFallback.HasFallback || commitFallback.FallbackReason != UpgradeFallbackProbeFailed {
		t.Fatalf("commit fallback = %#v, want probe_failed", commitFallback)
	}
	if !commitFallback.WireFallback {
		t.Fatalf("commit wire fallback = false, want true")
	}
	acceptedFallback, err := readUpgradeControlAcceptedPhase(bytes.NewReader(fallbackFrame))
	if err != nil {
		t.Fatalf("read accepted fallback: %v", err)
	}
	if !acceptedFallback.HasFallback || acceptedFallback.FallbackReason != UpgradeFallbackProbeFailed {
		t.Fatalf("accepted fallback = %#v, want probe_failed", acceptedFallback)
	}
	if !acceptedFallback.WireFallback {
		t.Fatalf("accepted wire fallback = false, want true")
	}
	convergedFallback, err := readUpgradeControlConvergedPhase(bytes.NewReader(fallbackFrame))
	if err != nil {
		t.Fatalf("read converged fallback: %v", err)
	}
	if !convergedFallback.HasFallback || convergedFallback.FallbackReason != UpgradeFallbackProbeFailed {
		t.Fatalf("converged fallback = %#v, want probe_failed", convergedFallback)
	}
	if !convergedFallback.WireFallback {
		t.Fatalf("converged wire fallback = false, want true")
	}
	confirmedFallback, err := readUpgradeControlConfirmedPhase(bytes.NewReader(fallbackFrame))
	if err != nil {
		t.Fatalf("read confirmed fallback: %v", err)
	}
	if !confirmedFallback.HasFallback || confirmedFallback.FallbackReason != UpgradeFallbackProbeFailed {
		t.Fatalf("confirmed fallback = %#v, want probe_failed", confirmedFallback)
	}
	if !confirmedFallback.WireFallback {
		t.Fatalf("confirmed wire fallback = false, want true")
	}
}

func TestUpgradeControlPhaseDecodersMarkSyntheticProtocolMismatch(t *testing.T) {
	readyFrame, err := encodeUpgradeControlReadyFrame()
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	selectedPhase, _ := decodeUpgradeControlSelectedPairPhasePayload(readyFrame[4:])
	if !selectedPhase.HasFallback || selectedPhase.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("ready decoded as selected-pair phase = %#v, want protocol mismatch fallback", selectedPhase)
	}
	if selectedPhase.WireFallback {
		t.Fatal("ready decoded as selected-pair phase reported wire fallback")
	}

	commitFrame, err := encodeUpgradeControlCommitFrame()
	if err != nil {
		t.Fatalf("encode commit: %v", err)
	}
	readyPhase, _ := decodeUpgradeControlPhasePayload(commitFrame[4:], upgradeControlPhaseReady)
	if !readyPhase.HasFallback || readyPhase.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("commit decoded as ready phase = %#v, want protocol mismatch fallback", readyPhase)
	}
	if readyPhase.WireFallback {
		t.Fatal("commit decoded as ready phase reported wire fallback")
	}

	acceptedFrame, err := encodeUpgradeControlAcceptedFrame()
	if err != nil {
		t.Fatalf("encode accepted: %v", err)
	}
	commitPhase, _ := decodeUpgradeControlPhasePayload(acceptedFrame[4:], upgradeControlPhaseCommit)
	if !commitPhase.HasFallback || commitPhase.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("accepted decoded as commit phase = %#v, want protocol mismatch fallback", commitPhase)
	}
	if commitPhase.WireFallback {
		t.Fatal("accepted decoded as commit phase reported wire fallback")
	}

	convergedFrame, err := encodeUpgradeControlConvergedFrame()
	if err != nil {
		t.Fatalf("encode converged: %v", err)
	}
	acceptedPhase, _ := decodeUpgradeControlPhasePayload(convergedFrame[4:], upgradeControlPhaseAccepted)
	if !acceptedPhase.HasFallback || acceptedPhase.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("converged decoded as accepted phase = %#v, want protocol mismatch fallback", acceptedPhase)
	}
	if acceptedPhase.WireFallback {
		t.Fatal("converged decoded as accepted phase reported wire fallback")
	}

	confirmedFrame, err := encodeUpgradeControlConfirmedFrame()
	if err != nil {
		t.Fatalf("encode confirmed: %v", err)
	}
	convergedPhase, _ := decodeUpgradeControlPhasePayload(confirmedFrame[4:], upgradeControlPhaseConverged)
	if !convergedPhase.HasFallback || convergedPhase.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("confirmed decoded as converged phase = %#v, want protocol mismatch fallback", convergedPhase)
	}
	if convergedPhase.WireFallback {
		t.Fatal("confirmed decoded as converged phase reported wire fallback")
	}
}

func TestEncodeUpgradeControlSelectedPairValidatesRTT(t *testing.T) {
	selected := selectedPair{
		dialer: Candidate{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
		},
		listener: Candidate{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("198.51.100.20:23456"),
		},
		rtt: -time.Nanosecond,
	}
	if _, err := encodeUpgradeControlSelectedPair(selected); err == nil {
		t.Fatal("encode selected pair with negative RTT error = nil, want non-nil")
	}
}

func TestEncodeUpgradeControlOfferValidatesLocalFields(t *testing.T) {
	validOffer := localUpgradeOffer{
		transportName:     "quic",
		handshakeMaterial: []byte("fake-handshake-material"),
		probeNonce:        bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		candidates: []Candidate{
			{
				Kind: CandidateKindHost,
				Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
			},
		},
	}
	tooManyCandidates := make([]Candidate, 0, upgradeControlMaxCandidates+1)
	for i := 1; i <= upgradeControlMaxCandidates+1; i++ {
		tooManyCandidates = append(tooManyCandidates, Candidate{
			Kind: CandidateKindHost,
			Addr: netip.AddrPortFrom(netip.AddrFrom4([4]byte{10, 0, 0, byte(i)}), 12345),
		})
	}

	tests := []struct {
		name   string
		mutate func(*localUpgradeOffer)
	}{
		{
			name: "empty transport name",
			mutate: func(offer *localUpgradeOffer) {
				offer.transportName = ""
			},
		},
		{
			name: "non-printable transport name",
			mutate: func(offer *localUpgradeOffer) {
				offer.transportName = "quic\n"
			},
		},
		{
			name: "long transport name",
			mutate: func(offer *localUpgradeOffer) {
				offer.transportName = string(bytes.Repeat([]byte{'q'}, upgradeControlMaxTransportNameBytes+1))
			},
		},
		{
			name: "oversized handshake material",
			mutate: func(offer *localUpgradeOffer) {
				offer.handshakeMaterial = bytes.Repeat([]byte{0x42}, upgradeControlMaxStringBytes+1)
			},
		},
		{
			name: "short probe nonce",
			mutate: func(offer *localUpgradeOffer) {
				offer.probeNonce = bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes-1)
			},
		},
		{
			name: "too many candidates",
			mutate: func(offer *localUpgradeOffer) {
				offer.candidates = tooManyCandidates
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			offer := validOffer
			offer.handshakeMaterial = append([]byte(nil), validOffer.handshakeMaterial...)
			offer.probeNonce = append([]byte(nil), validOffer.probeNonce...)
			offer.candidates = append([]Candidate(nil), validOffer.candidates...)
			tt.mutate(&offer)

			if _, err := encodeUpgradeControlOffer(offer); err == nil {
				t.Fatal("encode offer error = nil, want non-nil")
			}
		})
	}
}

func TestEncodeUpgradeControlOfferRejectsUnsupportedCandidateKind(t *testing.T) {
	offer := localUpgradeOffer{
		transportName:     "quic",
		handshakeMaterial: []byte("handshake"),
		probeNonce:        make([]byte, upgradeControlProbeNonceBytes),
		candidates: []Candidate{
			{Kind: CandidateKindRelay, Addr: mustAddrPort(t, "192.0.2.10:12345")},
		},
	}

	_, err := encodeUpgradeControlOffer(offer)
	if err == nil {
		t.Fatal("encodeUpgradeControlOffer() error = nil, want unsupported candidate kind error")
	}
	if !errors.Is(err, errUnsupportedCandidateKind) {
		t.Fatalf("encodeUpgradeControlOffer() error = %v, want %v", err, errUnsupportedCandidateKind)
	}
	if !bytes.Contains([]byte(err.Error()), []byte(CandidateKindRelay)) {
		t.Fatalf("encodeUpgradeControlOffer() error = %q, want domain kind %q", err, CandidateKindRelay)
	}
}

func TestReadUpgradeControlFirstPhaseAcceptsOffer(t *testing.T) {
	got, err := readUpgradeControlFirstPhase(bytes.NewReader(mustEncodeUpgradeControlOfferFrame(t)))
	if err != nil {
		t.Fatalf("read first phase: %v", err)
	}
	if got.HasFallback {
		t.Fatalf("first phase fallback = %#v, want valid offer without fallback", got)
	}
	if !got.HasOffer {
		t.Fatal("first phase did not report a valid offer")
	}
	if got.Offer.transportName != "fake-stream" {
		t.Fatalf("offer transport name = %q, want fake-stream", got.Offer.transportName)
	}
	if !bytes.Equal(got.Offer.handshakeMaterial, []byte("fake-handshake-material")) {
		t.Fatalf("offer handshake material = %q, want fake-handshake-material", got.Offer.handshakeMaterial)
	}
	if !bytes.Equal(got.Offer.probeNonce, bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes)) {
		t.Fatalf("offer probe nonce = %x, want repeated 0x42", got.Offer.probeNonce)
	}
	wantCandidates := []Candidate{{
		Kind: CandidateKindHost,
		Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
	}}
	if !equalCandidates(got.Offer.candidates, wantCandidates) {
		t.Fatalf("offer candidates = %#v, want %#v", got.Offer.candidates, wantCandidates)
	}
}

func TestReadUpgradeControlFirstPhaseRoundTripsIPv6Candidate(t *testing.T) {
	ipv6Candidate := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "[2001:db8::10]:12345")}
	offer := localUpgradeOffer{
		transportName:     "quic",
		handshakeMaterial: []byte("handshake-material"),
		probeNonce:        bytes.Repeat([]byte{0xab}, upgradeControlProbeNonceBytes),
		candidates:        []Candidate{ipv6Candidate},
	}

	frame, err := encodeUpgradeControlOffer(offer)
	if err != nil {
		t.Fatalf("encodeUpgradeControlOffer() error = %v", err)
	}
	got, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("readUpgradeControlFirstPhase() error = %v", err)
	}
	if got.HasFallback {
		t.Fatalf("first phase fallback = %#v, want IPv6 offer", got)
	}
	if !got.HasOffer {
		t.Fatal("first phase did not report an offer")
	}
	if len(got.Offer.candidates) != 1 {
		t.Fatalf("len(candidates) = %d, want 1: %#v", len(got.Offer.candidates), got.Offer.candidates)
	}
	if got.Offer.candidates[0] != ipv6Candidate {
		t.Fatalf("candidate = %#v, want %#v", got.Offer.candidates[0], ipv6Candidate)
	}
}

func TestReadUpgradeControlFirstPhaseRejectsIPv4MappedIPv6Candidate(t *testing.T) {
	addr := netip.MustParseAddr("::ffff:192.0.2.10")
	raw := addr.As16()
	addrPort := make([]byte, 19)
	addrPort[0] = 0x06
	copy(addrPort[1:17], raw[:])
	addrPort[17] = 0x30
	addrPort[18] = 0x39
	frame := mustEncodeTestFrame(t, map[uint64]any{
		upgradeControlKeyType:          upgradeControlMessageOffer,
		upgradeControlKeyVersion:       upgradeControlVersion,
		upgradeControlKeyTransportName: "quic",
		upgradeControlKeyHandshake:     []byte("handshake-material"),
		upgradeControlKeyProbeNonce:    bytes.Repeat([]byte{0xab}, upgradeControlProbeNonceBytes),
		upgradeControlKeyCandidates: []any{
			map[uint64]any{
				upgradeControlCandidateKeyKind:     upgradeControlCandidateKindHostCode,
				upgradeControlCandidateKeyAddrPort: addrPort,
			},
		},
	})

	got, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("readUpgradeControlFirstPhase() error = %v", err)
	}
	if !got.HasFallback {
		t.Fatalf("first phase accepted IPv4-mapped IPv6 candidate: %#v", got)
	}
	if got.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("fallback reason = %q, want %q", got.FallbackReason, UpgradeFallbackProtocolMismatch)
	}
}

func TestReadUpgradeControlFirstPhaseRejectsUnknownCandidateKind(t *testing.T) {
	frame := mustEncodeTestFrame(t, map[uint64]any{
		upgradeControlKeyType:          upgradeControlMessageOffer,
		upgradeControlKeyVersion:       upgradeControlVersion,
		upgradeControlKeyTransportName: "quic",
		upgradeControlKeyHandshake:     []byte("handshake-material"),
		upgradeControlKeyProbeNonce:    bytes.Repeat([]byte{0xab}, upgradeControlProbeNonceBytes),
		upgradeControlKeyCandidates: []any{
			map[uint64]any{
				upgradeControlCandidateKeyKind:     uint64(99),
				upgradeControlCandidateKeyAddrPort: []byte{0x04, 192, 0, 2, 10, 0x30, 0x39},
			},
		},
	})

	got, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("readUpgradeControlFirstPhase() error = %v", err)
	}
	if !got.HasFallback {
		t.Fatalf("first phase accepted unknown candidate kind: %#v", got)
	}
	if got.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("fallback reason = %q, want %q", got.FallbackReason, UpgradeFallbackProtocolMismatch)
	}
}

func TestReadUpgradeControlFirstPhaseValidatesOfferTransportName(t *testing.T) {
	tests := []struct {
		name          string
		transportName string
		wantFallback  bool
	}{
		{
			name:          "printable ASCII",
			transportName: "quic",
		},
		{
			name:          "NUL",
			transportName: "quic\x00",
			wantFallback:  true,
		},
		{
			name:          "C0 control",
			transportName: "quic\t",
			wantFallback:  true,
		},
		{
			name:          "DEL",
			transportName: "quic\x7f",
			wantFallback:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			frame := mustEncodeUpgradeControlOfferFrameWithTransport(t, tt.transportName)

			got, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
			if err != nil {
				t.Fatalf("read first phase: %v", err)
			}
			if got.HasFallback != tt.wantFallback {
				t.Fatalf("first phase fallback = %v, want %v", got.HasFallback, tt.wantFallback)
			}
			if tt.wantFallback && got.FallbackReason != UpgradeFallbackProtocolMismatch {
				t.Fatalf("fallback reason = %q, want %q", got.FallbackReason, UpgradeFallbackProtocolMismatch)
			}
		})
	}
}

func TestReadUpgradeControlFirstPhaseRejectsMalformedOfferAsProtocolMismatch(t *testing.T) {
	frame := mustEncodeTestFrame(t, map[uint64]any{
		upgradeControlKeyType:          upgradeControlMessageOffer,
		upgradeControlKeyVersion:       upgradeControlVersion,
		upgradeControlKeyTransportName: "fake-stream",
		upgradeControlKeyHandshake:     []byte("fake-handshake-material"),
		upgradeControlKeyProbeNonce:    bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		upgradeControlKeyCandidates:    []any{},
	})

	got, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("read first phase: %v", err)
	}
	if !got.HasFallback {
		t.Fatal("first phase accepted malformed offer, want protocol mismatch fallback")
	}
	if got.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("fallback reason = %q, want %q", got.FallbackReason, UpgradeFallbackProtocolMismatch)
	}
}

func TestUpgradeControlReadersClassifyFramingFailures(t *testing.T) {
	tests := []struct {
		name    string
		frame   []byte
		wantErr error
	}{
		{
			name:    "oversize",
			frame:   []byte{0x00, 0x01, 0x00, 0x01},
			wantErr: errUpgradeControlFrameOversize,
		},
		{
			name:    "truncated",
			frame:   []byte{0x00, 0x00, 0x00, 0x03, 0xa1},
			wantErr: errUpgradeControlFrameTruncated,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name+"/first phase", func(t *testing.T) {
			got, err := readUpgradeControlFirstPhase(bytes.NewReader(tt.frame))
			if err == nil {
				t.Fatal("readUpgradeControlFirstPhase() error = nil, want framing error")
			}
			if got.HasFallback || got.HasOffer {
				t.Fatalf("first phase = %#v, want zero value", got)
			}
			assertUpgradeControlFramingError(t, err, tt.wantErr)
		})
		t.Run(tt.name+"/fallback", func(t *testing.T) {
			got, err := readUpgradeControlFallback(bytes.NewReader(tt.frame))
			if err == nil {
				t.Fatal("readUpgradeControlFallback() error = nil, want framing error")
			}
			if got != (upgradeControlFallback{}) {
				t.Fatalf("fallback = %#v, want zero value", got)
			}
			assertUpgradeControlFramingError(t, err, tt.wantErr)
		})
		t.Run(tt.name+"/raw frame", func(t *testing.T) {
			got, err := readUpgradeControlFrame(bytes.NewReader(tt.frame))
			if err == nil {
				t.Fatal("readUpgradeControlFrame() error = nil, want framing error")
			}
			if got != nil {
				t.Fatalf("frame = %x, want nil", got)
			}
			assertUpgradeControlFramingError(t, err, tt.wantErr)
		})
	}
}

func TestReadUpgradeControlFallbackRejectsDuplicateKeysAsProtocolMismatch(t *testing.T) {
	// u32be(9) || {0: 2, 0: 2, 1: 1, 20: 1}
	frame := mustHex(t, "00000009a40002000201011401")

	got, err := readUpgradeControlFallback(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("read fallback: %v", err)
	}
	if got.Reason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("fallback reason = %q, want %q", got.Reason, UpgradeFallbackProtocolMismatch)
	}
}

func TestReadUpgradeControlFallbackRejectsNonDeterministicEncodingAsProtocolMismatch(t *testing.T) {
	// u32be(8) || {0: 2, 1: 1, 20: 1}, with value 2 encoded as uint8.
	frame := mustHex(t, "00000008a300180201011401")

	got, err := readUpgradeControlFallback(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("read fallback: %v", err)
	}
	if got.Reason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("fallback reason = %q, want %q", got.Reason, UpgradeFallbackProtocolMismatch)
	}
}

func TestReadUpgradeControlFallbackRejectsFloatExtensionsAsProtocolMismatch(t *testing.T) {
	tests := []struct {
		name  string
		frame []byte
	}{
		{
			name:  "float16 extension value",
			frame: mustHex(t, "0000000ea40002010102a16166f900141401"),
		},
		{
			name:  "float32 extension value",
			frame: mustHex(t, "00000010a40002010102a16166fa000000001401"),
		},
		{
			name:  "float64 extension value",
			frame: mustHex(t, "00000014a40002010102a16166fb00000000000000001401"),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := readUpgradeControlFallback(bytes.NewReader(tt.frame))
			if err != nil {
				t.Fatalf("read fallback: %v", err)
			}
			if got.Reason != UpgradeFallbackProtocolMismatch {
				t.Fatalf("fallback reason = %q, want %q", got.Reason, UpgradeFallbackProtocolMismatch)
			}
		})
	}
}

func TestReadUpgradeControlFallbackRejectsMalformedPayloadsAsProtocolMismatch(t *testing.T) {
	tests := []struct {
		name   string
		fields any
	}{
		{
			name: "missing type",
			fields: map[uint64]uint64{
				upgradeControlKeyVersion:        upgradeControlVersion,
				upgradeControlKeyFallbackReason: 1,
			},
		},
		{
			name: "missing version",
			fields: map[uint64]uint64{
				upgradeControlKeyType:           upgradeControlMessageFallback,
				upgradeControlKeyFallbackReason: 1,
			},
		},
		{
			name: "missing reason",
			fields: map[uint64]uint64{
				upgradeControlKeyType:    upgradeControlMessageFallback,
				upgradeControlKeyVersion: upgradeControlVersion,
			},
		},
		{
			name: "unknown message type",
			fields: map[uint64]uint64{
				upgradeControlKeyType:           99,
				upgradeControlKeyVersion:        upgradeControlVersion,
				upgradeControlKeyFallbackReason: 1,
			},
		},
		{
			name: "unknown version",
			fields: map[uint64]uint64{
				upgradeControlKeyType:           upgradeControlMessageFallback,
				upgradeControlKeyVersion:        99,
				upgradeControlKeyFallbackReason: 1,
			},
		},
		{
			name: "unknown reason",
			fields: map[uint64]uint64{
				upgradeControlKeyType:           upgradeControlMessageFallback,
				upgradeControlKeyVersion:        upgradeControlVersion,
				upgradeControlKeyFallbackReason: 99,
			},
		},
		{
			name: "malformed extensions",
			fields: map[uint64]uint64{
				upgradeControlKeyType:           upgradeControlMessageFallback,
				upgradeControlKeyVersion:        upgradeControlVersion,
				upgradeControlKeyExtensions:     0,
				upgradeControlKeyFallbackReason: 1,
			},
		},
		{
			name: "unknown core field",
			fields: map[uint64]uint64{
				upgradeControlKeyType:           upgradeControlMessageFallback,
				upgradeControlKeyVersion:        upgradeControlVersion,
				3:                               0,
				upgradeControlKeyFallbackReason: 1,
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			frame := mustEncodeTestFrame(t, tt.fields)

			got, err := readUpgradeControlFallback(bytes.NewReader(frame))
			if err != nil {
				t.Fatalf("read fallback: %v", err)
			}
			if got.Reason != UpgradeFallbackProtocolMismatch {
				t.Fatalf("fallback reason = %q, want %q", got.Reason, UpgradeFallbackProtocolMismatch)
			}
		})
	}
}

func TestReadUpgradeControlFallbackRejectsIncompleteFramesAsErrors(t *testing.T) {
	tests := []struct {
		name  string
		frame []byte
	}{
		{
			name:  "oversize payload",
			frame: mustHex(t, "00010001"),
		},
		{
			name:  "short payload",
			frame: mustHex(t, "00000003a1"),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := readUpgradeControlFallback(bytes.NewReader(tt.frame))
			if err == nil {
				t.Fatal("read fallback error = nil, want non-nil")
			}
			if got != (upgradeControlFallback{}) {
				t.Fatalf("fallback message = %#v, want zero value", got)
			}
		})
	}
}

func assertUpgradeControlFramingError(t *testing.T, err, wantErr error) {
	t.Helper()
	if !errors.Is(err, ErrUpgradeControlFramingFailed) {
		t.Fatalf("error = %v, want %v classification", err, ErrUpgradeControlFramingFailed)
	}
	if !errors.Is(err, wantErr) {
		t.Fatalf("error = %v, want underlying %v", err, wantErr)
	}
}

func mustEncodeTestFrame(t *testing.T, fields any) []byte {
	t.Helper()

	frame, err := encodeUpgradeControlTestFrame(fields)
	if err != nil {
		t.Fatalf("encode test frame %#v: %v", fields, err)
	}
	return frame
}

// TestDecodeUpgradeControlRejectsNonCanonicalUint pins the canonical-uint
// policy on the upgrade-control decode path: the shared scanner's
// readCBORHead accepts only minimal-length heads, so a two-byte encoding of a
// value below 24 must reject even though it is well-formed CBOR. The
// turn-retry codec pins the same policy in its own decode tests.
func TestDecodeUpgradeControlRejectsNonCanonicalUint(t *testing.T) {
	// map{0:4,1:1} — a canonical Ready payload.
	canonical := mustHex(t, "a200040101")
	if result, _ := decodeUpgradeControlPhasePayload(canonical, upgradeControlPhaseReady); !result.Is(upgradeControlPhaseReady) {
		t.Fatal("rejected canonical ready payload")
	}
	// The same map with the type value 4 encoded as 24(4) instead of 4.
	nonCanonical := mustHex(t, "a20018040101")
	result, _ := decodeUpgradeControlPhasePayload(nonCanonical, upgradeControlPhaseReady)
	if result.Is(upgradeControlPhaseReady) {
		t.Fatal("accepted non-canonical uint value encoding")
	}
	if !result.HasFallback || result.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("non-canonical uint: got %+v, want protocol-mismatch fallback", result)
	}
}
