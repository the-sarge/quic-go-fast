package connect

import (
	"testing"
	"time"
)

func TestSelectedPairLocalRemoteByRole(t *testing.T) {
	dialer := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.20:20000")}
	listener := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.10:10000")}
	selected := selectedPair{dialer: dialer, listener: listener}

	tests := []struct {
		name       string
		role       upgradeRole
		wantLocal  Candidate
		wantRemote Candidate
	}{
		{
			name:       "dialer view",
			role:       upgradeRoleDial,
			wantLocal:  dialer,
			wantRemote: listener,
		},
		{
			name:       "listener view",
			role:       upgradeRoleListen,
			wantLocal:  listener,
			wantRemote: dialer,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := selected.local(tt.role); got != tt.wantLocal {
				t.Fatalf("local(%v) = %#v, want %#v", tt.role, got, tt.wantLocal)
			}
			if got := selected.remote(tt.role); got != tt.wantRemote {
				t.Fatalf("remote(%v) = %#v, want %#v", tt.role, got, tt.wantRemote)
			}
		})
	}
}

func TestSelectedPairCandidatePairByRole(t *testing.T) {
	dialer := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.20:20000")}
	listener := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.10:10000")}
	selected := selectedPair{dialer: dialer, listener: listener}

	tests := []struct {
		name string
		role upgradeRole
		want CandidatePair
	}{
		{
			name: "dialer view",
			role: upgradeRoleDial,
			want: CandidatePair{Local: dialer, Remote: listener},
		},
		{
			name: "listener view",
			role: upgradeRoleListen,
			want: CandidatePair{Local: listener, Remote: dialer},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := selected.candidatePair(tt.role); got != tt.want {
				t.Fatalf("candidatePair(%v) = %#v, want %#v", tt.role, got, tt.want)
			}
		})
	}
}

func TestSelectedPairProbeResultWireRoundTrip(t *testing.T) {
	dialer := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.20:20000")}
	listener := Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.10:10000")}
	probeRTT := 7 * time.Millisecond

	selected := selectedPairFromProbeResult(candidatePairProbeResult{
		succeeded: true,
		pair:      probeCandidatePair{local: dialer, remote: listener},
		rtt:       probeRTT,
	})
	if selected != (selectedPair{dialer: dialer, listener: listener, rtt: probeRTT}) {
		t.Fatalf("selectedPairFromProbeResult() = %#v, want dialer/listener/rtt fixture", selected)
	}

	frame, err := encodeUpgradeControlSelectedPair(selected)
	if err != nil {
		t.Fatalf("encodeUpgradeControlSelectedPair() error = %v", err)
	}
	decoded, _ := decodeUpgradeControlSelectedPairPhasePayload(frame[4:])
	if !decoded.HasSelectedPair {
		t.Fatal("decoded phase did not report a selected pair")
	}
	if decoded.SelectedPair != selected {
		t.Fatalf("decoded selected pair = %#v, want %#v", decoded.SelectedPair, selected)
	}
}

func TestSelectedProbeRTTUsesKnownValueAndFallback(t *testing.T) {
	known := 7 * time.Millisecond
	fallback := 11 * time.Millisecond

	if got := selectedProbeRTT(selectedPair{rtt: known}, fallback); got != known {
		t.Fatalf("selectedProbeRTT known = %s, want %s", got, known)
	}
	if got := selectedProbeRTT(selectedPair{}, fallback); got != fallback {
		t.Fatalf("selectedProbeRTT unknown = %s, want fallback %s", got, fallback)
	}
}

func TestSelectedPairRTTWirePresence(t *testing.T) {
	dialer := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.20:20000")}
	listener := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "198.51.100.10:10000")}

	tests := []struct {
		name        string
		rtt         time.Duration
		wantSet     bool
		wantWireRTT uint64
	}{
		{
			name:    "unknown",
			rtt:     0,
			wantSet: false,
		},
		{
			name:        "known",
			rtt:         123 * time.Nanosecond,
			wantSet:     true,
			wantWireRTT: 123,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			frame, err := encodeUpgradeControlSelectedPair(selectedPair{
				dialer:   dialer,
				listener: listener,
				rtt:      tt.rtt,
			})
			if err != nil {
				t.Fatalf("encodeUpgradeControlSelectedPair() error = %v", err)
			}

			fields := mustDecodeUpgradeControlPayloadFields(t, frame[4:])
			wireRTTPayload, gotSet := fields[upgradeControlKeyProbeRTTNanos]
			if gotSet != tt.wantSet {
				t.Fatalf("wire RTT field present = %t, want %t", gotSet, tt.wantSet)
			}
			if gotSet {
				gotWireRTT, ok := decodeUint(wireRTTPayload)
				if !ok {
					t.Fatalf("wire RTT field is not uint: %x", wireRTTPayload)
				}
				if gotWireRTT != tt.wantWireRTT {
					t.Fatalf("wire RTT = %d, want %d", gotWireRTT, tt.wantWireRTT)
				}
			}

			got, ok := decodeSelectedPair(frame[4:])
			if !ok {
				t.Fatal("decodeSelectedPair() ok = false, want true")
			}
			if got.rtt != tt.rtt {
				t.Fatalf("round-trip RTT = %s, want %s", got.rtt, tt.rtt)
			}
		})
	}
}

func mustDecodeUpgradeControlPayloadFields(t *testing.T, payload []byte) map[uint64][]byte {
	t.Helper()

	entries, ok := decodeTopLevelMap(payload)
	if !ok {
		t.Fatalf("decodeTopLevelMap(%x) ok = false, want true", payload)
	}
	fields, _, ok := decodeCommonFields(entries)
	if !ok {
		t.Fatalf("decodeCommonFields(%x) ok = false, want true", payload)
	}
	return fields
}

func TestEncodeUpgradeControlSelectedPairRejectsNegativeRTT(t *testing.T) {
	dialer := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.20:20000")}
	listener := Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "198.51.100.10:10000")}

	if _, err := encodeUpgradeControlSelectedPair(selectedPair{dialer: dialer, listener: listener, rtt: -time.Nanosecond}); err == nil {
		t.Fatal("encodeUpgradeControlSelectedPair() error = nil, want negative probe RTT error")
	}
}

func TestDecodeSelectedPairRejectsOutOfRangeRTT(t *testing.T) {
	frame := mustEncodeTestFrame(t, map[uint64]any{
		upgradeControlKeyType:    upgradeControlMessageSelectedPair,
		upgradeControlKeyVersion: upgradeControlVersion,
		upgradeControlKeyDialerCandidate: map[uint64]any{
			upgradeControlCandidateKeyKind:     upgradeControlCandidateKindHostCode,
			upgradeControlCandidateKeyAddrPort: []byte{0x04, 192, 0, 2, 20, 0x4e, 0x20},
		},
		upgradeControlKeyListenerCandidate: map[uint64]any{
			upgradeControlCandidateKeyKind:     upgradeControlCandidateKindHostCode,
			upgradeControlCandidateKeyAddrPort: []byte{0x04, 198, 51, 100, 10, 0x27, 0x10},
		},
		upgradeControlKeyProbeRTTNanos: upgradeControlMaxProbeRTTNanos + 1,
	})

	if got, ok := decodeSelectedPair(frame[4:]); ok {
		t.Fatalf("decodeSelectedPair() = (%#v, true), want invalid RTT rejection", got)
	}

	phase, _ := decodeUpgradeControlSelectedPairPhasePayload(frame[4:])
	if !phase.HasFallback || phase.FallbackReason != UpgradeFallbackProtocolMismatch {
		t.Fatalf("selected-pair phase = %#v, want protocol mismatch fallback", phase)
	}
}
