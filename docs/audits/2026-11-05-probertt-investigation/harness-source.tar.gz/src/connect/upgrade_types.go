package connect

import (
	"errors"
	"io"
	"net"
	"net/netip"
	"strings"
	"time"

	"github.com/GridSwarm/wiremux/internal/lifecycle"
	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// UpgradeOption configures a direct-upgrade attempt.
type UpgradeOption func(*upgradeConfig)

// CandidatePair is the local/remote candidate pair selected for a direct path.
type CandidatePair struct {
	Local  Candidate
	Remote Candidate
}

// UpgradePath identifies the active path returned by Upgrade.
type UpgradePath string

const (
	UpgradePathRelay  UpgradePath = "relay"
	UpgradePathDirect UpgradePath = "direct"
)

// UpgradeFallbackReason identifies why a relay-path result was selected.
type UpgradeFallbackReason string

// UpgradeFallbackReason literals are the public values used by the
// fallback-reason authority. TestFallbackReasonRegistryMirrorsPRDAndPhasePrecedence
// guards drift between these public constants and the wire/precedence table.
const (
	// UpgradeFallbackNone is the no-fallback sentinel. It intentionally has no
	// wire code, phase membership, or precedence rank.
	UpgradeFallbackNone UpgradeFallbackReason = ""
	// UpgradeFallbackNotRequested means direct upgrade was not requested by configuration.
	UpgradeFallbackNotRequested UpgradeFallbackReason = "not_requested"
	// UpgradeFallbackPolicyExcluded means candidate policy excluded all usable paths.
	UpgradeFallbackPolicyExcluded UpgradeFallbackReason = "policy_excluded"
	// UpgradeFallbackNoCandidates means no local candidates were available to offer.
	UpgradeFallbackNoCandidates UpgradeFallbackReason = "no_candidates"
	// UpgradeFallbackTransportMismatch means the peers could not agree on a transport.
	UpgradeFallbackTransportMismatch UpgradeFallbackReason = "transport_mismatch"
	// UpgradeFallbackProtocolMismatch means peer control data was unsupported or invalid.
	UpgradeFallbackProtocolMismatch UpgradeFallbackReason = "protocol_mismatch"
	// UpgradeFallbackProbeFailed means direct-path probing did not produce a selected pair.
	UpgradeFallbackProbeFailed UpgradeFallbackReason = "probe_failed"
	// UpgradeFallbackTransportFailed means direct transport setup failed after candidate work.
	UpgradeFallbackTransportFailed UpgradeFallbackReason = "transport_failed"
)

// UpgradeResult contains the active reliable stream, optional pairwise-agreed
// Datagram carrier, and path metadata returned by Upgrade. Datagrams was added
// as the second exported field, so unkeyed literals written for the earlier
// five-field shape no longer compile; consumers must migrate them to keyed
// literals. The pre-release public shape may continue to evolve.
type UpgradeResult struct {
	// Stream is the active reliable-only path. It never implements
	// DatagramCapable after Upgrade returns.
	Stream io.ReadWriteCloser
	// Datagrams is the optional pairwise-agreed lower carrier. Its payloads
	// include the wiremux envelope and follow DatagramCarrier's admission,
	// ownership, context, and lifetime contract. Nil is normal capability
	// absence; the Stream remains usable.
	Datagrams      DatagramCarrier
	Path           UpgradePath
	SelectedPair   *CandidatePair
	ProbeRTT       time.Duration
	FallbackReason UpgradeFallbackReason
}

// CandidatePolicy controls which candidates direct upgrade may advertise or try.
// Local filters apply before this peer's offer is encoded. Remote filters apply
// after an authenticated peer offer is decoded and before UDP probing starts.
// Authentication proves which peer advertised a remote candidate, but it is not
// a range policy: valid unicast remote host/reflexive candidates are not broadly
// excluded by default. Deployments that need stricter egress controls should
// set ExcludeRemotePrefixes; deployments that only prefer another path should
// set DeprioritizeRemotePrefixes. Interface filters are local-only, prefix
// filters use the local or remote fields for their respective side, and kind
// filters apply to both local advertisement and remote probing.
//
// STUN reflexive candidates can have no known local interface, commonly when
// gathered from a wildcard-bound packet socket, or when an explicit bound
// address cannot be mapped to an enumerable interface. To avoid leaking a path
// that might have come from an excluded or deprioritized interface, an
// unknown-interface reflexive candidate matches any non-empty
// ExcludeLocalInterfaces rule and is excluded conservatively; it also matches
// any non-empty DeprioritizeLocalInterfaces rule and is deprioritized
// conservatively. This conservative unknown-interface rule is specific to
// reflexive candidates; host candidates from explicit binds are caller-selected,
// and interface filters match them only when the bound address resolves to a
// local interface name.
type CandidatePolicy struct {
	ExcludeLocalInterfaces      []string
	DeprioritizeLocalInterfaces []string
	ExcludeLocalPrefixes        []netip.Prefix
	DeprioritizeLocalPrefixes   []netip.Prefix
	ExcludeRemotePrefixes       []netip.Prefix
	DeprioritizeRemotePrefixes  []netip.Prefix
	ExcludeKinds                []CandidateKind
	DeprioritizeKinds           []CandidateKind
}

var (
	ErrUpgradePacketConnWithoutTransport = errors.New("connect: upgrade packet conn requires transport")
	ErrInvalidProbeTimeout               = errors.New("connect: probe timeout must be positive")
	ErrInvalidControlTimeout             = errors.New("connect: control exchange timeout must be positive")
	ErrInvalidProbeConcurrency           = errors.New("connect: probe concurrency must be between 1 and 16")
	ErrInvalidCandidatePolicy            = errors.New("connect: candidate policy is invalid")
	ErrUpgradeControlTimeout             = errors.New("connect: upgrade-control exchange timed out")
	// ErrNilTURNAllocator reports WithTURNAllocator configured with a nil
	// allocator.
	ErrNilTURNAllocator = errors.New("connect: TURN allocator must be non-nil")
	// ErrInvalidTURNRetryTimeout reports a non-positive WithTURNRetryTimeout.
	ErrInvalidTURNRetryTimeout = errors.New("connect: TURN retry timeout must be positive")
	// ErrTURNTransportUnsupported reports a TURN configuration whose final
	// configured transport is not the exact eligible built-in QUIC transport
	// value or non-nil pointer. Validation rejects before any control or
	// network I/O; typed-nil, additional-pointer, custom, named-wrapper, and
	// embedding-wrapper transports remain valid only when TURN is omitted.
	ErrTURNTransportUnsupported = errors.New("connect: configured transport is not TURN-eligible")
	// ErrUpgradeControlFramingFailed classifies truncated or oversized upgrade-control frames.
	ErrUpgradeControlFramingFailed = errors.New("connect: upgrade-control framing failed")
	// ErrUpgradeTransportNotConverged reports direct-transport failure after
	// the applicable local ownership boundary: local commit or any non-nil
	// stream returned by Session.Dial or TransportListener.Accept, including a
	// stream returned with an error.
	ErrUpgradeTransportNotConverged = errors.New("connect: direct transport did not converge after ownership transfer")
)

const (
	defaultUpgradeProbeTimeout     = 3 * time.Second
	defaultUpgradeControlTimeout   = lifecycle.DefaultUpgradeControlTimeout
	defaultUpgradeProbeConcurrency = 4
	defaultTURNRetryTimeout        = 5 * time.Second
)

type upgradeConfig struct {
	strict              bool
	transport           Transport
	transportSet        bool
	packetConn          net.PacketConn
	packetConnSet       bool
	stunServer          net.Addr
	stunServerSet       bool
	probeTimeout        time.Duration
	probeTimeoutSet     bool
	controlTimeout      time.Duration
	controlTimeoutSet   bool
	probeConcurrency    int
	probeConcurrencySet bool
	candidatePolicy     CandidatePolicy
	testGatherer        candidateGatherer
	// testTurnRetryProbeRunner replaces the retry probe execution launched by
	// startRetryProbe; nil in production.
	testTurnRetryProbeRunner turnRetryProbeRunner
	turnAllocator            RelayPacketAllocator
	turnAllocatorSet         bool
	turnRetryTimeout         time.Duration
	turnRetryTimeoutSet      bool
}

// WithTransport sets the direct-upgrade transport implementation.
func WithTransport(transport Transport) UpgradeOption {
	return func(cfg *upgradeConfig) {
		cfg.transport = transport
		cfg.transportSet = true
	}
}

// WithUpgradePacketConn sets the packet socket used for direct upgrade.
// The outcome-dependent ownership boundaries are role-specific:
//   - callers retain ownership until local direct-transport commit or any
//     non-nil stream returned by Session.Dial or TransportListener.Accept;
//   - a non-nil stream transfers ownership even with an accompanying error and
//     before listener commit is observed.
//
// On direct success, the returned stream owns cleanup. After the applicable
// boundary, later failure closes direct transport resources and conn before
// returning ErrUpgradeTransportNotConverged with no active stream; relay
// fallback is not available.
func WithUpgradePacketConn(conn net.PacketConn) UpgradeOption {
	return func(cfg *upgradeConfig) {
		cfg.packetConn = conn
		cfg.packetConnSet = true
	}
}

// WithUpgradeSTUNServer sets the STUN server used by Upgrade candidate gathering.
func WithUpgradeSTUNServer(addr net.Addr) UpgradeOption {
	return func(cfg *upgradeConfig) {
		cfg.stunServer = addr
		cfg.stunServerSet = true
	}
}

// WithProbeTimeout sets the direct-probe timeout. After the applicable local
// ownership boundary (local commit or any non-nil Session.Dial or
// TransportListener.Accept stream), each subsequent transport setup or
// convergence wait receives a fresh budget from this same timeout. A non-nil
// listener Accept result can start that budget before commit is observed.
func WithProbeTimeout(timeout time.Duration) UpgradeOption {
	return func(cfg *upgradeConfig) {
		cfg.probeTimeout = timeout
		cfg.probeTimeoutSet = true
	}
}

// WithUpgradeControlTimeout sets the upgrade-control exchange timeout.
func WithUpgradeControlTimeout(timeout time.Duration) UpgradeOption {
	return func(cfg *upgradeConfig) {
		cfg.controlTimeout = timeout
		cfg.controlTimeoutSet = true
	}
}

// WithProbeConcurrency sets the direct-probe candidate-pair concurrency limit.
func WithProbeConcurrency(limit int) UpgradeOption {
	return func(cfg *upgradeConfig) {
		cfg.probeConcurrency = limit
		cfg.probeConcurrencySet = true
	}
}

// WithCandidatePolicy sets this caller's candidate policy for direct upgrade.
// Local filters apply before advertising candidates; remote filters apply after
// decoding the authenticated peer offer and before probing. For local
// unknown-interface STUN reflexive candidates, interface filters match
// conservatively; see CandidatePolicy.
func WithCandidatePolicy(policy CandidatePolicy) UpgradeOption {
	return func(cfg *upgradeConfig) {
		cfg.candidatePolicy = policy
	}
}

// WithTURNAllocator configures the TURN relay allocator for direct-first TURN
// retry. The allocator must be non-nil and requires the exact eligible
// built-in QUIC transport; any other final transport fails validation with
// ErrTURNTransportUnsupported before control or network I/O. Allocation runs
// only inside authenticated Upgrade after bilateral peer support and this
// role's direct probe failure, and each role invokes the allocator at most
// once per Upgrade. Any non-nil allocation result is closed through its
// RelayPacketConn Close contract when it does not become the selected path.
func WithTURNAllocator(allocator RelayPacketAllocator) UpgradeOption {
	return func(cfg *upgradeConfig) {
		cfg.turnAllocator = allocator
		cfg.turnAllocatorSet = true
	}
}

// WithTURNRetryTimeout sets this role's TURN retry budget, which covers its
// allocation, both retry offers, peer preparation, and the authenticated
// retry probe. The timeout must be positive and defaults to 5 seconds. The
// budget starts at Retry Start send for the dialer and at authenticated Retry
// Start receipt for the listener; role-local values are not negotiated and
// may differ between peers.
func WithTURNRetryTimeout(timeout time.Duration) UpgradeOption {
	return func(cfg *upgradeConfig) {
		cfg.turnRetryTimeout = timeout
		cfg.turnRetryTimeoutSet = true
	}
}

// ValidateUpgradeOptions validates Upgrade options without starting an upgrade.
// It is useful for callers that assemble UpgradeOption slices ahead of a
// Negotiator.Upgrade call and want the same nil transport, packet socket,
// timeout, concurrency, candidate-policy, and STUN-address validation that
// Upgrade applies before exchanging control frames. Validation can only check
// relationships expressed by the supplied options; for example, STUN address
// family checks are exact when a packet conn is supplied, and broad otherwise.
func ValidateUpgradeOptions(opts ...UpgradeOption) error {
	_, err := newUpgradeConfig(opts)
	return err
}

func newUpgradeConfig(opts []UpgradeOption) (upgradeConfig, error) {
	var cfg upgradeConfig
	for _, opt := range opts {
		if opt != nil {
			opt(&cfg)
		}
	}
	if cfg.transportSet && cfg.transport == nil {
		return upgradeConfig{}, ErrNilTransport
	}
	if cfg.packetConnSet && cfg.packetConn == nil {
		return upgradeConfig{}, ErrNilPacketConn
	}
	if cfg.packetConn != nil && packetConnBearsRelayProfile(cfg.packetConn) {
		return upgradeConfig{}, ErrRelayProfileDirectPath
	}
	if cfg.packetConn != nil && cfg.transport == nil {
		return upgradeConfig{}, ErrUpgradePacketConnWithoutTransport
	}
	if cfg.probeTimeoutSet && cfg.probeTimeout <= 0 {
		return upgradeConfig{}, ErrInvalidProbeTimeout
	}
	if !cfg.probeTimeoutSet {
		cfg.probeTimeout = defaultUpgradeProbeTimeout
	}
	if cfg.controlTimeoutSet && cfg.controlTimeout <= 0 {
		return upgradeConfig{}, ErrInvalidControlTimeout
	}
	if !cfg.controlTimeoutSet {
		cfg.controlTimeout = defaultUpgradeControlTimeout
	}
	if cfg.probeConcurrencySet && (cfg.probeConcurrency < 1 || cfg.probeConcurrency > 16) {
		return upgradeConfig{}, ErrInvalidProbeConcurrency
	}
	if !cfg.probeConcurrencySet {
		cfg.probeConcurrency = defaultUpgradeProbeConcurrency
	}
	if err := validateCandidatePolicy(cfg.candidatePolicy); err != nil {
		return upgradeConfig{}, err
	}
	families := candidateAddrFamilies{ipv4: true, ipv6: true}
	if cfg.packetConn != nil {
		addr, err := addrPortFromNetAddr(cfg.packetConn.LocalAddr())
		if err != nil {
			return upgradeConfig{}, err
		}
		if !addr.IsValid() || addr.Port() == 0 {
			return upgradeConfig{}, ErrInvalidPacketConnLocalAddr
		}
		families = packetConnAddrFamilies(cfg.packetConn, addr)
	}
	if cfg.stunServerSet {
		if err := validateSTUNServerAddress(cfg.stunServer, families); err != nil {
			return upgradeConfig{}, err
		}
	}
	if cfg.turnAllocatorSet && cfg.turnAllocator == nil {
		return upgradeConfig{}, ErrNilTURNAllocator
	}
	if cfg.turnRetryTimeoutSet && cfg.turnRetryTimeout <= 0 {
		return upgradeConfig{}, ErrInvalidTURNRetryTimeout
	}
	if !cfg.turnRetryTimeoutSet {
		cfg.turnRetryTimeout = defaultTURNRetryTimeout
	}
	// Final eligibility validation: whenever TURN is configured, the final
	// configured transport must be the exact eligible built-in QUIC value or
	// non-nil pointer. This rejects before any control or network I/O.
	if cfg.turnAllocator != nil && !relayprofile.IsTURNQUIC3Transport(cfg.transport) {
		return upgradeConfig{}, ErrTURNTransportUnsupported
	}
	return cfg, nil
}

func validateCandidatePolicy(policy CandidatePolicy) error {
	interfaceSets := [][]string{
		policy.ExcludeLocalInterfaces,
		policy.DeprioritizeLocalInterfaces,
	}
	for _, interfaces := range interfaceSets {
		for _, name := range interfaces {
			if strings.TrimSpace(name) == "" {
				return ErrInvalidCandidatePolicy
			}
		}
	}

	prefixSets := [][]netip.Prefix{
		policy.ExcludeLocalPrefixes,
		policy.DeprioritizeLocalPrefixes,
		policy.ExcludeRemotePrefixes,
		policy.DeprioritizeRemotePrefixes,
	}
	for _, prefixes := range prefixSets {
		for _, prefix := range prefixes {
			if !prefix.IsValid() {
				return ErrInvalidCandidatePolicy
			}
		}
	}

	kindSets := [][]CandidateKind{
		policy.ExcludeKinds,
		policy.DeprioritizeKinds,
	}
	for _, kinds := range kindSets {
		for _, kind := range kinds {
			if !candidateKindIsValid(kind) {
				return ErrInvalidCandidatePolicy
			}
		}
	}
	return nil
}

func candidateKindIsValid(kind CandidateKind) bool {
	return classifyCandidateKind(kind).recognized
}
