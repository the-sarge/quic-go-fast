package connect

import (
	"net/netip"
	"testing"
)

// benchmarkProbeWireFixture is one deterministic v1 candidate pair plus key
// and probe ID for the per-packet probe wire benchmarks.
func benchmarkProbeWireFixture() (probeWireParams, []byte, [probeIDBytes]byte, Candidate, Candidate) {
	params := v1ProbeWireParams()
	key := make([]byte, probeKeyBytes)
	for i := range key {
		key[i] = byte(i)
	}
	probeID := [probeIDBytes]byte{0x7f, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07}
	source := Candidate{
		Kind: CandidateKindHost,
		Addr: netip.MustParseAddrPort("192.0.2.10:40000"),
	}
	destination := Candidate{
		Kind: CandidateKindReflexive,
		Addr: netip.MustParseAddrPort("198.51.100.40:54321"),
	}
	return params, key, probeID, source, destination
}

func BenchmarkProbeEncodeDatagramRequest(b *testing.B) {
	params, key, probeID, source, destination := benchmarkProbeWireFixture()

	b.ReportAllocs()
	b.ResetTimer()
	for range b.N {
		datagram, err := params.encodeDatagram(key, probeMessageRequest, probeDirectionDialerToListener, probeID, source, destination)
		if err != nil {
			b.Fatalf("encodeDatagram: %v", err)
		}
		if len(datagram) != probeDatagramBytes {
			b.Fatalf("datagram length = %d, want %d", len(datagram), probeDatagramBytes)
		}
	}
}

func BenchmarkProbeDecodeDatagramValid(b *testing.B) {
	params, key, probeID, source, destination := benchmarkProbeWireFixture()
	datagram, err := params.encodeDatagram(key, probeMessageRequest, probeDirectionDialerToListener, probeID, source, destination)
	if err != nil {
		b.Fatalf("encodeDatagram: %v", err)
	}

	b.ReportAllocs()
	b.ResetTimer()
	for range b.N {
		decoded, ok := params.decodeDatagram(datagram)
		if !ok {
			b.Fatal("decodeDatagram rejected a valid datagram")
		}
		if decoded.MessageType != probeMessageRequest {
			b.Fatalf("decoded message type = %d, want request", decoded.MessageType)
		}
	}
}

func BenchmarkProbeAuthenticateDatagramRequest(b *testing.B) {
	params, key, probeID, source, destination := benchmarkProbeWireFixture()

	b.ReportAllocs()
	b.ResetTimer()
	for range b.N {
		_, tag, err := params.authenticateDatagram(key, probeMessageRequest, probeDirectionDialerToListener, probeID, source, destination)
		if err != nil {
			b.Fatalf("authenticateDatagram: %v", err)
		}
		if len(tag) == 0 {
			b.Fatal("authenticateDatagram returned an empty tag")
		}
	}
}
