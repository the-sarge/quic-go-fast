package connect

import (
	"bytes"
	"net/netip"
	"testing"
)

func TestEncodeOfferNilHandshakeMaterialRoundTrips(t *testing.T) {
	offer := localUpgradeOffer{
		transportName:     "fake-stream",
		handshakeMaterial: nil,
		probeNonce:        bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		candidates: []Candidate{{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
		}},
	}

	frame, err := encodeUpgradeControlOffer(offer)
	if err != nil {
		t.Fatalf("encodeUpgradeControlOffer: %v", err)
	}

	got, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("readUpgradeControlFirstPhase: %v", err)
	}
	if !got.HasOffer {
		t.Fatalf("first phase = %#v, want offer", got)
	}
	if len(got.Offer.handshakeMaterial) != 0 {
		t.Fatalf("handshake material = %x, want empty", got.Offer.handshakeMaterial)
	}
}

func TestEncodeOfferEmptyHandshakeMaterialRoundTrips(t *testing.T) {
	offer := localUpgradeOffer{
		transportName:     "fake-stream",
		handshakeMaterial: []byte{},
		probeNonce:        bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		candidates: []Candidate{{
			Kind: CandidateKindHost,
			Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
		}},
	}

	frame, err := encodeUpgradeControlOffer(offer)
	if err != nil {
		t.Fatalf("encodeUpgradeControlOffer: %v", err)
	}

	got, err := readUpgradeControlFirstPhase(bytes.NewReader(frame))
	if err != nil {
		t.Fatalf("readUpgradeControlFirstPhase: %v", err)
	}
	if !got.HasOffer {
		t.Fatalf("first phase = %#v, want offer", got)
	}
	if len(got.Offer.handshakeMaterial) != 0 {
		t.Fatalf("handshake material = %x, want empty", got.Offer.handshakeMaterial)
	}
}
