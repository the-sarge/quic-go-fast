package connect

import (
	"bytes"
	"context"
	"errors"
	"net"
	"net/netip"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/goroutineleaktest"
)

// scriptedTurnRetryListener drives the peer side of the retry-entry
// transition by hand over the raw relay end: it completes the v1 offer
// exchange, waits for Retry Start, and then writes one scripted frame.
func scriptTurnRetryEntryPeer(t *testing.T, peer *turnRetryTestPeer, entryFrame []byte) <-chan error {
	t.Helper()
	done := make(chan error, 1)
	go func() {
		done <- func() error {
			offer := localUpgradeOffer{
				transportName:     "fake-stream",
				handshakeMaterial: []byte{0x05},
				probeNonce:        bytes.Repeat([]byte{0x21}, upgradeControlProbeNonceBytes),
				candidates: []Candidate{{
					Kind: CandidateKindHost,
					Addr: netip.MustParseAddrPort("192.0.2.99:40000"),
				}},
				turnRetry: true,
			}
			offerFrame, err := encodeUpgradeControlOffer(offer)
			if err != nil {
				return err
			}
			writeErr := make(chan error, 1)
			go func() { writeErr <- writeFull(peer.relay, offerFrame) }()
			if _, err := readUpgradeControlFrame(peer.relay); err != nil {
				return err
			}
			if err := <-writeErr; err != nil {
				return err
			}
			// The dialer probes its unreachable candidates, then sends Start.
			startPayload, err := readUpgradeControlFrame(peer.relay)
			if err != nil {
				return err
			}
			if !decodeTurnRetryStart(startPayload) {
				return errors.New("scripted peer expected exact Retry Start")
			}
			return writeFull(peer.relay, entryFrame)
		}()
	}()
	return done
}

func TestTurnRetryInvalidDialectEntryTerminatesWithoutGuessedFallback(t *testing.T) {
	oversizePayload := bytes.Repeat([]byte{0xA5}, turnRetryMaxPayload+1)
	oversizeFrame := make([]byte, 4+len(oversizePayload))
	putUint32Length(oversizeFrame[:4], len(oversizePayload))
	copy(oversizeFrame[4:], oversizePayload)

	boundaryPayload := bytes.Repeat([]byte{0xA5}, turnRetryMaxPayload)
	boundaryFrame := make([]byte, 4+len(boundaryPayload))
	putUint32Length(boundaryFrame[:4], len(boundaryPayload))
	copy(boundaryFrame[4:], boundaryPayload)

	garbageFrame := mustEncodeUpgradeControlFrame(t, map[uint64]any{
		upgradeControlKeyType:    uint64(99),
		upgradeControlKeyVersion: upgradeControlVersion,
	})

	cases := []struct {
		name  string
		frame []byte
	}{
		{name: "declared 8193-byte frame rejects before semantic dispatch", frame: oversizeFrame},
		{name: "8192-byte frame passes framing and rejects semantically", frame: boundaryFrame},
		{name: "invalid semantic frame selects no dialect", frame: garbageFrame},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dialer, listener := newTurnRetryFailingDirectPeers(t)
			composite := newFakeRelayComposite(t)
			dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return composite, nil }

			scriptDone := scriptTurnRetryEntryPeer(t, listener, tc.frame)
			dialTransport, _ := newDirectHandoffTransports("fake-stream")
			dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})

			dialerOutcome := <-dialerDone
			if err := <-scriptDone; err != nil {
				t.Fatalf("scripted peer: %v", err)
			}
			if !errors.Is(dialerOutcome.err, errInvalidTurnRetryDialectEntry) {
				t.Fatalf("dialer error = %v, want %v", dialerOutcome.err, errInvalidTurnRetryDialectEntry)
			}
			if dialerOutcome.result.Stream != nil || dialerOutcome.result.Path != UpgradePath("") {
				t.Fatalf("dialer result = %+v, want zero result without fallback success", dialerOutcome.result)
			}
			// No guessed v1 or retry Fallback left the dialer after Start.
			if reasons := dialer.relay.turnRetryFallbackReasons(); len(reasons) != 0 {
				t.Fatalf("dialer sent retry fallback frames %v after invalid entry", reasons)
			}
			for _, payload := range dialer.relay.recordedPayloads() {
				if _, ok := decodeCanonicalV1TerminalFallback(payload); ok {
					t.Fatal("dialer sent a guessed v1 Fallback after invalid entry")
				}
			}
			// The owned allocation was closed before terminal return.
			if composite.closeCount() == 0 {
				t.Fatal("owned allocation not closed on invalid dialect entry")
			}
			if calls := dialer.allocator.callCount(); calls != 1 {
				t.Fatalf("dialer allocator calls = %d, want 1", calls)
			}
		})
	}
}

func TestTurnRetrySimultaneousRetryTimeoutsConvergeOnProbeFailed(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	release := make(chan struct{})
	t.Cleanup(func() { close(release) })
	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
		return &prepareBlockingComposite{fakeRelayComposite: dialerComposite, release: release}, nil
	}
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) {
		return &prepareBlockingComposite{fakeRelayComposite: listenerComposite, release: release}, nil
	}
	// Both roles block in preparation until their independent role-local
	// budgets expire, producing bilateral retry-timeout Fallback 6.
	dialer.extraOpts = []UpgradeOption{WithTURNRetryTimeout(400 * time.Millisecond)}
	listener.extraOpts = []UpgradeOption{WithTURNRetryTimeout(400 * time.Millisecond)}

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackProbeFailed)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackProbeFailed)

	for name, peer := range map[string]*turnRetryTestPeer{"dialer": dialer, "listener": listener} {
		reasons := peer.relay.turnRetryFallbackReasons()
		if len(reasons) != 1 || reasons[0] != UpgradeFallbackProbeFailed {
			t.Fatalf("%s retry fallback reasons = %v, want exactly [probe_failed]", name, reasons)
		}
	}
	if dialerComposite.closeCount() == 0 || listenerComposite.closeCount() == 0 {
		t.Fatal("composites not closed after simultaneous retry expiry")
	}
}

func TestTurnRetryTopologyOfLiveOutcomes(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)
	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	if dialerOutcome.err != nil || listenerOutcome.err != nil {
		t.Fatalf("upgrade errors = %v / %v", dialerOutcome.err, listenerOutcome.err)
	}
	defer func() {
		_ = dialerOutcome.result.Stream.Close()
		_ = listenerOutcome.result.Stream.Close()
	}()
	for name, outcome := range map[string]turnRetryTestOutcome{"dialer": dialerOutcome, "listener": listenerOutcome} {
		topology, err := outcome.result.CarrierTopology()
		if err != nil {
			t.Fatalf("%s CarrierTopology error = %v", name, err)
		}
		if topology != CarrierTopologyRelayAssisted {
			t.Fatalf("%s topology = %q, want %q for QUIC-over-TURN", name, topology, CarrierTopologyRelayAssisted)
		}
	}
}

// TestTurnRetryGoroutineCensusAfterCompletion snapshots every goroutine after
// a complete retry upgrade finished and its streams closed: no retry-engine,
// allocation, or probe-runtime work may remain.
func TestTurnRetryGoroutineCensusAfterCompletion(t *testing.T) {
	if goroutineleaktest.RunIsolated(t) {
		return
	}
	dialer, listener := newTurnRetryFailingDirectPeers(t)
	dialerComposite := newFakeRelayComposite(t)
	listenerComposite := newFakeRelayComposite(t)
	dialer.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return dialerComposite, nil }
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return listenerComposite, nil }

	dialTransport, listenTransport := newDirectHandoffTransports("fake-stream")
	dialerDone := runTurnRetryHandoffPeer(t, dialer, eligibleHandoffTransport{inner: dialTransport})
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	if dialerOutcome.err != nil || listenerOutcome.err != nil {
		t.Fatalf("upgrade errors = %v / %v", dialerOutcome.err, listenerOutcome.err)
	}
	_ = dialerOutcome.result.Stream.Close()
	_ = listenerOutcome.result.Stream.Close()

	deadline := time.Now().Add(2 * time.Second)
	for {
		leaked := turnRetryWorkStacks()
		if len(leaked) == 0 {
			return
		}
		if time.Now().After(deadline) {
			t.Fatalf("retry-engine work still running after completion:\n%s", strings.Join(leaked, "\n\n"))
		}
		time.Sleep(20 * time.Millisecond)
	}
}

func turnRetryWorkStacks() []string {
	buf := make([]byte, 1<<22)
	n := runtime.Stack(buf, true)
	stacks := strings.Split(string(buf[:n]), "\n\n")
	var leaked []string
	for _, stack := range stacks[1:] {
		if strings.Contains(stack, "turnRetry") ||
			strings.Contains(stack, "probePairsWithRetryDelay") ||
			strings.Contains(stack, "proberuntime") {
			leaked = append(leaked, stack)
		}
	}
	return leaked
}

// writeBlockedRelayComposite is an official-marked composite whose WriteTo
// blocks until Close: retry-probe work stuck in the composite's synchronous
// prepared write that no deadline or context can wake.
type writeBlockedRelayComposite struct {
	*fakeRelayComposite
	closeOnceGuard sync.Once
	startOnceGuard sync.Once
	released       chan struct{}
	// writeStarted closes once the first write is parked.
	writeStarted chan struct{}
}

func newWriteBlockedRelayComposite(t *testing.T) *writeBlockedRelayComposite {
	return &writeBlockedRelayComposite{
		fakeRelayComposite: newFakeRelayComposite(t),
		released:           make(chan struct{}),
		writeStarted:       make(chan struct{}),
	}
}

func (c *writeBlockedRelayComposite) WriteTo(p []byte, addr net.Addr) (int, error) {
	c.startOnceGuard.Do(func() { close(c.writeStarted) })
	<-c.released
	return 0, net.ErrClosed
}

func (c *writeBlockedRelayComposite) Close() error {
	c.closeOnceGuard.Do(func() { close(c.released) })
	return c.fakeRelayComposite.Close()
}

// TestTurnRetryValidSelectedJoinsProbeBlockedInCompositeWrite is the #1271
// liveness regression at the listener's valid-Selected path: the retry probe
// is blocked in the composite's synchronous write, and the selected composite
// cannot be disposed to wake it because it is the materialization carrier.
// The listener must still complete the probe join and reach a terminal
// outcome within a bound, with composite disposal happening only at terminal
// settlement, after which the parked writer exits without leaking.
func TestTurnRetryValidSelectedJoinsProbeBlockedInCompositeWrite(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	composite := newWriteBlockedRelayComposite(t)
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return composite, nil }

	dialerCandidate := Candidate{Kind: CandidateKindRelay, Addr: netip.MustParseAddrPort("203.0.113.5:4000")}
	readyObserved := make(chan struct{})
	scriptDone := make(chan error, 1)
	go func() {
		scriptDone <- func() error {
			offer := localUpgradeOffer{
				transportName:     "fake-stream",
				handshakeMaterial: []byte{0x06},
				probeNonce:        bytes.Repeat([]byte{0x33}, upgradeControlProbeNonceBytes),
				candidates: []Candidate{{
					Kind: CandidateKindHost,
					Addr: netip.MustParseAddrPort("192.0.2.98:41000"),
				}},
				turnRetry: true,
			}
			offerFrame, err := encodeUpgradeControlOffer(offer)
			if err != nil {
				return err
			}
			writeErr := make(chan error, 1)
			go func() { writeErr <- writeFull(dialer.relay, offerFrame) }()
			if _, err := readUpgradeControlFrame(dialer.relay); err != nil {
				return err
			}
			if err := <-writeErr; err != nil {
				return err
			}
			startFrame, err := encodeTurnRetryStart()
			if err != nil {
				return err
			}
			if err := writeFull(dialer.relay, startFrame); err != nil {
				return err
			}
			listenerOfferPayload, err := readUpgradeControlFrame(dialer.relay)
			if err != nil {
				return err
			}
			if _, ok := decodeTurnRetryOffer(listenerOfferPayload); !ok {
				return errors.New("script expected listener retry Offer")
			}
			scriptedOffer, err := encodeTurnRetryOffer(turnRetryOffer{
				candidate:     dialerCandidate,
				packetProfile: turnRetryPacketProfileQUIC3,
				probeNonce:    bytes.Repeat([]byte{0x44}, upgradeControlProbeNonceBytes),
			})
			if err != nil {
				return err
			}
			if err := writeFull(dialer.relay, scriptedOffer); err != nil {
				return err
			}
			// Wait until the listener's probe is parked in its blocked
			// composite write, then send a valid Selected naming the exact
			// offered pair.
			select {
			case <-composite.writeStarted:
			case <-time.After(5 * time.Second):
				return errors.New("script timed out waiting for the listener probe write to block")
			}
			selected, err := encodeTurnRetrySelected(turnRetrySelected{
				dialer:   dialerCandidate,
				listener: Candidate{Kind: CandidateKindRelay, Addr: composite.relayedAddr()},
				rtt:      5 * time.Millisecond,
			})
			if err != nil {
				return err
			}
			if err := writeFull(dialer.relay, selected); err != nil {
				return err
			}
			// Ready proves the listener passed Selected validation, joined the
			// probe, and started materializing over the still-open composite.
			readyPayload, err := readUpgradeControlFrame(dialer.relay)
			if err != nil {
				return err
			}
			if !decodeTurnRetryReady(readyPayload) {
				return errors.New("script expected listener retry Ready after valid Selected")
			}
			close(readyObserved)
			// Terminate deterministically: closing the dialer end fails the
			// listener closed at its Commit wait.
			return dialer.relay.Close()
		}()
	}()

	listenTransport, _ := newDirectHandoffTransports("fake-stream")
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	select {
	case outcome := <-listenerDone:
		if outcome.err == nil {
			t.Fatalf("listener outcome = %+v, want fail-closed error after the dialer end closed", outcome.result)
		}
		select {
		case <-readyObserved:
		default:
			t.Fatalf("listener terminated with %v before sending Ready: the valid Selected path did not complete the probe join", outcome.err)
		}
	case <-time.After(8 * time.Second):
		_ = composite.Close()
		t.Fatal("listener hung on valid Selected: probe join waited on a write blocked in composite I/O")
	}
	if err := <-scriptDone; err != nil {
		t.Fatalf("scripted dialer: %v", err)
	}
	if composite.closeCount() == 0 {
		t.Fatal("composite not disposed at terminal settlement")
	}

	// The parked writer's lifetime is bounded by the composite disposal above:
	// no probe-runtime or retry-engine work may remain.
	deadline := time.Now().Add(2 * time.Second)
	for {
		leaked := turnRetryWorkStacks()
		if len(leaked) == 0 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("retry work still running after terminal settlement:\n%s", strings.Join(leaked, "\n\n"))
		}
		time.Sleep(20 * time.Millisecond)
	}
}

// TestTurnRetryImpossibleSelectedDisposesBeforeProbeJoin is the C-001
// disposal-ordering regression at the listener's Selected validation: an
// impossible Selected while the retry probe is blocked in composite write
// I/O must invoke composite disposal before awaiting the probe join and
// converge on retry code 5.
func TestTurnRetryImpossibleSelectedDisposesBeforeProbeJoin(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	composite := newWriteBlockedRelayComposite(t)
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return composite, nil }

	scriptDone := make(chan error, 1)
	go func() {
		scriptDone <- func() error {
			offer := localUpgradeOffer{
				transportName:     "fake-stream",
				handshakeMaterial: []byte{0x06},
				probeNonce:        bytes.Repeat([]byte{0x33}, upgradeControlProbeNonceBytes),
				candidates: []Candidate{{
					Kind: CandidateKindHost,
					Addr: netip.MustParseAddrPort("192.0.2.98:41000"),
				}},
				turnRetry: true,
			}
			offerFrame, err := encodeUpgradeControlOffer(offer)
			if err != nil {
				return err
			}
			writeErr := make(chan error, 1)
			go func() { writeErr <- writeFull(dialer.relay, offerFrame) }()
			if _, err := readUpgradeControlFrame(dialer.relay); err != nil {
				return err
			}
			if err := <-writeErr; err != nil {
				return err
			}
			startFrame, err := encodeTurnRetryStart()
			if err != nil {
				return err
			}
			if err := writeFull(dialer.relay, startFrame); err != nil {
				return err
			}
			listenerOfferPayload, err := readUpgradeControlFrame(dialer.relay)
			if err != nil {
				return err
			}
			if _, ok := decodeTurnRetryOffer(listenerOfferPayload); !ok {
				return errors.New("script expected listener retry Offer")
			}
			scriptedOffer, err := encodeTurnRetryOffer(turnRetryOffer{
				candidate:     Candidate{Kind: CandidateKindRelay, Addr: netip.MustParseAddrPort("203.0.113.5:4000")},
				packetProfile: turnRetryPacketProfileQUIC3,
				probeNonce:    bytes.Repeat([]byte{0x44}, upgradeControlProbeNonceBytes),
			})
			if err != nil {
				return err
			}
			if err := writeFull(dialer.relay, scriptedOffer); err != nil {
				return err
			}
			// Give the listener's probe time to reach its blocked composite
			// write, then send an impossible Selected: the dialer candidate is
			// not the offered one.
			time.Sleep(200 * time.Millisecond)
			mismatched, err := encodeTurnRetrySelected(turnRetrySelected{
				dialer:   Candidate{Kind: CandidateKindRelay, Addr: netip.MustParseAddrPort("198.51.100.77:5000")},
				listener: Candidate{Kind: CandidateKindRelay, Addr: composite.relayedAddr()},
			})
			if err != nil {
				return err
			}
			if err := writeFull(dialer.relay, mismatched); err != nil {
				return err
			}
			// The listener must converge through retry code 5.
			fallbackPayload, err := readUpgradeControlFrame(dialer.relay)
			if err != nil {
				return err
			}
			fallback, ok := decodeTurnRetryFallback(fallbackPayload)
			if !ok || fallback.Reason != UpgradeFallbackProtocolMismatch {
				return errors.New("script expected listener retry Fallback protocol_mismatch")
			}
			echo, err := encodeTurnRetryFallback(UpgradeFallbackProtocolMismatch)
			if err != nil {
				return err
			}
			return writeFull(dialer.relay, echo)
		}()
	}()

	listenTransport, _ := newDirectHandoffTransports("fake-stream")
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	select {
	case outcome := <-listenerDone:
		assertRelayFallbackResult(t, "listener", upgradeTestOutcome(outcome), listener.relay, UpgradeFallbackProtocolMismatch)
	case <-time.After(8 * time.Second):
		t.Fatal("listener deadlocked: probe join awaited before composite disposal on impossible Selected")
	}
	if err := <-scriptDone; err != nil {
		t.Fatalf("scripted dialer: %v", err)
	}
	if composite.closeCount() == 0 {
		t.Fatal("composite not closed on impossible Selected")
	}
}

// TestTurnRetryValidSelectedWithRealProbeErrorFailsClosedProbeFailed is the
// #1272 regression for the listener's fail-closed arm at valid-Selected
// receipt: the joined retry probe carries a real error that is neither
// context.Canceled nor the cross-profile sentinel. The injected probe runner
// blocks until its context is canceled and only then reports the error, so
// the valid Selected frame deterministically wins the selection race and the
// join at Selected deterministically observes the real error. The listener
// must resolve the probe-failed local disposition, run the synchronized
// terminal fallback exchange, dispose the composite, and leave no probe work
// behind.
func TestTurnRetryValidSelectedWithRealProbeErrorFailsClosedProbeFailed(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)

	composite := newFakeRelayComposite(t)
	listener.allocator.allocate = func(context.Context) (RelayPacketConn, error) { return composite, nil }

	injectedErr := errors.New("injected real retry probe failure")
	runnerStarted := make(chan struct{})
	runnerCanceled := make(chan struct{})
	var (
		runnerRole   upgradeRole
		runnerCtxErr error
	)
	listener.probeRunner = func(ctx context.Context, role upgradeRole) (candidatePairProbeResult, error) {
		runnerRole = role
		close(runnerStarted)
		// Cooperate with cancellation, then report a real failure: the error
		// must not wrap context.Canceled, or localProbeDisposition would treat
		// it as a cancellation artifact rather than a real probe failure.
		<-ctx.Done()
		// The cause discriminates which arm ended the probe: the Selected join
		// cancels (context.Canceled), while retry-budget expiry would surface
		// as context.DeadlineExceeded through the same probe_failed exchange.
		runnerCtxErr = ctx.Err()
		close(runnerCanceled)
		return candidatePairProbeResult{}, injectedErr
	}

	dialerCandidate := Candidate{Kind: CandidateKindRelay, Addr: netip.MustParseAddrPort("203.0.113.5:4000")}
	scriptDone := make(chan error, 1)
	go func() {
		scriptDone <- func() error {
			offer := localUpgradeOffer{
				transportName:     "fake-stream",
				handshakeMaterial: []byte{0x06},
				probeNonce:        bytes.Repeat([]byte{0x33}, upgradeControlProbeNonceBytes),
				candidates: []Candidate{{
					Kind: CandidateKindHost,
					Addr: netip.MustParseAddrPort("192.0.2.98:41000"),
				}},
				turnRetry: true,
			}
			offerFrame, err := encodeUpgradeControlOffer(offer)
			if err != nil {
				return err
			}
			writeErr := make(chan error, 1)
			go func() { writeErr <- writeFull(dialer.relay, offerFrame) }()
			if _, err := readUpgradeControlFrame(dialer.relay); err != nil {
				return err
			}
			if err := <-writeErr; err != nil {
				return err
			}
			startFrame, err := encodeTurnRetryStart()
			if err != nil {
				return err
			}
			if err := writeFull(dialer.relay, startFrame); err != nil {
				return err
			}
			listenerOfferPayload, err := readUpgradeControlFrame(dialer.relay)
			if err != nil {
				return err
			}
			if _, ok := decodeTurnRetryOffer(listenerOfferPayload); !ok {
				return errors.New("script expected listener retry Offer")
			}
			scriptedOffer, err := encodeTurnRetryOffer(turnRetryOffer{
				candidate:     dialerCandidate,
				packetProfile: turnRetryPacketProfileQUIC3,
				probeNonce:    bytes.Repeat([]byte{0x44}, upgradeControlProbeNonceBytes),
			})
			if err != nil {
				return err
			}
			if err := writeFull(dialer.relay, scriptedOffer); err != nil {
				return err
			}
			// Wait until the injected probe runner is parked on its context,
			// then send a valid Selected naming the exact offered pair. The
			// runner cannot complete before that cancellation, so Selected
			// wins the listener's selection race by construction.
			select {
			case <-runnerStarted:
			case <-time.After(5 * time.Second):
				return errors.New("script timed out waiting for the injected probe runner to start")
			}
			selected, err := encodeTurnRetrySelected(turnRetrySelected{
				dialer:   dialerCandidate,
				listener: Candidate{Kind: CandidateKindRelay, Addr: composite.relayedAddr()},
				rtt:      5 * time.Millisecond,
			})
			if err != nil {
				return err
			}
			if err := writeFull(dialer.relay, selected); err != nil {
				return err
			}
			// The listener must fail closed through retry Fallback probe_failed,
			// never Ready: the real probe error overrides the Selected evidence.
			payload, err := readUpgradeControlFrame(dialer.relay)
			if err != nil {
				return err
			}
			if decodeTurnRetryReady(payload) {
				return errors.New("listener sent Ready after a real probe error at valid Selected")
			}
			fallback, ok := decodeTurnRetryFallback(payload)
			if !ok || fallback.Reason != UpgradeFallbackProbeFailed {
				return errors.New("script expected listener retry Fallback probe_failed")
			}
			echo, err := encodeTurnRetryFallback(UpgradeFallbackProbeFailed)
			if err != nil {
				return err
			}
			return writeFull(dialer.relay, echo)
		}()
	}()

	listenTransport, _ := newDirectHandoffTransports("fake-stream")
	listenerDone := runTurnRetryHandoffPeer(t, listener, eligibleHandoffTransport{inner: listenTransport})

	select {
	case outcome := <-listenerDone:
		assertRelayFallbackResult(t, "listener", upgradeTestOutcome(outcome), listener.relay, UpgradeFallbackProbeFailed)
	case <-time.After(8 * time.Second):
		_ = composite.Close()
		t.Fatal("listener hung: real probe error at valid Selected did not reach terminal settlement")
	}
	if err := <-scriptDone; err != nil {
		t.Fatalf("scripted dialer: %v", err)
	}
	select {
	case <-runnerCanceled:
	default:
		t.Fatal("injected probe runner was never canceled: the Selected join did not cancel the probe")
	}
	if !errors.Is(runnerCtxErr, context.Canceled) || errors.Is(runnerCtxErr, context.DeadlineExceeded) {
		t.Fatalf("injected probe runner context error = %v, want context.Canceled from the valid-Selected join, not retry-budget expiry", runnerCtxErr)
	}
	if runnerRole != upgradeRoleListen {
		t.Fatalf("injected probe runner role = %v, want %v", runnerRole, upgradeRoleListen)
	}
	if reasons := listener.relay.turnRetryFallbackReasons(); len(reasons) != 1 || reasons[0] != UpgradeFallbackProbeFailed {
		t.Fatalf("listener retry fallback reasons = %v, want exactly [probe_failed]", reasons)
	}
	if composite.closeCount() == 0 {
		t.Fatal("composite not disposed at terminal settlement")
	}

	deadline := time.Now().Add(2 * time.Second)
	for {
		leaked := turnRetryWorkStacks()
		if len(leaked) == 0 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("retry work still running after terminal settlement:\n%s", strings.Join(leaked, "\n\n"))
		}
		time.Sleep(20 * time.Millisecond)
	}
}
