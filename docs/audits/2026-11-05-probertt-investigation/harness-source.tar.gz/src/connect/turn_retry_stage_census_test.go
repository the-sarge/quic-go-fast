package connect

import (
	"go/ast"
	"go/parser"
	"go/token"
	"testing"
)

// TestTurnRetryMismatchExitsUseUnconditionalStageLabel pins Decision 2 of
// issue #1270 at its enforcement owner by source census: both production
// errDatagramExposureAgreementMismatch fail-closed exits in the retry engine
// wrap the sentinel with the unconditional stageError helper, never with
// stagePostCommitCause, whose expired-budget branch would discard the more
// specific mismatch cause. A harness case cannot force that coincidence, so
// the wrapper choice is asserted directly.
func TestTurnRetryMismatchExitsUseUnconditionalStageLabel(t *testing.T) {
	t.Parallel()

	parsed, err := parser.ParseFile(token.NewFileSet(), "turn_retry_engine.go", nil, 0)
	if err != nil {
		t.Fatalf("parse turn_retry_engine.go: %v", err)
	}

	const sentinel = "errDatagramExposureAgreementMismatch"
	mentions := func(node ast.Node) bool {
		found := false
		ast.Inspect(node, func(n ast.Node) bool {
			if ident, ok := n.(*ast.Ident); ok && ident.Name == sentinel {
				found = true
			}
			return !found
		})
		return found
	}

	var exits []string
	ast.Inspect(parsed, func(n ast.Node) bool {
		call, ok := n.(*ast.CallExpr)
		if !ok {
			return true
		}
		if terminalCensusCalledName(call.Fun) != "failClosed" || len(call.Args) == 0 || !mentions(call.Args[0]) {
			return true
		}
		shape := "other"
		if wrapper, ok := call.Args[0].(*ast.CallExpr); ok && len(wrapper.Args) == 1 {
			if arg, ok := wrapper.Args[0].(*ast.Ident); ok && arg.Name == sentinel {
				shape = terminalCensusCalledName(wrapper.Fun)
			}
		}
		exits = append(exits, shape)
		return true
	})

	if len(exits) != 2 {
		t.Fatalf("mismatch fail-closed exits = %v, want exactly 2 in the retry engine", exits)
	}
	for i, shape := range exits {
		if shape != "stageError" {
			t.Fatalf("mismatch exit %d wraps the sentinel with %q, want unconditional stageError (Decision 2, issue #1270)", i, shape)
		}
	}
}
