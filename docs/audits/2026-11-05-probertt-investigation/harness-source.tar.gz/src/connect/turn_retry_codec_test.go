package connect

import (
	"bytes"
	"net/netip"
	"testing"
	"time"
)

func TestTurnRetryPreservesV1OfferAndProbeGoldens(t *testing.T) {
	offer := localUpgradeOffer{
		transportName:     "quic",
		handshakeMaterial: []byte{0x01, 0x02},
		probeNonce:        bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
		candidates: []Candidate{
			{
				Kind: CandidateKindHost,
				Addr: netip.MustParseAddrPort("192.0.2.10:12345"),
			},
		},
	}
	gotOffer, err := encodeUpgradeControlOffer(offer)
	if err != nil {
		t.Fatalf("encodeUpgradeControlOffer: %v", err)
	}
	wantOffer := mustHex(t, "00000040a6000101010a64717569630b4201020c582042424242424242424242424242424242424242424242424242424242424242420d81a20001014704c000020a3039")
	if !bytes.Equal(gotOffer, wantOffer) {
		t.Fatalf("v1 offer frame drifted: got %x want %x", gotOffer, wantOffer)
	}

	key := mustHex(t, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
	probeID := [probeIDBytes]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}
	gotProbe, err := encodeProbeDatagram(
		key,
		probeMessageRequest,
		probeDirectionDialerToListener,
		probeID,
		Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")},
		Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.40:54321")},
	)
	if err != nil {
		t.Fatalf("encodeProbeDatagram: %v", err)
	}
	wantProbe := mustHex(t,
		"574d58500101010102030405060708"+
			"f543ac095e6378cb98552a8300d754de"+
			"7360039d44a2c03cd865ac0bbc3b5078552bb4bf1ec59cf6285af4ae149f3101",
	)
	if !bytes.Equal(gotProbe, wantProbe) {
		t.Fatalf("v1 probe datagram drifted: got %x want %x", gotProbe, wantProbe)
	}
}

func TestEncodeTurnRetryMessageGoldens(t *testing.T) {
	relay := Candidate{Kind: CandidateKindRelay, Addr: netip.MustParseAddrPort("192.0.2.10:12345")}
	listenerRelay := Candidate{Kind: CandidateKindRelay, Addr: netip.MustParseAddrPort("198.51.100.20:23456")}
	nonce := bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes)

	tests := []struct {
		name string
		got  func() ([]byte, error)
		want string
	}{
		{
			name: "start",
			got:  encodeTurnRetryStart,
			want: "00000005a200010101",
		},
		{
			name: "offer",
			got: func() ([]byte, error) {
				return encodeTurnRetryOffer(turnRetryOffer{
					candidate:     relay,
					packetProfile: turnRetryPacketProfileQUIC3,
					probeNonce:    nonce,
				})
			},
			want: "00000037a5000201010aa20003014704c000020a30390b010c58204242424242424242424242424242424242424242424242424242424242424242",
		},
		{
			name: "fallback probe_failed",
			got: func() ([]byte, error) {
				return encodeTurnRetryFallback(UpgradeFallbackProbeFailed)
			},
			want: "00000007a3000301011406",
		},
		{
			name: "fallback policy_excluded",
			got: func() ([]byte, error) {
				return encodeTurnRetryFallback(UpgradeFallbackPolicyExcluded)
			},
			want: "00000007a3000301011402",
		},
		{
			name: "fallback protocol_mismatch",
			got: func() ([]byte, error) {
				return encodeTurnRetryFallback(UpgradeFallbackProtocolMismatch)
			},
			want: "00000007a3000301011405",
		},
		{
			name: "selected with rtt",
			got: func() ([]byte, error) {
				return encodeTurnRetrySelected(turnRetrySelected{
					dialer:   relay,
					listener: listenerRelay,
					rtt:      123456789 * time.Nanosecond,
				})
			},
			want: "00000028a500040101181ea20003014704c000020a3039181fa20003014704c63364145ba018201a075bcd15",
		},
		{
			name: "selected without rtt",
			got: func() ([]byte, error) {
				return encodeTurnRetrySelected(turnRetrySelected{
					dialer:   relay,
					listener: listenerRelay,
				})
			},
			want: "00000021a400040101181ea20003014704c000020a3039181fa20003014704c63364145ba0",
		},
		{
			name: "ready",
			got:  encodeTurnRetryReady,
			want: "00000005a200050101",
		},
		{
			name: "commit",
			got:  encodeTurnRetryCommit,
			want: "00000005a200060101",
		},
		{
			name: "accepted",
			got: func() ([]byte, error) {
				return encodeTurnRetryAccepted(false)
			},
			want: "00000005a200070101",
		},
		{
			name: "accepted datagram",
			got: func() ([]byte, error) {
				return encodeTurnRetryAccepted(true)
			},
			want: "0000001ba30007010102a172776972656d75782e646174616772616d2f31f5",
		},
		{
			name: "converged",
			got: func() ([]byte, error) {
				return encodeTurnRetryConverged(false)
			},
			want: "00000005a200080101",
		},
		{
			name: "confirmed",
			got: func() ([]byte, error) {
				return encodeTurnRetryConfirmed(false)
			},
			want: "00000005a200090101",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.got()
			if err != nil {
				t.Fatalf("encode: %v", err)
			}
			want := mustHex(t, tt.want)
			if !bytes.Equal(got, want) {
				t.Fatalf("frame = %x, want %x", got, want)
			}
		})
	}
}

func TestDecodeTurnRetryMessageRoundTrips(t *testing.T) {
	relay := Candidate{Kind: CandidateKindRelay, Addr: netip.MustParseAddrPort("192.0.2.10:12345")}
	listenerRelay := Candidate{Kind: CandidateKindRelay, Addr: netip.MustParseAddrPort("198.51.100.20:23456")}
	nonce := bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes)

	startFrame, err := encodeTurnRetryStart()
	if err != nil {
		t.Fatalf("encode start: %v", err)
	}
	if !decodeTurnRetryStart(startFrame[4:]) {
		t.Fatal("decodeTurnRetryStart rejected canonical start")
	}

	readyFrame, err := encodeTurnRetryReady()
	if err != nil {
		t.Fatalf("encode ready: %v", err)
	}
	if !decodeTurnRetryReady(readyFrame[4:]) {
		t.Fatal("decodeTurnRetryReady rejected canonical ready")
	}
	if decodeTurnRetryReady(startFrame[4:]) {
		t.Fatal("decodeTurnRetryReady accepted start payload")
	}

	commitFrame, err := encodeTurnRetryCommit()
	if err != nil {
		t.Fatalf("encode commit: %v", err)
	}
	if !decodeTurnRetryCommit(commitFrame[4:]) {
		t.Fatal("decodeTurnRetryCommit rejected canonical commit")
	}
	if decodeTurnRetryCommit(readyFrame[4:]) {
		t.Fatal("decodeTurnRetryCommit accepted ready payload")
	}
	if decodeTurnRetryReady(commitFrame[4:]) {
		t.Fatal("decodeTurnRetryReady accepted commit payload")
	}

	offerFrame, err := encodeTurnRetryOffer(turnRetryOffer{
		candidate:     relay,
		packetProfile: turnRetryPacketProfileQUIC3,
		probeNonce:    nonce,
	})
	if err != nil {
		t.Fatalf("encode offer: %v", err)
	}
	offer, ok := decodeTurnRetryOffer(offerFrame[4:])
	if !ok {
		t.Fatal("decodeTurnRetryOffer rejected canonical offer")
	}
	if offer.candidate != relay || offer.packetProfile != turnRetryPacketProfileQUIC3 || !bytes.Equal(offer.probeNonce, nonce) {
		t.Fatalf("decoded offer = %+v", offer)
	}

	fallbackFrame, err := encodeTurnRetryFallback(UpgradeFallbackProbeFailed)
	if err != nil {
		t.Fatalf("encode fallback: %v", err)
	}
	fallback, ok := decodeTurnRetryFallback(fallbackFrame[4:])
	if !ok || fallback.Reason != UpgradeFallbackProbeFailed {
		t.Fatalf("decoded fallback = %+v ok=%v", fallback, ok)
	}

	selectedFrame, err := encodeTurnRetrySelected(turnRetrySelected{
		dialer:   relay,
		listener: listenerRelay,
		rtt:      123456789 * time.Nanosecond,
	})
	if err != nil {
		t.Fatalf("encode selected: %v", err)
	}
	selected, ok := decodeTurnRetrySelected(selectedFrame[4:])
	if !ok || selected.dialer != relay || selected.listener != listenerRelay || selected.rtt != 123456789*time.Nanosecond {
		t.Fatalf("decoded selected = %+v ok=%v", selected, ok)
	}

	for _, phase := range []struct {
		name   string
		encode func(bool) ([]byte, error)
		decode func([]byte) (bool, bool)
	}{
		{"accepted", encodeTurnRetryAccepted, decodeTurnRetryAccepted},
		{"converged", encodeTurnRetryConverged, decodeTurnRetryConverged},
		{"confirmed", encodeTurnRetryConfirmed, decodeTurnRetryConfirmed},
	} {
		frame, err := phase.encode(true)
		if err != nil {
			t.Fatalf("encode %s: %v", phase.name, err)
		}
		datagrams, ok := phase.decode(frame[4:])
		if !ok || !datagrams {
			t.Fatalf("decode %s = datagrams=%v ok=%v", phase.name, datagrams, ok)
		}
	}
}

func TestDecodeTurnRetryRejectsMalformedFields(t *testing.T) {
	tests := []struct {
		name    string
		payload func(*testing.T) []byte
		check   func(*testing.T, []byte)
	}{
		{
			name: "start wrong version",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:    turnRetryMessageStart,
					turnRetryKeyVersion: uint64(2),
				})
			},
			check: func(t *testing.T, payload []byte) {
				if decodeTurnRetryStart(payload) {
					t.Fatal("accepted start with version 2")
				}
			},
		},
		{
			name: "offer short nonce",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:          turnRetryMessageOffer,
					turnRetryKeyVersion:       turnRetryVersion,
					turnRetryKeyCandidate:     map[uint64]any{0: uint64(3), 1: []byte{0x04, 192, 0, 2, 10, 0x30, 0x39}},
					turnRetryKeyPacketProfile: turnRetryPacketProfileQUIC3,
					turnRetryKeyProbeNonce:    bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes-1),
				})
			},
			check: func(t *testing.T, payload []byte) {
				if _, ok := decodeTurnRetryOffer(payload); ok {
					t.Fatal("accepted offer with 31-byte nonce")
				}
			},
		},
		{
			name: "selected rtt above max",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:              turnRetryMessageSelected,
					turnRetryKeyVersion:           turnRetryVersion,
					turnRetryKeyDialerCandidate:   map[uint64]any{0: uint64(3), 1: []byte{0x04, 192, 0, 2, 10, 0x30, 0x39}},
					turnRetryKeyListenerCandidate: map[uint64]any{0: uint64(3), 1: []byte{0x04, 198, 51, 100, 20, 0x5b, 0xa0}},
					turnRetryKeyProbeRTTNanos:     upgradeControlMaxProbeRTTNanos + 1,
				})
			},
			check: func(t *testing.T, payload []byte) {
				if _, ok := decodeTurnRetrySelected(payload); ok {
					t.Fatal("accepted selected with RTT above max")
				}
			},
		},
		{
			name: "start unknown field",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:           turnRetryMessageStart,
					turnRetryKeyVersion:        turnRetryVersion,
					turnRetryKeyFallbackReason: uint64(6),
				})
			},
			check: func(t *testing.T, payload []byte) {
				if decodeTurnRetryStart(payload) {
					t.Fatal("accepted start with forbidden field")
				}
			},
		},
		{
			name: "offer missing nonce",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:          turnRetryMessageOffer,
					turnRetryKeyVersion:       turnRetryVersion,
					turnRetryKeyCandidate:     map[uint64]any{0: uint64(3), 1: []byte{0x04, 192, 0, 2, 10, 0x30, 0x39}},
					turnRetryKeyPacketProfile: turnRetryPacketProfileQUIC3,
				})
			},
			check: func(t *testing.T, payload []byte) {
				if _, ok := decodeTurnRetryOffer(payload); ok {
					t.Fatal("accepted offer missing nonce")
				}
			},
		},
		{
			name: "offer host candidate",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:          turnRetryMessageOffer,
					turnRetryKeyVersion:       turnRetryVersion,
					turnRetryKeyCandidate:     map[uint64]any{0: uint64(1), 1: []byte{0x04, 192, 0, 2, 10, 0x30, 0x39}},
					turnRetryKeyPacketProfile: turnRetryPacketProfileQUIC3,
					turnRetryKeyProbeNonce:    bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
				})
			},
			check: func(t *testing.T, payload []byte) {
				if _, ok := decodeTurnRetryOffer(payload); ok {
					t.Fatal("accepted offer with host candidate")
				}
			},
		},
		{
			name: "offer wrong profile",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:          turnRetryMessageOffer,
					turnRetryKeyVersion:       turnRetryVersion,
					turnRetryKeyCandidate:     map[uint64]any{0: uint64(3), 1: []byte{0x04, 192, 0, 2, 10, 0x30, 0x39}},
					turnRetryKeyPacketProfile: uint64(2),
					turnRetryKeyProbeNonce:    bytes.Repeat([]byte{0x42}, upgradeControlProbeNonceBytes),
				})
			},
			check: func(t *testing.T, payload []byte) {
				if _, ok := decodeTurnRetryOffer(payload); ok {
					t.Fatal("accepted offer with non-/3 profile")
				}
			},
		},
		{
			name: "fallback unsupported reason",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:           turnRetryMessageFallback,
					turnRetryKeyVersion:        turnRetryVersion,
					turnRetryKeyFallbackReason: uint64(1),
				})
			},
			check: func(t *testing.T, payload []byte) {
				if _, ok := decodeTurnRetryFallback(payload); ok {
					t.Fatal("accepted fallback reason 1")
				}
			},
		},
		{
			name: "selected mixed pair",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:              turnRetryMessageSelected,
					turnRetryKeyVersion:           turnRetryVersion,
					turnRetryKeyDialerCandidate:   map[uint64]any{0: uint64(3), 1: []byte{0x04, 192, 0, 2, 10, 0x30, 0x39}},
					turnRetryKeyListenerCandidate: map[uint64]any{0: uint64(1), 1: []byte{0x04, 198, 51, 100, 20, 0x5b, 0xa0}},
				})
			},
			check: func(t *testing.T, payload []byte) {
				if _, ok := decodeTurnRetrySelected(payload); ok {
					t.Fatal("accepted mixed selected pair")
				}
			},
		},
		{
			name: "selected zero rtt",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:              turnRetryMessageSelected,
					turnRetryKeyVersion:           turnRetryVersion,
					turnRetryKeyDialerCandidate:   map[uint64]any{0: uint64(3), 1: []byte{0x04, 192, 0, 2, 10, 0x30, 0x39}},
					turnRetryKeyListenerCandidate: map[uint64]any{0: uint64(3), 1: []byte{0x04, 198, 51, 100, 20, 0x5b, 0xa0}},
					turnRetryKeyProbeRTTNanos:     uint64(0),
				})
			},
			check: func(t *testing.T, payload []byte) {
				if _, ok := decodeTurnRetrySelected(payload); ok {
					t.Fatal("accepted selected with zero rtt")
				}
			},
		},
		{
			name: "accepted malformed extension",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:       turnRetryMessageAccepted,
					turnRetryKeyVersion:    turnRetryVersion,
					turnRetryKeyExtensions: map[string]bool{"wiremux.datagram/1": false},
				})
			},
			check: func(t *testing.T, payload []byte) {
				if _, ok := decodeTurnRetryAccepted(payload); ok {
					t.Fatal("accepted false datagram extension")
				}
			},
		},
		{
			name: "ready with extensions",
			payload: func(t *testing.T) []byte {
				return mustEncodeTurnRetryTestPayload(t, map[uint64]any{
					turnRetryKeyType:       turnRetryMessageReady,
					turnRetryKeyVersion:    turnRetryVersion,
					turnRetryKeyExtensions: map[string]bool{"wiremux.datagram/1": true},
				})
			},
			check: func(t *testing.T, payload []byte) {
				if !decodeTurnRetryReady(payload) {
					return
				}
				t.Fatal("accepted ready with extensions")
			},
		},
		{
			name: "duplicate map key",
			payload: func(t *testing.T) []byte {
				// a3 00 01 00 01 01 01 — duplicate key 0, not ascending-unique
				return mustHex(t, "a3000100010101")
			},
			check: func(t *testing.T, payload []byte) {
				if decodeTurnRetryStart(payload) {
					t.Fatal("accepted duplicate keys")
				}
			},
		},
		{
			name: "non-canonical uint encoding",
			payload: func(t *testing.T) []byte {
				// map{0:1,1:1} but type value encoded as 24(1) instead of 1
				return mustHex(t, "a20018010101")
			},
			check: func(t *testing.T, payload []byte) {
				if decodeTurnRetryStart(payload) {
					t.Fatal("accepted non-canonical uint value encoding")
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.check(t, tt.payload(t))
		})
	}
}

// TestDecodeTurnRetryRejectsCanonicalV1Frames pins the intentional message-code
// overlap between the retry dialect and v1: retry Offer (2) reuses the v1
// Fallback code, retry Fallback (3) reuses the v1 SelectedPair code, and retry
// Selected (4) reuses the v1 Ready code. The shared type/version prefilter
// therefore admits every canonical v1 payload below, and the test pins only the
// rejection outcome of each retry decoder — not which downstream check (exact
// field-set guard or required-field decoding) produces it.
func TestDecodeTurnRetryRejectsCanonicalV1Frames(t *testing.T) {
	v1Fallback, err := encodeUpgradeControlFallback(UpgradeFallbackProbeFailed)
	if err != nil {
		t.Fatalf("encodeUpgradeControlFallback: %v", err)
	}
	v1SelectedPair, err := encodeUpgradeControlSelectedPair(selectedPair{
		dialer:   Candidate{Kind: CandidateKindHost, Addr: mustAddrPort(t, "192.0.2.10:12345")},
		listener: Candidate{Kind: CandidateKindReflexive, Addr: mustAddrPort(t, "198.51.100.40:54321")},
		rtt:      25 * time.Millisecond,
	})
	if err != nil {
		t.Fatalf("encodeUpgradeControlSelectedPair: %v", err)
	}
	v1Ready, err := encodeUpgradeControlReadyFrame()
	if err != nil {
		t.Fatalf("encodeUpgradeControlReadyFrame: %v", err)
	}
	frames := []struct {
		name  string
		frame []byte
	}{
		{name: "v1 fallback", frame: v1Fallback},
		{name: "v1 selected pair", frame: v1SelectedPair},
		{name: "v1 ready", frame: v1Ready},
	}
	decoders := []struct {
		name   string
		decode func([]byte) bool
	}{
		{name: "retry offer", decode: func(payload []byte) bool {
			_, ok := decodeTurnRetryOffer(payload)
			return ok
		}},
		{name: "retry fallback", decode: func(payload []byte) bool {
			_, ok := decodeTurnRetryFallback(payload)
			return ok
		}},
		{name: "retry selected", decode: func(payload []byte) bool {
			_, ok := decodeTurnRetrySelected(payload)
			return ok
		}},
	}
	for _, frame := range frames {
		payload := frame.frame[4:]
		if _, _, ok := decodeTurnRetryCommonFields(payload); !ok {
			t.Fatalf("%s: canonical v1 payload should pass the shared type/version prefilter", frame.name)
		}
		for _, decoder := range decoders {
			t.Run(frame.name+"/"+decoder.name, func(t *testing.T) {
				if decoder.decode(payload) {
					t.Fatalf("%s decoder accepted canonical %s frame %x", decoder.name, frame.name, frame.frame)
				}
			})
		}
	}
}

func TestEncodeTurnRetryHelpersRejectInvalidMessageFamilies(t *testing.T) {
	if _, err := encodeTurnRetryEmptyMessage(turnRetryMessageOffer); err == nil {
		t.Fatal("encodeTurnRetryEmptyMessage(offer) succeeded, want error")
	}
	if _, err := encodeTurnRetryPostCommitMessage(turnRetryMessageReady, true); err == nil {
		t.Fatal("encodeTurnRetryPostCommitMessage(ready) succeeded, want error")
	}
}

func TestEncodeTurnRetryFallbackRejectsUnsupportedReasons(t *testing.T) {
	for _, reason := range []UpgradeFallbackReason{
		UpgradeFallbackNotRequested,
		UpgradeFallbackNoCandidates,
		UpgradeFallbackTransportMismatch,
		UpgradeFallbackTransportFailed,
		UpgradeFallbackNone,
	} {
		if _, err := encodeTurnRetryFallback(reason); err == nil {
			t.Fatalf("encodeTurnRetryFallback(%q) succeeded, want error", reason)
		}
	}
}

func mustEncodeTurnRetryTestPayload(t *testing.T, fields any) []byte {
	t.Helper()
	payload, err := encMode.Marshal(fields)
	if err != nil {
		t.Fatalf("marshal test payload: %v", err)
	}
	return payload
}

func TestDecodeTurnRetryCommonFieldsOwnsPayloadBound(t *testing.T) {
	exact := mustEncodeTurnRetryTestPayloadOfLength(t, turnRetryMessageStart, turnRetryMaxPayload)
	_, messageType, ok := decodeTurnRetryCommonFields(exact)
	if !ok {
		t.Fatal("8192-byte payload rejected at the decoder bound")
	}
	if messageType != turnRetryMessageStart {
		t.Fatalf("8192-byte payload type = %d, want %d", messageType, turnRetryMessageStart)
	}
	if decodeTurnRetryStart(exact) {
		t.Fatal("8192-byte padded Start accepted; the exact key set must reject it after the bound")
	}

	over := mustEncodeTurnRetryTestPayloadOfLength(t, turnRetryMessageStart, turnRetryMaxPayload+1)
	if _, _, ok := decodeTurnRetryCommonFields(over); ok {
		t.Fatal("8193-byte payload passed the decoder bound")
	}
}

// mustEncodeTurnRetryTestPayloadOfLength builds a well-formed retry payload of
// exactly n bytes: type and version plus padding byte strings that stay under
// the bounded scanner's per-string and pair limits, so only the payload length
// can reject it before semantic decoding.
func mustEncodeTurnRetryTestPayloadOfLength(t *testing.T, messageType uint64, n int) []byte {
	t.Helper()
	const chunk = 3000 // well under upgradeControlMaxStringBytes; two chunks leave the remainder under the cap too
	remainder := 0
	for range 8 {
		fields := map[uint64]any{
			turnRetryKeyType:    messageType,
			turnRetryKeyVersion: turnRetryVersion,
			uint64(100):         bytes.Repeat([]byte{0x5a}, chunk),
			uint64(101):         bytes.Repeat([]byte{0x5a}, chunk),
			uint64(102):         bytes.Repeat([]byte{0x5a}, remainder),
		}
		payload := mustEncodeTurnRetryTestPayload(t, fields)
		if len(payload) == n {
			return payload
		}
		remainder += n - len(payload)
		if remainder < 0 || remainder > chunk {
			break
		}
	}
	t.Fatalf("could not build a %d-byte turn-retry payload", n)
	return nil
}

func TestDecodeTurnRetryStartAndFallbackRejectOversizePayloads(t *testing.T) {
	// The three formerly unguarded sites (upgrade.go and
	// upgrade_terminal_fallback.go call decodeTurnRetryStart; the retry
	// terminal exchange calls decodeTurnRetryFallback) rely on the codec
	// rejecting an oversize payload before any retry semantics.
	start := mustEncodeTurnRetryTestPayloadOfLength(t, turnRetryMessageStart, turnRetryMaxPayload+1)
	if decodeTurnRetryStart(start) {
		t.Fatal("decodeTurnRetryStart accepted an 8193-byte payload")
	}
	fallback := mustEncodeTurnRetryTestPayloadOfLength(t, turnRetryMessageFallback, turnRetryMaxPayload+1)
	if _, ok := decodeTurnRetryFallback(fallback); ok {
		t.Fatal("decodeTurnRetryFallback accepted an 8193-byte payload")
	}
}
