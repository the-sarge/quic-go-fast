package connect

import (
	"context"
	"errors"
	"io"
	"net"
	"sync"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// turnTestTransport wraps the fake stream transport in a TURN-eligible shape:
// value-receiver delegation (not embedding) plus a value-receiver profile
// method sealing this exact concrete type.
type turnTestTransport struct{ inner *fakeTransport }

func (t turnTestTransport) Name() string { return t.inner.Name() }

func (t turnTestTransport) NewSession(ctx context.Context, auth TransportAuth) (Session, error) {
	return t.inner.NewSession(ctx, auth)
}

func (t turnTestTransport) WiremuxRelayTransportProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3TransportForTest(t)
}

// countingRelayAllocator counts Allocate calls and delegates to allocate, or
// fails by default so tests that must not allocate detect any call.
type countingRelayAllocator struct {
	mu       sync.Mutex
	calls    int
	allocate func(context.Context) (RelayPacketConn, error)
}

func (a *countingRelayAllocator) Allocate(ctx context.Context) (RelayPacketConn, error) {
	a.mu.Lock()
	a.calls++
	a.mu.Unlock()
	if a.allocate != nil {
		return a.allocate(ctx)
	}
	return nil, errors.New("connect test: unexpected TURN allocation")
}

func (a *countingRelayAllocator) callCount() int {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.calls
}

// frameRecordingChannel records every complete written control frame so tests
// can assert that no retry-dialect frame reached the peer.
type frameRecordingChannel struct {
	io.ReadWriteCloser
	mu     sync.Mutex
	writes []byte
}

func (c *frameRecordingChannel) Write(p []byte) (int, error) {
	c.mu.Lock()
	c.writes = append(c.writes, p...)
	c.mu.Unlock()
	return c.ReadWriteCloser.Write(p)
}

// recordedPayloads splits the recorded write stream into complete frame
// payloads.
func (c *frameRecordingChannel) recordedPayloads() [][]byte {
	c.mu.Lock()
	defer c.mu.Unlock()
	var payloads [][]byte
	buf := c.writes
	for len(buf) >= 4 {
		payloadLen := int(uint32(buf[0])<<24 | uint32(buf[1])<<16 | uint32(buf[2])<<8 | uint32(buf[3]))
		if payloadLen <= 0 || len(buf) < 4+payloadLen {
			return payloads
		}
		payloads = append(payloads, buf[4:4+payloadLen])
		buf = buf[4+payloadLen:]
	}
	return payloads
}

// wroteTurnRetryStart reports how many recorded frames are the exact minimal
// retry Start.
func (c *frameRecordingChannel) turnRetryStartCount() int {
	count := 0
	for _, payload := range c.recordedPayloads() {
		if decodeTurnRetryStart(payload) {
			count++
		}
	}
	return count
}

func (c *frameRecordingChannel) wroteTurnRetryStart() bool {
	return c.turnRetryStartCount() > 0
}

// turnRetryFallbackReasons lists the reasons of every recorded retry Fallback
// frame in write order.
func (c *frameRecordingChannel) turnRetryFallbackReasons() []UpgradeFallbackReason {
	var reasons []UpgradeFallbackReason
	for _, payload := range c.recordedPayloads() {
		if fallback, ok := decodeTurnRetryFallback(payload); ok {
			reasons = append(reasons, fallback.Reason)
		}
	}
	return reasons
}

type turnRetryTestPeer struct {
	name      string
	negotiate *Negotiator
	relay     *frameRecordingChannel
	conn      net.PacketConn
	allocator *countingRelayAllocator
	role      upgradeRole
	extraOpts []UpgradeOption
	// probeRunner, when set, replaces the retry probe execution through the
	// production test seam (testTurnRetryProbeRunner).
	probeRunner turnRetryProbeRunner
}

type turnRetryTestOutcome struct {
	result UpgradeResult
	err    error
}

// newTurnRetryFailingDirectPeers builds a two-peer fixture whose direct
// probing always fails: fake gathered interface addresses never receive
// traffic. Returned peers are identified by upgrade role, not fixture name.
func newTurnRetryFailingDirectPeers(t *testing.T) (dialer, listener *turnRetryTestPeer) {
	t.Helper()
	return newTurnRetryPeersBound(t, "0.0.0.0:0")
}

// newTurnRetryLoopbackDirectPeers builds a two-peer fixture whose explicit
// loopback bindings become the offered host candidates as-is, so direct probe
// traffic really flows between the peers. Tests shape which side succeeds by
// wrapping a peer's conn (for example probeResponseDroppingConn).
func newTurnRetryLoopbackDirectPeers(t *testing.T) (dialer, listener *turnRetryTestPeer) {
	t.Helper()
	return newTurnRetryPeersBound(t, "127.0.0.1:0")
}

func newTurnRetryPeersBound(t *testing.T, bindAddr string) (dialer, listener *turnRetryTestPeer) {
	t.Helper()

	aliceRelayRaw, bobRelayRaw := net.Pipe()
	t.Cleanup(func() {
		_ = aliceRelayRaw.Close()
		_ = bobRelayRaw.Close()
	})
	aliceRelay := &frameRecordingChannel{ReadWriteCloser: aliceRelayRaw}
	bobRelay := &frameRecordingChannel{ReadWriteCloser: bobRelayRaw}

	alice, bob := newNegotiatorPair(t, aliceRelay, bobRelay)

	aliceConn := listenPacketNetwork(t, "udp4", bindAddr)
	t.Cleanup(func() { _ = aliceConn.Close() })
	bobConn := listenPacketNetwork(t, "udp4", bindAddr)
	t.Cleanup(func() { _ = bobConn.Close() })

	alicePeer := &turnRetryTestPeer{
		name:      "alice",
		negotiate: alice,
		relay:     aliceRelay,
		conn:      aliceConn,
		allocator: &countingRelayAllocator{},
	}
	bobPeer := &turnRetryTestPeer{
		name:      "bob",
		negotiate: bob,
		relay:     bobRelay,
		conn:      bobConn,
		allocator: &countingRelayAllocator{},
	}

	alicePeer.role = newDirectUpgradeAttempt(alice, upgradeConfig{transport: &fakeTransport{name: "fake-stream"}}).role()
	bobPeer.role = newDirectUpgradeAttempt(bob, upgradeConfig{transport: &fakeTransport{name: "fake-stream"}}).role()
	if alicePeer.role == bobPeer.role {
		t.Fatalf("both peers assigned role %v", alicePeer.role)
	}
	if alicePeer.role == upgradeRoleDial {
		return alicePeer, bobPeer
	}
	return bobPeer, alicePeer
}

func runTurnRetryTestPeer(t *testing.T, peer *turnRetryTestPeer, configureTURN bool) <-chan turnRetryTestOutcome {
	t.Helper()

	gatherer := testGathererWithInterfaces([]gatherInterface{{
		name:  "test0",
		flags: net.FlagUp,
		addrs: []net.Addr{testNetAddr("192.0.2.10/24")},
	}})

	opts := []UpgradeOption{
		WithTransport(turnTestTransport{inner: &fakeTransport{name: "fake-stream"}}),
		WithUpgradePacketConn(peer.conn),
		WithProbeTimeout(50 * time.Millisecond),
		WithUpgradeControlTimeout(time.Second),
	}
	if configureTURN {
		opts = append(opts, WithTURNAllocator(peer.allocator))
	}
	opts = append(opts, peer.extraOpts...)
	cfg := testUpgradeConfig(t, opts...)
	cfg.testGatherer = gatherer

	done := make(chan turnRetryTestOutcome, 1)
	go func() {
		result, err := newDirectUpgradeAttempt(peer.negotiate, cfg).run(context.Background())
		done <- turnRetryTestOutcome{result: result, err: err}
	}()
	return done
}

func TestTurnRetryOneSidedConfigurationPreservesV1ProbeFailedFallback(t *testing.T) {
	cases := []struct {
		name           string
		configureDial  bool
		configureListn bool
	}{
		{name: "dialer only", configureDial: true},
		{name: "listener only", configureListn: true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dialer, listener := newTurnRetryFailingDirectPeers(t)
			dialerDone := runTurnRetryTestPeer(t, dialer, tc.configureDial)
			listenerDone := runTurnRetryTestPeer(t, listener, tc.configureListn)

			dialerOutcome := <-dialerDone
			listenerOutcome := <-listenerDone
			assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackProbeFailed)
			assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackProbeFailed)

			if calls := dialer.allocator.callCount(); calls != 0 {
				t.Fatalf("dialer allocator calls = %d, want 0", calls)
			}
			if calls := listener.allocator.callCount(); calls != 0 {
				t.Fatalf("listener allocator calls = %d, want 0", calls)
			}
			if dialer.relay.wroteTurnRetryStart() {
				t.Fatal("dialer sent retry Start without bilateral support")
			}
		})
	}
}

func TestTurnRetryDialerRelayKindExclusionEntersV1PolicyExcludedFallback(t *testing.T) {
	dialer, listener := newTurnRetryFailingDirectPeers(t)
	dialer.extraOpts = []UpgradeOption{WithCandidatePolicy(CandidatePolicy{
		ExcludeKinds: []CandidateKind{CandidateKindRelay},
	})}

	dialerDone := runTurnRetryTestPeer(t, dialer, true)
	listenerDone := runTurnRetryTestPeer(t, listener, true)

	dialerOutcome := <-dialerDone
	listenerOutcome := <-listenerDone
	assertRelayFallbackResult(t, "dialer", upgradeTestOutcome(dialerOutcome), dialer.relay, UpgradeFallbackPolicyExcluded)
	assertRelayFallbackResult(t, "listener", upgradeTestOutcome(listenerOutcome), listener.relay, UpgradeFallbackPolicyExcluded)

	if calls := dialer.allocator.callCount(); calls != 0 {
		t.Fatalf("dialer allocator calls = %d, want 0", calls)
	}
	if calls := listener.allocator.callCount(); calls != 0 {
		t.Fatalf("listener allocator calls = %d, want 0", calls)
	}
	if dialer.relay.wroteTurnRetryStart() {
		t.Fatal("dialer sent retry Start despite relay-kind exclusion")
	}
}
