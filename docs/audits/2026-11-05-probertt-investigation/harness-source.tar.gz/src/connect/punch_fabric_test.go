package connect

import (
	"context"
	"errors"
	"net"
	"net/netip"
	"sync"
	"time"

	"github.com/GridSwarm/wiremux/internal/proberuntime"
)

var (
	errPunchFabricStalled  = errors.New("connect: punch fabric stalled without pending work")
	errPunchFabricWatchdog = errors.New("connect: punch fabric wall-clock watchdog fired")
)

// punchProbeFabric is a deterministic two-runtime probe network for the
// issue-#1006 asymmetric-VPN diagnosis. It models the field topology at the
// probe seam:
//
//   - Each peer owns one packet socket, so every probe leaves that socket and
//     the peer observes the sender's reflexive address no matter which local
//     candidate the probe was scheduled for.
//   - Address+port-dependent filtering: an inbound probe is delivered only
//     after the receiving peer's send toward the probe source has activated
//     permission. The activation delay is independently configurable; earlier
//     arrivals are dropped at their arrival instant.
//   - Dead candidate addresses swallow packets silently, matching the field
//     condition (send-error pairs would retire early instead).
//
// Logical time is cooperative: it advances to the earliest pending delivery or
// receive deadline only when every registered, unreleased runtime is parked.
type punchProbeFabric struct {
	mu        sync.Mutex
	cond      *sync.Cond
	epoch     time.Time
	now       time.Time
	runtimes  []*punchProbeRuntime
	endpoints map[netip.AddrPort]*punchProbeRuntime
	active    int
	waiting   int
	round     uint64
	sends     []punchFabricSend
	aborted   error
	// deliveryLatency is the fixed logical time between a send and its
	// arrival at the destination runtime.
	deliveryLatency time.Duration
}

// punchFabricSend is one observed outbound probe datagram, timed relative to
// the fabric epoch.
type punchFabricSend struct {
	at      time.Duration
	from    netip.AddrPort
	to      netip.AddrPort
	payload []byte
}

type punchFabricPacket struct {
	at      time.Time
	payload []byte
	source  netip.AddrPort
}

func newPunchProbeFabric(epoch time.Time) *punchProbeFabric {
	fabric := &punchProbeFabric{
		epoch:           epoch,
		now:             epoch,
		endpoints:       make(map[netip.AddrPort]*punchProbeRuntime),
		deliveryLatency: time.Millisecond,
	}
	fabric.cond = sync.NewCond(&fabric.mu)
	return fabric
}

// punchProbeRuntime is one peer's attempt-bound probe runtime on the fabric.
type punchProbeRuntime struct {
	fabric                    *punchProbeFabric
	addr                      netip.AddrPort
	permitActivationDelay     time.Duration
	permitActivationDeadlines map[netip.AddrPort]time.Time
	queue                     []punchFabricPacket
	released                  bool
	blocked                   bool
	waitDeadline              time.Time
}

var _ proberuntime.Runtime = (*punchProbeRuntime)(nil)

func (f *punchProbeFabric) newRuntime(addr netip.AddrPort) *punchProbeRuntime {
	f.mu.Lock()
	defer f.mu.Unlock()
	runtime := &punchProbeRuntime{
		fabric:                    f,
		addr:                      addr,
		permitActivationDeadlines: make(map[netip.AddrPort]time.Time),
	}
	f.runtimes = append(f.runtimes, runtime)
	f.endpoints[addr] = runtime
	f.active++
	return runtime
}

// abort wakes every parked runtime with err; probePairs surfaces it as a test
// failure instead of deadlocking the suite.
func (f *punchProbeFabric) abort(err error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.aborted == nil {
		f.aborted = err
	}
	f.round++
	f.cond.Broadcast()
}

func (f *punchProbeFabric) sendLog() []punchFabricSend {
	f.mu.Lock()
	defer f.mu.Unlock()
	return append([]punchFabricSend(nil), f.sends...)
}

func (r *punchProbeRuntime) Now() time.Time {
	r.fabric.mu.Lock()
	defer r.fabric.mu.Unlock()
	return r.fabric.now
}

func (r *punchProbeRuntime) Send(ctx context.Context, packet []byte, addr net.Addr) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	destination, err := addrPortFromNetAddr(addr)
	if err != nil {
		return err
	}
	f := r.fabric
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.aborted != nil {
		return f.aborted
	}
	f.sends = append(f.sends, punchFabricSend{
		at:      f.now.Sub(f.epoch),
		from:    r.addr,
		to:      destination,
		payload: append([]byte(nil), packet...),
	})
	// The outbound punch begins permission activation at send time. Tests may
	// give one peer a network-owned activation delay independently from packet
	// delivery latency; later sends cannot postpone an activation already in
	// progress.
	activationDeadline := f.now.Add(r.permitActivationDelay)
	current, exists := r.permitActivationDeadlines[destination]
	if !exists || activationDeadline.Before(current) {
		r.permitActivationDeadlines[destination] = activationDeadline
	}
	target := f.endpoints[destination]
	if target == nil || target == r {
		return nil // packet-swallowing dead candidate address
	}
	target.queue = append(target.queue, punchFabricPacket{
		at:      f.now.Add(f.deliveryLatency),
		payload: append([]byte(nil), packet...),
		source:  r.addr,
	})
	return nil
}

func (r *punchProbeRuntime) Receive(ctx context.Context, packet []byte, deadline time.Time) (int, net.Addr, bool, error) {
	f := r.fabric
	f.mu.Lock()
	defer f.mu.Unlock()
	for {
		if err := ctx.Err(); err != nil {
			return 0, nil, false, err
		}
		if f.aborted != nil {
			return 0, nil, false, f.aborted
		}
		if n, addr, ok := r.receiveArrivedLocked(packet); ok {
			return n, addr, false, nil
		}
		if !f.now.Before(deadline) {
			return 0, nil, true, nil
		}
		f.parkLocked(r, deadline)
	}
}

func (r *punchProbeRuntime) Release() {
	f := r.fabric
	f.mu.Lock()
	defer f.mu.Unlock()
	if r.released {
		return
	}
	r.released = true
	f.active--
	if f.active > 0 && f.waiting == f.active {
		f.advanceLocked()
	}
}

// sleepUntil delays this peer's probe start while keeping the runtime a full
// cooperative participant, modeling probe-start skew from offer arrival and
// processing time. Unpermitted arrivals are still dropped at arrival time, as
// the peer's NAT would drop them regardless of whether probing has begun.
func (r *punchProbeRuntime) sleepUntil(target time.Time) {
	f := r.fabric
	f.mu.Lock()
	defer f.mu.Unlock()
	for {
		if f.aborted != nil {
			return
		}
		r.dropUnpermittedArrivedLocked()
		if !f.now.Before(target) {
			return
		}
		f.parkLocked(r, target)
	}
}

// receiveArrivedLocked returns the earliest arrived, NAT-admitted packet.
func (r *punchProbeRuntime) receiveArrivedLocked(buf []byte) (int, net.Addr, bool) {
	r.dropUnpermittedArrivedLocked()
	for i := range r.queue {
		if r.queue[i].at.After(r.fabric.now) {
			continue
		}
		delivered := r.queue[i]
		r.queue = append(r.queue[:i], r.queue[i+1:]...)
		n := copy(buf, delivered.payload)
		return n, net.UDPAddrFromAddrPort(delivered.source), true
	}
	return 0, nil, false
}

// dropUnpermittedArrivedLocked applies inbound filtering at each packet's
// arrival instant: cooperative advance always halts at delivery times, so this
// runs with the permit state the receiver had when the packet arrived.
func (r *punchProbeRuntime) dropUnpermittedArrivedLocked() {
	for i := 0; i < len(r.queue); {
		if r.queue[i].at.After(r.fabric.now) {
			i++
			continue
		}
		activationDeadline, ok := r.permitActivationDeadlines[r.queue[i].source]
		if ok && !r.queue[i].at.Before(activationDeadline) {
			i++
			continue
		}
		r.queue = append(r.queue[:i], r.queue[i+1:]...)
	}
}

// parkLocked blocks the runtime until logical time moves. The last active
// runtime to park performs the advance for everyone.
func (f *punchProbeFabric) parkLocked(r *punchProbeRuntime, deadline time.Time) {
	r.waitDeadline = deadline
	r.blocked = true
	f.waiting++
	if f.waiting == f.active {
		f.advanceLocked()
		r.blocked = false
		return
	}
	round := f.round
	for f.round == round && f.aborted == nil {
		f.cond.Wait()
	}
	r.blocked = false
}

// advanceLocked jumps logical time to the earliest pending delivery or parked
// receive deadline, then wakes every runtime to re-evaluate at the new instant.
func (f *punchProbeFabric) advanceLocked() {
	var next time.Time
	consider := func(t time.Time) {
		if !t.After(f.now) {
			return
		}
		if next.IsZero() || t.Before(next) {
			next = t
		}
	}
	for _, runtime := range f.runtimes {
		if runtime.released {
			continue
		}
		if runtime.blocked {
			consider(runtime.waitDeadline)
		}
		for i := range runtime.queue {
			consider(runtime.queue[i].at)
		}
	}
	if next.IsZero() {
		f.aborted = errPunchFabricStalled
	} else {
		f.now = next
	}
	f.waiting = 0
	f.round++
	f.cond.Broadcast()
}
