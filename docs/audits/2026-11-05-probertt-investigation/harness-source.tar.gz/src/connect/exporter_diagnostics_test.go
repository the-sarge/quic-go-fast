package connect

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha256"
	"fmt"
	"strings"
	"sync"
	"testing"
)

// Deliberately dynamic: rejected verbs are part of the diagnostic contract,
// while ordinary literal-format call sites must continue to pass go vet.
func exporterDiagnosticFormats() []string {
	return []string{"%v", "%+v", "%#v", "%s", "%q", "%p", "%w", "%d", "%x", "%X"}
}

func exporterDiagnosticOperands(e *hkdfKeyExporter) map[string]any {
	operands := map[string]any{
		"interface":         KeyExporter(e),
		"pointer":           e,
		"exportedInterface": struct{ Exporter KeyExporter }{e},
		"exportedPointer":   struct{ Exporter *hkdfKeyExporter }{e},
		"hiddenInterface":   struct{ exporter KeyExporter }{e},
		"hiddenPointer":     struct{ exporter *hkdfKeyExporter }{e},
	}
	if e != nil {
		operands["value"] = *e
		operands["exportedValue"] = struct{ Exporter hkdfKeyExporter }{*e}
		operands["hiddenValue"] = struct{ exporter hkdfKeyExporter }{*e}
	}
	return operands
}

// RFC 5869 Extract is HMAC(salt, IKM). This oracle does not use the
// production constructor or crypto/hkdf to obtain the expected PRK.
func exporterPRKForTest(master, binding []byte) []byte {
	h := hmac.New(sha256.New, binding)
	_, _ = h.Write(master)
	return h.Sum(nil)
}

func exporterSecretRenderings(secret []byte) map[string]string {
	goBytes := fmt.Sprintf("%#v", secret)
	return map[string]string{
		"raw":          string(secret),
		"quoted":       fmt.Sprintf("%q", secret),
		"decimal":      fmt.Sprintf("%d", secret),
		"hexLower":     fmt.Sprintf("%x", secret),
		"hexUpper":     fmt.Sprintf("%X", secret),
		"goBytes":      goBytes,
		"goUint8":      strings.Replace(goBytes, "[]byte", "[]uint8", 1),
		"goByteValues": strings.TrimPrefix(goBytes, "[]byte"),
	}
}

func exporterDiagnosticLeak(rendered string, secrets map[string]string) string {
	for name, secret := range secrets {
		if strings.Contains(rendered, secret) {
			return name
		}
	}
	return ""
}

func TestHKDFKeyExporterDiagnosticDetector(t *testing.T) {
	prk := exporterPRKForTest([]byte("diagnostic synthetic master"), []byte("diagnostic synthetic binding"))
	secrets := exporterSecretRenderings(prk)
	for name, planted := range secrets {
		t.Run(name, func(t *testing.T) {
			if exporterDiagnosticLeak("holder{"+planted+"}", secrets) == "" {
				t.Fatal("planted secret detection: got false, want true")
			}
		})
	}
	// Exercise fmt's actual hidden-field fallback, including reflected []uint8.
	for _, format := range []string{"%v", "%+v", "%#v", "%s", "%q", "%d", "%x", "%X"} {
		t.Run("hidden/"+format, func(t *testing.T) {
			rendered := fmt.Sprintf(format, struct{ prk []byte }{prk})
			if exporterDiagnosticLeak(rendered, secrets) == "" {
				t.Fatal("hidden secret detection: got false, want true")
			}
		})
	}
	if exporterDiagnosticLeak("HKDFKeyExporter{<redacted>}", secrets) != "" {
		t.Fatal("redacted detection: got true, want false")
	}
}

func TestHKDFKeyExporterDiagnostics(t *testing.T) {
	master := []byte("diagnostic synthetic master")
	binding := []byte("diagnostic synthetic binding")
	secrets := exporterSecretRenderings(exporterPRKForTest(master, binding))
	states := map[string]*hkdfKeyExporter{
		"valid":   NewHKDFKeyExporter(master, binding).(*hkdfKeyExporter),
		"invalid": NewHKDFKeyExporter(nil, binding).(*hkdfKeyExporter),
		"zero":    {},
		"nil":     nil,
	}
	for state, e := range states {
		t.Run(state, func(t *testing.T) {
			var before []byte
			var beforeErr error
			if e != nil {
				before, beforeErr = e.Derive("diagnostic stability", nil, 32)
			}
			for name, operand := range exporterDiagnosticOperands(e) {
				for _, format := range exporterDiagnosticFormats() {
					t.Run(name+"/"+format, func(t *testing.T) {
						rendered := fmt.Sprintf(format, operand)
						if encoding := exporterDiagnosticLeak(rendered, secrets); encoding != "" {
							t.Errorf("retained PRK exposure (%s): got true, want false", encoding)
						}
						if strings.Contains(rendered, "PANIC=") {
							t.Error("formatter panic marker: got true, want false")
						}
					})
				}
			}
			if e != nil {
				after, afterErr := e.Derive("diagnostic stability", nil, 32)
				if !bytes.Equal(before, after) || beforeErr != afterErr { //nolint:errorlint // Verify formatting preserves the exact error identity, including nil.
					t.Error("derivation changed after diagnostics: got true, want false")
				}
			}
		})
	}
}

func TestHKDFKeyExporterDirectRedaction(t *testing.T) {
	for name, e := range map[string]*hkdfKeyExporter{
		"valid":   NewHKDFKeyExporter([]byte("synthetic master"), nil).(*hkdfKeyExporter),
		"invalid": NewHKDFKeyExporter(nil, nil).(*hkdfKeyExporter),
		"zero":    {},
	} {
		t.Run(name, func(t *testing.T) {
			for _, operand := range []any{KeyExporter(e), e, *e} {
				// Literal formats remain checked by the normal vet pass.
				for _, rendered := range []string{
					fmt.Sprintf("%v", operand), fmt.Sprintf("%+v", operand),
					fmt.Sprintf("%#v", operand), fmt.Sprintf("%s", operand),
				} {
					if rendered != "HKDFKeyExporter{<redacted>}" {
						t.Error("intentional redacted diagnostic: got false, want true")
					}
				}
				if fmt.Sprintf("%q", operand) != `"HKDFKeyExporter{<redacted>}"` {
					t.Error("quoted redacted diagnostic: got false, want true")
				}
			}
		})
	}
}

func TestHKDFKeyExporterConcurrentDiagnostics(t *testing.T) {
	master := []byte("diagnostic synthetic master")
	binding := []byte("diagnostic synthetic binding")
	e := NewHKDFKeyExporter(master, binding).(*hkdfKeyExporter)
	secrets := exporterSecretRenderings(exporterPRKForTest(master, binding))
	want := exporterKnownAnswerForTest(t)
	operands := exporterDiagnosticOperands(e)
	var workers sync.WaitGroup
	start := make(chan struct{})
	for range 4 {
		workers.Go(func() {
			<-start
			for range 16 {
				for name, operand := range operands {
					for _, format := range exporterDiagnosticFormats() {
						rendered := fmt.Sprintf(format, operand)
						if exporterDiagnosticLeak(rendered, secrets) != "" || strings.Contains(rendered, "PANIC=") {
							t.Errorf("safe concurrent diagnostic (%s/%s): got false, want true", name, format)
							return
						}
					}
				}
				got, err := e.Derive("wiremux v1 test", []byte{0, 255, 1}, len(want))
				if err != nil || !bytes.Equal(got, want) {
					t.Error("concurrent known-answer derivation: got mismatch, want match")
					return
				}
			}
		})
	}
	close(start)
	workers.Wait()
}
