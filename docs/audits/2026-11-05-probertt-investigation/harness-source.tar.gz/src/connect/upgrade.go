package connect

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"io"
	"net"
	"net/netip"
	"time"

	"github.com/GridSwarm/wiremux/internal/packetownership"
)

type upgradeRole uint8

const (
	upgradeRoleListen upgradeRole = iota + 1
	upgradeRoleDial
)

const upgradeTransportSessionCleanupTimeout = 100 * time.Millisecond

const (
	upgradePacketDrainMaxPackets = 64
	upgradePacketDrainMaxElapsed = 50 * time.Millisecond
	upgradePacketDrainIdleWait   = 2 * time.Millisecond
)

var (
	errNilTransportStream                  = errors.New("connect: transport returned nil stream")
	errNilTransportListener                = errors.New("connect: transport returned nil listener")
	errUnexpectedListenerHandoffState      = errors.New("connect: unexpected listener handoff state")
	errUnexpectedDirectUpgradeControlState = errors.New("connect: unexpected direct-upgrade control state")
	errUnexpectedPostCommitPhaseOrder      = errors.New("connect: unexpected direct-upgrade post-commit phase order")
)

type localUpgradeOffer struct {
	transportName     string
	handshakeMaterial []byte
	probeNonce        []byte
	candidates        []Candidate
	// role is derived locally from directional key orientation; it is not encoded in the offer frame.
	role upgradeRole
	// turnRetry advertises canonical wiremux.turn-retry/1 capability in the v1
	// Offer extension map. An unconfigured peer's complete Offer stays
	// byte-identical because the extensions key is omitted entirely.
	turnRetry bool
}

type directUpgradeAttempt struct {
	channel        io.ReadWriteCloser
	auth           AuthContext
	transportAuth  TransportAuth
	testProbeRetry func() time.Duration

	cfg            upgradeConfig
	keyOrientation DirectionalKeyOrientation
	controlFrames  *controlFrameSequencer
	owner          *attemptResources
}

// Upgrade attempts a transport upgrade and returns the active stream plus path metadata.
//
// Nil ctx and invalid options are precondition failures and return the zero
// UpgradeResult with a sentinel error without consuming or closing the relay
// channel. When no packet socket is supplied, direct upgrade is not requested;
// Upgrade synchronizes a first-phase fallback over the relay stream and returns
// that relay stream with not_requested metadata unless the peer's first-phase
// message has higher fallback precedence. In normal use, both peers should
// enter Upgrade concurrently. Direct-capable peers exchange offers, run bounded
// UDP probes, converge on a selected pair with ready/commit control frames, and
// hand the probed packet socket to the configured transport. After commit,
// direct success requires listener accepted, dialer converged, and listener
// confirmed control frames before peers close the obsolete relay channel.
// Callers must supply a
// cancelable or deadlined context when the peer may be absent or may not enter
// Upgrade concurrently.
// If Upgrade returns a direct path, the returned stream owns cleanup for the
// packet socket supplied with WithUpgradePacketConn. Relay fallback and setup
// errors leave a dialer's socket caller-owned until local commit and a
// listener's socket caller-owned until local commit or any non-nil stream
// returned by Session.Dial or TransportListener.Accept. A non-nil stream
// transfers ownership even when returned with an error and before listener
// commit is observed. After the applicable boundary,
// ErrUpgradeTransportNotConverged closes direct transport resources and the
// socket before returning no active stream; relay fallback is not available.
// Cancellation, deadline expiry, or control-frame I/O failure after the control
// exchange begins may close or consume the relay channel; in those cases
// Upgrade returns the zero UpgradeResult and no active stream.
func (n *Negotiator) Upgrade(ctx context.Context, opts ...UpgradeOption) (UpgradeResult, error) {
	if ctx == nil {
		return UpgradeResult{}, ErrNilContext
	}
	cfg, err := newUpgradeConfig(opts)
	if err != nil {
		return UpgradeResult{}, err
	}

	attempt := newDirectUpgradeAttempt(n, cfg, packetownership.MarkerFromContext(ctx))
	return attempt.run(ctx)
}

func newDirectUpgradeAttempt(
	n *Negotiator,
	cfg upgradeConfig,
	markers ...packetownership.Marker,
) directUpgradeAttempt {
	channel := n.channel
	marker := packetownership.NewMarker()
	if len(markers) != 0 {
		marker = markers[0]
	}
	owner := newAttemptResources(channel, cfg.packetConn, marker)
	owner.strict = cfg.strict
	if cfg.strict {
		owner.strictToken = new(strictAttemptToken)
	}
	return directUpgradeAttempt{
		channel:        channel,
		auth:           n.auth,
		transportAuth:  n.transportAuth,
		cfg:            cfg,
		keyOrientation: n.directionalKeyOrientation,
		controlFrames:  newControlFrameSequencer(channel, owner.strictToken),
		owner:          owner,
	}
}

func (a directUpgradeAttempt) run(ctx context.Context) (UpgradeResult, error) {
	resources := a.resources()
	resources.strictCallerCtx = ctx
	select {
	case <-ctx.Done():
		return resources.failClosed(ctx.Err(), retainForOuterSettlement)
	default:
	}

	if a.selectedPacketConn() == nil {
		return a.firstPhaseFallback(ctx, UpgradeFallbackNotRequested)
	}

	setupCtx, cancelSetup := context.WithTimeout(ctx, a.cfg.probeTimeout)
	defer cancelSetup()

	session, err := a.newTransportSession(setupCtx)
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return resources.failClosed(ctxErr, retainForOuterSettlement)
		}
		if a.cfg.strict && setupCtx.Err() == nil {
			cause := resources.strictTransportCause(err)
			if resources.strictTerminalCause(cause) {
				return resources.failClosed(cause, abortBeforeOwnedResources)
			}
		}
		return a.firstPhaseFallback(ctx, UpgradeFallbackTransportFailed)
	}
	if session == nil {
		if a.cfg.strict {
			return resources.failClosed(resources.strictCause(UpgradeErrorLocal, errNilTransportSession), abortBeforeOwnedResources)
		}
		return a.firstPhaseFallback(ctx, UpgradeFallbackTransportFailed)
	}
	candidates, fallbackReason, err := a.localCandidates(setupCtx)
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return resources.failClosed(ctxErr, retainForOuterSettlement)
		}
		if a.cfg.strict && setupCtx.Err() == nil {
			return resources.failClosed(err, abortBeforeOwnedResources)
		}
		return a.firstPhaseFallback(ctx, UpgradeFallbackTransportFailed)
	}
	if fallbackReason != UpgradeFallbackNone {
		return a.firstPhaseFallback(ctx, fallbackReason)
	}
	probeNonce, err := newProbeNonce()
	if err != nil {
		if a.cfg.strict {
			return resources.failClosed(a.resources().strictCause(UpgradeErrorLocal, err), abortBeforeOwnedResources)
		}
		return a.firstPhaseFallback(ctx, UpgradeFallbackTransportFailed)
	}
	offer, err := a.localOffer(setupCtx, session, candidates, probeNonce)
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return resources.failClosed(ctxErr, retainForOuterSettlement)
		}
		if a.cfg.strict && setupCtx.Err() == nil {
			return resources.failClosed(a.resources().strictCause(UpgradeErrorLocal, err), abortBeforeOwnedResources)
		}
		return a.firstPhaseFallback(ctx, UpgradeFallbackTransportFailed)
	}
	if err := validateUpgradeControlOffer(offer); err != nil {
		if a.cfg.strict {
			return resources.failClosed(a.resources().strictCause(UpgradeErrorLocal, err), abortBeforeOwnedResources)
		}
		return a.firstPhaseFallback(ctx, UpgradeFallbackTransportFailed)
	}

	peer, err := a.firstPhaseOffer(ctx, offer)
	if err != nil {
		return resources.failClosed(err, abortBeforeOwnedResources)
	}
	if peer.HasFallback {
		return resources.settleRelay(firstPhasePeerFallbackReason(peer.FallbackReason))
	}
	// The first-phase decoder returns exactly one successful state:
	// fallback handled above or offer handled below.

	terminalFallback := newTerminalFallbackExchange(a)
	if peer.Offer.transportName != offer.transportName {
		return terminalFallback.withSessionCleanup(ctx, session, UpgradeFallbackTransportMismatch)
	}
	pairPlan := planProbeCandidatePairs(offer.candidates, peer.Offer.candidates, a.cfg.candidatePolicy, offer.role)

	probeCtx, cancelProbe := context.WithCancel(ctx)
	defer cancelProbe()

	race, err := a.probeCandidatePairsWithTerminalFallback(probeCtx, cancelProbe, offer, peer.Offer, pairPlan)
	if a.cfg.strict && race.peer != nil && race.peer.err != nil {
		err = resources.strictCause(resources.strictFailureKind(race.peer.err), race.peer.err)
	}
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return resources.failClosed(ctxErr, abortBeforeOwnedResources)
		}
		if a.cfg.strict {
			if _, tagged := resources.strictSemanticKind(err); !tagged {
				err = resources.strictCause(UpgradeErrorLocal, err)
			}
			if resources.strictTerminalCause(err) {
				return resources.failClosed(err, abortBeforeOwnedResources)
			}
		}
	}
	if race.kind == probeControlRacePeerFallback {
		return terminalFallback.withSessionCleanupUsingPeerFallback(ctx, session, race.probe.fallback, race.peer)
	}
	if err != nil {
		return terminalFallback.withSessionCleanup(ctx, session, race.probe.fallback)
	}
	if race.kind == probeControlRaceSelectedPair {
		return a.directTransportHandoff(ctx, session, offer, peer.Offer, pairPlan, candidatePairProbeResult{}, 0)
	}
	if race.kind == probeControlRaceTurnRetryStart {
		return a.runTurnRetryListener(ctx, session, offer, peer.Offer)
	}
	if !race.probe.succeeded {
		bilateral := turnRetryBilateralCapability(offer, peer.Offer)
		if bilateral && offer.role == upgradeRoleDial && race.probe.fallback == UpgradeFallbackProbeFailed {
			return a.runTurnRetryDialer(ctx, session, terminalFallback, offer, peer.Offer)
		}
		if bilateral && offer.role == upgradeRoleListen {
			// A listener that reaches the v1 terminal exchange under bilateral
			// support may still receive a crossed Retry Start; it stays
			// exclusively in the v1 exchange and treats the exact Start as a
			// no-op.
			return terminalFallback.withSessionCleanupIgnoringTurnRetryStart(ctx, session, race.probe.fallback)
		}
		return terminalFallback.withSessionCleanup(ctx, session, race.probe.fallback)
	}

	return a.directTransportHandoff(ctx, session, offer, peer.Offer, pairPlan, race.probe, race.probe.rtt)
}

type transportSessionResult struct {
	session Session
	err     error
}

type probeCandidatePairsOutcome struct {
	result candidatePairProbeResult
	err    error
}

type probeControlRaceKind uint8

const (
	probeControlRaceProbeDone probeControlRaceKind = iota + 1
	probeControlRaceSelectedPair
	probeControlRacePeerFallback
	probeControlRaceFailed
	probeControlRaceTurnRetryStart
)

type probeControlRaceOutcome struct {
	kind     probeControlRaceKind
	probe    candidatePairProbeResult
	selected selectedPair
	peer     *terminalFallbackReadResult
	err      error
}

type controlFrameReadResult struct {
	payload []byte
	err     error
}

type terminalFallbackReadResult struct {
	peer upgradeControlFallback
	err  error
}

func (a directUpgradeAttempt) newTransportSession(ctx context.Context) (Session, error) {
	resources := a.resources()
	done := make(chan transportSessionResult)
	go func() {
		session, err := a.cfg.transport.NewSession(ctx, a.transportAuth)
		result := transportSessionResult{session: session, err: err}
		registered := resources.registerSession(result.session)
		if result.session != nil && !registered {
			_ = closeTransportSessionWithTimeout(result.session)
		}
		select {
		case done <- result:
		case <-ctx.Done():
		}
	}()

	select {
	case result := <-done:
		if ctxErr := ctx.Err(); ctxErr != nil {
			return nil, ctxErr
		}
		if result.err != nil {
			return nil, result.err
		}
		return result.session, result.err
	case <-ctx.Done():
		return nil, ctx.Err()
	}
}

func closeTransportSessionWithTimeout(session Session) error {
	ctx, cancel := context.WithTimeout(context.Background(), upgradeTransportSessionCleanupTimeout)
	defer cancel()
	return closeTransportSession(ctx, session)
}

func closeTransportSession(ctx context.Context, session Session) error {
	if session == nil {
		return nil
	}

	done := make(chan error, 1)
	go func() {
		done <- session.Close()
	}()

	select {
	case err := <-done:
		return err
	case <-ctx.Done():
		return ctx.Err()
	}
}

func (a directUpgradeAttempt) localCandidates(ctx context.Context) ([]Candidate, UpgradeFallbackReason, error) {
	opts := []GatherOption{WithPacketConn(a.selectedPacketConn())}
	if a.cfg.stunServerSet {
		opts = append(opts, WithSTUNServer(a.cfg.stunServer))
	}
	candidates, err := a.cfg.testGatherer.gatherCandidates(ctx, opts...)
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return nil, UpgradeFallbackNone, ctxErr
		}
		if errors.Is(err, ErrNoCandidates) {
			plan := planLocalCandidates(nil, a.cfg.candidatePolicy)
			return plan.candidates, plan.fallback, nil
		}
		if a.cfg.strict {
			return nil, UpgradeFallbackNone, a.resources().strictCause(UpgradeErrorLocal, err)
		}
		return nil, UpgradeFallbackTransportFailed, nil
	}

	plan := planLocalCandidates(candidates, a.cfg.candidatePolicy)
	return plan.candidates, plan.fallback, nil
}

func newProbeNonce() ([]byte, error) {
	nonce := make([]byte, upgradeControlProbeNonceBytes)
	if _, err := rand.Read(nonce); err != nil {
		return nil, err
	}
	return nonce, nil
}

func (a directUpgradeAttempt) firstPhaseFallback(ctx context.Context, reason UpgradeFallbackReason) (UpgradeResult, error) {
	frame, err := encodeUpgradeControlFallback(reason)
	if err != nil {
		return a.resources().failClosed(err, retainForOuterSettlement)
	}

	peer, err := a.exchangeFirstPhaseControlFrame(ctx, frame)
	if err != nil {
		return a.resources().failClosed(err, abortBeforeOwnedResources)
	}

	fallbackReason := reason
	if peer.HasFallback {
		fallbackReason = resolveFallbackReason(fallbackReasonPhaseFirst, reason, peer.FallbackReason)
	}
	return a.resources().settleRelay(fallbackReason)
}

func (a directUpgradeAttempt) firstPhaseOffer(ctx context.Context, offer localUpgradeOffer) (upgradeControlFirstPhase, error) {
	frame, err := encodeUpgradeControlOffer(offer)
	if err != nil {
		return upgradeControlFirstPhase{}, err
	}

	return a.exchangeFirstPhaseControlFrame(ctx, frame)
}

func terminalFallbackFromControlFrame(result controlFrameReadResult, strict ...bool) terminalFallbackReadResult {
	if result.err != nil {
		return terminalFallbackReadResult{err: result.err}
	}
	peer, cause := decodeUpgradeControlFallbackPayload(result.payload)
	if len(strict) == 0 || !strict[0] {
		cause = nil
	}
	return terminalFallbackReadResult{peer: peer, err: cause}
}

func (a directUpgradeAttempt) probeCandidatePairsWithTerminalFallback(
	ctx context.Context,
	cancelProbe context.CancelFunc,
	local localUpgradeOffer,
	peer localUpgradeOffer,
	pairPlan candidatePairPlan,
) (probeControlRaceOutcome, error) {
	probeDone := make(chan probeCandidatePairsOutcome, 1)
	go func() {
		result, err := a.probeCandidatePairPlan(ctx, local, peer, pairPlan)
		probeDone <- probeCandidatePairsOutcome{result: result, err: err}
	}()

	bilateral := turnRetryBilateralCapability(local, peer)
	var (
		held        *probeCandidatePairsOutcome
		holdTimer   *time.Timer
		holdTimeout <-chan time.Time
		// holdCanceled is armed only while held: outer cancellation must end
		// the hold promptly with the exact context error rather than waiting
		// for a peer frame or the control-timeout hold expiry. Before the
		// hold, the probe operation itself observes ctx and reports through
		// probeDone, so an unconditional arm would race the probe join.
		holdCanceled <-chan struct{}
	)
	defer func() {
		if holdTimer != nil {
			holdTimer.Stop()
		}
	}()
	// joinProbe returns the completed probe outcome: the held one when the
	// bilateral listener hold already drained probeDone, otherwise it cancels
	// the probe and awaits the outcome.
	joinProbe := func() probeCandidatePairsOutcome {
		if held != nil {
			return *held
		}
		cancelProbe()
		return <-probeDone
	}

	for {
		var probePending <-chan probeCandidatePairsOutcome
		if held == nil {
			probePending = probeDone
		}
		select {
		case peerFrame := <-a.controlFrames.next():
			// The probe race must choose between a relay control frame and probe
			// completion; recv would hide that two-event select behind a goroutine.
			if local.role == upgradeRoleListen {
				if bilateral && peerFrame.err == nil && decodeTurnRetryStart(peerFrame.payload) {
					// Authenticated Retry Start before this listener sent v1
					// Fallback: cancel and join the direct probe, discard held
					// success or failure, and enter retry.
					outcome := joinProbe()
					if outcome.err != nil && !errors.Is(outcome.err, context.Canceled) {
						return probeControlRaceOutcome{
							kind:  probeControlRaceFailed,
							probe: outcome.result,
							err:   outcome.err,
						}, outcome.err
					}
					return probeControlRaceOutcome{kind: probeControlRaceTurnRetryStart}, nil
				}
				// This peek preserves the raw frame for validation by its phase owner.
				selectedPhase, _ := decodeUpgradeControlSelectedPairPhasePayload(peerFrame.payload)
				if selectedPhase.HasSelectedPair {
					outcome := joinProbe()
					outcome.err = a.resources().strictJoinedProbeCause(outcome.err)
					if outcome.err != nil && (a.cfg.strict || !errors.Is(outcome.err, context.Canceled)) {
						return probeControlRaceOutcome{
							kind:  probeControlRaceFailed,
							probe: outcome.result,
							err:   outcome.err,
						}, outcome.err
					}
					a.controlFrames.unread(peerFrame)
					return probeControlRaceOutcome{
						kind:     probeControlRaceSelectedPair,
						selected: selectedPhase.SelectedPair,
					}, nil
				}
			}
			peerFallback := terminalFallbackFromControlFrame(peerFrame, a.cfg.strict)

			outcome := joinProbe()
			race := probeControlRaceOutcome{
				kind:  probeControlRacePeerFallback,
				probe: candidatePairProbeResult{fallback: localReasonAfterPeerTerminalFallback(peerFallback.peer.Reason, outcome)},
				peer:  &peerFallback,
			}
			if a.cfg.strict {
				race.err = a.resources().strictJoinedProbeCause(outcome.err)
			}
			return race, race.err
		case outcome := <-probePending:
			if outcome.err != nil {
				cancelProbe()
				return probeControlRaceOutcome{
					kind:  probeControlRaceFailed,
					probe: outcome.result,
					err:   outcome.err,
				}, outcome.err
			}
			if bilateral && local.role == upgradeRoleListen &&
				!outcome.result.succeeded && outcome.result.fallback == UpgradeFallbackProbeFailed {
				// Bilateral listener hold: a local probe_failed suppresses the
				// immediate v1 Fallback and waits under the existing control
				// timeout for the dialer's v1 Selected Pair, Retry Start, or
				// Fallback; timeout enters the existing v1 terminal exchange
				// and outer cancellation ends the hold with the exact context
				// error.
				held = &outcome
				holdTimer = time.NewTimer(a.cfg.controlTimeout)
				holdTimeout = holdTimer.C
				holdCanceled = ctx.Done()
				continue
			}
			cancelProbe()
			return probeControlRaceOutcome{
				kind:  probeControlRaceProbeDone,
				probe: outcome.result,
			}, nil
		case <-holdTimeout:
			return probeControlRaceOutcome{
				kind:  probeControlRaceProbeDone,
				probe: held.result,
			}, nil
		case <-holdCanceled:
			// The held probe already completed, so nothing remains to join;
			// the caller maps this failed race to the exact outer context
			// error exactly as it does for a probe canceled before the hold.
			return probeControlRaceOutcome{
				kind:  probeControlRaceFailed,
				probe: held.result,
				err:   ctx.Err(),
			}, ctx.Err()
		}
	}
}

func localReasonAfterPeerTerminalFallback(peerReason UpgradeFallbackReason, outcome probeCandidatePairsOutcome) UpgradeFallbackReason {
	if outcome.err != nil {
		if errors.Is(outcome.err, context.Canceled) {
			return peerReason
		}
		if outcome.result.fallback != UpgradeFallbackNone {
			return outcome.result.fallback
		}
		return UpgradeFallbackTransportFailed
	}
	if outcome.result.succeeded {
		return UpgradeFallbackTransportFailed
	}
	if outcome.result.fallback != UpgradeFallbackNone {
		return outcome.result.fallback
	}
	return peerReason
}

func (a directUpgradeAttempt) directTransportHandoff(
	ctx context.Context,
	session Session,
	local localUpgradeOffer,
	peer localUpgradeOffer,
	pairPlan candidatePairPlan,
	probeResult candidatePairProbeResult,
	localProbeRTT time.Duration,
) (UpgradeResult, error) {
	// Setup/probe stays on directUpgradeAttempt; role-specific transport
	// handoff moves from this dispatcher into the dialer/listener owners.
	if local.role == upgradeRoleDial {
		handoffCtx, cancel := context.WithTimeout(ctx, a.cfg.probeTimeout)
		defer cancel()
		return newDialerDirectUpgradeProtocolEngine(a, session, peer, probeResult).runDialer(ctx, handoffCtx)
	}
	engine := newListenerDirectUpgradeProtocolEngine(a, session, peer, pairPlan, localProbeRTT)
	if turnRetryBilateralCapability(local, peer) {
		engine.turnRetryStart = func(retryCtx context.Context) (UpgradeResult, error) {
			return a.runTurnRetryListener(retryCtx, session, local, peer)
		}
		// Bilateral held-success hold: the listener awaits the dialer's
		// Selected/Start/Fallback under the control timeout alone, matching
		// the held-failure hold, and the transport handoff budget begins only
		// once that frame arrives.
		return engine.runHeldSuccessListener(ctx, a.cfg.probeTimeout)
	}
	handoffCtx, cancel := context.WithTimeout(ctx, a.cfg.probeTimeout)
	defer cancel()
	return engine.runListener(ctx, handoffCtx)
}

func (a directUpgradeAttempt) writeUpgradeControlFrame(ctx context.Context, frame []byte) error {
	writeErr := make(chan error, 1)
	go func() {
		writeErr <- writeFull(a.channel, frame)
	}()

	timeout := time.NewTimer(a.cfg.controlTimeout)
	defer timeout.Stop()

	select {
	case err := <-writeErr:
		if err != nil {
			if ctxErr := ctx.Err(); ctxErr != nil {
				return ctxErr
			}
			return err
		}
		return nil
	case <-ctx.Done():
		return ctx.Err()
	case <-timeout.C:
		if ctxErr := ctx.Err(); ctxErr != nil {
			return ctxErr
		}
		return a.phaseTimeoutCause(ErrUpgradeControlTimeout)
	}
}

func (a directUpgradeAttempt) exchangeFirstPhaseControlFrame(
	ctx context.Context,
	frame []byte,
) (upgradeControlFirstPhase, error) {
	select {
	case <-ctx.Done():
		return upgradeControlFirstPhase{}, ctx.Err()
	default:
	}

	writeErr := make(chan error, 1)
	go func() {
		writeErr <- writeFull(a.channel, frame)
	}()
	readDone := make(chan controlFrameReadResult, 1)
	go func() {
		result, err := a.controlFrames.recv(ctx, 0)
		readDone <- controlFrameReadResult{payload: result.payload, err: err}
	}()

	timeout := time.NewTimer(a.cfg.controlTimeout)
	defer timeout.Stop()
	var (
		value upgradeControlFirstPhase
		sent  bool
		done  bool
	)
	for !sent || !done {
		if err := ctx.Err(); err != nil {
			return upgradeControlFirstPhase{}, err
		}
		var pendingWrite <-chan error
		if !sent {
			pendingWrite = writeErr
		}
		var pendingRead <-chan controlFrameReadResult
		if !done {
			pendingRead = readDone
		}
		select {
		case err := <-pendingWrite:
			sent = true
			if err != nil {
				if ctxErr := ctx.Err(); ctxErr != nil {
					return upgradeControlFirstPhase{}, ctxErr
				}
				return upgradeControlFirstPhase{}, err
			}
		case result := <-pendingRead:
			done = true
			if result.err != nil {
				if ctxErr := ctx.Err(); ctxErr != nil {
					return upgradeControlFirstPhase{}, ctxErr
				}
				return upgradeControlFirstPhase{}, result.err
			}
			var payloadCause error
			value, payloadCause = decodeUpgradeControlFirstPhasePayload(result.payload)
			if a.cfg.strict && payloadCause != nil {
				return upgradeControlFirstPhase{}, payloadCause
			}
		case <-ctx.Done():
			return upgradeControlFirstPhase{}, ctx.Err()
		case <-timeout.C:
			if ctxErr := ctx.Err(); ctxErr != nil {
				return upgradeControlFirstPhase{}, ctxErr
			}
			return upgradeControlFirstPhase{}, a.phaseTimeoutCause(ErrUpgradeControlTimeout)
		}
	}
	return value, nil
}

type transportListenResult struct {
	listener TransportListener
	err      error
}

type transportStreamResult struct {
	stream                       io.ReadWriteCloser
	datagrams                    DatagramCarrier
	datagramCarrierValidationErr bool
	err                          error
}

type transportStreamResultClass uint8

const (
	transportStreamResultNoMaterialization transportStreamResultClass = iota + 1
	transportStreamResultSuccess
	transportStreamResultMaterializedError
)

func classifyTransportStreamResult(result transportStreamResult) transportStreamResultClass {
	if result.stream == nil {
		return transportStreamResultNoMaterialization
	}
	if result.err != nil {
		return transportStreamResultMaterializedError
	}
	return transportStreamResultSuccess
}

func newTransportStreamResult(stream io.ReadWriteCloser, err error) transportStreamResult {
	result := transportStreamResult{stream: stream, err: err}
	if classifyTransportStreamResult(result) == transportStreamResultSuccess {
		result.datagrams, result.err = datagramCarrierFromStream(result.stream)
		result.datagramCarrierValidationErr = result.err != nil
	}
	return result
}

type transportAcceptResult = transportStreamResult

func isPreCommitControlTimeout(err error) bool {
	return errors.Is(err, ErrUpgradeControlTimeout) || errors.Is(err, context.DeadlineExceeded)
}

func isStoppedCommitAwait(err error) bool {
	return isPreCommitControlTimeout(err) || errors.Is(err, context.Canceled)
}

func directUpgradeResult(stream io.ReadWriteCloser, datagrams DatagramCarrier, pair CandidatePair, rtt time.Duration) UpgradeResult {
	return UpgradeResult{
		Stream:       reliableOnlyStream{stream: stream},
		Datagrams:    datagrams,
		Path:         UpgradePathDirect,
		SelectedPair: &pair,
		ProbeRTT:     rtt,
	}
}

type reliableOnlyStream struct {
	stream io.ReadWriteCloser
}

func (s reliableOnlyStream) Read(p []byte) (int, error)  { return s.stream.Read(p) }
func (s reliableOnlyStream) Write(p []byte) (int, error) { return s.stream.Write(p) }
func (s reliableOnlyStream) Close() error                { return s.stream.Close() }

// Abort preserves the built-in transport's interruption capability for
// the managed root lifetime without exposing Datagram or raw stream access.
func (s reliableOnlyStream) Abort() error {
	if aborter, ok := s.stream.(interface{ Abort() error }); ok {
		return aborter.Abort()
	}
	return fmt.Errorf("connect: transport stream does not support abort: %w", errors.ErrUnsupported)
}

func netUDPAddr(addr netip.AddrPort) net.Addr {
	return net.UDPAddrFromAddrPort(addr)
}

func drainPacketConn(ctx context.Context, conn net.PacketConn) {
	drainPacketConnWithNow(ctx, conn, time.Now)
}

func drainPacketConnWithNow(ctx context.Context, conn net.PacketConn, now func() time.Time) {
	if conn == nil {
		return
	}
	deadline := now().Add(upgradePacketDrainMaxElapsed)
	if ctx != nil {
		if ctxDeadline, ok := ctx.Deadline(); ok && ctxDeadline.Before(deadline) {
			deadline = ctxDeadline
		}
	}
	buf := make([]byte, 2048)
	for range upgradePacketDrainMaxPackets {
		if ctx != nil {
			if err := ctx.Err(); err != nil {
				break
			}
		}
		currentTime := now()
		if !currentTime.Before(deadline) {
			break
		}
		readDeadline := currentTime.Add(upgradePacketDrainIdleWait)
		if readDeadline.After(deadline) {
			readDeadline = deadline
		}
		_ = conn.SetReadDeadline(readDeadline)
		if _, _, err := conn.ReadFrom(buf); err != nil {
			break
		}
	}
	_ = conn.SetReadDeadline(time.Time{})
}

type commitAwaitResult struct {
	frame controlFrameReadResult
	err   error
}

func (a directUpgradeAttempt) newOwnedTransportBudgetContext(ctx context.Context) (context.Context, context.CancelFunc) {
	return context.WithTimeout(ctx, a.cfg.probeTimeout)
}

func ownedTransportNotConvergedError(err error) error {
	if err == nil {
		return ErrUpgradeTransportNotConverged
	}
	if errors.Is(err, ErrUpgradeTransportNotConverged) {
		return err
	}
	return errors.Join(ErrUpgradeTransportNotConverged, err)
}

func relayFallbackResult(stream io.ReadWriteCloser, reason UpgradeFallbackReason) UpgradeResult {
	return UpgradeResult{
		Stream:         stream,
		Path:           UpgradePathRelay,
		FallbackReason: reason,
	}
}

func writeFull(writer io.Writer, data []byte) error {
	for len(data) > 0 {
		n, err := writer.Write(data)
		if err != nil {
			return err
		}
		data = data[n:]
		if n == 0 {
			return io.ErrShortWrite
		}
	}
	return nil
}

type localOfferResult struct {
	offer localUpgradeOffer
}

func (a directUpgradeAttempt) localOffer(ctx context.Context, session Session, candidates []Candidate, probeNonce []byte) (localUpgradeOffer, error) {
	done := make(chan localOfferResult)
	go func() {
		handshakeMaterial := append([]byte{}, session.HandshakeMaterial()...)
		result := localOfferResult{
			offer: localUpgradeOffer{
				transportName:     a.cfg.transport.Name(),
				handshakeMaterial: handshakeMaterial,
				probeNonce:        append([]byte(nil), probeNonce...),
				candidates:        append([]Candidate(nil), candidates...),
				role:              a.role(),
				// Local capability: a non-nil validated TURN allocator, whose
				// exact built-in transport eligibility config validation
				// already enforced.
				turnRetry: a.cfg.turnAllocator != nil,
			},
		}
		select {
		case done <- result:
		case <-ctx.Done():
		}
	}()

	select {
	case result := <-done:
		if ctxErr := ctx.Err(); ctxErr != nil {
			return localUpgradeOffer{}, ctxErr
		}
		return result.offer, nil
	case <-ctx.Done():
		return localUpgradeOffer{}, ctx.Err()
	}
}

func (a directUpgradeAttempt) role() upgradeRole {
	return assignUpgradeRole(a.keyOrientation)
}

func assignUpgradeRole(orientation DirectionalKeyOrientation) upgradeRole {
	if orientation == DirectionalKeyOrientationSendHashGreater {
		return upgradeRoleDial
	}
	return upgradeRoleListen
}
