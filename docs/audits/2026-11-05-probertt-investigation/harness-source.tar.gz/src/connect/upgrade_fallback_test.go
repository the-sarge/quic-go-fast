package connect

import (
	"context"
	"errors"
	"reflect"
	"testing"
)

func allFallbackReasonDefinitions() []fallbackReasonDefinition {
	return append([]fallbackReasonDefinition(nil), fallbackReasonDefinitions...)
}

func TestFallbackReasonRegistryMirrorsPRDAndPhasePrecedence(t *testing.T) {
	got := allFallbackReasonDefinitions()
	want := []fallbackReasonDefinition{
		{
			value:          UpgradeFallbackNotRequested,
			wire:           1,
			phase:          fallbackReasonPhaseFirst,
			precedenceRank: 1,
		},
		{
			value:          UpgradeFallbackPolicyExcluded,
			wire:           2,
			phase:          fallbackReasonPhaseFirst | fallbackReasonPhaseTerminal | fallbackReasonPhaseRetryTerminal,
			precedenceRank: 3,
		},
		{
			value:          UpgradeFallbackNoCandidates,
			wire:           3,
			phase:          fallbackReasonPhaseFirst,
			precedenceRank: 4,
		},
		{
			value:          UpgradeFallbackTransportMismatch,
			wire:           4,
			phase:          fallbackReasonPhaseTerminal,
			precedenceRank: 2,
		},
		{
			value:          UpgradeFallbackProtocolMismatch,
			wire:           5,
			phase:          fallbackReasonPhaseFirst | fallbackReasonPhaseTerminal | fallbackReasonPhaseRetryTerminal,
			precedenceRank: 0,
		},
		{
			value:          UpgradeFallbackProbeFailed,
			wire:           6,
			phase:          fallbackReasonPhaseTerminal | fallbackReasonPhaseRetryTerminal,
			precedenceRank: 6,
		},
		{
			value:          UpgradeFallbackTransportFailed,
			wire:           7,
			phase:          fallbackReasonPhaseFirst | fallbackReasonPhaseTerminal,
			precedenceRank: 5,
		},
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("fallback reason registry = %#v, want %#v", got, want)
	}
}

func TestFallbackReasonRetryTerminalMembership(t *testing.T) {
	const allPhases = fallbackReasonPhaseFirst | fallbackReasonPhaseTerminal | fallbackReasonPhaseRetryTerminal
	if allPhases != 0b111 {
		t.Fatalf("phase bit union = %#b, want exactly three distinct bits %#b", allPhases, 0b111)
	}
	for _, def := range allFallbackReasonDefinitions() {
		if extra := def.phase &^ allPhases; extra != 0 {
			t.Fatalf("fallback reason %q carries unknown phase bits %#b", def.value, extra)
		}
	}

	retryMembers := map[UpgradeFallbackReason]uint64{
		UpgradeFallbackPolicyExcluded:   2,
		UpgradeFallbackProtocolMismatch: 5,
		UpgradeFallbackProbeFailed:      6,
	}
	reasons := []UpgradeFallbackReason{
		UpgradeFallbackNone,
		UpgradeFallbackNotRequested,
		UpgradeFallbackPolicyExcluded,
		UpgradeFallbackNoCandidates,
		UpgradeFallbackTransportMismatch,
		UpgradeFallbackProtocolMismatch,
		UpgradeFallbackProbeFailed,
		UpgradeFallbackTransportFailed,
	}
	for _, reason := range reasons {
		wantWire, wantMember := retryMembers[reason]
		if got := validFallbackReasonForPhase(reason, fallbackReasonPhaseRetryTerminal); got != wantMember {
			t.Fatalf("validFallbackReasonForPhase(%q, retry-terminal) = %t, want %t", reason, got, wantMember)
		}
		wire, ok := fallbackReasonToWireForPhase(reason, fallbackReasonPhaseRetryTerminal)
		if ok != wantMember || wire != wantWire {
			t.Fatalf("fallbackReasonToWireForPhase(%q, retry-terminal) = (%d, %t), want (%d, %t)", reason, wire, ok, wantWire, wantMember)
		}
	}
	wantByWire := map[uint64]UpgradeFallbackReason{}
	for reason, wire := range retryMembers {
		wantByWire[wire] = reason
	}
	for wire := range uint64(9) {
		wantReason, wantMember := wantByWire[wire]
		reason, ok := fallbackReasonFromWireForPhase(wire, fallbackReasonPhaseRetryTerminal)
		if ok != wantMember || reason != wantReason {
			t.Fatalf("fallbackReasonFromWireForPhase(%d, retry-terminal) = (%q, %t), want (%q, %t)", wire, reason, ok, wantReason, wantMember)
		}
	}

	// The lookups are phase-scoped, not retry-specific: the direct terminal
	// phase admits transport_mismatch (4) and the first phase does not.
	if wire, ok := fallbackReasonToWireForPhase(UpgradeFallbackTransportMismatch, fallbackReasonPhaseTerminal); !ok || wire != 4 {
		t.Fatalf("fallbackReasonToWireForPhase(transport_mismatch, terminal) = (%d, %t), want (4, true)", wire, ok)
	}
	if reason, ok := fallbackReasonFromWireForPhase(4, fallbackReasonPhaseFirst); ok {
		t.Fatalf("fallbackReasonFromWireForPhase(4, first) = (%q, true), want rejected", reason)
	}
}

func TestFallbackReasonFirstPhasePrecedenceMatrix(t *testing.T) {
	reasons := []UpgradeFallbackReason{
		UpgradeFallbackNotRequested,
		UpgradeFallbackPolicyExcluded,
		UpgradeFallbackNoCandidates,
		UpgradeFallbackTransportMismatch,
		UpgradeFallbackProtocolMismatch,
		UpgradeFallbackProbeFailed,
		UpgradeFallbackTransportFailed,
	}
	want := [][]UpgradeFallbackReason{
		{
			UpgradeFallbackNotRequested,
			UpgradeFallbackNotRequested,
			UpgradeFallbackNotRequested,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackNotRequested,
		},
		{
			UpgradeFallbackNotRequested,
			UpgradeFallbackPolicyExcluded,
			UpgradeFallbackPolicyExcluded,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackPolicyExcluded,
		},
		{
			UpgradeFallbackNotRequested,
			UpgradeFallbackPolicyExcluded,
			UpgradeFallbackNoCandidates,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackNoCandidates,
		},
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
		},
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
		},
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
		},
		{
			UpgradeFallbackNotRequested,
			UpgradeFallbackPolicyExcluded,
			UpgradeFallbackNoCandidates,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackTransportFailed,
		},
	}

	assertFallbackReasonPrecedenceMatrix(t, fallbackReasonPhaseFirst, reasons, want)
}

func TestFallbackReasonTerminalPrecedenceMatrix(t *testing.T) {
	reasons := []UpgradeFallbackReason{
		UpgradeFallbackNotRequested,
		UpgradeFallbackPolicyExcluded,
		UpgradeFallbackNoCandidates,
		UpgradeFallbackTransportMismatch,
		UpgradeFallbackProtocolMismatch,
		UpgradeFallbackProbeFailed,
		UpgradeFallbackTransportFailed,
	}
	want := [][]UpgradeFallbackReason{
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
		},
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackPolicyExcluded,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackTransportMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackPolicyExcluded,
			UpgradeFallbackPolicyExcluded,
		},
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
		},
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackTransportMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackTransportMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackTransportMismatch,
			UpgradeFallbackTransportMismatch,
		},
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProtocolMismatch,
		},
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackPolicyExcluded,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackTransportMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackProbeFailed,
			UpgradeFallbackTransportFailed,
		},
		{
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackPolicyExcluded,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackTransportMismatch,
			UpgradeFallbackProtocolMismatch,
			UpgradeFallbackTransportFailed,
			UpgradeFallbackTransportFailed,
		},
	}

	assertFallbackReasonPrecedenceMatrix(t, fallbackReasonPhaseTerminal, reasons, want)
}

func assertFallbackReasonPrecedenceMatrix(
	t *testing.T,
	phase fallbackReasonPhase,
	reasons []UpgradeFallbackReason,
	want [][]UpgradeFallbackReason,
) {
	t.Helper()
	if len(want) != len(reasons) {
		t.Fatalf("precedence matrix has %d rows, want %d", len(want), len(reasons))
	}
	for i, local := range reasons {
		if len(want[i]) != len(reasons) {
			t.Fatalf("precedence matrix row %d has %d columns, want %d", i, len(want[i]), len(reasons))
		}
		for j, peer := range reasons {
			got := resolveFallbackReason(phase, local, peer)
			if got != want[i][j] {
				t.Fatalf("Resolve(%d, local=%q, peer=%q) = %q, want %q", phase, local, peer, got, want[i][j])
			}
		}
	}
}

func TestFallbackReasonPhaseValidity(t *testing.T) {
	tests := []struct {
		reason     UpgradeFallbackReason
		firstPhase bool
		terminal   bool
	}{
		{
			reason:     UpgradeFallbackNotRequested,
			firstPhase: true,
		},
		{
			reason:     UpgradeFallbackPolicyExcluded,
			firstPhase: true,
			terminal:   true,
		},
		{
			reason:     UpgradeFallbackNoCandidates,
			firstPhase: true,
		},
		{
			reason:   UpgradeFallbackTransportMismatch,
			terminal: true,
		},
		{
			reason:     UpgradeFallbackProtocolMismatch,
			firstPhase: true,
			terminal:   true,
		},
		{
			reason:   UpgradeFallbackProbeFailed,
			terminal: true,
		},
		{
			reason:     UpgradeFallbackTransportFailed,
			firstPhase: true,
			terminal:   true,
		},
	}

	for _, tt := range tests {
		t.Run(string(tt.reason), func(t *testing.T) {
			if got := validFallbackReasonForPhase(tt.reason, fallbackReasonPhaseFirst); got != tt.firstPhase {
				t.Fatalf("ValidForPhase(%q, first) = %t, want %t", tt.reason, got, tt.firstPhase)
			}
			if got := validFallbackReasonForPhase(tt.reason, fallbackReasonPhaseTerminal); got != tt.terminal {
				t.Fatalf("ValidForPhase(%q, terminal) = %t, want %t", tt.reason, got, tt.terminal)
			}
		})
	}
}

func TestFirstPhasePeerFallbackReason(t *testing.T) {
	tests := []struct {
		name string
		peer UpgradeFallbackReason
		want UpgradeFallbackReason
	}{
		{
			name: "not requested",
			peer: UpgradeFallbackNotRequested,
			want: UpgradeFallbackNotRequested,
		},
		{
			name: "policy excluded",
			peer: UpgradeFallbackPolicyExcluded,
			want: UpgradeFallbackPolicyExcluded,
		},
		{
			name: "no candidates",
			peer: UpgradeFallbackNoCandidates,
			want: UpgradeFallbackNoCandidates,
		},
		{
			name: "protocol mismatch",
			peer: UpgradeFallbackProtocolMismatch,
			want: UpgradeFallbackProtocolMismatch,
		},
		{
			name: "transport failed",
			peer: UpgradeFallbackTransportFailed,
			want: UpgradeFallbackTransportFailed,
		},
		{
			name: "terminal transport mismatch",
			peer: UpgradeFallbackTransportMismatch,
			want: UpgradeFallbackProtocolMismatch,
		},
		{
			name: "terminal probe failed",
			peer: UpgradeFallbackProbeFailed,
			want: UpgradeFallbackProtocolMismatch,
		},
		{
			name: "none sentinel",
			peer: UpgradeFallbackNone,
			want: UpgradeFallbackProtocolMismatch,
		},
		{
			name: "unknown",
			peer: "unknown",
			want: UpgradeFallbackProtocolMismatch,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := firstPhasePeerFallbackReason(tt.peer); got != tt.want {
				t.Fatalf("firstPhasePeerFallbackReason(%q) = %q, want %q", tt.peer, got, tt.want)
			}
		})
	}
}

func TestFallbackReasonUnknownValuesResolveToProtocolMismatch(t *testing.T) {
	tests := []struct {
		name  string
		phase fallbackReasonPhase
		local UpgradeFallbackReason
		peer  UpgradeFallbackReason
	}{
		{
			name:  "unknown local first phase",
			phase: fallbackReasonPhaseFirst,
			local: "unknown",
			peer:  UpgradeFallbackNotRequested,
		},
		{
			name:  "unknown peer first phase",
			phase: fallbackReasonPhaseFirst,
			local: UpgradeFallbackNotRequested,
			peer:  "unknown",
		},
		{
			name:  "unknown local terminal",
			phase: fallbackReasonPhaseTerminal,
			local: "unknown",
			peer:  UpgradeFallbackProbeFailed,
		},
		{
			name:  "unknown peer terminal",
			phase: fallbackReasonPhaseTerminal,
			local: UpgradeFallbackProbeFailed,
			peer:  "unknown",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := resolveFallbackReason(tt.phase, tt.local, tt.peer)
			if got != UpgradeFallbackProtocolMismatch {
				t.Fatalf("Resolve(%d, local=%q, peer=%q) = %q, want %q", tt.phase, tt.local, tt.peer, got, UpgradeFallbackProtocolMismatch)
			}
		})
	}
}

func TestFallbackReasonWireRoundTrip(t *testing.T) {
	tests := []struct {
		reason UpgradeFallbackReason
		wire   uint64
	}{
		{reason: UpgradeFallbackNotRequested, wire: 1},
		{reason: UpgradeFallbackPolicyExcluded, wire: 2},
		{reason: UpgradeFallbackNoCandidates, wire: 3},
		{reason: UpgradeFallbackTransportMismatch, wire: 4},
		{reason: UpgradeFallbackProtocolMismatch, wire: 5},
		{reason: UpgradeFallbackProbeFailed, wire: 6},
		{reason: UpgradeFallbackTransportFailed, wire: 7},
	}

	for _, tt := range tests {
		t.Run(string(tt.reason), func(t *testing.T) {
			wire, err := fallbackReasonToWire(tt.reason)
			if err != nil {
				t.Fatalf("fallbackReasonToWire(%q): %v", tt.reason, err)
			}
			if wire != tt.wire {
				t.Fatalf("fallbackReasonToWire(%q) = %d, want %d", tt.reason, wire, tt.wire)
			}
			reason, ok := fallbackReasonFromWireValue(tt.wire)
			if !ok {
				t.Fatalf("fallbackReasonFromWireValue(%d) was not registered", tt.wire)
			}
			if reason != tt.reason {
				t.Fatalf("fallbackReasonFromWireValue(%d) = %q, want %q", tt.wire, reason, tt.reason)
			}
		})
	}
}

func TestFallbackReasonUnknownWireValueIsUnregistered(t *testing.T) {
	reason, ok := fallbackReasonFromWireValue(99)
	if ok {
		t.Fatalf("fallbackReasonFromWireValue(99) = (%q, true), want unregistered", reason)
	}
}

func TestResolveFallbackReasonFirstPhaseConvergesSymmetrically(t *testing.T) {
	tests := []struct {
		name string
		a    UpgradeFallbackReason
		b    UpgradeFallbackReason
		want UpgradeFallbackReason
	}{
		{
			name: "not requested beats no candidates",
			a:    UpgradeFallbackNotRequested,
			b:    UpgradeFallbackNoCandidates,
			want: UpgradeFallbackNotRequested,
		},
		{
			name: "policy excluded beats transport failed",
			a:    UpgradeFallbackPolicyExcluded,
			b:    UpgradeFallbackTransportFailed,
			want: UpgradeFallbackPolicyExcluded,
		},
		{
			name: "no candidates beats transport failed",
			a:    UpgradeFallbackNoCandidates,
			b:    UpgradeFallbackTransportFailed,
			want: UpgradeFallbackNoCandidates,
		},
		{
			name: "protocol mismatch beats not requested",
			a:    UpgradeFallbackProtocolMismatch,
			b:    UpgradeFallbackNotRequested,
			want: UpgradeFallbackProtocolMismatch,
		},
		{
			name: "terminal-only probe failed is protocol mismatch",
			a:    UpgradeFallbackNotRequested,
			b:    UpgradeFallbackProbeFailed,
			want: UpgradeFallbackProtocolMismatch,
		},
		{
			name: "none is protocol mismatch",
			a:    UpgradeFallbackNone,
			b:    UpgradeFallbackNoCandidates,
			want: UpgradeFallbackProtocolMismatch,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotAB := resolveFallbackReason(fallbackReasonPhaseFirst, tt.a, tt.b)
			gotBA := resolveFallbackReason(fallbackReasonPhaseFirst, tt.b, tt.a)
			if gotAB != tt.want {
				t.Fatalf("resolveFallbackReason(first, %q, %q) = %q, want %q", tt.a, tt.b, gotAB, tt.want)
			}
			if gotBA != tt.want {
				t.Fatalf("resolveFallbackReason(first, %q, %q) = %q, want %q", tt.b, tt.a, gotBA, tt.want)
			}
		})
	}
}

func TestResolveFallbackReasonTerminalConvergesSymmetrically(t *testing.T) {
	tests := []struct {
		name string
		a    UpgradeFallbackReason
		b    UpgradeFallbackReason
		want UpgradeFallbackReason
	}{
		{
			name: "transport mismatch beats policy excluded",
			a:    UpgradeFallbackTransportMismatch,
			b:    UpgradeFallbackPolicyExcluded,
			want: UpgradeFallbackTransportMismatch,
		},
		{
			name: "policy excluded beats probe failed",
			a:    UpgradeFallbackPolicyExcluded,
			b:    UpgradeFallbackProbeFailed,
			want: UpgradeFallbackPolicyExcluded,
		},
		{
			name: "transport failed beats probe failed",
			a:    UpgradeFallbackTransportFailed,
			b:    UpgradeFallbackProbeFailed,
			want: UpgradeFallbackTransportFailed,
		},
		{
			name: "protocol mismatch beats transport mismatch",
			a:    UpgradeFallbackProtocolMismatch,
			b:    UpgradeFallbackTransportMismatch,
			want: UpgradeFallbackProtocolMismatch,
		},
		{
			name: "first-phase-only no candidates is protocol mismatch",
			a:    UpgradeFallbackNoCandidates,
			b:    UpgradeFallbackProbeFailed,
			want: UpgradeFallbackProtocolMismatch,
		},
		{
			name: "none is protocol mismatch",
			a:    UpgradeFallbackNone,
			b:    UpgradeFallbackProbeFailed,
			want: UpgradeFallbackProtocolMismatch,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotAB := resolveFallbackReason(fallbackReasonPhaseTerminal, tt.a, tt.b)
			gotBA := resolveFallbackReason(fallbackReasonPhaseTerminal, tt.b, tt.a)
			if gotAB != tt.want {
				t.Fatalf("resolveFallbackReason(terminal, %q, %q) = %q, want %q", tt.a, tt.b, gotAB, tt.want)
			}
			if gotBA != tt.want {
				t.Fatalf("resolveFallbackReason(terminal, %q, %q) = %q, want %q", tt.b, tt.a, gotBA, tt.want)
			}
		})
	}
}

func TestFallbackReasonPhaseMembershipCoversCodecWireMapping(t *testing.T) {
	for _, def := range allFallbackReasonDefinitions() {
		reason, ok := fallbackReasonFromWireValue(def.wire)
		if !ok {
			t.Fatalf("fallback wire reason %d did not map to a domain reason", def.wire)
		}
		if got, err := fallbackReasonToWire(reason); err != nil || got != def.wire {
			t.Fatalf("fallback codec round-trip for wire reason %d = (%d, %v), want %d", def.wire, got, err, def.wire)
		}
		if !validFirstPhaseFallbackReason(reason) && !validTerminalFallbackReason(reason) {
			t.Fatalf("wire fallback reason %d maps to %q, which is in no phase membership set", def.wire, reason)
		}
	}
}

func TestFallbackReasonNoneIsNoFallbackSentinel(t *testing.T) {
	if UpgradeFallbackNone != "" {
		t.Fatalf("none fallback reason = %q, want empty string", UpgradeFallbackNone)
	}
	if _, ok := lookupFallbackReason(UpgradeFallbackNone); ok {
		t.Fatal("none fallback reason is registered")
	}
	if validFirstPhaseFallbackReason(UpgradeFallbackNone) {
		t.Fatal("none fallback reason is valid for first-phase fallback")
	}
	if validTerminalFallbackReason(UpgradeFallbackNone) {
		t.Fatal("none fallback reason is valid for terminal fallback")
	}
	if _, err := fallbackReasonToWire(UpgradeFallbackNone); err == nil {
		t.Fatal("none fallback reason has a wire code")
	}
}

func TestFallbackReasonRegistryEntriesAreUniqueAndUsable(t *testing.T) {
	values := map[string]struct{}{}
	wires := map[uint64]struct{}{}
	precedenceRanks := map[int]struct{}{}
	for _, def := range allFallbackReasonDefinitions() {
		if def.value == "" {
			t.Fatal("fallback reason registry contains empty public reason")
		}
		if _, ok := values[string(def.value)]; ok {
			t.Fatalf("fallback reason registry contains duplicate public reason %q", def.value)
		}
		values[string(def.value)] = struct{}{}
		if def.wire == 0 {
			t.Fatalf("fallback reason %q has zero wire value", def.value)
		}
		if _, ok := wires[def.wire]; ok {
			t.Fatalf("fallback reason registry contains duplicate wire value %d", def.wire)
		}
		wires[def.wire] = struct{}{}
		if def.phase == 0 {
			t.Fatalf("fallback reason %q belongs to no phase", def.value)
		}
		if _, ok := precedenceRanks[def.precedenceRank]; ok {
			t.Fatalf("fallback reason registry contains duplicate precedence rank %d", def.precedenceRank)
		}
		precedenceRanks[def.precedenceRank] = struct{}{}
	}
}

func TestLocalReasonAfterPeerTerminalFallbackPreservesIndependentOutcome(t *testing.T) {
	tests := []struct {
		name    string
		peer    UpgradeFallbackReason
		outcome probeCandidatePairsOutcome
		want    UpgradeFallbackReason
	}{
		{
			name: "probe canceled by peer fallback echoes peer reason",
			peer: UpgradeFallbackProbeFailed,
			outcome: probeCandidatePairsOutcome{
				err: context.Canceled,
			},
			want: UpgradeFallbackProbeFailed,
		},
		{
			name: "independent local fallback is preserved",
			peer: UpgradeFallbackProbeFailed,
			outcome: probeCandidatePairsOutcome{
				result: candidatePairProbeResult{fallback: UpgradeFallbackTransportFailed},
			},
			want: UpgradeFallbackTransportFailed,
		},
		{
			name: "local success uses current terminal handoff fallback reason",
			peer: UpgradeFallbackProbeFailed,
			outcome: probeCandidatePairsOutcome{
				result: candidatePairProbeResult{succeeded: true},
			},
			want: UpgradeFallbackTransportFailed,
		},
		{
			name: "hard local probe error maps to transport failed",
			peer: UpgradeFallbackProbeFailed,
			outcome: probeCandidatePairsOutcome{
				err: errors.New("probe failed"),
			},
			want: UpgradeFallbackTransportFailed,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := localReasonAfterPeerTerminalFallback(tt.peer, tt.outcome)
			if got != tt.want {
				t.Fatalf("localReasonAfterPeerTerminalFallback(%q, %#v) = %q, want %q", tt.peer, tt.outcome, got, tt.want)
			}
		})
	}
}
