package connect

import (
	"context"
	"errors"
	"sync"
	"time"

	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// errInvalidTurnRetryDialectEntry classifies a post-Start frame that is none
// of the three canonical retry-entry shapes: a retry Offer, a retry Fallback,
// or a canonical late v1 terminal Fallback. The dialer selects no wire
// dialect, cleans up locally, terminates control, and returns this error;
// it never guesses a fallback dialect or claims reliable-fallback success.
var errInvalidTurnRetryDialectEntry = errors.New("connect: invalid turn-retry dialect-entry frame")

// turnRetryBilateralCapability is the exact bilateral predicate: local
// capability advertised in this peer's authenticated v1 Offer and canonical
// wiremux.turn-retry/1:true present in the authenticated peer Offer. Retry
// Start and allocation are forbidden until it is true.
func turnRetryBilateralCapability(local, peer localUpgradeOffer) bool {
	return local.turnRetry && peer.turnRetry
}

// turnRetryRelayKindExcluded evaluates this role's relay-kind exclusion: the
// dialer applies it before Retry Start and the listener after authenticated
// Start receipt, before its local allocation. Interface exclusion stays
// direct-only because a relay allocation has no authoritative originating
// interface name.
func turnRetryRelayKindExcluded(policy CandidatePolicy) bool {
	return candidateKindMatches(CandidateKindRelay, policy.ExcludeKinds)
}

// turnRetryAllocationOutcome is one Allocate result. Any non-nil conn is
// caller-owned even when err is non-nil and must be closed exactly once.
type turnRetryAllocationOutcome struct {
	conn RelayPacketConn
	err  error
}

// turnRetryAllocation tracks this role's single in-flight Allocate call. Each
// role invokes its allocator at most once per Upgrade; the single Start call
// site per role engine enforces that cardinality structurally.
type turnRetryAllocation struct {
	done      chan turnRetryAllocationOutcome
	closeOnce sync.Once
}

func startTurnRetryAllocation(ctx context.Context, allocator RelayPacketAllocator) *turnRetryAllocation {
	allocation := &turnRetryAllocation{done: make(chan turnRetryAllocationOutcome, 1)}
	go func() {
		conn, err := allocator.Allocate(ctx)
		allocation.done <- turnRetryAllocationOutcome{conn: conn, err: err}
	}()
	return allocation
}

// join awaits the Allocate return. An in-flight Allocate is exempt from the
// disposal-before-join terminal ordering: no composite exists until it
// returns, and the allocator contract guarantees prompt joined return after
// cancellation.
func (a *turnRetryAllocation) join() turnRetryAllocationOutcome {
	outcome := <-a.done
	// Re-buffer so repeated joins on distinct cleanup paths observe the same
	// outcome instead of blocking forever.
	a.done <- outcome
	return outcome
}

// dispose joins the single Allocate call and closes any non-nil result
// exactly once through its contractual Close, waiting for that Close to
// return. A completed result's disposal is itself the Close invocation, so no
// composite-dependent join precedes it.
func (a *turnRetryAllocation) dispose() {
	outcome := a.join()
	if outcome.conn != nil {
		a.closeOnce.Do(func() { _ = outcome.conn.Close() })
	}
}

type turnRetryEntryFrameKind uint8

const (
	turnRetryEntryInvalid turnRetryEntryFrameKind = iota
	turnRetryEntryOffer
	turnRetryEntryFallback
	turnRetryEntryV1Fallback
)

type turnRetryEntryFrame struct {
	kind     turnRetryEntryFrameKind
	offer    turnRetryOffer
	fallback turnRetryFallback
	v1Reason UpgradeFallbackReason
}

// classifyTurnRetryEntryFrame recognizes exactly the three canonical disjoint
// post-Start frame shapes. The retry profile's 8192-byte maximum is owned by
// the retry decoder (decodeTurnRetryCommonFields) and applies before any retry
// semantics; the canonical v1 Fallback shape is exactly three uint fields and
// cannot exceed it, so no caller-side length check is needed here.
func classifyTurnRetryEntryFrame(payload []byte) turnRetryEntryFrame {
	if offer, ok := decodeTurnRetryOffer(payload); ok {
		return turnRetryEntryFrame{kind: turnRetryEntryOffer, offer: offer}
	}
	if fallback, ok := decodeTurnRetryFallback(payload); ok {
		return turnRetryEntryFrame{kind: turnRetryEntryFallback, fallback: fallback}
	}
	if reason, ok := decodeCanonicalV1TerminalFallback(payload); ok {
		return turnRetryEntryFrame{kind: turnRetryEntryV1Fallback, v1Reason: reason}
	}
	return turnRetryEntryFrame{kind: turnRetryEntryInvalid}
}

// decodeCanonicalV1TerminalFallback accepts exactly the frame the v1 encoder
// produces for a terminal Fallback: fields {type, version, reason} with a
// wire reason valid in the terminal phase. Anything looser stays owned by the
// lenient v1 decoder outside the retry-entry transition.
func decodeCanonicalV1TerminalFallback(payload []byte) (UpgradeFallbackReason, bool) {
	fields, ok := decodeTopLevelMap(payload)
	if !ok {
		return UpgradeFallbackNone, false
	}
	fieldValues, messageType, ok := decodeCommonFields(fields)
	if !ok || messageType != upgradeControlMessageFallback {
		return UpgradeFallbackNone, false
	}
	if len(fieldValues) != 3 {
		return UpgradeFallbackNone, false
	}
	reasonPayload, ok := fieldValues[upgradeControlKeyFallbackReason]
	if !ok {
		return UpgradeFallbackNone, false
	}
	wire, ok := decodeUint(reasonPayload)
	if !ok {
		return UpgradeFallbackNone, false
	}
	reason, ok := fallbackReasonFromWireValue(wire)
	if !ok || !validTerminalFallbackReason(reason) {
		return UpgradeFallbackNone, false
	}
	return reason, true
}

// runTurnRetryDialer is the dialer retry decision authority. It runs only
// after the dialer joined its own direct probe_failed under bilateral
// capability: it evaluates local relay-kind exclusion before Start and either
// enters the existing v1 terminal Fallback exchange with policy_excluded and
// zero allocator calls, or sends Retry Start and begins its configured
// retry-timeout budget.
func (a directUpgradeAttempt) runTurnRetryDialer(
	ctx context.Context,
	session Session,
	terminalFallback terminalFallbackExchange,
	local localUpgradeOffer,
	peer localUpgradeOffer,
) (UpgradeResult, error) {
	if turnRetryRelayKindExcluded(a.cfg.candidatePolicy) {
		return terminalFallback.withSessionCleanup(ctx, session, UpgradeFallbackPolicyExcluded)
	}
	return a.runTurnRetryDialerEntry(ctx, session, terminalFallback, local, peer)
}

// runTurnRetryDialerEntry sends Retry Start and owns the explicit retry-entry
// transition: the dialer may allocate but emits no retry Offer or Fallback
// until the listener selects the dialect through exactly one of a late v1
// Fallback, a retry Offer, or a retry Fallback.
func (a directUpgradeAttempt) runTurnRetryDialerEntry(
	ctx context.Context,
	session Session,
	terminalFallback terminalFallbackExchange,
	local localUpgradeOffer,
	peer localUpgradeOffer,
) (UpgradeResult, error) {
	resources := a.resources()
	startFrame, err := encodeTurnRetryStart()
	if err != nil {
		return resources.failClosed(err, retainForOuterSettlement)
	}
	if err := a.writeUpgradeControlFrame(ctx, startFrame); err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return resources.failClosed(ctxErr, abortBeforeOwnedResources)
		}
		return resources.failClosed(err, abortBeforeOwnedResources)
	}

	// The dialer's role-local retry budget starts at Start send and covers its
	// allocation, both retry offers, peer preparation, and the retry probe.
	retryCtx, cancelRetry := context.WithTimeout(ctx, a.cfg.turnRetryTimeout)
	defer cancelRetry()
	allocation := startTurnRetryAllocation(retryCtx, a.cfg.turnAllocator)

	for {
		frame, err := a.controlFrames.recv(ctx, a.cfg.controlTimeout)
		if err != nil {
			// Control-transition expiry, framing failure, or outer-context
			// termination selects no dialect and returns its existing error.
			return a.failTurnRetryEntry(ctx, cancelRetry, allocation, err)
		}
		entry := classifyTurnRetryEntryFrame(frame.payload)
		switch entry.kind {
		case turnRetryEntryOffer:
			return a.runTurnRetryDialerSelected(ctx, retryCtx, cancelRetry, session, allocation, local, peer, entry.offer)
		case turnRetryEntryFallback:
			return a.runTurnRetryDialerPeerFallback(ctx, retryCtx, cancelRetry, allocation, entry.fallback)
		case turnRetryEntryV1Fallback:
			// A canonical late v1 Fallback selects v1: cancel retry work, close
			// any owned allocation before awaiting those joins, discard
			// retry-only dispositions, and complete the v1 exchange with the
			// original direct probe_failed.
			cancelRetry()
			allocation.dispose()
			peerFallback := &terminalFallbackReadResult{peer: upgradeControlFallback{Reason: entry.v1Reason}}
			return terminalFallback.withSessionCleanupUsingPeerFallback(ctx, session, UpgradeFallbackProbeFailed, peerFallback)
		default:
			return a.failTurnRetryEntry(ctx, cancelRetry, allocation, errInvalidTurnRetryDialectEntry)
		}
	}
}

// failTurnRetryEntry is the no-dialect termination: cancel retry work, invoke
// Close on any owned allocation before awaiting further joins, terminate
// control, and return the existing control/protocol error without claiming
// reliable-fallback success.
func (a directUpgradeAttempt) failTurnRetryEntry(
	ctx context.Context,
	cancelRetry context.CancelFunc,
	allocation *turnRetryAllocation,
	cause error,
) (UpgradeResult, error) {
	cancelRetry()
	allocation.dispose()
	if ctxErr := ctx.Err(); ctxErr != nil {
		return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
	}
	return a.resources().failClosed(turnRetryStageError(turnRetryStageDialectEntry, cause), abortBeforeOwnedResources)
}

// runTurnRetryDialerSelected handles the listener's retry Offer selecting the
// retry dialect. A dialer whose retry deadline expired before selection
// recorded probe_failed without emission; that recorded disposition now
// resolves through the bidirectional retry Fallback exchange with code 6.
func (a directUpgradeAttempt) runTurnRetryDialerSelected(
	ctx context.Context,
	retryCtx context.Context,
	cancelRetry context.CancelFunc,
	session Session,
	allocation *turnRetryAllocation,
	local localUpgradeOffer,
	peer localUpgradeOffer,
	peerOffer turnRetryOffer,
) (UpgradeResult, error) {
	if retryCtx.Err() != nil {
		cancelRetry()
		return a.turnRetryTerminalFallbackExchange(ctx, turnRetryStageDialectEntry, UpgradeFallbackProbeFailed, UpgradeFallbackProbeFailed, allocation.dispose)
	}
	return a.runTurnRetryDialerEngine(ctx, retryCtx, cancelRetry, session, allocation, local, peer, peerOffer)
}

// runTurnRetryDialerEngine continues the selected retry dialect through the
// retry engine.
func (a directUpgradeAttempt) runTurnRetryDialerEngine(
	ctx context.Context,
	retryCtx context.Context,
	cancelRetry context.CancelFunc,
	session Session,
	allocation *turnRetryAllocation,
	local localUpgradeOffer,
	peer localUpgradeOffer,
	peerOffer turnRetryOffer,
) (UpgradeResult, error) {
	e := &turnRetryEngine{
		attempt:     a,
		session:     session,
		local:       local,
		peer:        peer,
		retryCtx:    retryCtx,
		cancelRetry: cancelRetry,
		stage:       turnRetryStageAllocation,
	}
	return e.runDialer(ctx, allocation, peerOffer)
}

// entry-stage disposition, if any: a retry-deadline expiry or an allocation
// failure that was not caused by preemptive cancellation. Every entry-stage
// disposition maps to retry code 6 while publicly preserving the original
// direct probe_failed. An operation-cancellation artifact never replaces the
// peer reason.
func turnRetryEntryLocalDisposition(retryCtx context.Context, outcome turnRetryAllocationOutcome) UpgradeFallbackReason {
	if errors.Is(retryCtx.Err(), context.DeadlineExceeded) {
		return UpgradeFallbackProbeFailed
	}
	if outcome.err != nil {
		if errors.Is(outcome.err, context.Canceled) {
			return UpgradeFallbackNone
		}
		return UpgradeFallbackProbeFailed
	}
	if outcome.conn == nil || !relayprofile.IsTURNQUIC3(outcome.conn) {
		return UpgradeFallbackProbeFailed
	}
	return UpgradeFallbackNone
}

// runTurnRetryDialerPeerFallback handles a listener retry Fallback selecting
// the retry dialect during the entry transition: the dialer cancels and joins
// its retry work, closes any owned allocation, and sends its independently
// reached code or echoes the authenticated peer reason.
func (a directUpgradeAttempt) runTurnRetryDialerPeerFallback(
	ctx context.Context,
	retryCtx context.Context,
	cancelRetry context.CancelFunc,
	allocation *turnRetryAllocation,
	peer turnRetryFallback,
) (UpgradeResult, error) {
	cancelRetry()
	outcome := allocation.join()
	local := turnRetryEntryLocalDisposition(retryCtx, outcome)
	allocation.dispose()
	return a.turnRetrySettlePreempted(ctx, turnRetryStageDialectEntry, local, peer.Reason)
}

// turnRetrySettlePreempted completes the bidirectional retry Fallback
// exchange for a role whose active work was preempted by an authenticated
// peer Fallback and whose local work is already canceled, disposed, and
// joined: it sends the independently reached local code or echoes the peer
// reason, then settles through the existing precedence owner. No preempted
// role sends UpgradeFallbackNone, and no operation-cancellation artifact
// replaces the peer reason. stage is the retry step the caller was in when
// preempted; it only labels retry-internal failure exits (issue #1270) and
// never changes settlement, which stays with the precedence owner.
func (a directUpgradeAttempt) turnRetrySettlePreempted(
	ctx context.Context,
	stage turnRetryStage,
	local UpgradeFallbackReason,
	peer UpgradeFallbackReason,
) (UpgradeResult, error) {
	outbound := local
	if outbound == UpgradeFallbackNone {
		outbound = peer
	}
	publicLocal := local
	if publicLocal == UpgradeFallbackNone {
		publicLocal = UpgradeFallbackProbeFailed
	}
	frame, err := encodeTurnRetryFallback(outbound)
	if err != nil {
		return a.resources().failClosed(turnRetryStageError(stage, err), retainForOuterSettlement)
	}
	if err := a.writeUpgradeControlFrame(ctx, frame); err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return a.resources().failClosed(ctxErr, abortBeforeOwnedResources)
		}
		return a.resources().failClosed(turnRetryStageError(stage, err), abortBeforeOwnedResources)
	}
	return a.resources().settleRelay(
		resolveFallbackReason(fallbackReasonPhaseRetryTerminal, publicLocal, peer),
	)
}

// turnRetryTerminalFallbackExchange is the bidirectional retry terminal
// exchange after retry-dialect selection: send the nonzero local coarse
// reason, await the authenticated peer reason under the independent control
// timeout, invoke composite disposal through dispose, and settle the
// synchronized reliable fallback through the existing precedence owner. A
// failed synchronization returns its existing control-error result labeled
// with the retry stage the caller was in when it entered the exchange, so a
// one-sided stall that dies here names the stalled step (issue #1218).
func (a directUpgradeAttempt) turnRetryTerminalFallbackExchange(
	ctx context.Context,
	stage turnRetryStage,
	outbound UpgradeFallbackReason,
	publicLocal UpgradeFallbackReason,
	dispose func(),
) (UpgradeResult, error) {
	resources := a.resources()
	frame, err := encodeTurnRetryFallback(outbound)
	if err != nil {
		dispose()
		return resources.failClosed(turnRetryStageError(stage, err), retainForOuterSettlement)
	}

	writeErr := make(chan error, 1)
	go func() {
		writeErr <- writeFull(a.channel, frame)
	}()
	var readDone chan controlFrameReadResult
	startRead := func() {
		if readDone != nil {
			return
		}
		readDone = make(chan controlFrameReadResult, 1)
		go func(done chan<- controlFrameReadResult) {
			result, err := a.controlFrames.recv(ctx, 0)
			done <- controlFrameReadResult{payload: result.payload, err: err}
		}(readDone)
	}

	timer := time.NewTimer(a.cfg.controlTimeout)
	defer timer.Stop()
	var (
		peerReason UpgradeFallbackReason
		sent       bool
		received   bool
	)
	for !sent || !received {
		if err := ctx.Err(); err != nil {
			dispose()
			return resources.failClosed(err, abortBeforeOwnedResources)
		}
		var pendingWrite <-chan error
		if !sent {
			pendingWrite = writeErr
		}
		var pendingRead <-chan controlFrameReadResult
		if !received {
			startRead()
			pendingRead = readDone
		}
		select {
		case err := <-pendingWrite:
			sent = true
			if err != nil {
				dispose()
				if ctxErr := ctx.Err(); ctxErr != nil {
					return resources.failClosed(ctxErr, abortBeforeOwnedResources)
				}
				return resources.failClosed(turnRetryStageError(stage, err), abortBeforeOwnedResources)
			}
		case result := <-pendingRead:
			readDone = nil
			if result.err != nil {
				dispose()
				if ctxErr := ctx.Err(); ctxErr != nil {
					return resources.failClosed(ctxErr, abortBeforeOwnedResources)
				}
				return resources.failClosed(turnRetryStageError(stage, result.err), abortBeforeOwnedResources)
			}
			if fallback, ok := decodeTurnRetryFallback(result.payload); ok {
				received = true
				peerReason = fallback.Reason
				continue
			}
			// A valid non-Fallback retry frame crossed our Fallback decision
			// in flight; skip it and keep awaiting the peer's Fallback.
			if isStaleTurnRetryFrame(result.payload) {
				continue
			}
			dispose()
			return resources.failClosed(turnRetryStageError(stage, errInvalidTurnRetryDialectEntry), abortBeforeOwnedResources)
		case <-ctx.Done():
			dispose()
			return resources.failClosed(ctx.Err(), abortBeforeOwnedResources)
		case <-timer.C:
			dispose()
			if ctxErr := ctx.Err(); ctxErr != nil {
				return resources.failClosed(ctxErr, abortBeforeOwnedResources)
			}
			return resources.failClosed(turnRetryStageError(stage, ErrUpgradeControlTimeout), abortBeforeOwnedResources)
		}
	}

	dispose()
	return resources.settleRelay(
		resolveFallbackReason(fallbackReasonPhaseRetryTerminal, publicLocal, peerReason),
	)
}
