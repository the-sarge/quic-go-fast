package connect

import (
	"context"
	"net"
	"testing"

	"github.com/GridSwarm/wiremux/internal/routeselection"
)

func TestSelectedGatherPerformsNoLiveInspection(t *testing.T) {
	interfaces, err := net.Interfaces()
	if err != nil {
		t.Fatal(err)
	}
	for _, iface := range interfaces {
		if iface.Flags&net.FlagLoopback == 0 || iface.Flags&net.FlagUp == 0 {
			continue
		}
		h, err := routeselection.Resolve(iface.Name)
		if err != nil {
			t.Fatal(err)
		}
		conn, binding, err := routeselection.ListenUDP(context.Background(), h)
		if err != nil {
			t.Fatal(err)
		}
		defer conn.Close()
		g := candidateGatherer{interfaces: func() ([]gatherInterface, error) {
			t.Error("selected gathering consulted live inventory")
			return nil, nil
		}}
		got, err := g.gatherCandidates(binding.Context(context.Background()), WithPacketConn(conn))
		if err != nil || len(got) != 1 {
			t.Fatalf("gather: got %v %v, want one bound candidate", got, err)
		}
		if got[0].localInterface != iface.Name {
			t.Fatalf("interface: got %q, want %q", got[0].localInterface, iface.Name)
		}
		return
	}
	t.Fatal("no loopback fixture")
}
