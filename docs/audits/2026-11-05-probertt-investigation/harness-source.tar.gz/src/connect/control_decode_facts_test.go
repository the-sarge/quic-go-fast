package connect

import (
	"bytes"
	"net/netip"
	"testing"
	"time"
)

func TestUpgradeControlDecodeRetainsPayloadCause(t *testing.T) {
	t.Run("malformed fallback retains legacy fields", func(t *testing.T) {
		// A fallback envelope with no reason is malformed, but still looks like
		// a wire fallback to legacy phase handling.
		got, cause := decodeUpgradeControlPhasePayload(mustHex(t, "a200020101"), upgradeControlPhaseReady)
		if !got.HasFallback || !got.WireFallback || got.FallbackReason != UpgradeFallbackProtocolMismatch {
			t.Fatalf("legacy fallback: got %+v, want wire protocol-mismatch fallback", got)
		}
		if cause != errMalformedUpgradeControl { //nolint:errorlint // The private decoder contract requires the exact sentinel.
			t.Fatalf("payload cause: got %v, want %v", cause, errMalformedUpgradeControl)
		}
	})
	t.Run("offer", func(t *testing.T) {
		got, cause := decodeUpgradeControlFirstPhasePayload(mustHex(t, "a6000101010a64717569630b4201020c582042424242424242424242424242424242424242424242424242424242424242420d81a20001014704c000020a3039"))
		if cause != nil || !got.HasOffer || got.HasFallback || got.Offer.transportName != "quic" ||
			!bytes.Equal(got.Offer.handshakeMaterial, []byte{1, 2}) || !bytes.Equal(got.Offer.probeNonce, bytes.Repeat([]byte{0x42}, 32)) ||
			len(got.Offer.candidates) != 1 || got.Offer.candidates[0].Kind != CandidateKindHost || got.Offer.candidates[0].Addr != netip.MustParseAddrPort("192.0.2.10:12345") {
			t.Fatalf("offer: got %+v, cause %v, want valid quic offer with original material and candidate", got, cause)
		}
	})
	t.Run("selected pair", func(t *testing.T) {
		got, cause := decodeUpgradeControlSelectedPairPhasePayload(mustHex(t, "a500030101181ea20001014704c000020a3039181fa20001014704c63364145ba018201a075bcd15"))
		want := selectedPair{
			dialer:   Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("192.0.2.10:12345")},
			listener: Candidate{Kind: CandidateKindHost, Addr: netip.MustParseAddrPort("198.51.100.20:23456")},
			rtt:      123456789 * time.Nanosecond,
		}
		if cause != nil || !got.HasSelectedPair || got.HasFallback || got.SelectedPair != want {
			t.Fatalf("selected pair: got %+v, cause %v, want %+v with nil cause", got, cause, want)
		}
	})
	t.Run("ready", func(t *testing.T) {
		got, cause := decodeUpgradeControlPhasePayload(mustHex(t, "a200040101"), upgradeControlPhaseReady)
		if cause != nil || !got.Is(upgradeControlPhaseReady) || got.Datagrams || got.HasFallback {
			t.Fatalf("phase: got %+v, cause %v, want ready with nil cause", got, cause)
		}
	})
	t.Run("fallback", func(t *testing.T) {
		got, cause := decodeUpgradeControlFallbackPayload(mustHex(t, "a3000201011402"))
		if cause != nil || got.Reason != UpgradeFallbackPolicyExcluded {
			t.Fatalf("fallback: got %+v, cause %v, want policy-excluded with nil cause", got, cause)
		}
	})
	t.Run("valid peer protocol mismatch", func(t *testing.T) {
		got, cause := decodeUpgradeControlPhasePayload(mustHex(t, "a3000201011405"), upgradeControlPhaseAccepted)
		if cause != nil || !got.HasFallback || !got.WireFallback || got.FallbackReason != UpgradeFallbackProtocolMismatch {
			t.Fatalf("peer fallback: got %+v, cause %v, want wire protocol-mismatch fallback with nil cause", got, cause)
		}
	})
	t.Run("unknown reason", func(t *testing.T) {
		got, cause := decodeUpgradeControlSelectedPairPhasePayload(mustHex(t, "a3000201011418ff"))
		if cause != errMalformedUpgradeControl || !got.HasFallback || !got.WireFallback || got.FallbackReason != UpgradeFallbackProtocolMismatch { //nolint:errorlint // The private decoder contract requires the exact sentinel.
			t.Fatalf("unknown reason: got %+v, cause %v, want wire protocol-mismatch fallback with malformed cause", got, cause)
		}
	})
	t.Run("phase forbidden reason retains legacy reason", func(t *testing.T) {
		// Transport mismatch is valid in the terminal phase, but not first phase.
		got, cause := decodeUpgradeControlFirstPhasePayload(mustHex(t, "a3000201011404"))
		if cause != errMalformedUpgradeControl || !got.HasFallback || got.HasOffer || got.FallbackReason != UpgradeFallbackTransportMismatch { //nolint:errorlint // The private decoder contract requires the exact sentinel.
			t.Fatalf("forbidden reason: got %+v, cause %v, want transport-mismatch fallback with malformed cause", got, cause)
		}
	})
}
