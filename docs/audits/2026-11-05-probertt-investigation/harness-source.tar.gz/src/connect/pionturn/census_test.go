package pionturn

import (
	"context"
	"runtime"
	"strings"
	"testing"
	"time"
)

// TestCloseJoinsAllCompositeOwnedWork is the one-to-one pre-return lifecycle
// census: at the moment Close returns — no post-return polling — no goroutine
// in the process is executing composite-owned or Pion-owned work: the base
// source guard, consumer pump, terminal close driver, and the fork's
// client/allocation timers and ChannelBind/refresh/preparation workers. The
// disposable server fixture is outside this census; it is a separate OS
// process joined by process wait.
func TestCloseJoinsAllCompositeOwnedWork(t *testing.T) {
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))
	conn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	_, peerAddr := listenPeer(t)
	if err := conn.PreparePeer(context.Background(), peerAddr); err != nil {
		t.Fatalf("PreparePeer error = %v", err)
	}
	if err := conn.Close(); err != nil {
		t.Fatalf("Close error = %v", err)
	}

	// Owner-specific join evidence, checked at return without polling: the
	// adapter pumps are joined (Wait returns immediately), the terminal
	// executor has signaled completion, and no preparation waiter remains
	// registered.
	composite := conn.(*packetConn)
	pumpsJoined := make(chan struct{})
	go func() {
		composite.adapterWork.Wait()
		close(pumpsJoined)
	}()
	select {
	case <-pumpsJoined:
	case <-time.After(time.Second):
		t.Fatal("adapter pumps were not joined when Close returned")
	}
	select {
	case <-composite.closeDone:
	default:
		t.Fatal("terminal executor had not signaled completion when Close returned")
	}
	composite.mu.Lock()
	waiters := len(composite.waiters)
	composite.mu.Unlock()
	if waiters != 0 {
		t.Fatalf("preparation waiters still registered after Close: %d", waiters)
	}

	// Snapshot every goroutine stack exactly once, immediately after Close
	// returned. Any frame still inside the composite or the fork dependency
	// is unjoined lifecycle work. The terminal executor's own post-signal
	// epilogue is excluded: it has already completed every join before
	// signaling and holds no resources.
	buf := make([]byte, 1<<22)
	n := runtime.Stack(buf, true)
	stacks := strings.Split(string(buf[:n]), "\n\n")
	for _, stack := range stacks[1:] { // stacks[0] is this test goroutine
		// Exclude only the executor frame proper (post-signal epilogue);
		// its close-driver closure ".terminalExecutor.func1(" does not
		// match this pattern and stays inside the census.
		if strings.Contains(stack, ".terminalExecutor(") {
			continue
		}
		// Composite and dependency worker frames only; test-harness frames
		// (TestMain, test functions, fixtures) are not lifecycle work.
		if strings.Contains(stack, "pionturn.(*packetConn)") ||
			strings.Contains(stack, "pionturn.(*allocator)") ||
			strings.Contains(stack, "the-sarge/turn") {
			t.Fatalf("composite-owned work still running when Close returned:\n%s", stack)
		}
	}
}
