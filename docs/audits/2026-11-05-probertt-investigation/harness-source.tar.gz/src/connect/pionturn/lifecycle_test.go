package pionturn

import (
	"bytes"
	"context"
	"errors"
	"net"
	"net/netip"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/connect"
	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

func mustAllocator(t *testing.T, cfg Config) connect.RelayPacketAllocator {
	t.Helper()
	allocator, err := NewAllocator(cfg)
	if err != nil {
		t.Fatalf("NewAllocator error = %v", err)
	}
	return allocator
}

// listenPeer opens a plain UDP peer socket used on the far side of the relay.
func listenPeer(t *testing.T) (net.PacketConn, netip.AddrPort) {
	t.Helper()
	peer, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("peer listen: %v", err)
	}
	t.Cleanup(func() { _ = peer.Close() })
	addr, ok := canonicalUDPAddr(peer.LocalAddr())
	if !ok {
		t.Fatalf("peer local address %v is not canonical", peer.LocalAddr())
	}
	return peer, addr
}

// refreshLifetimeZero reports whether datagram is a STUN Refresh request
// carrying LIFETIME=0: the local deallocation emission the graceful path
// must produce.
func refreshLifetimeZero(datagram []byte) bool {
	if len(datagram) < 20 {
		return false
	}
	if datagram[0] != 0x00 || datagram[1] != 0x04 { // Refresh request
		return false
	}
	if datagram[4] != 0x21 || datagram[5] != 0x12 || datagram[6] != 0xA4 || datagram[7] != 0x42 {
		return false
	}
	offset := 20
	for offset+4 <= len(datagram) {
		attrType := int(datagram[offset])<<8 | int(datagram[offset+1])
		attrLen := int(datagram[offset+2])<<8 | int(datagram[offset+3])
		valueStart := offset + 4
		if valueStart+attrLen > len(datagram) {
			return false
		}
		if attrType == 0x000D && attrLen == 4 {
			value := datagram[valueStart : valueStart+4]
			return value[0] == 0 && value[1] == 0 && value[2] == 0 && value[3] == 0
		}
		offset = valueStart + (attrLen+3)/4*4
	}
	return false
}

func TestAllocatePrepareExchangeAndGracefulClose(t *testing.T) {
	observed := installObservedListen(t)
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))

	conn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	base := <-observed
	if !relayprofile.IsTURNQUIC3(conn) {
		t.Fatal("official composite must bear the TURNQUIC3 packet marker")
	}
	if got := fixture.AllocationCount(); got != 1 {
		t.Fatalf("server allocation count = %d, want 1", got)
	}

	relayedAddr, ok := conn.LocalAddr().(*net.UDPAddr)
	if !ok || relayedAddr == nil || relayedAddr.Port == 0 {
		t.Fatalf("LocalAddr = %v, want nonzero-port *net.UDPAddr", conn.LocalAddr())
	}
	// Mutating one returned address must not change later publications.
	relayedBefore := relayedAddr.String()
	relayedAddr.IP = net.ParseIP("203.0.113.9")
	relayedAddr.Port = 1
	if got := conn.LocalAddr().String(); got != relayedBefore {
		t.Fatalf("LocalAddr after caller mutation = %q, want %q", got, relayedBefore)
	}

	peer, peerAddr := listenPeer(t)

	if err := conn.PreparePeer(context.Background(), peerAddr); err != nil {
		t.Fatalf("PreparePeer error = %v", err)
	}
	// Same-peer preparation coalesces/idempotently succeeds.
	if err := conn.PreparePeer(context.Background(), peerAddr); err != nil {
		t.Fatalf("repeat PreparePeer error = %v", err)
	}

	// Composite -> peer through the relay.
	outbound := []byte("wiremux over turn")
	if n, err := conn.WriteTo(outbound, net.UDPAddrFromAddrPort(peerAddr)); err != nil || n != len(outbound) {
		t.Fatalf("WriteTo = (%d, %v), want (%d, nil)", n, err, len(outbound))
	}
	peerBuf := make([]byte, 1500)
	_ = peer.SetReadDeadline(time.Now().Add(5 * time.Second))
	n, relaySource, err := peer.ReadFrom(peerBuf)
	if err != nil {
		t.Fatalf("peer ReadFrom error = %v", err)
	}
	if !bytes.Equal(peerBuf[:n], outbound) {
		t.Fatalf("peer received %q, want %q", peerBuf[:n], outbound)
	}
	if relaySource.String() != relayedBefore {
		t.Fatalf("peer saw relay source %v, want %v", relaySource, relayedBefore)
	}

	// Peer -> composite through the relay, with a fresh exact peer address.
	inbound := []byte("turn to wiremux")
	if _, err := peer.WriteTo(inbound, net.UDPAddrFromAddrPort(netip.MustParseAddrPort(relayedBefore))); err != nil {
		t.Fatalf("peer WriteTo error = %v", err)
	}
	readBuf := make([]byte, 1500)
	if err := conn.SetReadDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatalf("SetReadDeadline error = %v", err)
	}
	rn, from, err := conn.ReadFrom(readBuf)
	if err != nil {
		t.Fatalf("composite ReadFrom error = %v", err)
	}
	if !bytes.Equal(readBuf[:rn], inbound) {
		t.Fatalf("composite received %q, want %q", readBuf[:rn], inbound)
	}
	fromUDP, ok := from.(*net.UDPAddr)
	if !ok {
		t.Fatalf("composite ReadFrom addr = %T, want *net.UDPAddr", from)
	}
	if got, ok := canonicalUDPAddr(fromUDP); !ok || got != peerAddr {
		t.Fatalf("composite ReadFrom addr = %v, want %v", from, peerAddr)
	}
	// The returned peer address is fresh: mutating it does not corrupt state.
	fromUDP.Port = 1

	// Ordinary close is local graceful completion within the window.
	start := time.Now()
	if err := conn.Close(); err != nil {
		t.Fatalf("Close error = %v", err)
	}
	if elapsed := time.Since(start); elapsed >= gracefulCloseWindow {
		t.Fatalf("graceful Close took %v, want < %v", elapsed, gracefulCloseWindow)
	}
	// Local emission evidence: the dedicated socket emitted a STUN Refresh
	// request carrying LIFETIME=0 before Close returned.
	emitted := false
	for _, datagram := range base.Outbound() {
		if refreshLifetimeZero(datagram) {
			emitted = true
			break
		}
	}
	if !emitted {
		t.Fatal("no lifetime-zero Refresh request observed on the dedicated socket after graceful Close")
	}
	// Controlled fixture observation, separately: the server deleted the
	// allocation promptly after processing that refresh.
	if !fixture.WaitForAllocationCount(0, 5*time.Second) {
		t.Fatalf("server allocation count did not reach 0 after Close")
	}

	// Repeated Close returns the same stable aggregate.
	if err := conn.Close(); err != nil {
		t.Fatalf("repeated Close error = %v", err)
	}

	// Post-close operations fail with the stable closed classification.
	if _, err := conn.WriteTo(outbound, net.UDPAddrFromAddrPort(peerAddr)); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("post-close WriteTo error = %v, want net.ErrClosed", err)
	}
	if _, _, err := conn.ReadFrom(readBuf); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("post-close ReadFrom error = %v, want net.ErrClosed", err)
	}
	if err := conn.PreparePeer(context.Background(), peerAddr); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("post-close PreparePeer error = %v, want net.ErrClosed", err)
	}
}
