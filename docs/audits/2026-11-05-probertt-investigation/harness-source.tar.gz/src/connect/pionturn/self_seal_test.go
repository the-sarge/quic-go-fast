package pionturn

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	turn "github.com/the-sarge/turn/v5"
)

// selfSealAlloc models the fork allocation's self-seal contract under
// v5.2.1-gs.1: after a permanent refresh failure the allocation seals itself,
// ReadFrom returns net.ErrClosed wrapping the recorded cause, and the
// caller's Close returns that recorded cause. A caller Close that wins the
// seal race performs the seal instead, after which ReadFrom returns plain
// net.ErrClosed and a later self-seal attempt records nothing.
type selfSealAlloc struct {
	sealCause error
	// closeEchoesClosed makes Close return the same net.ErrClosed-wrapping
	// shape ReadFrom returned, exercising induced-close normalization.
	closeEchoesClosed bool
	// prepareObservesSeal makes an in-flight PreparePeer wake on the seal
	// with the fork's closed shape, as the fork's awaitPermission and
	// awaitBinding do, instead of waiting for the waiter context.
	prepareObservesSeal bool
	// readWakeDelay delays the pump's ReadFrom wake after the seal so a
	// contending waiter deterministically observes the seal first.
	readWakeDelay time.Duration
	// prepareClosedShaped, when closed, wakes an in-flight PreparePeer with
	// a plain closed-shaped transaction failure (the shape a dead dedicated
	// socket or the fork's transaction abort produces) without any seal.
	prepareClosedShaped chan struct{}

	mu         sync.Mutex
	sealed     bool
	selfSealed bool
	sealedCh   chan struct{}
	closeCalls atomic.Int32
}

func newSelfSealAlloc(cause error) *selfSealAlloc {
	return &selfSealAlloc{sealCause: cause, sealedCh: make(chan struct{})}
}

// seal simulates the fork's permanent refresh failure.
func (a *selfSealAlloc) seal() {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.sealed {
		return
	}
	a.sealed = true
	a.selfSealed = true
	close(a.sealedCh)
}

func (a *selfSealAlloc) closedErr() error {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.selfSealed {
		return fmt.Errorf("%w: %w", net.ErrClosed, a.sealCause)
	}
	return net.ErrClosed
}

func (a *selfSealAlloc) ReadFrom([]byte) (int, netip.AddrPort, error) {
	<-a.sealedCh
	if a.readWakeDelay > 0 {
		time.Sleep(a.readWakeDelay)
	}
	return 0, netip.AddrPort{}, a.closedErr()
}

func (a *selfSealAlloc) WriteTo([]byte, netip.AddrPort) (int, error) {
	<-a.sealedCh
	return 0, a.closedErr()
}

// PreparePeer blocks until the waiter context ends so that only the
// composite's own terminal routing wakes a registered waiter, unless
// prepareObservesSeal selects the fork's behavior of waking in-flight
// preparation on the seal with the closed shape.
func (a *selfSealAlloc) PreparePeer(ctx context.Context, _ netip.AddrPort) error {
	if a.prepareObservesSeal {
		select {
		case <-ctx.Done():
			return context.Cause(ctx)
		case <-a.sealedCh:
			return a.closedErr()
		}
	}
	if a.prepareClosedShaped != nil {
		select {
		case <-ctx.Done():
			return context.Cause(ctx)
		case <-a.prepareClosedShaped:
			return &net.OpError{Op: "write", Net: "udp", Err: net.ErrClosed}
		}
	}
	<-ctx.Done()
	return context.Cause(ctx)
}

func (a *selfSealAlloc) Close() error {
	a.closeCalls.Add(1)
	a.mu.Lock()
	defer a.mu.Unlock()
	if !a.sealed {
		a.sealed = true
		close(a.sealedCh)
		return nil
	}
	if !a.selfSealed {
		return net.ErrClosed
	}
	if a.closeEchoesClosed {
		return fmt.Errorf("%w: %w", net.ErrClosed, a.sealCause)
	}
	return a.sealCause
}

// newFakeAllocComposite publishes a composite over a fake allocation with a
// prepared selected peer and a running consumer pump.
func newFakeAllocComposite(t *testing.T, alloc relayAllocation) (*packetConn, *observedPacketConn, netip.AddrPort) {
	t.Helper()
	base, err := defaultListenPacket("udp4")
	if err != nil {
		t.Fatalf("base listen: %v", err)
	}
	observedBase := &observedPacketConn{PacketConn: base, closedCh: make(chan struct{})}
	client, err := turn.NewClient(&turn.ClientConfig{
		Server:   netip.MustParseAddrPort("127.0.0.1:1"),
		Username: "user",
		Password: "secret",
		Conn:     observedBase,
	})
	if err != nil {
		t.Fatalf("client: %v", err)
	}
	conn := newPacketConn(netip.MustParseAddrPort("127.0.0.1:3478"), observedBase, client)
	conn.adapterWork.Add(1)
	go func() {
		defer conn.adapterWork.Done()
		conn.baseSourceGuard()
	}()
	if err := conn.publish(alloc, netip.MustParseAddrPort("127.0.0.1:40000")); err != nil {
		t.Fatalf("publish: got %v, want nil", err)
	}
	peer := netip.MustParseAddrPort("127.0.0.1:41000")
	conn.mu.Lock()
	conn.selected = peer
	conn.selectedSet = true
	conn.ready = true
	conn.mu.Unlock()
	t.Cleanup(func() { _ = conn.Close() })
	return conn, observedBase, peer
}

func refreshFailureCause() error {
	return fmt.Errorf("%w: %w", turn.ErrAllocationRefreshFailed, turn.ErrTransactionTimeout)
}

// assertSelfSealAggregate checks the self-seal terminal classification with a
// responsive base: the aggregate carries turn.ErrAllocationRefreshFailed and
// claims neither forced interruption nor external base death.
func assertSelfSealAggregate(t *testing.T, closeErr error) {
	t.Helper()
	if !errors.Is(closeErr, turn.ErrAllocationRefreshFailed) {
		t.Fatalf("Close aggregate = %v, want it to preserve turn.ErrAllocationRefreshFailed", closeErr)
	}
	if errors.Is(closeErr, ErrForcedClose) {
		t.Fatalf("Close aggregate = %v claims ErrForcedClose while the base stayed responsive", closeErr)
	}
	if errors.Is(closeErr, errBaseReadPumpFailed) {
		t.Fatalf("Close aggregate = %v claims external base death while the base stayed responsive", closeErr)
	}
	if errors.Is(closeErr, errPreparationFailed) {
		t.Fatalf("Close aggregate = %v routed through the shared-preparation-failure class, want the pump trigger", closeErr)
	}
}

// assertJoinedAtReturn is the pre-return completion census for the fake
// composite: pumps joined, terminal executor signaled, no waiter registered.
func assertJoinedAtReturn(t *testing.T, conn *packetConn) {
	t.Helper()
	pumpsJoined := make(chan struct{})
	go func() {
		conn.adapterWork.Wait()
		close(pumpsJoined)
	}()
	select {
	case <-pumpsJoined:
	case <-time.After(time.Second):
		t.Fatal("adapter pumps were not joined when Close returned")
	}
	select {
	case <-conn.closeDone:
	default:
		t.Fatal("terminal executor had not signaled completion when Close returned")
	}
	conn.mu.Lock()
	waiters := len(conn.waiters)
	conn.mu.Unlock()
	if waiters != 0 {
		t.Fatalf("preparation waiters still registered after Close: %d", waiters)
	}
}

// TestAllocationSelfSealTerminalizesAndWakesConsumers proves the adopted
// trigger: a post-publication allocation self-seal observed before the
// composite seal terminalizes the composite with the recorded cause, wakes
// blocked ReadFrom callers with the closed error and PreparePeer waiters with
// the cause, closes the dedicated base exactly once, and preserves
// turn.ErrAllocationRefreshFailed in the stable Close aggregate without a
// forced or external-base-death claim.
func TestAllocationSelfSealTerminalizesAndWakesConsumers(t *testing.T) {
	alloc := newSelfSealAlloc(refreshFailureCause())
	conn, observedBase, peer := newFakeAllocComposite(t, alloc)

	// A consumer blocked in ReadFrom and a fresh-peer PreparePeer waiter
	// both depend on the allocation plane routing the terminal trigger.
	readDone := make(chan error, 1)
	go func() {
		_, _, err := conn.ReadFrom(make([]byte, 16))
		readDone <- err
	}()
	conn.mu.Lock()
	conn.ready = false // reopen preparation so a waiter registers
	conn.mu.Unlock()
	prepDone := make(chan error, 1)
	go func() { prepDone <- conn.PreparePeer(context.Background(), peer) }()
	time.Sleep(100 * time.Millisecond) // Let both callers block.

	alloc.seal()

	select {
	case err := <-readDone:
		if !errors.Is(err, net.ErrClosed) {
			t.Fatalf("blocked ReadFrom woke with %v, want net.ErrClosed", err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("blocked ReadFrom did not wake after allocation self-seal")
	}
	select {
	case err := <-prepDone:
		if !errors.Is(err, turn.ErrAllocationRefreshFailed) {
			t.Fatalf("PreparePeer waiter woke with %v, want the self-seal cause", err)
		}
		if !errors.Is(err, net.ErrClosed) {
			t.Fatalf("PreparePeer waiter woke with %v, want closed classification", err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("PreparePeer waiter did not wake after allocation self-seal")
	}

	start := time.Now()
	closeErr := conn.Close()
	if elapsed := time.Since(start); elapsed >= gracefulCloseWindow {
		t.Fatalf("Close after self-seal took %v, want the graceful driver path", elapsed)
	}
	assertSelfSealAggregate(t, closeErr)
	assertJoinedAtReturn(t, conn)
	if calls := observedBase.closeCalls.Load(); calls != 1 {
		t.Fatalf("base Close calls = %d, want exactly 1", calls)
	}
	if calls := alloc.closeCalls.Load(); calls != 1 {
		t.Fatalf("allocation Close calls = %d, want exactly 1", calls)
	}
	// Repeated Close returns the same stable aggregate; post-close
	// operations return the stable closed classification.
	if again := conn.Close(); !errors.Is(again, closeErr) {
		t.Fatalf("repeated Close = %v, want the stable aggregate %v", again, closeErr)
	}
	if _, _, err := conn.ReadFrom(make([]byte, 16)); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("post-seal ReadFrom error = %v, want net.ErrClosed", err)
	}
	if _, err := conn.WriteTo([]byte("x"), net.UDPAddrFromAddrPort(peer)); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("post-seal WriteTo error = %v, want net.ErrClosed", err)
	}
}

// TestAllocationSelfSealInducedCloseNormalizationKeepsCause gates the
// classification when the close driver echoes the allocation's own seal in
// the net.ErrClosed-wrapping shape: induced-close normalization must not
// erase the refresh cause, and the socket-close-shaped driver return must not
// be read as external base death while the base stayed responsive.
func TestAllocationSelfSealInducedCloseNormalizationKeepsCause(t *testing.T) {
	alloc := newSelfSealAlloc(refreshFailureCause())
	alloc.closeEchoesClosed = true
	conn, observedBase, _ := newFakeAllocComposite(t, alloc)

	alloc.seal()
	deadline := time.Now().Add(2 * time.Second)
	for {
		conn.mu.Lock()
		sealed := conn.sealed
		conn.mu.Unlock()
		if sealed || time.Now().After(deadline) {
			break
		}
		time.Sleep(5 * time.Millisecond)
	}
	closeErr := conn.Close()
	assertSelfSealAggregate(t, closeErr)
	if calls := observedBase.closeCalls.Load(); calls != 1 {
		t.Fatalf("base Close calls = %d, want exactly 1", calls)
	}
}

// TestOwnerDrivenAllocationCloseExitsPumpWithoutRouting proves the sealed
// discrimination: when the terminal executor itself drives the allocation
// close, the consumer pump's read failure is owner-induced, records no
// allocation seal cause, and the ordinary graceful close aggregate is nil.
func TestOwnerDrivenAllocationCloseExitsPumpWithoutRouting(t *testing.T) {
	alloc := newSelfSealAlloc(refreshFailureCause())
	conn, observedBase, _ := newFakeAllocComposite(t, alloc)

	if err := conn.Close(); err != nil {
		t.Fatalf("Close error = %v, want nil graceful aggregate", err)
	}
	assertJoinedAtReturn(t, conn)
	conn.mu.Lock()
	recorded := conn.allocSealCause
	conn.mu.Unlock()
	if recorded != nil {
		t.Fatalf("owner-driven allocation close recorded a seal cause: %v", recorded)
	}
	if calls := observedBase.closeCalls.Load(); calls != 1 {
		t.Fatalf("base Close calls = %d, want exactly 1", calls)
	}
	if calls := alloc.closeCalls.Load(); calls != 1 {
		t.Fatalf("allocation Close calls = %d, want exactly 1", calls)
	}
}

// TestAllocationSelfSealRacingCloseReturnsOneStableAggregate races the
// self-seal trigger against an explicit Close: whichever wins, exactly one
// terminal path runs, every caller receives one stable aggregate that
// preserves the refresh cause without a forced or base-death claim, and
// post-race operations return the stable closed result.
func TestAllocationSelfSealRacingCloseReturnsOneStableAggregate(t *testing.T) {
	for i := range 12 {
		alloc := newSelfSealAlloc(refreshFailureCause())
		conn, observedBase, _ := newFakeAllocComposite(t, alloc)

		start := make(chan struct{})
		closeResult := make(chan error, 2)
		for range 2 {
			go func() {
				<-start
				closeResult <- conn.Close()
			}()
		}
		go func() {
			<-start
			alloc.seal()
		}()
		close(start)

		first := <-closeResult
		second := <-closeResult
		if !errors.Is(second, first) {
			t.Fatalf("iteration %d concurrent Close returned %v and %v, want one stable aggregate", i, first, second)
		}
		conn.mu.Lock()
		routed := conn.allocSealCause != nil
		conn.mu.Unlock()
		if routed {
			// The self-seal won the terminal race: the pump routed it and
			// the aggregate is the self-seal class.
			assertSelfSealAggregate(t, first)
		} else if first != nil {
			// The explicit Close won: the pump exited without routing. The
			// driver still returns the recorded seal when the fake sealed
			// before the owner's close reached it, which the aggregate
			// preserves as a plain component; it never claims forced
			// interruption or base death.
			if errors.Is(first, ErrForcedClose) || errors.Is(first, errBaseReadPumpFailed) {
				t.Fatalf("iteration %d Close aggregate = %v claims forced/base-death while the base stayed responsive", i, first)
			}
			if !errors.Is(first, turn.ErrAllocationRefreshFailed) {
				t.Fatalf("iteration %d Close aggregate = %v is non-nil but does not carry the refresh cause", i, first)
			}
		}
		assertJoinedAtReturn(t, conn)
		if calls := observedBase.closeCalls.Load(); calls != 1 {
			t.Fatalf("iteration %d base Close calls = %d, want exactly 1", i, calls)
		}
		if calls := alloc.closeCalls.Load(); calls != 1 {
			t.Fatalf("iteration %d allocation Close calls = %d, want exactly 1", i, calls)
		}
		if _, _, err := conn.ReadFrom(make([]byte, 8)); !errors.Is(err, net.ErrClosed) {
			t.Fatalf("iteration %d post-race ReadFrom error = %v, want net.ErrClosed", i, err)
		}
	}
}

// TestAllocationSelfSealObservedFirstByWaiterLeavesRoutingToPump gates the
// contending-waiter interleaving: the fork wakes an in-flight PreparePeer on
// the seal with the closed shape before the pump's read returns. A closed
// shape is not a discriminating representation of the seal (a dead dedicated
// socket and the fork's transaction abort produce it too), so the waiter
// wakes with the closed classification and its observed cause but neither
// classifies nor terminalizes; the consumer pump routes the seal, and the
// composite terminalizes in the allocation-seal class through the single
// terminal path.
func TestAllocationSelfSealObservedFirstByWaiterLeavesRoutingToPump(t *testing.T) {
	alloc := newSelfSealAlloc(refreshFailureCause())
	alloc.prepareObservesSeal = true
	alloc.readWakeDelay = 100 * time.Millisecond
	conn, observedBase, peer := newFakeAllocComposite(t, alloc)

	conn.mu.Lock()
	conn.ready = false // reopen preparation so a waiter registers
	conn.mu.Unlock()
	prepDone := make(chan error, 1)
	go func() { prepDone <- conn.PreparePeer(context.Background(), peer) }()
	time.Sleep(50 * time.Millisecond) // Let the waiter block.

	alloc.seal()

	select {
	case err := <-prepDone:
		if !errors.Is(err, net.ErrClosed) || !errors.Is(err, turn.ErrAllocationRefreshFailed) {
			t.Fatalf("contending waiter woke with %v, want the closed classification carrying its observed cause", err)
		}
		if errors.Is(err, errPreparationFailed) {
			t.Fatalf("contending waiter woke with %v, want no shared-preparation-failure classification", err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("contending waiter did not wake after allocation self-seal")
	}
	// The pump, not the waiter, routes the seal.
	deadline := time.Now().Add(2 * time.Second)
	for {
		conn.mu.Lock()
		sealed := conn.sealed
		conn.mu.Unlock()
		if sealed || time.Now().After(deadline) {
			break
		}
		time.Sleep(5 * time.Millisecond)
	}
	conn.mu.Lock()
	sealed, recorded := conn.sealed, conn.allocSealCause
	conn.mu.Unlock()
	if !sealed || recorded == nil {
		t.Fatalf("pump did not route the seal after the waiter woke: sealed=%v recorded=%v", sealed, recorded)
	}
	closeErr := conn.Close()
	assertSelfSealAggregate(t, closeErr)
	assertJoinedAtReturn(t, conn)
	if calls := observedBase.closeCalls.Load(); calls != 1 {
		t.Fatalf("base Close calls = %d, want exactly 1", calls)
	}
}

// TestClosedShapedWaiterFailureDoesNotClaimAllocationSeal preserves the
// base-death class against the waiter path: a plain closed-shaped preparation
// failure (the shape a dead dedicated socket produces) is not evidence of an
// allocation self-seal. The waiter wakes closed without recording a seal or
// terminalizing, and the base source guard's later observation of the dead
// socket still takes the forced/base-death class.
func TestClosedShapedWaiterFailureDoesNotClaimAllocationSeal(t *testing.T) {
	alloc := newSelfSealAlloc(refreshFailureCause())
	alloc.prepareClosedShaped = make(chan struct{})
	conn, observedBase, peer := newFakeAllocComposite(t, alloc)

	conn.mu.Lock()
	conn.ready = false // reopen preparation so a waiter registers
	conn.mu.Unlock()
	prepDone := make(chan error, 1)
	go func() { prepDone <- conn.PreparePeer(context.Background(), peer) }()
	time.Sleep(50 * time.Millisecond) // Let the waiter block.

	close(alloc.prepareClosedShaped)
	select {
	case err := <-prepDone:
		if !errors.Is(err, net.ErrClosed) {
			t.Fatalf("waiter woke with %v, want the closed classification", err)
		}
		if errors.Is(err, errPreparationFailed) || errors.Is(err, errAllocationSealed) {
			t.Fatalf("waiter woke with %v, want neither preparation-failure nor allocation-seal classification", err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("waiter did not wake on the closed-shaped failure")
	}
	conn.mu.Lock()
	sealed, recorded := conn.sealed, conn.allocSealCause
	conn.mu.Unlock()
	if sealed || recorded != nil {
		t.Fatalf("closed-shaped waiter failure classified the composite: sealed=%v recorded=%v", sealed, recorded)
	}

	// The dedicated socket now dies externally; the base source guard owns
	// that classification.
	_ = observedBase.PacketConn.Close()
	deadline := time.Now().Add(2 * time.Second)
	for {
		conn.mu.Lock()
		sealed = conn.sealed
		conn.mu.Unlock()
		if sealed || time.Now().After(deadline) {
			break
		}
		time.Sleep(5 * time.Millisecond)
	}
	closeErr := conn.Close()
	if !errors.Is(closeErr, ErrForcedClose) || !errors.Is(closeErr, errBaseReadPumpFailed) {
		t.Fatalf("base-death Close aggregate = %v, want forced/base-death classification", closeErr)
	}
	if errors.Is(closeErr, errAllocationSealed) {
		t.Fatalf("base-death Close aggregate = %v claims an allocation seal", closeErr)
	}
	assertJoinedAtReturn(t, conn)
}
