package pionturn

import (
	"context"
	"errors"
	"io"
	"net"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/connect"
	quictransport "github.com/GridSwarm/wiremux/transport/quic"
)

// relayOuterCeiling is the largest base datagram the `/3` profile may emit:
// the fixed 1200-byte QUIC packet class plus the 4-byte TURN ChannelData
// header. With UDP and IPv6 headers it is 1252 bytes, under the 1280-byte
// IPv6 minimum MTU, so the supported fixtures never fragment.
const relayOuterCeiling = 1204

// TestRelayProfileCertifiedThroughRealComposite is the Slice 1.4 certification
// evidence: two real official composites, allocated on the disposable fork
// TURN server, carry an exclusive `/3` QUIC connection. It proves the first
// client Initial leaves the base as one 1204-byte ChannelData datagram, that
// every base datagram before and after permission refresh remains ChannelData
// within the outer ceiling, that the 1160-byte Datagram maximum crosses in
// both directions while max+1 rejects, and that each returned stream closes
// its composite's dedicated socket exactly once. It runs once per controlled
// address family.
func TestRelayProfileCertifiedThroughRealComposite(t *testing.T) {
	t.Run("IPv4", func(t *testing.T) { certifyRelayProfile(t, false) })
	t.Run("IPv6", func(t *testing.T) { certifyRelayProfile(t, true) })
}

func certifyRelayProfile(t *testing.T, ipv6 bool) {
	previous := testPermissionRefreshInterval
	testPermissionRefreshInterval = 250 * time.Millisecond
	t.Cleanup(func() { testPermissionRefreshInterval = previous })

	observed := installObservedListen(t)
	var fixture *turnFixture
	if ipv6 {
		fixture = startTURNFixture(t, fixtureIPv6Env+"=1")
	} else {
		fixture = startTURNFixture(t)
	}
	if got := fixture.Addr.Addr().Is6(); got != ipv6 {
		t.Fatalf("fixture address %v Is6() = %v, want %v", fixture.Addr, got, ipv6)
	}
	allocator := mustAllocator(t, fixtureConfig(fixture))

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	dialRelay, err := allocator.Allocate(ctx)
	if err != nil {
		t.Fatalf("dial Allocate error = %v", err)
	}
	dialBase := <-observed
	listenRelay, err := allocator.Allocate(ctx)
	if err != nil {
		_ = dialRelay.Close()
		t.Fatalf("listen Allocate error = %v", err)
	}
	listenBase := <-observed

	dialRelayed, ok := canonicalUDPAddr(dialRelay.LocalAddr())
	if !ok {
		t.Fatalf("dial relayed address %v is not canonical", dialRelay.LocalAddr())
	}
	listenRelayed, ok := canonicalUDPAddr(listenRelay.LocalAddr())
	if !ok {
		t.Fatalf("listen relayed address %v is not canonical", listenRelay.LocalAddr())
	}
	if dialRelayed.Addr().Is6() != ipv6 || listenRelayed.Addr().Is6() != ipv6 {
		t.Fatalf("relayed addresses %v/%v are not in the %v family", dialRelayed, listenRelayed, ipv6)
	}
	if err := dialRelay.PreparePeer(ctx, listenRelayed); err != nil {
		t.Fatalf("dial PreparePeer error = %v", err)
	}
	if err := listenRelay.PreparePeer(ctx, dialRelayed); err != nil {
		t.Fatalf("listen PreparePeer error = %v", err)
	}

	dialSession, err := quictransport.Transport{}.NewSession(ctx, nil)
	if err != nil {
		t.Fatalf("dial NewSession error = %v", err)
	}
	listenSession, err := quictransport.Transport{}.NewSession(ctx, nil)
	if err != nil {
		t.Fatalf("listen NewSession error = %v", err)
	}
	listener, err := listenSession.Listen(ctx, listenRelay, net.UDPAddrFromAddrPort(dialRelayed), dialSession.HandshakeMaterial())
	if err != nil {
		t.Fatalf("Listen error = %v", err)
	}
	defer listener.Close()

	type acceptResult struct {
		stream io.ReadWriteCloser
		err    error
	}
	accepted := make(chan acceptResult, 1)
	go func() {
		stream, err := listener.Accept(ctx)
		accepted <- acceptResult{stream: stream, err: err}
	}()

	dialStream, err := dialSession.Dial(ctx, dialRelay, net.UDPAddrFromAddrPort(listenRelayed), listenSession.HandshakeMaterial())
	if err != nil {
		t.Fatalf("Dial error = %v", err)
	}
	defer dialStream.Close()
	if _, err := dialStream.Write([]byte("first")); err != nil {
		t.Fatalf("dial write error = %v", err)
	}
	result := <-accepted
	if result.err != nil {
		t.Fatalf("Accept error = %v", result.err)
	}
	acceptedStream := result.stream
	defer acceptedStream.Close()
	buf := make([]byte, len("first"))
	if _, err := io.ReadFull(acceptedStream, buf); err != nil {
		t.Fatalf("accepted read error = %v", err)
	}

	// First client flight: one 1204-byte ChannelData datagram carrying the
	// padded 1200-byte Initial.
	dialOutbound := dialBase.Outbound()
	firstChannelData := -1
	for i, datagram := range dialOutbound {
		if isChannelData(datagram) {
			firstChannelData = i
			break
		}
	}
	if firstChannelData < 0 {
		t.Fatal("dial base emitted no ChannelData datagram during the handshake")
	}
	if got := len(dialOutbound[firstChannelData]); got != relayOuterCeiling {
		t.Fatalf("first dial ChannelData datagram = %d bytes, want %d", got, relayOuterCeiling)
	}

	// Datagram maximum in both directions and max+1 rejection in both.
	dialCarrier := requireCarrier(t, dialStream)
	listenCarrier := requireCarrier(t, acceptedStream)
	if got := dialCarrier.MaxDatagramPayload(); got != 1160 {
		t.Fatalf("dial MaxDatagramPayload() = %d, want 1160", got)
	}
	if got := listenCarrier.MaxDatagramPayload(); got != 1160 {
		t.Fatalf("listen MaxDatagramPayload() = %d, want 1160", got)
	}
	maxPayload := make([]byte, 1160)
	for i := range maxPayload {
		maxPayload[i] = byte(i)
	}
	exchangeDatagram(t, ctx, dialCarrier, listenCarrier, maxPayload)
	exchangeDatagram(t, ctx, listenCarrier, dialCarrier, maxPayload)
	over := make([]byte, 1161)
	if err := dialCarrier.SendDatagram(ctx, over); !errors.Is(err, connect.ErrDatagramTooLarge) {
		t.Fatalf("dial SendDatagram(max+1) error = %v, want connect.ErrDatagramTooLarge", err)
	}
	if err := listenCarrier.SendDatagram(ctx, over); !errors.Is(err, connect.ErrDatagramTooLarge) {
		t.Fatalf("listen SendDatagram(max+1) error = %v, want connect.ErrDatagramTooLarge", err)
	}

	// Post-refresh: let at least two permission-refresh cycles elapse, then
	// prove application traffic still leaves as ChannelData.
	time.Sleep(600 * time.Millisecond)
	before := len(dialBase.Outbound())
	if _, err := dialStream.Write([]byte("post-refresh")); err != nil {
		t.Fatalf("post-refresh write error = %v", err)
	}
	buf = make([]byte, len("post-refresh"))
	if _, err := io.ReadFull(acceptedStream, buf); err != nil {
		t.Fatalf("post-refresh read error = %v", err)
	}
	postRefresh := dialBase.Outbound()[before:]
	sawChannelData := false
	for _, datagram := range postRefresh {
		if isChannelData(datagram) {
			sawChannelData = true
		}
	}
	if !sawChannelData {
		t.Fatal("no ChannelData datagram left the dial base after permission refresh")
	}

	// Every base datagram in both roles is ChannelData or STUN control and
	// never exceeds the outer ceiling; a Send indication never appears.
	for name, base := range map[string]*observedPacketConn{"dial": dialBase, "listen": listenBase} {
		largest := 0
		for i, datagram := range base.Outbound() {
			if isSendIndication(datagram) {
				t.Fatalf("%s base datagram %d is a Send indication", name, i)
			}
			if len(datagram) > relayOuterCeiling {
				t.Fatalf("%s base datagram %d = %d bytes, exceeds outer ceiling %d", name, i, len(datagram), relayOuterCeiling)
			}
			if isChannelData(datagram) && len(datagram) > largest {
				largest = len(datagram)
			}
		}
		t.Logf("%s largest ChannelData datagram = %d bytes (ceiling %d)", name, largest, relayOuterCeiling)
	}

	// Handoff: each stream is the sole composite closer; the composite closes
	// its dedicated base exactly once.
	if err := dialStream.Close(); err != nil {
		t.Fatalf("dial stream close error = %v", err)
	}
	if err := acceptedStream.Close(); err != nil {
		t.Fatalf("accepted stream close error = %v", err)
	}
	if calls := dialBase.closeCalls.Load(); calls != 1 {
		t.Fatalf("dial base close calls = %d, want 1", calls)
	}
	if calls := listenBase.closeCalls.Load(); calls != 1 {
		t.Fatalf("listen base close calls = %d, want 1", calls)
	}
}

func requireCarrier(t *testing.T, stream io.ReadWriteCloser) connect.DatagramCarrier {
	t.Helper()
	capable, ok := stream.(connect.DatagramCapable)
	if !ok {
		t.Fatalf("stream %T is not DatagramCapable", stream)
	}
	carrier, ok := capable.DatagramCarrier()
	if !ok || carrier == nil {
		t.Fatal("stream negotiated no Datagram carrier")
	}
	return carrier
}

func exchangeDatagram(t *testing.T, ctx context.Context, from, to connect.DatagramCarrier, payload []byte) {
	t.Helper()
	// Datagrams are unreliable even over loopback; retry a bounded number of
	// times so a single loss does not fail the certification.
	for attempt := range 5 {
		if err := from.SendDatagram(ctx, payload); err != nil {
			t.Fatalf("SendDatagram error = %v", err)
		}
		receiveCtx, cancel := context.WithTimeout(ctx, time.Second)
		got, err := to.ReceiveDatagram(receiveCtx)
		cancel()
		if err == nil {
			if len(got) != len(payload) || got[0] != payload[0] || got[len(got)-1] != payload[len(payload)-1] {
				t.Fatalf("ReceiveDatagram = %d bytes, want %d", len(got), len(payload))
			}
			return
		}
		if !errors.Is(err, context.DeadlineExceeded) {
			t.Fatalf("ReceiveDatagram error = %v", err)
		}
		t.Logf("datagram attempt %d lost; retrying", attempt+1)
	}
	t.Fatal("maximum Datagram never arrived after bounded retries")
}

// isChannelData reports a TURN ChannelData frame: channel numbers occupy
// 0x4000-0x7FFF, so the first byte is in 0x40-0x7F.
func isChannelData(datagram []byte) bool {
	return len(datagram) >= 4 && datagram[0] >= 0x40 && datagram[0] <= 0x7f
}

// isSendIndication reports a STUN Send indication (method 0x006, class
// indication): message type 0x0016.
func isSendIndication(datagram []byte) bool {
	return len(datagram) >= 20 && datagram[0] == 0x00 && datagram[1] == 0x16
}
