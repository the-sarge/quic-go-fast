package pionturn

import (
	"bytes"
	"context"
	"net"
	"testing"
	"time"
)

// TestPreparedWritesRemainChannelDataAcrossRefresh proves the lifetime
// ChannelData-only invariant at the composite boundary: every data-plane
// datagram the base socket emits for a prepared write is ChannelData, before
// and after permission refresh, and never a Send indication.
func TestPreparedWritesRemainChannelDataAcrossRefresh(t *testing.T) {
	previous := testPermissionRefreshInterval
	testPermissionRefreshInterval = 250 * time.Millisecond
	t.Cleanup(func() { testPermissionRefreshInterval = previous })

	observed := installObservedListen(t)
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))
	relayConn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	t.Cleanup(func() { _ = relayConn.Close() })
	base := <-observed

	peer, peerAddr := listenPeer(t)
	if err := relayConn.PreparePeer(context.Background(), peerAddr); err != nil {
		t.Fatalf("PreparePeer error = %v", err)
	}

	exchange := func(payload []byte) {
		t.Helper()
		if _, err := relayConn.WriteTo(payload, net.UDPAddrFromAddrPort(peerAddr)); err != nil {
			t.Fatalf("WriteTo error = %v", err)
		}
		buf := make([]byte, 256)
		_ = peer.SetReadDeadline(time.Now().Add(5 * time.Second))
		if _, _, err := peer.ReadFrom(buf); err != nil {
			t.Fatalf("peer ReadFrom error = %v", err)
		}
	}

	first := []byte("first-packet-payload")
	exchange(first)
	// Let at least two permission-refresh cycles elapse.
	time.Sleep(600 * time.Millisecond)
	second := []byte("post-refresh-payload")
	exchange(second)

	for _, payload := range [][]byte{first, second} {
		found := false
		for _, datagram := range base.Outbound() {
			if !bytes.Contains(datagram, payload) {
				continue
			}
			found = true
			// ChannelData frames carry a channel number in 0x4000-0x7FFF;
			// a STUN Send indication would start 0x00 0x16.
			if datagram[0] < 0x40 || datagram[0] > 0x7f {
				t.Fatalf("payload %q left the base as non-ChannelData frame % x", payload, datagram[:4])
			}
		}
		if !found {
			t.Fatalf("payload %q never observed on the base socket", payload)
		}
	}
}
