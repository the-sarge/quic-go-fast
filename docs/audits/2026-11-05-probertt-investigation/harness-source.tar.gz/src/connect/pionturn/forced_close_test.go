package pionturn

import (
	"context"
	"errors"
	"net"
	"net/netip"
	"testing"
	"time"

	turn "github.com/the-sarge/turn/v5"
)

// blockedCloseAlloc simulates Pion blocked on socket I/O: its Close returns
// only after the dedicated base socket is force-closed.
type blockedCloseAlloc struct {
	baseClosed <-chan struct{}
	closedAt   chan time.Time
}

func (a *blockedCloseAlloc) Close() error {
	<-a.baseClosed
	a.closedAt <- time.Now()
	return net.ErrClosed
}

func (a *blockedCloseAlloc) ReadFrom(p []byte) (int, netip.AddrPort, error) {
	<-a.baseClosed
	return 0, netip.AddrPort{}, net.ErrClosed
}

func (a *blockedCloseAlloc) WriteTo(p []byte, peer netip.AddrPort) (int, error) {
	<-a.baseClosed
	return 0, net.ErrClosed
}

func (a *blockedCloseAlloc) PreparePeer(context.Context, netip.AddrPort) error { return nil }

// TestForcedCloseInterruptsBlockedPionIO proves the graceful-to-forced
// transition: the executor grants the close driver the fixed two-second
// window, then closes the dedicated base to force interruption, joins the
// driver, omits induced socket-close errors, and returns a stable aggregate
// wrapping ErrForcedClose.
func TestForcedCloseInterruptsBlockedPionIO(t *testing.T) {
	base, err := defaultListenPacket("udp4")
	if err != nil {
		t.Fatalf("base listen: %v", err)
	}
	observedBase := &observedPacketConn{PacketConn: base, closedCh: make(chan struct{})}
	client, err := turn.NewClient(&turn.ClientConfig{
		Server:   netip.MustParseAddrPort("127.0.0.1:1"),
		Username: "user",
		Password: "secret",
		Conn:     observedBase,
	})
	if err != nil {
		t.Fatalf("client: %v", err)
	}

	alloc := &blockedCloseAlloc{
		baseClosed: observedBase.closedCh,
		closedAt:   make(chan time.Time, 1),
	}
	conn := newPacketConn(netip.MustParseAddrPort("127.0.0.1:3478"), observedBase, client)

	// A consumer pump blocked in the allocation read and an in-flight
	// prepared write blocked in the allocation write both depend on forced
	// base interruption to unblock.
	if err := conn.publish(alloc, netip.MustParseAddrPort("127.0.0.1:40000")); err != nil {
		t.Fatalf("publish: got %v, want nil", err)
	}
	peer := netip.MustParseAddrPort("127.0.0.1:41000")
	conn.mu.Lock()
	conn.selected = peer
	conn.selectedSet = true
	conn.ready = true
	conn.mu.Unlock()
	writerDone := make(chan error, 1)
	go func() {
		_, err := conn.WriteTo([]byte("blocked write"), net.UDPAddrFromAddrPort(peer))
		writerDone <- err
	}()
	time.Sleep(100 * time.Millisecond) // Let the write block inside the allocation.

	start := time.Now()
	closeErr := conn.Close()
	elapsed := time.Since(start)

	// Forced base interruption unblocked the in-flight prepared write.
	select {
	case <-writerDone:
	case <-time.After(2 * time.Second):
		t.Fatal("blocked prepared write did not unblock after forced close")
	}

	if !errors.Is(closeErr, ErrForcedClose) {
		t.Fatalf("forced Close aggregate = %v, want wrapping ErrForcedClose", closeErr)
	}
	// The induced net.ErrClosed from the driver is omitted; the aggregate
	// carries only the forced classification.
	if !errors.Is(closeErr, ErrForcedClose) || errors.Is(closeErr, context.Canceled) {
		t.Fatalf("aggregate = %v carries unexpected components", closeErr)
	}
	if elapsed < gracefulCloseWindow {
		t.Fatalf("forced Close returned in %v, before the %v graceful window", elapsed, gracefulCloseWindow)
	}
	if elapsed > gracefulCloseWindow+2*time.Second {
		t.Fatalf("forced Close took %v, want prompt interruption after the window", elapsed)
	}
	// Forced base close preceded the close-driver join.
	select {
	case <-alloc.closedAt:
	default:
		t.Fatal("close driver never unblocked; forced base interruption did not run")
	}
	if calls := observedBase.closeCalls.Load(); calls != 1 {
		t.Fatalf("base Close calls = %d, want exactly 1", calls)
	}
	if calls := observedBase.deadlineCalls.Load(); calls != 0 {
		t.Fatalf("base deadline calls = %d, want 0", calls)
	}
	// Repeated Close returns the same stable aggregate promptly.
	again := conn.Close()
	if !errors.Is(again, ErrForcedClose) {
		t.Fatalf("repeated forced Close = %v, want the stable aggregate", again)
	}
}

// TestCloseRacingBaseDeathPreservesCauseAndNormalizes gates an explicit
// Close against an external base death: whichever wins the terminal race,
// the aggregate never leaks a bare induced net.ErrClosed as evidence, never
// classifies as a timeout, and post-race operations return the stable
// closed result.
func TestCloseRacingBaseDeathPreservesCauseAndNormalizes(t *testing.T) {
	observed := installObservedListen(t)
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))

	for i := range 12 {
		relayConn, err := allocator.Allocate(context.Background())
		if err != nil {
			t.Fatalf("iteration %d Allocate error = %v", i, err)
		}
		base := <-observed

		start := make(chan struct{})
		closeResult := make(chan error, 1)
		go func() {
			<-start
			closeResult <- relayConn.Close()
		}()
		go func() {
			<-start
			_ = base.PacketConn.Close() // external death of the raw socket beneath the once owner
		}()
		close(start)

		closeErr := <-closeResult
		composite := relayConn.(*packetConn)
		composite.mu.Lock()
		recordedDeath := composite.pumpFailure
		composite.mu.Unlock()
		if recordedDeath != nil {
			// An observed external base death is the forced class even
			// when the explicit Close won the terminal race.
			if !errors.Is(closeErr, ErrForcedClose) || !errors.Is(closeErr, errBaseReadPumpFailed) {
				t.Fatalf("iteration %d observed base death but Close aggregate = %v, want forced/base-death classification", i, closeErr)
			}
		} else if closeErr != nil {
			// Without an observed death the driver completed on a usable
			// socket; only genuine component errors may remain.
			if !errors.Is(closeErr, ErrForcedClose) && !errors.Is(closeErr, errBaseReadPumpFailed) {
				t.Fatalf("iteration %d Close aggregate = %v, want nil or forced/base-death classification", i, closeErr)
			}
		}
		if closeErr != nil {
			var netErr net.Error
			if errors.As(closeErr, &netErr) && netErr.Timeout() {
				t.Fatalf("iteration %d Close aggregate classifies as timeout: %v", i, closeErr)
			}
		}
		if _, _, err := relayConn.ReadFrom(make([]byte, 8)); !errors.Is(err, net.ErrClosed) {
			t.Fatalf("iteration %d post-race ReadFrom error = %v, want net.ErrClosed", i, err)
		}
	}
}

// TestBaseDeathForcesTerminalPath proves a dead dedicated socket is a
// terminal trigger that takes the forced path without waiting the window.
func TestBaseDeathForcesTerminalPath(t *testing.T) {
	observed := installObservedListen(t)
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))
	relayConn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	base := <-observed
	composite := relayConn.(*packetConn)

	// Kill the dedicated socket out from under the composite.
	_ = base.PacketConn.Close()

	// The pump routes the terminal trigger; Close joins the same stable
	// aggregate, which wraps ErrForcedClose and the pump-death cause.
	deadline := time.Now().Add(5 * time.Second)
	for {
		composite.mu.Lock()
		sealed := composite.sealed
		composite.mu.Unlock()
		if sealed || time.Now().After(deadline) {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	closeErr := relayConn.Close()
	if !errors.Is(closeErr, ErrForcedClose) {
		t.Fatalf("base-death Close aggregate = %v, want wrapping ErrForcedClose", closeErr)
	}
	if !errors.Is(closeErr, errBaseReadPumpFailed) {
		t.Fatalf("base-death Close aggregate = %v, want wrapping errBaseReadPumpFailed", closeErr)
	}
	if _, _, err := relayConn.ReadFrom(make([]byte, 16)); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("post-death ReadFrom error = %v, want net.ErrClosed", err)
	}
}
