package pionturn

// The disposable TURN server fixture runs the tagged fork's turntest
// responder (a fork-owned verification aid with an example-level guarantee)
// in a separate OS process through the re-exec pattern, keeping its
// goroutines outside the composite lifecycle census; the parent joins it by
// OS process wait. The control protocol is line-based: the child prints
// "ADDR <addr>" once, answers "count" with "COUNT <n>", and exits when
// stdin closes.

import (
	"bufio"
	"fmt"
	"io"
	"net"
	"net/netip"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/the-sarge/turn/v5/turntest"
)

const (
	fixtureEnv                = "PIONTURN_TEST_FIXTURE"
	fixtureRelayIPEnv         = "PIONTURN_TEST_FIXTURE_RELAY_IP"
	fixtureDenyPermissionsEnv = "PIONTURN_TEST_FIXTURE_DENY_PERMISSIONS"
	// fixtureIPv6Env selects the IPv6-minimum controlled outer path: the
	// server listens and relays on ::1 so the client-to-server hop carries
	// IPv6 headers.
	fixtureIPv6Env  = "PIONTURN_TEST_FIXTURE_IPV6"
	fixtureRealm    = "wiremux.test"
	fixtureUsername = "user"
	fixturePassword = "secret"
)

func TestMain(m *testing.M) {
	if os.Getenv(fixtureEnv) == "1" {
		runServerFixture()
		return
	}
	os.Exit(m.Run())
}

func runServerFixture() {
	opts := turntest.Options{
		Realm:    fixtureRealm,
		Username: fixtureUsername,
		Password: fixturePassword,
		IPv6:     os.Getenv(fixtureIPv6Env) == "1",
		// DenyPermissions makes every CreatePermission fail, matching the
		// deny-all PermissionHandler the retired fork server fixture used.
		DenyPermissions: os.Getenv(fixtureDenyPermissionsEnv) == "1",
	}
	// The override lets invalid-relayed-address tests advertise a value the
	// composite must reject; the relay socket still binds loopback.
	if override := os.Getenv(fixtureRelayIPEnv); override != "" {
		opts.RelayIPOverride = net.ParseIP(override)
	}
	server, err := turntest.New(opts)
	if err != nil {
		fmt.Fprintln(os.Stderr, "fixture server:", err)
		os.Exit(1)
	}
	fmt.Println("ADDR", server.Addr().String())

	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		if strings.TrimSpace(scanner.Text()) == "count" {
			fmt.Println("COUNT", server.AllocationCount())
		}
	}
	_ = server.Close()
	os.Exit(0)
}

type turnFixture struct {
	t      *testing.T
	cmd    *exec.Cmd
	stdin  io.WriteCloser
	stdout *bufio.Reader
	Addr   netip.AddrPort
}

// startTURNFixture launches the disposable fork TURN server subprocess. Its
// cleanup closes control stdin and joins the child by OS process wait.
func startTURNFixture(t *testing.T, extraEnv ...string) *turnFixture {
	t.Helper()

	cmd := exec.Command(os.Args[0]) // #nosec G204 G702 -- re-exec of the test binary itself.
	cmd.Env = append(os.Environ(), fixtureEnv+"=1")
	cmd.Env = append(cmd.Env, extraEnv...)
	stdin, err := cmd.StdinPipe()
	if err != nil {
		t.Fatalf("fixture stdin: %v", err)
	}
	stdoutPipe, err := cmd.StdoutPipe()
	if err != nil {
		t.Fatalf("fixture stdout: %v", err)
	}
	cmd.Stderr = os.Stderr
	if err := cmd.Start(); err != nil {
		t.Fatalf("fixture start: %v", err)
	}
	fixture := &turnFixture{t: t, cmd: cmd, stdin: stdin, stdout: bufio.NewReader(stdoutPipe)}
	t.Cleanup(func() {
		_ = stdin.Close()
		_ = cmd.Wait()
	})

	line, err := fixture.stdout.ReadString('\n')
	if err != nil {
		t.Fatalf("fixture address line: %v", err)
	}
	fields := strings.Fields(line)
	if len(fields) != 2 || fields[0] != "ADDR" {
		t.Fatalf("fixture address line = %q", line)
	}
	addr, err := netip.ParseAddrPort(fields[1])
	if err != nil {
		t.Fatalf("fixture address %q: %v", fields[1], err)
	}
	fixture.Addr = addr
	return fixture
}

// AllocationCount asks the child server for its live allocation count.
func (f *turnFixture) AllocationCount() int {
	f.t.Helper()
	if _, err := io.WriteString(f.stdin, "count\n"); err != nil {
		f.t.Fatalf("fixture count request: %v", err)
	}
	line, err := f.stdout.ReadString('\n')
	if err != nil {
		f.t.Fatalf("fixture count reply: %v", err)
	}
	fields := strings.Fields(line)
	if len(fields) != 2 || fields[0] != "COUNT" {
		f.t.Fatalf("fixture count reply = %q", line)
	}
	n, err := strconv.Atoi(fields[1])
	if err != nil {
		f.t.Fatalf("fixture count value %q: %v", fields[1], err)
	}
	return n
}

// WaitForAllocationCount polls until the child reports want allocations.
func (f *turnFixture) WaitForAllocationCount(want int, timeout time.Duration) bool {
	f.t.Helper()
	dead := time.Now().Add(timeout)
	for {
		if f.AllocationCount() == want {
			return true
		}
		if time.Now().After(dead) {
			return false
		}
		time.Sleep(20 * time.Millisecond)
	}
}

func fixtureConfig(f *turnFixture) Config {
	return Config{Server: f.Addr, Username: fixtureUsername, Password: fixturePassword}
}
