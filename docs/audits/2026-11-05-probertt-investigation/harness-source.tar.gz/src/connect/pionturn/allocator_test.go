package pionturn

import (
	"context"
	"errors"
	"fmt"
	"net"
	"testing"
	"time"

	turn "github.com/the-sarge/turn/v5"

	"github.com/GridSwarm/wiremux/connect"
)

func TestAllocatePreCanceledContextPreservesCause(t *testing.T) {
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))

	cause := errors.New("caller abandoned before construction")
	ctx, cancel := context.WithCancelCause(context.Background())
	cancel(cause)

	conn, err := allocator.Allocate(ctx)
	if conn != nil {
		t.Fatalf("Allocate = %T, want nil", conn)
	}
	if !errors.Is(err, cause) {
		t.Fatalf("Allocate error = %v, want wrapping exact cause %v", err, cause)
	}
	if got := fixture.AllocationCount(); got != 0 {
		t.Fatalf("server allocation count = %d, want 0", got)
	}
}

func TestAllocateCancellationDuringBlockedEstablishment(t *testing.T) {
	observed := installObservedListen(t)

	// A plain UDP socket that never responds stands in for an unreachable
	// TURN server, driving the real transaction machinery.
	silent, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("silent server listen: %v", err)
	}
	t.Cleanup(func() { _ = silent.Close() })
	silentAddr, _ := canonicalUDPAddr(silent.LocalAddr())

	allocator := mustAllocator(t, Config{Server: silentAddr, Username: "user", Password: "secret"})

	cause := errors.New("caller gave up waiting")
	ctx, cancel := context.WithCancelCause(context.Background())
	go func() {
		time.Sleep(200 * time.Millisecond)
		cancel(cause)
	}()

	start := time.Now()
	conn, err := allocator.Allocate(ctx)
	elapsed := time.Since(start)

	if conn != nil {
		t.Fatalf("Allocate = %T, want nil", conn)
	}
	if !errors.Is(err, cause) {
		t.Fatalf("Allocate error = %v, want wrapping exact cause %v", err, cause)
	}
	// Prompt cancellation observation: the fork's ctx-native Allocate wakes
	// this caller well before the transaction's retransmission budget.
	if elapsed > 5*time.Second {
		t.Fatalf("canceled Allocate took %v, want prompt interruption", elapsed)
	}
	base := <-observed
	if calls := base.closeCalls.Load(); calls != 1 {
		t.Fatalf("dedicated socket close calls = %d, want exactly 1", calls)
	}
	if calls := base.deadlineCalls.Load(); calls != 0 {
		t.Fatalf("base deadline calls = %d, want 0", calls)
	}
}

// TestCanceledAllocateEvidence pins the canceled-allocate aggregate family:
// the exact cancellation cause appears first and exactly once, an allocate
// error that merely spells the cause (bare or wrapped) is suppressed, and
// independent evidence — including an external socket death wrapping
// net.ErrClosed — and cleanup errors are preserved.
func TestCanceledAllocateEvidence(t *testing.T) {
	cause := errors.New("caller canceled")
	closeErr := errors.New("close failed")

	bare := canceledAllocateEvidence(cause, cause, nil)
	if len(bare) != 1 || !errors.Is(bare[0], cause) {
		t.Fatalf("bare duplicate evidence = %v, want exactly the cause", bare)
	}

	wrapped := canceledAllocateEvidence(cause, fmt.Errorf("turn: %w", cause), nil)
	if len(wrapped) != 1 || !errors.Is(wrapped[0], cause) {
		t.Fatalf("wrapped duplicate evidence = %v, want exactly the cause", wrapped)
	}

	external := fmt.Errorf("transaction: %w", net.ErrClosed)
	preserved := canceledAllocateEvidence(cause, external, []error{closeErr})
	joined := errors.Join(preserved...)
	if !errors.Is(preserved[0], cause) {
		t.Fatalf("evidence = %v, want the cause first", preserved)
	}
	if !errors.Is(joined, net.ErrClosed) {
		t.Fatalf("evidence = %v, want external socket death preserved", joined)
	}
	if !errors.Is(joined, closeErr) {
		t.Fatalf("evidence = %v, want cleanup error preserved", joined)
	}
}

func TestAllocateRejectsInvalidRelayedAddress(t *testing.T) {
	fixture := startTURNFixture(t, fixtureRelayIPEnv+"=224.0.0.1")
	allocator := mustAllocator(t, fixtureConfig(fixture))

	conn, err := allocator.Allocate(context.Background())
	if conn != nil {
		t.Fatalf("Allocate = %T, want nil", conn)
	}
	// The fork owns relayed-address canonicalization and rejects before the
	// composite's defense-in-depth check can observe the allocation.
	if !errors.Is(err, turn.ErrInvalidRelayedAddress) {
		t.Fatalf("Allocate error = %v, want wrapping turn.ErrInvalidRelayedAddress", err)
	}
	// Every partial resource was disposed: the fork released the server-side
	// allocation with a lifetime-0 refresh before returning the rejection.
	if !fixture.WaitForAllocationCount(0, 5*time.Second) {
		t.Fatal("server allocation was not deleted after invalid relayed address")
	}
}

func TestAllocateConcurrentIndependentComposites(t *testing.T) {
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))

	// Both Allocate calls enter simultaneously through a shared start gate,
	// proving the allocator is concurrently reusable with independent
	// dedicated sockets and composites.
	type result struct {
		conn connect.RelayPacketConn
		err  error
	}
	start := make(chan struct{})
	results := make(chan result, 2)
	for range 2 {
		go func() {
			<-start
			conn, err := allocator.Allocate(context.Background())
			results <- result{conn: conn, err: err}
		}()
	}
	close(start)
	firstResult, secondResult := <-results, <-results
	if firstResult.err != nil || secondResult.err != nil {
		t.Fatalf("overlapping Allocate errors = %v, %v", firstResult.err, secondResult.err)
	}
	first, second := firstResult.conn, secondResult.conn
	if got := fixture.AllocationCount(); got != 2 {
		t.Fatalf("server allocation count = %d, want 2", got)
	}
	if first.LocalAddr().String() == second.LocalAddr().String() {
		t.Fatalf("independent composites share relayed address %v", first.LocalAddr())
	}
	if err := first.Close(); err != nil {
		t.Fatalf("first Close error = %v", err)
	}
	if !fixture.WaitForAllocationCount(1, 5*time.Second) {
		t.Fatal("first allocation did not delete independently")
	}
	// The second composite remains fully usable after the first closed.
	_, peerAddr := listenPeer(t)
	if err := second.PreparePeer(context.Background(), peerAddr); err != nil {
		t.Fatalf("second PreparePeer after first Close error = %v", err)
	}
	if err := second.Close(); err != nil {
		t.Fatalf("second Close error = %v", err)
	}
	if !fixture.WaitForAllocationCount(0, 5*time.Second) {
		t.Fatal("second allocation did not delete")
	}
}
