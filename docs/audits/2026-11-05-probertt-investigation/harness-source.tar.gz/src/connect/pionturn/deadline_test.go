package pionturn

import (
	"context"
	"errors"
	"net"
	"os"
	"testing"
	"time"
)

func TestLogicalReadDeadlineSemantics(t *testing.T) {
	observed := installObservedListen(t)
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))
	conn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	t.Cleanup(func() { _ = conn.Close() })
	base := <-observed

	peer, peerAddr := listenPeer(t)
	if err := conn.PreparePeer(context.Background(), peerAddr); err != nil {
		t.Fatalf("PreparePeer error = %v", err)
	}

	classify := func(t *testing.T, err error) {
		t.Helper()
		if !errors.Is(err, os.ErrDeadlineExceeded) {
			t.Fatalf("read error = %v, want wrapping os.ErrDeadlineExceeded", err)
		}
		var netErr net.Error
		if !errors.As(err, &netErr) || !netErr.Timeout() {
			t.Fatalf("read error = %v, want net.Error with Timeout() == true", err)
		}
	}

	// Expiring an installed deadline wakes a pending blocked read.
	blocked := make(chan error, 1)
	go func() {
		buf := make([]byte, 64)
		_, _, err := conn.ReadFrom(buf)
		blocked <- err
	}()
	time.Sleep(100 * time.Millisecond) // Let the read block.
	if err := conn.SetReadDeadline(time.Now().Add(-time.Second)); err != nil {
		t.Fatalf("SetReadDeadline(past) error = %v", err)
	}
	select {
	case err := <-blocked:
		classify(t, err)
	case <-time.After(2 * time.Second):
		t.Fatal("pending read did not wake on deadline expiry")
	}

	// While the deadline remains expired, newly started reads fail too.
	buf := make([]byte, 64)
	if _, _, err := conn.ReadFrom(buf); err == nil {
		t.Fatal("new read while expired = nil error, want deadline error")
	} else {
		classify(t, err)
	}

	// Unsupported write and combined deadlines change nothing.
	for _, tc := range []struct {
		name string
		call func() error
	}{
		{name: "SetWriteDeadline nonzero", call: func() error { return conn.SetWriteDeadline(time.Now().Add(time.Second)) }},
		{name: "SetWriteDeadline zero", call: func() error { return conn.SetWriteDeadline(time.Time{}) }},
		{name: "SetDeadline nonzero", call: func() error { return conn.SetDeadline(time.Now().Add(time.Second)) }},
		{name: "SetDeadline zero", call: func() error { return conn.SetDeadline(time.Time{}) }},
	} {
		if err := tc.call(); !errors.Is(err, errors.ErrUnsupported) {
			t.Fatalf("%s error = %v, want wrapping errors.ErrUnsupported", tc.name, err)
		}
	}

	// A later reset restores reads; pump and protocol work stayed live.
	if err := conn.SetReadDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatalf("SetReadDeadline(reset) error = %v", err)
	}
	relayed := conn.LocalAddr().(*net.UDPAddr)
	if _, err := peer.WriteTo([]byte("after reset"), relayed); err != nil {
		t.Fatalf("peer WriteTo error = %v", err)
	}
	if n, _, err := conn.ReadFrom(buf); err != nil || string(buf[:n]) != "after reset" {
		t.Fatalf("post-reset ReadFrom = (%q, %v), want (\"after reset\", nil)", buf[:n], err)
	}

	// The dedicated base socket never saw a deadline mutation.
	if calls := base.deadlineCalls.Load(); calls != 0 {
		t.Fatalf("base socket deadline calls = %d, want 0", calls)
	}

	// A deadline update racing Close completes before the seal or returns
	// the stable closed result.
	raceDone := make(chan error, 1)
	go func() { raceDone <- conn.SetReadDeadline(time.Now().Add(time.Second)) }()
	closeErr := conn.Close()
	if closeErr != nil {
		t.Fatalf("Close error = %v", closeErr)
	}
	if err := <-raceDone; err != nil && !errors.Is(err, net.ErrClosed) {
		t.Fatalf("racing SetReadDeadline error = %v, want nil or net.ErrClosed", err)
	}
	if err := conn.SetReadDeadline(time.Now()); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("post-close SetReadDeadline error = %v, want net.ErrClosed", err)
	}
	if calls := base.deadlineCalls.Load(); calls != 0 {
		t.Fatalf("base socket deadline calls after close = %d, want 0", calls)
	}
}

// TestExpiredDeadlineBeatsQueuedData pins read-path precedence: while an
// installed deadline remains expired, every read fails with the deadline
// classification even when a selected-peer payload is already buffered, and
// a later reset makes the queued payload readable.
func TestExpiredDeadlineBeatsQueuedData(t *testing.T) {
	conn, peer, _, _ := preparedComposite(t)

	relayed := conn.LocalAddr().(*net.UDPAddr)
	if _, err := peer.WriteTo([]byte("queued payload"), relayed); err != nil {
		t.Fatalf("peer WriteTo error = %v", err)
	}
	// Wait until the payload is buffered in the composite's read queue.
	deadline := time.Now().Add(5 * time.Second)
	for len(conn.readQueue) == 0 {
		if time.Now().After(deadline) {
			t.Fatal("selected-peer payload never reached the read queue")
		}
		time.Sleep(5 * time.Millisecond)
	}

	if err := conn.SetReadDeadline(time.Now().Add(-time.Second)); err != nil {
		t.Fatalf("SetReadDeadline(past) error = %v", err)
	}
	buf := make([]byte, 64)
	for i := range 100 {
		if _, _, err := conn.ReadFrom(buf); !errors.Is(err, os.ErrDeadlineExceeded) {
			t.Fatalf("read %d with queued data under expired deadline = %v, want deadline error", i, err)
		}
	}

	// Resetting the deadline restores reads and delivers the queued data.
	if err := conn.SetReadDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatalf("SetReadDeadline(reset) error = %v", err)
	}
	n, _, err := conn.ReadFrom(buf)
	if err != nil || string(buf[:n]) != "queued payload" {
		t.Fatalf("post-reset ReadFrom = (%q, %v), want (\"queued payload\", nil)", buf[:n], err)
	}
	if err := conn.Close(); err != nil {
		t.Fatalf("Close error = %v", err)
	}
}

// TestPendingReaderNeverDeliversWhileExpired pins the blocked-reader
// window: a reader already blocked when expiry and data become ready
// together must fail with the deadline classification, never deliver.
func TestPendingReaderNeverDeliversWhileExpired(t *testing.T) {
	conn, peer, _, _ := preparedComposite(t)
	relayed := conn.LocalAddr().(*net.UDPAddr)

	for i := range 40 {
		result := make(chan error, 1)
		go func() {
			buf := make([]byte, 64)
			_, _, err := conn.ReadFrom(buf)
			result <- err
		}()
		time.Sleep(2 * time.Millisecond) // Let the reader block.

		// Expire the deadline and land a datagram as close together as the
		// scheduler allows.
		if err := conn.SetReadDeadline(time.Now().Add(-time.Second)); err != nil {
			t.Fatalf("iteration %d SetReadDeadline error = %v", i, err)
		}
		if _, err := peer.WriteTo([]byte("racing datagram"), relayed); err != nil {
			t.Fatalf("iteration %d peer WriteTo error = %v", i, err)
		}

		select {
		case err := <-result:
			if !errors.Is(err, os.ErrDeadlineExceeded) {
				t.Fatalf("iteration %d pending read = %v, want deadline error", i, err)
			}
		case <-time.After(5 * time.Second):
			t.Fatalf("iteration %d pending read did not wake", i)
		}

		// Reset and drain so the next iteration starts clean; the racing
		// datagram may have been requeued or dropped, both acceptable.
		if err := conn.SetReadDeadline(time.Now().Add(200 * time.Millisecond)); err != nil {
			t.Fatalf("iteration %d reset error = %v", i, err)
		}
		buf := make([]byte, 64)
		for {
			if _, _, err := conn.ReadFrom(buf); err != nil {
				break
			}
		}
	}
	if err := conn.Close(); err != nil {
		t.Fatalf("Close error = %v", err)
	}
}

// TestExpiredDeadlineThenCloseAlwaysClassifiesClosed pins select priority:
// with both the expired sticky deadline and the terminal seal ready, every
// post-close read must classify as closed, never as a retryable timeout.
func TestExpiredDeadlineThenCloseAlwaysClassifiesClosed(t *testing.T) {
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))
	conn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	if err := conn.SetReadDeadline(time.Now().Add(-time.Second)); err != nil {
		t.Fatalf("SetReadDeadline(past) error = %v", err)
	}
	if err := conn.Close(); err != nil {
		t.Fatalf("Close error = %v", err)
	}
	buf := make([]byte, 16)
	for i := range 200 {
		if _, _, err := conn.ReadFrom(buf); !errors.Is(err, net.ErrClosed) {
			t.Fatalf("post-close ReadFrom attempt %d error = %v, want net.ErrClosed", i, err)
		}
	}
}
