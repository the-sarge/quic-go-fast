package pionturn

import (
	"net"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// observedPacketConn wraps the dedicated base socket so tests can prove the
// composite never mutates base deadlines, closes the base exactly once, and
// emits the expected packet forms.
type observedPacketConn struct {
	net.PacketConn
	deadlineCalls atomic.Int32
	closeCalls    atomic.Int32
	closeOnce     sync.Once
	closedCh      chan struct{}

	mu       sync.Mutex
	outbound [][]byte
}

func (o *observedPacketConn) SetDeadline(t time.Time) error {
	o.deadlineCalls.Add(1)
	return o.PacketConn.SetDeadline(t)
}

func (o *observedPacketConn) SetReadDeadline(t time.Time) error {
	o.deadlineCalls.Add(1)
	return o.PacketConn.SetReadDeadline(t)
}

func (o *observedPacketConn) SetWriteDeadline(t time.Time) error {
	o.deadlineCalls.Add(1)
	return o.PacketConn.SetWriteDeadline(t)
}

func (o *observedPacketConn) Close() error {
	o.closeCalls.Add(1)
	o.closeOnce.Do(func() { close(o.closedCh) })
	return o.PacketConn.Close()
}

func (o *observedPacketConn) WriteTo(payload []byte, addr net.Addr) (int, error) {
	o.mu.Lock()
	o.outbound = append(o.outbound, append([]byte(nil), payload...))
	o.mu.Unlock()
	return o.PacketConn.WriteTo(payload, addr)
}

func (o *observedPacketConn) Outbound() [][]byte {
	o.mu.Lock()
	defer o.mu.Unlock()
	out := make([][]byte, len(o.outbound))
	copy(out, o.outbound)
	return out
}

// installObservedListen swaps the package listen hook so every base socket
// the allocator creates is observed. Tests using it must not run parallel.
func installObservedListen(t *testing.T) <-chan *observedPacketConn {
	t.Helper()
	created := make(chan *observedPacketConn, 8)
	previous := testListenPacket
	testListenPacket = func(network string) (net.PacketConn, error) {
		conn, err := defaultListenPacket(network)
		if err != nil {
			return nil, err
		}
		observed := &observedPacketConn{PacketConn: conn, closedCh: make(chan struct{})}
		created <- observed
		return observed, nil
	}
	t.Cleanup(func() { testListenPacket = previous })
	return created
}
