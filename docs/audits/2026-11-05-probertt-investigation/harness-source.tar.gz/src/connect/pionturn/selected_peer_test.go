package pionturn

import (
	"context"
	"errors"
	"net"
	"net/netip"
	"testing"
	"time"
)

// preparedComposite allocates against a fresh fixture and prepares peerAddr.
func preparedComposite(t *testing.T) (conn *packetConn, peer net.PacketConn, peerAddr netip.AddrPort, fixture *turnFixture) {
	t.Helper()
	fixture = startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))
	relayConn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	t.Cleanup(func() { _ = relayConn.Close() })
	peer, peerAddr = listenPeer(t)
	if err := relayConn.PreparePeer(context.Background(), peerAddr); err != nil {
		t.Fatalf("PreparePeer error = %v", err)
	}
	composite, ok := relayConn.(*packetConn)
	if !ok {
		t.Fatalf("Allocate returned %T, want *packetConn", relayConn)
	}
	return composite, peer, peerAddr, fixture
}

// expectPeerSilence asserts the far peer receives nothing.
func expectPeerSilence(t *testing.T, peer net.PacketConn) {
	t.Helper()
	buf := make([]byte, 64)
	_ = peer.SetReadDeadline(time.Now().Add(150 * time.Millisecond))
	if n, from, err := peer.ReadFrom(buf); err == nil {
		t.Fatalf("peer unexpectedly received %d bytes from %v", n, from)
	}
}

func TestPreparePeerRejectsInvalidPeers(t *testing.T) {
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))
	conn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	t.Cleanup(func() { _ = conn.Close() })

	invalid := []struct {
		name string
		peer netip.AddrPort
	}{
		{name: "zero value", peer: netip.AddrPort{}},
		{name: "zero port", peer: netip.AddrPortFrom(netip.MustParseAddr("127.0.0.1"), 0)},
		{name: "unspecified", peer: netip.MustParseAddrPort("0.0.0.0:9999")},
		{name: "multicast", peer: netip.MustParseAddrPort("224.0.0.1:9999")},
		{name: "zoned", peer: netip.AddrPortFrom(netip.MustParseAddr("fe80::1").WithZone("en0"), 9999)},
	}
	for _, tc := range invalid {
		t.Run(tc.name, func(t *testing.T) {
			if err := conn.PreparePeer(context.Background(), tc.peer); !errors.Is(err, errInvalidPeer) {
				t.Fatalf("PreparePeer(%v) error = %v, want errInvalidPeer", tc.peer, err)
			}
		})
	}
}

func TestPreparePeerCanonicalizesIPv4MappedInput(t *testing.T) {
	conn, _, peerAddr, _ := preparedComposite(t)

	mapped := netip.AddrPortFrom(netip.AddrFrom16(peerAddr.Addr().As16()), peerAddr.Port())
	if !mapped.Addr().Is4In6() {
		t.Fatalf("test setup: %v is not IPv4-mapped", mapped)
	}
	// The mapped spelling canonicalizes to the already-selected peer and
	// coalesces instead of rejecting as a different peer.
	if err := conn.PreparePeer(context.Background(), mapped); err != nil {
		t.Fatalf("PreparePeer(mapped same peer) error = %v, want nil", err)
	}
}

func TestPreparePeerRejectsDifferentPeerAndRetainsOriginal(t *testing.T) {
	conn, peer, peerAddr, _ := preparedComposite(t)

	_, otherAddr := listenPeer(t)
	if err := conn.PreparePeer(context.Background(), otherAddr); !errors.Is(err, errDifferentPeer) {
		t.Fatalf("PreparePeer(different) error = %v, want errDifferentPeer", err)
	}

	// The original selected peer remains the write authority.
	payload := []byte("still original peer")
	if n, err := conn.WriteTo(payload, net.UDPAddrFromAddrPort(peerAddr)); err != nil || n != len(payload) {
		t.Fatalf("WriteTo original peer = (%d, %v), want (%d, nil)", n, err, len(payload))
	}
	buf := make([]byte, 128)
	_ = peer.SetReadDeadline(time.Now().Add(5 * time.Second))
	if _, _, err := peer.ReadFrom(buf); err != nil {
		t.Fatalf("original peer ReadFrom error = %v", err)
	}
}

func TestWriteToZeroOutputNegativeCases(t *testing.T) {
	conn, peer, peerAddr, _ := preparedComposite(t)

	otherUDP := &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: int(peerAddr.Port()) + 1}
	cases := []struct {
		name string
		addr net.Addr
	}{
		{name: "nil address", addr: nil},
		{name: "typed-nil UDP address", addr: (*net.UDPAddr)(nil)},
		{name: "non-UDP address type", addr: &net.TCPAddr{IP: net.ParseIP("127.0.0.1"), Port: int(peerAddr.Port())}},
		{name: "different peer", addr: otherUDP},
		{name: "zoned spelling", addr: &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: int(peerAddr.Port()), Zone: "en0"}},
		{name: "negative raw port", addr: &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: -1}},
		{name: "overflowing raw port truncating to the selected port", addr: &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: 65536 + int(peerAddr.Port())}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			n, err := conn.WriteTo([]byte("must not escape"), tc.addr)
			if n != 0 || err == nil {
				t.Fatalf("WriteTo = (%d, %v), want (0, error)", n, err)
			}
		})
	}
	expectPeerSilence(t, peer)
}

func TestWriteToAliasMutationCannotRedirect(t *testing.T) {
	conn, peer, peerAddr, _ := preparedComposite(t)

	alias := net.UDPAddrFromAddrPort(peerAddr)
	payload := []byte("alias write")
	if n, err := conn.WriteTo(payload, alias); err != nil || n != len(payload) {
		t.Fatalf("WriteTo = (%d, %v), want (%d, nil)", n, err, len(payload))
	}
	// Mutating the caller's address after the call cannot affect the owned
	// canonical value used for later writes.
	alias.IP = net.ParseIP("203.0.113.7")
	alias.Port = 9
	second := []byte("post-mutation write")
	if n, err := conn.WriteTo(second, net.UDPAddrFromAddrPort(peerAddr)); err != nil || n != len(second) {
		t.Fatalf("post-mutation WriteTo = (%d, %v), want (%d, nil)", n, err, len(second))
	}
	buf := make([]byte, 128)
	for _, want := range [][]byte{payload, second} {
		_ = peer.SetReadDeadline(time.Now().Add(5 * time.Second))
		n, _, err := peer.ReadFrom(buf)
		if err != nil {
			t.Fatalf("peer ReadFrom error = %v", err)
		}
		if string(buf[:n]) != string(want) {
			t.Fatalf("peer received %q, want %q", buf[:n], want)
		}
	}
}

func TestWriteBeforePrepareFailsWithoutOutput(t *testing.T) {
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))
	conn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	t.Cleanup(func() { _ = conn.Close() })

	peer, peerAddr := listenPeer(t)
	if n, err := conn.WriteTo([]byte("too early"), net.UDPAddrFromAddrPort(peerAddr)); n != 0 || !errors.Is(err, errNotPrepared) {
		t.Fatalf("pre-prepare WriteTo = (%d, %v), want (0, errNotPrepared)", n, err)
	}
	expectPeerSilence(t, peer)
}
