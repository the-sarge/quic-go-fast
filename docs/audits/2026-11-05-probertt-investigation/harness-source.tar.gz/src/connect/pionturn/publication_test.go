package pionturn

import (
	"context"
	"errors"
	"net"
	"strings"
	"testing"
	"time"
)

// TestAllocateRejectsRecordedBaseFailure orders a real allocation success
// before external socket death, joins the base guard, and only then permits
// construction to finish. No scheduling probability selects this history.
func TestAllocateRejectsRecordedBaseFailure(t *testing.T) {
	observed := installObservedListen(t)
	fixture := startTURNFixture(t)
	a := mustAllocator(t, fixtureConfig(fixture))
	var composite *packetConn
	var base *observedPacketConn
	testBeforePublication = func(c *packetConn) {
		composite = c
		base = <-observed
		_ = base.PacketConn.Close()
		c.adapterWork.Wait()
	}
	t.Cleanup(func() { testBeforePublication = nil })
	conn, err := a.Allocate(context.Background())
	if conn != nil {
		_ = conn.Close()
		t.Fatalf("Allocate after observed base failure: got (%T, %v), want (nil, base failure)", conn, err)
	}
	if !errors.Is(err, errBaseReadPumpFailed) || !errors.Is(err, net.ErrClosed) || !errors.Is(err, ErrForcedClose) {
		t.Fatalf("Allocate error: got %v, want forced close with exact base failure", err)
	}
	assertJoinedAtReturn(t, composite)
	if got := base.closeCalls.Load(); got != 1 {
		t.Fatalf("owned socket closes: got %d, want 1", got)
	}
}

func TestPublicationAdoptsAlreadySelfSealedAllocation(t *testing.T) {
	alloc := newSelfSealAlloc(refreshFailureCause())
	alloc.seal()
	conn, base, _ := newFakeAllocComposite(t, alloc)
	select {
	case <-conn.closeDone:
	case <-time.After(5 * time.Second):
		t.Fatal("self-sealed allocation: got no terminal completion, want joined cleanup")
	}
	closeErr := conn.Close()
	assertSelfSealAggregate(t, closeErr)
	assertJoinedAtReturn(t, conn)
	if got := alloc.closeCalls.Load(); got != 1 {
		t.Fatalf("allocation closes: got %d, want 1", got)
	}
	if got := base.closeCalls.Load(); got != 1 {
		t.Fatalf("owned socket closes: got %d, want 1", got)
	}
	if again := conn.Close(); !errors.Is(again, closeErr) {
		t.Fatalf("repeated Close: got %v, want stable aggregate %v", again, closeErr)
	}
}

func TestPublishedBaseFailureJoinsTerminalCleanup(t *testing.T) {
	observed := installObservedListen(t)
	fixture := startTURNFixture(t)
	a := mustAllocator(t, fixtureConfig(fixture))
	conn, err := a.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate: got %v, want nil", err)
	}
	t.Cleanup(func() { _ = conn.Close() })
	base := <-observed
	_ = base.PacketConn.Close()
	composite := conn.(*packetConn)
	select {
	case <-composite.closeDone:
	case <-time.After(5 * time.Second):
		t.Fatal("published base failure: got no terminal completion, want joined cleanup")
	}
	closeErr := conn.Close()
	if !errors.Is(closeErr, errBaseReadPumpFailed) || !errors.Is(closeErr, net.ErrClosed) || !errors.Is(closeErr, ErrForcedClose) {
		t.Fatalf("Close: got %v, want forced close with exact base failure", closeErr)
	}
	assertJoinedAtReturn(t, composite)
	if got := base.closeCalls.Load(); got != 1 {
		t.Fatalf("owned socket closes: got %d, want 1", got)
	}
	if again := conn.Close(); !errors.Is(again, closeErr) {
		t.Fatalf("repeated Close: got %v, want stable aggregate %v", again, closeErr)
	}
}

func TestAllocateCancellationPreservesRecordedBaseFailure(t *testing.T) {
	observed := installObservedListen(t)
	fixture := startTURNFixture(t)
	a := mustAllocator(t, fixtureConfig(fixture))
	cause := errors.New("caller canceled after allocation success")
	ctx, cancel := context.WithCancelCause(context.Background())
	defer cancel(nil)
	var composite *packetConn
	var base *observedPacketConn
	testBeforePublication = func(c *packetConn) {
		composite = c
		base = <-observed
		_ = base.PacketConn.Close()
		c.adapterWork.Wait()
		cancel(cause)
	}
	t.Cleanup(func() { testBeforePublication = nil })
	conn, err := a.Allocate(ctx)
	if conn != nil {
		_ = conn.Close()
		t.Fatalf("canceled Allocate: got %T, want nil", conn)
	}
	if !errors.Is(err, cause) || !errors.Is(err, errBaseReadPumpFailed) || !errors.Is(err, ErrForcedClose) {
		t.Fatalf("Allocate error: got %v, want exact cancellation and independent forced base failure", err)
	}
	if got := strings.Count(err.Error(), cause.Error()); got != 1 {
		t.Fatalf("cancellation cause occurrences: got %d in %v, want 1", got, err)
	}
	if got := strings.Count(err.Error(), errBaseReadPumpFailed.Error()); got != 1 {
		t.Fatalf("base failure occurrences: got %d in %v, want 1", got, err)
	}
	assertJoinedAtReturn(t, composite)
	if composite.published {
		t.Fatal("rejected construction publication: got true, want false")
	}
	if got := base.closeCalls.Load(); got != 1 {
		t.Fatalf("owned socket closes: got %d, want 1", got)
	}
}
