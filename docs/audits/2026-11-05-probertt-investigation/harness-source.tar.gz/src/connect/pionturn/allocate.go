package pionturn

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"sync"
	"time"

	turn "github.com/the-sarge/turn/v5"

	"github.com/GridSwarm/wiremux/connect"
)

var errInvalidRelayedAddress = errors.New("pionturn: server-reported relayed address is invalid")

// testPermissionRefreshInterval overrides Pion's permission-refresh default in
// tests that observe ChannelData form across refresh; zero keeps the
// dependency default.
var testPermissionRefreshInterval time.Duration

// testListenPacket replaces defaultListenPacket in tests that observe the
// composite never mutating base-socket deadlines or closing it twice; nil in
// production paths.
var testListenPacket func(network string) (net.PacketConn, error)

// testBeforePublication orders base-reader observations after allocation
// success and before construction outcome selection; nil in production.
var testBeforePublication func(*packetConn)

// defaultListenPacket creates the dedicated base socket.
func defaultListenPacket(network string) (net.PacketConn, error) {
	var lc net.ListenConfig
	return lc.ListenPacket(context.Background(), network, ":0")
}

func (a *allocator) Allocate(ctx context.Context) (connect.RelayPacketConn, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("pionturn: allocate canceled before construction: %w", context.Cause(ctx))
	}

	network := "udp4"
	if a.config.Server.Addr().Is6() {
		network = "udp6"
	}
	listen := defaultListenPacket
	if testListenPacket != nil {
		listen = testListenPacket
	}
	rawBase, err := listen(network)
	if err != nil {
		return nil, fmt.Errorf("pionturn: dedicated socket creation failed: %w", err)
	}
	// One once-backed owner collapses the construction cleanup paths and
	// the terminal executor into exactly one underlying close of the
	// dedicated socket.
	base := &onceClosePacketConn{PacketConn: rawBase}

	client, err := turn.NewClient(&turn.ClientConfig{
		Server:                    a.config.Server,
		Username:                  a.config.Username,
		Password:                  a.config.Password,
		Conn:                      base,
		PermissionRefreshInterval: testPermissionRefreshInterval,
	})
	if err != nil {
		closeErr := base.Close()
		return nil, fmt.Errorf("pionturn: client construction failed: %w", errors.Join(err, closeErr))
	}

	conn := newPacketConn(a.config.Server, base, client)
	conn.adapterWork.Add(1)
	go func() {
		defer conn.adapterWork.Done()
		conn.baseSourceGuard()
	}()

	// Cancellation wakes the fork's Allocate natively with the exact ctx
	// cause; the dedicated socket stays untouched until this cleanup so an
	// in-flight retransmit write is never interrupted mid-transaction.
	alloc, allocErr := client.Allocate(ctx)
	if allocErr != nil {
		client.Close()
		closeErr := base.Close()
		conn.adapterWork.Wait()
		var cleanup []error
		if closeErr != nil && !errors.Is(closeErr, net.ErrClosed) {
			cleanup = append(cleanup, closeErr)
		}
		if ctx.Err() != nil {
			evidence := canceledAllocateEvidence(context.Cause(ctx), allocErr, cleanup)
			return nil, fmt.Errorf("pionturn: allocate canceled: %w", errors.Join(evidence...))
		}
		return nil, fmt.Errorf("pionturn: allocation failed: %w", errors.Join(append([]error{allocErr}, cleanup...)...))
	}

	if testBeforePublication != nil {
		testBeforePublication(conn)
	}

	disposeViaLifecycle := func(cause error, forceNow bool) error {
		conn.alloc = alloc
		conn.terminate(cause, forceNow)
		<-conn.closeDone
		return conn.closeErr
	}

	relayed := alloc.RelayedAddr()
	if !validRelayedAddr(relayed) {
		return nil, disposeViaLifecycle(errInvalidRelayedAddress, false)
	}

	if ctx.Err() != nil {
		cause := context.Cause(ctx)
		cleanup := disposeViaLifecycle(cause, false)
		return nil, fmt.Errorf("pionturn: allocate canceled: %w", cleanup)
	}

	if err := conn.publish(alloc, relayed); err != nil {
		return nil, disposeViaLifecycle(err, true)
	}
	return conn, nil
}

// onceClosePacketConn makes the dedicated base socket's Close idempotent
// with one stable result, so every disposal path observes exactly one
// underlying close.
type onceClosePacketConn struct {
	net.PacketConn
	once sync.Once
	err  error
}

func (c *onceClosePacketConn) Close() error {
	c.once.Do(func() { c.err = c.PacketConn.Close() })
	return c.err
}

// canceledAllocateEvidence assembles the canceled-allocate aggregate: the
// exact cancellation cause first and exactly once, the allocate error only
// when it is independent evidence rather than a spelling of the cause (an
// external socket death racing the cancellation is preserved; the owner
// never closes the socket during Allocate, so no allocate error is
// induced), then the remaining cleanup evidence.
func canceledAllocateEvidence(cause, allocErr error, cleanup []error) []error {
	evidence := []error{cause}
	if allocErr != nil && !errors.Is(allocErr, cause) {
		evidence = append(evidence, allocErr)
	}
	return append(evidence, cleanup...)
}

// validRelayedAddr re-validates the fork-canonicalized relayed address as
// defense in depth: invalid, zero-port, unspecified, multicast, zoned, and
// IPv4-mapped allocation addresses fail construction rather than being
// trusted.
func validRelayedAddr(ap netip.AddrPort) bool {
	if !ap.IsValid() || ap.Port() == 0 {
		return false
	}
	addr := ap.Addr()
	return !addr.IsUnspecified() && !addr.IsMulticast() && addr.Zone() == "" && !addr.Is4In6()
}
