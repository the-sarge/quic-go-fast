package pionturn

import (
	"context"
	"crypto/rand"
	"errors"
	"net"
	"os"
	"testing"
	"time"
)

// TestBaseSourceGuardDiscardsSecondSender proves the composite admits base
// traffic only from the exact configured server: valid-looking ChannelData
// and STUN-indication datagrams from a second UDP sender are discarded with
// zero Pion or composite delivery, while real configured-server traffic
// still flows.
func TestBaseSourceGuardDiscardsSecondSender(t *testing.T) {
	observed := installObservedListen(t)
	fixture := startTURNFixture(t)
	allocator := mustAllocator(t, fixtureConfig(fixture))
	relayConn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	t.Cleanup(func() { _ = relayConn.Close() })
	base := <-observed

	peer, peerAddr := listenPeer(t)
	if err := relayConn.PreparePeer(context.Background(), peerAddr); err != nil {
		t.Fatalf("PreparePeer error = %v", err)
	}

	basePort := base.LocalAddr().(*net.UDPAddr).Port
	baseTarget := &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: basePort}

	attacker, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("attacker listen: %v", err)
	}
	t.Cleanup(func() { _ = attacker.Close() })

	// Valid-looking ChannelData on the first bound channel number.
	channelData := []byte{0x40, 0x00, 0x00, 0x04, 'e', 'v', 'i', 'l'}
	// Valid-looking STUN data indication: type 0x0017, magic cookie, random
	// transaction ID, zero-length body.
	indication := make([]byte, 20)
	indication[0], indication[1] = 0x00, 0x17
	indication[4], indication[5], indication[6], indication[7] = 0x21, 0x12, 0xA4, 0x42
	if _, err := rand.Read(indication[8:]); err != nil {
		t.Fatalf("transaction id: %v", err)
	}
	for _, packet := range [][]byte{channelData, indication} {
		if _, err := attacker.WriteTo(packet, baseTarget); err != nil {
			t.Fatalf("attacker WriteTo error = %v", err)
		}
	}

	// Zero composite delivery: the read deadline expires instead.
	if err := relayConn.SetReadDeadline(time.Now().Add(300 * time.Millisecond)); err != nil {
		t.Fatalf("SetReadDeadline error = %v", err)
	}
	buf := make([]byte, 128)
	if n, from, err := relayConn.ReadFrom(buf); !errors.Is(err, os.ErrDeadlineExceeded) {
		t.Fatalf("ReadFrom after injection = (%d, %v, %v), want deadline expiry", n, from, err)
	}

	// The guard does not over-drop: real relayed traffic still arrives.
	if err := relayConn.SetReadDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatalf("SetReadDeadline(reset) error = %v", err)
	}
	relayed := relayConn.LocalAddr().(*net.UDPAddr)
	if _, err := peer.WriteTo([]byte("genuine"), relayed); err != nil {
		t.Fatalf("peer WriteTo error = %v", err)
	}
	if n, _, err := relayConn.ReadFrom(buf); err != nil || string(buf[:n]) != "genuine" {
		t.Fatalf("ReadFrom = (%q, %v), want (\"genuine\", nil)", buf[:n], err)
	}
}
