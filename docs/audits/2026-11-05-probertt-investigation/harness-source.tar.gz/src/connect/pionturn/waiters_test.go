package pionturn

import (
	"context"
	"encoding/binary"
	"errors"
	"net"
	"net/netip"
	"sync"
	"testing"
	"time"
)

// dropPermissionProxy forwards UDP datagrams between the composite and the
// fixture server but silently drops CreatePermission requests, keeping
// shared peer preparation in flight against real retransmission machinery.
type dropPermissionProxy struct {
	front  net.PacketConn
	server *net.UDPAddr
	// passFirst forwards the first CreatePermission request and drops the
	// rest, so initial preparation succeeds while permission refresh stays
	// in flight against real retransmission machinery.
	passFirst bool

	mu          sync.Mutex
	client      net.Addr
	permissions int
}

func startDropPermissionProxy(t *testing.T, server netip.AddrPort) netip.AddrPort {
	t.Helper()
	_, addr := startPermissionProxy(t, server, false)
	return addr
}

func startRefreshDropProxy(t *testing.T, server netip.AddrPort) (*dropPermissionProxy, netip.AddrPort) {
	t.Helper()
	return startPermissionProxy(t, server, true)
}

func startPermissionProxy(t *testing.T, server netip.AddrPort, passFirst bool) (*dropPermissionProxy, netip.AddrPort) {
	t.Helper()
	front, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("proxy listen: %v", err)
	}
	proxy := &dropPermissionProxy{front: front, server: net.UDPAddrFromAddrPort(server), passFirst: passFirst}
	go proxy.run()
	t.Cleanup(func() { _ = front.Close() })
	addr, ok := canonicalUDPAddr(front.LocalAddr())
	if !ok {
		t.Fatalf("proxy local address %v is not canonical", front.LocalAddr())
	}
	return proxy, addr
}

// waitForPermissionRequests polls until the proxy has seen at least want
// CreatePermission requests from the client.
func (p *dropPermissionProxy) waitForPermissionRequests(t *testing.T, want int, timeout time.Duration) bool {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for {
		p.mu.Lock()
		seen := p.permissions
		p.mu.Unlock()
		if seen >= want {
			return true
		}
		if time.Now().After(deadline) {
			return false
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func (p *dropPermissionProxy) run() {
	buf := make([]byte, 65536)
	for {
		n, from, err := p.front.ReadFrom(buf)
		if err != nil {
			return
		}
		fromUDP, ok := from.(*net.UDPAddr)
		if !ok {
			continue
		}
		if fromUDP.AddrPort() == p.server.AddrPort() {
			p.mu.Lock()
			client := p.client
			p.mu.Unlock()
			if client != nil {
				_, _ = p.front.WriteTo(buf[:n], client)
			}
			continue
		}
		p.mu.Lock()
		p.client = fromUDP
		drop := false
		if isCreatePermissionRequest(buf[:n]) {
			p.permissions++
			drop = !p.passFirst || p.permissions > 1
		}
		p.mu.Unlock()
		if drop {
			continue
		}
		_, _ = p.front.WriteTo(buf[:n], p.server)
	}
}

func isCreatePermissionRequest(data []byte) bool {
	if len(data) < 20 {
		return false
	}
	if binary.BigEndian.Uint32(data[4:8]) != 0x2112A442 {
		return false
	}
	return binary.BigEndian.Uint16(data[:2]) == 0x0008
}

func TestCrossedWaiterCancellationStaysWaiterLocal(t *testing.T) {
	fixture := startTURNFixture(t)
	proxyAddr := startDropPermissionProxy(t, fixture.Addr)
	allocator := mustAllocator(t, Config{Server: proxyAddr, Username: fixtureUsername, Password: fixturePassword})

	conn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate through proxy error = %v", err)
	}
	_, peerAddr := listenPeer(t)

	resultA := make(chan error, 1)
	go func() { resultA <- conn.PreparePeer(context.Background(), peerAddr) }()

	ctxB, cancelB := context.WithCancelCause(context.Background())
	defer cancelB(nil)
	resultB := make(chan error, 1)
	go func() { resultB <- conn.PreparePeer(ctxB, peerAddr) }()

	time.Sleep(200 * time.Millisecond) // Let the CreatePermission transaction get in flight.

	cause := errors.New("waiter B gave up")
	cancelB(cause)
	select {
	case err := <-resultB:
		if !errors.Is(err, cause) {
			t.Fatalf("canceled waiter error = %v, want exact cause %v", err, cause)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("canceled waiter did not wake promptly")
	}

	// The surviving waiter and shared preparation are unaffected.
	select {
	case err := <-resultA:
		t.Fatalf("surviving waiter finished early with %v", err)
	case <-time.After(300 * time.Millisecond):
	}

	// Close during the in-flight bind wakes the survivor with the stable
	// closed classification and still completes gracefully: the socket and
	// the Pion close driver remain responsive through the proxy.
	start := time.Now()
	if err := conn.Close(); err != nil {
		t.Fatalf("Close during bind error = %v", err)
	}
	if elapsed := time.Since(start); elapsed >= gracefulCloseWindow {
		t.Fatalf("Close during bind took %v, want < %v", elapsed, gracefulCloseWindow)
	}
	select {
	case err := <-resultA:
		if !errors.Is(err, net.ErrClosed) {
			t.Fatalf("surviving waiter error after close = %v, want net.ErrClosed", err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("surviving waiter did not unblock on close")
	}
	if !fixture.WaitForAllocationCount(0, 5*time.Second) {
		t.Fatal("server allocation did not delete after close during bind")
	}
}

// TestCloseDuringInFlightPermissionRefresh closes the composite while a
// permission-refresh transaction is retransmitting against a proxy that
// forwarded only the initial CreatePermission. The socket and the Pion close
// driver stay responsive, so the close remains graceful and the server
// deletes the allocation.
func TestCloseDuringInFlightPermissionRefresh(t *testing.T) {
	previous := testPermissionRefreshInterval
	testPermissionRefreshInterval = 150 * time.Millisecond
	t.Cleanup(func() { testPermissionRefreshInterval = previous })

	fixture := startTURNFixture(t)
	proxyHandle, proxyAddr := startRefreshDropProxy(t, fixture.Addr)
	allocator := mustAllocator(t, Config{Server: proxyAddr, Username: fixtureUsername, Password: fixturePassword})

	conn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate through proxy error = %v", err)
	}
	_, peerAddr := listenPeer(t)
	if err := conn.PreparePeer(context.Background(), peerAddr); err != nil {
		t.Fatalf("PreparePeer error = %v", err)
	}

	// Gate on the proxy observing (and dropping) a permission-refresh
	// CreatePermission beyond the forwarded initial one, so the refresh
	// transaction is provably in flight and retransmitting at Close.
	if !proxyHandle.waitForPermissionRequests(t, 2, 5*time.Second) {
		t.Fatal("no permission-refresh CreatePermission observed in flight")
	}

	start := time.Now()
	if err := conn.Close(); err != nil {
		t.Fatalf("Close during refresh error = %v", err)
	}
	if elapsed := time.Since(start); elapsed >= gracefulCloseWindow {
		t.Fatalf("Close during refresh took %v, want < %v", elapsed, gracefulCloseWindow)
	}
	if !fixture.WaitForAllocationCount(0, 5*time.Second) {
		t.Fatal("server allocation did not delete after close during refresh")
	}
}

func TestSharedPreparationFailureTerminalizes(t *testing.T) {
	fixture := startTURNFixture(t, fixtureDenyPermissionsEnv+"=1")
	allocator := mustAllocator(t, fixtureConfig(fixture))
	conn, err := allocator.Allocate(context.Background())
	if err != nil {
		t.Fatalf("Allocate error = %v", err)
	}
	_, peerAddr := listenPeer(t)

	err = conn.PreparePeer(context.Background(), peerAddr)
	if !errors.Is(err, errPreparationFailed) {
		t.Fatalf("PreparePeer error = %v, want wrapping errPreparationFailed", err)
	}

	// The shared failure terminalizes readiness and the composite: writes
	// and further preparation fail, and the terminal path has run.
	if _, werr := conn.WriteTo([]byte("x"), net.UDPAddrFromAddrPort(peerAddr)); !errors.Is(werr, net.ErrClosed) {
		t.Fatalf("post-failure WriteTo error = %v, want net.ErrClosed", werr)
	}
	if perr := conn.PreparePeer(context.Background(), peerAddr); !errors.Is(perr, net.ErrClosed) {
		t.Fatalf("post-failure PreparePeer error = %v, want net.ErrClosed", perr)
	}
	closeErr := conn.Close()
	if !errors.Is(closeErr, errPreparationFailed) {
		t.Fatalf("Close aggregate = %v, want it to carry the preparation failure", closeErr)
	}
	if !fixture.WaitForAllocationCount(0, 5*time.Second) {
		t.Fatal("server allocation did not delete after terminal preparation failure")
	}
}

func TestConcurrentCloseReturnsOneStableAggregate(t *testing.T) {
	conn, _, _, _ := preparedComposite(t)

	const closers = 4
	results := make(chan error, closers)
	for range closers {
		go func() { results <- conn.Close() }()
	}
	first := <-results
	for i := 1; i < closers; i++ {
		// The stable aggregate is one error value; identity satisfies
		// errors.Is for nil and non-nil aggregates alike.
		if got := <-results; !errors.Is(got, first) {
			t.Fatalf("concurrent Close returned %v, want the stable aggregate %v", got, first)
		}
	}
}
