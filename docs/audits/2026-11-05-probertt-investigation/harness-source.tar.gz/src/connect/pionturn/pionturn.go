// Package pionturn provides the official wiremux TURN/UDP packet allocator
// backed by the tagged github.com/the-sarge/turn/v5 dependency.
//
// NewAllocator performs no network I/O. Each Allocate call creates one
// dedicated UDP socket in the configured server literal's address family and
// one TURN allocation, and returns a composite that exclusively owns that
// socket's deadlines and close.
package pionturn

import (
	"errors"
	"fmt"
	"net/netip"

	"github.com/GridSwarm/wiremux/connect"
)

// ErrForcedClose classifies a locally complete forced socket interruption
// because the Pion close driver did not return within the graceful window.
// It makes no claim about server acknowledgement or deletion; any
// unacknowledged allocation may persist until server expiry.
var ErrForcedClose = errors.New("pionturn: forced close interrupted the graceful deallocation window")

// Config configures the allocator. Server must be a valid IP-literal
// address with a nonzero port that is neither unspecified nor multicast and
// has no zone; IPv4-mapped IPv6 values reject rather than silently choosing
// a socket family. Loopback and private addresses remain valid for tests and
// private TURN. Callers resolve DNS names before construction. Username and
// Password are 1-512 visible ASCII bytes.
type Config struct {
	Server   netip.AddrPort
	Username string
	Password string
}

// NewAllocator validates cfg and returns an immutable, concurrently
// reusable allocator. It performs no network I/O.
func NewAllocator(cfg Config) (connect.RelayPacketAllocator, error) {
	if err := validateServer(cfg.Server); err != nil {
		return nil, err
	}
	if err := validateCredential("username", cfg.Username); err != nil {
		return nil, err
	}
	if err := validateCredential("password", cfg.Password); err != nil {
		return nil, err
	}
	return &allocator{config: cfg}, nil
}

// allocator is immutable after construction; Config.Server is retained as
// one canonical netip.AddrPort value.
type allocator struct {
	config Config
}

func validateServer(server netip.AddrPort) error {
	addr := server.Addr()
	switch {
	case !server.IsValid():
		return errors.New("pionturn: server address is not a valid IP literal and port")
	case server.Port() == 0:
		return errors.New("pionturn: server port must be nonzero")
	case addr.IsUnspecified():
		return errors.New("pionturn: server address must not be unspecified")
	case addr.IsMulticast():
		return errors.New("pionturn: server address must not be multicast")
	case addr.Zone() != "":
		return errors.New("pionturn: server address must not carry a zone")
	case addr.Is4In6():
		return errors.New("pionturn: IPv4-mapped IPv6 server addresses are rejected; use the IPv4 literal")
	default:
		return nil
	}
}

// validateCredential enforces 1-512 visible ASCII bytes (0x21-0x7E): NUL,
// controls, whitespace, DEL, and non-ASCII bytes reject. Credential values
// never appear in the error.
func validateCredential(field, value string) error {
	if len(value) == 0 {
		return fmt.Errorf("pionturn: %s must not be empty", field)
	}
	if len(value) > 512 {
		return fmt.Errorf("pionturn: %s exceeds 512 bytes", field)
	}
	for i := range len(value) {
		if value[i] < 0x21 || value[i] > 0x7e {
			return fmt.Errorf("pionturn: %s byte %d is not visible ASCII", field, i)
		}
	}
	return nil
}
