package pionturn

import (
	"net/netip"
	"strings"
	"testing"
)

func validConfig() Config {
	return Config{
		Server:   netip.MustParseAddrPort("127.0.0.1:3478"),
		Username: "user",
		Password: "secret",
	}
}

func TestNewAllocatorConfigValidation(t *testing.T) {
	t.Parallel()

	longestCredential := strings.Repeat("a", 512)

	cases := []struct {
		name   string
		mutate func(*Config)
		valid  bool
	}{
		{name: "canonical IPv4 loopback", mutate: func(*Config) {}, valid: true},
		{name: "canonical IPv6", mutate: func(c *Config) { c.Server = netip.MustParseAddrPort("[::1]:3478") }, valid: true},
		{name: "private IPv4", mutate: func(c *Config) { c.Server = netip.MustParseAddrPort("192.168.1.10:3478") }, valid: true},
		{name: "512-byte credentials", mutate: func(c *Config) { c.Username = longestCredential; c.Password = longestCredential }, valid: true},
		{name: "full visible-ASCII credential range", mutate: func(c *Config) { c.Username = "!aZ~9#"; c.Password = "p@ss!" }, valid: true},
		{name: "zero server", mutate: func(c *Config) { c.Server = netip.AddrPort{} }, valid: false},
		{name: "zero port", mutate: func(c *Config) { c.Server = netip.AddrPortFrom(netip.MustParseAddr("127.0.0.1"), 0) }, valid: false},
		{name: "unspecified IPv4", mutate: func(c *Config) { c.Server = netip.MustParseAddrPort("0.0.0.0:3478") }, valid: false},
		{name: "unspecified IPv6", mutate: func(c *Config) { c.Server = netip.MustParseAddrPort("[::]:3478") }, valid: false},
		{name: "multicast IPv4", mutate: func(c *Config) { c.Server = netip.MustParseAddrPort("224.0.0.1:3478") }, valid: false},
		{name: "multicast IPv6", mutate: func(c *Config) { c.Server = netip.MustParseAddrPort("[ff02::1]:3478") }, valid: false},
		{name: "zoned IPv6", mutate: func(c *Config) { c.Server = netip.MustParseAddrPort("[fe80::1%en0]:3478") }, valid: false},
		{name: "IPv4-mapped IPv6", mutate: func(c *Config) { c.Server = netip.MustParseAddrPort("[::ffff:127.0.0.1]:3478") }, valid: false},
		{name: "empty username", mutate: func(c *Config) { c.Username = "" }, valid: false},
		{name: "empty password", mutate: func(c *Config) { c.Password = "" }, valid: false},
		{name: "513-byte username", mutate: func(c *Config) { c.Username = longestCredential + "a" }, valid: false},
		{name: "513-byte password", mutate: func(c *Config) { c.Password = longestCredential + "a" }, valid: false},
		{name: "NUL in username", mutate: func(c *Config) { c.Username = "user\x00name" }, valid: false},
		{name: "control byte in password", mutate: func(c *Config) { c.Password = "pass\nword" }, valid: false},
		{name: "space in username", mutate: func(c *Config) { c.Username = "user name" }, valid: false},
		{name: "tab in password", mutate: func(c *Config) { c.Password = "pass\tword" }, valid: false},
		{name: "DEL byte in username", mutate: func(c *Config) { c.Username = "user\x7f" }, valid: false},
		{name: "non-ASCII username", mutate: func(c *Config) { c.Username = "usér" }, valid: false},
		{name: "high-bit byte in password", mutate: func(c *Config) { c.Password = "pass\x80" }, valid: false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			cfg := validConfig()
			tc.mutate(&cfg)
			allocator, err := NewAllocator(cfg)
			if tc.valid {
				if err != nil {
					t.Fatalf("NewAllocator(%+v) error = %v, want nil", cfg, err)
				}
				if allocator == nil {
					t.Fatal("NewAllocator returned nil allocator for valid config")
				}
				return
			}
			if err == nil {
				t.Fatalf("NewAllocator(%+v) error = nil, want rejection", cfg)
			}
			if allocator != nil {
				t.Fatalf("NewAllocator returned non-nil allocator %T with error", allocator)
			}
		})
	}
}
