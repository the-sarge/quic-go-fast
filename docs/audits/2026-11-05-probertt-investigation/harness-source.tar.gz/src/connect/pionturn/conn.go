package pionturn

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"os"
	"sync"
	"time"

	"github.com/pion/transport/v4/deadline"
	turn "github.com/the-sarge/turn/v5"

	"github.com/GridSwarm/wiremux/internal/relayprofile"
)

// relayAllocation is the fork allocation surface the composite consumes.
// *turn.Allocation satisfies it; lifecycle tests substitute a local fake.
type relayAllocation interface {
	PreparePeer(ctx context.Context, peer netip.AddrPort) error
	ReadFrom(p []byte) (int, netip.AddrPort, error)
	WriteTo(payload []byte, peer netip.AddrPort) (int, error)
	Close() error
}

var _ relayAllocation = (*turn.Allocation)(nil)

// gracefulCloseWindow is the fixed private window the terminal executor
// grants the Pion close driver before forcing base-socket interruption.
const gracefulCloseWindow = 2 * time.Second

// readQueueDepth bounds composite-owned buffering between the Pion
// allocation read queue and consumer ReadFrom callers.
const readQueueDepth = 8

var (
	errClosed             = fmt.Errorf("pionturn: composite is closed: %w", net.ErrClosed)
	errNotPrepared        = errors.New("pionturn: write requires a successfully prepared selected peer")
	errInvalidPeer        = errors.New("pionturn: peer address is invalid")
	errDifferentPeer      = errors.New("pionturn: a different peer is already selected")
	errInvalidWriteAddr   = errors.New("pionturn: write address must be a non-nil *net.UDPAddr matching the selected peer")
	errDeadlineUnsupport  = fmt.Errorf("pionturn: write and combined deadlines are not supported: %w", errors.ErrUnsupported)
	errPreparationFailed  = errors.New("pionturn: shared peer preparation failed")
	errBaseReadPumpFailed = errors.New("pionturn: dedicated base socket read pump failed")
	errAllocationSealed   = errors.New("pionturn: allocation sealed itself before the composite close")
	errAllocationClosed   = errors.New("pionturn: allocation closed under peer preparation")
)

// readDeadlineError implements net.Error for the logical read deadline.
type readDeadlineError struct{}

func (readDeadlineError) Error() string   { return "pionturn: logical read deadline exceeded" }
func (readDeadlineError) Timeout() bool   { return true }
func (readDeadlineError) Temporary() bool { return true }
func (readDeadlineError) Unwrap() error   { return os.ErrDeadlineExceeded }

// readItem is one admitted selected-peer datagram.
type readItem struct {
	payload []byte
}

// packetConn is the official relay packet composite. It exclusively owns its
// dedicated base socket, logical consumer deadlines, graceful-window timer,
// terminal close driver, aggregate result, and immutable server, relayed,
// and selected-peer addresses. Pion owns only protocol state and its
// internal workers.
type packetConn struct {
	server  netip.AddrPort
	relayed netip.AddrPort

	base   net.PacketConn
	client *turn.Client
	alloc  relayAllocation

	readDeadline *deadline.Deadline
	readQueue    chan readItem

	// adapterWork tracks the composite-owned base and consumer read pumps.
	adapterWork sync.WaitGroup

	mu sync.Mutex
	// published and pumpFailure share mu: a recorded base failure either
	// rejects construction or routes through the published terminal owner.
	published   bool
	selected    netip.AddrPort
	selectedSet bool
	ready       bool
	prepFailure error
	pumpFailure error
	// allocSealCause is the exact allocation-plane read failure the consumer
	// pump observed before the composite seal: the fork's allocation
	// self-seal (for example a permanent refresh failure). It is the
	// composite's terminal cause for that class and is what in-flight
	// PreparePeer waiters that observe the resulting seal wake with.
	allocSealCause error
	// ownerClosedBase orders base-socket death against the terminal
	// executor's own interruption: a pump failure recorded before the owner
	// closed the base is external terminal evidence; one after is induced.
	ownerClosedBase bool
	waiters         map[*prepWaiter]struct{}
	sealed          bool

	sealedCh  chan struct{}
	closeDone chan struct{}
	closeOnce sync.Once
	closeErr  error
}

type prepWaiter struct {
	cancel context.CancelCauseFunc
}

var _ relayprofile.Provider = (*packetConn)(nil)

// WiremuxRelayProfile marks the composite as the official relay packet
// carrier. relayprofile owns marker validity.
func (c *packetConn) WiremuxRelayProfile() relayprofile.Token {
	return relayprofile.TURNQUIC3()
}

func newPacketConn(server netip.AddrPort, base net.PacketConn, client *turn.Client) *packetConn {
	conn := &packetConn{
		server:       server,
		base:         base,
		client:       client,
		readDeadline: deadline.New(),
		readQueue:    make(chan readItem, readQueueDepth),
		waiters:      make(map[*prepWaiter]struct{}),
		sealedCh:     make(chan struct{}),
		closeDone:    make(chan struct{}),
	}
	return conn
}

// publish adopts a successful allocation and validated immutable address.
// A previously recorded base failure leaves construction unpublished and
// disposal with the allocator. Otherwise registration precedes publication,
// and launch follows it, so every published terminal path joins the pump.
// The caller retains its existing choice of whether to start the base guard.
func (c *packetConn) publish(alloc relayAllocation, relayed netip.AddrPort) error {
	c.mu.Lock()
	if c.pumpFailure != nil {
		failure := c.pumpFailure
		c.mu.Unlock()
		return failure
	}
	c.alloc = alloc
	c.relayed = relayed
	c.adapterWork.Add(1)
	c.published = true
	c.mu.Unlock()
	go func() {
		defer c.adapterWork.Done()
		c.consumerPump()
	}()
	return nil
}

// consumerPump drains the Pion allocation read queue, admits only the
// canonical selected peer, and hands admitted payloads to ReadFrom callers.
// It is also the allocation-plane terminal trigger router, exactly as the
// base source guard is for the base plane.
func (c *packetConn) consumerPump() {
	buf := make([]byte, 65536)
	for {
		n, from, err := c.alloc.ReadFrom(buf)
		if err != nil {
			// The allocation read queue terminalizes either because the
			// terminal executor drove Pion close (owner-driven, after the
			// composite seal) or because the allocation sealed itself (for
			// example a permanent refresh failure) before any composite
			// terminal path ran. The seal flag discriminates the two: an
			// owner-driven close is already terminal and the pump only
			// exits; a self-seal is a terminal trigger carrying the exact
			// observed cause, so blocked consumers wake and the aggregate
			// preserves that cause. The composite is published before the
			// pump starts, so no construction-time failure reaches here.
			c.mu.Lock()
			sealed := c.sealed
			var failure error
			if !sealed {
				failure = fmt.Errorf("%w: %w", errAllocationSealed, err)
				c.allocSealCause = failure
			}
			c.mu.Unlock()
			if !sealed {
				// The base stayed responsive: the driver takes the graceful
				// path and the executor forces only if it cannot return.
				c.terminate(failure, false)
			}
			return
		}
		// The fork returns canonical peers; admission compares against the
		// canonical selected peer directly.
		if !c.peerAdmitted(from) {
			continue
		}
		item := readItem{payload: append([]byte(nil), buf[:n]...)}
		select {
		case c.readQueue <- item:
		case <-c.sealedCh:
			return
		}
	}
}

func (c *packetConn) peerAdmitted(peer netip.AddrPort) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.selectedSet && c.ready && peer == c.selected
}

// baseSourceGuard reads the dedicated base socket, canonicalizes the actual
// UDP source of every datagram, and delivers only exact configured-server
// traffic to Pion HandleInbound. It is started before allocation.
func (c *packetConn) baseSourceGuard() {
	buf := make([]byte, 65536)
	for {
		n, from, err := c.base.ReadFrom(buf)
		if err != nil {
			// Record the failure regardless of who wins the terminal race
			// so an explicit Close racing external base death cannot
			// discard the cause. A failure after the owner's own base
			// close is induced and is not evidence.
			failure := fmt.Errorf("%w: %w", errBaseReadPumpFailed, err)
			c.mu.Lock()
			if !c.ownerClosedBase {
				c.pumpFailure = failure
			}
			sealed := c.sealed
			published := c.published
			c.mu.Unlock()
			if published && !sealed {
				// Base death is a terminal trigger; the base is already
				// unusable, so the executor forces immediately.
				c.terminate(failure, true)
			}
			return
		}
		source, ok := canonicalUDPAddr(from)
		if !ok || source != c.server {
			continue
		}
		if err := c.client.HandleInbound(buf[:n], from); err != nil {
			// Malformed or unexpected protocol input is discarded; the
			// composite terminalizes only on base death, allocation
			// self-seal, shared preparation failure, or close triggers.
			continue
		}
	}
}

// canonicalUDPAddr canonicalizes a datagram source or peer address under the
// composite's validity rules: a non-nil *net.UDPAddr whose IP is valid,
// nonzero-port, not unspecified, not multicast, and without a zone,
// IPv4-mapped values unmapped.
func canonicalUDPAddr(addr net.Addr) (netip.AddrPort, bool) {
	udpAddr, ok := addr.(*net.UDPAddr)
	if !ok || udpAddr == nil {
		return netip.AddrPort{}, false
	}
	// netip drops zones on IPv4 addresses, so check the caller's spelling
	// before conversion: the validity rules admit no zone at all.
	if udpAddr.Zone != "" {
		return netip.AddrPort{}, false
	}
	// UDPAddr.AddrPort truncates ports outside uint16, so an out-of-range
	// raw port could otherwise canonicalize equal to a valid peer.
	if udpAddr.Port < 1 || udpAddr.Port > 65535 {
		return netip.AddrPort{}, false
	}
	ap := udpAddr.AddrPort()
	if !ap.IsValid() {
		return netip.AddrPort{}, false
	}
	canonical := netip.AddrPortFrom(ap.Addr().Unmap(), ap.Port())
	addrPart := canonical.Addr()
	if canonical.Port() == 0 || addrPart.IsUnspecified() || addrPart.IsMulticast() || addrPart.Zone() != "" {
		return netip.AddrPort{}, false
	}
	return canonical, true
}

// canonicalPeer validates and canonicalizes a caller-supplied selected peer.
func canonicalPeer(peer netip.AddrPort) (netip.AddrPort, bool) {
	if !peer.IsValid() || peer.Port() == 0 {
		return netip.AddrPort{}, false
	}
	canonical := netip.AddrPortFrom(peer.Addr().Unmap(), peer.Port())
	addrPart := canonical.Addr()
	if addrPart.IsUnspecified() || addrPart.IsMulticast() || addrPart.Zone() != "" {
		return netip.AddrPort{}, false
	}
	return canonical, true
}

func freshUDPAddr(ap netip.AddrPort) *net.UDPAddr {
	return net.UDPAddrFromAddrPort(ap)
}

// LocalAddr returns a fresh *net.UDPAddr derived from the immutable
// canonical relayed address; caller mutation cannot affect later calls.
func (c *packetConn) LocalAddr() net.Addr {
	return freshUDPAddr(c.relayed)
}

// PreparePeer atomically selects exactly one canonical peer and returns
// after Pion confirms readiness. Same-peer callers coalesce; canceling one
// caller wakes only that waiter with its exact cause.
func (c *packetConn) PreparePeer(ctx context.Context, peer netip.AddrPort) error {
	if ctx == nil {
		ctx = context.Background()
	}
	canonical, ok := canonicalPeer(peer)
	if !ok {
		return errInvalidPeer
	}

	c.mu.Lock()
	if c.sealed {
		c.mu.Unlock()
		return errClosed
	}
	if c.prepFailure != nil {
		err := c.prepFailure
		c.mu.Unlock()
		return err
	}
	if c.selectedSet && c.selected != canonical {
		c.mu.Unlock()
		return errDifferentPeer
	}
	if !c.selectedSet {
		c.selected = canonical
		c.selectedSet = true
	}
	if c.ready {
		c.mu.Unlock()
		return nil
	}
	waiterCtx, waiterCancel := context.WithCancelCause(ctx)
	waiter := &prepWaiter{cancel: waiterCancel}
	c.waiters[waiter] = struct{}{}
	c.mu.Unlock()
	defer func() {
		waiterCancel(nil)
		c.mu.Lock()
		delete(c.waiters, waiter)
		c.mu.Unlock()
	}()

	err := c.alloc.PreparePeer(waiterCtx, canonical)

	c.mu.Lock()
	if err == nil {
		if c.sealed {
			err := c.waiterSealedErrorLocked()
			c.mu.Unlock()
			return err
		}
		c.ready = true
		c.mu.Unlock()
		return nil
	}
	if c.sealed {
		err := c.waiterSealedErrorLocked()
		c.mu.Unlock()
		return err
	}
	if waiterCtx.Err() != nil {
		c.mu.Unlock()
		// Waiter-local cancellation: return the exact cause and leave the
		// shared operation, other waiters, and the composite unaffected.
		return context.Cause(waiterCtx)
	}
	if inducedSocketClose(err) {
		c.mu.Unlock()
		// A closed-shaped failure under a live waiter on an unsealed
		// composite means the allocation is closed beneath it, but the shape
		// does not say why: the fork's self-seal wakes in-flight preparation
		// with net.ErrClosed (with or without the recorded cause, depending
		// on whether the read queue or the transaction abort woke it), and
		// a dead dedicated socket fails the transaction write with the same
		// shape. Only the plane observers can discriminate: the consumer
		// pump sees the allocation read queue close exactly when the
		// allocation is closed, and the base source guard sees the dead
		// socket. The waiter therefore neither classifies nor terminalizes;
		// it wakes with the closed classification and its observed cause and
		// leaves terminalization to the observer that fires, so no waiter
		// can misattribute a seal as a shared preparation failure or a base
		// death as a seal.
		return fmt.Errorf("%w: %w", errAllocationClosed, err)
	}
	// A shared Pion preparation failure terminalizes readiness and the
	// composite.
	failure := fmt.Errorf("%w: %w", errPreparationFailed, err)
	c.prepFailure = failure
	c.mu.Unlock()
	c.terminate(failure, false)
	return failure
}

// waiterSealedErrorLocked is the result for an in-flight PreparePeer waiter
// that observes the composite seal: the recorded allocation self-seal cause
// when that trigger sealed the composite (it wraps net.ErrClosed, so the
// closed classification is preserved), otherwise the stable closed error.
// New PreparePeer calls after the seal always return the closed error.
func (c *packetConn) waiterSealedErrorLocked() error {
	if c.allocSealCause != nil {
		return c.allocSealCause
	}
	return errClosed
}

// WriteTo accepts only a non-nil *net.UDPAddr that canonicalizes to the
// prepared selected peer; every other write returns zero bytes with no
// network output.
func (c *packetConn) WriteTo(payload []byte, addr net.Addr) (int, error) {
	c.mu.Lock()
	if c.sealed {
		c.mu.Unlock()
		return 0, errClosed
	}
	if !c.selectedSet || !c.ready {
		c.mu.Unlock()
		return 0, errNotPrepared
	}
	selected := c.selected
	c.mu.Unlock()

	udpAddr, ok := addr.(*net.UDPAddr)
	if !ok || udpAddr == nil {
		return 0, errInvalidWriteAddr
	}
	canonical, ok := canonicalUDPAddr(udpAddr)
	if !ok || canonical != selected {
		return 0, errInvalidWriteAddr
	}
	return c.alloc.WriteTo(payload, selected)
}

// ReadFrom returns admitted selected-peer payloads with a fresh exact peer
// address. While an installed logical deadline remains expired, every
// pending and newly started read fails with an error wrapping
// os.ErrDeadlineExceeded without terminalizing the pump or protocol work.
func (c *packetConn) ReadFrom(p []byte) (int, net.Addr, error) {
	for {
		// Deterministic precedence between ready channels (select order is
		// random): terminal closure wins over the sticky expired deadline,
		// and the expired deadline wins over queued data — while expired,
		// every pending and newly started read fails even when a
		// selected-peer payload is already buffered.
		select {
		case <-c.sealedCh:
			return 0, nil, errClosed
		default:
		}
		select {
		case item := <-c.readQueue:
			// The expiry re-check at dequeue is the single central
			// precedence owner for every reader path: entering readers and
			// readers already blocked when data and expiry became ready
			// together must fail while expired. The datagram is requeued
			// when possible; dropping on a full queue matches UDP
			// semantics.
			select {
			case <-c.readDeadline.Done():
				select {
				case c.readQueue <- item:
				default:
				}
				select {
				case <-c.sealedCh:
					return 0, nil, errClosed
				default:
				}
				return 0, nil, readDeadlineError{}
			default:
			}
			n := copy(p, item.payload)
			c.mu.Lock()
			selected := c.selected
			c.mu.Unlock()
			return n, freshUDPAddr(selected), nil
		case <-c.readDeadline.Done():
			select {
			case <-c.sealedCh:
				return 0, nil, errClosed
			default:
			}
			return 0, nil, readDeadlineError{}
		case <-c.sealedCh:
			return 0, nil, errClosed
		}
	}
}

// SetReadDeadline installs the logical read deadline for current and future
// ReadFrom calls. It never touches the dedicated base socket.
func (c *packetConn) SetReadDeadline(t time.Time) error {
	// Hold the lifecycle mutex through the deadline mutation so an update
	// either completes entirely before the terminal seal or returns the
	// stable closed result; no update can land after the seal.
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.sealed {
		return errClosed
	}
	c.readDeadline.Set(t)
	return nil
}

// SetWriteDeadline is explicitly unsupported; the prepared write path is the
// tagged Pion synchronous UDP operation.
func (c *packetConn) SetWriteDeadline(time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.sealed {
		return errClosed
	}
	return errDeadlineUnsupport
}

// SetDeadline is explicitly unsupported: it would combine the unsupported
// write deadline with the logical read deadline.
func (c *packetConn) SetDeadline(time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.sealed {
		return errClosed
	}
	return errDeadlineUnsupport
}

// Close runs the terminal path and returns its stable aggregate to every
// caller. It may consume the two-second graceful window plus forced and
// intermediate join time.
func (c *packetConn) Close() error {
	c.terminate(nil, false)
	<-c.closeDone
	return c.closeErr
}

// terminate routes every terminal trigger to the sole terminal executor.
func (c *packetConn) terminate(cause error, forceNow bool) {
	c.closeOnce.Do(func() {
		c.mu.Lock()
		c.sealed = true
		waiters := make([]*prepWaiter, 0, len(c.waiters))
		for waiter := range c.waiters {
			waiters = append(waiters, waiter)
		}
		c.mu.Unlock()
		close(c.sealedCh)
		terminalCause := cause
		if terminalCause == nil {
			terminalCause = errClosed
		}
		for _, waiter := range waiters {
			waiter.cancel(terminalCause)
		}
		go c.terminalExecutor(cause, forceNow)
	})
}

// terminalExecutor is the sole terminal path: one owned close driver, one
// owned graceful-window timer, graceful-then-forced ordering, induced-error
// normalization, and the exact pre-return completion census.
func (c *packetConn) terminalExecutor(cause error, forceNow bool) {
	defer close(c.closeDone)

	driverDone := make(chan error, 1)
	go func() {
		driverDone <- c.alloc.Close()
	}()

	timer := time.NewTimer(gracefulCloseWindow)
	var componentErrs []error
	forced := forceNow
	var driverErr error

	if !forceNow {
		select {
		case driverErr = <-driverDone:
			// Graceful local completion within the window.
		case <-timer.C:
			forced = true
		}
	}

	if forced {
		// Force interruption: close the dedicated base so blocked Pion I/O
		// unblocks, then join the close driver and its Pion-owned workers.
		baseErr := c.markOwnerCloseBase()
		if baseErr != nil && !inducedSocketClose(baseErr) {
			componentErrs = append(componentErrs, baseErr)
		}
		driverErr = <-driverDone
		// Induced socket-close errors are omitted from the aggregate.
		if driverErr != nil && !inducedSocketClose(driverErr) {
			componentErrs = append(componentErrs, driverErr)
		}
		if !timer.Stop() {
			select {
			case <-timer.C:
			default:
			}
		}
		c.client.Close()
		c.adapterWork.Wait()
		if pumpErr := c.pumpFailureComponent(cause); pumpErr != nil {
			componentErrs = append(componentErrs, pumpErr)
		}
		aggregate := []error{ErrForcedClose}
		if cause != nil && !errors.Is(cause, errClosed) {
			aggregate = append(aggregate, cause)
		}
		aggregate = append(aggregate, componentErrs...)
		c.closeErr = errors.Join(aggregate...)
		return
	}

	// Graceful path: the driver returned within the window. The owner has
	// not closed the base at this point by construction, so a driver error
	// that is itself a socket-close artifact proves the base died
	// externally before the deallocation write: that is the forced class,
	// independent of when the pump observes the death. The one exception
	// is the allocation self-seal class: there the driver returns the
	// allocation's own recorded seal, which may itself carry net.ErrClosed,
	// so it is not base-death evidence; the base source guard's recorded
	// failure remains the sole base-death evidence for that class.
	allocSealed := errors.Is(cause, errAllocationSealed)
	externallyDead := driverErr != nil && inducedSocketClose(driverErr) && !allocSealed
	if driverErr != nil && !inducedSocketClose(driverErr) && !errors.Is(cause, driverErr) {
		// A driver return the recorded cause already wraps (the fork's
		// Close returns the same recorded terminal cause after a self-seal)
		// is not independent evidence and is not repeated in the aggregate.
		componentErrs = append(componentErrs, driverErr)
	}
	if baseErr := c.markOwnerCloseBase(); baseErr != nil && !inducedSocketClose(baseErr) {
		componentErrs = append(componentErrs, baseErr)
	}
	if !timer.Stop() {
		select {
		case <-timer.C:
		default:
		}
	}
	c.client.Close()
	c.adapterWork.Wait()
	// The pumps are joined, so a recorded external base death is also
	// visible now. A dead base belongs to the forced class even when the
	// explicit Close won the terminal race: reclassify the aggregate. When
	// neither the driver nor the pump observed a death, the deallocation
	// write genuinely succeeded and the graceful classification is
	// truthful.
	pumpErr := c.pumpFailureComponent(cause)
	if externallyDead || pumpErr != nil {
		aggregate := []error{ErrForcedClose}
		if cause != nil && !errors.Is(cause, errClosed) {
			aggregate = append(aggregate, cause)
		}
		if pumpErr != nil {
			aggregate = append(aggregate, pumpErr)
		} else if driverErr != nil {
			aggregate = append(aggregate, fmt.Errorf("%w: %w", errBaseReadPumpFailed, driverErr))
		}
		aggregate = append(aggregate, componentErrs...)
		c.closeErr = errors.Join(aggregate...)
		return
	}
	if cause != nil && !errors.Is(cause, errClosed) {
		componentErrs = append([]error{cause}, componentErrs...)
	}
	c.closeErr = errors.Join(componentErrs...)
}

// markOwnerCloseBase records the ordering fact that the terminal executor
// itself is closing the base, then closes it. Pump failures observed after
// this point are induced, not external terminal evidence.
func (c *packetConn) markOwnerCloseBase() error {
	c.mu.Lock()
	c.ownerClosedBase = true
	c.mu.Unlock()
	return c.base.Close()
}

// pumpFailureComponent returns the recorded external base-death failure
// unless the terminal cause already carries it. Recording is gated on the
// owner-close ordering fact, so a recorded failure is always genuine
// external evidence rather than an induced artifact.
func (c *packetConn) pumpFailureComponent(cause error) error {
	c.mu.Lock()
	failure := c.pumpFailure
	c.mu.Unlock()
	if failure == nil {
		return nil
	}
	if cause != nil && errors.Is(cause, errBaseReadPumpFailed) {
		return nil
	}
	return failure
}

// inducedSocketClose classifies errors produced because the dedicated
// socket was closed under a component. The tagged dependency guarantees
// every socket-close cause satisfies errors.Is(err, net.ErrClosed), so no
// string matching is needed.
func inducedSocketClose(err error) bool {
	return errors.Is(err, net.ErrClosed)
}
