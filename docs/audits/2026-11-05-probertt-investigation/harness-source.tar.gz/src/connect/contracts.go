package connect

import (
	"context"
	"errors"
	"io"
	"net"
)

// ErrDatagramTooLarge classifies a lower Datagram rejected locally for
// exceeding its carrier's fixed MaxDatagramPayload ceiling.
var ErrDatagramTooLarge = errors.New("connect: Datagram payload too large")

// ErrChannelUseClaimed reports an AuthContext whose directional key material
// has already been claimed for one encrypted channel initialization.
var ErrChannelUseClaimed = errors.New("connect: auth context channel use already claimed")

// ErrAuthContextReleased reports access through an auth view after its owner
// has logically revoked the underlying context.
var ErrAuthContextReleased = errors.New("connect: auth context released")

// ErrAuthContextReleaseTimeout reports that logical auth-context revocation
// completed but physical producer release did not finish within wiremux's
// bounded release budget.
var ErrAuthContextReleaseTimeout = errors.New("connect: auth context release timed out")

// ErrNilAuthContextRelease reports a missing callback passed to
// NewReleasingAuthContext.
var ErrNilAuthContextRelease = errors.New("connect: auth context release callback is nil")

// AuthContext is the seam between identity layers and wiremux's transport
// upgrade. Identity layers produce it; wiremux consumes it.
//
// AuthContext deliberately contains only directional channel keys, a session
// binding, and a generic exporter. PAKE-derived, Noise-IK-derived, and
// externally supplied authentication contexts all satisfy the same interface;
// transports must not require identity- or transport-specific methods.
//
// Implementations must return caller-owned byte slices from SendKey,
// ReceiveKey, and SessionBinding. Callers may retain, mutate, or zeroize the
// returned slices without changing future AuthContext results. SendKey and
// ReceiveKey must be non-empty, distinct, and valid AES key sizes: 16, 24, or
// 32 bytes. Across a two-peer session, peer A's SendKey must equal peer B's
// ReceiveKey, and peer A's ReceiveKey must equal peer B's SendKey. That mirror
// invariant cannot be proven from one local AuthContext; asymmetric peers fail
// authentication when channel frames are opened.
type AuthContext interface {
	// SendKey returns a caller-owned copy of the symmetric key for outbound
	// channel traffic from the local peer.
	SendKey() []byte

	// ReceiveKey returns a caller-owned copy of the symmetric key for inbound
	// channel traffic from the remote peer.
	ReceiveKey() []byte

	// SessionBinding returns a caller-owned copy of the domain-separated
	// session binding mixed into downstream derivations.
	SessionBinding() []byte

	// Exporter returns an HKDF-style exporter rooted in the session's master
	// secret. Transport implementations use the exporter for transport-specific
	// keying material without requiring identity-layer changes.
	Exporter() KeyExporter
}

// ChannelUseClaimer is optionally implemented by AuthContexts that enforce
// single use of their directional keys by wiremux channel constructors.
// A successful claim is irreversible; subsequent claims return an error
// wrapping ErrChannelUseClaimed.
type ChannelUseClaimer interface {
	ClaimChannelUse() error
}

// AuthContextReleaser is optionally implemented by AuthContexts whose retained
// cryptographic state requires deterministic cleanup after ownership transfers
// to wiremux. ReleaseAuthContext must be concurrency-safe, idempotent, bounded,
// and free of network I/O or external coordination.
//
// This purpose-specific capability is intentionally distinct from io.Closer;
// an unrelated Close method never opts an AuthContext into release ownership.
type AuthContextReleaser interface {
	ReleaseAuthContext() error
}

// KeyExporter derives protocol-specific keying material from an auth context.
//
// Implementations must not retain or mutate the context argument passed to
// Derive, and Derive returns caller-owned output that callers may retain,
// mutate, or zeroize.
type KeyExporter interface {
	// Derive returns length bytes bound to label, context, and the parent
	// AuthContext's session binding.
	//
	// Calling Derive with the same label, context, and length on the same
	// exporter must return identical material. Different labels or contexts
	// must produce independent material. Labels are printable-ASCII protocol
	// constants and must not contain NUL, because the recommended
	// HKDF-Expand-style info framing is label || 0x00 || context. Derive fails
	// on labels containing NUL. The built-in HKDF-SHA-256 exporter supports
	// output lengths from 0 through 8160 bytes. Different lengths for the same
	// label and context share a prefix; distinct purposes must use distinct
	// labels or contexts, not only distinct lengths.
	// Derive is a bounded local cryptographic operation. It must not perform
	// network I/O or external coordination.
	Derive(label string, context []byte, length int) ([]byte, error)
}

// TransportAuth is the least-privilege authentication view supplied to a
// Transport. It exposes no directional channel keys and therefore cannot be
// used to initialize wiremux's encrypted channel.
type TransportAuth interface {
	// SessionBinding returns a caller-owned copy of the session binding while
	// the owning Wire remains live. After revocation it returns
	// ErrAuthContextReleased.
	SessionBinding() ([]byte, error)

	// Exporter returns a non-nil exporter governed by the same lifetime.
	Exporter() KeyExporter
}

// Transport opens direct peer-to-peer connectivity after a successful probe.
//
// Streams returned by a Transport must surface local-close and peer-teardown
// errors carrying a recognized closed-wire identity — net.ErrClosed is the
// conventional choice, io.ErrClosedPipe also qualifies — reachable through
// errors.Is, so the root Wire boundary can classify teardown without matching
// transport-specific strings or types. Transports with bespoke close or reset
// errors wrap them with that identity while keeping the original error
// reachable; wiremux's default QUIC transport stream adapter is the reference
// pattern. This is the transport-layer convention. The root Wire classifier
// additionally recognizes channel and syscall teardown identities contributed
// by other layers; those are not extra identities custom transports must
// synthesize. See the root wiremux.WithTransport and wiremux.ErrWireClosed
// documentation for that broader classification boundary.
type Transport interface {
	// Name returns a stable transport identifier used during negotiation. It must
	// return promptly and must not perform unbounded I/O.
	Name() string

	// NewSession creates per-upgrade transport state bound to auth. The session
	// binds any handshake material generated before candidate exchange to the
	// subsequent Dial or Listen call.
	NewSession(ctx context.Context, auth TransportAuth) (Session, error)
}

// DatagramCarrier is the lower transport view of an established carrier's
// optional unreliable-unordered atomic-message plane. Payloads at this seam
// include wiremux's envelope byte; direct Upgrade callers own validating and
// removing that envelope. One send maps to at most one atomic receive and is
// never fragmented or retransmitted by wiremux. The carrier supports one send
// and one receive concurrently with aggregate stream close.
type DatagramCarrier interface {
	// Lifetime is canceled with a cause when the established carrier becomes
	// terminal. It is stable, non-nil, has a non-nil Done channel, and reports a
	// non-nil context.Cause after cancellation. Per-call cancellation and
	// ordinary Datagram loss do not end it.
	Lifetime() context.Context
	// MaxDatagramPayload returns the lifetime-fixed exact maximum lower payload,
	// including the wiremux envelope byte.
	MaxDatagramPayload() int
	// SendDatagram copies and admits one payload. Success means admission, not
	// transmission or delivery. A nil context means context.Background. Payloads
	// above MaxDatagramPayload are rejected without ending Lifetime; a terminal
	// carrier failure must cancel Lifetime with its cause.
	SendDatagram(context.Context, []byte) error
	// ReceiveDatagram waits for one complete lower payload and returns a
	// caller-owned slice. Success is a non-nil payload and nil error, including a
	// non-nil empty slice for an empty native Datagram; failure is a nil payload
	// and non-nil error. A nil context means context.Background. Per-call
	// cancellation is non-terminal; terminal carrier failure cancels Lifetime.
	ReceiveDatagram(context.Context) ([]byte, error)
}

// DatagramCapable is optionally implemented by a stream returned from
// Session.Dial or TransportListener.Accept. Required transport interfaces stay
// stream-only; callers must treat capability absence as a normal outcome.
// Upgrade extracts and validates this interface, then returns a reliable-only
// Stream and exposes agreed capability exclusively through
// UpgradeResult.Datagrams.
type DatagramCapable interface {
	DatagramCarrier() (DatagramCarrier, bool)
}

// Session is single-upgrade transport state. Exactly one of Dial or Listen is
// called per successful direct upgrade, based on the negotiator's role
// assignment. Transports over reused probe sockets must perform any internal
// stream-establishment priming themselves so Accept can return an
// application-ready stream without depending on application bytes from Upgrade
// callers.
type Session interface {
	// HandshakeMaterial returns authentication material for the negotiator to
	// deliver over the authenticated channel. It may be empty for transports
	// whose authentication is entirely exporter-derived. It must return promptly
	// and must not perform unbounded I/O.
	HandshakeMaterial() []byte

	// Dial opens an outbound transport connection using the punched packet
	// socket. Any non-nil returned connection owns the exact conn, including
	// one returned with an error. Its Close must synchronously attempt
	// bounded reliable-stream, parent-connection, transport-resource, and exact
	// packet-socket cleanup exactly once before returning. A nil connection
	// result leaves conn open and caller-owned.
	// remote is the selected remote address and is the only authorized remote
	// endpoint for the returned connection's lifetime. Transport migration or
	// rebinding from any other address must be disabled or filtered.
	// Session.Close does not close conn or any connection returned by Dial. The
	// returned io.ReadWriteCloser may optionally implement DatagramCapable. Upgrade
	// validates that transport-native surface before wrapping it and keeps the
	// final Stream reliable-only.
	Dial(ctx context.Context, conn net.PacketConn, remote net.Addr, remoteMaterial []byte) (io.ReadWriteCloser, error)

	// Listen prepares an inbound listener using the punched packet socket and
	// selected remote address. Listen and Accept may temporarily own reads on
	// conn, but remote is the only authorized remote endpoint for the returned
	// connection's lifetime. Packets, transport migration, or rebinding from
	// sources other than remote must be disabled or filtered before they can
	// establish or confuse an upgraded connection. Ownership of conn transfers to
	// any non-nil connection returned by Accept, including one returned with an
	// error. On a nil connection result, closing the listener must leave conn open
	// and caller-owned.
	// The returned connection's Close has the same synchronous exact-packet
	// disposal contract as Dial. Session.Close does not close conn or any
	// accepted connection.
	Listen(ctx context.Context, conn net.PacketConn, remote net.Addr, remoteMaterial []byte) (TransportListener, error)

	// Close releases per-upgrade session state and actively unblocks
	// implementation-owned I/O in an active Dial or Listen. Dial and Listen must
	// return promptly after their context is canceled and Close is called
	// concurrently. Upgrade may also call Close concurrently with in-flight
	// setup or handshake work after the setup budget expires. Close itself must
	// return promptly, must not perform unbounded I/O, and is not the operation
	// join authority; Upgrade joins the registered Dial or Listen result. Close
	// does not close conn or any connection returned by Dial or by a listener.
	Close() error
}

// TransportListener accepts at most one upgraded transport connection.
type TransportListener interface {
	// Accept waits for the upgraded transport connection. Any non-nil returned
	// connection owns the exact packet socket even when returned together with
	// an error. Its Close synchronously completes the bounded disposal contract
	// defined by Session.Dial before returning, and callers close that connection
	// before closing the listener. The
	// returned io.ReadWriteCloser may optionally implement DatagramCapable.
	// Upgrade validates that transport-native surface before wrapping it and
	// keeps the final Stream reliable-only.
	Accept(ctx context.Context) (io.ReadWriteCloser, error)

	// Close actively unblocks and joins an active Accept result while releasing
	// listener resources. Before a non-nil Accept result, Close leaves the packet
	// socket passed to Session.Listen open; afterward it must not take cleanup
	// from the returned connection path.
	Close() error
}
