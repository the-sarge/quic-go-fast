package connect

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"sort"
	"time"

	"github.com/GridSwarm/wiremux/internal/packetfamily"
	"github.com/GridSwarm/wiremux/internal/routeselection"
	"github.com/GridSwarm/wiremux/stun"
)

// CandidateKind identifies the kind of network-address candidate.
type CandidateKind string

const (
	// CandidateKindHost is an address directly assigned to the local peer.
	CandidateKindHost CandidateKind = "host"

	// CandidateKindReflexive is an externally observed address reported by STUN.
	CandidateKindReflexive CandidateKind = "reflexive"

	// CandidateKindRelay represents relay-assisted connectivity.
	CandidateKindRelay CandidateKind = "relay"
)

// Candidate is a network address a peer can offer as a possible direct path.
type Candidate struct {
	Kind CandidateKind
	Addr netip.AddrPort
}

var (
	// ErrNilPacketConn reports Gather without the packet socket candidates use.
	ErrNilPacketConn = errors.New("connect: packet conn is nil")

	// ErrInvalidPacketConnLocalAddr reports a packet socket with an unusable local address.
	ErrInvalidPacketConnLocalAddr = errors.New("connect: packet conn local address is invalid")

	// ErrInvalidSTUNServerAddress reports an unusable configured STUN server address.
	ErrInvalidSTUNServerAddress = errors.New("connect: STUN server address is invalid")

	// ErrNoCandidates reports that candidate gathering found no usable addresses.
	ErrNoCandidates = errors.New("connect: no candidates gathered")

	errInvalidReflexiveCandidateAddress = errors.New("connect: STUN reflexive address is invalid")

	errSTUNDiscoveryFailed = errors.New("connect: STUN discovery failed")
)

const defaultSTUNGatherTimeout = time.Second

// GatherOption configures candidate gathering.
type GatherOption func(*gatherConfig)

type gatherConfig struct {
	conn          net.PacketConn
	stunServer    net.Addr
	stunServerSet bool
}

type gatherInterface struct {
	name     string
	flags    net.Flags
	addrs    []net.Addr
	addrsErr error
}

type gatheredCandidate struct {
	candidate      Candidate
	localInterface string
}

type candidateAddrFamilies struct {
	ipv4 bool
	ipv6 bool
}

type candidateGatherer struct {
	interfaces func() ([]gatherInterface, error)
	reflexive  func(context.Context, net.PacketConn, net.Addr) (net.Addr, error)
}

// WithPacketConn sets the caller-owned packet socket used for gathered candidates.
func WithPacketConn(conn net.PacketConn) GatherOption {
	return func(cfg *gatherConfig) {
		cfg.conn = conn
	}
}

// WithSTUNServer sets the STUN server used to gather a reflexive candidate.
func WithSTUNServer(addr net.Addr) GatherOption {
	return func(cfg *gatherConfig) {
		cfg.stunServer = addr
		cfg.stunServerSet = true
	}
}

// Gather gathers local and reflexive candidates for the supplied packet socket.
//
// STUN discovery is best-effort after input validation: if reflexive discovery
// fails while ctx remains active and at least one host candidate exists, Gather
// returns those host candidates. Internal STUN budget expiry and silent no-response
// remain best-effort when the caller context is still active. When zero candidates
// are gathered, non-context STUN discovery failures are joined with ErrNoCandidates
// for ordinary host absence, or with the host/interface enumeration error when host
// discovery itself failed. Invalid options, context cancellation or deadline expiry,
// and total candidate absence remain errors. Gather does not attribute a
// returned-but-unparseable STUN reflexive address to the packet connection local
// address. Gather does not close caller-owned sockets. Explicit non-wildcard bindings
// are caller-selected and returned unfiltered; wildcard
// bindings enumerate interface addresses and apply usability filtering. IPv6
// wildcard sockets enumerate IPv4 addresses only when a best-effort IPV6_V6ONLY
// probe shows the socket accepts IPv4 traffic; if the probe cannot run, Gather
// conservatively treats the socket as IPv6-only.
// When STUN is configured, callers must not read from the packet socket
// concurrently while Gather is running; STUN discovery may set and then clear
// read deadlines on the socket. Gather applies a fixed one-second STUN
// discovery budget; a shorter caller deadline wins, while a longer caller
// deadline is capped by that internal budget. Internal STUN timeout is treated
// as a best-effort STUN failure unless ctx has also ended.
func Gather(ctx context.Context, opts ...GatherOption) ([]Candidate, error) {
	return defaultCandidateGatherer().gather(ctx, opts...)
}

func defaultCandidateGatherer() candidateGatherer {
	return candidateGatherer{
		interfaces: systemGatherInterfaces,
		reflexive:  systemGatherReflexive,
	}
}

func (g candidateGatherer) withDefaults() candidateGatherer {
	if g.interfaces == nil {
		g.interfaces = systemGatherInterfaces
	}
	if g.reflexive == nil {
		g.reflexive = systemGatherReflexive
	}
	return g
}

func (g candidateGatherer) gather(ctx context.Context, opts ...GatherOption) ([]Candidate, error) {
	gathered, err := g.gatherCandidates(ctx, opts...)
	if err != nil {
		return nil, err
	}
	return candidatesFromGathered(gathered), nil
}

func (g candidateGatherer) gatherCandidates(ctx context.Context, opts ...GatherOption) ([]gatheredCandidate, error) {
	g = g.withDefaults()

	if ctx == nil {
		return nil, ErrNilContext
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	var cfg gatherConfig
	for _, opt := range opts {
		if opt != nil {
			opt(&cfg)
		}
	}
	if cfg.conn == nil {
		return nil, ErrNilPacketConn
	}
	if err := routeselection.PacketFromContext(ctx).Validate(); err != nil {
		return nil, err
	}
	if packetConnBearsRelayProfile(cfg.conn) {
		return nil, ErrRelayProfileDirectPath
	}

	addr, err := addrPortFromNetAddr(cfg.conn.LocalAddr())
	if err != nil {
		return nil, err
	}
	if !addr.IsValid() || addr.Port() == 0 {
		return nil, ErrInvalidPacketConnLocalAddr
	}
	families := packetConnAddrFamilies(cfg.conn, addr)
	if cfg.stunServerSet {
		if err := validateSTUNServerAddress(cfg.stunServer, families); err != nil {
			return nil, err
		}
	}

	localInterface := ""
	if binding := routeselection.PacketFromContext(ctx); binding != nil {
		localInterface = binding.InterfaceName()
	} else if !addr.Addr().IsUnspecified() {
		localInterface = g.localInterfaceForAddr(addr.Addr())
	}
	candidates, hostErr := g.hostCandidatesForLocalAddr(addr, families, localInterface)
	if hostErr != nil && !cfg.stunServerSet {
		return nil, hostErr
	}
	var reflexiveErr error
	if cfg.stunServerSet {
		stunCtx, cancel := context.WithTimeout(ctx, defaultSTUNGatherTimeout)
		reflexive, err := g.reflexive(stunCtx, cfg.conn, cfg.stunServer)
		cancel()
		if err != nil {
			var selectedFailure *routeselection.Error
			if errors.As(err, &selectedFailure) {
				return nil, err
			}
			if ctxErr := ctx.Err(); ctxErr != nil {
				return nil, ctxErr
			}
			reflexiveErr = stunDiscoveryDiagnostic(err)
		} else {
			reflexiveAddr, err := addrPortFromNetAddrWithSentinel(reflexive, errInvalidReflexiveCandidateAddress)
			if err != nil {
				reflexiveErr = err
			} else if usableReflexiveAddress(reflexiveAddr) && families.allows(reflexiveAddr.Addr()) {
				candidates = append(candidates, gatheredCandidate{
					candidate: Candidate{
						Kind: CandidateKindReflexive,
						Addr: reflexiveAddr,
					},
					localInterface: localInterface,
				})
			}
		}
	}

	candidates = dedupeAndSortGatheredCandidates(candidates)
	if len(candidates) == 0 {
		if hostErr != nil && !errors.Is(hostErr, ErrNoCandidates) {
			if reflexiveErr != nil {
				return nil, errors.Join(hostErr, reflexiveErr)
			}
			return nil, hostErr
		}
		if reflexiveErr != nil {
			return nil, errors.Join(ErrNoCandidates, reflexiveErr)
		}
		return nil, ErrNoCandidates
	}
	return candidates, nil
}

func systemGatherReflexive(ctx context.Context, conn net.PacketConn, server net.Addr) (net.Addr, error) {
	return stun.NewClient().Reflexive(ctx, conn, server)
}

func stunDiscoveryDiagnostic(err error) error {
	if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
		return nil
	}
	return errors.Join(errSTUNDiscoveryFailed, err)
}

func (g candidateGatherer) hostCandidatesForLocalAddr(localAddr netip.AddrPort, families candidateAddrFamilies, localInterface string) ([]gatheredCandidate, error) {
	if !localAddr.IsValid() || localAddr.Port() == 0 {
		return nil, ErrInvalidPacketConnLocalAddr
	}
	if !localAddr.Addr().IsUnspecified() {
		// Explicit bindings are caller-selected and returned as-is; keep the
		// interface name when the system inventory can map the bound address so
		// Upgrade candidate policy can still apply before offer encoding.
		return []gatheredCandidate{{
			candidate:      Candidate{Kind: CandidateKindHost, Addr: localAddr},
			localInterface: localInterface,
		}}, nil
	}

	interfaces, err := g.interfaces()
	if err != nil {
		return nil, err
	}

	var candidates []gatheredCandidate
	var addrsErr error
	for _, iface := range interfaces {
		if iface.flags&net.FlagUp == 0 {
			continue
		}
		if iface.addrsErr != nil {
			addrsErr = errors.Join(addrsErr, iface.addrsErr)
			continue
		}
		for _, interfaceAddr := range iface.addrs {
			addr, ok := addrFromInterfaceAddr(interfaceAddr)
			if !ok {
				continue
			}
			if !usableHostAddress(addr) || !families.allows(addr) {
				continue
			}
			candidates = append(candidates, gatheredCandidate{
				candidate: Candidate{
					Kind: CandidateKindHost,
					Addr: netip.AddrPortFrom(addr, localAddr.Port()),
				},
				localInterface: iface.name,
			})
		}
	}
	if len(candidates) == 0 {
		if addrsErr != nil {
			return nil, fmt.Errorf("connect: gather interface addresses: %w", addrsErr)
		}
		return nil, ErrNoCandidates
	}
	return candidates, nil
}

func (g candidateGatherer) localInterfaceForAddr(addr netip.Addr) string {
	addr = addr.Unmap()
	if !addr.IsValid() {
		return ""
	}
	if zone := addr.Zone(); zone != "" {
		return zone
	}
	addr = unscopedAddr(addr)

	interfaces, err := g.interfaces()
	if err != nil {
		return ""
	}
	for _, iface := range interfaces {
		if iface.flags&net.FlagUp == 0 || iface.addrsErr != nil {
			continue
		}
		for _, interfaceAddr := range iface.addrs {
			interfaceIP, ok := addrFromInterfaceAddr(interfaceAddr)
			if ok && unscopedAddr(interfaceIP) == addr {
				return iface.name
			}
		}
	}
	return ""
}

func unscopedAddr(addr netip.Addr) netip.Addr {
	return addr.Unmap().WithZone("")
}

func addrFromInterfaceAddr(addr net.Addr) (netip.Addr, bool) {
	if addr == nil {
		return netip.Addr{}, false
	}
	switch typed := addr.(type) {
	case *net.IPNet:
		if typed == nil {
			return netip.Addr{}, false
		}
		ip, ok := netip.AddrFromSlice(typed.IP)
		if !ok {
			return netip.Addr{}, false
		}
		return ip.Unmap(), true
	case *net.IPAddr:
		if typed == nil {
			return netip.Addr{}, false
		}
		ip, ok := netip.AddrFromSlice(typed.IP)
		if !ok {
			return netip.Addr{}, false
		}
		return ip.Unmap(), true
	default:
		prefix, err := netip.ParsePrefix(addr.String())
		if err == nil {
			return prefix.Addr().Unmap(), true
		}
		ip, err := netip.ParseAddr(addr.String())
		if err == nil {
			return ip.Unmap(), true
		}
		return netip.Addr{}, false
	}
}

func systemGatherInterfaces() ([]gatherInterface, error) {
	interfaces, err := net.Interfaces()
	if err != nil {
		return nil, err
	}

	gathered := make([]gatherInterface, 0, len(interfaces))
	for _, iface := range interfaces {
		addrs, err := iface.Addrs()
		if err != nil {
			gathered = append(gathered, gatherInterface{
				name:     iface.Name,
				flags:    iface.Flags,
				addrsErr: fmt.Errorf("interface %s addrs: %w", iface.Name, err),
			})
			continue
		}
		gathered = append(gathered, gatherInterface{
			name:  iface.Name,
			flags: iface.Flags,
			addrs: addrs,
		})
	}
	return gathered, nil
}

func usableHostAddress(addr netip.Addr) bool {
	addr = addr.Unmap()
	return addr.IsValid() &&
		!addr.IsUnspecified() &&
		!addr.IsLoopback() &&
		!addr.IsLinkLocalUnicast() &&
		!addr.IsLinkLocalMulticast() &&
		!addr.IsMulticast()
}

func usableReflexiveAddress(addrPort netip.AddrPort) bool {
	addr := addrPort.Addr().Unmap()
	return addr.IsValid() &&
		addrPort.IsValid() &&
		addrPort.Port() != 0 &&
		!addr.IsUnspecified() &&
		!addr.IsLoopback() &&
		!addr.IsLinkLocalUnicast() &&
		!addr.IsLinkLocalMulticast() &&
		!addr.IsMulticast()
}

func packetConnAddrFamilies(conn net.PacketConn, localAddr netip.AddrPort) candidateAddrFamilies {
	addr := localAddr.Addr()
	if !addr.IsValid() {
		return candidateAddrFamilies{}
	}
	if addr.Is4() {
		return candidateAddrFamilies{ipv4: true}
	}
	if addr.Is6() {
		families := candidateAddrFamilies{ipv6: true}
		if addr.IsUnspecified() && ipv6WildcardAllowsIPv4(conn) {
			families.ipv4 = true
		}
		return families
	}
	return candidateAddrFamilies{}
}

func (families candidateAddrFamilies) allows(addr netip.Addr) bool {
	addr = addr.Unmap()
	switch {
	case addr.Is4():
		return families.ipv4
	case addr.Is6():
		return families.ipv6
	default:
		return false
	}
}

func dedupeAndSortGatheredCandidates(candidates []gatheredCandidate) []gatheredCandidate {
	seen := make(map[netip.AddrPort]struct{}, len(candidates))
	deduped := candidates[:0]
	for _, item := range candidates {
		if _, ok := seen[item.candidate.Addr]; ok {
			continue
		}
		seen[item.candidate.Addr] = struct{}{}
		deduped = append(deduped, item)
	}

	sort.Slice(deduped, func(i, j int) bool {
		if deduped[i].candidate.Kind != deduped[j].candidate.Kind {
			return candidateKindOrder(deduped[i].candidate.Kind) < candidateKindOrder(deduped[j].candidate.Kind)
		}
		if cmp := deduped[i].candidate.Addr.Addr().Compare(deduped[j].candidate.Addr.Addr()); cmp != 0 {
			return cmp < 0
		}
		return deduped[i].candidate.Addr.Port() < deduped[j].candidate.Addr.Port()
	})

	return deduped
}

func candidatesFromGathered(gathered []gatheredCandidate) []Candidate {
	candidates := make([]Candidate, 0, len(gathered))
	for _, item := range gathered {
		candidates = append(candidates, item.candidate)
	}
	return candidates
}

func validateSTUNServerAddress(addr net.Addr, families candidateAddrFamilies) error {
	serverAddr, err := addrPortFromNetAddrWithSentinel(addr, ErrInvalidSTUNServerAddress)
	if err != nil {
		return err
	}
	if !isUDPNetwork(addr.Network()) {
		return fmt.Errorf("%w: network %q is not UDP", ErrInvalidSTUNServerAddress, addr.Network())
	}
	if serverAddr.Port() == 0 {
		return fmt.Errorf("%w: port is zero", ErrInvalidSTUNServerAddress)
	}

	serverIP := serverAddr.Addr().Unmap()
	if !serverIP.IsValid() || serverIP.IsUnspecified() || serverIP.IsMulticast() {
		return fmt.Errorf("%w: address %s is not usable", ErrInvalidSTUNServerAddress, serverIP)
	}
	if !families.allows(serverIP) {
		return packetfamily.NewMismatch(fmt.Errorf("%w: address family %s is incompatible with packet conn", ErrInvalidSTUNServerAddress, serverIP))
	}
	return nil
}

func isUDPNetwork(network string) bool {
	switch network {
	case "udp", "udp4", "udp6":
		return true
	default:
		return false
	}
}

func candidateKindOrder(kind CandidateKind) int {
	return classifyCandidateKind(kind).preferenceRank
}

func addrPortFromNetAddr(addr net.Addr) (netip.AddrPort, error) {
	return addrPortFromNetAddrWithSentinel(addr, ErrInvalidPacketConnLocalAddr)
}

func addrPortFromNetAddrWithSentinel(addr net.Addr, sentinel error) (netip.AddrPort, error) {
	if addr == nil {
		return netip.AddrPort{}, sentinel
	}
	if udpAddr, ok := addr.(*net.UDPAddr); ok {
		addrPort := udpAddr.AddrPort()
		return netip.AddrPortFrom(addrPort.Addr().Unmap(), addrPort.Port()), nil
	}
	parsed, err := netip.ParseAddrPort(addr.String())
	if err != nil {
		return netip.AddrPort{}, fmt.Errorf("%w: %w", sentinel, err)
	}
	return netip.AddrPortFrom(parsed.Addr().Unmap(), parsed.Port()), nil
}
