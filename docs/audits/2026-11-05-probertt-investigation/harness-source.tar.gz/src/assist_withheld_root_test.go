package wiremux_test

import (
	"bytes"
	"errors"
	"io"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux"
	"github.com/GridSwarm/wiremux/relay"
)

// TestRelayOnlyDialSurfacesAssistWithheldWhenRelayShedsAssist is the
// wire-dialer half of the #1255 slice-3 contract: a pairing established while
// the relay's active-pair budget is full still yields a relay-path Wire, and
// once the relay closes it after the withheld allowance the Wire's error tree
// carries relay.ErrRelayAssistWithheld rather than a generic disconnect.
func TestRelayOnlyDialSurfacesAssistWithheldWhenRelayShedsAssist(t *testing.T) {
	endpoint := startTestRelay(t, relay.WithMaxActivePairs(1))

	// Fill the single active-pair slot with an ordinary relay-only pair.
	blocker := dialTestPair(t, dialPairSpec{endpoint: endpoint, sessionID: relay.SessionID{0x51, 0x01}, commonOpts: []wiremux.Option{wiremux.WithRelayOnly()}})
	defer blocker.left.wire.Close()
	defer blocker.right.wire.Close()

	// The next pairing is withheld: rendezvous and the encrypted handshake
	// still complete over the allowance, so the dial succeeds on the relay path.
	pair := dialTestPair(t, dialPairSpec{endpoint: endpoint, sessionID: relay.SessionID{0x51, 0x02}, commonOpts: []wiremux.Option{wiremux.WithRelayOnly()}})
	left, right := pair.left.wire, pair.right.wire
	defer left.Close()
	defer right.Close()
	assertRelayWire(t, "withheld left", left)
	assertRelayWire(t, "withheld right", right)

	// Exhaust the byte allowance; the relay then closes the stream.
	go func() { _, _ = left.Write(bytes.Repeat([]byte{7}, 512<<10)) }()
	buf := make([]byte, 32<<10)
	deadline := time.Now().Add(10 * time.Second)
	for {
		if time.Now().After(deadline) {
			t.Fatal("relay did not close the withheld stream after the byte allowance")
		}
		_, err := right.Read(buf)
		if err == nil {
			continue
		}
		if !errors.Is(err, relay.ErrRelayAssistWithheld) {
			t.Fatalf("Wire.Read after the allowance: got %v, want an error wrapping %v", err, relay.ErrRelayAssistWithheld)
		}
		if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
			t.Fatalf("Wire.Read after the allowance: got %v, want no clean-EOF identity for a truncated stream", err)
		}
		return
	}
}
