package channel

import (
	"bytes"
	"errors"
	"io"
	"testing"

	"github.com/GridSwarm/wiremux/internal/compatmanifest"
)

// These tests prove the production encrypted-channel framing matches the
// independently constructed ciphertext vectors that the release wire-vectors
// manifest freezes for v0.1.x: AES-GCM framing, directional orientation,
// counter nonces, AAD composition, and the authenticated close frame.

func channelCompatVector(t *testing.T, name string) []byte {
	t.Helper()
	for _, v := range compatmanifest.ChannelVectors() {
		if v.Name == name {
			return v.Data
		}
	}
	t.Fatalf("compatmanifest has no channel vector %q", name)
	return nil
}

func TestChannelFrameVectorsMatchProductionEncoding(t *testing.T) {
	var wire bytes.Buffer
	sender, err := NewChannel(&wire, authFixture{
		sendKey:    compatmanifest.ChannelSendKey(),
		receiveKey: compatmanifest.ChannelReceiveKey(),
	})
	if err != nil {
		t.Fatalf("NewChannel: %v", err)
	}

	payloads := compatmanifest.ChannelVectorPayloads()
	vectors := []string{"frame-data-seq0", "frame-data-seq1", "frame-data-empty-seq2"}
	if len(payloads) != len(vectors) {
		t.Fatalf("compatmanifest returned %d channel payloads, want %d", len(payloads), len(vectors))
	}
	for i, payload := range payloads {
		if err := sender.Send(payload); err != nil {
			t.Fatalf("Send(%d): %v", i, err)
		}
		want := channelCompatVector(t, vectors[i])
		got := append([]byte(nil), wire.Bytes()...)
		wire.Reset()
		if !bytes.Equal(got, want) {
			t.Fatalf("Send(%d) frame = %x, want %x", i, got, want)
		}
	}

	if err := sender.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	want := channelCompatVector(t, "frame-close-seq3")
	if !bytes.Equal(wire.Bytes(), want) {
		t.Fatalf("close frame = %x, want %x", wire.Bytes(), want)
	}
}

func TestChannelMirrorDirectionVectorMatchesProductionEncoding(t *testing.T) {
	var wire bytes.Buffer
	sender, err := NewChannel(&wire, authFixture{
		sendKey:    compatmanifest.ChannelReceiveKey(),
		receiveKey: compatmanifest.ChannelSendKey(),
	})
	if err != nil {
		t.Fatalf("NewChannel: %v", err)
	}

	if err := sender.Send(compatmanifest.ChannelVectorPayloads()[0]); err != nil {
		t.Fatalf("Send: %v", err)
	}
	want := channelCompatVector(t, "frame-data-seq0-mirror")
	if !bytes.Equal(wire.Bytes(), want) {
		t.Fatalf("mirror frame = %x, want %x", wire.Bytes(), want)
	}
}

func TestChannelVectorsDecodeThroughProductionReceive(t *testing.T) {
	var wire bytes.Buffer
	for _, name := range []string{"frame-data-seq0", "frame-data-seq1", "frame-data-empty-seq2", "frame-close-seq3"} {
		wire.Write(channelCompatVector(t, name))
	}

	receiver, err := NewChannel(&wire, authFixture{
		sendKey:    compatmanifest.ChannelReceiveKey(),
		receiveKey: compatmanifest.ChannelSendKey(),
	})
	if err != nil {
		t.Fatalf("NewChannel: %v", err)
	}

	for i, wantPayload := range compatmanifest.ChannelVectorPayloads() {
		payload, err := receiver.Receive()
		if err != nil {
			t.Fatalf("Receive(%d): %v", i, err)
		}
		if !bytes.Equal(payload, wantPayload) {
			t.Fatalf("Receive(%d) = %q, want %q", i, payload, wantPayload)
		}
	}
	if _, err := receiver.Receive(); !errors.Is(err, io.EOF) {
		t.Fatalf("Receive(close vector) = %v, want io.EOF", err)
	}
}
