// Package channel provides the encrypted byte-stream and framed-channel layer
// over a connect.AuthContext.
//
// Channels encrypt bounded frames with the identity layer's directional
// SendKey and ReceiveKey values directly. Each direction uses a monotonic
// counter nonce, strict receive sequence enforcement, direction-bound AAD, and
// an authenticated close frame.
//
// AuthContext keys are not re-derived inside this package. Callers must supply
// fresh, domain-separated directional keys for each channel instance, and each
// AuthContext/key pair must initialize at most one Channel or Stream. Reusing a
// key pair across channel instances reuses AES-GCM nonce streams.
package channel
