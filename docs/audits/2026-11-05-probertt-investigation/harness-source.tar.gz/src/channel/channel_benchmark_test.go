package channel

import (
	"bytes"
	"io"
	"testing"
)

// discardReadWriter satisfies NewChannel's io.ReadWriter with a write sink,
// so a send benchmark measures framing and sealing without transport cost.
type discardReadWriter struct{}

func (discardReadWriter) Write(p []byte) (int, error) { return len(p), nil }

func (discardReadWriter) Read([]byte) (int, error) { return 0, io.EOF }

func benchmarkChannelSend(b *testing.B, size int) {
	b.Helper()
	ch, err := NewChannel(discardReadWriter{}, aliceAuth())
	if err != nil {
		b.Fatalf("NewChannel: %v", err)
	}
	payload := bytes.Repeat([]byte{0xA5}, size)

	b.ReportAllocs()
	b.SetBytes(int64(size))
	b.ResetTimer()
	for range b.N {
		if err := ch.Send(payload); err != nil {
			b.Fatalf("Send: %v", err)
		}
	}
}

func BenchmarkChannelSend1KiB(b *testing.B) {
	benchmarkChannelSend(b, 1024)
}

func BenchmarkChannelSend64KiB(b *testing.B) {
	benchmarkChannelSend(b, MaxPayloadSize)
}

func benchmarkChannelReceive(b *testing.B, size int) {
	b.Helper()
	var wire bytes.Buffer
	sender, err := NewChannel(&wire, aliceAuth())
	if err != nil {
		b.Fatalf("NewChannel sender: %v", err)
	}
	receiver, err := NewChannel(&wire, bobAuth())
	if err != nil {
		b.Fatalf("NewChannel receiver: %v", err)
	}
	payload := bytes.Repeat([]byte{0xA5}, size)

	// Frames are pre-encoded in bounded batches so the wire buffer never
	// holds b.N frames at once; the refill runs off the timer while the
	// paired sequence numbers keep advancing.
	const batch = 256
	fill := func() {
		for range batch {
			if err := sender.Send(payload); err != nil {
				b.Fatalf("Send: %v", err)
			}
		}
	}
	fill()
	remaining := batch

	b.ReportAllocs()
	b.SetBytes(int64(size))
	b.ResetTimer()
	for range b.N {
		if remaining == 0 {
			b.StopTimer()
			fill()
			remaining = batch
			b.StartTimer()
		}
		got, err := receiver.Receive()
		if err != nil {
			b.Fatalf("Receive: %v", err)
		}
		if len(got) != size {
			b.Fatalf("Receive returned %d bytes, want %d", len(got), size)
		}
		remaining--
	}
}

func BenchmarkChannelReceive1KiB(b *testing.B) {
	benchmarkChannelReceive(b, 1024)
}

func BenchmarkChannelReceive64KiB(b *testing.B) {
	benchmarkChannelReceive(b, MaxPayloadSize)
}
