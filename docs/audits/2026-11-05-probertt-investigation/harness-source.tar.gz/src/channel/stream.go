package channel

import (
	"io"
	"sync"

	"github.com/GridSwarm/wiremux/connect"
)

// NewStream constructs an encrypted byte-stream adapter over rw.
//
// Options are applied in order; nil options are ignored.
//
// The auth context's directional keys are used directly by NewChannel. Each
// AuthContext/key pair must initialize at most one Channel or Stream, because
// channel nonces start at zero and key/nonce reuse breaks AES-GCM security.
//
// The returned stream serializes concurrent Read calls and concurrent Write
// calls. A single Write larger than MaxPayloadSize is sent as contiguous
// channel frames before another Write or Close can send frames. Close is
// graceful: it waits for any active Write and is not an abort path for a Write
// stuck in the underlying transport; callers must close or cancel the
// underlying transport out-of-band to unblock it. Read rejects authenticated
// empty data frames with ErrStreamEmptyDataFrame by default, which wraps
// io.ErrNoProgress, because byte-stream reads must either return data or a
// terminal error. AllowEmptyDataFrames makes Read skip those frames for callers
// that intentionally carry channel-shaped traffic through the stream adapter.
// That read-side error does not poison the independent Write side, and a
// transport write failure does not poison Read: after Write fails, Read still
// returns bytes the peer already delivered and then reports its own EOF or
// error. Authentication and truncation failures on Read remain terminal for
// both directions. Concurrent
// Read and Write calls require an underlying rw that supports full-duplex use.
func NewStream(rw io.ReadWriter, auth connect.AuthContext, opts ...StreamOption) (io.ReadWriteCloser, error) {
	ch, err := NewChannel(rw, auth)
	if err != nil {
		return nil, err
	}
	return newStream(ch, opts), nil
}

// NewChannelStream constructs NewStream's byte-stream adapter over an existing
// Channel, for a caller that first exchanged whole frames on it. The adapter
// starts with an empty plaintext read buffer and continues the Channel's send
// and receive sequence numbers; it never initializes keys again. The caller
// must stop using ch directly once the adapter exists.
func NewChannelStream(ch *Channel, opts ...StreamOption) (io.ReadWriteCloser, error) {
	if ch == nil {
		return nil, ErrNilChannel
	}
	return newStream(ch, opts), nil
}

func newStream(ch *Channel, opts []StreamOption) *stream {
	cfg := streamConfig{}
	for _, opt := range opts {
		if opt == nil {
			continue
		}
		opt(&cfg)
	}
	return &stream{
		channel:              ch,
		allowEmptyDataFrames: cfg.allowEmptyDataFrames,
	}
}

// StreamOption customizes stream adapter behavior. Options are applied in
// order; nil options are ignored.
type StreamOption func(*streamConfig)

type streamConfig struct {
	allowEmptyDataFrames bool
}

// AllowEmptyDataFrames makes Stream.Read skip authenticated empty data frames
// instead of returning ErrStreamEmptyDataFrame. While a peer sends only empty
// frames, Read may keep processing frames without returning; callers that need
// cancellation or deadlines must enforce them through the underlying transport.
func AllowEmptyDataFrames() StreamOption {
	return func(cfg *streamConfig) {
		cfg.allowEmptyDataFrames = true
	}
}

type stream struct {
	channel              *Channel
	readMu               sync.Mutex
	writeMu              sync.Mutex
	readBuf              []byte
	readErr              error
	allowEmptyDataFrames bool
}

func (s *stream) Read(p []byte) (int, error) {
	s.readMu.Lock()
	defer s.readMu.Unlock()

	if len(p) == 0 {
		return 0, nil
	}
	if s.readErr != nil {
		return 0, s.readErr
	}

	for len(s.readBuf) == 0 {
		payload, err := s.channel.Receive()
		if err != nil {
			return 0, err
		}
		if len(payload) == 0 {
			if s.allowEmptyDataFrames {
				continue
			}
			s.readErr = ErrStreamEmptyDataFrame
			return 0, s.readErr
		}
		s.readBuf = payload
	}

	n := copy(p, s.readBuf)
	s.readBuf = s.readBuf[n:]
	return n, nil
}

func (s *stream) Write(p []byte) (int, error) {
	s.writeMu.Lock()
	defer s.writeMu.Unlock()

	if len(p) == 0 {
		return 0, nil
	}

	written := 0
	for len(p) > 0 {
		chunkLen := min(len(p), MaxPayloadSize)
		if err := s.channel.Send(p[:chunkLen]); err != nil {
			return written, err
		}
		written += chunkLen
		p = p[chunkLen:]
	}
	return written, nil
}

func (s *stream) Close() error {
	s.writeMu.Lock()
	defer s.writeMu.Unlock()

	return s.channel.Close()
}
