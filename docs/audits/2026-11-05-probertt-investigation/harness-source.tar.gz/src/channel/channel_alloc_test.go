// Allocation-ceiling pins for the channel data plane, deferred from the
// 2026-08-28 baseline benchmarks (#1403) until buffer reuse made the property
// worth freezing. The race detector changes allocation behavior, so these
// pins run only in non-race builds; the race lane still runs every behavioral
// test in this package.

//go:build !race

package channel

import (
	"bytes"
	"testing"
)

func testChannelSendSteadyStateAllocs(t *testing.T, size int) {
	t.Helper()

	ch, err := NewChannel(discardReadWriter{}, aliceAuth())
	if err != nil {
		t.Fatalf("NewChannel: %v", err)
	}
	payload := bytes.Repeat([]byte{0xA5}, size)

	allocs := testing.AllocsPerRun(100, func() {
		if err := ch.Send(payload); err != nil {
			t.Fatalf("Send: %v", err)
		}
	})
	if allocs != 0 {
		t.Errorf("Send of %d bytes allocates %.1f objects per call in steady state, want 0; the per-channel scratch buffers are no longer reused", size, allocs)
	}
}

func TestChannelSendSteadyStateAllocationCeiling1KiB(t *testing.T) {
	testChannelSendSteadyStateAllocs(t, 1024)
}

func TestChannelSendSteadyStateAllocationCeiling64KiB(t *testing.T) {
	testChannelSendSteadyStateAllocs(t, MaxPayloadSize)
}

func testChannelReceiveSteadyStateAllocs(t *testing.T, size int) {
	t.Helper()

	wire := &bytes.Buffer{}
	sender := mustChannel(t, wire, aliceAuth())
	receiver := mustChannel(t, wire, bobAuth())
	payload := bytes.Repeat([]byte{0xA5}, size)

	// AllocsPerRun performs one warm-up call before its measured runs, so the
	// wire must hold runs+1 frames before measurement starts.
	const runs = 100
	for range runs + 1 {
		if err := sender.Send(payload); err != nil {
			t.Fatalf("Send: %v", err)
		}
	}

	allocs := testing.AllocsPerRun(runs, func() {
		got, err := receiver.Receive()
		if err != nil {
			t.Fatalf("Receive: %v", err)
		}
		if len(got) != size {
			t.Fatalf("Receive returned %d bytes, want %d", len(got), size)
		}
	})
	if allocs != 0 {
		t.Errorf("Receive of %d bytes allocates %.1f objects per call in steady state, want 0; the per-channel scratch buffers are no longer reused", size, allocs)
	}
}

func TestChannelReceiveSteadyStateAllocationCeiling1KiB(t *testing.T) {
	testChannelReceiveSteadyStateAllocs(t, 1024)
}

func TestChannelReceiveSteadyStateAllocationCeiling64KiB(t *testing.T) {
	testChannelReceiveSteadyStateAllocs(t, MaxPayloadSize)
}
