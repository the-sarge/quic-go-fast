package channel

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"math"
	"sync"

	"github.com/GridSwarm/wiremux/connect"
)

const (
	// MaxPayloadSize is the largest plaintext payload accepted by Send.
	MaxPayloadSize = 64 * 1024

	frameHeaderSize = 4
	frameTypeData   = 0x01
	frameTypeClose  = 0x02
	directionOne    = 0x01
	directionTwo    = 0x02
)

var (
	// ErrNilReadWriter reports a nil stream passed to NewChannel or NewStream.
	ErrNilReadWriter = errors.New("channel: read writer is nil")

	// ErrNilChannel reports a nil Channel passed to NewChannelStream.
	ErrNilChannel = errors.New("channel: channel is nil")

	// ErrNilAuthContext reports a nil auth context passed to NewChannel or NewStream.
	ErrNilAuthContext = errors.New("channel: auth context is nil")

	// ErrEmptyDirectionalKey reports an empty SendKey or ReceiveKey. It is
	// identical to connect.ErrEmptyDirectionalKey and uses connect's error text.
	ErrEmptyDirectionalKey = connect.ErrEmptyDirectionalKey

	// ErrEqualDirectionalKeys reports identical SendKey and ReceiveKey values.
	// It is identical to connect.ErrEqualDirectionalKeys and uses connect's
	// error text.
	ErrEqualDirectionalKeys = connect.ErrEqualDirectionalKeys

	// ErrInvalidDirectionalKeySize reports keys that cannot be used directly as
	// AES keys. It is identical to connect.ErrInvalidDirectionalKeySize and uses
	// connect's error text.
	ErrInvalidDirectionalKeySize = connect.ErrInvalidDirectionalKeySize

	// ErrFrameTooLarge reports a frame that exceeds MaxPayloadSize.
	ErrFrameTooLarge = errors.New("channel: frame too large")

	// ErrAuthentication reports an AEAD verification, replay, reordering, reflection, or gap failure.
	ErrAuthentication = errors.New("channel: frame authentication failed")

	// ErrTruncated reports raw EOF before an authenticated close frame. The
	// transport's EOF-class error is wrapped beneath it as the cause.
	ErrTruncated = errors.New("channel: stream ended before authenticated close frame")

	// ErrClosed reports sends after the local channel was closed.
	ErrClosed = errors.New("channel: closed")

	// ErrNonceExhausted reports sequence exhaustion before nonce reuse.
	ErrNonceExhausted = errors.New("channel: nonce counter exhausted")

	// ErrStreamEmptyDataFrame reports an authenticated empty data frame received by Stream.Read.
	ErrStreamEmptyDataFrame = fmt.Errorf("channel: authenticated empty data frame: %w", io.ErrNoProgress)
)

// Channel is an encrypted framed channel over an authenticated byte stream.
type Channel struct {
	rw io.ReadWriter

	sendAEAD cipher.AEAD
	recvAEAD cipher.AEAD
	sendDir  byte
	recvDir  byte

	sendMu    sync.Mutex
	sendSeq   uint64
	sendClose bool
	sendErr   error
	sendBuf   []byte
	sendNonce []byte
	sendAAD   []byte

	recvMu     sync.Mutex
	recvSeq    uint64
	recvClose  bool
	recvBuf    []byte
	recvNonce  []byte
	recvAAD    []byte
	recvHeader [frameHeaderSize]byte

	fatalMu  sync.Mutex
	fatalErr error

	closeMu          sync.Mutex
	underlyingClosed bool
}

// NewChannel constructs an encrypted framed channel over rw.
//
// The channel uses auth.SendKey and auth.ReceiveKey directly as AES-GCM keys;
// it does not call auth.Exporter. The two keys must be non-empty, distinct,
// and valid AES key sizes. Each AuthContext/key pair must initialize at most
// one Channel or Stream, because channel nonces start at zero and key/nonce
// reuse breaks AES-GCM security. Key freshness and domain separation are the
// caller or identity layer's responsibility. When auth implements
// connect.ChannelUseClaimer, construction makes one irreversible claim before
// reading keys; a later validation or construction failure does not restore it.
func NewChannel(rw io.ReadWriter, auth connect.AuthContext) (*Channel, error) {
	if rw == nil {
		return nil, ErrNilReadWriter
	}
	if auth == nil {
		return nil, ErrNilAuthContext
	}
	if claimer, ok := auth.(connect.ChannelUseClaimer); ok {
		if err := claimer.ClaimChannelUse(); err != nil {
			return nil, err
		}
	}

	keys, err := connect.NewDirectionalKeys(auth)
	if err != nil {
		return nil, err
	}
	defer keys.Clear()

	sendKey := keys.SendKey()
	receiveKey := keys.ReceiveKey()
	defer clear(sendKey)
	defer clear(receiveKey)

	sendAEAD, err := newAEAD(sendKey)
	if err != nil {
		return nil, err
	}
	recvAEAD, err := newAEAD(receiveKey)
	if err != nil {
		return nil, err
	}

	sendDir := directionForOrientation(keys.Orientation())
	return &Channel{
		rw:       rw,
		sendAEAD: sendAEAD,
		recvAEAD: recvAEAD,
		sendDir:  sendDir,
		recvDir:  mirrorDirection(sendDir),
	}, nil
}

// Send encrypts and writes one data frame.
//
// The payload is copied into a channel-owned buffer before encryption; the
// channel never retains or mutates the caller's slice.
//
// A transport write failure is terminal for the send side only: later Send
// and Close calls return that same error without writing, while Receive keeps
// reading already-delivered frames until its own EOF, close frame, or error.
// A receive-side integrity or truncation failure remains fatal for both
// directions and takes precedence, so once Receive has failed that way, later
// Send and Close calls report the receive-side error instead.
//
// Zero-length data frames are valid for Channel. NewStream's byte-stream
// adapter rejects authenticated empty data frames with ErrStreamEmptyDataFrame
// by default; AllowEmptyDataFrames makes it skip them.
func (c *Channel) Send(payload []byte) error {
	return c.sendFrame(frameTypeData, payload)
}

// Receive reads, verifies, and decrypts one data frame.
//
// The returned payload aliases a channel-owned receive buffer that a later
// Receive call reuses, so it is valid only until the next Receive or Close
// call on the channel. A caller that needs the bytes longer must copy them
// first.
//
// An authenticated close frame returns io.EOF. A raw EOF before that frame
// returns an error wrapping ErrTruncated and the transport's EOF-class cause.
// A send-side transport write failure does not affect
// Receive: after Send fails, Receive still returns frames the peer already
// delivered and then reports its own EOF, close frame, or read error.
func (c *Channel) Receive() ([]byte, error) {
	c.recvMu.Lock()
	defer c.recvMu.Unlock()

	if err := c.fatal(); err != nil {
		return nil, err
	}
	if c.recvClose {
		return nil, io.EOF
	}
	if c.recvSeq == math.MaxUint64 {
		return nil, c.setFatal(ErrNonceExhausted)
	}

	if _, err := io.ReadFull(c.rw, c.recvHeader[:]); err != nil {
		return nil, c.setFatal(readFrameError(err))
	}

	ciphertextLen := binary.BigEndian.Uint32(c.recvHeader[:])
	maxCiphertextLen, ok := uint32Length(MaxPayloadSize + 1 + c.recvAEAD.Overhead())
	if !ok {
		return nil, c.setFatal(fmt.Errorf("%w: configured ciphertext limit exceeds uint32", ErrFrameTooLarge))
	}
	if ciphertextLen > maxCiphertextLen {
		return nil, c.setFatal(fmt.Errorf("%w: ciphertext length %d exceeds %d", ErrFrameTooLarge, ciphertextLen, maxCiphertextLen))
	}

	if cap(c.recvBuf) < int(ciphertextLen) {
		c.recvBuf = make([]byte, ciphertextLen)
	}
	ciphertext := c.recvBuf[:ciphertextLen]
	if _, err := io.ReadFull(c.rw, ciphertext); err != nil {
		return nil, c.setFatal(readFrameError(err))
	}

	c.recvNonce = nonceInto(c.recvNonce, c.recvSeq, c.recvAEAD.NonceSize())
	c.recvAAD = aadInto(c.recvAAD, c.recvDir, c.recvSeq, c.recvHeader)
	plaintext, err := c.recvAEAD.Open(ciphertext[:0], c.recvNonce, ciphertext, c.recvAAD)
	if err != nil || len(plaintext) == 0 {
		return nil, c.setFatal(ErrAuthentication)
	}
	c.recvSeq++

	frameType := plaintext[0]
	payload := plaintext[1:]
	switch frameType {
	case frameTypeData:
		return payload, nil
	case frameTypeClose:
		if len(payload) != 0 {
			return nil, c.setFatal(ErrAuthentication)
		}
		c.recvClose = true
		return nil, io.EOF
	default:
		return nil, c.setFatal(ErrAuthentication)
	}
}

// Close sends the authenticated close frame and closes the underlying stream
// when it implements io.Closer.
func (c *Channel) Close() error {
	err := c.sendFrame(frameTypeClose, nil)
	closeErr := c.closeUnderlying()
	if errors.Is(err, ErrClosed) {
		err = nil
	}
	if err == nil {
		err = closeErr
	}
	return err
}

func (c *Channel) sendFrame(frameType byte, payload []byte) error {
	c.sendMu.Lock()
	defer c.sendMu.Unlock()

	if err := c.fatal(); err != nil {
		return err
	}
	if c.sendErr != nil {
		return c.sendErr
	}
	if c.sendClose {
		return ErrClosed
	}
	if len(payload) > MaxPayloadSize {
		return fmt.Errorf("%w: payload length %d exceeds %d", ErrFrameTooLarge, len(payload), MaxPayloadSize)
	}
	if c.sendSeq == math.MaxUint64 {
		return ErrNonceExhausted
	}

	frameLen := 1 + len(payload)
	ciphertextLen, ok := uint32Length(frameLen + c.sendAEAD.Overhead())
	if !ok {
		return fmt.Errorf("%w: ciphertext length exceeds uint32", ErrFrameTooLarge)
	}
	// The record is sealed behind its length header in one buffer and handed
	// to the transport in one Write: a header written on its own costs the
	// native stream a short packet and the relay stream a TLS record per frame.
	recordLen := frameHeaderSize + int(ciphertextLen)
	if cap(c.sendBuf) < recordLen {
		c.sendBuf = make([]byte, recordLen)
	}
	header := c.sendBuf[:frameHeaderSize]
	binary.BigEndian.PutUint32(header, ciphertextLen)
	plaintext := c.sendBuf[frameHeaderSize : frameHeaderSize+frameLen]
	plaintext[0] = frameType
	copy(plaintext[1:], payload)

	seq := c.sendSeq
	c.sendSeq++

	c.sendNonce = nonceInto(c.sendNonce, seq, c.sendAEAD.NonceSize())
	c.sendAAD = aadInto(c.sendAAD, c.sendDir, seq, [frameHeaderSize]byte(header))
	ciphertext := c.sendAEAD.Seal(plaintext[:0], c.sendNonce, plaintext, c.sendAAD)
	if err := writeFull(c.rw, c.sendBuf[:frameHeaderSize+len(ciphertext)]); err != nil {
		return c.setSendErr(err)
	}

	if frameType == frameTypeClose {
		c.sendClose = true
	}
	return nil
}

// setSendErr records a send-side transport failure. The caller holds sendMu.
// Unlike setFatal, it leaves Receive free to drain frames the peer already
// delivered: a local write failure carries no information about inbound data.
func (c *Channel) setSendErr(err error) error {
	if c.sendErr == nil {
		c.sendErr = err
	}
	return c.sendErr
}

func (c *Channel) setFatal(err error) error {
	c.fatalMu.Lock()
	defer c.fatalMu.Unlock()

	if c.fatalErr == nil {
		c.fatalErr = err
	}
	return c.fatalErr
}

func (c *Channel) fatal() error {
	c.fatalMu.Lock()
	defer c.fatalMu.Unlock()

	return c.fatalErr
}

func uint32Length(n int) (uint32, bool) {
	if n < 0 {
		return 0, false
	}
	if uint64(n) > math.MaxUint32 {
		return 0, false
	}
	return uint32(n), true
}

func (c *Channel) closeUnderlying() error {
	closer, ok := c.rw.(io.Closer)
	if !ok {
		return nil
	}

	c.closeMu.Lock()
	defer c.closeMu.Unlock()

	if c.underlyingClosed {
		return nil
	}
	c.underlyingClosed = true
	return closer.Close()
}

func newAEAD(key []byte) (cipher.AEAD, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("%w: %d bytes", ErrInvalidDirectionalKeySize, len(key))
	}

	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return aead, nil
}

func directionForOrientation(orientation connect.DirectionalKeyOrientation) byte {
	if orientation == connect.DirectionalKeyOrientationSendHashGreater {
		return directionOne
	}
	return directionTwo
}

func mirrorDirection(direction byte) byte {
	if direction == directionOne {
		return directionTwo
	}
	return directionOne
}

func nonce(seq uint64, size int) []byte {
	return nonceInto(nil, seq, size)
}

// nonceInto writes the counter nonce for seq into buf, growing it only when
// its capacity is too small, and returns the possibly regrown slice so a
// channel can reuse one nonce buffer per direction across frames.
func nonceInto(buf []byte, seq uint64, size int) []byte {
	if cap(buf) < size {
		buf = make([]byte, size)
	}
	buf = buf[:size]
	clear(buf[:size-8])
	binary.BigEndian.PutUint64(buf[size-8:], seq)
	return buf
}

func aad(direction byte, seq uint64, header [frameHeaderSize]byte) []byte {
	return aadInto(nil, direction, seq, header)
}

// aadInto writes the frame's additional authenticated data into buf, growing
// it only when its capacity is too small, and returns the possibly regrown
// slice so a channel can reuse one AAD buffer per direction across frames.
func aadInto(buf []byte, direction byte, seq uint64, header [frameHeaderSize]byte) []byte {
	const aadLen = 1 + 8 + frameHeaderSize
	if cap(buf) < aadLen {
		buf = make([]byte, 0, aadLen)
	}
	out := buf[:0]
	out = append(out, direction)
	out = binary.BigEndian.AppendUint64(out, seq)
	out = append(out, header[:]...)
	return out
}

// readFrameError classifies a transport read failure. A raw EOF before the
// authenticated close frame is ErrTruncated. The transport's own error stays
// reachable as the cause so a wrapped transport sentinel (for example a relay
// reporting why it closed the stream) remains observable with errors.Is, but
// the EOF identities themselves are hidden: a truncated stream must never
// match io.EOF, which this package reserves for the authenticated close.
func readFrameError(err error) error {
	if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
		return fmt.Errorf("%w: %w", ErrTruncated, &truncationCauseError{cause: err})
	}
	return err
}

// truncationCauseError exposes every identity in a transport error except io.EOF
// and io.ErrUnexpectedEOF. It deliberately has no Unwrap so tree walkers
// cannot reach the EOF sentinels beneath it; matching goes through Is.
type truncationCauseError struct {
	cause error
}

func (c *truncationCauseError) Error() string { return c.cause.Error() }

func (c *truncationCauseError) Is(target error) bool {
	if target == io.EOF || target == io.ErrUnexpectedEOF {
		return false
	}
	return errors.Is(c.cause, target)
}

func writeFull(w io.Writer, p []byte) error {
	for len(p) > 0 {
		n, err := w.Write(p)
		if n > 0 {
			p = p[n:]
		}
		if err != nil {
			return err
		}
		if n == 0 {
			return io.ErrShortWrite
		}
	}
	return nil
}
