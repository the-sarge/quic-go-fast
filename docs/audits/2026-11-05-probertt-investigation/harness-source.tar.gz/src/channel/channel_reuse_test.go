package channel

import (
	"bytes"
	"testing"
)

// TestChannelReceivePayloadInvalidatedByNextReceive pins the documented
// payload lifetime: the slice Receive returns is valid only until the next
// Receive or Close call, because it aliases the channel's reused receive
// buffer. Two equal-length frames land at the same offset of that buffer, so
// the second Receive deterministically overwrites the first payload. If this
// test fails because Receive started returning caller-owned copies, that is a
// deliberate contract change: update the Receive documentation and the
// allocation pins together with this test.
func TestChannelReceivePayloadInvalidatedByNextReceive(t *testing.T) {
	wire := &bytes.Buffer{}
	alice := mustChannel(t, wire, aliceAuth())
	bob := mustChannel(t, wire, bobAuth())

	if err := alice.Send([]byte("frame-one")); err != nil {
		t.Fatalf("Send frame-one: %v", err)
	}
	if err := alice.Send([]byte("frame-two")); err != nil {
		t.Fatalf("Send frame-two: %v", err)
	}

	first, err := bob.Receive()
	if err != nil {
		t.Fatalf("first Receive: %v", err)
	}
	if string(first) != "frame-one" {
		t.Fatalf("first Receive = %q, want frame-one", first)
	}

	second, err := bob.Receive()
	if err != nil {
		t.Fatalf("second Receive: %v", err)
	}
	if string(second) != "frame-two" {
		t.Fatalf("second Receive = %q, want frame-two", second)
	}

	if string(first) != "frame-two" {
		t.Fatalf("payload from the first Receive = %q after the next Receive, want it to alias the reused buffer now holding frame-two", first)
	}
}
