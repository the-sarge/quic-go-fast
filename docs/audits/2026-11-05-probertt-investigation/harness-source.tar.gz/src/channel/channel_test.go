package channel

import (
	"bytes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/connect"
	"github.com/GridSwarm/wiremux/internal/nettest"
)

var (
	aliceSendKey, aliceRecvKey = channelDirectionalKeys()

	errInjectedWrite         = errors.New("injected write failure")
	errUnexpectedSecondClose = errors.New("unexpected second close")
)

type testOverheadAEAD struct {
	cipher.AEAD
	overhead int
}

func (a testOverheadAEAD) Overhead() int {
	return a.overhead
}

func TestNewChannelRejectsInvalidAuth(t *testing.T) {
	tests := []struct {
		name    string
		auth    connect.AuthContext
		wantErr error
	}{
		{
			name:    "nil auth context",
			auth:    nil,
			wantErr: ErrNilAuthContext,
		},
		{
			name:    "empty send key",
			auth:    authFixture{sendKey: nil, receiveKey: aliceRecvKey},
			wantErr: ErrEmptyDirectionalKey,
		},
		{
			name:    "empty receive key",
			auth:    authFixture{sendKey: aliceSendKey, receiveKey: nil},
			wantErr: ErrEmptyDirectionalKey,
		},
		{
			name:    "equal keys",
			auth:    authFixture{sendKey: aliceSendKey, receiveKey: aliceSendKey},
			wantErr: ErrEqualDirectionalKeys,
		},
		{
			name:    "invalid send key size",
			auth:    authFixture{sendKey: []byte("too-short"), receiveKey: aliceRecvKey},
			wantErr: ErrInvalidDirectionalKeySize,
		},
		{
			name:    "invalid receive key size",
			auth:    authFixture{sendKey: aliceSendKey, receiveKey: []byte("too-short")},
			wantErr: ErrInvalidDirectionalKeySize,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := NewChannel(&bytes.Buffer{}, tt.auth)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("NewChannel error = %v, want %v", err, tt.wantErr)
			}
			if got != nil {
				t.Fatalf("NewChannel returned %v, want nil", got)
			}
		})
	}
}

func TestNewChannelRejectsNilReadWriter(t *testing.T) {
	got, err := NewChannel(nil, aliceAuth())
	if !errors.Is(err, ErrNilReadWriter) {
		t.Fatalf("NewChannel nil rw error = %v, want %v", err, ErrNilReadWriter)
	}
	if got != nil {
		t.Fatalf("NewChannel returned %v, want nil", got)
	}
}

func TestNewStreamRejectsEqualDirectionalKeys(t *testing.T) {
	got, err := NewStream(&bytes.Buffer{}, authFixture{sendKey: aliceSendKey, receiveKey: aliceSendKey})
	if !errors.Is(err, ErrEqualDirectionalKeys) {
		t.Fatalf("NewStream equal key error = %v, want %v", err, ErrEqualDirectionalKeys)
	}
	if got != nil {
		t.Fatalf("NewStream returned %v, want nil", got)
	}
}

func TestDirectionalKeyErrorsAliasConnect(t *testing.T) {
	if ErrEmptyDirectionalKey != connect.ErrEmptyDirectionalKey { //nolint:errorlint // Public alias identity is the contract under test.
		t.Fatalf("ErrEmptyDirectionalKey does not alias connect.ErrEmptyDirectionalKey")
	}
	if ErrEqualDirectionalKeys != connect.ErrEqualDirectionalKeys { //nolint:errorlint // Public alias identity is the contract under test.
		t.Fatalf("ErrEqualDirectionalKeys does not alias connect.ErrEqualDirectionalKeys")
	}
	if ErrInvalidDirectionalKeySize != connect.ErrInvalidDirectionalKeySize { //nolint:errorlint // Public alias identity is the contract under test.
		t.Fatalf("ErrInvalidDirectionalKeySize does not alias connect.ErrInvalidDirectionalKeySize")
	}
}

func TestChannelSendReceiveRoundTrip(t *testing.T) {
	wire := &bytes.Buffer{}
	alice := mustChannel(t, wire, aliceAuth())

	if err := alice.Send([]byte("hello")); err != nil {
		t.Fatalf("Send: %v", err)
	}
	captured := append([]byte(nil), wire.Bytes()...)
	if bytes.Contains(captured, []byte("hello")) {
		t.Fatalf("wire frame contains plaintext payload: %x", captured)
	}

	bob := mustChannel(t, bytes.NewBuffer(captured), bobAuth())
	got, err := bob.Receive()
	if err != nil {
		t.Fatalf("Receive: %v", err)
	}
	if string(got) != "hello" {
		t.Fatalf("Receive = %q, want hello", got)
	}
}

func TestNewChannelAndStreamAcceptNettestDefaultAuth(t *testing.T) {
	t.Run("channel", func(t *testing.T) {
		ch, err := NewChannel(&bytes.Buffer{}, nettest.NewAuthContext())
		if err != nil {
			t.Fatalf("NewChannel with nettest auth: %v", err)
		}
		if ch == nil {
			t.Fatal("NewChannel returned nil")
		}
	})

	t.Run("stream", func(t *testing.T) {
		stream, err := NewStream(&bytes.Buffer{}, nettest.NewAuthContext(), nil)
		if err != nil {
			t.Fatalf("NewStream with nettest default auth and nil option: %v", err)
		}
		if stream == nil {
			t.Fatal("NewStream returned nil")
		}
	})
}

func TestNewStreamAppliesOptionsInOrder(t *testing.T) {
	setAllowEmptyDataFrames := func(allow bool) StreamOption {
		return func(cfg *streamConfig) {
			cfg.allowEmptyDataFrames = allow
		}
	}

	tests := []struct {
		name                string
		opts                []StreamOption
		wantEmptyDataFrames bool
	}{
		{
			name:                "later option disables earlier option",
			opts:                []StreamOption{setAllowEmptyDataFrames(true), nil, setAllowEmptyDataFrames(false)},
			wantEmptyDataFrames: false,
		},
		{
			name:                "later option enables earlier option",
			opts:                []StreamOption{setAllowEmptyDataFrames(false), nil, setAllowEmptyDataFrames(true)},
			wantEmptyDataFrames: true,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			got, err := NewStream(&bytes.Buffer{}, nettest.NewAuthContext(), test.opts...)
			if err != nil {
				t.Fatalf("NewStream: %v", err)
			}

			gotStream, ok := got.(*stream)
			if !ok {
				t.Fatalf("NewStream returned %T, want *stream", got)
			}
			if gotStream.allowEmptyDataFrames != test.wantEmptyDataFrames {
				t.Fatalf("allowEmptyDataFrames = %v, want %v", gotStream.allowEmptyDataFrames, test.wantEmptyDataFrames)
			}
		})
	}
}

func TestChannelRoundtripsZeroLengthDataFrame(t *testing.T) {
	wire := &bytes.Buffer{}
	alice := mustChannel(t, wire, aliceAuth())
	if err := alice.Send(nil); err != nil {
		t.Fatalf("Send zero-length frame: %v", err)
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	bob := mustChannel(t, bytes.NewBuffer(wire.Bytes()), bobAuth())
	got, err := bob.Receive()
	if err != nil {
		t.Fatalf("Receive zero-length frame: %v", err)
	}
	if len(got) != 0 {
		t.Fatalf("Receive zero-length frame length = %d, want 0", len(got))
	}
	_, err = bob.Receive()
	if !errors.Is(err, io.EOF) {
		t.Fatalf("Receive close frame error = %v, want %v", err, io.EOF)
	}
}

func TestChannelRejectsOversizedPayload(t *testing.T) {
	alice := mustChannel(t, &bytes.Buffer{}, aliceAuth())

	err := alice.Send(make([]byte, MaxPayloadSize+1))
	if !errors.Is(err, ErrFrameTooLarge) {
		t.Fatalf("Send oversized error = %v, want %v", err, ErrFrameTooLarge)
	}
	if alice.sendSeq != 0 {
		t.Fatalf("sendSeq after oversized payload = %d, want 0", alice.sendSeq)
	}
}

func TestChannelCiphertextLengthRejectionDoesNotReserveSequence(t *testing.T) {
	if math.MaxInt <= math.MaxUint32 {
		t.Skip("int cannot represent a ciphertext length above uint32 on this platform")
	}

	alice := mustChannel(t, &bytes.Buffer{}, aliceAuth())
	alice.sendAEAD = testOverheadAEAD{
		AEAD:     alice.sendAEAD,
		overhead: math.MaxInt,
	}

	err := alice.Send([]byte("first"))
	if !errors.Is(err, ErrFrameTooLarge) {
		t.Fatalf("Send with oversized ciphertext length error = %v, want %v", err, ErrFrameTooLarge)
	}
	if alice.sendSeq != 0 {
		t.Fatalf("sendSeq after oversized ciphertext length = %d, want 0", alice.sendSeq)
	}
}

func TestChannelReceiveRejectsOversizedFrameHeader(t *testing.T) {
	bob := mustChannel(t, &bytes.Buffer{}, bobAuth())
	maxCiphertextLen, ok := uint32Length(MaxPayloadSize + 1 + bob.recvAEAD.Overhead())
	if !ok {
		t.Fatal("max ciphertext length exceeds uint32")
	}

	var header [frameHeaderSize]byte
	binary.BigEndian.PutUint32(header[:], maxCiphertextLen+1)
	bob.rw = bytes.NewBuffer(header[:])

	_, err := bob.Receive()
	if !errors.Is(err, ErrFrameTooLarge) {
		t.Fatalf("Receive oversized frame header error = %v, want %v", err, ErrFrameTooLarge)
	}

	_, secondErr := bob.Receive()
	if secondErr != err { //nolint:errorlint // Latched error identity is the contract under test.
		t.Fatalf("Receive after oversized frame error = %v, want same latched error %v", secondErr, err)
	}
}

func TestChannelUsesMonotonicCounterNonces(t *testing.T) {
	wire := encryptedFrames(t, aliceAuth(), "same", "same")
	frames := splitFrames(t, wire)

	if bytes.Equal(frames[0], frames[1]) {
		t.Fatalf("identical payloads produced identical frames; nonce counter may not be advancing")
	}
}

func TestChannelTerminatesBeforeNonceExhaustion(t *testing.T) {
	alice := mustChannel(t, &bytes.Buffer{}, aliceAuth())
	alice.sendSeq = math.MaxUint64

	err := alice.Send([]byte("after exhaustion"))
	if !errors.Is(err, ErrNonceExhausted) {
		t.Fatalf("Send after nonce exhaustion error = %v, want %v", err, ErrNonceExhausted)
	}

	bob := mustChannel(t, &bytes.Buffer{}, bobAuth())
	bob.recvSeq = math.MaxUint64
	_, err = bob.Receive()
	if !errors.Is(err, ErrNonceExhausted) {
		t.Fatalf("Receive after nonce exhaustion error = %v, want %v", err, ErrNonceExhausted)
	}
}

func TestChannelSendWriteFailureIsFatal(t *testing.T) {
	wire := &partialFailReadWriter{
		failAfter: frameHeaderSize + 3,
		err:       errInjectedWrite,
	}
	alice := mustChannel(t, wire, aliceAuth())

	err := alice.Send([]byte("first"))
	if !errors.Is(err, errInjectedWrite) {
		t.Fatalf("Send partial write error = %v, want %v", err, errInjectedWrite)
	}
	if alice.sendSeq != 1 {
		t.Fatalf("sendSeq after failed write = %d, want 1 reserved sequence", alice.sendSeq)
	}

	written := wire.Len()
	writeCalls := wire.writeCalls
	err = alice.Send([]byte("second"))
	if !errors.Is(err, errInjectedWrite) {
		t.Fatalf("Send after failed write error = %v, want %v", err, errInjectedWrite)
	}
	if wire.Len() != written {
		t.Fatalf("Send after failed write added %d bytes, want 0", wire.Len()-written)
	}
	if wire.writeCalls != writeCalls {
		t.Fatalf("Send after failed write called Write %d additional times, want 0", wire.writeCalls-writeCalls)
	}
	if alice.sendSeq != 1 {
		t.Fatalf("sendSeq after terminal send = %d, want 1", alice.sendSeq)
	}
}

func TestChannelZeroByteShortWriteIsFatal(t *testing.T) {
	wire := &zeroWriteReadWriter{}
	alice := mustChannel(t, wire, aliceAuth())

	err := alice.Send([]byte("first"))
	if !errors.Is(err, io.ErrShortWrite) {
		t.Fatalf("Send zero-byte write error = %v, want %v", err, io.ErrShortWrite)
	}

	writeCalls := wire.writeCalls
	err = alice.Send([]byte("second"))
	if !errors.Is(err, io.ErrShortWrite) {
		t.Fatalf("Send after short write error = %v, want %v", err, io.ErrShortWrite)
	}
	if wire.writeCalls != writeCalls {
		t.Fatalf("Send after short write called Write %d additional times, want 0", wire.writeCalls-writeCalls)
	}
	if alice.sendSeq != 1 {
		t.Fatalf("sendSeq after short write = %d, want 1", alice.sendSeq)
	}
}

func TestChannelDoesNotUseExporter(t *testing.T) {
	if _, err := NewChannel(&bytes.Buffer{}, exporterPanicAuth{authFixture: aliceAuth()}); err != nil {
		t.Fatalf("NewChannel with panicking exporter: %v", err)
	}
}

func TestChannelReplayIsFatal(t *testing.T) {
	wire := &bytes.Buffer{}
	alice := mustChannel(t, wire, aliceAuth())
	if err := alice.Send([]byte("first")); err != nil {
		t.Fatalf("Send first: %v", err)
	}
	frame := append([]byte(nil), wire.Bytes()...)
	replayed := append(append([]byte(nil), frame...), frame...)

	bob := mustChannel(t, bytes.NewBuffer(replayed), bobAuth())
	if _, err := bob.Receive(); err != nil {
		t.Fatalf("Receive first: %v", err)
	}
	_, err := bob.Receive()
	if !errors.Is(err, ErrAuthentication) {
		t.Fatalf("Receive replay error = %v, want %v", err, ErrAuthentication)
	}
	_, err = bob.Receive()
	if !errors.Is(err, ErrAuthentication) {
		t.Fatalf("Receive after fatal error = %v, want %v", err, ErrAuthentication)
	}
}

func TestChannelReorderingIsFatal(t *testing.T) {
	wire := encryptedFrames(t, aliceAuth(), "first", "second")
	frames := splitFrames(t, wire)

	bob := mustChannel(t, bytes.NewBuffer(append(frames[1], frames[0]...)), bobAuth())
	_, err := bob.Receive()
	if !errors.Is(err, ErrAuthentication) {
		t.Fatalf("Receive reordered frame error = %v, want %v", err, ErrAuthentication)
	}
}

func TestChannelMidstreamDropIsFatal(t *testing.T) {
	wire := encryptedFrames(t, aliceAuth(), "first", "second", "third")
	frames := splitFrames(t, wire)

	dropped := append(append([]byte(nil), frames[0]...), frames[2]...)
	bob := mustChannel(t, bytes.NewBuffer(dropped), bobAuth())
	if got, err := bob.Receive(); err != nil || string(got) != "first" {
		t.Fatalf("Receive first = %q, %v; want first, nil", got, err)
	}
	_, err := bob.Receive()
	if !errors.Is(err, ErrAuthentication) {
		t.Fatalf("Receive after dropped frame error = %v, want %v", err, ErrAuthentication)
	}
}

func TestChannelReflectedFrameIsFatal(t *testing.T) {
	wire := encryptedFrames(t, aliceAuth(), "reflected")

	alice := mustChannel(t, bytes.NewBuffer(wire), aliceAuth())
	_, err := alice.Receive()
	if !errors.Is(err, ErrAuthentication) {
		t.Fatalf("Receive reflected frame error = %v, want %v", err, ErrAuthentication)
	}
}

func TestChannelRejectsFrameSealedWithWrongDirectionAAD(t *testing.T) {
	payload := []byte("direction-bound")
	receiver := mustChannel(t, &bytes.Buffer{}, bobAuth())
	sealFrame := func(direction byte) []byte {
		t.Helper()

		plaintext := append([]byte{frameTypeData}, payload...)
		ciphertextLen, ok := uint32Length(len(plaintext) + receiver.recvAEAD.Overhead())
		if !ok {
			t.Fatal("ciphertext length exceeds uint32")
		}
		var header [frameHeaderSize]byte
		binary.BigEndian.PutUint32(header[:], ciphertextLen)

		ciphertext := receiver.recvAEAD.Seal(nil, nonce(0, receiver.recvAEAD.NonceSize()), plaintext, aad(direction, 0, header))
		wire := append([]byte(nil), header[:]...)
		wire = append(wire, ciphertext...)
		return wire
	}

	control := mustChannel(t, bytes.NewBuffer(sealFrame(receiver.recvDir)), bobAuth())
	got, err := control.Receive()
	if err != nil {
		t.Fatalf("Receive control frame: %v", err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("Receive control frame = %q, want %q", got, payload)
	}

	wrongDirection := mirrorDirection(receiver.recvDir)
	bob := mustChannel(t, bytes.NewBuffer(sealFrame(wrongDirection)), bobAuth())
	_, err = bob.Receive()
	if !errors.Is(err, ErrAuthentication) {
		t.Fatalf("Receive wrong-direction AAD frame error = %v, want %v", err, ErrAuthentication)
	}
}

func TestChannelSendAfterReceiveFatalWritesNothing(t *testing.T) {
	reflected := encryptedFrames(t, aliceAuth(), "reflected")
	wire := &splitReadWriter{read: bytes.NewReader(reflected)}
	alice := mustChannel(t, wire, aliceAuth())

	_, err := alice.Receive()
	if !errors.Is(err, ErrAuthentication) {
		t.Fatalf("Receive reflected frame error = %v, want %v", err, ErrAuthentication)
	}

	err = alice.Send([]byte("after fatal"))
	if !errors.Is(err, ErrAuthentication) {
		t.Fatalf("Send after receive fatal error = %v, want %v", err, ErrAuthentication)
	}
	if wire.write.Len() != 0 {
		t.Fatalf("Send after receive fatal wrote %d bytes, want 0", wire.write.Len())
	}
	if alice.sendSeq != 0 {
		t.Fatalf("sendSeq after receive fatal send = %d, want 0", alice.sendSeq)
	}
}

func TestChannelConcurrentSendReceiveFatalRace(t *testing.T) {
	left, right := net.Pipe()
	defer func() { _ = left.Close() }()
	defer func() { _ = right.Close() }()

	alice := mustChannel(t, left, aliceAuth())
	reflected := encryptedFrames(t, aliceAuth(), "reflected")

	drainDone := make(chan struct{})
	go func() {
		_, _ = io.Copy(io.Discard, right)
		close(drainDone)
	}()

	sendErr := make(chan error, 1)
	go func() {
		for {
			if err := alice.Send([]byte("payload")); err != nil {
				sendErr <- err
				return
			}
		}
	}()

	writeErr := make(chan error, 1)
	go func() {
		_, err := right.Write(reflected)
		writeErr <- err
	}()

	_, err := alice.Receive()
	if !errors.Is(err, ErrAuthentication) {
		t.Fatalf("Receive reflected frame error = %v, want %v", err, ErrAuthentication)
	}

	select {
	case err := <-writeErr:
		if err != nil {
			t.Fatalf("write reflected frame: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out writing reflected frame")
	}

	select {
	case err := <-sendErr:
		if !errors.Is(err, ErrAuthentication) {
			t.Fatalf("Send after concurrent receive fatal error = %v, want %v", err, ErrAuthentication)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for Send to observe fatal receive error")
	}

	_ = left.Close()
	_ = right.Close()
	select {
	case <-drainDone:
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for drain goroutine")
	}
}

func TestChannelRawEOFIsFatalTruncation(t *testing.T) {
	bob := mustChannel(t, bytes.NewBuffer(nil), bobAuth())

	_, err := bob.Receive()
	if !errors.Is(err, ErrTruncated) {
		t.Fatalf("Receive raw EOF error = %v, want %v", err, ErrTruncated)
	}
}

func TestChannelPartialFrameEOFIsFatalTruncation(t *testing.T) {
	wire := encryptedFrames(t, aliceAuth(), "first")
	truncated := wire[:len(wire)-1]
	bob := mustChannel(t, bytes.NewBuffer(truncated), bobAuth())

	_, err := bob.Receive()
	if !errors.Is(err, ErrTruncated) {
		t.Fatalf("Receive partial frame error = %v, want %v", err, ErrTruncated)
	}
}

func TestChannelCloseEmitsAuthenticatedCloseFrame(t *testing.T) {
	wire := &closeBuffer{}
	alice := mustChannel(t, wire, aliceAuth())

	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	if !wire.closed {
		t.Fatal("Close did not close underlying io.Closer")
	}
	if wire.Len() == 0 {
		t.Fatal("Close did not write an authenticated close frame")
	}

	bob := mustChannel(t, bytes.NewBuffer(wire.Bytes()), bobAuth())
	_, err := bob.Receive()
	if !errors.Is(err, io.EOF) {
		t.Fatalf("Receive close frame error = %v, want %v", err, io.EOF)
	}
}

func TestChannelSendsEachFrameInOneWrite(t *testing.T) {
	tests := []struct {
		name string
		send func(*Channel) error
		want []byte
	}{
		{
			name: "1KiBDataFrame",
			send: func(c *Channel) error { return c.Send(bytes.Repeat([]byte{0x5A}, 1024)) },
			want: bytes.Repeat([]byte{0x5A}, 1024),
		},
		{
			name: "64KiBDataFrame",
			send: func(c *Channel) error { return c.Send(bytes.Repeat([]byte{0xC3}, MaxPayloadSize)) },
			want: bytes.Repeat([]byte{0xC3}, MaxPayloadSize),
		},
		{
			name: "CloseFrame",
			send: (*Channel).Close,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			wire := &recordingWriteReadWriter{}
			alice := mustChannel(t, wire, aliceAuth())

			if err := tt.send(alice); err != nil {
				t.Fatalf("send: %v", err)
			}
			if got := len(wire.writes); got != 1 {
				t.Fatalf("transport Write calls: got %d, want 1", got)
			}
			record := wire.writes[0]
			if len(record) < frameHeaderSize {
				t.Fatalf("Write length: got %d, want at least the %d-byte header", len(record), frameHeaderSize)
			}
			if got, want := int(binary.BigEndian.Uint32(record[:frameHeaderSize])), len(record)-frameHeaderSize; got != want {
				t.Fatalf("header length: got %d, want %d bytes following it in the same Write", got, want)
			}

			bob := mustChannel(t, bytes.NewBuffer(record), bobAuth())
			got, err := bob.Receive()
			if tt.want == nil {
				if !errors.Is(err, io.EOF) {
					t.Fatalf("Receive close frame error: got %v, want %v", err, io.EOF)
				}
				return
			}
			if err != nil {
				t.Fatalf("Receive: %v", err)
			}
			if !bytes.Equal(got, tt.want) {
				t.Fatalf("Receive payload: got %d bytes, want %d matching bytes", len(got), len(tt.want))
			}
		})
	}
}

func TestChannelCloseClosesUnderlyingOnce(t *testing.T) {
	wire := &countingCloseBuffer{}
	alice := mustChannel(t, wire, aliceAuth())

	if err := alice.Close(); err != nil {
		t.Fatalf("first Close: %v", err)
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("second Close: %v", err)
	}
	if wire.closeCount != 1 {
		t.Fatalf("underlying Close count = %d, want 1", wire.closeCount)
	}
}

func TestChannelGracefulCloseAfterData(t *testing.T) {
	wire := &bytes.Buffer{}
	alice := mustChannel(t, wire, aliceAuth())

	if err := alice.Send([]byte("payload")); err != nil {
		t.Fatalf("Send: %v", err)
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	bob := mustChannel(t, wire, bobAuth())
	got, err := bob.Receive()
	if err != nil {
		t.Fatalf("Receive payload: %v", err)
	}
	if string(got) != "payload" {
		t.Fatalf("Receive payload = %q, want payload", got)
	}
	_, err = bob.Receive()
	if !errors.Is(err, io.EOF) {
		t.Fatalf("Receive close frame error = %v, want %v", err, io.EOF)
	}
}

func TestChannelRejectsMalformedAuthenticatedFrames(t *testing.T) {
	tests := []struct {
		name string
		send func(*Channel) error
	}{
		{
			name: "close frame with payload",
			send: func(ch *Channel) error {
				return ch.sendFrame(frameTypeClose, []byte("payload"))
			},
		},
		{
			name: "unknown frame type",
			send: func(ch *Channel) error {
				return ch.sendFrame(0xff, []byte("payload"))
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			wire := &bytes.Buffer{}
			alice := mustChannel(t, wire, aliceAuth())
			if err := tt.send(alice); err != nil {
				t.Fatalf("send malformed frame fixture: %v", err)
			}

			bob := mustChannel(t, bytes.NewBuffer(wire.Bytes()), bobAuth())
			_, err := bob.Receive()
			if !errors.Is(err, ErrAuthentication) {
				t.Fatalf("Receive malformed frame error = %v, want %v", err, ErrAuthentication)
			}
			_, err = bob.Receive()
			if !errors.Is(err, ErrAuthentication) {
				t.Fatalf("Receive after malformed frame error = %v, want %v", err, ErrAuthentication)
			}
		})
	}
}

func TestStreamReadWriteAndGracefulClose(t *testing.T) {
	wire := &bytes.Buffer{}
	alice, err := NewStream(wire, aliceAuth())
	if err != nil {
		t.Fatalf("NewStream alice: %v", err)
	}
	if n, err := alice.Write([]byte("hello world")); err != nil || n != len("hello world") {
		t.Fatalf("Write = %d, %v; want %d, nil", n, err, len("hello world"))
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	bob, err := NewStream(wire, bobAuth())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}
	buf := make([]byte, 5)
	n, err := bob.Read(buf)
	if err != nil {
		t.Fatalf("Read first chunk: %v", err)
	}
	if string(buf[:n]) != "hello" {
		t.Fatalf("Read first chunk = %q, want hello", buf[:n])
	}
	n, err = bob.Read(buf)
	if err != nil {
		t.Fatalf("Read second chunk: %v", err)
	}
	if string(buf[:n]) != " worl" {
		t.Fatalf("Read second chunk = %q, want ' worl'", buf[:n])
	}
	n, err = bob.Read(buf)
	if err != nil {
		t.Fatalf("Read third chunk: %v", err)
	}
	if string(buf[:n]) != "d" {
		t.Fatalf("Read third chunk = %q, want d", buf[:n])
	}
	n, err = bob.Read(buf)
	if n != 0 || !errors.Is(err, io.EOF) {
		t.Fatalf("Read after close = %d, %v; want 0, %v", n, err, io.EOF)
	}
}

func TestDirectionOrientationMirrorsBetweenPeers(t *testing.T) {
	aliceKeys, err := connect.NewDirectionalKeys(aliceAuth())
	if err != nil {
		t.Fatalf("NewDirectionalKeys alice: %v", err)
	}
	defer aliceKeys.Clear()
	bobKeys, err := connect.NewDirectionalKeys(bobAuth())
	if err != nil {
		t.Fatalf("NewDirectionalKeys bob: %v", err)
	}
	defer bobKeys.Clear()

	aliceDirection := directionForOrientation(aliceKeys.Orientation())
	bobDirection := directionForOrientation(bobKeys.Orientation())

	if aliceDirection == bobDirection {
		t.Fatalf("peer send directions both = %x, want mirrored directions", aliceDirection)
	}
	if mirrorDirection(aliceDirection) != bobDirection {
		t.Fatalf("mirrorDirection(%x) = %x, want %x", aliceDirection, mirrorDirection(aliceDirection), bobDirection)
	}
}

func TestNewChannelClaimsAuthContextOnce(t *testing.T) {
	auth := &claimingAuthFixture{authFixture: aliceAuth()}
	if _, err := NewChannel(&bytes.Buffer{}, auth); err != nil {
		t.Fatalf("first NewChannel: %v", err)
	}

	if _, err := NewChannel(&bytes.Buffer{}, auth); !errors.Is(err, connect.ErrChannelUseClaimed) {
		t.Fatalf("second NewChannel error = %v, want %v", err, connect.ErrChannelUseClaimed)
	}
	if auth.claimCalls != 2 {
		t.Fatalf("ClaimChannelUse calls = %d, want 2", auth.claimCalls)
	}
}

func TestNewChannelDoesNotRestoreClaimAfterInvalidKeys(t *testing.T) {
	auth := &claimingAuthFixture{authFixture: authFixture{
		sendKey:    []byte("invalid-size"),
		receiveKey: aliceRecvKey,
	}}
	if _, err := NewChannel(&bytes.Buffer{}, auth); !errors.Is(err, connect.ErrInvalidDirectionalKeySize) {
		t.Fatalf("first NewChannel error = %v, want %v", err, connect.ErrInvalidDirectionalKeySize)
	}

	auth.sendKey = aliceSendKey
	if _, err := NewChannel(&bytes.Buffer{}, auth); !errors.Is(err, connect.ErrChannelUseClaimed) {
		t.Fatalf("second NewChannel error = %v, want %v", err, connect.ErrChannelUseClaimed)
	}
}

func TestChannelConstructorsClaimOnlyAfterValidLocalInputs(t *testing.T) {
	t.Run("nil read writer", func(t *testing.T) {
		auth := &claimingAuthFixture{authFixture: aliceAuth()}
		if _, err := NewChannel(nil, auth); !errors.Is(err, ErrNilReadWriter) {
			t.Fatalf("NewChannel error = %v, want %v", err, ErrNilReadWriter)
		}
		if auth.claimCalls != 0 {
			t.Fatalf("ClaimChannelUse calls = %d, want 0", auth.claimCalls)
		}
	})

	t.Run("stream delegates one claim", func(t *testing.T) {
		auth := &claimingAuthFixture{authFixture: aliceAuth()}
		if _, err := NewStream(&bytes.Buffer{}, auth); err != nil {
			t.Fatalf("NewStream: %v", err)
		}
		if auth.claimCalls != 1 {
			t.Fatalf("ClaimChannelUse calls = %d, want 1", auth.claimCalls)
		}
	})
}

func TestCapabilityDroppingWrapperHidesOptionalChannelClaim(t *testing.T) {
	source := &claimingAuthFixture{authFixture: aliceAuth()}
	// This wrapper is deliberately non-conforming: embedding only the required
	// AuthContext surface hides the source's optional ChannelUseClaimer.
	dropped := struct{ connect.AuthContext }{AuthContext: source}
	if _, err := NewChannel(&bytes.Buffer{}, dropped); err != nil {
		t.Fatalf("first NewChannel through capability-dropping wrapper: %v", err)
	}
	if _, err := NewChannel(&bytes.Buffer{}, dropped); err != nil {
		t.Fatalf("second NewChannel through capability-dropping wrapper: %v", err)
	}
	if source.claimCalls != 0 {
		t.Fatalf("hidden ClaimChannelUse calls = %d, want 0", source.claimCalls)
	}
}

func encryptedFrames(t *testing.T, auth connect.AuthContext, payloads ...string) []byte {
	t.Helper()

	wire := &bytes.Buffer{}
	ch := mustChannel(t, wire, auth)
	for _, payload := range payloads {
		if err := ch.Send([]byte(payload)); err != nil {
			t.Fatalf("Send %q: %v", payload, err)
		}
	}
	return append([]byte(nil), wire.Bytes()...)
}

func splitFrames(t *testing.T, wire []byte) [][]byte {
	t.Helper()

	var frames [][]byte
	for len(wire) > 0 {
		if len(wire) < frameHeaderSize {
			t.Fatalf("truncated frame header in %x", wire)
		}
		frameLen := frameHeaderSize + int(binary.BigEndian.Uint32(wire[:frameHeaderSize]))
		if len(wire) < frameLen {
			t.Fatalf("truncated frame body: have %d want %d", len(wire), frameLen)
		}
		frames = append(frames, append([]byte(nil), wire[:frameLen]...))
		wire = wire[frameLen:]
	}
	return frames
}

func mustChannel(t *testing.T, rw io.ReadWriter, auth connect.AuthContext) *Channel {
	t.Helper()

	ch, err := NewChannel(rw, auth)
	if err != nil {
		t.Fatalf("NewChannel: %v", err)
	}
	return ch
}

func aliceAuth() authFixture {
	alice, _ := channelAuthPair()
	return alice
}

func bobAuth() authFixture {
	_, bob := channelAuthPair()
	return bob
}

func channelDirectionalKeys() ([]byte, []byte) {
	alice, _ := channelAuthPair()
	return alice.SendKey(), alice.ReceiveKey()
}

func channelAuthPair() (authFixture, authFixture) {
	binding := []byte("channel-test-binding")
	alice, bob := nettest.NewAuthContextPair(
		nettest.WithSessionBinding(binding),
		nettest.WithExporter(connect.NewHKDFKeyExporter([]byte("channel-test-master-secret"), binding)),
	)
	return authFixture{sendKey: alice.SendKey(), receiveKey: alice.ReceiveKey()},
		authFixture{sendKey: bob.SendKey(), receiveKey: bob.ReceiveKey()}
}

type authFixture struct {
	sendKey    []byte
	receiveKey []byte
}

func (a authFixture) SendKey() []byte {
	return append([]byte(nil), a.sendKey...)
}

func (a authFixture) ReceiveKey() []byte {
	return append([]byte(nil), a.receiveKey...)
}

func (a authFixture) SessionBinding() []byte {
	return []byte("channel-test-binding")
}

func (a authFixture) Exporter() connect.KeyExporter {
	return connect.NewHKDFKeyExporter([]byte("channel-test-master-secret"), a.SessionBinding())
}

type exporterPanicAuth struct {
	authFixture
}

func (a exporterPanicAuth) Exporter() connect.KeyExporter {
	panic("channel must not call AuthContext.Exporter")
}

type claimingAuthFixture struct {
	authFixture
	claimed    bool
	claimCalls int
}

func (a *claimingAuthFixture) ClaimChannelUse() error {
	a.claimCalls++
	if a.claimed {
		return connect.ErrChannelUseClaimed
	}
	a.claimed = true
	return nil
}

type closeBuffer struct {
	bytes.Buffer
	closed bool
}

func (b *closeBuffer) Close() error {
	b.closed = true
	return nil
}

type partialFailReadWriter struct {
	bytes.Buffer
	failAfter  int
	err        error
	writeCalls int
}

func (w *partialFailReadWriter) Write(p []byte) (int, error) {
	w.writeCalls++
	if w.failAfter < 0 {
		return w.Buffer.Write(p)
	}
	if w.failAfter == 0 {
		return 0, w.err
	}
	if len(p) <= w.failAfter {
		n, err := w.Buffer.Write(p)
		w.failAfter -= n
		return n, err
	}

	n, err := w.Buffer.Write(p[:w.failAfter])
	w.failAfter = 0
	if err != nil {
		return n, err
	}
	return n, w.err
}

// recordingWriteReadWriter keeps a copy of every Write it accepts, so a test can
// see how the bytes were split across transport calls.
type recordingWriteReadWriter struct {
	writes [][]byte
}

func (w *recordingWriteReadWriter) Read(_ []byte) (int, error) {
	return 0, io.EOF
}

func (w *recordingWriteReadWriter) Write(p []byte) (int, error) {
	w.writes = append(w.writes, append([]byte(nil), p...))
	return len(p), nil
}

type zeroWriteReadWriter struct {
	writeCalls int
}

func (w *zeroWriteReadWriter) Read(_ []byte) (int, error) {
	return 0, io.EOF
}

func (w *zeroWriteReadWriter) Write(_ []byte) (int, error) {
	w.writeCalls++
	return 0, nil
}

type splitReadWriter struct {
	read  *bytes.Reader
	write bytes.Buffer
}

func (rw *splitReadWriter) Read(p []byte) (int, error) {
	return rw.read.Read(p)
}

func (rw *splitReadWriter) Write(p []byte) (int, error) {
	return rw.write.Write(p)
}

type countingCloseBuffer struct {
	bytes.Buffer
	closeCount int
}

func (b *countingCloseBuffer) Close() error {
	b.closeCount++
	if b.closeCount > 1 {
		return errUnexpectedSecondClose
	}
	return nil
}

// failWriteReadWriter serves queued inbound bytes while every Write fails
// before any byte reaches the transport.
type failWriteReadWriter struct {
	read       *bytes.Reader
	err        error
	writeCalls int
}

func (rw *failWriteReadWriter) Read(p []byte) (int, error) {
	return rw.read.Read(p)
}

func (rw *failWriteReadWriter) Write(_ []byte) (int, error) {
	rw.writeCalls++
	return 0, rw.err
}

func inboundFramesWithClose(t *testing.T, auth connect.AuthContext, payloads ...string) []byte {
	t.Helper()

	wire := &bytes.Buffer{}
	ch := mustChannel(t, wire, auth)
	for _, payload := range payloads {
		if err := ch.Send([]byte(payload)); err != nil {
			t.Fatalf("Send %q: %v", payload, err)
		}
	}
	if err := ch.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	return append([]byte(nil), wire.Bytes()...)
}

func TestChannelReceiveDrainsQueuedFramesAfterSendFailure(t *testing.T) {
	inbound := inboundFramesWithClose(t, bobAuth(), "first", "final")
	wire := &failWriteReadWriter{read: bytes.NewReader(inbound), err: errInjectedWrite}
	alice := mustChannel(t, wire, aliceAuth())

	if err := alice.Send([]byte("outbound")); !errors.Is(err, errInjectedWrite) {
		t.Fatalf("Send write failure error = %v, want %v", err, errInjectedWrite)
	}

	for _, want := range []string{"first", "final"} {
		got, err := alice.Receive()
		if err != nil {
			t.Fatalf("Receive %q after send failure error = %v, want nil", want, err)
		}
		if string(got) != want {
			t.Fatalf("Receive after send failure = %q, want %q", got, want)
		}
	}
	if _, err := alice.Receive(); !errors.Is(err, io.EOF) {
		t.Fatalf("Receive close frame after send failure error = %v, want %v", err, io.EOF)
	}

	writeCalls := wire.writeCalls
	if err := alice.Send([]byte("after failure")); !errors.Is(err, errInjectedWrite) {
		t.Fatalf("Send after send failure error = %v, want %v", err, errInjectedWrite)
	}
	if wire.writeCalls != writeCalls {
		t.Fatalf("Send after send failure called Write %d additional times, want 0", wire.writeCalls-writeCalls)
	}
	if alice.sendSeq != 1 {
		t.Fatalf("sendSeq after send failure = %d, want 1 reserved sequence", alice.sendSeq)
	}
}

func TestChannelReceiveReportsOwnReadErrorAfterSendFailure(t *testing.T) {
	inbound := encryptedFrames(t, bobAuth(), "queued")
	wire := &failWriteReadWriter{read: bytes.NewReader(inbound), err: errInjectedWrite}
	alice := mustChannel(t, wire, aliceAuth())

	if err := alice.Send([]byte("outbound")); !errors.Is(err, errInjectedWrite) {
		t.Fatalf("Send write failure error = %v, want %v", err, errInjectedWrite)
	}
	got, err := alice.Receive()
	if err != nil || string(got) != "queued" {
		t.Fatalf("Receive queued frame = (%q, %v), want (%q, nil)", got, err, "queued")
	}
	if _, err := alice.Receive(); !errors.Is(err, ErrTruncated) {
		t.Fatalf("Receive raw EOF after send failure error = %v, want %v", err, ErrTruncated)
	}
	if _, err := alice.Receive(); !errors.Is(err, ErrTruncated) {
		t.Fatalf("second Receive after truncation error = %v, want %v", err, ErrTruncated)
	}
	// A receive-side fatal error still poisons the send side and takes
	// precedence over the earlier send-side transport failure.
	if err := alice.Send([]byte("after")); !errors.Is(err, ErrTruncated) {
		t.Fatalf("Send after receive truncation error = %v, want %v", err, ErrTruncated)
	}
}

func TestTruncatedReadKeepsTransportCause(t *testing.T) {
	cause := errors.New("transport says why")
	err := readFrameError(fmt.Errorf("%w: %w", cause, io.EOF))
	if !errors.Is(err, ErrTruncated) || !errors.Is(err, cause) {
		t.Fatalf("readFrameError: got %v, want both %v and %v", err, ErrTruncated, cause)
	}
	// Truncation is never the authenticated close: the EOF identities beneath
	// the cause stay hidden.
	if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
		t.Fatalf("readFrameError: got %v, want no io.EOF or io.ErrUnexpectedEOF identity", err)
	}
	if err := readFrameError(io.ErrUnexpectedEOF); !errors.Is(err, ErrTruncated) || errors.Is(err, io.ErrUnexpectedEOF) {
		t.Fatalf("readFrameError(ErrUnexpectedEOF): got %v, want ErrTruncated without the EOF identity", err)
	}
}
