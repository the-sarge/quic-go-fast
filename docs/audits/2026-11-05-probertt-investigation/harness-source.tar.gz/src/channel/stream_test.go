package channel

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestStreamWriteChunksLargePayload(t *testing.T) {
	payload := bytes.Repeat([]byte("x"), MaxPayloadSize+1)
	wire := &bytes.Buffer{}
	alice, err := NewStream(wire, aliceAuth())
	if err != nil {
		t.Fatalf("NewStream alice: %v", err)
	}

	n, err := alice.Write(payload)
	if err != nil || n != len(payload) {
		t.Fatalf("Write = %d, %v; want %d, nil", n, err, len(payload))
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	frames := splitFrames(t, wire.Bytes())
	if len(frames) != 3 {
		t.Fatalf("frame count = %d, want 3 data/data/close frames", len(frames))
	}

	bob, err := NewStream(wire, bobAuth())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}
	got, err := io.ReadAll(bob)
	if err != nil {
		t.Fatalf("ReadAll: %v", err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("ReadAll returned %d bytes, want %d matching payload", len(got), len(payload))
	}
}

func TestStreamCopyFromWriterToSourceChunksLargePayload(t *testing.T) {
	payload := bytes.Repeat([]byte{0xa5}, 70*1024)
	wire := &bytes.Buffer{}
	alice, err := NewStream(wire, aliceAuth())
	if err != nil {
		t.Fatalf("NewStream alice: %v", err)
	}

	n, err := io.Copy(alice, bytes.NewBuffer(payload))
	if err != nil || n != int64(len(payload)) {
		t.Fatalf("Copy = %d, %v; want %d, nil", n, err, len(payload))
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	bob, err := NewStream(wire, bobAuth())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}
	got, err := io.ReadAll(bob)
	if err != nil {
		t.Fatalf("ReadAll: %v", err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("ReadAll returned %d bytes, want %d matching payload", len(got), len(payload))
	}
}

func TestStreamReadRejectsAuthenticatedEmptyDataFrame(t *testing.T) {
	tests := []struct {
		name   string
		prefix []byte
	}{
		{name: "first frame"},
		{name: "mid stream", prefix: []byte("prefix")},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			wire := &bytes.Buffer{}
			alice := mustChannel(t, wire, aliceAuth())
			if len(tt.prefix) > 0 {
				if err := alice.Send(tt.prefix); err != nil {
					t.Fatalf("Send prefix: %v", err)
				}
			}
			if err := alice.Send(nil); err != nil {
				t.Fatalf("Send empty data frame: %v", err)
			}
			if err := alice.Send([]byte("after empty frame")); err != nil {
				t.Fatalf("Send data after empty frame: %v", err)
			}
			if err := alice.Close(); err != nil {
				t.Fatalf("Close: %v", err)
			}

			bob, err := NewStream(bytes.NewBuffer(wire.Bytes()), bobAuth())
			if err != nil {
				t.Fatalf("NewStream bob: %v", err)
			}
			if len(tt.prefix) > 0 {
				prefix := make([]byte, len(tt.prefix))
				n, err := bob.Read(prefix)
				if err != nil || n != len(tt.prefix) || !bytes.Equal(prefix, tt.prefix) {
					t.Fatalf("Read prefix = %d, %q, %v; want %d, %q, nil", n, prefix[:n], err, len(tt.prefix), tt.prefix)
				}
			}

			buf := make([]byte, 32)
			n, err := bob.Read(buf)
			if n != 0 || !errors.Is(err, ErrStreamEmptyDataFrame) || !errors.Is(err, io.ErrNoProgress) {
				t.Fatalf("Read empty frame = %d, %v; want 0, %v wrapping %v", n, err, ErrStreamEmptyDataFrame, io.ErrNoProgress)
			}

			n, err = bob.Read(buf)
			if n != 0 || !errors.Is(err, ErrStreamEmptyDataFrame) || !errors.Is(err, io.ErrNoProgress) {
				t.Fatalf("Read after empty frame = %d, %v; want latched 0, %v wrapping %v", n, err, ErrStreamEmptyDataFrame, io.ErrNoProgress)
			}
		})
	}
}

func TestStreamReadAllowsAuthenticatedEmptyDataFramesWhenConfigured(t *testing.T) {
	wire := &bytes.Buffer{}
	alice := mustChannel(t, wire, aliceAuth())
	if err := alice.Send(nil); err != nil {
		t.Fatalf("Send empty data frame: %v", err)
	}
	if err := alice.Send([]byte("payload")); err != nil {
		t.Fatalf("Send payload: %v", err)
	}
	if err := alice.Send(nil); err != nil {
		t.Fatalf("Send trailing empty data frame: %v", err)
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	bob, err := NewStream(bytes.NewBuffer(wire.Bytes()), bobAuth(), AllowEmptyDataFrames())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}
	got, err := io.ReadAll(bob)
	if err != nil {
		t.Fatalf("ReadAll: %v", err)
	}
	if string(got) != "payload" {
		t.Fatalf("ReadAll = %q, want payload", got)
	}
}

func TestStreamReadAllowsOnlyEmptyDataFramesAsEmptyReadAll(t *testing.T) {
	wire := &bytes.Buffer{}
	alice := mustChannel(t, wire, aliceAuth())
	if err := alice.Send(nil); err != nil {
		t.Fatalf("Send empty data frame: %v", err)
	}
	if err := alice.Send(nil); err != nil {
		t.Fatalf("Send second empty data frame: %v", err)
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	bob, err := NewStream(bytes.NewBuffer(wire.Bytes()), bobAuth(), AllowEmptyDataFrames())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}
	got, err := io.ReadAll(bob)
	if err != nil {
		t.Fatalf("ReadAll: %v", err)
	}
	if len(got) != 0 {
		t.Fatalf("ReadAll = %q, want empty data", got)
	}
}

func TestStreamReadAllowsMidStreamEmptyDataFrameAcrossPartialReads(t *testing.T) {
	wire := &bytes.Buffer{}
	alice := mustChannel(t, wire, aliceAuth())
	if err := alice.Send([]byte("ab")); err != nil {
		t.Fatalf("Send prefix: %v", err)
	}
	if err := alice.Send(nil); err != nil {
		t.Fatalf("Send empty data frame: %v", err)
	}
	if err := alice.Send([]byte("cd")); err != nil {
		t.Fatalf("Send suffix: %v", err)
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	bob, err := NewStream(bytes.NewBuffer(wire.Bytes()), bobAuth(), AllowEmptyDataFrames())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}
	buf := make([]byte, 1)
	var got []byte
	for range 4 {
		n, err := bob.Read(buf)
		if err != nil || n != 1 {
			t.Fatalf("Read = %d, %v; want 1, nil", n, err)
		}
		got = append(got, buf[0])
	}
	if string(got) != "abcd" {
		t.Fatalf("partial reads = %q, want abcd", got)
	}
	n, err := bob.Read(buf)
	if n != 0 || !errors.Is(err, io.EOF) {
		t.Fatalf("Read after payload = %d, %v; want 0, EOF", n, err)
	}
}

func TestStreamEmptyDataFrameReadErrorDoesNotPoisonWrites(t *testing.T) {
	inbound := encryptedFrames(t, aliceAuth(), "")
	wire := &splitReadWriter{read: bytes.NewReader(inbound)}
	bob, err := NewStream(wire, bobAuth())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}

	buf := make([]byte, 1)
	n, err := bob.Read(buf)
	if n != 0 || !errors.Is(err, ErrStreamEmptyDataFrame) {
		t.Fatalf("Read empty frame = %d, %v; want 0, %v", n, err, ErrStreamEmptyDataFrame)
	}

	const outbound = "write side remains open"
	if n, err := bob.Write([]byte(outbound)); err != nil || n != len(outbound) {
		t.Fatalf("Write after read poison = %d, %v; want %d, nil", n, err, len(outbound))
	}
	if err := bob.Close(); err != nil {
		t.Fatalf("Close after read poison: %v", err)
	}

	alice, err := NewStream(bytes.NewBuffer(wire.write.Bytes()), aliceAuth())
	if err != nil {
		t.Fatalf("NewStream alice: %v", err)
	}
	got, err := io.ReadAll(alice)
	if err != nil {
		t.Fatalf("ReadAll outbound: %v", err)
	}
	if string(got) != outbound {
		t.Fatalf("ReadAll outbound = %q, want %q", got, outbound)
	}
}

func TestStreamConcurrentReadIsSafe(t *testing.T) {
	payload := bytes.Repeat([]byte("abcdefghijklmnopqrstuvwxyz"), 8*1024)
	wire := &bytes.Buffer{}
	alice, err := NewStream(wire, aliceAuth())
	if err != nil {
		t.Fatalf("NewStream alice: %v", err)
	}
	if n, err := alice.Write(payload); err != nil || n != len(payload) {
		t.Fatalf("Write = %d, %v; want %d, nil", n, err, len(payload))
	}
	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	bob, err := NewStream(wire, bobAuth())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}

	const readers = 8
	var total atomic.Int64
	var wg sync.WaitGroup
	errs := make(chan error, readers)
	for range readers {
		wg.Go(func() {
			buf := make([]byte, 101)
			for {
				n, err := bob.Read(buf)
				if n > 0 {
					total.Add(int64(n))
				}
				if errors.Is(err, io.EOF) {
					return
				}
				if err != nil {
					errs <- err
					return
				}
				if n == 0 {
					errs <- io.ErrNoProgress
					return
				}
			}
		})
	}

	wg.Wait()
	close(errs)
	for err := range errs {
		t.Errorf("Read: %v", err)
	}
	if got := int(total.Load()); got != len(payload) {
		t.Fatalf("concurrent Read total = %d, want %d", got, len(payload))
	}
}

func TestStreamConcurrentLargeWritesStayContiguous(t *testing.T) {
	payloadA := bytes.Repeat([]byte("A"), MaxPayloadSize*3+17)
	payloadB := bytes.Repeat([]byte("B"), MaxPayloadSize*3+31)
	wire := &bytes.Buffer{}
	alice, err := NewStream(wire, aliceAuth())
	if err != nil {
		t.Fatalf("NewStream alice: %v", err)
	}

	start := make(chan struct{})
	errs := make(chan error, 2)
	var wg sync.WaitGroup
	writePayload := func(name string, payload []byte) {
		defer wg.Done()
		<-start

		n, err := alice.Write(payload)
		if err != nil {
			errs <- fmt.Errorf("%s Write: %w", name, err)
			return
		}
		if n != len(payload) {
			errs <- fmt.Errorf("%s Write = %d, want %d", name, n, len(payload))
		}
	}

	wg.Add(2)
	go writePayload("A", payloadA)
	go writePayload("B", payloadB)
	close(start)
	wg.Wait()
	close(errs)
	for err := range errs {
		t.Error(err)
	}
	if t.Failed() {
		return
	}

	if err := alice.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}

	bob, err := NewStream(bytes.NewBuffer(wire.Bytes()), bobAuth())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}
	got, err := io.ReadAll(bob)
	if err != nil {
		t.Fatalf("ReadAll: %v", err)
	}

	wantAB := append(append([]byte(nil), payloadA...), payloadB...)
	wantBA := append(append([]byte(nil), payloadB...), payloadA...)
	if !bytes.Equal(got, wantAB) && !bytes.Equal(got, wantBA) {
		t.Fatalf("concurrent large writes interleaved or corrupted: got %d bytes, want contiguous writes of %d and %d bytes", len(got), len(payloadA), len(payloadB))
	}
}

func TestStreamCloseSerializesWithInFlightWrite(t *testing.T) {
	wire := &bytes.Buffer{}
	alice, err := NewStream(wire, aliceAuth())
	if err != nil {
		t.Fatalf("NewStream alice: %v", err)
	}
	aliceStream := alice.(*stream)
	// writeMu is held across all chunks of a single Write, so holding it here
	// models an in-flight multi-frame Write without depending on scheduler luck.
	aliceStream.writeMu.Lock()

	closeErr := make(chan error, 1)
	go func() {
		closeErr <- alice.Close()
	}()

	select {
	case err := <-closeErr:
		t.Fatalf("Close returned while write side was locked: %v", err)
	case <-time.After(25 * time.Millisecond):
	}
	if wire.Len() != 0 {
		t.Fatalf("Close wrote %d bytes while a write was in flight, want 0", wire.Len())
	}

	aliceStream.writeMu.Unlock()
	select {
	case err := <-closeErr:
		if err != nil {
			t.Fatalf("Close after write unlock: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for Close after write unlock")
	}
	if wire.Len() == 0 {
		t.Fatal("Close after write unlock did not write an authenticated close frame")
	}
}

func TestStreamCloseWaitsForBlockedWrite(t *testing.T) {
	wire := newBlockingWriteReadWriter(errInjectedWrite)
	alice, err := NewStream(wire, aliceAuth())
	if err != nil {
		t.Fatalf("NewStream alice: %v", err)
	}

	writeErr := make(chan error, 1)
	go func() {
		_, err := alice.Write([]byte("blocked write"))
		writeErr <- err
	}()
	select {
	case <-wire.entered:
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for Write to block")
	}

	closeStarted := make(chan struct{})
	closeErr := make(chan error, 1)
	go func() {
		close(closeStarted)
		closeErr <- alice.Close()
	}()
	<-closeStarted

	select {
	case err := <-closeErr:
		t.Fatalf("Close returned before blocked Write was unblocked: %v", err)
	case <-time.After(25 * time.Millisecond):
	}

	wire.release()
	select {
	case err := <-writeErr:
		if !errors.Is(err, errInjectedWrite) {
			t.Fatalf("Write after unblock error = %v, want %v", err, errInjectedWrite)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for Write after unblock")
	}
	select {
	case err := <-closeErr:
		if !errors.Is(err, errInjectedWrite) {
			t.Fatalf("Close after unblock error = %v, want %v", err, errInjectedWrite)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for Close after unblock")
	}
}

func TestStreamCloseFrameFollowsInFlightMultiFrameWrite(t *testing.T) {
	payload := bytes.Repeat([]byte("C"), MaxPayloadSize+1)
	wire := newGateAfterFrameReadWriter(1)
	alice, err := NewStream(wire, aliceAuth())
	if err != nil {
		t.Fatalf("NewStream alice: %v", err)
	}

	writeErr := make(chan error, 1)
	go func() {
		n, err := alice.Write(payload)
		if err != nil {
			writeErr <- err
			return
		}
		if n != len(payload) {
			writeErr <- fmt.Errorf("Write = %d, want %d", n, len(payload))
			return
		}
		writeErr <- nil
	}()
	select {
	case <-wire.frameDone:
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for first data frame")
	}

	closeStarted := make(chan struct{})
	closeErr := make(chan error, 1)
	go func() {
		close(closeStarted)
		closeErr <- alice.Close()
	}()
	<-closeStarted

	select {
	case err := <-closeErr:
		t.Fatalf("Close returned before multi-frame Write was released: %v", err)
	case <-time.After(25 * time.Millisecond):
	}

	wire.release()
	select {
	case err := <-writeErr:
		if err != nil {
			t.Fatalf("Write after release: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for Write after release")
	}
	select {
	case err := <-closeErr:
		if err != nil {
			t.Fatalf("Close after release: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for Close after release")
	}

	captured := wire.bytes()
	frames := splitFrames(t, captured)
	if len(frames) != 3 {
		t.Fatalf("frame count = %d, want 3 data/data/close frames", len(frames))
	}
	bob, err := NewStream(bytes.NewBuffer(captured), bobAuth())
	if err != nil {
		t.Fatalf("NewStream bob: %v", err)
	}
	got, err := io.ReadAll(bob)
	if err != nil {
		t.Fatalf("ReadAll: %v", err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("ReadAll returned %d bytes, want %d matching payload", len(got), len(payload))
	}
}

type blockingWriteReadWriter struct {
	entered     chan struct{}
	released    chan struct{}
	releaseOnce sync.Once
	enterOnce   sync.Once
	err         error
}

func newBlockingWriteReadWriter(err error) *blockingWriteReadWriter {
	return &blockingWriteReadWriter{
		entered:  make(chan struct{}),
		released: make(chan struct{}),
		err:      err,
	}
}

func (w *blockingWriteReadWriter) Read(_ []byte) (int, error) {
	return 0, io.EOF
}

func (w *blockingWriteReadWriter) Write(_ []byte) (int, error) {
	w.enterOnce.Do(func() {
		close(w.entered)
	})
	<-w.released
	return 0, w.err
}

func (w *blockingWriteReadWriter) release() {
	w.releaseOnce.Do(func() {
		close(w.released)
	})
}

type gateAfterFrameReadWriter struct {
	bytes.Buffer
	mu          sync.Mutex
	header      [frameHeaderSize]byte
	headerLen   int
	remaining   int
	frames      int
	afterFrames int
	blocked     bool
	frameDone   chan struct{}
	released    chan struct{}
	releaseOnce sync.Once
}

func newGateAfterFrameReadWriter(afterFrames int) *gateAfterFrameReadWriter {
	return &gateAfterFrameReadWriter{
		afterFrames: afterFrames,
		frameDone:   make(chan struct{}),
		released:    make(chan struct{}),
	}
}

func (w *gateAfterFrameReadWriter) Read(_ []byte) (int, error) {
	return 0, io.EOF
}

func (w *gateAfterFrameReadWriter) Write(p []byte) (int, error) {
	w.mu.Lock()
	n, err := w.Buffer.Write(p)
	shouldBlock := err == nil && w.trackWriteLocked(p)
	w.mu.Unlock()

	if shouldBlock {
		<-w.released
	}
	return n, err
}

// trackWriteLocked parses frame boundaries from the accumulated byte stream,
// however the frames are split across Write calls, and reports whether this
// Write completed the frame the gate waits for.
func (w *gateAfterFrameReadWriter) trackWriteLocked(p []byte) bool {
	shouldBlock := false
	for len(p) > 0 {
		if w.headerLen < frameHeaderSize {
			n := copy(w.header[w.headerLen:], p)
			w.headerLen += n
			p = p[n:]
			if w.headerLen == frameHeaderSize {
				w.remaining = int(binary.BigEndian.Uint32(w.header[:]))
			}
			continue
		}

		n := min(w.remaining, len(p))
		w.remaining -= n
		p = p[n:]
		if w.remaining != 0 {
			continue
		}
		w.headerLen = 0
		w.frames++
		if w.frames == w.afterFrames && !w.blocked {
			w.blocked = true
			close(w.frameDone)
			shouldBlock = true
		}
	}
	return shouldBlock
}

func (w *gateAfterFrameReadWriter) release() {
	w.releaseOnce.Do(func() {
		close(w.released)
	})
}

func (w *gateAfterFrameReadWriter) bytes() []byte {
	w.mu.Lock()
	defer w.mu.Unlock()

	return append([]byte(nil), w.Bytes()...)
}

func TestStreamReadDrainsAfterWriteFailure(t *testing.T) {
	inbound := inboundFramesWithClose(t, bobAuth(), "final frame")
	wire := &failWriteReadWriter{read: bytes.NewReader(inbound), err: errInjectedWrite}
	alice, err := NewStream(wire, aliceAuth())
	if err != nil {
		t.Fatalf("NewStream: %v", err)
	}

	if _, err := alice.Write([]byte("outbound")); !errors.Is(err, errInjectedWrite) {
		t.Fatalf("Write failure error = %v, want %v", err, errInjectedWrite)
	}
	got, err := io.ReadAll(alice)
	if err != nil {
		t.Fatalf("ReadAll after write failure error = %v, want nil", err)
	}
	if string(got) != "final frame" {
		t.Fatalf("ReadAll after write failure = %q, want %q", got, "final frame")
	}
	if _, err := alice.Write([]byte("again")); !errors.Is(err, errInjectedWrite) {
		t.Fatalf("Write after write failure error = %v, want %v", err, errInjectedWrite)
	}
}
