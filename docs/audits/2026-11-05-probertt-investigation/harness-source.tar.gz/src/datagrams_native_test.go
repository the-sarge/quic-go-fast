package wiremux

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"net"
	"sync/atomic"
	"testing"
	"time"

	"github.com/GridSwarm/wiremux/connect"
	"github.com/GridSwarm/wiremux/internal/datagramadmission"
)

// ownedQueueTestCarrier is a native carrier double: a real admission queue
// owned by the connection context conn, with no sender, so the test dequeues
// what Send admitted. Its lifetime ends separately, as the native carrier's
// lifetime ends one goroutine hop after its connection.
type ownedQueueTestCarrier struct {
	maxPayload int
	lifetime   context.Context
	endLife    context.CancelCauseFunc
	conn       context.Context
	endConn    context.CancelCauseFunc
	queue      *datagramadmission.Queue
	// fail, when set, is returned by sendOwned instead of admitting.
	fail error
	// onSeal, when set, runs after the first seal of the queue.
	onSeal      func()
	seals       atomic.Int32
	copyingSend atomic.Int32
}

func newOwnedQueueTestCarrier(maxPayload, capacity int) *ownedQueueTestCarrier {
	lifetime, endLife := context.WithCancelCause(context.Background())
	conn, endConn := context.WithCancelCause(context.Background())
	return &ownedQueueTestCarrier{
		maxPayload: maxPayload,
		lifetime:   lifetime,
		endLife:    endLife,
		conn:       conn,
		endConn:    endConn,
		queue:      datagramadmission.New(conn, capacity),
	}
}

func (c *ownedQueueTestCarrier) Lifetime() context.Context { return c.lifetime }

func (c *ownedQueueTestCarrier) MaxDatagramPayload() int { return c.maxPayload }

func (c *ownedQueueTestCarrier) SendDatagram(context.Context, []byte) error {
	c.copyingSend.Add(1)
	return errors.New("copying SendDatagram called on a one-queue handle")
}

func (c *ownedQueueTestCarrier) ReceiveDatagram(ctx context.Context) ([]byte, error) {
	<-ctx.Done()
	return nil, ctx.Err()
}

// sendOwned reports the connection's end as the native carrier does: its
// closed error, wrapping the connection's cause.
func (c *ownedQueueTestCarrier) sendOwned(ctx context.Context, framed []byte) error {
	if c.fail != nil {
		return c.fail
	}
	err := c.queue.AdmitOwned(ctx, framed)
	if errors.Is(err, datagramadmission.ErrOwnerEnded) {
		return fmt.Errorf("%w: %w", net.ErrClosed, context.Cause(c.conn))
	}
	return err
}

// sealAdmission counts and reports only the first seal: end is idempotent
// and runs again later in teardown.
func (c *ownedQueueTestCarrier) sealAdmission() {
	if !c.queue.Close(net.ErrClosed) {
		return
	}
	c.seals.Add(1)
	if c.onSeal != nil {
		c.onSeal()
	}
}

func dequeueOwned(t *testing.T, carrier *ownedQueueTestCarrier) []byte {
	t.Helper()
	got := make(chan []byte, 1)
	go func() {
		payload, ok := carrier.queue.Dequeue()
		if ok {
			got <- payload
		}
		close(got)
	}()
	select {
	case payload, ok := <-got:
		if !ok {
			t.Fatal("carrier queue ended before a payload was admitted")
		}
		return payload
	case <-time.After(time.Second):
		t.Fatal("no payload admitted to the carrier queue")
		return nil
	}
}

// waitForAdmission starts send and waits until it blocks on admission
// capacity, observed through its context.
func waitForAdmission(t *testing.T, ctx context.Context, send func(context.Context) error) <-chan error {
	t.Helper()
	observed := &doneObservedContext{Context: ctx, observed: make(chan struct{})}
	done := make(chan error, 1)
	go func() { done <- send(observed) }()
	select {
	case <-observed.observed:
	case <-time.After(time.Second):
		t.Fatal("Send did not begin waiting for admission")
	}
	return done
}

func requireSendResult(t *testing.T, done <-chan error) error {
	t.Helper()
	select {
	case err := <-done:
		return err
	case <-time.After(time.Second):
		t.Fatal("Send did not return")
		return nil
	}
}

// A one-queue handle copies the payload once, with its envelope, and admits
// that copy itself into the carrier's queue: no root queue, no pump, and
// Close seals the carrier's queue.
func TestNativeDatagramsSendAdmitsOneCopyIntoCarrierQueue(t *testing.T) {
	carrier := newOwnedQueueTestCarrier(6, 2)
	stream := &datagramTestStream{}
	wire := newNativeWire(stream, carrier, nil, nil)
	handle, ok := wire.Datagrams()
	if !ok || handle.MaxPayload() != 5 {
		t.Fatalf("Datagrams = (%v, %v), want a handle with MaxPayload 5", handle, ok)
	}
	if handle.sendAdmission != nil {
		t.Fatal("one-queue handle built a root send queue")
	}
	drained := make(chan struct{})
	go func() { handle.drain(); close(drained) }()
	select {
	case <-drained:
	case <-time.After(time.Second):
		t.Fatal("drain waited on a live one-queue handle: a root worker is running")
	}

	payload := []byte("data")
	if err := handle.Send(context.Background(), payload); err != nil {
		t.Fatalf("Send: %v", err)
	}
	payload[0] = 'X'
	if got := dequeueOwned(t, carrier); !bytes.Equal(got, []byte{0x00, 'd', 'a', 't', 'a'}) {
		t.Fatalf("admitted payload = %v, want the framed copy", got)
	}
	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	if got := carrier.seals.Load(); got != 1 {
		t.Fatalf("carrier queue seals = %d, want 1", got)
	}
	if got := carrier.copyingSend.Load(); got != 0 {
		t.Fatalf("copying SendDatagram calls = %d, want 0", got)
	}
}

// A Send waiting for admission when end seals the carrier's queue reports the
// closed error, before end sets the gate's closed flag; it never succeeds.
func TestNativeDatagramsSealWinsRacingSend(t *testing.T) {
	carrier := newOwnedQueueTestCarrier(1243, 1)
	wire := newNativeWire(&datagramTestStream{}, carrier, nil, nil)
	handle, _ := wire.Datagrams()
	if err := handle.Send(context.Background(), []byte("fills the queue")); err != nil {
		t.Fatalf("first Send: %v", err)
	}
	blocked := waitForAdmission(t, context.Background(), func(ctx context.Context) error {
		return handle.Send(ctx, []byte("racing end"))
	})

	type outcome struct {
		err          error
		closedBefore bool
	}
	atSeal := make(chan outcome, 1)
	carrier.onSeal = func() {
		closed := handle.closed.Load()
		atSeal <- outcome{requireSendResult(t, blocked), closed}
	}
	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	var got outcome
	select {
	case got = <-atSeal:
	default:
		// No seal at end: free a slot so the blocked Send can commit.
		_, _ = carrier.queue.Dequeue()
		got = outcome{err: requireSendResult(t, blocked)}
	}
	if !errors.Is(got.err, ErrWireClosed) {
		t.Fatalf("Send racing end = %v, want ErrWireClosed", got.err)
	}
	if got.closedBefore {
		t.Fatal("the seal resolved after the gate's closed flag was set")
	}
}

// Local Send errors stay non-terminal on a one-queue handle: an oversized
// payload, a context already done, and a context ending while the carrier's
// queue is full, which admits nothing.
func TestNativeDatagramsLocalErrorsAreNonTerminal(t *testing.T) {
	carrier := newOwnedQueueTestCarrier(6, 1)
	stream := &datagramTestStream{closeCalled: make(chan struct{})}
	wire := newNativeWire(stream, carrier, nil, nil)
	handle, _ := wire.Datagrams()
	t.Cleanup(func() { _ = wire.Close() })

	if err := handle.Send(context.Background(), []byte("larger")); !errors.Is(err, ErrDatagramTooLarge) || errors.Is(err, connect.ErrDatagramTooLarge) {
		t.Fatalf("oversize Send = %v, want only root ErrDatagramTooLarge", err)
	}
	canceled, cancel := context.WithCancel(context.Background())
	cancel()
	if err := handle.Send(canceled, []byte("ok")); !errors.Is(err, context.Canceled) {
		t.Fatalf("Send with a done context = %v, want context.Canceled", err)
	}
	if err := handle.Send(context.Background(), []byte("full")); err != nil {
		t.Fatalf("Send filling the queue: %v", err)
	}
	ctx, cancelBlocked := context.WithCancel(context.Background())
	blocked := waitForAdmission(t, ctx, func(ctx context.Context) error {
		return handle.Send(ctx, []byte("never"))
	})
	cancelBlocked()
	if err := requireSendResult(t, blocked); !errors.Is(err, context.Canceled) || errors.Is(err, ErrWireClosed) {
		t.Fatalf("Send canceled while the queue is full = %v, want context.Canceled", err)
	}
	if got := dequeueOwned(t, carrier); string(got[1:]) != "full" {
		t.Fatalf("admitted payload = %q, want only the queue-filling Send", got[1:])
	}
	if err := handle.Send(context.Background(), []byte("later")); err != nil {
		t.Fatalf("Send after local errors: %v", err)
	}
	if got := dequeueOwned(t, carrier); string(got[1:]) != "later" {
		t.Fatalf("admitted payload = %q, want later; the canceled Send was admitted", got[1:])
	}
	select {
	case <-stream.closeCalled:
		t.Fatal("a local Send error closed the Wire")
	default:
	}
}

// When the carrier's connection ends while a Send waits for admission, the
// Send faults the Wire: with the carrier's closed error while its lifetime
// has not yet ended, and with the lifetime's cause once it has.
func TestNativeDatagramsOwnerEndFaultsWire(t *testing.T) {
	for _, tc := range []struct {
		name         string
		lifetimeEnds bool
	}{
		{"before the carrier lifetime ends", false},
		{"after the carrier lifetime ends", true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			carrier := newOwnedQueueTestCarrier(1243, 1)
			stream := &datagramTestStream{closeCalled: make(chan struct{})}
			wire := newNativeWire(stream, carrier, nil, nil)
			handle, _ := wire.Datagrams()
			t.Cleanup(func() { _ = wire.Close() })
			if err := handle.Send(context.Background(), []byte("fills the queue")); err != nil {
				t.Fatalf("first Send: %v", err)
			}
			blocked := waitForAdmission(t, context.Background(), func(ctx context.Context) error {
				return handle.Send(ctx, []byte("blocked"))
			})
			connCause := errors.New("connection ended")
			lifetimeCause := errors.New("carrier lifetime cause")
			want := connCause
			if tc.lifetimeEnds {
				carrier.endLife(lifetimeCause)
				want = lifetimeCause
			}
			carrier.endConn(connCause)

			if err := requireSendResult(t, blocked); !errors.Is(err, ErrWireClosed) || !errors.Is(err, want) {
				t.Fatalf("Send when the connection ended = %v, want ErrWireClosed with %v", err, want)
			}
			select {
			case <-stream.closeCalled:
			case <-time.After(time.Second):
				t.Fatal("the connection's end did not close the Wire")
			}
		})
	}
}

// Any other carrier admission failure while the gate is open, including a
// size refusal at or below the ceiling, faults the Wire with that failure.
func TestNativeDatagramsCarrierFailureFaultsWire(t *testing.T) {
	for _, tc := range []struct {
		name string
		fail error
	}{
		{"at-ceiling size refusal", fmt.Errorf("native refused the fixed ceiling: %w", connect.ErrDatagramTooLarge)},
		{"other failure", errors.New("unexpected carrier failure")},
	} {
		t.Run(tc.name, func(t *testing.T) {
			carrier := newOwnedQueueTestCarrier(1243, 1)
			carrier.fail = tc.fail
			stream := &datagramTestStream{closeCalled: make(chan struct{})}
			wire := newNativeWire(stream, carrier, nil, nil)
			handle, _ := wire.Datagrams()
			t.Cleanup(func() { _ = wire.Close() })

			err := handle.Send(context.Background(), make([]byte, handle.MaxPayload()))
			if !errors.Is(err, ErrWireClosed) || !errors.Is(err, tc.fail) || errors.Is(err, ErrDatagramTooLarge) {
				t.Fatalf("Send = %v, want ErrWireClosed with %v", err, tc.fail)
			}
			select {
			case <-stream.closeCalled:
			case <-time.After(time.Second):
				t.Fatal("the carrier failure did not close the Wire")
			}
			if err := handle.Send(context.Background(), nil); !errors.Is(err, ErrWireClosed) || !errors.Is(err, tc.fail) {
				t.Fatalf("Send after the fault = %v, want the closed error with %v", err, tc.fail)
			}
		})
	}
}

// The managed construction path keeps the root queue and pump even for a
// carrier that could admit owned payloads: only the native construction path
// selects one-queue sends.
func TestManagedWireKeepsRootDatagramQueueAndPump(t *testing.T) {
	carrier := newOwnedQueueTestCarrier(1243, 1)
	wire := newWireWithManagedLifetime(connect.UpgradeResult{Stream: &datagramTestStream{}, Datagrams: carrier}, connect.CarrierTopologyRelayAssisted, nil, func() error { return nil }, nil)
	handle, _ := wire.Datagrams()
	if handle.sendAdmission == nil {
		t.Fatal("managed Wire built no root send queue")
	}
	drained := make(chan struct{})
	go func() { handle.drain(); close(drained) }()
	select {
	case <-drained:
		t.Fatal("drain returned on a live managed Wire: no root pump is running")
	case <-time.After(50 * time.Millisecond):
	}
	if err := handle.Send(context.Background(), []byte("pumped")); err != nil {
		t.Fatalf("Send: %v", err)
	}
	deadline := time.Now().Add(time.Second)
	for carrier.copyingSend.Load() == 0 {
		if time.Now().After(deadline) {
			t.Fatal("the root pump did not hand the payload to the carrier's SendDatagram")
		}
		time.Sleep(time.Millisecond)
	}
	if err := wire.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	<-drained
	if got := carrier.seals.Load(); got != 0 {
		t.Fatalf("managed Wire sealed the carrier's queue %d times, want 0", got)
	}
}
