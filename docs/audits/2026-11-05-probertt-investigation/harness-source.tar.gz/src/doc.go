// Package wiremux provides the consumer entry point for establishing an
// authenticated encrypted wire over a relay rendezvous, with optional direct
// transport upgrade.
//
// Dial pairs peers through a relay URL and rendezvous ID, runs an Authenticator
// such as StaticAuth, wraps the paired relay stream in the encrypted channel,
// and performs upgrade-control negotiation. Returned Wire values may use either
// the relay path or a direct transport path; Wire.Info reports the selected
// path, fallback reason, selected candidate pair, and probe RTT, and
// Wire.CarrierTopology reports whether the active carrier is peer-to-peer
// direct or relay-assisted. WithTURN enables authenticated direct-first TURN
// retry after direct probing fails; a successful QUIC-over-TURN carrier is a
// direct-path outcome with relay-assisted topology.
// Supporting established carriers also expose a borrowed Datagrams handle.
// Call Wire.Datagrams with comma-ok discovery on every Wire; absence leaves the
// reliable stream fully usable. Datagram Send success means bounded local
// admission for possible transmission, not delivery.
//
// [ADR-0009] and [PRD-0001] define the optional carrier-bound Datagram
// capability exposed through Wire.Datagrams. The required Wire plane remains
// the reliable byte stream when that optional capability is absent.
//
// Establishment failures are classified with ErrRendezvous, ErrIdentity,
// ErrChannel, or ErrUpgrade after option preflight succeeds. By default Dial
// creates an internally owned UDP socket for direct upgrade and starts a
// best-effort relay-host STUN lookup without blocking relay rendezvous. If the
// default UDP socket cannot be opened, Dial can still return a relay-path Wire;
// inspect Wire.Direct or Wire.Info for the selected path. WithPacketConn keeps
// caller ownership only before local commit and before any non-nil stream from
// Session.Dial or TransportListener.Accept. A non-nil stream transfers
// ownership even with an accompanying error and before listener commit is
// observed; its synchronous Close is the sole exact-socket disposer. After
// transfer, terminal failure has no relay fallback, and root settlement reads
// only the monotonic transfer fact: a Dial error classifies with
// ErrPacketConnTransferred exactly when the effective caller-owned
// WithPacketConn socket crossed that boundary. A TURN outcome never transfers
// or marks the caller-owned direct socket. WithTransferredPacketConn gives Dial exclusive lifecycle
// responsibility as soon as that option is the effective packet-socket
// selection. WithTransport, WithRelayOnly, and the other With* options control
// direct-upgrade behavior; see the individual option docs for exact contracts.
//
// Importing this package places the Pion TURN dependency used by WithTURN,
// and its transitive packages, in every consumer's Go build and dependency
// closure even when TURN is not configured; toolchain dead-code elimination
// remains authoritative for binary size.
// A graceful peer close is reported as io.EOF from Wire.Read. On direct QUIC,
// a normal remote parent close is graceful only after the final receive offset
// is known and every byte through it has been delivered; earlier parent
// teardown preserves a non-EOF transport error. Post-close and peer-teardown
// failures from Wire.Read, Wire.Write, and Wire.Close are
// classifiable with errors.Is(err, ErrWireClosed), but ErrWireClosed does not
// prove clean shutdown. Underlying transport and channel identities are
// preserved. Inspect channel integrity failures such as channel.ErrAuthentication
// or channel.ErrTruncated before treating ErrWireClosed as ordinary teardown.
// Teardown errors may be wrapped; use errors.Is or errors.As rather than error
// equality.
//
// For ephemeral SessionID rendezvous, Dial consumes after successful local
// upgrade, eligible identity failure, or one-shot post-success failure.
// Disposition markers let identity layers declare spent failures that consume
// with the without-cancel default budget and retryable failures that do not
// consume. Unmarked identity failures keep the default heuristic: pure context
// cancellation, deadline, and relay I/O remain retryable; terminal
// identity/authentication errors should be returned as domain errors so Dial can
// consume after pairing. Ephemeral SessionID consume failures remain non-fatal
// and may be observed with WithConsumeSessionErrorHandler.
//
// [ADR-0009]: https://github.com/GridSwarm/wiremux/blob/main/docs/adr/adr-0009-optional-datagram-capability.md
// [PRD-0001]: https://github.com/GridSwarm/wiremux/blob/main/docs/prd/prd-0001-connectivity-kernel.md
package wiremux
