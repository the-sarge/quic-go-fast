//go:build !race

package wiremux

import (
	"context"
	"testing"

	"github.com/GridSwarm/wiremux/connect"
)

// A native Send allocates only its one framed copy: no root queue copy and no
// escaping error target.
func TestNativeDatagramSendAllocations(t *testing.T) {
	carrier := newOwnedQueueTestCarrier(1412, 1)
	wire := newNativeWire(&datagramTestStream{}, carrier, nil, nil)
	t.Cleanup(func() { _ = wire.Close() })
	handle, _ := wire.Datagrams()
	payload := make([]byte, handle.MaxPayload())
	ctx := context.Background()
	allocs := testing.AllocsPerRun(1000, func() {
		if err := handle.Send(ctx, payload); err != nil {
			t.Fatal(err)
		}
		if _, ok := carrier.queue.Dequeue(); !ok {
			t.Fatal("Dequeue: queue ended")
		}
	})
	if allocs != 1 {
		t.Fatalf("native Send allocations = %v, want 1", allocs)
	}
}

// receiveAllocations reports Receive's allocations per call on the same
// handle, for contexts from newContext. AllocsPerRun makes one warm-up call
// before its measured runs, so the carrier holds runs+1 frames.
func receiveAllocations(t *testing.T, newCarrier func(...[]byte) connect.DatagramCarrier, newContext func() context.Context) float64 {
	t.Helper()
	const runs = 100
	handle := newFeedTestWire(t, newCarrier(applicationFrames(runs+1)...))
	return testing.AllocsPerRun(runs, func() {
		if _, err := handle.Receive(newContext()); err != nil {
			t.Fatal(err)
		}
	})
}

func declaringFeed(frames ...[]byte) connect.DatagramCarrier {
	return freshFeedDatagramCarrier{newFeedDatagramCarrier(frames...)}
}

func nonDeclaringFeed(frames ...[]byte) connect.DatagramCarrier {
	return newFeedDatagramCarrier(frames...)
}

// A declaring carrier's Receive on the same cancelable context allocates
// nothing in root: the merged context is kept and the payload is not copied.
func TestDatagramReceiveReusedContextAllocations(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	if allocs := receiveAllocations(t, declaringFeed, func() context.Context { return ctx }); allocs != 0 {
		t.Fatalf("declaring carrier, same context: Receive allocations = %v, want 0", allocs)
	}
}

// A non-declaring carrier's Receive on the same context allocates only the
// copy.
func TestDatagramReceiveNonDeclaringCarrierAllocations(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	if allocs := receiveAllocations(t, nonDeclaringFeed, func() context.Context { return ctx }); allocs != 1 {
		t.Fatalf("non-declaring carrier, same context: Receive allocations = %v, want 1", allocs)
	}
}

// A non-comparable context builds its merged context on every call, as before
// this slice, and a declaring carrier still skips the copy.
func TestDatagramReceiveNonComparableContextAllocations(t *testing.T) {
	type structContext struct {
		context.Context
		labels map[string]string
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	// Boxed once, so the measured calls count only Receive's allocations.
	var nonComparable context.Context = structContext{ctx, map[string]string{}}
	if allocs := receiveAllocations(t, declaringFeed, func() context.Context { return nonComparable }); allocs != perCallMergedContextAllocations {
		t.Fatalf("declaring carrier, non-comparable context: Receive allocations = %v, want %d", allocs, perCallMergedContextAllocations)
	}
}

// perCallMergedContextAllocations is what building one merged context costs:
// context.WithCancel on a cancelable parent and the gate's AfterFunc.
const perCallMergedContextAllocations = 4
