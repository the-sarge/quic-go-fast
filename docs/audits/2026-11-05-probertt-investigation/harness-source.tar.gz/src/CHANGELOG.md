# Changelog

This file indexes wiremux releases. Each entry summarizes a release and links its tracked release notes, which are authoritative and become the GitHub Release body. [`docs/COMPATIBILITY.md`](docs/COMPATIBILITY.md) is the normative compatibility contract, and [`docs/RELEASE.md`](docs/RELEASE.md) records publication evidence. All releases are private and immutable.

## v0.3.1 (pending publication)

- Add explicit per-endpoint Reno/BBRv3 selection through additive native and built-in QUIC constructors, with managed/migration options and actual native connection readout.
- Add conservative ACK policy for BBR and mixed-controller deployments while preserving default Reno behavior. Unsupported explicit BBR fails before networking; BBR remains experimental and unqualified. See [adoption instructions](docs/QUIC-CONTROLLERS.md).

## v0.3.0 — 2026-10-27

- Native packet-I/O and admission improvements, path-MTU-derived Datagram ceilings and receive-drop snapshots; unkeyed `NativeWireInfo` literals require migration.
- Relay pending/source quotas and absolute one-hour default registration leases; clients must reacquire lost registrations.
- Application-owned optional quic-go-fast v0.62.1-fast.9 native lane, retaining upstream v0.62.0 by default and explicit rollback.
- Go 1.27.3 toolchain floor and x/crypto, x/net, x/sys and x/text dependency updates. API inventory adds 35 lines and changes the native maximum value; CLI and wire-vector inventories remain unchanged.
- Preserved native certification results and limitations, including three Windows floor misses and Arm pending.

Notes: [docs/release/v0.3.0/notes.md](docs/release/v0.3.0/notes.md)

## v0.2.7 — 2026-10-05

- Added the `binding` package: interface-scoped unicast bindings with per-datagram identity, ingress and route admission.
- Added the `discovery` package: scoped mDNS-group datagram I/O on LAN-classified interfaces.
- Added `PairRelay`, `PairRelayOrdered`, `WriteSetupRecord` and `ReadSetupRecord`: relay pairings held before authentication, with an opaque setup-record exchange.
- Added native QUIC candidates (`NewNativeEndpoint`, `DialInterface`) with authentication and promotion into a Wire (`Wire.Native`, `channel.NewChannelStream`). Native endpoints require a QUIC module with the native capabilities and report unsupported under upstream quic-go and quic-go-fast fast.6.
- Fixed paired-relay `Abandon` to join in-flight setup operations before releasing the attempt (#1760); native Wires survive application idleness (#1770), close within about one second (#1771) and tighten promotion admission (#1772).
- Updated pion/transport to v4.1.1. API inventory adds 170 lines; CLI and wire-vector inventories are unchanged.

Notes: [docs/release/v0.2.7/notes.md](docs/release/v0.2.7/notes.md)

## v0.2.6 — 2026-09-25

- Added ordered selected-interface establishment (`selection.NewOrdered`, `relay.DialOrdered`, `wiremux.DialOrdered`) and `selection.ResolvePresent`.
- Fixed HKDF exporter diagnostics exposing the retained pseudorandom key (#1594).
- Relay proxy completion now joins its owned workers before releasing accounting.

Notes: [docs/release/v0.2.6/notes.md](docs/release/v0.2.6/notes.md)

## v0.2.5 — 2026-09-24

- Updated TURN v5.3.1 (with STUN v3.1.7 and DTLS v3.1.8), CBOR v2.9.4 and tools-only dependencies.
- Corrected remote measurement result retention. No public API, CLI or wire-profile change.

Notes: [docs/release/v0.2.5/notes.md](docs/release/v0.2.5/notes.md)

## v0.2.4 — 2026-09-24

- Added opt-in authenticated managed migration and the `selection` package with selected-interface entry points for Linux, macOS and Windows.
- Advertised optional quic-go-fast v0.62.1-fast.6; socket-lifetime and receive-allocation corrections.

Notes: [docs/release/v0.2.4/notes.md](docs/release/v0.2.4/notes.md)

## v0.2.3 — 2026-09-17

- Added `ManagedWire.Datagrams` to discover the optional borrowed Datagram plane on managed direct QUIC Wires.

Notes: [docs/release/v0.2.3/notes.md](docs/release/v0.2.3/notes.md)

## v0.2.2 — 2026-09-17

- Added the managed packet endpoint and optional packet-I/O integration; applications may select quic-go-fast v0.62.1-fast.3, with upstream quic-go v0.62.0 as the default.

Notes: [docs/release/v0.2.2/notes.md](docs/release/v0.2.2/notes.md)

## v0.2.1 — 2026-08-29

- Added an opt-in loopback-only pprof endpoint to `wiremux-server`.
- Removed steady-state allocations from channel framing and source rate limiting; `channel.Receive` payload-lifetime compatibility exception.

Notes: [docs/release/v0.2.1/notes.md](docs/release/v0.2.1/notes.md)

## v0.2.0 — 2026-08-25

- Opened the v0.2.x line with three compatibility breaks: the `0x02` assist-withheld pairing reply, the 1232-byte direct packet class, and `serve` owning `SIGHUP`.
- Added relay shaping knobs, ACME directory-URL and EAB support, and the OOB-capable direct-transport adapter; fixed the channel send-failure drain.

Notes: [docs/release/v0.2.0/notes.md](docs/release/v0.2.0/notes.md)

## v0.1.6 — 2026-08-24

- Fixed relay proxy drain of final in-flight bytes, the TURN retry listener stall (#1218) and a Selected-join hang; folded error-string namespaces.

Notes: [docs/release/v0.1.6/notes.md](docs/release/v0.1.6/notes.md)

## v0.1.5 — 2026-08-21

- Added opt-in client-side TURN/UDP relay fallback for the authenticated direct upgrade, plus two probe-settlement corrections.

Notes: [docs/release/v0.1.5/notes.md](docs/release/v0.1.5/notes.md)

## v0.1.4 — 2026-08-12

- Fixed a prior-pass probe success waiting until the attempt deadline (#1134).

Notes: [docs/release/v0.1.4/notes.md](docs/release/v0.1.4/notes.md)

## v0.1.3 — 2026-08-11

- Fixed a viable direct pair falling back to relay after its single probe burst ended (#1006).

Notes: [docs/release/v0.1.3/notes.md](docs/release/v0.1.3/notes.md)

## v0.1.2 — 2026-08-06

- Fixed direct QUIC Wires dying after 30 seconds of application silence (#1001).

Notes: [docs/release/v0.1.2/notes.md](docs/release/v0.1.2/notes.md)

## v0.1.1 — 2026-08-05

- Added `wiremuxtest.(*Relay).RequireEphemeralWaiter` (#987); no production behavior change.

Notes: [docs/release/v0.1.1/notes.md](docs/release/v0.1.1/notes.md)

## v0.1.0 — 2026-08-05

- First private release of the identity-agnostic pairwise connectivity kernel.

Notes: [docs/release/v0.1.0/notes.md](docs/release/v0.1.0/notes.md)
