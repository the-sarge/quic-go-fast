//go:build emission_experiment

package quic

import (
 "fmt"
 "os"
 "testing"
 "unsafe"

 "github.com/quic-go/quic-go/internal/protocol"
 "github.com/quic-go/quic-go/internal/qerr"
 "github.com/stretchr/testify/require"
 "go.uber.org/mock/gomock"
)

// Resolve the pre/post contraction queue representations once, outside measurement.
func emissionCaptureQueue(c *Conn) sender {
 switch q := any(c.emission.queue).(type) {
 case sender: return q
 case *sender: return *q
 default: panic("unsupported capture queue representation")
 }
}

func TestEmissionCloseAllocations(t *testing.T) {
 if os.Getenv("EMISSION_EXPERIMENT") != "1" { t.Skip("explicit E6 capture only") }
 ctrl := gomock.NewController(t)
 const observations = 1000
 emitters := make([]func(error) ([]byte,error), observations+1)
 var length int
 for i := range emitters {
  tc := newServerTestConnection(t, ctrl, nil, false)
  useLifecyclePacketPacker(t, ctrl, tc)
  c := tc.conn
  c.handshakeComplete, c.handshakeConfirmed, c.droppedInitialKeys = true, true, true
  tc.sendConn.EXPECT().Write(gomock.Any(), uint16(0), gomock.Any()).DoAndReturn(func(b []byte, _ uint16, _ protocol.ECN) error { length=len(b); return nil })
  // Bind once per prepared connection: real close construction occurs once.
  if owner, ok := any(c).(interface{ sendConnectionClose(error) ([]byte,error) }); ok {
   emitters[i]=owner.sendConnectionClose
  } else { emitters[i]=any(&c.emission).(interface{ close(error) ([]byte,error) }).close }
 }
 i := 0
 cause := &qerr.ApplicationError{ErrorCode:42, ErrorMessage:"retained close"}
 allocs := testing.AllocsPerRun(observations, func() {
  retained, err := emitters[i](cause)
  i++
  require.NoError(t,err)
  require.Len(t,retained,length)
 })
 fmt.Printf("E6_CLOSE allocs=%g serialized_bytes=%d conn_bytes=%d emission_bytes=%d\n",allocs,length,unsafe.Sizeof(Conn{}),unsafe.Sizeof(packetEmission{}))
}
