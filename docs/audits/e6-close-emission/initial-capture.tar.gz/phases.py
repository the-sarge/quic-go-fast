import json,subprocess,time
from pathlib import Path
root=Path('/home/josh/.cache/qgf-e6')
for name,mode in [('alloc-01','alloc'),('bench-01','bench'),('qlog-01','qlog'),('campaign-01','campaign')]:
 with (root/(name+'.log')).open('x') as log:
  proc=subprocess.Popen(['sudo','-n','bash',str(root/'isolate.sh'),str(root/name),mode],stdout=log,stderr=subprocess.STDOUT)
  code=proc.wait()
 record=dict(phase=name,exit=code,finished=time.time(),allowed_cpus={s:subprocess.check_output(['systemctl','show',s,'--property=AllowedCPUs','--value'],text=True).strip() for s in ['machine.slice','system.slice','user.slice']},marker=Path('/run/qgf-e6-cpu-reservation').exists(),timer_active=subprocess.run(['systemctl','is-active','--quiet','qgf-e6-cpu-restore.timer']).returncode==0)
 record['restored']=not any(record['allowed_cpus'].values()) and not record['marker'] and not record['timer_active']
 (root/(name+'-restoration.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if code or not record['restored']:raise SystemExit(code or 1)
