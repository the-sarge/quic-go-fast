TEXT github.com/quic-go/quic-go.(*packetEmission).withGSO(SB) /Volumes/worktrees/quic-go-fast/e5-linux-base/packet_emission.go
  packet_emission.go:144	0x6cef60		4c8d6424e8		LEAQ -0x18(SP), R12							
  packet_emission.go:144	0x6cef65		4d3b6610		CMPQ R12, 0x10(R14)							
  packet_emission.go:144	0x6cef69		0f864a040000		JBE 0x6cf3b9								
  packet_emission.go:144	0x6cef6f		55			PUSHQ BP								
  packet_emission.go:144	0x6cef70		4889e5			MOVQ SP, BP								
  packet_emission.go:144	0x6cef73		4881ec90000000		SUBQ $0x90, SP								
  buffer_pool.go:79		0x6cef7a		48898424a0000000	MOVQ AX, 0xa0(SP)							
  buffer_pool.go:79		0x6cef82		48899c24a8000000	MOVQ BX, 0xa8(SP)							
  packet_emission.go:144	0x6cef8a		488d4c2448		LEAQ 0x48(SP), CX							
  packet_emission.go:144	0x6cef8f		440f1139		MOVUPS X15, 0(CX)							
  packet_emission.go:144	0x6cef93		440f117910		MOVUPS X15, 0x10(CX)							
  packet_emission.go:144	0x6cef98		440f117920		MOVUPS X15, 0x20(CX)							
  packet_emission.go:145	0x6cef9d		90			NOPL									
  buffer_pool.go:79		0x6cef9e		488d055ba74500		LEAQ github.com/quic-go/quic-go.largeBufferPool(SB), AX			
  buffer_pool.go:79		0x6cefa5		e8766edcff		CALL sync.(*Pool).Get(SB)						
  buffer_pool.go:79		0x6cefaa		488d0d577c3900		LEAQ 0x397c57(IP), CX							
  buffer_pool.go:79		0x6cefb1		4839c8			CMPQ AX, CX								
  buffer_pool.go:79		0x6cefb4		0f85ef030000		JNE 0x6cf3a9								
  buffer_pool.go:79		0x6cefba		48899c2488000000	MOVQ BX, 0x88(SP)							
  buffer_pool.go:80		0x6cefc2		48c7431801000000	MOVQ $0x1, 0x18(BX)							
  buffer_pool.go:81		0x6cefca		48c7430800000000	MOVQ $0x0, 0x8(BX)							
  packet_emission.go:146	0x6cefd2		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:146	0x6cefda		488b5120		MOVQ 0x20(CX), DX							
  packet_emission.go:146	0x6cefde		488b4128		MOVQ 0x28(CX), AX							
  packet_emission.go:146	0x6cefe2		488b4a38		MOVQ 0x38(DX), CX							
  packet_emission.go:146	0x6cefe6		ffd1			CALL CX									
  packet_emission.go:146	0x6cefe8		4889442438		MOVQ AX, 0x38(SP)							
  packet_emission.go:147	0x6cefed		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:147	0x6ceff5		488b4908		MOVQ 0x8(CX), CX							
  packet_emission.go:147	0x6ceff9		488b11			MOVQ 0(CX), DX								
  packet_emission.go:147	0x6ceffc		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:147	0x6cf000		488b4a20		MOVQ 0x20(DX), CX							
  packet_emission.go:147	0x6cf004		bb01000000		MOVL $0x1, BX								
  packet_emission.go:147	0x6cf009		ffd1			CALL CX									
  packet_emission.go:147	0x6cf00b		488b8c2488000000	MOVQ 0x88(SP), CX							
  packet_emission.go:148	0x6cf013		eb05			JMP 0x6cf01a								
  packet_emission.go:148	0x6cf015		4889d9			MOVQ BX, CX								
  packet_emission.go:148	0x6cf018		89f8			MOVL DI, AX								
  packet_emission.go:148	0x6cf01a		8844242d		MOVB AL, 0x2d(SP)							
  packet_emission.go:148	0x6cf01e		48898c2480000000	MOVQ CX, 0x80(SP)							
  packet_emission.go:150	0x6cf026		4889cb			MOVQ CX, BX								
  packet_emission.go:150	0x6cf029		488b4c2438		MOVQ 0x38(SP), CX							
  packet_emission.go:150	0x6cf02e		89c7			MOVL AX, DI								
  packet_emission.go:150	0x6cf030		488bb424a8000000	MOVQ 0xa8(SP), SI							
  packet_emission.go:150	0x6cf038		488b8424a0000000	MOVQ 0xa0(SP), AX							
  packet_emission.go:150	0x6cf040		e83bf9ffff		CALL github.com/quic-go/quic-go.(*packetEmission).appendPacket(SB)	
  packet_emission.go:150	0x6cf045		4889442430		MOVQ AX, 0x30(SP)							
  packet_emission.go:151	0x6cf04a		4885db			TESTQ BX, BX								
  packet_emission.go:151	0x6cf04d		7461			JE 0x6cf0b0								
  packet_emission.go:150	0x6cf04f		48894c2478		MOVQ CX, 0x78(SP)							
  packet_emission.go:150	0x6cf054		48895c2440		MOVQ BX, 0x40(SP)							
  packet_emission.go:150	0x6cf059		0f1f8000000000		NOPL 0(AX)								
  packet_emission.go:152	0x6cf060		48391da9d84400		CMPQ github.com/quic-go/quic-go.errNothingToPack(SB), BX		
  packet_emission.go:152	0x6cf067		0f8549020000		JNE 0x6cf2b6								
  packet_emission.go:152	0x6cf06d		488b15a4d84400		MOVQ github.com/quic-go/quic-go.errNothingToPack+8(SB), DX		
  packet_emission.go:152	0x6cf074		4889d8			MOVQ BX, AX								
  packet_emission.go:152	0x6cf077		4889cb			MOVQ CX, BX								
  packet_emission.go:152	0x6cf07a		4889d1			MOVQ DX, CX								
  packet_emission.go:152	0x6cf07d		0f1f00			NOPL 0(AX)								
  packet_emission.go:152	0x6cf080		e85b81d4ff		CALL runtime.ifaceeq(SB)						
  packet_emission.go:152	0x6cf085		84c0			TESTL AL, AL								
  packet_emission.go:152	0x6cf087		0f8429020000		JE 0x6cf2b6								
  buffer_pool.go:54		0x6cf08d		488b842480000000	MOVQ 0x80(SP), AX							
  buffer_pool.go:54		0x6cf095		4883780800		CMPQ 0x8(AX), $0x0							
  buffer_pool.go:54		0x6cf09a		660f1f440000		NOPW 0(AX)(AX*1)							
  packet_emission.go:157	0x6cf0a0		0f84e4010000		JE 0x6cf28a								
  packet_emission.go:151	0x6cf0a6		488b4c2440		MOVQ 0x40(SP), CX							
  packet_emission.go:151	0x6cf0ab		4885c9			TESTQ CX, CX								
  packet_emission.go:157	0x6cf0ae		eb08			JMP 0x6cf0b8								
  buffer_pool.go:54		0x6cf0b0		488b842480000000	MOVQ 0x80(SP), AX							
  packet_emission.go:163	0x6cf0b8		740b			JE 0x6cf0c5								
  packet_emission.go:163	0x6cf0ba		b901000000		MOVL $0x1, CX								
  packet_emission.go:163	0x6cf0bf		90			NOPL									
  packet_emission.go:163	0x6cf0c0		e98a000000		JMP 0x6cf14f								
  packet_emission.go:164	0x6cf0c5		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:164	0x6cf0cd		488b4908		MOVQ 0x8(CX), CX							
  packet_emission.go:164	0x6cf0d1		488b11			MOVQ 0(CX), DX								
  packet_emission.go:164	0x6cf0d4		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:164	0x6cf0d8		488b4a78		MOVQ 0x78(DX), CX							
  packet_emission.go:164	0x6cf0dc		488b9c24a8000000	MOVQ 0xa8(SP), BX							
  packet_emission.go:164	0x6cf0e4		ffd1			CALL CX									
  packet_emission.go:165	0x6cf0e6		3c05			CMPL AL, $0x5								
  packet_emission.go:165	0x6cf0e8		7425			JE 0x6cf10f								
  packet_emission.go:167	0x6cf0ea		3c06			CMPL AL, $0x6								
  packet_emission.go:167	0x6cf0ec		745c			JE 0x6cf14a								
  packet_emission.go:80		0x6cf0ee		84c0			TESTL AL, AL								
  packet_emission.go:80		0x6cf0f0		7507			JNE 0x6cf0f9								
  packet_emission.go:80		0x6cf0f2		b902000000		MOVL $0x2, CX								
  packet_emission.go:168	0x6cf0f7		eb10			JMP 0x6cf109								
  packet_emission.go:82		0x6cf0f9		3c01			CMPL AL, $0x1								
  packet_emission.go:82		0x6cf0fb		7507			JNE 0x6cf104								
  packet_emission.go:82		0x6cf0fd		b905000000		MOVL $0x5, CX								
  packet_emission.go:168	0x6cf102		eb05			JMP 0x6cf109								
  packet_emission.go:168	0x6cf104		b906000000		MOVL $0x6, CX								
  packet_emission.go:168	0x6cf109		884c2458		MOVB CL, 0x58(SP)							
  packet_emission.go:168	0x6cf10d		eb3b			JMP 0x6cf14a								
  packet_emission.go:164	0x6cf10f		8844242c		MOVB AL, 0x2c(SP)							
  packet_emission.go:90		0x6cf113		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:90		0x6cf11b		488b4908		MOVQ 0x8(CX), CX							
  packet_emission.go:90		0x6cf11f		488b11			MOVQ 0(CX), DX								
  packet_emission.go:90		0x6cf122		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:90		0x6cf126		488b8a90000000		MOVQ 0x90(DX), CX							
  packet_emission.go:90		0x6cf12d		ffd1			CALL CX									
  time.go:52			0x6cf12f		4885c0			TESTQ AX, AX								
  packet_emission.go:91		0x6cf132		7507			JNE 0x6cf13b								
  packet_emission.go:166	0x6cf134		488b05f5874200		MOVQ github.com/quic-go/quic-go.deadlineSendImmediately(SB), AX		
  packet_emission.go:166	0x6cf13b		c644245803		MOVB $0x3, 0x58(SP)							
  packet_emission.go:166	0x6cf140		4889442460		MOVQ AX, 0x60(SP)							
  packet_emission.go:170	0x6cf145		0fb644242c		MOVZX 0x2c(SP), AX							
  packet_emission.go:170	0x6cf14a		3c06			CMPL AL, $0x6								
  packet_emission.go:170	0x6cf14c		0f95c1			SETNE CL								
  packet_emission.go:172	0x6cf14f		884c242e		MOVB CL, 0x2e(SP)							
  packet_emission.go:172	0x6cf153		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:172	0x6cf15b		488b4908		MOVQ 0x8(CX), CX							
  packet_emission.go:172	0x6cf15f		488b11			MOVQ 0(CX), DX								
  packet_emission.go:172	0x6cf162		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:172	0x6cf166		488b4a20		MOVQ 0x20(DX), CX							
  packet_emission.go:172	0x6cf16a		bb01000000		MOVL $0x1, BX								
  packet_emission.go:172	0x6cf16f		ffd1			CALL CX									
  packet_emission.go:172	0x6cf171		8844242f		MOVB AL, 0x2f(SP)							
  packet_emission.go:172	0x6cf175		0fb64c242e		MOVZX 0x2e(SP), CX							
  packet_emission.go:172	0x6cf17a		84c9			TESTL CL, CL								
  packet_emission.go:173	0x6cf17c		754d			JNE 0x6cf1cb								
  packet_emission.go:173	0x6cf17e		488b542430		MOVQ 0x30(SP), DX							
  packet_emission.go:173	0x6cf183		4c8b4c2438		MOVQ 0x38(SP), R9							
  packet_emission.go:173	0x6cf188		4c39ca			CMPQ DX, R9								
  packet_emission.go:173	0x6cf18b		752f			JNE 0x6cf1bc								
  packet_emission.go:173	0x6cf18d		0fb67c242d		MOVZX 0x2d(SP), DI							
  packet_emission.go:173	0x6cf192		4038f8			CMPL AL, DI								
  packet_emission.go:173	0x6cf195		751b			JNE 0x6cf1b2								
  buffer_pool.go:54		0x6cf197		488b9c2480000000	MOVQ 0x80(SP), BX							
  buffer_pool.go:54		0x6cf19f		488b5308		MOVQ 0x8(BX), DX							
  packet_emission.go:173	0x6cf1a3		4c01ca			ADDQ R9, DX								
  packet_emission.go:173	0x6cf1a6		48395310		CMPQ 0x10(BX), DX							
  packet_emission.go:173	0x6cf1aa		0f8d65feffff		JGE 0x6cf015								
  packet_emission.go:173	0x6cf1b0		eb2b			JMP 0x6cf1dd								
  packet_emission.go:176	0x6cf1b2		488b9c2480000000	MOVQ 0x80(SP), BX							
  packet_emission.go:173	0x6cf1ba		eb21			JMP 0x6cf1dd								
  packet_emission.go:176	0x6cf1bc		488b9c2480000000	MOVQ 0x80(SP), BX							
  packet_emission.go:176	0x6cf1c4		0fb67c242d		MOVZX 0x2d(SP), DI							
  packet_emission.go:173	0x6cf1c9		eb12			JMP 0x6cf1dd								
  packet_emission.go:176	0x6cf1cb		488b9c2480000000	MOVQ 0x80(SP), BX							
  packet_emission.go:176	0x6cf1d3		0fb67c242d		MOVZX 0x2d(SP), DI							
  packet_emission.go:176	0x6cf1d8		4c8b4c2438		MOVQ 0x38(SP), R9							
  packet_emission.go:176	0x6cf1dd		488b9424a0000000	MOVQ 0xa0(SP), DX							
  packet_emission.go:176	0x6cf1e5		488b5210		MOVQ 0x10(DX), DX							
  packet_emission.go:176	0x6cf1e9		4c8b12			MOVQ 0(DX), R10								
  packet_emission.go:176	0x6cf1ec		488b4208		MOVQ 0x8(DX), AX							
  packet_emission.go:176	0x6cf1f0		498b5230		MOVQ 0x30(R10), DX							
  packet_emission.go:176	0x6cf1f4		4c89c9			MOVQ R9, CX								
  packet_emission.go:176	0x6cf1f7		31f6			XORL SI, SI								
  packet_emission.go:176	0x6cf1f9		4531c0			XORL R8, R8								
  packet_emission.go:176	0x6cf1fc		ffd2			CALL DX									
  packet_emission.go:177	0x6cf1fe		c644244801		MOVB $0x1, 0x48(SP)							
  packet_emission.go:172	0x6cf203		0fb654242e		MOVZX 0x2e(SP), DX							
  packet_emission.go:172	0x6cf208		84d2			TESTL DL, DL								
  packet_emission.go:178	0x6cf20a		0f8563010000		JNE 0x6cf373								
  packet_emission.go:181	0x6cf210		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:181	0x6cf218		488b4910		MOVQ 0x10(CX), CX							
  packet_emission.go:181	0x6cf21c		488b11			MOVQ 0(CX), DX								
  packet_emission.go:181	0x6cf21f		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:181	0x6cf223		488b4a40		MOVQ 0x40(DX), CX							
  packet_emission.go:181	0x6cf227		ffd1			CALL CX									
  packet_emission.go:181	0x6cf229		84c0			TESTL AL, AL								
  packet_emission.go:181	0x6cf22b		0f85f8000000		JNE 0x6cf329								
  packet_emission.go:185	0x6cf231		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:185	0x6cf239		488b5120		MOVQ 0x20(CX), DX							
  packet_emission.go:185	0x6cf23d		488b4128		MOVQ 0x28(CX), AX							
  packet_emission.go:185	0x6cf241		488b4a20		MOVQ 0x20(DX), CX							
  packet_emission.go:185	0x6cf245		ffd1			CALL CX									
  packet_emission.go:185	0x6cf247		84c0			TESTL AL, AL								
  packet_emission.go:185	0x6cf249		0f85a7000000		JNE 0x6cf2f6								
  buffer_pool.go:79		0x6cf24f		488d05aaa44500		LEAQ github.com/quic-go/quic-go.largeBufferPool(SB), AX			
  buffer_pool.go:79		0x6cf256		e8c56bdcff		CALL sync.(*Pool).Get(SB)						
  buffer_pool.go:79		0x6cf25b		488d0da6793900		LEAQ 0x3979a6(IP), CX							
  buffer_pool.go:79		0x6cf262		4839c8			CMPQ AX, CX								
  buffer_pool.go:79		0x6cf265		0f852f010000		JNE 0x6cf39a								
  buffer_pool.go:80		0x6cf26b		48c7431801000000	MOVQ $0x1, 0x18(BX)							
  buffer_pool.go:81		0x6cf273		48c7430800000000	MOVQ $0x0, 0x8(BX)							
  packet_emission.go:150	0x6cf27b		4c8b4c2438		MOVQ 0x38(SP), R9							
  packet_emission.go:149	0x6cf280		0fb67c242f		MOVZX 0x2f(SP), DI							
  packet_emission.go:190	0x6cf285		e98bfdffff		JMP 0x6cf015								
  packet_emission.go:158	0x6cf28a		e8113afeff		CALL github.com/quic-go/quic-go.(*packetBuffer).Release(SB)		
  packet_emission.go:159	0x6cf28f		0fb6442448		MOVZX 0x48(SP), AX							
  packet_emission.go:159	0x6cf294		488b5c2450		MOVQ 0x50(SP), BX							
  packet_emission.go:159	0x6cf299		0fb64c2458		MOVZX 0x58(SP), CX							
  packet_emission.go:159	0x6cf29e		488b7c2460		MOVQ 0x60(SP), DI							
  packet_emission.go:159	0x6cf2a3		488b742468		MOVQ 0x68(SP), SI							
  packet_emission.go:159	0x6cf2a8		4c8b442470		MOVQ 0x70(SP), R8							
  packet_emission.go:159	0x6cf2ad		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:159	0x6cf2b4		5d			POPQ BP									
  packet_emission.go:159	0x6cf2b5		c3			RET									
  packet_emission.go:153	0x6cf2b6		488b842480000000	MOVQ 0x80(SP), AX							
  packet_emission.go:153	0x6cf2be		6690			NOPW									
  packet_emission.go:153	0x6cf2c0		e8db39feff		CALL github.com/quic-go/quic-go.(*packetBuffer).Release(SB)		
  packet_emission.go:154	0x6cf2c5		488b742440		MOVQ 0x40(SP), SI							
  packet_emission.go:154	0x6cf2ca		4889742468		MOVQ SI, 0x68(SP)							
  packet_emission.go:154	0x6cf2cf		4c8b442478		MOVQ 0x78(SP), R8							
  packet_emission.go:154	0x6cf2d4		4c89442470		MOVQ R8, 0x70(SP)							
  packet_emission.go:155	0x6cf2d9		0fb6442448		MOVZX 0x48(SP), AX							
  packet_emission.go:155	0x6cf2de		488b5c2450		MOVQ 0x50(SP), BX							
  packet_emission.go:155	0x6cf2e3		0fb64c2458		MOVZX 0x58(SP), CX							
  packet_emission.go:155	0x6cf2e8		488b7c2460		MOVQ 0x60(SP), DI							
  packet_emission.go:155	0x6cf2ed		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:155	0x6cf2f4		5d			POPQ BP									
  packet_emission.go:155	0x6cf2f5		c3			RET									
  packet_emission.go:186	0x6cf2f6		c644245804		MOVB $0x4, 0x58(SP)							
  packet_emission.go:186	0x6cf2fb		488b3d2e864200		MOVQ github.com/quic-go/quic-go.deadlineSendImmediately(SB), DI		
  packet_emission.go:186	0x6cf302		48897c2460		MOVQ DI, 0x60(SP)							
  packet_emission.go:187	0x6cf307		0fb6442448		MOVZX 0x48(SP), AX							
  packet_emission.go:187	0x6cf30c		488b5c2450		MOVQ 0x50(SP), BX							
  packet_emission.go:187	0x6cf311		488b742468		MOVQ 0x68(SP), SI							
  packet_emission.go:187	0x6cf316		4c8b442470		MOVQ 0x70(SP), R8							
  packet_emission.go:187	0x6cf31b		b904000000		MOVL $0x4, CX								
  packet_emission.go:187	0x6cf320		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:187	0x6cf327		5d			POPQ BP									
  packet_emission.go:187	0x6cf328		c3			RET									
  packet_emission.go:182	0x6cf329		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:182	0x6cf331		488b4910		MOVQ 0x10(CX), CX							
  packet_emission.go:182	0x6cf335		488b11			MOVQ 0(CX), DX								
  packet_emission.go:182	0x6cf338		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:182	0x6cf33c		488b4a18		MOVQ 0x18(DX), CX							
  packet_emission.go:182	0x6cf340		ffd1			CALL CX									
  packet_emission.go:182	0x6cf342		c644245801		MOVB $0x1, 0x58(SP)							
  packet_emission.go:182	0x6cf347		4889442450		MOVQ AX, 0x50(SP)							
  packet_emission.go:183	0x6cf34c		0fb64c2448		MOVZX 0x48(SP), CX							
  packet_emission.go:183	0x6cf351		488b7c2460		MOVQ 0x60(SP), DI							
  packet_emission.go:183	0x6cf356		488b742468		MOVQ 0x68(SP), SI							
  packet_emission.go:183	0x6cf35b		4c8b442470		MOVQ 0x70(SP), R8							
  packet_emission.go:183	0x6cf360		4889c3			MOVQ AX, BX								
  packet_emission.go:183	0x6cf363		89c8			MOVL CX, AX								
  packet_emission.go:183	0x6cf365		b901000000		MOVL $0x1, CX								
  packet_emission.go:183	0x6cf36a		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:183	0x6cf371		5d			POPQ BP									
  packet_emission.go:183	0x6cf372		c3			RET									
  packet_emission.go:179	0x6cf373		488b5c2450		MOVQ 0x50(SP), BX							
  packet_emission.go:179	0x6cf378		0fb64c2458		MOVZX 0x58(SP), CX							
  packet_emission.go:179	0x6cf37d		488b7c2460		MOVQ 0x60(SP), DI							
  packet_emission.go:179	0x6cf382		488b742468		MOVQ 0x68(SP), SI							
  packet_emission.go:179	0x6cf387		4c8b442470		MOVQ 0x70(SP), R8							
  packet_emission.go:179	0x6cf38c		b801000000		MOVL $0x1, AX								
  packet_emission.go:179	0x6cf391		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:179	0x6cf398		5d			POPQ BP									
  packet_emission.go:179	0x6cf399		c3			RET									
  buffer_pool.go:79		0x6cf39a		4889cb			MOVQ CX, BX								
  buffer_pool.go:79		0x6cf39d		488d0decd53d00		LEAQ 0x3dd5ec(IP), CX							
  buffer_pool.go:79		0x6cf3a4		e837f3d4ff		CALL runtime.panicdottypeE(SB)						
  buffer_pool.go:79		0x6cf3a9		4889cb			MOVQ CX, BX								
  buffer_pool.go:79		0x6cf3ac		488d0dddd53d00		LEAQ 0x3dd5dd(IP), CX							
  buffer_pool.go:79		0x6cf3b3		e828f3d4ff		CALL runtime.panicdottypeE(SB)						
  buffer_pool.go:79		0x6cf3b8		90			NOPL									
  packet_emission.go:144	0x6cf3b9		4889442408		MOVQ AX, 0x8(SP)							
  packet_emission.go:144	0x6cf3be		48895c2410		MOVQ BX, 0x10(SP)							
  packet_emission.go:144	0x6cf3c3		e898dadbff		CALL runtime.morestack_noctxt.abi0(SB)					
  packet_emission.go:144	0x6cf3c8		488b442408		MOVQ 0x8(SP), AX							
  packet_emission.go:144	0x6cf3cd		488b5c2410		MOVQ 0x10(SP), BX							
  packet_emission.go:144	0x6cf3d2		e989fbffff		JMP github.com/quic-go/quic-go.(*packetEmission).withGSO(SB)		
