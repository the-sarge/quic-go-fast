from pathlib import Path
import subprocess,re,json,difflib
root=Path('/home/josh/.cache/qgf-e5')
result={}
for name,pattern in [('emitPackets',r'github.com/quic-go/quic-go\.\(\*Conn\)\.emitPackets$'),('withGSO',r'github.com/quic-go/quic-go\.\(\*packetEmission\)\.withGSO$')]:
 texts=[]
 for variant in ['base','candidate']:
  s=subprocess.check_output(['go','tool','objdump','-s',pattern,str(root/(variant+'-endpoint'))],text=True)
  (root/(variant+'-'+name+'.asm')).write_text(s)
  lines=[]
  for line in s.splitlines()[1:]:
   cols=line.split(None,3)
   if len(cols)<4:continue
   op=cols[3]
   op=re.sub(r'(?<![$\w])0x[0-9a-f]+(?=\s|$)','ADDR',op)
   lines.append(op)
  texts.append(lines)
 result[name]=dict(instructions=[len(t) for t in texts])
 (root/(name+'-normalized.diff')).write_text('\n'.join(difflib.unified_diff(*texts,fromfile='base',tofile='candidate'))+'\n')
(root/'compiled-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
