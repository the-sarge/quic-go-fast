import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/josh/.cache/qgf-e5'); sources=json.loads((root/'source.json').read_text())
repo='/home/josh/.cache/qgf-e1/repo.git'
subprocess.run(['git','--git-dir='+repo,'fetch',str(root/'source.bundle'),'HEAD:refs/heads/codex/e5-linux-source'],check=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt=dict(sources=sources,go=subprocess.check_output(['go','version'],text=True).strip(),environment=json.loads(subprocess.check_output(['go','env','-json','GOFLAGS','GOEXPERIMENT','GOOS','GOARCH','CGO_ENABLED','GOTOOLCHAIN'])),endpoint_sha256=sha(root/'endpoint.go'),builder_sha256=sha(__file__),steps=[])
assert receipt['go']=='go version go1.27.1 linux/amd64'
for variant,head in sources.items():
 wd=Path('/Volumes/worktrees/quic-go-fast/e5-linux-'+variant)
 subprocess.run(['git','--git-dir='+repo,'worktree','add','-b','codex/e5-linux-'+variant,str(wd),head],check=True)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=wd,text=True).strip()
 fixture=subprocess.check_output(['git','--git-dir='+repo,'show',sources['candidate']+':connection_probe_experiment_test.go'])
 (wd/'connection_probe_experiment_test.go').write_bytes(fixture)
 commands=[('endpoint',['go','build','-o',str(root/(variant+'-endpoint')),str(root/'endpoint.go')]),('alloc',['go','test','-tags','emission_experiment','-c','-o',str(root/(variant+'-alloc')),'.'])]
 
 if variant=='candidate':commands += [('tests',['go','test','./...','-count=1']),('race',['go','test','-race','.','-run','^TestEmission|^Test.*Constructor.*Lifetime|^TestConnection(GSOBatch|SendQueue|ReceivePrioritization|PathValidation)|^TestHandshakeMTU|^TestSendQueue','-count=1']),('vet',['go','vet','./...'])]
 for name,cmd in commands:
  step=dict(variant=variant,head=head,kind=name,command=cmd,cwd=str(wd),started=time.time(),fixture_sha256=sha(wd/'connection_emission_experiment_test.go'),probe_fixture_sha256=sha(wd/'connection_probe_experiment_test.go'))
  print('start',variant,name,flush=True)
  with (root/(variant+'-'+name+'.log')).open('x') as log:r=subprocess.run(cmd,cwd=wd,stdout=log,stderr=subprocess.STDOUT)
  step.update(exit=r.returncode,finished=time.time())
  if name in ['endpoint','alloc','bench'] and r.returncode==0:step['binary_sha256']=sha(root/(variant+'-'+name))
  receipt['steps'].append(step);(root/'build.json').write_text(json.dumps(receipt,indent=2)+'\n')
  r.check_returncode()
