from pathlib import Path
import tarfile,hashlib
root=Path('/home/josh/.cache/qgf-e5')
out=root/'capture.tar.gz'
with tarfile.open(out,'w:gz') as tf:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.sh','.go','.json','.log','.stdout','.stderr','.asm','.diff']:
   tf.add(p,arcname=p.relative_to(root))
print(out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
