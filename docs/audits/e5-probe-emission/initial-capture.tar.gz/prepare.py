from pathlib import Path
old=Path('/home/josh/.cache/qgf-e4-r2');root=Path('/home/josh/.cache/qgf-e5')
for name in ['endpoint.go','collect.py','isolate.sh','alloc.py','phases.py','build.py','analyze-e4.py']:
 s=(old/name).read_text().replace('qgf-e4-r2','qgf-e5').replace('E4 replacement P3 campaign','E5 initial P3 campaign')
 if name=='build.py':
  s=s.replace('e4-r2-linux','e5-linux')
  s=s.replace("commands += [('bench',['go','test','-c','-o',str(root/(variant+'-bench')),'./integrationtests/self'])]",'')
  # Only the opt-in test fixture is overlaid on the exact base runtime.
  s=s.replace("commands=[('endpoint'", "fixture=subprocess.check_output(['git','--git-dir='+repo,'show',sources['candidate']+':connection_probe_experiment_test.go'])\n (wd/'connection_probe_experiment_test.go').write_bytes(fixture)\n commands=[('endpoint'")
  s=s.replace("fixture_sha256=sha(wd/'connection_emission_experiment_test.go')", "fixture_sha256=sha(wd/'connection_emission_experiment_test.go'),probe_fixture_sha256=sha(wd/'connection_probe_experiment_test.go')")
  s=s.replace('^TestEmission|^Test.*Constructor.*Lifetime|^TestConnection(GSOBatch|SendQueue|ReceivePrioritization)|^TestHandshakeMTU','^TestEmission|^Test.*Constructor.*Lifetime|^TestConnection(GSOBatch|SendQueue|ReceivePrioritization|PathValidation)|^TestHandshakeMTU|^TestSendQueue')
 if name=='alloc.py':s=s.replace('^TestEmissionFocusedAllocations$','^TestEmission(Focused|Probe)Allocations$')
 if name=='phases.py':s=s.replace("[('bench-01','bench'),('alloc-01','alloc'),('qlog-01','qlog'),('campaign-01','campaign')]","[('alloc-01','alloc'),('qlog-01','qlog'),('campaign-01','campaign')]")
 (root/name).write_text(s)
