import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/josh/.cache/qgf-e5')
fixture=(root/'probe-fixture.go').read_bytes()
receipt=dict(fixture_sha256=hashlib.sha256(fixture).hexdigest(),sources=json.loads((root/'source.json').read_text()),steps=[])
for variant in ['base','candidate']:
 wd=Path('/Volumes/worktrees/quic-go-fast/e5-linux-'+variant)
 before=subprocess.check_output(['git','status','--short','--branch'],cwd=wd,text=True)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=wd,text=True).strip()
 assert head==receipt['sources'][variant]
 assert subprocess.check_output(['git','diff','--name-only'],cwd=wd,text=True).strip()==''
 (wd/'connection_probe_experiment_test.go').write_bytes(fixture)
 cmd=['go','test','-tags','emission_experiment','-c','-o',str(root/(variant+'-path-alloc')),'.']
 with (root/(variant+'-path-alloc-build.log')).open('x') as log:
  r=subprocess.run(cmd,cwd=wd,stdout=log,stderr=subprocess.STDOUT)
 receipt['steps'].append(dict(variant=variant,head=head,before=before,command=cmd,exit=r.returncode,binary_sha256=hashlib.sha256((root/(variant+'-path-alloc')).read_bytes()).hexdigest()))
 (root/'path-alloc-build.json').write_text(json.dumps(receipt,indent=2)+'\n')
 r.check_returncode()
# Same launcher/controller and four-core process placement; separate finite cold-path observation.
s=(root/'alloc.py').read_text().replace("variant+'-alloc'","variant+'-path-alloc'").replace('build.json','path-alloc-build.json').replace('isolate.sh','isolate-path.sh').replace('^TestEmission(Focused|Probe)Allocations$','^TestEmissionProbeAllocations/path-replacement$')
(root/'alloc-path-runner.py').write_text(s)
s=(root/'isolate.sh').read_text().replace('/alloc.py','/alloc-path-runner.py')
(root/'isolate-path.sh').write_text(s)
with (root/'alloc-path-01.log').open('x') as log:
 code=subprocess.run(['sudo','-n','bash',str(root/'isolate-path.sh'),str(root/'alloc-path-01'),'alloc'],stdout=log,stderr=subprocess.STDOUT).returncode
record=dict(exit=code,allowed_cpus={s:subprocess.check_output(['systemctl','show',s,'--property=AllowedCPUs','--value'],text=True).strip() for s in ['machine.slice','system.slice','user.slice']},marker=Path('/run/qgf-e5-cpu-reservation').exists(),timer_active=subprocess.run(['systemctl','is-active','--quiet','qgf-e5-cpu-restore.timer']).returncode==0)
record['restored']=not any(record['allowed_cpus'].values()) and not record['marker'] and not record['timer_active']
(root/'alloc-path-01-restoration.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
if code or not record['restored']:raise SystemExit(code or 1)
