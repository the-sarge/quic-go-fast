TEXT github.com/quic-go/quic-go.(*Conn).emitPackets(SB) /Volumes/worktrees/quic-go-fast/e5-linux-candidate/connection.go
  connection.go:2511		0x6c29c0		4c8da424c8feffff	LEAQ 0xfffffec8(SP), R12							
  connection.go:2511		0x6c29c8		4d3b6610		CMPQ R12, 0x10(R14)								
  connection.go:2511		0x6c29cc		0f8674060000		JBE 0x6c3046									
  connection.go:2511		0x6c29d2		55			PUSHQ BP									
  connection.go:2511		0x6c29d3		4889e5			MOVQ SP, BP									
  connection.go:2511		0x6c29d6		4881ecb0010000		SUBQ $0x1b0, SP									
  connection.go:2512		0x6c29dd		48898424c0010000	MOVQ AX, 0x1c0(SP)								
  connection.go:2512		0x6c29e5		48899c24c8010000	MOVQ BX, 0x1c8(SP)								
  connection.go:2511		0x6c29ed		488d9424a8000000	LEAQ 0xa8(SP), DX								
  connection.go:2511		0x6c29f5		440f113a		MOVUPS X15, 0(DX)								
  connection.go:2511		0x6c29f9		440f117a10		MOVUPS X15, 0x10(DX)								
  connection.go:2511		0x6c29fe		440f117a20		MOVUPS X15, 0x20(DX)								
  connection.go:2512		0x6c2a03		4883787002		CMPQ 0x70(AX), $0x2								
  connection.go:2512		0x6c2a08		0f850c020000		JNE 0x6c2c1a									
  connection.go:2512		0x6c2a0e		80b83b03000000		CMPB 0x33b(AX), $0x0								
  connection.go:2512		0x6c2a15		0f84ff010000		JE 0x6c2c1a									
  type.go:58			0x6c2a1b		488b90e0000000		MOVQ 0xe0(AX), DX								
  connection.go:2513		0x6c2a22		4885d2			TESTQ DX, DX									
  connection.go:2513		0x6c2a25		0f84ef010000		JE 0x6c2c1a									
  connection.go:2514		0x6c2a2b		4889d0			MOVQ DX, AX									
  connection.go:2514		0x6c2a2e		e8cd8a0100		CALL github.com/quic-go/quic-go.(*pathManagerOutgoing).NextPathToProbe(SB)	
  connection.go:2514		0x6c2a33		488d54247b		LEAQ 0x7b(SP), DX								
  connection.go:2514		0x6c2a38		4989e1			MOVQ SP, R9									
  connection.go:2514		0x6c2a3b		450f1031		MOVUPS 0(R9), X14								
  connection.go:2514		0x6c2a3f		440f1132		MOVUPS X14, 0(DX)								
  connection.go:2514		0x6c2a43		450f107105		MOVUPS 0x5(R9), X14								
  connection.go:2514		0x6c2a48		440f117205		MOVUPS X14, 0x5(DX)								
  connection.go:2514		0x6c2a4d		4c8d542466		LEAQ 0x66(SP), R10								
  connection.go:2514		0x6c2a52		440f1032		MOVUPS 0(DX), X14								
  connection.go:2514		0x6c2a56		450f1132		MOVUPS X14, 0(R10)								
  connection.go:2514		0x6c2a5a		440f107205		MOVUPS 0x5(DX), X14								
  connection.go:2514		0x6c2a5f		450f117205		MOVUPS X14, 0x5(R10)								
  connection.go:2514		0x6c2a64		4584c0			TESTL R8, R8									
  connection.go:2515		0x6c2a67		7515			JNE 0x6c2a7e									
  connection.go:2530		0x6c2a69		488b8424c0010000	MOVQ 0x1c0(SP), AX								
  connection.go:2531		0x6c2a71		488b9c24c8010000	MOVQ 0x1c8(SP), BX								
  connection.go:2515		0x6c2a79		e99c010000		JMP 0x6c2c1a									
  connection.go:2514		0x6c2a7e		4889b424d8000000	MOVQ SI, 0xd8(SP)								
  connection.go:2514		0x6c2a86		4889bc2478010000	MOVQ DI, 0x178(SP)								
  connection.go:2514		0x6c2a8e		48899c2470010000	MOVQ BX, 0x170(SP)								
  connection.go:2514		0x6c2a96		48898424a0000000	MOVQ AX, 0xa0(SP)								
  connection.go:2514		0x6c2a9e		48898c2498000000	MOVQ CX, 0x98(SP)								
  connection.go:2516		0x6c2aa6		488b8c24c0010000	MOVQ 0x1c0(SP), CX								
  connection.go:2516		0x6c2aae		488b9188000000		MOVQ 0x88(CX), DX								
  connection.go:2516		0x6c2ab5		488b8190000000		MOVQ 0x90(CX), AX								
  connection.go:2516		0x6c2abc		488b4a30		MOVQ 0x30(DX), CX								
  connection.go:2516		0x6c2ac0		ffd1			CALL CX										
  connection.go:2516		0x6c2ac2		4889e1			MOVQ SP, CX									
  connection.go:2516		0x6c2ac5		488d542466		LEAQ 0x66(SP), DX								
  connection.go:2516		0x6c2aca		440f1032		MOVUPS 0(DX), X14								
  connection.go:2516		0x6c2ace		440f1131		MOVUPS X14, 0(CX)								
  connection.go:2516		0x6c2ad2		440f107205		MOVUPS 0x5(DX), X14								
  connection.go:2516		0x6c2ad7		440f117105		MOVUPS X14, 0x5(CX)								
  connection.go:2516		0x6c2adc		488bbc2498000000	MOVQ 0x98(SP), DI								
  connection.go:2516		0x6c2ae4		488bb42478010000	MOVQ 0x178(SP), SI								
  connection.go:2516		0x6c2aec		4c8b8424d8000000	MOVQ 0xd8(SP), R8								
  connection.go:2516		0x6c2af4		4989c1			MOVQ AX, R9									
  connection.go:2516		0x6c2af7		4989da			MOVQ BX, R10									
  connection.go:2516		0x6c2afa		4c8b9c24c8010000	MOVQ 0x1c8(SP), R11								
  connection.go:2516		0x6c2b02		488b8424c0010000	MOVQ 0x1c0(SP), AX								
  connection.go:2516		0x6c2b0a		488b9c24a0000000	MOVQ 0xa0(SP), BX								
  connection.go:2516		0x6c2b12		488b8c2470010000	MOVQ 0x170(SP), CX								
  connection.go:2516		0x6c2b1a		e801db0000		CALL github.com/quic-go/quic-go.(*packetEmission).clientProbe(SB)		
  connection.go:2516		0x6c2b1f		90			NOPL										
  connection.go:2516		0x6c2b20		4885c0			TESTQ AX, AX									
  connection.go:2516		0x6c2b23		0f8495000000		JE 0x6c2bbe									
  connection.go:2517		0x6c2b29		488d942480010000	LEAQ 0x180(SP), DX								
  connection.go:2517		0x6c2b31		440f113a		MOVUPS X15, 0(DX)								
  connection.go:2517		0x6c2b35		440f117a10		MOVUPS X15, 0x10(DX)								
  connection.go:2517		0x6c2b3a		440f117a20		MOVUPS X15, 0x20(DX)								
  packet_emission.go:66		0x6c2b3f		c684249001000007	MOVB $0x7, 0x190(SP)								
  packet_emission.go:66		0x6c2b47		48898424a0010000	MOVQ AX, 0x1a0(SP)								
  packet_emission.go:66		0x6c2b4f		48899c24a8010000	MOVQ BX, 0x1a8(SP)								
  connection.go:2517		0x6c2b57		0fb6942480010000	MOVZX 0x180(SP), DX								
  connection.go:2517		0x6c2b5f		4c8b8c2488010000	MOVQ 0x188(SP), R9								
  connection.go:2517		0x6c2b67		0fb68c2490010000	MOVZX 0x190(SP), CX								
  connection.go:2517		0x6c2b6f		488bbc2498010000	MOVQ 0x198(SP), DI								
  connection.go:2517		0x6c2b77		488bb424a0010000	MOVQ 0x1a0(SP), SI								
  connection.go:2517		0x6c2b7f		4c8d9424a8000000	LEAQ 0xa8(SP), R10								
  connection.go:2517		0x6c2b87		450f113a		MOVUPS X15, 0(R10)								
  connection.go:2517		0x6c2b8b		450f117a10		MOVUPS X15, 0x10(R10)								
  connection.go:2517		0x6c2b90		450f117a20		MOVUPS X15, 0x20(R10)								
  connection.go:2517		0x6c2b95		c68424b800000007	MOVB $0x7, 0xb8(SP)								
  connection.go:2517		0x6c2b9d		48898424c8000000	MOVQ AX, 0xc8(SP)								
  connection.go:2517		0x6c2ba5		48899c24d0000000	MOVQ BX, 0xd0(SP)								
  connection.go:2517		0x6c2bad		89d0			MOVL DX, AX									
  connection.go:2517		0x6c2baf		4989d8			MOVQ BX, R8									
  connection.go:2517		0x6c2bb2		4c89cb			MOVQ R9, BX									
  connection.go:2517		0x6c2bb5		4881c4b0010000		ADDQ $0x1b0, SP									
  connection.go:2517		0x6c2bbc		5d			POPQ BP										
  connection.go:2517		0x6c2bbd		c3			RET										
  connection.go:2731		0x6c2bbe		488b8c24c0010000	MOVQ 0x1c0(SP), CX								
  connection.go:2731		0x6c2bc6		488b81a0020000		MOVQ 0x2a0(CX), AX								
  connection.go:2520		0x6c2bcd		90			NOPL										
  connection.go:2731		0x6c2bce		488d5c247b		LEAQ 0x7b(SP), BX								
  connection.go:2731		0x6c2bd3		e8887ad5ff		CALL runtime.selectnbsend(SB)							
  connection.go:2521		0x6c2bd8		488d8c24a8000000	LEAQ 0xa8(SP), CX								
  connection.go:2521		0x6c2be0		440f1139		MOVUPS X15, 0(CX)								
  connection.go:2521		0x6c2be4		440f117910		MOVUPS X15, 0x10(CX)								
  connection.go:2521		0x6c2be9		440f117920		MOVUPS X15, 0x20(CX)								
  connection.go:2521		0x6c2bee		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  connection.go:2521		0x6c2bf6		4c8b8424d0000000	MOVQ 0xd0(SP), R8								
  connection.go:2521		0x6c2bfe		c68424b800000007	MOVB $0x7, 0xb8(SP)								
  connection.go:2521		0x6c2c06		31c0			XORL AX, AX									
  connection.go:2521		0x6c2c08		b907000000		MOVL $0x7, CX									
  connection.go:2521		0x6c2c0d		31ff			XORL DI, DI									
  connection.go:2521		0x6c2c0f		31f6			XORL SI, SI									
  connection.go:2521		0x6c2c11		4881c4b0010000		ADDQ $0x1b0, SP									
  connection.go:2521		0x6c2c18		5d			POPQ BP										
  connection.go:2521		0x6c2c19		c3			RET										
  connection.go:2530		0x6c2c1a		80b83b03000000		CMPB 0x33b(AX), $0x0								
  connection.go:2530		0x6c2c21		742c			JE 0x6c2c4f									
  connection.go:2530		0x6c2c23		488b9058020000		MOVQ 0x258(AX), DX								
  connection.go:2530		0x6c2c2a		4885d2			TESTQ DX, DX									
  connection.go:2530		0x6c2c2d		7504			JNE 0x6c2c33									
  connection.go:2530		0x6c2c2f		31c9			XORL CX, CX									
  connection.go:2530		0x6c2c31		eb1e			JMP 0x6c2c51									
  connection.go:2530		0x6c2c33		4889d0			MOVQ DX, AX									
  connection.go:2530		0x6c2c36		e845b10000		CALL github.com/quic-go/quic-go.(*mtuFinder).ShouldSendProbe(SB)		
  connection.go:2531		0x6c2c3b		488b9c24c8010000	MOVQ 0x1c8(SP), BX								
  connection.go:2530		0x6c2c43		89c1			MOVL AX, CX									
  connection.go:2531		0x6c2c45		488b8424c0010000	MOVQ 0x1c0(SP), AX								
  connection.go:2530		0x6c2c4d		eb02			JMP 0x6c2c51									
  connection.go:2530		0x6c2c4f		31c9			XORL CX, CX									
  connection.go:2530		0x6c2c51		84c9			TESTL CL, CL									
  connection.go:2530		0x6c2c53		0f84f5000000		JE 0x6c2d4e									
  connection.go:2531		0x6c2c59		488b9058020000		MOVQ 0x258(AX), DX								
  connection.go:2531		0x6c2c60		4889d9			MOVQ BX, CX									
  connection.go:2531		0x6c2c63		4889d3			MOVQ DX, BX									
  connection.go:2531		0x6c2c66		e8f5dd0000		CALL github.com/quic-go/quic-go.(*packetEmission).mtuProbe(SB)			
  connection.go:2531		0x6c2c6b		88842480010000		MOVB AL, 0x180(SP)								
  connection.go:2531		0x6c2c72		48899c2488010000	MOVQ BX, 0x188(SP)								
  connection.go:2531		0x6c2c7a		888c2490010000		MOVB CL, 0x190(SP)								
  connection.go:2531		0x6c2c81		4889bc2498010000	MOVQ DI, 0x198(SP)								
  connection.go:2531		0x6c2c89		4889b424a0010000	MOVQ SI, 0x1a0(SP)								
  connection.go:2531		0x6c2c91		4c898424a8010000	MOVQ R8, 0x1a8(SP)								
  connection.go:2532		0x6c2c99		80bc248001000000	CMPB 0x180(SP), $0x0								
  connection.go:2531		0x6c2ca1		488d942440010000	LEAQ 0x140(SP), DX								
  connection.go:2531		0x6c2ca9		488db42480010000	LEAQ 0x180(SP), SI								
  connection.go:2531		0x6c2cb1		440f1036		MOVUPS 0(SI), X14								
  connection.go:2531		0x6c2cb5		440f1132		MOVUPS X14, 0(DX)								
  connection.go:2531		0x6c2cb9		440f107610		MOVUPS 0x10(SI), X14								
  connection.go:2531		0x6c2cbe		440f117210		MOVUPS X14, 0x10(DX)								
  connection.go:2531		0x6c2cc3		440f107620		MOVUPS 0x20(SI), X14								
  connection.go:2531		0x6c2cc8		440f117220		MOVUPS X14, 0x20(DX)								
  connection.go:2532		0x6c2ccd		7422			JE 0x6c2cf1									
  connection.go:2731		0x6c2ccf		488b8c24c0010000	MOVQ 0x1c0(SP), CX								
  connection.go:2731		0x6c2cd7		488b81a0020000		MOVQ 0x2a0(CX), AX								
  connection.go:2533		0x6c2cde		90			NOPL										
  connection.go:2731		0x6c2cdf		488d5c247b		LEAQ 0x7b(SP), BX								
  connection.go:2731		0x6c2ce4		e87779d5ff		CALL runtime.selectnbsend(SB)							
  connection.go:2531		0x6c2ce9		488d942440010000	LEAQ 0x140(SP), DX								
  connection.go:2535		0x6c2cf1		0fb6842440010000	MOVZX 0x140(SP), AX								
  connection.go:2535		0x6c2cf9		488b9c2448010000	MOVQ 0x148(SP), BX								
  connection.go:2535		0x6c2d01		0fb68c2450010000	MOVZX 0x150(SP), CX								
  connection.go:2535		0x6c2d09		488bbc2458010000	MOVQ 0x158(SP), DI								
  connection.go:2535		0x6c2d11		488bb42460010000	MOVQ 0x160(SP), SI								
  connection.go:2535		0x6c2d19		4c8b842468010000	MOVQ 0x168(SP), R8								
  connection.go:2535		0x6c2d21		4c8d8c24a8000000	LEAQ 0xa8(SP), R9								
  connection.go:2535		0x6c2d29		440f1032		MOVUPS 0(DX), X14								
  connection.go:2535		0x6c2d2d		450f1131		MOVUPS X14, 0(R9)								
  connection.go:2535		0x6c2d31		440f107210		MOVUPS 0x10(DX), X14								
  connection.go:2535		0x6c2d36		450f117110		MOVUPS X14, 0x10(R9)								
  connection.go:2535		0x6c2d3b		440f107220		MOVUPS 0x20(DX), X14								
  connection.go:2535		0x6c2d40		450f117120		MOVUPS X14, 0x20(R9)								
  connection.go:2535		0x6c2d45		4881c4b0010000		ADDQ $0x1b0, SP									
  connection.go:2535		0x6c2d4c		5d			POPQ BP										
  connection.go:2535		0x6c2d4d		c3			RET										
  connection.go:2538		0x6c2d4e		488b8008020000		MOVQ 0x208(AX), AX								
  connection.go:2538		0x6c2d55		e806630000		CALL github.com/quic-go/quic-go.(*connectionFlowController).GetWindowUpdate(SB)	
  connection.go:2538		0x6c2d5a		4885c0			TESTQ AX, AX									
  connection.go:2538		0x6c2d5d		7e4a			JLE 0x6c2da9									
  connection.go:2538		0x6c2d5f		4889842490000000	MOVQ AX, 0x90(SP)								
  connection.go:2539		0x6c2d67		b808000000		MOVL $0x8, AX									
  connection.go:2539		0x6c2d6c		488d1df53f3f00		LEAQ 0x3f3ff5(IP), BX								
  connection.go:2539		0x6c2d73		b901000000		MOVL $0x1, CX									
  connection.go:2539		0x6c2d78		e8a315d6ff		CALL runtime.mallocgcTinySC2(SB)						
  connection.go:2539		0x6c2d7d		488b942490000000	MOVQ 0x90(SP), DX								
  connection.go:2539		0x6c2d85		488910			MOVQ DX, 0(AX)									
  connection.go:2539		0x6c2d88		488b9424c0010000	MOVQ 0x1c0(SP), DX								
  connection.go:2539		0x6c2d90		488b9200020000		MOVQ 0x200(DX), DX								
  connection.go:2539		0x6c2d97		488d1d72114300		LEAQ 0x431172(IP), BX								
  connection.go:2539		0x6c2d9e		4889c1			MOVQ AX, CX									
  connection.go:2539		0x6c2da1		4889d0			MOVQ DX, AX									
  connection.go:2539		0x6c2da4		e8977e0000		CALL github.com/quic-go/quic-go.(*framer).QueueControlFrame(SB)			
  connection.go:2541		0x6c2da9		488b8424c0010000	MOVQ 0x1c0(SP), AX								
  connection.go:2541		0x6c2db1		488b9038010000		MOVQ 0x138(AX), DX								
  crypto_stream_manager.go:57	0x6c2db8		488b5210		MOVQ 0x10(DX), DX								
  crypto_stream_manager.go:57	0x6c2dbc		48837a3800		CMPQ 0x38(DX), $0x0								
  crypto_stream_manager.go:57	0x6c2dc1		7504			JNE 0x6c2dc7									
  crypto_stream_manager.go:57	0x6c2dc3		31c9			XORL CX, CX									
  connection.go:2541		0x6c2dc5		eb19			JMP 0x6c2de0									
  crypto_stream_manager.go:60	0x6c2dc7		4889d0			MOVQ DX, AX									
  crypto_stream_manager.go:60	0x6c2dca		bbe8030000		MOVL $0x3e8, BX									
  crypto_stream_manager.go:60	0x6c2dcf		e84c3f0000		CALL github.com/quic-go/quic-go.(*baseCryptoStream).PopCryptoFrame(SB)		
  connection.go:2541		0x6c2dd4		4889c1			MOVQ AX, CX									
  connection.go:2545		0x6c2dd7		488b8424c0010000	MOVQ 0x1c0(SP), AX								
  connection.go:2545		0x6c2ddf		90			NOPL										
  connection.go:2541		0x6c2de0		4885c9			TESTQ CX, CX									
  connection.go:2541		0x6c2de3		7436			JE 0x6c2e1b									
  connection.go:2772		0x6c2de5		488b8000020000		MOVQ 0x200(AX), AX								
  connection.go:2542		0x6c2dec		90			NOPL										
  connection.go:2772		0x6c2ded		488d1dec0e4300		LEAQ 0x430eec(IP), BX								
  connection.go:2772		0x6c2df4		e8477e0000		CALL github.com/quic-go/quic-go.(*framer).QueueControlFrame(SB)			
  connection.go:2731		0x6c2df9		488b9424c0010000	MOVQ 0x1c0(SP), DX								
  connection.go:2731		0x6c2e01		488b82a0020000		MOVQ 0x2a0(DX), AX								
  connection.go:2773		0x6c2e08		90			NOPL										
  connection.go:2731		0x6c2e09		488d5c247b		LEAQ 0x7b(SP), BX								
  connection.go:2731		0x6c2e0e		e84d78d5ff		CALL runtime.selectnbsend(SB)							
  connection.go:2545		0x6c2e13		488b8424c0010000	MOVQ 0x1c0(SP), AX								
  connection.go:2545		0x6c2e1b		80b83b03000000		CMPB 0x33b(AX), $0x0								
  connection.go:2545		0x6c2e22		0f8429010000		JE 0x6c2f51									
  connection.go:2553		0x6c2e28		488b8888000000		MOVQ 0x88(AX), CX								
  connection.go:2553		0x6c2e2f		488b8090000000		MOVQ 0x90(AX), AX								
  connection.go:2553		0x6c2e36		488b4948		MOVQ 0x48(CX), CX								
  connection.go:2553		0x6c2e3a		ffd1			CALL CX										
  connection.go:2553		0x6c2e3c		488b8424c0010000	MOVQ 0x1c0(SP), AX								
  connection.go:2553		0x6c2e44		89d9			MOVL BX, CX									
  connection.go:2553		0x6c2e46		488b9c24c8010000	MOVQ 0x1c8(SP), BX								
  connection.go:2553		0x6c2e4e		e8cdb20000		CALL github.com/quic-go/quic-go.(*packetEmission).advance(SB)			
  connection.go:2553		0x6c2e53		88842480010000		MOVB AL, 0x180(SP)								
  connection.go:2553		0x6c2e5a		48899c2488010000	MOVQ BX, 0x188(SP)								
  connection.go:2553		0x6c2e62		888c2490010000		MOVB CL, 0x190(SP)								
  connection.go:2553		0x6c2e69		4889bc2498010000	MOVQ DI, 0x198(SP)								
  connection.go:2553		0x6c2e71		4889b424a0010000	MOVQ SI, 0x1a0(SP)								
  connection.go:2553		0x6c2e79		4c898424a8010000	MOVQ R8, 0x1a8(SP)								
  connection.go:2554		0x6c2e81		0fb68c2490010000	MOVZX 0x190(SP), CX								
  connection.go:2556		0x6c2e89		488b942498010000	MOVQ 0x198(SP), DX								
  connection.go:2553		0x6c2e91		488d9c24e0000000	LEAQ 0xe0(SP), BX								
  connection.go:2553		0x6c2e99		488db42480010000	LEAQ 0x180(SP), SI								
  connection.go:2553		0x6c2ea1		440f1036		MOVUPS 0(SI), X14								
  connection.go:2553		0x6c2ea5		440f1133		MOVUPS X14, 0(BX)								
  connection.go:2553		0x6c2ea9		440f107610		MOVUPS 0x10(SI), X14								
  connection.go:2553		0x6c2eae		440f117310		MOVUPS X14, 0x10(BX)								
  connection.go:2553		0x6c2eb3		440f107620		MOVUPS 0x20(SI), X14								
  connection.go:2553		0x6c2eb8		440f117320		MOVUPS X14, 0x20(BX)								
  connection.go:2553		0x6c2ebd		0f1f00			NOPL 0(AX)									
  connection.go:2554		0x6c2ec0		80f904			CMPL CL, $0x4									
  connection.go:2555		0x6c2ec3		771b			JA 0x6c2ee0									
  connection.go:2557		0x6c2ec5		80f902			CMPL CL, $0x2									
  connection.go:2557		0x6c2ec8		7627			JBE 0x6c2ef1									
  connection.go:2556		0x6c2eca		4c8b8c24c0010000	MOVQ 0x1c0(SP), R9								
  connection.go:2556		0x6c2ed2		49899160030000		MOVQ DX, 0x360(R9)								
  connection.go:2556		0x6c2ed9		eb16			JMP 0x6c2ef1									
  connection.go:2556		0x6c2edb		0f1f440000		NOPL 0(AX)(AX*1)								
  connection.go:2557		0x6c2ee0		80f906			CMPL CL, $0x6									
  connection.go:2557		0x6c2ee3		760c			JBE 0x6c2ef1									
  connection.go:2560		0x6c2ee5		8d51f9			LEAL -0x7(CX), DX								
  connection.go:2560		0x6c2ee8		80fa02			CMPL DL, $0x2									
  connection.go:2560		0x6c2eeb		0f8640010000		JBE 0x6c3031									
  connection.go:2563		0x6c2ef1		0fb68424e0000000	MOVZX 0xe0(SP), AX								
  connection.go:2563		0x6c2ef9		488b9424e8000000	MOVQ 0xe8(SP), DX								
  connection.go:2563		0x6c2f01		0fb68c24f0000000	MOVZX 0xf0(SP), CX								
  connection.go:2563		0x6c2f09		488bbc24f8000000	MOVQ 0xf8(SP), DI								
  connection.go:2563		0x6c2f11		488bb42400010000	MOVQ 0x100(SP), SI								
  connection.go:2563		0x6c2f19		4c8b842408010000	MOVQ 0x108(SP), R8								
  connection.go:2563		0x6c2f21		4c8d8c24a8000000	LEAQ 0xa8(SP), R9								
  connection.go:2563		0x6c2f29		440f1033		MOVUPS 0(BX), X14								
  connection.go:2563		0x6c2f2d		450f1131		MOVUPS X14, 0(R9)								
  connection.go:2563		0x6c2f31		440f107310		MOVUPS 0x10(BX), X14								
  connection.go:2563		0x6c2f36		450f117110		MOVUPS X14, 0x10(R9)								
  connection.go:2563		0x6c2f3b		440f107320		MOVUPS 0x20(BX), X14								
  connection.go:2563		0x6c2f40		450f117120		MOVUPS X14, 0x20(R9)								
  connection.go:2563		0x6c2f45		4889d3			MOVQ DX, BX									
  connection.go:2563		0x6c2f48		4881c4b0010000		ADDQ $0x1b0, SP									
  connection.go:2563		0x6c2f4f		5d			POPQ BP										
  connection.go:2563		0x6c2f50		c3			RET										
  connection.go:2546		0x6c2f51		488b9c24c8010000	MOVQ 0x1c8(SP), BX								
  connection.go:2546		0x6c2f59		e8a2c40000		CALL github.com/quic-go/quic-go.(*packetEmission).coalesced(SB)			
  connection.go:2546		0x6c2f5e		88842480010000		MOVB AL, 0x180(SP)								
  connection.go:2546		0x6c2f65		48899c2488010000	MOVQ BX, 0x188(SP)								
  connection.go:2546		0x6c2f6d		888c2490010000		MOVB CL, 0x190(SP)								
  connection.go:2546		0x6c2f74		4889bc2498010000	MOVQ DI, 0x198(SP)								
  connection.go:2546		0x6c2f7c		4889b424a0010000	MOVQ SI, 0x1a0(SP)								
  connection.go:2546		0x6c2f84		4c898424a8010000	MOVQ R8, 0x1a8(SP)								
  connection.go:2548		0x6c2f8c		488b8c2498010000	MOVQ 0x198(SP), CX								
  connection.go:2546		0x6c2f94		488d942410010000	LEAQ 0x110(SP), DX								
  connection.go:2546		0x6c2f9c		488db42480010000	LEAQ 0x180(SP), SI								
  connection.go:2546		0x6c2fa4		440f1036		MOVUPS 0(SI), X14								
  connection.go:2546		0x6c2fa8		440f1132		MOVUPS X14, 0(DX)								
  connection.go:2546		0x6c2fac		440f107610		MOVUPS 0x10(SI), X14								
  connection.go:2546		0x6c2fb1		440f117210		MOVUPS X14, 0x10(DX)								
  connection.go:2546		0x6c2fb6		440f107620		MOVUPS 0x20(SI), X14								
  connection.go:2546		0x6c2fbb		440f117220		MOVUPS X14, 0x20(DX)								
  time.go:52			0x6c2fc0		4885c9			TESTQ CX, CX									
  connection.go:2547		0x6c2fc3		740f			JE 0x6c2fd4									
  connection.go:2548		0x6c2fc5		4c8b8c24c0010000	MOVQ 0x1c0(SP), R9								
  connection.go:2548		0x6c2fcd		49898960030000		MOVQ CX, 0x360(R9)								
  connection.go:2550		0x6c2fd4		0fb6842410010000	MOVZX 0x110(SP), AX								
  connection.go:2550		0x6c2fdc		488b9c2418010000	MOVQ 0x118(SP), BX								
  connection.go:2550		0x6c2fe4		0fb68c2420010000	MOVZX 0x120(SP), CX								
  connection.go:2550		0x6c2fec		488bbc2428010000	MOVQ 0x128(SP), DI								
  connection.go:2550		0x6c2ff4		488bb42430010000	MOVQ 0x130(SP), SI								
  connection.go:2550		0x6c2ffc		4c8b842438010000	MOVQ 0x138(SP), R8								
  connection.go:2550		0x6c3004		4c8d8c24a8000000	LEAQ 0xa8(SP), R9								
  connection.go:2550		0x6c300c		440f1032		MOVUPS 0(DX), X14								
  connection.go:2550		0x6c3010		450f1131		MOVUPS X14, 0(R9)								
  connection.go:2550		0x6c3014		440f107210		MOVUPS 0x10(DX), X14								
  connection.go:2550		0x6c3019		450f117110		MOVUPS X14, 0x10(R9)								
  connection.go:2550		0x6c301e		440f107220		MOVUPS 0x20(DX), X14								
  connection.go:2550		0x6c3023		450f117120		MOVUPS X14, 0x20(R9)								
  connection.go:2550		0x6c3028		4881c4b0010000		ADDQ $0x1b0, SP									
  connection.go:2550		0x6c302f		5d			POPQ BP										
  connection.go:2550		0x6c3030		c3			RET										
  connection.go:2561		0x6c3031		488d05c8503e00		LEAQ 0x3e50c8(IP), AX								
  connection.go:2561		0x6c3038		488d1d61300d00		LEAQ 0xd3061(IP), BX								
  connection.go:2561		0x6c303f		90			NOPL										
  connection.go:2561		0x6c3040		e87b4bdcff		CALL runtime.gopanic(SB)							
  connection.go:2561		0x6c3045		90			NOPL										
  connection.go:2511		0x6c3046		4889442408		MOVQ AX, 0x8(SP)								
  connection.go:2511		0x6c304b		48895c2410		MOVQ BX, 0x10(SP)								
  connection.go:2511		0x6c3050		e80b9edcff		CALL runtime.morestack_noctxt.abi0(SB)						
  connection.go:2511		0x6c3055		488b442408		MOVQ 0x8(SP), AX								
  connection.go:2511		0x6c305a		488b5c2410		MOVQ 0x10(SP), BX								
  connection.go:2511		0x6c305f		90			NOPL										
  connection.go:2511		0x6c3060		e95bf9ffff		JMP github.com/quic-go/quic-go.(*Conn).emitPackets(SB)				
