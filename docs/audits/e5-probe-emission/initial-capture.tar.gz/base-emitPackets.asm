TEXT github.com/quic-go/quic-go.(*Conn).emitPackets(SB) /Volumes/worktrees/quic-go-fast/e5-linux-base/connection.go
  connection.go:2517		0x6c2d20		4c8da424c8fdffff	LEAQ 0xfffffdc8(SP), R12									
  connection.go:2517		0x6c2d28		4d3b6610		CMPQ R12, 0x10(R14)										
  connection.go:2517		0x6c2d2c		0f86a90c0000		JBE 0x6c39db											
  connection.go:2517		0x6c2d32		55			PUSHQ BP											
  connection.go:2517		0x6c2d33		4889e5			MOVQ SP, BP											
  connection.go:2517		0x6c2d36		4881ecb0020000		SUBQ $0x2b0, SP											
  connection.go:2518		0x6c2d3d		48898424c0020000	MOVQ AX, 0x2c0(SP)										
  connection.go:2518		0x6c2d45		48899c24c8020000	MOVQ BX, 0x2c8(SP)										
  connection.go:2517		0x6c2d4d		488d942420010000	LEAQ 0x120(SP), DX										
  connection.go:2517		0x6c2d55		440f113a		MOVUPS X15, 0(DX)										
  connection.go:2517		0x6c2d59		440f117a10		MOVUPS X15, 0x10(DX)										
  connection.go:2517		0x6c2d5e		440f117a20		MOVUPS X15, 0x20(DX)										
  connection.go:2518		0x6c2d63		4883787002		CMPQ 0x70(AX), $0x2										
  connection.go:2518		0x6c2d68		0f8501050000		JNE 0x6c326f											
  connection.go:2518		0x6c2d6e		80b83b03000000		CMPB 0x33b(AX), $0x0										
  connection.go:2518		0x6c2d75		0f84f4040000		JE 0x6c326f											
  type.go:58			0x6c2d7b		488b90e0000000		MOVQ 0xe0(AX), DX										
  connection.go:2519		0x6c2d82		4885d2			TESTQ DX, DX											
  connection.go:2519		0x6c2d85		0f84e4040000		JE 0x6c326f											
  connection.go:2520		0x6c2d8b		4889d0			MOVQ DX, AX											
  connection.go:2520		0x6c2d8e		e86d7e0100		CALL github.com/quic-go/quic-go.(*pathManagerOutgoing).NextPathToProbe(SB)			
  connection.go:2520		0x6c2d93		488d9424c3000000	LEAQ 0xc3(SP), DX										
  connection.go:2520		0x6c2d9b		4989e1			MOVQ SP, R9											
  connection.go:2520		0x6c2d9e		450f1031		MOVUPS 0(R9), X14										
  connection.go:2520		0x6c2da2		440f1132		MOVUPS X14, 0(DX)										
  connection.go:2520		0x6c2da6		450f107105		MOVUPS 0x5(R9), X14										
  connection.go:2520		0x6c2dab		440f117205		MOVUPS X14, 0x5(DX)										
  connection.go:2520		0x6c2db0		4c8d9424ae000000	LEAQ 0xae(SP), R10										
  connection.go:2520		0x6c2db8		440f1032		MOVUPS 0(DX), X14										
  connection.go:2520		0x6c2dbc		450f1132		MOVUPS X14, 0(R10)										
  connection.go:2520		0x6c2dc0		440f107205		MOVUPS 0x5(DX), X14										
  connection.go:2520		0x6c2dc5		450f117205		MOVUPS X14, 0x5(R10)										
  connection.go:2520		0x6c2dca		4584c0			TESTL R8, R8											
  connection.go:2521		0x6c2dcd		7516			JNE 0x6c2de5											
  connection.go:2541		0x6c2dcf		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection.go:2541		0x6c2dd7		488b9c24c8020000	MOVQ 0x2c8(SP), BX										
  connection.go:2541		0x6c2ddf		90			NOPL												
  connection.go:2521		0x6c2de0		e98a040000		JMP 0x6c326f											
  connection.go:2520		0x6c2de5		48898424f8000000	MOVQ AX, 0xf8(SP)										
  connection.go:2520		0x6c2ded		4889b42450010000	MOVQ SI, 0x150(SP)										
  connection.go:2520		0x6c2df5		4889bc24a8020000	MOVQ DI, 0x2a8(SP)										
  connection.go:2520		0x6c2dfd		48898c24f0000000	MOVQ CX, 0xf0(SP)										
  connection.go:2520		0x6c2e05		48899c24a0020000	MOVQ BX, 0x2a0(SP)										
  connection.go:2522		0x6c2e0d		488d942438020000	LEAQ 0x238(SP), DX										
  connection.go:2522		0x6c2e15		440f113a		MOVUPS X15, 0(DX)										
  connection.go:2522		0x6c2e19		440f117a10		MOVUPS X15, 0x10(DX)										
  connection.go:2522		0x6c2e1e		440f117a20		MOVUPS X15, 0x20(DX)										
  connection.go:2522		0x6c2e23		440f117a30		MOVUPS X15, 0x30(DX)										
  connection.go:2522		0x6c2e28		440f117a40		MOVUPS X15, 0x40(DX)										
  connection.go:2522		0x6c2e2d		440f117a50		MOVUPS X15, 0x50(DX)										
  connection.go:2522		0x6c2e32		440f117a58		MOVUPS X15, 0x58(DX)										
  connection.go:2522		0x6c2e37		b820000000		MOVL $0x20, AX											
  connection.go:2522		0x6c2e3c		488d1d65513b00		LEAQ 0x3b5165(IP), BX										
  connection.go:2522		0x6c2e43		b901000000		MOVL $0x1, CX											
  connection.go:2522		0x6c2e48		e8b305d6ff		CALL runtime.mallocgcSmallScanNoHeaderSC4(SB)							
  connection.go:2522		0x6c2e4d		488b9424f8000000	MOVQ 0xf8(SP), DX										
  connection.go:2522		0x6c2e55		488910			MOVQ DX, 0(AX)											
  connection.go:2522		0x6c2e58		488b9424f0000000	MOVQ 0xf0(SP), DX										
  connection.go:2522		0x6c2e60		48895010		MOVQ DX, 0x10(AX)										
  connection.go:2522		0x6c2e64		833dc57d480000		CMPL runtime.writeBarrier(SB), $0x0								
  connection.go:2522		0x6c2e6b		7513			JNE 0x6c2e80											
  connection.go:2522		0x6c2e6d		488b9424a0020000	MOVQ 0x2a0(SP), DX										
  connection.go:2522		0x6c2e75		4c8b8424a8020000	MOVQ 0x2a8(SP), R8										
  connection.go:2522		0x6c2e7d		eb1d			JMP 0x6c2e9c											
  connection.go:2522		0x6c2e7f		90			NOPL												
  connection.go:2522		0x6c2e80		e8dbb9dcff		CALL runtime.gcWriteBarrier2(SB)								
  connection.go:2522		0x6c2e85		488b9424a0020000	MOVQ 0x2a0(SP), DX										
  connection.go:2522		0x6c2e8d		498913			MOVQ DX, 0(R11)											
  connection.go:2522		0x6c2e90		4c8b8424a8020000	MOVQ 0x2a8(SP), R8										
  connection.go:2522		0x6c2e98		4d894308		MOVQ R8, 0x8(R11)										
  connection.go:2522		0x6c2e9c		48895008		MOVQ DX, 0x8(AX)										
  connection.go:2522		0x6c2ea0		4c894018		MOVQ R8, 0x18(AX)										
  connection.go:2522		0x6c2ea4		488b9424c0020000	MOVQ 0x2c0(SP), DX										
  connection.go:2522		0x6c2eac		4c8b8248020000		MOVQ 0x248(DX), R8										
  connection.go:2522		0x6c2eb3		4c8b8a50020000		MOVQ 0x250(DX), R9										
  connection.go:2522		0x6c2eba		4d8b4050		MOVQ 0x50(R8), R8										
  connection.go:2522		0x6c2ebe		8b7278			MOVL 0x78(DX), SI										
  connection.go:2522		0x6c2ec1		4889e2			MOVQ SP, DX											
  connection.go:2522		0x6c2ec4		4c8d9424ae000000	LEAQ 0xae(SP), R10										
  connection.go:2522		0x6c2ecc		450f1032		MOVUPS 0(R10), X14										
  connection.go:2522		0x6c2ed0		440f1132		MOVUPS X14, 0(DX)										
  connection.go:2522		0x6c2ed4		450f107205		MOVUPS 0x5(R10), X14										
  connection.go:2522		0x6c2ed9		440f117205		MOVUPS X14, 0x5(DX)										
  connection.go:2522		0x6c2ede		4889c3			MOVQ AX, BX											
  connection.go:2522		0x6c2ee1		b901000000		MOVL $0x1, CX											
  connection.go:2522		0x6c2ee6		89cf			MOVL CX, DI											
  connection.go:2522		0x6c2ee8		4c89c8			MOVQ R9, AX											
  connection.go:2522		0x6c2eeb		41ffd0			CALL R8												
  connection.go:2522		0x6c2eee		488d942438020000	LEAQ 0x238(SP), DX										
  connection.go:2522		0x6c2ef6		4c8d442418		LEAQ 0x18(SP), R8										
  connection.go:2522		0x6c2efb		450f1030		MOVUPS 0(R8), X14										
  connection.go:2522		0x6c2eff		440f1132		MOVUPS X14, 0(DX)										
  connection.go:2522		0x6c2f03		450f107010		MOVUPS 0x10(R8), X14										
  connection.go:2522		0x6c2f08		440f117210		MOVUPS X14, 0x10(DX)										
  connection.go:2522		0x6c2f0d		450f107020		MOVUPS 0x20(R8), X14										
  connection.go:2522		0x6c2f12		440f117220		MOVUPS X14, 0x20(DX)										
  connection.go:2522		0x6c2f17		450f107030		MOVUPS 0x30(R8), X14										
  connection.go:2522		0x6c2f1c		440f117230		MOVUPS X14, 0x30(DX)										
  connection.go:2522		0x6c2f21		450f107040		MOVUPS 0x40(R8), X14										
  connection.go:2522		0x6c2f26		440f117240		MOVUPS X14, 0x40(DX)										
  connection.go:2522		0x6c2f2b		450f107050		MOVUPS 0x50(R8), X14										
  connection.go:2522		0x6c2f30		440f117250		MOVUPS X14, 0x50(DX)										
  connection.go:2522		0x6c2f35		450f107058		MOVUPS 0x58(R8), X14										
  connection.go:2522		0x6c2f3a		440f117258		MOVUPS X14, 0x58(DX)										
  connection.go:2522		0x6c2f3f		4c8d8424b8010000	LEAQ 0x1b8(SP), R8										
  connection.go:2522		0x6c2f47		440f1032		MOVUPS 0(DX), X14										
  connection.go:2522		0x6c2f4b		450f1130		MOVUPS X14, 0(R8)										
  connection.go:2522		0x6c2f4f		440f107210		MOVUPS 0x10(DX), X14										
  connection.go:2522		0x6c2f54		450f117010		MOVUPS X14, 0x10(R8)										
  connection.go:2522		0x6c2f59		440f107220		MOVUPS 0x20(DX), X14										
  connection.go:2522		0x6c2f5e		450f117020		MOVUPS X14, 0x20(R8)										
  connection.go:2522		0x6c2f63		440f107230		MOVUPS 0x30(DX), X14										
  connection.go:2522		0x6c2f68		450f117030		MOVUPS X14, 0x30(R8)										
  connection.go:2522		0x6c2f6d		440f107240		MOVUPS 0x40(DX), X14										
  connection.go:2522		0x6c2f72		450f117040		MOVUPS X14, 0x40(R8)										
  connection.go:2522		0x6c2f77		440f107250		MOVUPS 0x50(DX), X14										
  connection.go:2522		0x6c2f7c		450f117050		MOVUPS X14, 0x50(R8)										
  connection.go:2522		0x6c2f81		440f107258		MOVUPS 0x58(DX), X14										
  connection.go:2522		0x6c2f86		450f117058		MOVUPS X14, 0x58(R8)										
  connection.go:2523		0x6c2f8b		4885db			TESTQ BX, BX											
  connection.go:2523		0x6c2f8e		0f8544020000		JNE 0x6c31d8											
  connection.go:2522		0x6c2f94		4889842430020000	MOVQ AX, 0x230(SP)										
  connection.go:2863		0x6c2f9c		488b8c24c0020000	MOVQ 0x2c0(SP), CX										
  connection.go:2863		0x6c2fa4		488b9188000000		MOVQ 0x88(CX), DX										
  connection.go:2863		0x6c2fab		488b8190000000		MOVQ 0x90(CX), AX										
  connection.go:2863		0x6c2fb2		488b4a28		MOVQ 0x28(DX), CX										
  connection.go:2863		0x6c2fb6		ffd1			CALL CX												
  connection.go:2863		0x6c2fb8		48898424d8000000	MOVQ AX, 0xd8(SP)										
  connection.go:2863		0x6c2fc0		48899c2418010000	MOVQ BX, 0x118(SP)										
  connection.go:2526		0x6c2fc8		b810000000		MOVL $0x10, AX											
  connection.go:2526		0x6c2fcd		488d1d3c513b00		LEAQ 0x3b513c(IP), BX										
  connection.go:2526		0x6c2fd4		b901000000		MOVL $0x1, CX											
  connection.go:2526		0x6c2fd9		e8c2fcd5ff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  connection.go:2526		0x6c2fde		488b8c24d8000000	MOVQ 0xd8(SP), CX										
  connection.go:2526		0x6c2fe6		4885c9			TESTQ CX, CX											
  connection.go:2526		0x6c2fe9		7406			JE 0x6c2ff1											
  connection.go:2526		0x6c2feb		488b5108		MOVQ 0x8(CX), DX										
  connection.go:2526		0x6c2fef		eb03			JMP 0x6c2ff4											
  connection.go:2526		0x6c2ff1		4889ca			MOVQ CX, DX											
  connection.go:2526		0x6c2ff4		488910			MOVQ DX, 0(AX)											
  connection.go:2526		0x6c2ff7		833d327c480000		CMPL runtime.writeBarrier(SB), $0x0								
  connection.go:2526		0x6c2ffe		6690			NOPW												
  connection.go:2526		0x6c3000		750a			JNE 0x6c300c											
  connection.go:2526		0x6c3002		488b942418010000	MOVQ 0x118(SP), DX										
  connection.go:2526		0x6c300a		eb10			JMP 0x6c301c											
  connection.go:2526		0x6c300c		e82fb8dcff		CALL runtime.gcWriteBarrier1(SB)								
  connection.go:2526		0x6c3011		488b942418010000	MOVQ 0x118(SP), DX										
  connection.go:2526		0x6c3019		498913			MOVQ DX, 0(R11)											
  connection.go:2526		0x6c301c		48895008		MOVQ DX, 0x8(AX)										
  connection.go:2526		0x6c3020		488b9424c0020000	MOVQ 0x2c0(SP), DX										
  connection.go:2526		0x6c3028		4c8b8ab0040000		MOVQ 0x4b0(DX), R9										
  connection.go:2526		0x6c302f		488b92b8040000		MOVQ 0x4b8(DX), DX										
  connection.go:2526		0x6c3036		4d8b4920		MOVQ 0x20(R9), R9										
  connection.go:2526		0x6c303a		488d1dc1e90b00		LEAQ 0xbe9c1(IP), BX										
  connection.go:2526		0x6c3041		b921000000		MOVL $0x21, CX											
  connection.go:2526		0x6c3046		4889c7			MOVQ AX, DI											
  connection.go:2526		0x6c3049		be01000000		MOVL $0x1, SI											
  connection.go:2526		0x6c304e		4189f0			MOVL SI, R8											
  connection.go:2526		0x6c3051		4889d0			MOVQ DX, AX											
  connection.go:2526		0x6c3054		41ffd1			CALL R9												
  buffer_pool.go:54		0x6c3057		488b942430020000	MOVQ 0x230(SP), DX										
  buffer_pool.go:54		0x6c305f		488b4a08		MOVQ 0x8(DX), CX										
  connection.go:2527		0x6c3063		90			NOPL												
  connection.go:2527		0x6c3064		90			NOPL												
  connection_logging.go:112	0x6c3065		4889e2			MOVQ SP, DX											
  connection_logging.go:112	0x6c3068		4c8d8c24b8010000	LEAQ 0x1b8(SP), R9										
  connection_logging.go:112	0x6c3070		450f1031		MOVUPS 0(R9), X14										
  connection_logging.go:112	0x6c3074		440f1132		MOVUPS X14, 0(DX)										
  connection_logging.go:112	0x6c3078		450f107110		MOVUPS 0x10(R9), X14										
  connection_logging.go:112	0x6c307d		440f117210		MOVUPS X14, 0x10(DX)										
  connection_logging.go:112	0x6c3082		450f107120		MOVUPS 0x20(R9), X14										
  connection_logging.go:112	0x6c3087		440f117220		MOVUPS X14, 0x20(DX)										
  connection_logging.go:112	0x6c308c		450f107130		MOVUPS 0x30(R9), X14										
  connection_logging.go:112	0x6c3091		440f117230		MOVUPS X14, 0x30(DX)										
  connection_logging.go:112	0x6c3096		450f107140		MOVUPS 0x40(R9), X14										
  connection_logging.go:112	0x6c309b		440f117240		MOVUPS X14, 0x40(DX)										
  connection_logging.go:112	0x6c30a0		450f107150		MOVUPS 0x50(R9), X14										
  connection_logging.go:112	0x6c30a5		440f117250		MOVUPS X14, 0x50(DX)										
  connection_logging.go:112	0x6c30aa		450f107158		MOVUPS 0x58(R9), X14										
  connection_logging.go:112	0x6c30af		440f117258		MOVUPS X14, 0x58(DX)										
  connection_logging.go:112	0x6c30b4		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection_logging.go:112	0x6c30bc		bb01000000		MOVL $0x1, BX											
  connection_logging.go:112	0x6c30c1		31ff			XORL DI, DI											
  connection_logging.go:112	0x6c30c3		31f6			XORL SI, SI											
  connection_logging.go:112	0x6c30c5		e8d6240000		CALL github.com/quic-go/quic-go.(*Conn).logShortHeaderPacketWithDatagramPayloadChecksum(SB)	
  connection.go:2528		0x6c30ca		90			NOPL												
  connection.go:2631		0x6c30cb		4889e2			MOVQ SP, DX											
  connection.go:2631		0x6c30ce		4c8d8c24b8010000	LEAQ 0x1b8(SP), R9										
  connection.go:2631		0x6c30d6		450f1031		MOVUPS 0(R9), X14										
  connection.go:2631		0x6c30da		440f1132		MOVUPS X14, 0(DX)										
  connection.go:2631		0x6c30de		450f107110		MOVUPS 0x10(R9), X14										
  connection.go:2631		0x6c30e3		440f117210		MOVUPS X14, 0x10(DX)										
  connection.go:2631		0x6c30e8		450f107120		MOVUPS 0x20(R9), X14										
  connection.go:2631		0x6c30ed		440f117220		MOVUPS X14, 0x20(DX)										
  connection.go:2631		0x6c30f2		450f107130		MOVUPS 0x30(R9), X14										
  connection.go:2631		0x6c30f7		440f117230		MOVUPS X14, 0x30(DX)										
  connection.go:2631		0x6c30fc		450f107140		MOVUPS 0x40(R9), X14										
  connection.go:2631		0x6c3101		440f117240		MOVUPS X14, 0x40(DX)										
  connection.go:2631		0x6c3106		450f107150		MOVUPS 0x50(R9), X14										
  connection.go:2631		0x6c310b		440f117250		MOVUPS X14, 0x50(DX)										
  connection.go:2631		0x6c3110		450f107158		MOVUPS 0x58(R9), X14										
  connection.go:2631		0x6c3115		440f117258		MOVUPS X14, 0x58(DX)										
  connection.go:2631		0x6c311a		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection.go:2631		0x6c3122		bb01000000		MOVL $0x1, BX											
  connection.go:2631		0x6c3127		488b8c24c8020000	MOVQ 0x2c8(SP), CX										
  connection.go:2631		0x6c312f		e8acc20000		CALL github.com/quic-go/quic-go.(*packetEmission).registerPacket(SB)				
  connection.go:2529		0x6c3134		488b9424c0020000	MOVQ 0x2c0(SP), DX										
  connection.go:2529		0x6c313c		4c8b8a88000000		MOVQ 0x88(DX), R9										
  connection.go:2529		0x6c3143		488b8290000000		MOVQ 0x90(DX), AX										
  connection.go:2529		0x6c314a		498b5130		MOVQ 0x30(R9), DX										
  connection.go:2529		0x6c314e		ffd2			CALL DX												
  connection.go:2529		0x6c3150		488b942430020000	MOVQ 0x230(SP), DX										
  connection.go:2529		0x6c3158		4c8b0a			MOVQ 0(DX), R9											
  connection.go:2529		0x6c315b		488b4a08		MOVQ 0x8(DX), CX										
  connection.go:2529		0x6c315f		488b7a10		MOVQ 0x10(DX), DI										
  connection.go:2529		0x6c3163		4889c6			MOVQ AX, SI											
  connection.go:2529		0x6c3166		4989d8			MOVQ BX, R8											
  connection.go:2529		0x6c3169		488b842450010000	MOVQ 0x150(SP), AX										
  connection.go:2529		0x6c3171		4c89cb			MOVQ R9, BX											
  connection.go:2529		0x6c3174		e8a7c30200		CALL github.com/quic-go/quic-go.(*Transport).WriteTo(SB)					
  connection.go:2744		0x6c3179		488b9424c0020000	MOVQ 0x2c0(SP), DX										
  connection.go:2744		0x6c3181		488b82a0020000		MOVQ 0x2a0(DX), AX										
  connection.go:2531		0x6c3188		90			NOPL												
  connection.go:2744		0x6c3189		488d9c24c3000000	LEAQ 0xc3(SP), BX										
  connection.go:2744		0x6c3191		e8ca74d5ff		CALL runtime.selectnbsend(SB)									
  connection.go:2532		0x6c3196		488d942420010000	LEAQ 0x120(SP), DX										
  connection.go:2532		0x6c319e		440f113a		MOVUPS X15, 0(DX)										
  connection.go:2532		0x6c31a2		440f117a10		MOVUPS X15, 0x10(DX)										
  connection.go:2532		0x6c31a7		440f117a20		MOVUPS X15, 0x20(DX)										
  connection.go:2532		0x6c31ac		488b9c2428010000	MOVQ 0x128(SP), BX										
  connection.go:2532		0x6c31b4		4c8b842448010000	MOVQ 0x148(SP), R8										
  connection.go:2532		0x6c31bc		c684243001000007	MOVB $0x7, 0x130(SP)										
  connection.go:2532		0x6c31c4		31c0			XORL AX, AX											
  connection.go:2532		0x6c31c6		b907000000		MOVL $0x7, CX											
  connection.go:2532		0x6c31cb		31ff			XORL DI, DI											
  connection.go:2532		0x6c31cd		31f6			XORL SI, SI											
  connection.go:2532		0x6c31cf		4881c4b0020000		ADDQ $0x2b0, SP											
  connection.go:2532		0x6c31d6		5d			POPQ BP												
  connection.go:2532		0x6c31d7		c3			RET												
  connection.go:2524		0x6c31d8		488d942438020000	LEAQ 0x238(SP), DX										
  connection.go:2524		0x6c31e0		440f113a		MOVUPS X15, 0(DX)										
  connection.go:2524		0x6c31e4		440f117a10		MOVUPS X15, 0x10(DX)										
  connection.go:2524		0x6c31e9		440f117a20		MOVUPS X15, 0x20(DX)										
  packet_emission.go:63		0x6c31ee		c684244802000007	MOVB $0x7, 0x248(SP)										
  packet_emission.go:63		0x6c31f6		48899c2458020000	MOVQ BX, 0x258(SP)										
  packet_emission.go:63		0x6c31fe		48898c2460020000	MOVQ CX, 0x260(SP)										
  connection.go:2524		0x6c3206		0fb6842438020000	MOVZX 0x238(SP), AX										
  connection.go:2524		0x6c320e		488b942440020000	MOVQ 0x240(SP), DX										
  connection.go:2524		0x6c3216		440fb68c2448020000	MOVZX 0x248(SP), R9										
  connection.go:2524		0x6c321f		488bbc2450020000	MOVQ 0x250(SP), DI										
  connection.go:2524		0x6c3227		488bb42458020000	MOVQ 0x258(SP), SI										
  connection.go:2524		0x6c322f		4c8d942420010000	LEAQ 0x120(SP), R10										
  connection.go:2524		0x6c3237		450f113a		MOVUPS X15, 0(R10)										
  connection.go:2524		0x6c323b		450f117a10		MOVUPS X15, 0x10(R10)										
  connection.go:2524		0x6c3240		450f117a20		MOVUPS X15, 0x20(R10)										
  connection.go:2524		0x6c3245		c684243001000007	MOVB $0x7, 0x130(SP)										
  connection.go:2524		0x6c324d		48899c2440010000	MOVQ BX, 0x140(SP)										
  connection.go:2524		0x6c3255		48898c2448010000	MOVQ CX, 0x148(SP)										
  connection.go:2524		0x6c325d		4889d3			MOVQ DX, BX											
  connection.go:2524		0x6c3260		4989c8			MOVQ CX, R8											
  connection.go:2524		0x6c3263		4489c9			MOVL R9, CX											
  connection.go:2524		0x6c3266		4881c4b0020000		ADDQ $0x2b0, SP											
  connection.go:2524		0x6c326d		5d			POPQ BP												
  connection.go:2524		0x6c326e		c3			RET												
  connection.go:2541		0x6c326f		80b83b03000000		CMPB 0x33b(AX), $0x0										
  connection.go:2541		0x6c3276		742d			JE 0x6c32a5											
  connection.go:2541		0x6c3278		488b9058020000		MOVQ 0x258(AX), DX										
  connection.go:2541		0x6c327f		90			NOPL												
  connection.go:2541		0x6c3280		4885d2			TESTQ DX, DX											
  connection.go:2541		0x6c3283		7504			JNE 0x6c3289											
  connection.go:2541		0x6c3285		31c9			XORL CX, CX											
  connection.go:2541		0x6c3287		eb1e			JMP 0x6c32a7											
  connection.go:2541		0x6c3289		4889d0			MOVQ DX, AX											
  connection.go:2541		0x6c328c		e86fb10000		CALL github.com/quic-go/quic-go.(*mtuFinder).ShouldSendProbe(SB)				
  connection.go:2556		0x6c3291		488b9c24c8020000	MOVQ 0x2c8(SP), BX										
  connection.go:2541		0x6c3299		89c1			MOVL AX, CX											
  connection.go:2542		0x6c329b		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection.go:2541		0x6c32a3		eb02			JMP 0x6c32a7											
  connection.go:2541		0x6c32a5		31c9			XORL CX, CX											
  connection.go:2541		0x6c32a7		84c9			TESTL CL, CL											
  connection.go:2541		0x6c32a9		744c			JE 0x6c32f7											
  connection.go:2542		0x6c32ab		488b9058020000		MOVQ 0x258(AX), DX										
  mtu_discoverer.go:154		0x6c32b2		807a3800		CMPB 0x38(DX), $0x0										
  mtu_discoverer.go:154		0x6c32b6		7525			JNE 0x6c32dd											
  mtu_discoverer.go:130		0x6c32b8		488d7220		LEAQ 0x20(DX), SI										
  mtu_discoverer.go:130		0x6c32bc		488dbc2400010000	LEAQ 0x100(SP), DI										
  mtu_discoverer.go:130		0x6c32c4		440f1036		MOVUPS 0(SI), X14										
  mtu_discoverer.go:130		0x6c32c8		440f1137		MOVUPS X14, 0(DI)										
  mtu_discoverer.go:130		0x6c32cc		440f107608		MOVUPS 0x8(SI), X14										
  mtu_discoverer.go:130		0x6c32d1		440f117708		MOVUPS X14, 0x8(DI)										
  mtu_discoverer.go:130		0x6c32d6		31f6			XORL SI, SI											
  mtu_discoverer.go:130		0x6c32d8		e9b9060000		JMP 0x6c3996											
  mtu_discoverer.go:155		0x6c32dd		488b7218		MOVQ 0x18(DX), SI										
  mtu_discoverer.go:155		0x6c32e1		48037220		ADDQ 0x20(DX), SI										
  mtu_discoverer.go:155		0x6c32e5		4889f7			MOVQ SI, DI											
  mtu_discoverer.go:155		0x6c32e8		48c1ee3f		SHRQ $0x3f, SI											
  mtu_discoverer.go:155		0x6c32ec		4801fe			ADDQ DI, SI											
  mtu_discoverer.go:155		0x6c32ef		48d1fe			SARQ $0x1, SI											
  mtu_discoverer.go:155		0x6c32f2		e9f7020000		JMP 0x6c35ee											
  connection.go:2556		0x6c32f7		488b8008020000		MOVQ 0x208(AX), AX										
  connection.go:2556		0x6c32fe		6690			NOPW												
  connection.go:2556		0x6c3300		e8db630000		CALL github.com/quic-go/quic-go.(*connectionFlowController).GetWindowUpdate(SB)			
  connection.go:2556		0x6c3305		4885c0			TESTQ AX, AX											
  connection.go:2556		0x6c3308		7e4a			JLE 0x6c3354											
  connection.go:2556		0x6c330a		48898424e8000000	MOVQ AX, 0xe8(SP)										
  connection.go:2557		0x6c3312		b808000000		MOVL $0x8, AX											
  connection.go:2557		0x6c3317		488d1d922e3f00		LEAQ 0x3f2e92(IP), BX										
  connection.go:2557		0x6c331e		b901000000		MOVL $0x1, CX											
  connection.go:2557		0x6c3323		e8f80fd6ff		CALL runtime.mallocgcTinySC2(SB)								
  connection.go:2557		0x6c3328		488b9424e8000000	MOVQ 0xe8(SP), DX										
  connection.go:2557		0x6c3330		488910			MOVQ DX, 0(AX)											
  connection.go:2557		0x6c3333		488b9424c0020000	MOVQ 0x2c0(SP), DX										
  connection.go:2557		0x6c333b		488b9200020000		MOVQ 0x200(DX), DX										
  connection.go:2557		0x6c3342		488d1d6fff4200		LEAQ 0x42ff6f(IP), BX										
  connection.go:2557		0x6c3349		4889c1			MOVQ AX, CX											
  connection.go:2557		0x6c334c		4889d0			MOVQ DX, AX											
  connection.go:2557		0x6c334f		e86c7f0000		CALL github.com/quic-go/quic-go.(*framer).QueueControlFrame(SB)					
  connection.go:2559		0x6c3354		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection.go:2559		0x6c335c		488b9038010000		MOVQ 0x138(AX), DX										
  crypto_stream_manager.go:57	0x6c3363		488b5210		MOVQ 0x10(DX), DX										
  crypto_stream_manager.go:57	0x6c3367		48837a3800		CMPQ 0x38(DX), $0x0										
  crypto_stream_manager.go:57	0x6c336c		7504			JNE 0x6c3372											
  crypto_stream_manager.go:57	0x6c336e		31c9			XORL CX, CX											
  connection.go:2559		0x6c3370		eb18			JMP 0x6c338a											
  crypto_stream_manager.go:60	0x6c3372		4889d0			MOVQ DX, AX											
  crypto_stream_manager.go:60	0x6c3375		bbe8030000		MOVL $0x3e8, BX											
  crypto_stream_manager.go:60	0x6c337a		e821400000		CALL github.com/quic-go/quic-go.(*baseCryptoStream).PopCryptoFrame(SB)				
  connection.go:2559		0x6c337f		4889c1			MOVQ AX, CX											
  connection.go:2563		0x6c3382		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection.go:2559		0x6c338a		4885c9			TESTQ CX, CX											
  connection.go:2559		0x6c338d		743e			JE 0x6c33cd											
  connection.go:2785		0x6c338f		488b8000020000		MOVQ 0x200(AX), AX										
  connection.go:2560		0x6c3396		90			NOPL												
  connection.go:2785		0x6c3397		488d1deafc4200		LEAQ 0x42fcea(IP), BX										
  connection.go:2785		0x6c339e		6690			NOPW												
  connection.go:2785		0x6c33a0		e81b7f0000		CALL github.com/quic-go/quic-go.(*framer).QueueControlFrame(SB)					
  connection.go:2744		0x6c33a5		488b9424c0020000	MOVQ 0x2c0(SP), DX										
  connection.go:2744		0x6c33ad		488b82a0020000		MOVQ 0x2a0(DX), AX										
  connection.go:2786		0x6c33b4		90			NOPL												
  connection.go:2744		0x6c33b5		488d9c24c3000000	LEAQ 0xc3(SP), BX										
  connection.go:2744		0x6c33bd		0f1f00			NOPL 0(AX)											
  connection.go:2744		0x6c33c0		e89b72d5ff		CALL runtime.selectnbsend(SB)									
  connection.go:2563		0x6c33c5		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection.go:2563		0x6c33cd		80b83b03000000		CMPB 0x33b(AX), $0x0										
  connection.go:2563		0x6c33d4		0f8421010000		JE 0x6c34fb											
  connection.go:2571		0x6c33da		488b8888000000		MOVQ 0x88(AX), CX										
  connection.go:2571		0x6c33e1		488b8090000000		MOVQ 0x90(AX), AX										
  connection.go:2571		0x6c33e8		488b4948		MOVQ 0x48(CX), CX										
  connection.go:2571		0x6c33ec		ffd1			CALL CX												
  connection.go:2571		0x6c33ee		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection.go:2571		0x6c33f6		89d9			MOVL BX, CX											
  connection.go:2571		0x6c33f8		488b9c24c8020000	MOVQ 0x2c8(SP), BX										
  connection.go:2571		0x6c3400		e89bb30000		CALL github.com/quic-go/quic-go.(*packetEmission).advance(SB)					
  connection.go:2571		0x6c3405		88842438020000		MOVB AL, 0x238(SP)										
  connection.go:2571		0x6c340c		48899c2440020000	MOVQ BX, 0x240(SP)										
  connection.go:2571		0x6c3414		888c2448020000		MOVB CL, 0x248(SP)										
  connection.go:2571		0x6c341b		4889bc2450020000	MOVQ DI, 0x250(SP)										
  connection.go:2571		0x6c3423		4889b42458020000	MOVQ SI, 0x258(SP)										
  connection.go:2571		0x6c342b		4c89842460020000	MOVQ R8, 0x260(SP)										
  connection.go:2572		0x6c3433		0fb68c2448020000	MOVZX 0x248(SP), CX										
  connection.go:2574		0x6c343b		488b942450020000	MOVQ 0x250(SP), DX										
  connection.go:2571		0x6c3443		488d9c2458010000	LEAQ 0x158(SP), BX										
  connection.go:2571		0x6c344b		488db42438020000	LEAQ 0x238(SP), SI										
  connection.go:2571		0x6c3453		440f1036		MOVUPS 0(SI), X14										
  connection.go:2571		0x6c3457		440f1133		MOVUPS X14, 0(BX)										
  connection.go:2571		0x6c345b		440f107610		MOVUPS 0x10(SI), X14										
  connection.go:2571		0x6c3460		440f117310		MOVUPS X14, 0x10(BX)										
  connection.go:2571		0x6c3465		440f107620		MOVUPS 0x20(SI), X14										
  connection.go:2571		0x6c346a		440f117320		MOVUPS X14, 0x20(BX)										
  connection.go:2572		0x6c346f		80f904			CMPL CL, $0x4											
  connection.go:2573		0x6c3472		7716			JA 0x6c348a											
  connection.go:2575		0x6c3474		80f902			CMPL CL, $0x2											
  connection.go:2575		0x6c3477		7622			JBE 0x6c349b											
  connection.go:2574		0x6c3479		4c8b8c24c0020000	MOVQ 0x2c0(SP), R9										
  connection.go:2574		0x6c3481		49899160030000		MOVQ DX, 0x360(R9)										
  connection.go:2574		0x6c3488		eb11			JMP 0x6c349b											
  connection.go:2575		0x6c348a		80f906			CMPL CL, $0x6											
  connection.go:2575		0x6c348d		760c			JBE 0x6c349b											
  connection.go:2578		0x6c348f		8d51f9			LEAL -0x7(CX), DX										
  connection.go:2578		0x6c3492		80fa02			CMPL DL, $0x2											
  connection.go:2578		0x6c3495		0f8640010000		JBE 0x6c35db											
  connection.go:2581		0x6c349b		0fb6842458010000	MOVZX 0x158(SP), AX										
  connection.go:2581		0x6c34a3		488b942460010000	MOVQ 0x160(SP), DX										
  connection.go:2581		0x6c34ab		0fb68c2468010000	MOVZX 0x168(SP), CX										
  connection.go:2581		0x6c34b3		488bbc2470010000	MOVQ 0x170(SP), DI										
  connection.go:2581		0x6c34bb		488bb42478010000	MOVQ 0x178(SP), SI										
  connection.go:2581		0x6c34c3		4c8b842480010000	MOVQ 0x180(SP), R8										
  connection.go:2581		0x6c34cb		4c8d8c2420010000	LEAQ 0x120(SP), R9										
  connection.go:2581		0x6c34d3		440f1033		MOVUPS 0(BX), X14										
  connection.go:2581		0x6c34d7		450f1131		MOVUPS X14, 0(R9)										
  connection.go:2581		0x6c34db		440f107310		MOVUPS 0x10(BX), X14										
  connection.go:2581		0x6c34e0		450f117110		MOVUPS X14, 0x10(R9)										
  connection.go:2581		0x6c34e5		440f107320		MOVUPS 0x20(BX), X14										
  connection.go:2581		0x6c34ea		450f117120		MOVUPS X14, 0x20(R9)										
  connection.go:2581		0x6c34ef		4889d3			MOVQ DX, BX											
  connection.go:2581		0x6c34f2		4881c4b0020000		ADDQ $0x2b0, SP											
  connection.go:2581		0x6c34f9		5d			POPQ BP												
  connection.go:2581		0x6c34fa		c3			RET												
  connection.go:2564		0x6c34fb		488b9c24c8020000	MOVQ 0x2c8(SP), BX										
  connection.go:2564		0x6c3503		e878c50000		CALL github.com/quic-go/quic-go.(*packetEmission).coalesced(SB)					
  connection.go:2564		0x6c3508		88842438020000		MOVB AL, 0x238(SP)										
  connection.go:2564		0x6c350f		48899c2440020000	MOVQ BX, 0x240(SP)										
  connection.go:2564		0x6c3517		888c2448020000		MOVB CL, 0x248(SP)										
  connection.go:2564		0x6c351e		4889bc2450020000	MOVQ DI, 0x250(SP)										
  connection.go:2564		0x6c3526		4889b42458020000	MOVQ SI, 0x258(SP)										
  connection.go:2564		0x6c352e		4c89842460020000	MOVQ R8, 0x260(SP)										
  connection.go:2566		0x6c3536		488b8c2450020000	MOVQ 0x250(SP), CX										
  connection.go:2564		0x6c353e		488d942488010000	LEAQ 0x188(SP), DX										
  connection.go:2564		0x6c3546		488db42438020000	LEAQ 0x238(SP), SI										
  connection.go:2564		0x6c354e		440f1036		MOVUPS 0(SI), X14										
  connection.go:2564		0x6c3552		440f1132		MOVUPS X14, 0(DX)										
  connection.go:2564		0x6c3556		440f107610		MOVUPS 0x10(SI), X14										
  connection.go:2564		0x6c355b		440f117210		MOVUPS X14, 0x10(DX)										
  connection.go:2564		0x6c3560		440f107620		MOVUPS 0x20(SI), X14										
  connection.go:2564		0x6c3565		440f117220		MOVUPS X14, 0x20(DX)										
  time.go:52			0x6c356a		4885c9			TESTQ CX, CX											
  connection.go:2565		0x6c356d		740f			JE 0x6c357e											
  connection.go:2566		0x6c356f		4c8b8c24c0020000	MOVQ 0x2c0(SP), R9										
  connection.go:2566		0x6c3577		49898960030000		MOVQ CX, 0x360(R9)										
  connection.go:2568		0x6c357e		0fb6842488010000	MOVZX 0x188(SP), AX										
  connection.go:2568		0x6c3586		488b9c2490010000	MOVQ 0x190(SP), BX										
  connection.go:2568		0x6c358e		0fb68c2498010000	MOVZX 0x198(SP), CX										
  connection.go:2568		0x6c3596		488bbc24a0010000	MOVQ 0x1a0(SP), DI										
  connection.go:2568		0x6c359e		488bb424a8010000	MOVQ 0x1a8(SP), SI										
  connection.go:2568		0x6c35a6		4c8b8424b0010000	MOVQ 0x1b0(SP), R8										
  connection.go:2568		0x6c35ae		4c8d8c2420010000	LEAQ 0x120(SP), R9										
  connection.go:2568		0x6c35b6		440f1032		MOVUPS 0(DX), X14										
  connection.go:2568		0x6c35ba		450f1131		MOVUPS X14, 0(R9)										
  connection.go:2568		0x6c35be		440f107210		MOVUPS 0x10(DX), X14										
  connection.go:2568		0x6c35c3		450f117110		MOVUPS X14, 0x10(R9)										
  connection.go:2568		0x6c35c8		440f107220		MOVUPS 0x20(DX), X14										
  connection.go:2568		0x6c35cd		450f117120		MOVUPS X14, 0x20(R9)										
  connection.go:2568		0x6c35d2		4881c4b0020000		ADDQ $0x2b0, SP											
  connection.go:2568		0x6c35d9		5d			POPQ BP												
  connection.go:2568		0x6c35da		c3			RET												
  connection.go:2579		0x6c35db		488d05c63f3e00		LEAQ 0x3e3fc6(IP), AX										
  connection.go:2579		0x6c35e2		488d1db72a0d00		LEAQ 0xd2ab7(IP), BX										
  connection.go:2579		0x6c35e9		e8d245dcff		CALL runtime.gopanic(SB)									
  connection.go:2542		0x6c35ee		4889942420020000	MOVQ DX, 0x220(SP)										
  mtu_discoverer.go:159		0x6c35f6		4889b424e0000000	MOVQ SI, 0xe0(SP)										
  mtu_discoverer.go:159		0x6c35fe		48891a			MOVQ BX, 0(DX)											
  mtu_discoverer.go:160		0x6c3601		48897210		MOVQ SI, 0x10(DX)										
  mtu_discoverer.go:163		0x6c3605		b810000000		MOVL $0x10, AX											
  mtu_discoverer.go:163		0x6c360a		488d1defd34100		LEAQ 0x41d3ef(IP), BX										
  mtu_discoverer.go:163		0x6c3611		b901000000		MOVL $0x1, CX											
  mtu_discoverer.go:163		0x6c3616		e885f6d5ff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  mtu_discoverer.go:163		0x6c361b		833d0e76480000		CMPL runtime.writeBarrier(SB), $0x0								
  mtu_discoverer.go:163		0x6c3622		750a			JNE 0x6c362e											
  mtu_discoverer.go:163		0x6c3624		488b942420020000	MOVQ 0x220(SP), DX										
  mtu_discoverer.go:163		0x6c362c		eb10			JMP 0x6c363e											
  mtu_discoverer.go:163		0x6c362e		e80db2dcff		CALL runtime.gcWriteBarrier1(SB)								
  mtu_discoverer.go:163		0x6c3633		488b942420020000	MOVQ 0x220(SP), DX										
  mtu_discoverer.go:163		0x6c363b		498913			MOVQ DX, 0(R11)											
  mtu_discoverer.go:163		0x6c363e		488910			MOVQ DX, 0(AX)											
  mtu_discoverer.go:163		0x6c3641		0fb65239		MOVZX 0x39(DX), DX										
  mtu_discoverer.go:163		0x6c3645		885008			MOVB DL, 0x8(AX)										
  connection.go:2543		0x6c3648		488d942438020000	LEAQ 0x238(SP), DX										
  connection.go:2543		0x6c3650		440f113a		MOVUPS X15, 0(DX)										
  connection.go:2543		0x6c3654		440f117a10		MOVUPS X15, 0x10(DX)										
  connection.go:2543		0x6c3659		440f117a20		MOVUPS X15, 0x20(DX)										
  connection.go:2543		0x6c365e		440f117a30		MOVUPS X15, 0x30(DX)										
  connection.go:2543		0x6c3663		440f117a40		MOVUPS X15, 0x40(DX)										
  connection.go:2543		0x6c3668		440f117a50		MOVUPS X15, 0x50(DX)										
  connection.go:2543		0x6c366d		440f117a58		MOVUPS X15, 0x58(DX)										
  connection.go:2543		0x6c3672		488b9424c0020000	MOVQ 0x2c0(SP), DX										
  connection.go:2543		0x6c367a		4c8b9248020000		MOVQ 0x248(DX), R10										
  connection.go:2543		0x6c3681		4c8b9a50020000		MOVQ 0x250(DX), R11										
  connection.go:2543		0x6c3688		4d8b5240		MOVQ 0x40(R10), R10										
  connection.go:2543		0x6c368c		448b4a78		MOVL 0x78(DX), R9										
  connection.go:2543		0x6c3690		488d1de1fa4200		LEAQ 0x42fae1(IP), BX										
  connection.go:2543		0x6c3697		488d0da2704800		LEAQ runtime.zerobase(SB), CX									
  connection.go:2543		0x6c369e		488d3d93fe4200		LEAQ 0x42fe93(IP), DI										
  connection.go:2543		0x6c36a5		4889c6			MOVQ AX, SI											
  connection.go:2543		0x6c36a8		4c8b8424e0000000	MOVQ 0xe0(SP), R8										
  connection.go:2543		0x6c36b0		4c89d8			MOVQ R11, AX											
  connection.go:2543		0x6c36b3		41ffd2			CALL R10											
  connection.go:2543		0x6c36b6		488d942438020000	LEAQ 0x238(SP), DX										
  connection.go:2543		0x6c36be		4989e2			MOVQ SP, R10											
  connection.go:2543		0x6c36c1		450f1032		MOVUPS 0(R10), X14										
  connection.go:2543		0x6c36c5		440f1132		MOVUPS X14, 0(DX)										
  connection.go:2543		0x6c36c9		450f107210		MOVUPS 0x10(R10), X14										
  connection.go:2543		0x6c36ce		440f117210		MOVUPS X14, 0x10(DX)										
  connection.go:2543		0x6c36d3		450f107220		MOVUPS 0x20(R10), X14										
  connection.go:2543		0x6c36d8		440f117220		MOVUPS X14, 0x20(DX)										
  connection.go:2543		0x6c36dd		450f107230		MOVUPS 0x30(R10), X14										
  connection.go:2543		0x6c36e2		440f117230		MOVUPS X14, 0x30(DX)										
  connection.go:2543		0x6c36e7		450f107240		MOVUPS 0x40(R10), X14										
  connection.go:2543		0x6c36ec		440f117240		MOVUPS X14, 0x40(DX)										
  connection.go:2543		0x6c36f1		450f107250		MOVUPS 0x50(R10), X14										
  connection.go:2543		0x6c36f6		440f117250		MOVUPS X14, 0x50(DX)										
  connection.go:2543		0x6c36fb		450f107258		MOVUPS 0x58(R10), X14										
  connection.go:2543		0x6c3700		440f117258		MOVUPS X14, 0x58(DX)										
  connection.go:2543		0x6c3705		4c8d9c24b8010000	LEAQ 0x1b8(SP), R11										
  connection.go:2543		0x6c370d		440f1032		MOVUPS 0(DX), X14										
  connection.go:2543		0x6c3711		450f1133		MOVUPS X14, 0(R11)										
  connection.go:2543		0x6c3715		440f107210		MOVUPS 0x10(DX), X14										
  connection.go:2543		0x6c371a		450f117310		MOVUPS X14, 0x10(R11)										
  connection.go:2543		0x6c371f		440f107220		MOVUPS 0x20(DX), X14										
  connection.go:2543		0x6c3724		450f117320		MOVUPS X14, 0x20(R11)										
  connection.go:2543		0x6c3729		440f107230		MOVUPS 0x30(DX), X14										
  connection.go:2543		0x6c372e		450f117330		MOVUPS X14, 0x30(R11)										
  connection.go:2543		0x6c3733		440f107240		MOVUPS 0x40(DX), X14										
  connection.go:2543		0x6c3738		450f117340		MOVUPS X14, 0x40(R11)										
  connection.go:2543		0x6c373d		440f107250		MOVUPS 0x50(DX), X14										
  connection.go:2543		0x6c3742		450f117350		MOVUPS X14, 0x50(R11)										
  connection.go:2543		0x6c3747		440f107258		MOVUPS 0x58(DX), X14										
  connection.go:2543		0x6c374c		450f117358		MOVUPS X14, 0x58(R11)										
  connection.go:2544		0x6c3751		4885db			TESTQ BX, BX											
  connection.go:2544		0x6c3754		0f8497000000		JE 0x6c37f1											
  connection.go:2545		0x6c375a		488d942438020000	LEAQ 0x238(SP), DX										
  connection.go:2545		0x6c3762		440f113a		MOVUPS X15, 0(DX)										
  connection.go:2545		0x6c3766		440f117a10		MOVUPS X15, 0x10(DX)										
  connection.go:2545		0x6c376b		440f117a20		MOVUPS X15, 0x20(DX)										
  packet_emission.go:63		0x6c3770		c684244802000007	MOVB $0x7, 0x248(SP)										
  packet_emission.go:63		0x6c3778		48899c2458020000	MOVQ BX, 0x258(SP)										
  packet_emission.go:63		0x6c3780		48898c2460020000	MOVQ CX, 0x260(SP)										
  connection.go:2545		0x6c3788		0fb6842438020000	MOVZX 0x238(SP), AX										
  connection.go:2545		0x6c3790		488b942440020000	MOVQ 0x240(SP), DX										
  connection.go:2545		0x6c3798		440fb68c2448020000	MOVZX 0x248(SP), R9										
  connection.go:2545		0x6c37a1		488bbc2450020000	MOVQ 0x250(SP), DI										
  connection.go:2545		0x6c37a9		488bb42458020000	MOVQ 0x258(SP), SI										
  connection.go:2545		0x6c37b1		4c8d9c2420010000	LEAQ 0x120(SP), R11										
  connection.go:2545		0x6c37b9		450f113b		MOVUPS X15, 0(R11)										
  connection.go:2545		0x6c37bd		450f117b10		MOVUPS X15, 0x10(R11)										
  connection.go:2545		0x6c37c2		450f117b20		MOVUPS X15, 0x20(R11)										
  connection.go:2545		0x6c37c7		c684243001000007	MOVB $0x7, 0x130(SP)										
  connection.go:2545		0x6c37cf		48899c2440010000	MOVQ BX, 0x140(SP)										
  connection.go:2545		0x6c37d7		48898c2448010000	MOVQ CX, 0x148(SP)										
  connection.go:2545		0x6c37df		4889d3			MOVQ DX, BX											
  connection.go:2545		0x6c37e2		4989c8			MOVQ CX, R8											
  connection.go:2545		0x6c37e5		4489c9			MOVL R9, CX											
  connection.go:2545		0x6c37e8		4881c4b0020000		ADDQ $0x2b0, SP											
  connection.go:2545		0x6c37ef		5d			POPQ BP												
  connection.go:2545		0x6c37f0		c3			RET												
  connection.go:2543		0x6c37f1		4889842428020000	MOVQ AX, 0x228(SP)										
  connection.go:2547		0x6c37f9		488b8c24c0020000	MOVQ 0x2c0(SP), CX										
  connection.go:2547		0x6c3801		488b9140010000		MOVQ 0x140(CX), DX										
  connection.go:2547		0x6c3808		488b8148010000		MOVQ 0x148(CX), AX										
  connection.go:2547		0x6c380f		488b4a20		MOVQ 0x20(DX), CX										
  connection.go:2547		0x6c3813		bb01000000		MOVL $0x1, BX											
  connection.go:2547		0x6c3818		ffd1			CALL CX												
  connection.go:2547		0x6c381a		888424ad000000		MOVB AL, 0xad(SP)										
  buffer_pool.go:54		0x6c3821		488b8c2428020000	MOVQ 0x228(SP), CX										
  buffer_pool.go:54		0x6c3829		488b4908		MOVQ 0x8(CX), CX										
  connection.go:2548		0x6c382d		90			NOPL												
  connection.go:2548		0x6c382e		90			NOPL												
  connection_logging.go:112	0x6c382f		4889e2			MOVQ SP, DX											
  connection_logging.go:112	0x6c3832		488db424b8010000	LEAQ 0x1b8(SP), SI										
  connection_logging.go:112	0x6c383a		440f1036		MOVUPS 0(SI), X14										
  connection_logging.go:112	0x6c383e		440f1132		MOVUPS X14, 0(DX)										
  connection_logging.go:112	0x6c3842		440f107610		MOVUPS 0x10(SI), X14										
  connection_logging.go:112	0x6c3847		440f117210		MOVUPS X14, 0x10(DX)										
  connection_logging.go:112	0x6c384c		440f107620		MOVUPS 0x20(SI), X14										
  connection_logging.go:112	0x6c3851		440f117220		MOVUPS X14, 0x20(DX)										
  connection_logging.go:112	0x6c3856		440f107630		MOVUPS 0x30(SI), X14										
  connection_logging.go:112	0x6c385b		440f117230		MOVUPS X14, 0x30(DX)										
  connection_logging.go:112	0x6c3860		440f107640		MOVUPS 0x40(SI), X14										
  connection_logging.go:112	0x6c3865		440f117240		MOVUPS X14, 0x40(DX)										
  connection_logging.go:112	0x6c386a		440f107650		MOVUPS 0x50(SI), X14										
  connection_logging.go:112	0x6c386f		440f117250		MOVUPS X14, 0x50(DX)										
  connection_logging.go:112	0x6c3874		440f107658		MOVUPS 0x58(SI), X14										
  connection_logging.go:112	0x6c3879		440f117258		MOVUPS X14, 0x58(DX)										
  connection_logging.go:112	0x6c387e		89c3			MOVL AX, BX											
  connection_logging.go:112	0x6c3880		31ff			XORL DI, DI											
  connection_logging.go:112	0x6c3882		31f6			XORL SI, SI											
  connection_logging.go:112	0x6c3884		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection_logging.go:112	0x6c388c		e80f1d0000		CALL github.com/quic-go/quic-go.(*Conn).logShortHeaderPacketWithDatagramPayloadChecksum(SB)	
  connection.go:2549		0x6c3891		90			NOPL												
  connection.go:2631		0x6c3892		4889e1			MOVQ SP, CX											
  connection.go:2631		0x6c3895		488d9424b8010000	LEAQ 0x1b8(SP), DX										
  connection.go:2631		0x6c389d		440f1032		MOVUPS 0(DX), X14										
  connection.go:2631		0x6c38a1		440f1131		MOVUPS X14, 0(CX)										
  connection.go:2631		0x6c38a5		440f107210		MOVUPS 0x10(DX), X14										
  connection.go:2631		0x6c38aa		440f117110		MOVUPS X14, 0x10(CX)										
  connection.go:2631		0x6c38af		440f107220		MOVUPS 0x20(DX), X14										
  connection.go:2631		0x6c38b4		440f117120		MOVUPS X14, 0x20(CX)										
  connection.go:2631		0x6c38b9		440f107230		MOVUPS 0x30(DX), X14										
  connection.go:2631		0x6c38be		440f117130		MOVUPS X14, 0x30(CX)										
  connection.go:2631		0x6c38c3		440f107240		MOVUPS 0x40(DX), X14										
  connection.go:2631		0x6c38c8		440f117140		MOVUPS X14, 0x40(CX)										
  connection.go:2631		0x6c38cd		440f107250		MOVUPS 0x50(DX), X14										
  connection.go:2631		0x6c38d2		440f117150		MOVUPS X14, 0x50(CX)										
  connection.go:2631		0x6c38d7		440f107258		MOVUPS 0x58(DX), X14										
  connection.go:2631		0x6c38dc		440f117158		MOVUPS X14, 0x58(CX)										
  connection.go:2631		0x6c38e1		488b8424c0020000	MOVQ 0x2c0(SP), AX										
  connection.go:2631		0x6c38e9		0fb69c24ad000000	MOVZX 0xad(SP), BX										
  connection.go:2631		0x6c38f1		488b8c24c8020000	MOVQ 0x2c8(SP), CX										
  connection.go:2631		0x6c38f9		e8e2ba0000		CALL github.com/quic-go/quic-go.(*packetEmission).registerPacket(SB)				
  connection.go:2550		0x6c38fe		488b8c24c0020000	MOVQ 0x2c0(SP), CX										
  connection.go:2550		0x6c3906		488b9198000000		MOVQ 0x98(CX), DX										
  connection.go:2550		0x6c390d		488b81a0000000		MOVQ 0xa0(CX), AX										
  connection.go:2550		0x6c3914		488b4a30		MOVQ 0x30(DX), CX										
  connection.go:2550		0x6c3918		488b9c2428020000	MOVQ 0x228(SP), BX										
  connection.go:2550		0x6c3920		0fb6bc24ad000000	MOVZX 0xad(SP), DI										
  connection.go:2550		0x6c3928		31f6			XORL SI, SI											
  connection.go:2550		0x6c392a		4531c0			XORL R8, R8											
  connection.go:2550		0x6c392d		4889ca			MOVQ CX, DX											
  connection.go:2550		0x6c3930		31c9			XORL CX, CX											
  connection.go:2550		0x6c3932		ffd2			CALL DX												
  connection.go:2744		0x6c3934		488b8c24c0020000	MOVQ 0x2c0(SP), CX										
  connection.go:2744		0x6c393c		488b81a0020000		MOVQ 0x2a0(CX), AX										
  connection.go:2552		0x6c3943		90			NOPL												
  connection.go:2744		0x6c3944		488d9c24c3000000	LEAQ 0xc3(SP), BX										
  connection.go:2744		0x6c394c		e80f6dd5ff		CALL runtime.selectnbsend(SB)									
  connection.go:2553		0x6c3951		488d8c2420010000	LEAQ 0x120(SP), CX										
  connection.go:2553		0x6c3959		440f1139		MOVUPS X15, 0(CX)										
  connection.go:2553		0x6c395d		440f117910		MOVUPS X15, 0x10(CX)										
  connection.go:2553		0x6c3962		440f117920		MOVUPS X15, 0x20(CX)										
  connection.go:2553		0x6c3967		488b9c2428010000	MOVQ 0x128(SP), BX										
  connection.go:2553		0x6c396f		4c8b842448010000	MOVQ 0x148(SP), R8										
  connection.go:2553		0x6c3977		c684243001000007	MOVB $0x7, 0x130(SP)										
  connection.go:2553		0x6c397f		31c0			XORL AX, AX											
  connection.go:2553		0x6c3981		b907000000		MOVL $0x7, CX											
  connection.go:2553		0x6c3986		31ff			XORL DI, DI											
  connection.go:2553		0x6c3988		31f6			XORL SI, SI											
  connection.go:2553		0x6c398a		4881c4b0020000		ADDQ $0x2b0, SP											
  connection.go:2553		0x6c3991		5d			POPQ BP												
  connection.go:2553		0x6c3992		c3			RET												
  mtu_discoverer.go:130		0x6c3993		48ffc6			INCQ SI												
  mtu_discoverer.go:130		0x6c3996		4883fe03		CMPQ SI, $0x3											
  mtu_discoverer.go:130		0x6c399a		7d1f			JGE 0x6c39bb											
  mtu_discoverer.go:130		0x6c399c		488bbcf400010000	MOVQ 0x100(SP)(SI*8), DI									
  mtu_discoverer.go:130		0x6c39a4		4883ffff		CMPQ DI, $-0x1											
  mtu_discoverer.go:131		0x6c39a8		75e9			JNE 0x6c3993											
  mtu_discoverer.go:132		0x6c39aa		488d7eff		LEAQ -0x1(SI), DI										
  mtu_discoverer.go:132		0x6c39ae		4883ff03		CMPQ DI, $0x3											
  mtu_discoverer.go:132		0x6c39b2		7321			JAE 0x6c39d5											
  mtu_discoverer.go:132		0x6c39b4		488b74f218		MOVQ 0x18(DX)(SI*8), SI										
  mtu_discoverer.go:157		0x6c39b9		eb04			JMP 0x6c39bf											
  mtu_discoverer.go:135		0x6c39bb		488b7230		MOVQ 0x30(DX), SI										
  mtu_discoverer.go:157		0x6c39bf		48037218		ADDQ 0x18(DX), SI										
  mtu_discoverer.go:157		0x6c39c3		4889f7			MOVQ SI, DI											
  mtu_discoverer.go:157		0x6c39c6		48c1ee3f		SHRQ $0x3f, SI											
  mtu_discoverer.go:157		0x6c39ca		4801fe			ADDQ DI, SI											
  mtu_discoverer.go:157		0x6c39cd		48d1fe			SARQ $0x1, SI											
  mtu_discoverer.go:157		0x6c39d0		e919fcffff		JMP 0x6c35ee											
  mtu_discoverer.go:132		0x6c39d5		e826b2dcff		CALL runtime.panicBounds(SB)									
  mtu_discoverer.go:132		0x6c39da		90			NOPL												
  connection.go:2517		0x6c39db		4889442408		MOVQ AX, 0x8(SP)										
  connection.go:2517		0x6c39e0		48895c2410		MOVQ BX, 0x10(SP)										
  connection.go:2517		0x6c39e5		e87694dcff		CALL runtime.morestack_noctxt.abi0(SB)								
  connection.go:2517		0x6c39ea		488b442408		MOVQ 0x8(SP), AX										
  connection.go:2517		0x6c39ef		488b5c2410		MOVQ 0x10(SP), BX										
  connection.go:2517		0x6c39f4		e927f3ffff		JMP github.com/quic-go/quic-go.(*Conn).emitPackets(SB)						
