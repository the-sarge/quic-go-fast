TEXT github.com/quic-go/quic-go.(*packetEmission).withGSO(SB) /Volumes/worktrees/quic-go-fast/e5-linux-candidate/packet_emission.go
  packet_emission.go:147	0x6ce8e0		4c8d6424e8		LEAQ -0x18(SP), R12							
  packet_emission.go:147	0x6ce8e5		4d3b6610		CMPQ R12, 0x10(R14)							
  packet_emission.go:147	0x6ce8e9		0f864a040000		JBE 0x6ced39								
  packet_emission.go:147	0x6ce8ef		55			PUSHQ BP								
  packet_emission.go:147	0x6ce8f0		4889e5			MOVQ SP, BP								
  packet_emission.go:147	0x6ce8f3		4881ec90000000		SUBQ $0x90, SP								
  buffer_pool.go:79		0x6ce8fa		48898424a0000000	MOVQ AX, 0xa0(SP)							
  buffer_pool.go:79		0x6ce902		48899c24a8000000	MOVQ BX, 0xa8(SP)							
  packet_emission.go:147	0x6ce90a		488d4c2448		LEAQ 0x48(SP), CX							
  packet_emission.go:147	0x6ce90f		440f1139		MOVUPS X15, 0(CX)							
  packet_emission.go:147	0x6ce913		440f117910		MOVUPS X15, 0x10(CX)							
  packet_emission.go:147	0x6ce918		440f117920		MOVUPS X15, 0x20(CX)							
  packet_emission.go:148	0x6ce91d		90			NOPL									
  buffer_pool.go:79		0x6ce91e		488d05dbbd4500		LEAQ github.com/quic-go/quic-go.largeBufferPool(SB), AX			
  buffer_pool.go:79		0x6ce925		e8f674dcff		CALL sync.(*Pool).Get(SB)						
  buffer_pool.go:79		0x6ce92a		488d0d178d3900		LEAQ 0x398d17(IP), CX							
  buffer_pool.go:79		0x6ce931		4839c8			CMPQ AX, CX								
  buffer_pool.go:79		0x6ce934		0f85ef030000		JNE 0x6ced29								
  buffer_pool.go:79		0x6ce93a		48899c2488000000	MOVQ BX, 0x88(SP)							
  buffer_pool.go:80		0x6ce942		48c7431801000000	MOVQ $0x1, 0x18(BX)							
  buffer_pool.go:81		0x6ce94a		48c7430800000000	MOVQ $0x0, 0x8(BX)							
  packet_emission.go:149	0x6ce952		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:149	0x6ce95a		488b5120		MOVQ 0x20(CX), DX							
  packet_emission.go:149	0x6ce95e		488b4128		MOVQ 0x28(CX), AX							
  packet_emission.go:149	0x6ce962		488b4a40		MOVQ 0x40(DX), CX							
  packet_emission.go:149	0x6ce966		ffd1			CALL CX									
  packet_emission.go:149	0x6ce968		4889442438		MOVQ AX, 0x38(SP)							
  packet_emission.go:150	0x6ce96d		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:150	0x6ce975		488b4908		MOVQ 0x8(CX), CX							
  packet_emission.go:150	0x6ce979		488b11			MOVQ 0(CX), DX								
  packet_emission.go:150	0x6ce97c		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:150	0x6ce980		488b4a20		MOVQ 0x20(DX), CX							
  packet_emission.go:150	0x6ce984		bb01000000		MOVL $0x1, BX								
  packet_emission.go:150	0x6ce989		ffd1			CALL CX									
  packet_emission.go:150	0x6ce98b		488b8c2488000000	MOVQ 0x88(SP), CX							
  packet_emission.go:151	0x6ce993		eb05			JMP 0x6ce99a								
  packet_emission.go:151	0x6ce995		4889d9			MOVQ BX, CX								
  packet_emission.go:151	0x6ce998		89f8			MOVL DI, AX								
  packet_emission.go:151	0x6ce99a		8844242d		MOVB AL, 0x2d(SP)							
  packet_emission.go:151	0x6ce99e		48898c2480000000	MOVQ CX, 0x80(SP)							
  packet_emission.go:153	0x6ce9a6		4889cb			MOVQ CX, BX								
  packet_emission.go:153	0x6ce9a9		488b4c2438		MOVQ 0x38(SP), CX							
  packet_emission.go:153	0x6ce9ae		89c7			MOVL AX, DI								
  packet_emission.go:153	0x6ce9b0		488bb424a8000000	MOVQ 0xa8(SP), SI							
  packet_emission.go:153	0x6ce9b8		488b8424a0000000	MOVQ 0xa0(SP), AX							
  packet_emission.go:153	0x6ce9c0		e83bf9ffff		CALL github.com/quic-go/quic-go.(*packetEmission).appendPacket(SB)	
  packet_emission.go:153	0x6ce9c5		4889442430		MOVQ AX, 0x30(SP)							
  packet_emission.go:154	0x6ce9ca		4885db			TESTQ BX, BX								
  packet_emission.go:154	0x6ce9cd		7461			JE 0x6cea30								
  packet_emission.go:153	0x6ce9cf		48894c2478		MOVQ CX, 0x78(SP)							
  packet_emission.go:153	0x6ce9d4		48895c2440		MOVQ BX, 0x40(SP)							
  packet_emission.go:153	0x6ce9d9		0f1f8000000000		NOPL 0(AX)								
  packet_emission.go:155	0x6ce9e0		48391d29ef4400		CMPQ github.com/quic-go/quic-go.errNothingToPack(SB), BX		
  packet_emission.go:155	0x6ce9e7		0f8549020000		JNE 0x6cec36								
  packet_emission.go:155	0x6ce9ed		488b1524ef4400		MOVQ github.com/quic-go/quic-go.errNothingToPack+8(SB), DX		
  packet_emission.go:155	0x6ce9f4		4889d8			MOVQ BX, AX								
  packet_emission.go:155	0x6ce9f7		4889cb			MOVQ CX, BX								
  packet_emission.go:155	0x6ce9fa		4889d1			MOVQ DX, CX								
  packet_emission.go:155	0x6ce9fd		0f1f00			NOPL 0(AX)								
  packet_emission.go:155	0x6cea00		e8db87d4ff		CALL runtime.ifaceeq(SB)						
  packet_emission.go:155	0x6cea05		84c0			TESTL AL, AL								
  packet_emission.go:155	0x6cea07		0f8429020000		JE 0x6cec36								
  buffer_pool.go:54		0x6cea0d		488b842480000000	MOVQ 0x80(SP), AX							
  buffer_pool.go:54		0x6cea15		4883780800		CMPQ 0x8(AX), $0x0							
  buffer_pool.go:54		0x6cea1a		660f1f440000		NOPW 0(AX)(AX*1)							
  packet_emission.go:160	0x6cea20		0f84e4010000		JE 0x6cec0a								
  packet_emission.go:154	0x6cea26		488b4c2440		MOVQ 0x40(SP), CX							
  packet_emission.go:154	0x6cea2b		4885c9			TESTQ CX, CX								
  packet_emission.go:160	0x6cea2e		eb08			JMP 0x6cea38								
  buffer_pool.go:54		0x6cea30		488b842480000000	MOVQ 0x80(SP), AX							
  packet_emission.go:166	0x6cea38		740b			JE 0x6cea45								
  packet_emission.go:166	0x6cea3a		b901000000		MOVL $0x1, CX								
  packet_emission.go:166	0x6cea3f		90			NOPL									
  packet_emission.go:166	0x6cea40		e98a000000		JMP 0x6ceacf								
  packet_emission.go:167	0x6cea45		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:167	0x6cea4d		488b4908		MOVQ 0x8(CX), CX							
  packet_emission.go:167	0x6cea51		488b11			MOVQ 0(CX), DX								
  packet_emission.go:167	0x6cea54		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:167	0x6cea58		488b4a78		MOVQ 0x78(DX), CX							
  packet_emission.go:167	0x6cea5c		488b9c24a8000000	MOVQ 0xa8(SP), BX							
  packet_emission.go:167	0x6cea64		ffd1			CALL CX									
  packet_emission.go:168	0x6cea66		3c05			CMPL AL, $0x5								
  packet_emission.go:168	0x6cea68		7425			JE 0x6cea8f								
  packet_emission.go:170	0x6cea6a		3c06			CMPL AL, $0x6								
  packet_emission.go:170	0x6cea6c		745c			JE 0x6ceaca								
  packet_emission.go:83		0x6cea6e		84c0			TESTL AL, AL								
  packet_emission.go:83		0x6cea70		7507			JNE 0x6cea79								
  packet_emission.go:83		0x6cea72		b902000000		MOVL $0x2, CX								
  packet_emission.go:171	0x6cea77		eb10			JMP 0x6cea89								
  packet_emission.go:85		0x6cea79		3c01			CMPL AL, $0x1								
  packet_emission.go:85		0x6cea7b		7507			JNE 0x6cea84								
  packet_emission.go:85		0x6cea7d		b905000000		MOVL $0x5, CX								
  packet_emission.go:171	0x6cea82		eb05			JMP 0x6cea89								
  packet_emission.go:171	0x6cea84		b906000000		MOVL $0x6, CX								
  packet_emission.go:171	0x6cea89		884c2458		MOVB CL, 0x58(SP)							
  packet_emission.go:171	0x6cea8d		eb3b			JMP 0x6ceaca								
  packet_emission.go:167	0x6cea8f		8844242c		MOVB AL, 0x2c(SP)							
  packet_emission.go:93		0x6cea93		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:93		0x6cea9b		488b4908		MOVQ 0x8(CX), CX							
  packet_emission.go:93		0x6cea9f		488b11			MOVQ 0(CX), DX								
  packet_emission.go:93		0x6ceaa2		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:93		0x6ceaa6		488b8a90000000		MOVQ 0x90(DX), CX							
  packet_emission.go:93		0x6ceaad		ffd1			CALL CX									
  time.go:52			0x6ceaaf		4885c0			TESTQ AX, AX								
  packet_emission.go:94		0x6ceab2		7507			JNE 0x6ceabb								
  packet_emission.go:169	0x6ceab4		488b05759e4200		MOVQ github.com/quic-go/quic-go.deadlineSendImmediately(SB), AX		
  packet_emission.go:169	0x6ceabb		c644245803		MOVB $0x3, 0x58(SP)							
  packet_emission.go:169	0x6ceac0		4889442460		MOVQ AX, 0x60(SP)							
  packet_emission.go:173	0x6ceac5		0fb644242c		MOVZX 0x2c(SP), AX							
  packet_emission.go:173	0x6ceaca		3c06			CMPL AL, $0x6								
  packet_emission.go:173	0x6ceacc		0f95c1			SETNE CL								
  packet_emission.go:175	0x6ceacf		884c242e		MOVB CL, 0x2e(SP)							
  packet_emission.go:175	0x6cead3		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:175	0x6ceadb		488b4908		MOVQ 0x8(CX), CX							
  packet_emission.go:175	0x6ceadf		488b11			MOVQ 0(CX), DX								
  packet_emission.go:175	0x6ceae2		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:175	0x6ceae6		488b4a20		MOVQ 0x20(DX), CX							
  packet_emission.go:175	0x6ceaea		bb01000000		MOVL $0x1, BX								
  packet_emission.go:175	0x6ceaef		ffd1			CALL CX									
  packet_emission.go:175	0x6ceaf1		8844242f		MOVB AL, 0x2f(SP)							
  packet_emission.go:175	0x6ceaf5		0fb64c242e		MOVZX 0x2e(SP), CX							
  packet_emission.go:175	0x6ceafa		84c9			TESTL CL, CL								
  packet_emission.go:176	0x6ceafc		754d			JNE 0x6ceb4b								
  packet_emission.go:176	0x6ceafe		488b542430		MOVQ 0x30(SP), DX							
  packet_emission.go:176	0x6ceb03		4c8b4c2438		MOVQ 0x38(SP), R9							
  packet_emission.go:176	0x6ceb08		4c39ca			CMPQ DX, R9								
  packet_emission.go:176	0x6ceb0b		752f			JNE 0x6ceb3c								
  packet_emission.go:176	0x6ceb0d		0fb67c242d		MOVZX 0x2d(SP), DI							
  packet_emission.go:176	0x6ceb12		4038f8			CMPL AL, DI								
  packet_emission.go:176	0x6ceb15		751b			JNE 0x6ceb32								
  buffer_pool.go:54		0x6ceb17		488b9c2480000000	MOVQ 0x80(SP), BX							
  buffer_pool.go:54		0x6ceb1f		488b5308		MOVQ 0x8(BX), DX							
  packet_emission.go:176	0x6ceb23		4c01ca			ADDQ R9, DX								
  packet_emission.go:176	0x6ceb26		48395310		CMPQ 0x10(BX), DX							
  packet_emission.go:176	0x6ceb2a		0f8d65feffff		JGE 0x6ce995								
  packet_emission.go:176	0x6ceb30		eb2b			JMP 0x6ceb5d								
  packet_emission.go:179	0x6ceb32		488b9c2480000000	MOVQ 0x80(SP), BX							
  packet_emission.go:176	0x6ceb3a		eb21			JMP 0x6ceb5d								
  packet_emission.go:179	0x6ceb3c		488b9c2480000000	MOVQ 0x80(SP), BX							
  packet_emission.go:179	0x6ceb44		0fb67c242d		MOVZX 0x2d(SP), DI							
  packet_emission.go:176	0x6ceb49		eb12			JMP 0x6ceb5d								
  packet_emission.go:179	0x6ceb4b		488b9c2480000000	MOVQ 0x80(SP), BX							
  packet_emission.go:179	0x6ceb53		0fb67c242d		MOVZX 0x2d(SP), DI							
  packet_emission.go:179	0x6ceb58		4c8b4c2438		MOVQ 0x38(SP), R9							
  packet_emission.go:179	0x6ceb5d		488b9424a0000000	MOVQ 0xa0(SP), DX							
  packet_emission.go:179	0x6ceb65		488b5210		MOVQ 0x10(DX), DX							
  packet_emission.go:179	0x6ceb69		4c8b12			MOVQ 0(DX), R10								
  packet_emission.go:179	0x6ceb6c		488b4208		MOVQ 0x8(DX), AX							
  packet_emission.go:179	0x6ceb70		498b5230		MOVQ 0x30(R10), DX							
  packet_emission.go:179	0x6ceb74		4c89c9			MOVQ R9, CX								
  packet_emission.go:179	0x6ceb77		31f6			XORL SI, SI								
  packet_emission.go:179	0x6ceb79		4531c0			XORL R8, R8								
  packet_emission.go:179	0x6ceb7c		ffd2			CALL DX									
  packet_emission.go:180	0x6ceb7e		c644244801		MOVB $0x1, 0x48(SP)							
  packet_emission.go:175	0x6ceb83		0fb654242e		MOVZX 0x2e(SP), DX							
  packet_emission.go:175	0x6ceb88		84d2			TESTL DL, DL								
  packet_emission.go:181	0x6ceb8a		0f8563010000		JNE 0x6cecf3								
  packet_emission.go:184	0x6ceb90		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:184	0x6ceb98		488b4910		MOVQ 0x10(CX), CX							
  packet_emission.go:184	0x6ceb9c		488b11			MOVQ 0(CX), DX								
  packet_emission.go:184	0x6ceb9f		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:184	0x6ceba3		488b4a40		MOVQ 0x40(DX), CX							
  packet_emission.go:184	0x6ceba7		ffd1			CALL CX									
  packet_emission.go:184	0x6ceba9		84c0			TESTL AL, AL								
  packet_emission.go:184	0x6cebab		0f85f8000000		JNE 0x6ceca9								
  packet_emission.go:188	0x6cebb1		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:188	0x6cebb9		488b5120		MOVQ 0x20(CX), DX							
  packet_emission.go:188	0x6cebbd		488b4128		MOVQ 0x28(CX), AX							
  packet_emission.go:188	0x6cebc1		488b4a20		MOVQ 0x20(DX), CX							
  packet_emission.go:188	0x6cebc5		ffd1			CALL CX									
  packet_emission.go:188	0x6cebc7		84c0			TESTL AL, AL								
  packet_emission.go:188	0x6cebc9		0f85a7000000		JNE 0x6cec76								
  buffer_pool.go:79		0x6cebcf		488d052abb4500		LEAQ github.com/quic-go/quic-go.largeBufferPool(SB), AX			
  buffer_pool.go:79		0x6cebd6		e84572dcff		CALL sync.(*Pool).Get(SB)						
  buffer_pool.go:79		0x6cebdb		488d0d668a3900		LEAQ 0x398a66(IP), CX							
  buffer_pool.go:79		0x6cebe2		4839c8			CMPQ AX, CX								
  buffer_pool.go:79		0x6cebe5		0f852f010000		JNE 0x6ced1a								
  buffer_pool.go:80		0x6cebeb		48c7431801000000	MOVQ $0x1, 0x18(BX)							
  buffer_pool.go:81		0x6cebf3		48c7430800000000	MOVQ $0x0, 0x8(BX)							
  packet_emission.go:153	0x6cebfb		4c8b4c2438		MOVQ 0x38(SP), R9							
  packet_emission.go:152	0x6cec00		0fb67c242f		MOVZX 0x2f(SP), DI							
  packet_emission.go:193	0x6cec05		e98bfdffff		JMP 0x6ce995								
  packet_emission.go:161	0x6cec0a		e89140feff		CALL github.com/quic-go/quic-go.(*packetBuffer).Release(SB)		
  packet_emission.go:162	0x6cec0f		0fb6442448		MOVZX 0x48(SP), AX							
  packet_emission.go:162	0x6cec14		488b5c2450		MOVQ 0x50(SP), BX							
  packet_emission.go:162	0x6cec19		0fb64c2458		MOVZX 0x58(SP), CX							
  packet_emission.go:162	0x6cec1e		488b7c2460		MOVQ 0x60(SP), DI							
  packet_emission.go:162	0x6cec23		488b742468		MOVQ 0x68(SP), SI							
  packet_emission.go:162	0x6cec28		4c8b442470		MOVQ 0x70(SP), R8							
  packet_emission.go:162	0x6cec2d		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:162	0x6cec34		5d			POPQ BP									
  packet_emission.go:162	0x6cec35		c3			RET									
  packet_emission.go:156	0x6cec36		488b842480000000	MOVQ 0x80(SP), AX							
  packet_emission.go:156	0x6cec3e		6690			NOPW									
  packet_emission.go:156	0x6cec40		e85b40feff		CALL github.com/quic-go/quic-go.(*packetBuffer).Release(SB)		
  packet_emission.go:157	0x6cec45		488b742440		MOVQ 0x40(SP), SI							
  packet_emission.go:157	0x6cec4a		4889742468		MOVQ SI, 0x68(SP)							
  packet_emission.go:157	0x6cec4f		4c8b442478		MOVQ 0x78(SP), R8							
  packet_emission.go:157	0x6cec54		4c89442470		MOVQ R8, 0x70(SP)							
  packet_emission.go:158	0x6cec59		0fb6442448		MOVZX 0x48(SP), AX							
  packet_emission.go:158	0x6cec5e		488b5c2450		MOVQ 0x50(SP), BX							
  packet_emission.go:158	0x6cec63		0fb64c2458		MOVZX 0x58(SP), CX							
  packet_emission.go:158	0x6cec68		488b7c2460		MOVQ 0x60(SP), DI							
  packet_emission.go:158	0x6cec6d		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:158	0x6cec74		5d			POPQ BP									
  packet_emission.go:158	0x6cec75		c3			RET									
  packet_emission.go:189	0x6cec76		c644245804		MOVB $0x4, 0x58(SP)							
  packet_emission.go:189	0x6cec7b		488b3dae9c4200		MOVQ github.com/quic-go/quic-go.deadlineSendImmediately(SB), DI		
  packet_emission.go:189	0x6cec82		48897c2460		MOVQ DI, 0x60(SP)							
  packet_emission.go:190	0x6cec87		0fb6442448		MOVZX 0x48(SP), AX							
  packet_emission.go:190	0x6cec8c		488b5c2450		MOVQ 0x50(SP), BX							
  packet_emission.go:190	0x6cec91		488b742468		MOVQ 0x68(SP), SI							
  packet_emission.go:190	0x6cec96		4c8b442470		MOVQ 0x70(SP), R8							
  packet_emission.go:190	0x6cec9b		b904000000		MOVL $0x4, CX								
  packet_emission.go:190	0x6ceca0		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:190	0x6ceca7		5d			POPQ BP									
  packet_emission.go:190	0x6ceca8		c3			RET									
  packet_emission.go:185	0x6ceca9		488b8c24a0000000	MOVQ 0xa0(SP), CX							
  packet_emission.go:185	0x6cecb1		488b4910		MOVQ 0x10(CX), CX							
  packet_emission.go:185	0x6cecb5		488b11			MOVQ 0(CX), DX								
  packet_emission.go:185	0x6cecb8		488b4108		MOVQ 0x8(CX), AX							
  packet_emission.go:185	0x6cecbc		488b4a18		MOVQ 0x18(DX), CX							
  packet_emission.go:185	0x6cecc0		ffd1			CALL CX									
  packet_emission.go:185	0x6cecc2		c644245801		MOVB $0x1, 0x58(SP)							
  packet_emission.go:185	0x6cecc7		4889442450		MOVQ AX, 0x50(SP)							
  packet_emission.go:186	0x6ceccc		0fb64c2448		MOVZX 0x48(SP), CX							
  packet_emission.go:186	0x6cecd1		488b7c2460		MOVQ 0x60(SP), DI							
  packet_emission.go:186	0x6cecd6		488b742468		MOVQ 0x68(SP), SI							
  packet_emission.go:186	0x6cecdb		4c8b442470		MOVQ 0x70(SP), R8							
  packet_emission.go:186	0x6cece0		4889c3			MOVQ AX, BX								
  packet_emission.go:186	0x6cece3		89c8			MOVL CX, AX								
  packet_emission.go:186	0x6cece5		b901000000		MOVL $0x1, CX								
  packet_emission.go:186	0x6cecea		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:186	0x6cecf1		5d			POPQ BP									
  packet_emission.go:186	0x6cecf2		c3			RET									
  packet_emission.go:182	0x6cecf3		488b5c2450		MOVQ 0x50(SP), BX							
  packet_emission.go:182	0x6cecf8		0fb64c2458		MOVZX 0x58(SP), CX							
  packet_emission.go:182	0x6cecfd		488b7c2460		MOVQ 0x60(SP), DI							
  packet_emission.go:182	0x6ced02		488b742468		MOVQ 0x68(SP), SI							
  packet_emission.go:182	0x6ced07		4c8b442470		MOVQ 0x70(SP), R8							
  packet_emission.go:182	0x6ced0c		b801000000		MOVL $0x1, AX								
  packet_emission.go:182	0x6ced11		4881c490000000		ADDQ $0x90, SP								
  packet_emission.go:182	0x6ced18		5d			POPQ BP									
  packet_emission.go:182	0x6ced19		c3			RET									
  buffer_pool.go:79		0x6ced1a		4889cb			MOVQ CX, BX								
  buffer_pool.go:79		0x6ced1d		488d0dc4e73d00		LEAQ 0x3de7c4(IP), CX							
  buffer_pool.go:79		0x6ced24		e8b7f9d4ff		CALL runtime.panicdottypeE(SB)						
  buffer_pool.go:79		0x6ced29		4889cb			MOVQ CX, BX								
  buffer_pool.go:79		0x6ced2c		488d0db5e73d00		LEAQ 0x3de7b5(IP), CX							
  buffer_pool.go:79		0x6ced33		e8a8f9d4ff		CALL runtime.panicdottypeE(SB)						
  buffer_pool.go:79		0x6ced38		90			NOPL									
  packet_emission.go:147	0x6ced39		4889442408		MOVQ AX, 0x8(SP)							
  packet_emission.go:147	0x6ced3e		48895c2410		MOVQ BX, 0x10(SP)							
  packet_emission.go:147	0x6ced43		e818e1dbff		CALL runtime.morestack_noctxt.abi0(SB)					
  packet_emission.go:147	0x6ced48		488b442408		MOVQ 0x8(SP), AX							
  packet_emission.go:147	0x6ced4d		488b5c2410		MOVQ 0x10(SP), BX							
  packet_emission.go:147	0x6ced52		e989fbffff		JMP github.com/quic-go/quic-go.(*packetEmission).withGSO(SB)		
