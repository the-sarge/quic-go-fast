from pathlib import Path
old=Path('/home/josh/.cache/qgf-e5');root=Path('/home/josh/.cache/qgf-e5-r2')
for name in ['endpoint.go','collect.py','isolate.sh','alloc.py','phases.py','build.py','analyze-e4.py']:
 s=(old/name).read_text().replace('qgf-e5','qgf-e5-r2').replace('e5-linux','e5-r2-linux').replace('E5 initial P3 campaign','E5 replacement P3 campaign after C-003 active-slot correction')
 (root/name).write_text(s)
